unit VDbTypes;
{ VDbTypes - paylasilan temel tipler.

  NEDEN AYRI BIRIM:
    VDbAst ve VDbTable birbirini kullaniyordu:
      VDbAst.pas -> uses VDbTable   (AST dugumleri TStrArray, TColDef,
                                     TFkDef, TWhereGroups, TTrigger* kullanir)
      VDbTable.pas -> uses VDbAst    (TViewDef.SelectStmt, TTriggerDef.WhenCondition,
                                     TColumnDef.DefaultExpr, TProcedureDef.Body AST tutar)
    Bu iki yonlu bagimlilik FPC'de derlenmez:
      "Fatal: Circular unit reference between VDbAst and VDbTable"

  Cozum: AST ile katalog arasinda paylasilan, HICBIRBIR DIZIYE
  BAGIMLI OLMAYAN tipler buraya tasindi. Iki birim de bunu kullanir;
    - VDbAst'in interface'inden VDbTable cikarildi (implementation'a
      tasindi: VDbNorm / VDbFloatToStr yalnizca uygulama kodunda
      gerekiyor),
    - VDbTable tip tanimlarini buradan alir.
  Boylece dongu kalici olarak kirilir ve AST'yi katalog birimi de
  tutabilir hale gelir (CREATE VIEW/Trigger/FUNCTION icin gerekli).

  ONEMLI: VDbTable bu birimi INTERFACE'inde uses ediyor. Pascal'da
  interface uses zincirleme (transitive) oldugu icin, VDbTable'i kullanan
  HICBIR birim bu tipleri kendi uses listesine eklemeden gorur - yani
  diger dosyalarda HICBIR DEGISIKLIK gerekmez.
}
{$mode delphi}{$H+}

interface

uses
  SysUtils;

const
  VCT_INT = 0;
  VCT_FLOAT = 1;
  VCT_STR = 2;
  VCT_BOOL = 3;
  VCT_DATE = 4;     // ISO yyyy-mm-dd metin
  VCT_DATETIME = 5; // ISO yyyy-mm-dd hh:nn:ss metin
  VCT_TIME = 6;     // ISO hh:nn:ss metin
  VCT_BLOB = 7;     // ham byte
  // F2-12: ON DELETE/UPDATE CASCADE zinciri ozguc doner (Delete ->
  // CheckRestrict -> Delete -> ...). CYCLE varsa (a -> b -> a) sonsuza
  // kadar doner (yigin tasmasi + sinirsiz silme). Azami derinlik.
  VDB_MAX_CASCADE_DEPTH = 32;

  // Sema tek dosyada: katalog ayrilmis key altinde KV icinde durur.
  // 0 kullanilir cunku VDbHashKey asla 0 uretmez (bak: asagida).
  VDB_SCHEMA_KEY: QWord = 0;
  VDB_SCHEMA_TAG = 'VSCH1';

  // Flags for VDbCore
  VDB_FLAG_PUT = 0;
  VDB_FLAG_DEL = 1;
  VDB_FLAG_BATCHEND = 2;
  VDB_FLAG_ENCRYPTED = 4;
  VDB_FLAG_COMPRESSED = 8;
  VDB_MAX_VALUE = 16 * 1024 * 1024;

  // File header
  VDB_FILE_MAGIC = $42444F56; // 'VODB' little-endian
  VDB_FILE_VER = 2;
  VDB_FILE_VER_OLD = 1;
  VDB_HDR_SIZE = 16;
  VDB_HFLAG_HAS_ENCRYPTED = 1;

  // Index key separator
  VDB_IDX_SEP = #1;

  // FK actions
  VDB_FK_RESTRICT = 'RESTRICT';
  VDB_FK_CASCADE = 'CASCADE';
  VDB_FK_SETNULL = 'SETNULL';
  VDB_FK_SETDEFAULT = 'SETDEFAULT';

type
  // --- basit dizi kisayollari ---
  TStrArray = array of string;
  TStrMatrix = array of TStrArray;
  TIntArray = array of Integer;
  TByteArray = array of Byte;

  // --- kolon tanimi ---
  TColDef = record
    Name: string;   // lower-case saklanir
    Ctype: Byte;
    NotNull: Boolean;
    Unique: Boolean;
    HasDef: Boolean;
    Def: string;    // ham literal (kullanimda normallesir)
  end;
  TColArray = array of TColDef;

  // --- yabanci anahtar ---
  TFkDef = record
    Col: Integer;     // cocuk kolon
    RefTable: string; // lower
    RefCol: string;   // lower
    // Referansli ebeveyn satiri silinince/guncellenince ne olacak:
    //   'RESTRICT' (varsayilan) | 'CASCADE' | 'SETNULL' | 'SETDEFAULT'
    OnDelete: string;
    OnUpdate: string;
  end;

  // Function/Procedure parametresi (F-35)
  TFunctionParameter = record
    Name: string;
    TypeName: string;
    Mode: Byte; // 0=IN, 1=OUT, 2=INOUT
    DefaultExpr: Pointer;
  end;

  // R-03: ON CONFLICT action
  TOnConflictAction = (ocaNone, ocaDoNothing, ocaDoUpdate);

  // --- UPDATE ... SET ifadesi ---
  //   Kind = 0 : Duz deger (E.Lit)
  //   Kind = 1 : <kolon> Op <deger>   (orn. n = n + 1)
  //   Kind = 2 : <kolon> Op <deger>   (orn. n = n - b)
  // Op: '+', '-', '*', '/', '%'
  TSetExpr = record
    Kind: Byte;
    ColA: Integer;   // sol taraf tablo kolonu
    ColB: Integer;   // sag taraf kolonu (-1 = degil)
    Op: Char;
    Lit: string;     // sag taraf sabiti
  end;
  TSetExprs = array of TSetExpr;

  // R-03: ON CONFLICT DO UPDATE SET col = <value> ciftleri.
  //   dizi: kolon indeksi + deger (string olarak saklanir, tip cevirimi
  //   uygulayici tarafta yapilir).
  TSetValuePair = record
    ColIdx: Integer;
    Value: string;
  end;
  TSetValuePairs = array of TSetValuePair;

  // --- WHERE: OR'lanmis AND gruplari (DNF). OR yoksa tek grup ---
  TWhereCond = record
    Col: Integer;   // tablo kolon indexi
    Ctype: Byte;    // kolon tipi: karsilastirma tip-bilgili olsun
                    // (TEXT kolonunda '007' ile '7' eslesmesin diye sart)
    Op: string;     // = <> != > < >= <= LIKE NOTLIKE ISNULL ISNOTNULL
                    // IN NOTIN BETWEEN NOTBETWEEN
    Val: string;    // tek degerli operatorler icin
    Vals: TStrArray;// IN (...) listesi ve BETWEEN ust siniri
  end;
  TWhereGroup = array of TWhereCond;
  TWhereGroups = array of TWhereGroup;

  // --- JOIN/WHERE cozumlemede tablo gorunumu ---
  // (Base = birlestirilmis satir ofseti)
  TTableRef = record
    Name: string;
    Alias: string;
    Cols: TColArray;
    Base: Integer;
  end;

  // --- F-35 FUNCTION/PROCEDURE ---
  TFunctionParameter = record
    Name: string;
    TypeName: string;
    Mode: Byte; // 0=IN, 1=OUT, 2=INOUT
    DefaultExpr: Pointer; // TSqlExprNode
  end;

  TFunctionDef = record
    Name: string;
    Parameters: array of TFunctionParameter;
    ReturnType: string;
    Language: string;
    Body: Pointer; // TSqlStmtNode
    IsFunction: Boolean;
  end;

  // --- F-36 TRIGGER ---
  TTriggerEvent = (teInsert, teUpdate, teDelete);
  TTriggerTiming = (ttBefore, ttAfter, ttInsteadOf);
  TTriggerForEach = (tfRow, tfStatement);

  TTriggerDef = record
    Name: string;           // lower-case
    TableName: string;      // target table
    Events: array of Byte;  // TTriggerEvent values
    Timing: Byte;           // TTriggerTiming
    ForEach: Byte;          // TTriggerForEach
    WhenCondition: Pointer; // TSqlExprNode - WHEN condition
    FunctionName: string;   // function to execute
  end;

implementation

end.
