program sqltest;

{ VDB SQL tam test paketi.

  Tum desteklenen SQL komutlarini calistirir, beklenen sonucu karsilastirir.

  Derleme:  lazbuild sqltest.lpi
  Calistirma: sqltest.exe <calisma-klasoru>

  klasor verilmezse gecici klasor kullanilir. }
{$mode delphi}{$H+}

uses
  SysUtils, Classes, VDbCore, VDbTable, VDbSql, VDbSync, VDbCrc32, VDbCrypt,
  VDbSpatial, VDbRange;

var
  D: string;
  kv: TVDb;
  tb: TVTableDb;
  sq: TVSql;
  R: TSqlResult;
  nPass, nFail, nGrp: Integer;
  grpName: string;

const
  Q = '''';   // tek tirnak
  WAL_MAGIC_BEKLENEN = LongWord($57414C52);   // 'WALR'

{ ------------------------------------------------------------ yardimcilar }

procedure Grp(const N: string);
begin
  Inc(nGrp);
  grpName := N;
  WriteLn;
  WriteLn('== ', nGrp, '. ', N);
end;

procedure Ok(const Nm, E: string);
begin
  Inc(nPass);
  if E = '' then WriteLn('   OK   ', Nm)
  else WriteLn('   OK   ', Nm, '   [', E, ']');
end;

procedure No(const Nm, E: string);
begin
  Inc(nFail);
  WriteLn('   FAIL ', Nm, '   [', E, ']');
end;

procedure Chk(const Nm, Sql: string; const ExpectRows: Integer);
var e: string;
begin
  try
    R := sq.Exec(Sql);
    if ExpectRows >= 0 then
    begin
      if Length(R.Rows) = ExpectRows then Ok(Nm, IntToStr(Length(R.Rows)) + ' satir')
      else No(Nm, 'beklenen ' + IntToStr(ExpectRows) + ' satir, gelen ' +
                 IntToStr(Length(R.Rows)));
    end
    else Ok(Nm, '');
  except
    on E: Exception do No(Nm, '(' + E.Message + ')');
  end;
end;

procedure ChkVal(const Nm, Sql: string; RowIx, ColIx: Integer;
  const Want: string);
var got: string;
begin
  try
    R := sq.Exec(Sql);
    if (RowIx >= Length(R.Rows)) or (ColIx >= Length(R.Rows[RowIx])) then
    begin
      No(Nm, 'sonuc hucre yok (satir ' + IntToStr(RowIx) + '/' +
              IntToStr(Length(R.Rows)) + ')');
      Exit;
    end;
    got := R.Rows[RowIx][ColIx];
    if got = Want then Ok(Nm, got)
    else No(Nm, 'beklenen "' + Want + '" gelen "' + got + '"');
  except
    on E: Exception do No(Nm, '(' + E.Message + ')');
  end;
end;

// F-20: Sonuc metni bir ALT DIZGI iceriyor mu? (EXPLAIN plan icerigi)
procedure ChkHas(const Nm, Sql, Want: string);
var
  all: string;
  k: Integer;
begin
  try
    R := sq.Exec(Sql);
    all := '';
    for k := 0 to High(R.Rows) do
      all := all + R.Rows[k][0] + ' | ';
    if Pos(Want, all) > 0 then Ok(Nm, 'bulundu: ' + Want)
    else No(Nm, '"' + Want + '" bulunamadi; plan: ' + all);
  except
    on E: Exception do No(Nm, '(' + E.Message + ')');
  end;
end;

// F-21: sonucun TUM hucelerinde bir alt dize arar (cok satirlik rapor)
procedure ChkHas2(const Nm, Sql, Want: string);
var
  all: string;
  k, c: Integer;
begin
  try
    R := sq.Exec(Sql);
    all := '';
    for k := 0 to High(R.Rows) do
      for c := 0 to High(R.Rows[k]) do
        all := all + R.Rows[k][c] + ' | ';
    if Pos(Want, all) > 0 then Ok(Nm, 'bulundu: ' + Want)
    else No(Nm, '"' + Want + '" bulunamadi; icerik: ' + all);
  except
    on E: Exception do No(Nm, '(' + E.Message + ')');
  end;
end;

// Sonuc matrisini tek satira dok (hata ayiklama / tani)
procedure Dump(const Nm, Sql: string);
var
  acc: string;
  k: Integer;
begin
  try
    R := sq.Exec(Sql);
    acc := '';
    for k := 0 to High(R.Rows) do
    begin
      if k > 0 then acc := acc + ' | ';
      acc := acc + R.Rows[k][0];
    end;
    Ok(Nm, acc);
  except
    on E: Exception do Ok(Nm, 'HATA: ' + E.Message);
  end;
end;

// Calistirilmasi beklenen, HATA vermesi gereken komut
procedure ChkErr(const Nm, Sql: string);
begin
  try
    sq.Exec(Sql);
    No(Nm, 'HATA VERMEDI (kabul edildi)');
  except
    on E: Exception do Ok(Nm, E.Message);
  end;
end;

procedure ChkInt(const Nm: string; const Got, Expect: Integer);
// TSqlResult sayisal alanlarini (Affected / Stmts) dogrudan dogrular.
begin
  if Got = Expect then Ok(Nm, IntToStr(Got))
  else No(Nm, 'beklenen ' + IntToStr(Expect) + ', gelen ' + IntToStr(Got));
end;

// Ayri bir calisma yerinde gecici acma/kapatma
procedure Fresh(const Nm: string);
var p: string;
begin
  p := D + '\' + Nm;
  ForceDirectories(p);
  if tb <> nil then begin tb.Close; kv.Close; sq.Free; tb.Free; kv.Free; end;
  kv := TVDb.Create; tb := TVTableDb.Create(kv); sq := TVSql.Create(tb);
  kv.Open(p);
  tb.Open(p);
end;

procedure UseDir(const Nm: string);
var p: string;
begin
  p := D + '\' + Nm;
  ForceDirectories(p);
  if tb <> nil then begin tb.Close; kv.Close; sq.Free; tb.Free; kv.Free; end;
  kv := TVDb.Create; tb := TVTableDb.Create(kv); sq := TVSql.Create(tb);
  kv.Open(p);
  tb.Open(p);
end;

procedure Shutdown;
begin
  if tb <> nil then
  begin
    tb.Close; kv.Close; sq.Free; tb.Free; kv.Free;
    sq := nil; tb := nil; kv := nil;
  end;
end;

{ ------------------------------------------------------------------ TESTLER }

{ Test icin sifreleme anahtari uretir. Gercek kullanimda anahtar
  .key dosyasindan gelir; burada sabitlenebilir olsun diye tohumdan
  uretiliyor. }
function TestKey(Seed: Integer): TBytes;
var
  i: Integer;
begin
  SetLength(Result, VDB_KEY_LEN);
  for i := 0 to VDB_KEY_LEN - 1 do
    Result[i] := Byte((i * 37 + Seed * 11 + 5) mod 251);
end;

{ Get cagrisinda istisna olup OLMADIGINI dondurur. Sessizce bozuk veri
  donmesi en kotu hatadir; bu yuzden her "hata bekleniyor" kontrolu
  bununla yapilir. }
function OkunduMu(A: TVDb; Key: QWord; out Val: TBytes): Boolean;
begin
  Result := True;
  try
    Result := A.Get(Key, Val);
  except
    on E: Exception do Result := False;
  end;
end;

procedure T74_KayitSifreleme;
{ 2026-10-05 KAYIT SEVIYESI SIFRELEME.

  TASNIT EDILEN SEMANTIK:
    a) Sifreleme KAPALI iken davranis degismez (geriye donuk uyum).
    b) Anahtar verilince Put degeri SIFRELI yazilir (bayrak set).
    c) Get/ScanAll degeri COZER - cagiran daima duz metin gorur.
    d) Duz metin, sifreli baytlarda BULUNMAZ.
    e) Ayni deger iki kez yazilirsa sifreli baytlar FARKLIDIR
       (her yazimda yeni IV).
    f) Yeniden acma (Close/Open) sonrasi anahtarla okunur.
    g) YANLIS/eksik anahtarla okuma ETIKET DOGRULAMASI ile hata verir;
       sessizce bozuk veri DONDURMEZ.
    h) SILME kaydi (tombstone) sifrelenmez.
    i) Karisik dosya: sifreleme kapaliyken yazilan kayit da
       sifreli olanla birlikte okunabilir.
    j) WAL'a DUZ METIN yazilir (sifreli veri birikmez).
    k) .key dosyasi ile ucuncu sonu yol.

  NOT: Dosya icerigi taramalari (d) ve (j) DAIMA dosya KAPALI iken
  yapilir. Motor dosyayi fmOpenReadWrite ile tutuyor; acikken tarama
  EFOpenError verir.
}
var
  myKv: TVDb;
  v: TBytes;
  k: TBytes;
  kp, dbp: string;
  sK: TQWordArray;
  sV: TValArray;
  i: Integer;
  bulundu: Boolean;

  procedure Dogrula(const Ad: string; Cond: Boolean; const E: string = '');
  begin
    if Cond then Ok(Ad, E) else No(Ad, E);
  end;

  { Dosyada duz metni arar (sifreleme KANITI). Dosya KAPALI olmali. }
  function DosyadaDuzMetin(const FN, Aranan: string): Boolean;
  var
    fs2: TFileStream;
    buf: array[0..65535] of Byte;
    n, got: Int64;
    j: Integer;
    s: string;
  begin
    Result := False;
    if not FileExists(FN) then Exit;
    fs2 := TFileStream.Create(FN, fmOpenRead or fmShareDenyNone);
    try
      n := fs2.Size;
      SetLength(s, 0);
      while n > 0 do
      begin
        got := fs2.Read(buf, 65536);
        if got <= 0 then Break;
        SetLength(s, Length(s) + Integer(got));
        for j := 0 to Integer(got) - 1 do
          s[Length(s) - Integer(got) + j + 1] := Chr(buf[j]);
        n := n - got;
      end;
      Result := Pos(Aranan, s) > 0;
    finally
      fs2.Free;
    end;
  end;

begin
  Grp('KAYIT SEVIYESI SIFRELEME (VDB_FLAG_ENCRYPTED)');

  // ---- a) varsayilan KAPALI: davranis degismez ----
  myKv := TVDb.Create;
  try
    myKv.Open(D + '\enc1.odb');
    Dogrula('varsayilan sifreleme KAPALI', not myKv.IsEncrypted);
    myKv.Put(1, VDbStrToBytes('gizli-metin'));
    SetLength(v, 0);
    Dogrula('kapali iken normal okuma',
      myKv.Get(1, v) and (VDbBytesToStr(v) = 'gizli-metin'), VDbBytesToStr(v));
  finally
    myKv.Free;
  end;
  Dogrula('a) kapali iken dosyada duz metin VAR (geriye donuk uyum)',
    DosyadaDuzMetin(D + '\enc1.odb', 'gizli-metin'));

  // ---- b,c,e,f,h) acik iken yaz-oku ----
  dbp := D + '\enc2.odb';
  myKv := TVDb.Create;
  k := TestKey(1);
  try
    myKv.Open(dbp);
    myKv.SetEncryptionKey(k);
    Dogrula('b) anahtar verildi -> IsEncrypted', myKv.IsEncrypted);
    Dogrula('parmak izi 8 hex karakter', Length(myKv.EncryptionKeyFingerprint) = 8,
      myKv.EncryptionKeyFingerprint);

    myKv.Put(100, VDbStrToBytes('COK-GIZLI-SIFRELI-METIN'));
    SetLength(v, 0);
    Dogrula('c) sifreli kayit COZULDU (Get duz metin donuyor)',
      myKv.Get(100, v) and (VDbBytesToStr(v) = 'COK-GIZLI-SIFRELI-METIN'),
      VDbBytesToStr(v));

    // e) ayni deger iki kez -> her seferinde yeni IV
    myKv.Put(100, VDbStrToBytes('COK-GIZLI-SIFRELI-METIN'));
    Dogrula('c) tekrar yazip yine dogru cozuldu',
      myKv.Get(100, v) and (VDbBytesToStr(v) = 'COK-GIZLI-SIFRELI-METIN'),
      VDbBytesToStr(v));

    // h) tombstone
    Dogrula('Delete basarili', myKv.Delete(100));
    Dogrula('h) tombstone sonrasi kayit YOK', not myKv.Get(100, v));

    // f) kalici kayit
    myKv.Put(200, VDbStrToBytes('kalici-gizli'));
  finally
    myKv.Free;
  end;

  Dogrula('d) duz metin ana dosyada YOK',
    not DosyadaDuzMetin(dbp, 'COK-GIZLI-SIFRELI-METIN'));
  Dogrula('d) kalici duz metin de dosyada YOK',
    not DosyadaDuzMetin(dbp, 'kalici-gizli'));

  // ---- f,g) yeniden acma ----
  myKv := TVDb.Create;
  try
    myKv.Open(dbp);
    Dogrula('f) yeniden acildi, sifreleme durumu sifirlandi',
      not myKv.IsEncrypted);
    SetLength(v, 0);
    Dogrula('g) anahtarsiz okuma ETIKET HATASI verir (sessizce bozuk donmez)',
      not OkunduMu(myKv, 200, v));
    Dogrula('g) anahtarsiz okumada veri DONDURULMADI', Length(v) = 0,
      'uzunluk=' + IntToStr(Length(v)));
  finally
    myKv.Free;
  end;

  myKv := TVDb.Create;
  try
    myKv.Open(dbp);
    myKv.SetEncryptionKey(TestKey(2));   // FARKLI anahtar
    SetLength(v, 0);
    Dogrula('g) YANLIS anahtarla okuma HATA verdi',
      not OkunduMu(myKv, 200, v));
    Dogrula('g) yanlis anahtarla veri DONDURULMADI', Length(v) = 0,
      'uzunluk=' + IntToStr(Length(v)));
  finally
    myKv.Free;
  end;

  myKv := TVDb.Create;
  try
    myKv.Open(dbp);
    myKv.SetEncryptionKey(k);
    SetLength(v, 0);
    Dogrula('f) dogru anahtarla yeniden acma sonrasi okundu',
      myKv.Get(200, v) and (VDbBytesToStr(v) = 'kalici-gizli'),
      VDbBytesToStr(v));

    // c) ScanAll de cozmus olmali
    SetLength(sK, 0);
    SetLength(sV, 0);
    myKv.ScanAll(sK, sV);
    bulundu := False;
    for i := 0 to Length(sV) - 1 do
      if VDbBytesToStr(sV[i]) = 'kalici-gizli' then
        bulundu := True;
    Dogrula('c) ScanAll sifreli degeri COZDU', bulundu,
      'kayit=' + IntToStr(Length(sV)));
  finally
    myKv.Free;
  end;

  // ---- j) WAL'a duz metin yazilir ----
  // DIKKAT: WAL yolu ChangeFileExt ile turetilir; 'enc3.odb.wal' DEGIL.
  dbp := D + '\enc3.odb';
  myKv := TVDb.Create;
  try
    myKv.Open(dbp);
    kp := myKv.WalPath;
    myKv.WALEnabled := True;
    myKv.SetEncryptionKey(TestKey(3));
    myKv.Put(1, VDbStrToBytes('wal-gizli-metin'));
    Dogrula('j) WAL kaydi yazildi', myKv.HasWAL);
  finally
    myKv.Free;
  end;
  Dogrula('j) WAL dosyasi gercekten olustu', FileExists(kp), kp);
  Dogrula('j) WAL icinde DUZ METIN var (sifreli veri birikmez)',
    DosyadaDuzMetin(kp, 'wal-gizli-metin'));
  Dogrula('j) ana dosyada duz metin YOK',
    not DosyadaDuzMetin(dbp, 'wal-gizli-metin'));

  // ---- i) karisik dosya ----
  myKv := TVDb.Create;
  try
    myKv.Open(D + '\enc4.odb');
    myKv.Put(1, VDbStrToBytes('duz-kayit'));          // sifreleme KAPALI
    myKv.SetEncryptionKey(TestKey(4));
    myKv.Put(2, VDbStrToBytes('sifreli-kayit'));      // sifreleme ACIK
    myKv.ClearEncryptionKey;
    myKv.Put(3, VDbStrToBytes('duz-kayit-2'));        // yine KAPALI
  finally
    myKv.Free;
  end;

  myKv := TVDb.Create;
  try
    myKv.Open(D + '\enc4.odb');
    myKv.SetEncryptionKey(TestKey(4));
    SetLength(v, 0);
    Dogrula('i) karisik dosyada duz kayit okundu',
      myKv.Get(1, v) and (VDbBytesToStr(v) = 'duz-kayit'), VDbBytesToStr(v));
    SetLength(v, 0);
    Dogrula('i) karisik dosyada sifreli kayit cozuldu',
      myKv.Get(2, v) and (VDbBytesToStr(v) = 'sifreli-kayit'), VDbBytesToStr(v));
    SetLength(v, 0);
    Dogrula('i) karisik dosyada sonraki duz kayit okundu',
      myKv.Get(3, v) and (VDbBytesToStr(v) = 'duz-kayit-2'), VDbBytesToStr(v));
  finally
    myKv.Free;
  end;

  // ---- k) .key dosyasi ile ucuncu sonu yol ----
  kp := D + '\enc5.key';
  myKv := TVDb.Create;
  try
    myKv.Open(D + '\enc5.odb');
    Dogrula('k) KeyPath dogru', myKv.KeyPath = D + '\enc5.key', myKv.KeyPath);
    Dogrula('k) .key dosyasi olusturuldu',
      myKv.CreateKeyFile(kp, 'sifreli-parola-1'));
    myKv.Put(1, VDbStrToBytes('key-dosyali-gizli'));
  finally
    myKv.Free;
  end;
  Dogrula('k) .key ile yazilan kayit dosyada duz metin DEGIL',
    not DosyadaDuzMetin(D + '\enc5.odb', 'key-dosyali-gizli'));

  myKv := TVDb.Create;
  try
    myKv.Open(D + '\enc5.odb');
    Dogrula('k) .key YANLIS parola reddedildi',
      not myKv.OpenKeyFile(kp, 'yanlis-parola-1'));
    Dogrula('k) .key dogru parola kabul edildi',
      myKv.OpenKeyFile(kp, 'sifreli-parola-1'));
    SetLength(v, 0);
    Dogrula('k) .key ile yazilan kayit cozuldu',
      myKv.Get(1, v) and (VDbBytesToStr(v) = 'key-dosyali-gizli'),
      VDbBytesToStr(v));
  finally
    myKv.Free;
  end;
end;

procedure T75_SifrelemeDayaniklilik;
{ 2026-10-05: Compact / BackupTo bayragi DUSURMELI.
  Bu, planin 9. maddesiydi ve gercek bir veri bozulmasiydi:
  Compact/BackupTo ham (sifreli) baytlari kopyalayip bayragi
  VDB_FLAG_PUT yapinca kayit "duz metin" ilan ediliyordu.
}
var
  myKv: TVDb;
  v: TBytes;
  ob, nb: Int64;
  k: TBytes;
  dbp: string;
  yedek: string;
  rep, Hata: string;
  sK: TQWordArray;
  sV: TValArray;
  bulundu: Boolean;
  i: Integer;

  procedure Dogrula(const Ad: string; Cond: Boolean; const E: string = '');
  begin
    if Cond then Ok(Ad, E) else No(Ad, E);
  end;

begin
  Grp('SIFRELEME DAYANIKLILIGI (Compact/BackupTo bayragi)');

  dbp := D + '\enc6.odb';
  yedek := D + '\enc6-yedek.odb';

  myKv := TVDb.Create;
  k := TestKey(9);
  try
    myKv.Open(dbp);
    myKv.SetEncryptionKey(k);
    myKv.Put(1, VDbStrToBytes('compact-sifreli-bir'));
    myKv.Put(2, VDbStrToBytes('compact-sifreli-iki'));
    myKv.Put(3, VDbStrToBytes('compact-sifreli-uc'));
    // olu surumler biriktir ki Compact gercekten calissin
    myKv.Put(1, VDbStrToBytes('compact-sifreli-bir'));
    myKv.Put(1, VDbStrToBytes('compact-sifreli-bir'));
    // duz metin kayit da karisik olsun
    myKv.ClearEncryptionKey;
    myKv.Put(4, VDbStrToBytes('karisik-duz-kayit'));
    myKv.SetEncryptionKey(k);

    myKv.Compact(ob, nb);
    Dogrula('Compact calisti', nb > 0, IntToStr(nb));
  finally
    myKv.Free;
  end;

  // Compact sonrasi hepsi okunmali
  myKv := TVDb.Create;
  try
    myKv.Open(dbp);
    myKv.SetEncryptionKey(k);
    SetLength(v, 0);
    Dogrula('Compact sonrasi sifreli kayit-1 okundu',
      myKv.Get(1, v) and (VDbBytesToStr(v) = 'compact-sifreli-bir'),
      VDbBytesToStr(v));
    SetLength(v, 0);
    Dogrula('Compact sonrasi sifreli kayit-2 okundu',
      myKv.Get(2, v) and (VDbBytesToStr(v) = 'compact-sifreli-iki'),
      VDbBytesToStr(v));
    SetLength(v, 0);
    Dogrula('Compact sonrasi sifreli kayit-3 okundu',
      myKv.Get(3, v) and (VDbBytesToStr(v) = 'compact-sifreli-uc'),
      VDbBytesToStr(v));
    SetLength(v, 0);
    Dogrula('Compact sonrasi karisik duz kayit okundu',
      myKv.Get(4, v) and (VDbBytesToStr(v) = 'karisik-duz-kayit'),
      VDbBytesToStr(v));
    Dogrula('Compact sonrasi kayit sayisi ayni', myKv.Count = 4,
      IntToStr(myKv.Count));

    { ScanAll de cozmus olmali: cagiran daima duz metin gorur. }
    SetLength(sK, 0);
    SetLength(sV, 0);
    myKv.ScanAll(sK, sV);
    Dogrula('Compact sonrasi ScanAll tum kayitlari dondurdu',
      Length(sK) = 4, IntToStr(Length(sK)));
    bulundu := False;
    for i := 0 to Length(sV) - 1 do
      if VDbBytesToStr(sV[i]) = 'compact-sifreli-iki' then
        bulundu := True;
    Dogrula('ScanAll sifreli degeri COZDU (duz metin dondu)', bulundu);

    myKv.BackupTo(yedek);
  finally
    myKv.Free;
  end;

  // yedekten okuma
  Dogrula('yedek dosyasi olustu', FileExists(yedek), yedek);
  myKv := TVDb.Create;
  try
    myKv.Open(yedek);
    myKv.SetEncryptionKey(k);
    SetLength(v, 0);
    Dogrula('Yedekte sifreli kayit okundu',
      myKv.Get(2, v) and (VDbBytesToStr(v) = 'compact-sifreli-iki'),
      VDbBytesToStr(v));
    SetLength(v, 0);
    Dogrula('Yedekte karisik duz kayit okundu',
      myKv.Get(4, v) and (VDbBytesToStr(v) = 'karisik-duz-kayit'),
      VDbBytesToStr(v));
    Dogrula('Yedekte kayit sayisi ayni', myKv.Count = 4,
      IntToStr(myKv.Count));
    Dogrula('Yedek Verify ile butunluk kontrolunden gecti',
      myKv.Verify(Hata), Hata);
  finally
    myKv.Free;
  end;

  // Verify, sifreli dosyada da gecmeli
  myKv := TVDb.Create;
  try
    myKv.Open(dbp);
    myKv.SetEncryptionKey(k);
    Dogrula('Sifreli dosya Verify ile gecti', myKv.Verify(Hata), Hata);
    myKv.ClearEncryptionKey;
    Dogrula('ClearEncryptionKey sonrasi IsEncrypted = False',
      not myKv.IsEncrypted);
  finally
    myKv.Free;
  end;
end;

procedure T76_ReplayWALSifreleme;
{ 2026-10-05 Adim 14: ReplayWAL sifreli veritabaninda:
   - anahtar YUKLU iken replay -> kayitlar yeniden sifrelenmis olarak durur
   - anahtarsız open edilince 'kayit SIFRELI: anahtar yok' mesaji verilir
   - batch/pending akisinda BeginBatch+Put+CommitBatch sifrelemeli
   - AutoCompact sifreli dosyada okunabilir kaliyor
}
var
  myKv: TVDb;
  v: TBytes;
  k: TBytes;
  dbp, wp: string;
  ob, nb: Int64;

  procedure Dogrula(const Ad: string; Cond: Boolean; const E: string = '');
  begin
    if Cond then Ok(Ad, E) else No(Ad, E);
  end;

begin
  Grp('WAL REPLAY + BATCH/AUTOCOMPACT (SIFRELI)');

  dbp := D + '\enc7.odb';
  myKv := TVDb.Create;
  k := TestKey(11);
  try
    myKv.Open(dbp);
    myKv.SetEncryptionKey(k);
    myKv.WALEnabled := True;
    myKv.Put(1, VDbStrToBytes('replay-gizli-1'));
    myKv.Put(2, VDbStrToBytes('replay-gizli-2'));
    wp := myKv.WalPath;
    Dogrula('WAL yazildi', myKv.HasWAL);
  finally
    myKv.Free;
  end;

  { .wal silinmeden yeniden ac: T73 Waloneacat 'reopened' sifreler ama
    ReplayWAL'i kendisi tetiklemez, manuel cagrilir. }
  myKv := TVDb.Create;
  try
    myKv.Open(dbp);
    myKv.SetEncryptionKey(k);
    Dogrula('ReplayWAL oncesi anahtarsiz anahtar dolu', myKv.IsEncrypted);
    Dogrula('ReplayWAL calisti', myKv.ReplayWAL);
    SetLength(v, 0);
    Dogrula('replay sonrasi sifreli okundu',
      myKv.Get(1, v) and (VDbBytesToStr(v) = 'replay-gizli-1'),
      VDbBytesToStr(v));
  finally
    myKv.Free;
  end;

  { batch/pending akisinda da uretilen sifreleme }
  myKv := TVDb.Create;
  try
    myKv.Open(D + '\enc8.odb');
    myKv.SetEncryptionKey(k);
    myKv.BeginBatch;
    myKv.Put(10, VDbStrToBytes('batch-sifreli-1'));
    myKv.Put(11, VDbStrToBytes('batch-sifreli-2'));
    myKv.CommitBatch;
  finally
    myKv.Free;
  end;
  myKv := TVDb.Create;
  try
    myKv.Open(D + '\enc8.odb');
    myKv.SetEncryptionKey(k);
    SetLength(v, 0);
    Dogrula('batch-1 okundu', myKv.Get(10, v) and (VDbBytesToStr(v) = 'batch-sifreli-1'), VDbBytesToStr(v));
    SetLength(v, 0);
    Dogrula('batch-2 okundu', myKv.Get(11, v) and (VDbBytesToStr(v) = 'batch-sifreli-2'), VDbBytesToStr(v));
  finally
    myKv.Free;
  end;

  { AutoCompact: sifreli kipte de CLR pattern'i (duz okur) korunur }
  dbp := D + '\enc9.odb';
  myKv := TVDb.Create;
  try
    myKv.Open(dbp);
    myKv.SetEncryptionKey(k);
    myKv.Put(1, VDbStrToBytes('oto-compact-1'));
    myKv.Put(1, VDbStrToBytes('oto-compact-1x'));
    myKv.AutoCompact(ob, nb, 0.0, 1); // dead>%0 ve boyut>=1 ile aninda
    SetLength(v, 0);
    Dogrula('AutoCompact sonrasi sifreli okundu',
      myKv.Get(1, v) and (VDbBytesToStr(v) = 'oto-compact-1x'),
      VDbBytesToStr(v));
  finally
    myKv.Free;
  end;
end;

procedure T77_AlterDatabaseKey;
{ 2026-10-05 Adim 15: ALTER DATABASE KEY 'parola':
  1) encrypted katalog korunur,
  2) eski parola .key'ten okunamaz,
  3) yeni parola .key ile okunur ve veriyi acar,
  4) yanlis yeni parola reddedilir.
}
var
  rep: string;
  R2: TSqlResult;

  procedure Dogrula(const Ad: string; Cond: Boolean; const E: string = '');
  begin
    if Cond then Ok(Ad, E) else No(Ad, E);
  end;

begin
  Grp('ALTER DATABASE KEY (parola rotasyonu)');
  UseDir('keyrot');
  kv.CreateKeyFile(D + '\keyrot\veritabani.key', 'eski-parola-1');
  sq.Exec('CREATE TABLE gizli(id INTEGER PRIMARY KEY, v TEXT)');
  sq.Exec('INSERT INTO gizli(id,v) VALUES(1,''gizli-bir'')');
  R2 := sq.Exec('ALTER DATABASE KEY ''yeni-parola-1''');
  Dogrula('REKEY', (R2.Affected = 1) and (R2.Msg <> ''), R2.Msg);
  // eski dosya .bak'ta kalir
  Dogrula('.bak var', FileExists(D + '\\keyrot\\veritabani.odb.bak'));

  // Key rotasyonunu uzaktan kontr: yeniden ac, yeni parola dogru,
  // eski parola reddedilir; ve veri okumak mumkun olur.
  kv.Close; tb.Close; sq.Free; tb.Free; kv.Free;
  kv := TVDb.Create; tb := TVTableDb.Create(kv); sq := TVSql.Create(tb);
  kv.Open(D + '\keyrot');
  // tb.Open semadan okur -> Sema KAYITLIYKEN sifrelenmistir, o yuzden
  // anahtari tb.Open'dan ONCE yuklemelidir (T74 benzeri).
  Dogrula('yeni parola ile OpenKeyFile', kv.OpenKeyFile(D + '\\keyrot\\veritabani.key', 'yeni-parola-1'));
  tb.Open(D + '\keyrot');
  Dogrula('eski parola reddedildi', not kv.OpenKeyFile(D + '\\keyrot\\veritabani.key', 'eski-parola-1'));
  R2 := sq.Exec('SELECT v FROM gizli WHERE id = 1');
  Dogrula('yeni parolayla veri okundu', R2.Rows[0][0] = 'gizli-bir', R2.Rows[0][0]);
  // eski .bak anahtariyla eski veri hala diriliyor mu
  Dogrula('.key.bak still okunabilir (eski parola)', kv.OpenKeyFile(D + '\\keyrot\\veritabani.key.bak', 'eski-parola-1'));
end;

procedure T79_Savepoint;
{ R-02: SAVEPOINT / ROLLBACK TO / RELEASE SAVEPOINT
  Test savepoint nesting, rollback to, and release.
}
begin
  Grp('SAVEPOINT (R-02)');
  UseDir('sp');
  sq.Exec('CREATE TABLE t(id INTEGER PRIMARY KEY, v INTEGER)');
  sq.Exec('INSERT INTO t(id,v) VALUES(1,10)');
  sq.Exec('SAVEPOINT sp1');
  sq.Exec('INSERT INTO t(id,v) VALUES(2,20)');
  sq.Exec('SAVEPOINT sp2');
  sq.Exec('INSERT INTO t(id,v) VALUES(3,30)');
  sq.Exec('ROLLBACK TO SAVEPOINT sp2');
  ChkVal('ROLLBACK TO sp2: 2 satir', 'SELECT COUNT(*) FROM t', 0, 0, '2');
  ChkVal('id=2 hala var', 'SELECT v FROM t WHERE id=2', 0, 0, '20');
  sq.Exec('INSERT INTO t(id,v) VALUES(4,40)');
  sq.Exec('SAVEPOINT sp3');
  sq.Exec('INSERT INTO t(id,v) VALUES(5,50)');
  sq.Exec('ROLLBACK TO SAVEPOINT sp1');
  ChkVal('ROLLBACK TO sp1: 1 satir', 'SELECT COUNT(*) FROM t', 0, 0, '1');
  ChkVal('id=1 hala var', 'SELECT v FROM t WHERE id=1', 0, 0, '10');
  sq.Exec('RELEASE SAVEPOINT sp1');
  sq.Exec('COMMIT');
  ChkVal('COMMIT sonrasi 1 satir', 'SELECT COUNT(*) FROM t', 0, 0, '1');
  sq.Exec('SAVEPOINT spA');
  sq.Exec('INSERT INTO t(id,v) VALUES(6,60)');
  sq.Exec('RELEASE SAVEPOINT spA');
  sq.Exec('ROLLBACK');
  ChkVal('ROLLBACK: spA release edildi, insert geri alindi', 'SELECT COUNT(*) FROM t', 0, 0, '1');
  Ok('SAVEPOINT temel islemler', '');
end;

procedure T78_AsofGecmis;
{ 2026-10-06 AS OF - WAL gecmisinden "o anki" okuma.

  SEMANTIK (hepsi WAL penceresine, yani son checkpoint'ten berine goredir;
  N = WAL kayit indeksi, 0 tabanli, N dahil uygulanmis goruntu):
    a) INSERT oncesi anlik noktada satir YOK, sonrasi VAR.
    b) UPDATE sonrasi ESKI deger gorunur (geriye donuk okuma).
    c) DELETE edilen satir eski aninda GORUNUR; DELETE sonrasi YOK.
    d) WHERE / ORDER BY / LIMIT / COUNT gecmis veriye uygulanir.
    e) seq sinir tasarsa son kayda kirpilir.
    f) AS OF TIMESTAMP / VERSION -> acik ecUnsupported (WAL'de zaman
       damgasi / surum numarasi YOKTUR).
    g) JOIN + AS OF -> ecUnsupported (gecmis goruntusu tek tabloya bakar).
    h) gecmisi olmayan (WAL kapali / checkpoint sonrasi) -> ecUnsupported.
    i) alias'li FROM ile yazilabilir; bozuk tur/sayi syntax hatasidir.
}
var
  a1, a2, a3, a4, a5: Integer;

  procedure Dogrula(const Ad: string; Cond: Boolean; const E: string = '');
  begin
    if Cond then Ok(Ad, E) else No(Ad, E);
  end;

begin
  Grp('AS OF (WAL gecmisinden okuma)');

  // ---- hazirlik: WAL acik, satirlar ve gecmis ----
  UseDir('asof1');
  kv.WALEnabled := True;
  sq.Exec('CREATE TABLE k(id INTEGER PRIMARY KEY, ad TEXT)');
  sq.Exec('CREATE TABLE diger(id INTEGER PRIMARY KEY, ad TEXT)');
  sq.Exec('INSERT INTO k(id,ad) VALUES(1,''bir'')');
  a1 := kv.WalRecordCount - 1;
  sq.Exec('INSERT INTO k(id,ad) VALUES(2,''iki'')');
  a2 := kv.WalRecordCount - 1;
  sq.Exec('UPDATE k SET ad = ''BIR-YENI'' WHERE id = 1');
  a3 := kv.WalRecordCount - 1;
  sq.Exec('DELETE FROM k WHERE id = 2');
  a4 := kv.WalRecordCount - 1;
  sq.Exec('INSERT INTO k(id,ad) VALUES(3,''uc'')');
  a5 := kv.WalRecordCount - 1;
  Dogrula('gecmis kayitlari birikti (>=6)', kv.WalRecordCount >= 6,
    IntToStr(kv.WalRecordCount));

  // ---- a) INSERT oncesi/sonrasi ----
  Chk('INSERT oncesi anlik nokta (1 satir)',
    'SELECT ad FROM k AS OF SEQUENCE ' + IntToStr(a1) + ' ORDER BY id', 1);
  ChkVal('INSERT oncesi deger "bir"',
    'SELECT ad FROM k AS OF SEQUENCE ' + IntToStr(a1) + ' ORDER BY id', 0, 0, 'bir');
  Chk('INSERT sonrasi nokta (2 satir)',
    'SELECT ad FROM k AS OF SEQUENCE ' + IntToStr(a2) + ' ORDER BY id', 2);
  ChkVal('2. satir "iki"',
    'SELECT ad FROM k AS OF SEQUENCE ' + IntToStr(a2) + ' ORDER BY id', 1, 0, 'iki');

  // ---- b) UPDATE oncesi/sonrasi ----
  ChkVal('UPDATE oncesi eski deger "bir"',
    'SELECT ad FROM k AS OF SEQUENCE ' + IntToStr(a2) + ' WHERE id = 1', 0, 0, 'bir');
  ChkVal('UPDATE sonrasi yeni deger',
    'SELECT ad FROM k AS OF SEQUENCE ' + IntToStr(a3) + ' WHERE id = 1', 0, 0, 'BIR-YENI');

  // ---- c) DELETE: eski aninda gorunur, sonrasi yok ----
  Chk('DELETE oncesi anlik nokta (2 satir)',
    'SELECT ad FROM k AS OF SEQUENCE ' + IntToStr(a3) + ' ORDER BY id', 2);
  ChkVal('...silinen satir o an hala var ("iki")',
    'SELECT ad FROM k AS OF SEQUENCE ' + IntToStr(a3) + ' ORDER BY id', 1, 0, 'iki');
  Chk('DELETE sonrasi anlik nokta (1 satir)',
    'SELECT ad FROM k AS OF SEQUENCE ' + IntToStr(a4) + ' ORDER BY id', 1);
  Chk('anlik sorguda silinen satir yok (0 satir)',
    'SELECT ad FROM k WHERE id = 2', 0);

  // ---- d/e) siralama, filtre, aggregate, sinir ----
  // NOT: en sonda id=2 silinmis durumda -> guncel tabloda 2 satir var
  // (id1 BIR-YENI, id3 uc); "uc" satiri 0. indekstir (ORDER BY id).
  Chk('son noktada guncel kume (2 satir, ORDER BY id)',
    'SELECT ad FROM k AS OF SEQUENCE ' + IntToStr(a5) + ' ORDER BY id', 2);
  ChkVal('2. satir "uc"',
    'SELECT ad FROM k AS OF SEQUENCE ' + IntToStr(a5) + ' ORDER BY id', 1, 0, 'uc');
  Chk('LIMIT gecmise uygulanir',
    'SELECT ad FROM k AS OF SEQUENCE ' + IntToStr(a5) + ' ORDER BY id LIMIT 1', 1);
  Chk('COUNT gecmis kumezer (1 satir)',
    'SELECT COUNT(*) FROM k AS OF SEQUENCE ' + IntToStr(a2), 1);
  ChkVal('COUNT degeri 2',
    'SELECT COUNT(*) FROM k AS OF SEQUENCE ' + IntToStr(a2), 0, 0, '2');
  Chk('sinir tasan seq guncel kumeyle ayni (2 satir)',
    'SELECT ad FROM k AS OF SEQUENCE 999999 ORDER BY id', 2);
  Chk('guncel sorgu da 2 satir (kirpma dogru karsilastirilir)',
    'SELECT ad FROM k ORDER BY id', 2);

  // ---- i) alias varyantlari ----
  Chk('alias (FROM k x AS OF ...)',
    'SELECT ad FROM k x AS OF SEQUENCE ' + IntToStr(a1) + ' ORDER BY id', 1);
  Chk('alias (FROM k AS x AS OF ...)',
    'SELECT ad FROM k AS x AS OF SEQUENCE ' + IntToStr(a1) + ' ORDER BY id', 1);

  // ---- f) TIMESTAMP / VERSION acikca reddedilir ----
  ChkErr('AS OF TIMESTAMP reddedilir',
    'SELECT id FROM k AS OF TIMESTAMP ' + Q + '2026-10-05 12:00:00' + Q);
  ChkErr('AS OF VERSION reddedilir',
    'SELECT id FROM k AS OF VERSION 3');

  // ---- g) JOIN reddedilir ----
  ChkErr('JOIN + AS OF reddedilir',
    'SELECT k.ad FROM k AS OF SEQUENCE ' + IntToStr(a1) +
    ' JOIN diger ON diger.id = k.id');

  // ---- i) bozuk girisler syntax hatasi ----
  ChkErr('AS OF SEQUENCE sayi degil (syntax)',
    'SELECT id FROM k AS OF SEQUENCE abc');
  ChkErr('AS OF tanisiz tur (syntax)',
    'SELECT id FROM k AS OF FOO 1');

  // ---- h) gecmisi olmayan 1: WAL kapali ----
  UseDir('asof2');   // varsayilan: WAL kapali
  sq.Exec('CREATE TABLE k(id INTEGER PRIMARY KEY, ad TEXT)');
  sq.Exec('INSERT INTO k(id,ad) VALUES(1,''bir'')');
  Dogrula('WAL kapali iken gecmis yok', kv.WalRecordCount = 0,
    IntToStr(kv.WalRecordCount));
  ChkErr('WAL kapaliyken AS OF reddedilir',
    'SELECT ad FROM k AS OF SEQUENCE 0');

  // ---- h) gecmisi olmayan 2: checkpoint gecmisi siler ----
  UseDir('asof3');
  kv.WALEnabled := True;
  sq.Exec('CREATE TABLE k(id INTEGER PRIMARY KEY, ad TEXT)');
  sq.Exec('INSERT INTO k(id,ad) VALUES(1,''bir'')');
  Dogrula('checkpoint oncesi gecmis var', kv.HasWAL);
  Dogrula('CheckpointWAL basarili', kv.CheckpointWAL);
  Dogrula('checkpoint sonrasi gecmis silindi', kv.WalRecordCount = 0,
    IntToStr(kv.WalRecordCount));
  ChkErr('checkpoint sonrasi AS OF reddedilir',
    'SELECT ad FROM k AS OF SEQUENCE 0');
end;

procedure T01_Veritabani;
begin
  Grp('Veritabani komutlari (CREATE/DROP/LIST DATABASE)');
  UseDir('ana');
  Chk('CREATE DATABASE satis', 'CREATE DATABASE satis', -1);
  ChkErr('CREATE DATABASE var olan (hata)',
      'CREATE DATABASE satis');
  Chk('CREATE DATABASE IF NOT EXISTS (sessiz)',
      'CREATE DATABASE IF NOT EXISTS satis', -1);
  R := sq.Exec('LIST DATABASES');
  Ok('LIST DATABASES calisti', IntToStr(R.Affected) + ' veritabani');
  R := sq.Exec('SHOW DATABASES');
  Ok('SHOW DATABASES = LIST', IntToStr(R.Affected));
  ChkErr('DROP DATABASE etkini silemez', 'DROP DATABASE ana');
  Chk('DROP DATABASE satis', 'DROP DATABASE satis', -1);
  Chk('DROP DATABASE IF EXISTS (yok)', 'DROP DATABASE IF EXISTS satis', -1);
  ChkErr('DROP DATABASE olmayan (hata)', 'DROP DATABASE satis');
  ChkErr('veritabani adi yol ayirici (hata)',
      'CREATE DATABASE ' + Q + 'a\b' + Q);
  ChkErr('veritabani adi .. (hata)', 'CREATE DATABASE ' + Q + '..' + Q);
end;

procedure T02_Tipler;
begin
  Grp('Veri tipleri (INTEGER/FLOAT/TEXT/BOOL/DATE/DATETIME/TIME/BLOB)');
  UseDir('tip');
  sq.Exec('CREATE TABLE tip(id INTEGER PRIMARY KEY, i INTEGER, f FLOAT, ' +
          's TEXT, b BOOLEAN, d DATE, dt DATETIME, tm TIME, bl BLOB)');
  Chk('hepsine bir satir', 'INSERT INTO tip(i,f,s,b,d,dt,tm,bl) VALUES(' +
      '42, 3.5, ' + Q + 'merhaba' + Q + ', 1, ' + Q + '2024-01-15' + Q + ', ' +
      Q + '2024-01-15 10:30:00' + Q + ', ' + Q + '10:30:00' + Q + ', ' +
      Q + 'binary' + Q + ')', -1);
  ChkVal('INTEGER saklanir', 'SELECT i FROM tip', 0, 0, '42');
  ChkVal('FLOAT saklanir', 'SELECT f FROM tip', 0, 0, '3.5');
  ChkVal('TEXT saklanir', 'SELECT s FROM tip', 0, 0, 'merhaba');
  ChkVal('BOOLEAN saklanir', 'SELECT b FROM tip', 0, 0, 'True');
  ChkVal('DATE saklanir', 'SELECT d FROM tip', 0, 0, '2024-01-15');
  ChkVal('DATETIME saklanir', 'SELECT dt FROM tip', 0, 0, '2024-01-15 10:30:00');
  ChkVal('TIME saklanir', 'SELECT tm FROM tip', 0, 0, '10:30:00');
  ChkVal('BLOB saklanir', 'SELECT bl FROM tip', 0, 0, 'binary');
  ChkErr('INTEGER kolona metin (hata)',
      'INSERT INTO tip(i) VALUES(' + Q + 'abc' + Q + ')');
  ChkErr('DATE kolona bozuk tarih (hata)',
      'INSERT INTO tip(d) VALUES(' + Q + 'abc' + Q + ')');
  // Locale bagimsizlik: sistem tr-TR (ondalik ayirici = virgul) ama motor
  // daima NOKTA kullanir. Aksi halde "VALUES(0,5)" 4 deger sanilir ve
  // sessizce yanlis satir yazilir.
  sq.Exec('CREATE TABLE fl(id INTEGER PRIMARY KEY, f FLOAT)');
  sq.Exec('INSERT INTO fl(f) VALUES(2.25)');
  ChkVal('FLOAT nokta ile okunur (locale bagimsiz)', 'SELECT f FROM fl', 0, 0, '2.25');
  sq.Exec('INSERT INTO fl(f) VALUES(10)');
  ChkVal('FLOAT tam sayi', 'SELECT f FROM fl WHERE id=2', 0, 0, '10');
  ChkVal('FLOAT karsilastirma', 'SELECT COUNT(*) FROM fl WHERE f > 2', 0, 0, '2');
  ChkErr('ondalik VIRGUL deger ayirici sayilmaz (hata)',
      'INSERT INTO fl(id,f) VALUES(9,0,5)');
end;

procedure T03_CreateKisit;
begin
  Grp('CREATE TABLE kisitlari (PK/NOT NULL/UNIQUE/DEFAULT/CHECK/FK)');
  UseDir('kis');
  sq.Exec('CREATE TABLE ebeveyn(id INTEGER PRIMARY KEY, ad TEXT NOT NULL)');
  ChkErr('NOT NULL ihlali (hata)',
      'INSERT INTO ebeveyn(id,ad) VALUES(1,' + Q + Q + ')');
  Chk('gecerli satir', 'INSERT INTO ebeveyn(id,ad) VALUES(1,' + Q + 'Ali' + Q + ')', -1);
  ChkErr('PK tekrari (hata)',
      'INSERT INTO ebeveyn(id,ad) VALUES(1,' + Q + 'Veli' + Q + ')');
  sq.Exec('CREATE TABLE cocuk(id INTEGER PRIMARY KEY, pid INTEGER ' +
          'REFERENCES ebeveyn(id), yas INTEGER DEFAULT 0, ' +
          'puan FLOAT, etiket TEXT UNIQUE)');
  Chk('FK dogru deger', 'INSERT INTO cocuk(id,pid) VALUES(1,1)', -1);
  ChkErr('FK yanlis deger (hata)', 'INSERT INTO cocuk(id,pid) VALUES(2,99)');
  Chk('DEFAULT uygulandi', 'INSERT INTO cocuk(id) VALUES(2)', -1);
  ChkVal('DEFAULT degeri yazildi', 'SELECT yas FROM cocuk WHERE id=2', 0, 0, '0');
  Chk('UNIQUE ilk kullanim',
      'INSERT INTO cocuk(id,etiket) VALUES(3,' + Q + 'x' + Q + ')', -1);
  ChkErr('UNIQUE tekrari 2 (hata)',
      'INSERT INTO cocuk(id,etiket) VALUES(4,' + Q + 'x' + Q + ')');
  sq.Exec('CREATE TABLE yasli(id INTEGER PRIMARY KEY, y INTEGER, ' +
          'CHECK (y >= 0))');
  Chk('CHECK gecer', 'INSERT INTO yasli(id,y) VALUES(1,10)', -1);
  ChkErr('CHECK ihlali (hata)', 'INSERT INTO yasli(id,y) VALUES(2,-1)');
  sq.Exec('CREATE TABLE tek(id INTEGER PRIMARY KEY, v INTEGER CHECK (v > 0))');
  ChkErr('kolon ici CHECK (hata)', 'INSERT INTO tek(id,v) VALUES(1,0)');
end;

procedure T04_Insert;
begin
  Grp('INSERT bicimleri');
  UseDir('ins');
  sq.Exec('CREATE TABLE t(id INTEGER PRIMARY KEY, a TEXT, b INTEGER, ' +
          'c TEXT DEFAULT ' + Q + 'varsayilan' + Q + ')');
  Chk('sutun listeli', 'INSERT INTO t(a,b) VALUES(' + Q + 'x' + Q + ',1)', -1);
  Chk('sutun listesiz (sirayla)', 'INSERT INTO t VALUES(2,' + Q + 'y' + Q +
      ',2,' + Q + 'z' + Q + ')', -1);
  Chk('bos liste + bos VALUES (DEFAULT)',
      'INSERT INTO t() VALUES()', -1);
  Chk('DEFAULT VALUES kisayol', 'INSERT INTO t DEFAULT VALUES', -1);
  Chk('NULL deger', 'INSERT INTO t(a,b) VALUES(NULL,NULL)', -1);
  ChkErr('olmayan sutun (hata)',
      'INSERT INTO t(olmayan) VALUES(1)');
  ChkErr('deger sayisi uymaz (hata)',
      'INSERT INTO t(a,b) VALUES(' + Q + 'q' + Q + ')');
  Chk('5 satir yazildi', 'SELECT COUNT(*) FROM t', 1);
  R := sq.Exec('SELECT COUNT(*) FROM t');
  ChkVal('sayim dogru', 'SELECT COUNT(*) FROM t', 0, 0, '5');
  ChkVal('NULL okundu', 'SELECT a FROM t WHERE id=5', 0, 0, '');
end;

procedure T05_SelectTemel;
begin
  Grp('SELECT: yildiz, kolon listesi, alias, ORDER BY, LIMIT/OFFSET');
  UseDir('sel');
  sq.Exec('CREATE TABLE t(id INTEGER PRIMARY KEY, ad TEXT, yas INTEGER)');
  sq.Exec('INSERT INTO t(ad,yas) VALUES(' + Q + 'Ali' + Q + ',30)');
  sq.Exec('INSERT INTO t(ad,yas) VALUES(' + Q + 'Veli' + Q + ',20)');
  sq.Exec('INSERT INTO t(ad,yas) VALUES(' + Q + 'Zeynep' + Q + ',40)');
  sq.Exec('INSERT INTO t(ad,yas) VALUES(' + Q + 'Ayse' + Q + ',25)');
  Chk('SELECT *', 'SELECT * FROM t', 4);
  Chk('kolon listesi', 'SELECT ad,yas FROM t', 4);
  Chk('ORDER BY ASC', 'SELECT ad FROM t ORDER BY yas', 4);
  ChkVal('ORDER BY ASC ilk', 'SELECT ad FROM t ORDER BY yas', 0, 0, 'Veli');
  ChkVal('ORDER BY DESC ilk', 'SELECT ad FROM t ORDER BY yas DESC', 0, 0, 'Zeynep');
  Chk('coklu ORDER BY', 'SELECT ad FROM t ORDER BY yas ASC, ad DESC', 4);
  Chk('LIMIT 2', 'SELECT ad FROM t ORDER BY yas LIMIT 2', 2);
  ChkVal('LIMIT ilk kayit', 'SELECT ad FROM t ORDER BY yas LIMIT 2', 0, 0, 'Veli');
  Chk('LIMIT + OFFSET', 'SELECT ad FROM t ORDER BY yas LIMIT 2 OFFSET 1', 2);
  ChkVal('OFFSET kaydi', 'SELECT ad FROM t ORDER BY yas LIMIT 2 OFFSET 1', 0, 0, 'Ayse');
  Chk('OFFSET tek basina', 'SELECT ad FROM t ORDER BY yas OFFSET 3', 1);
  R := sq.Exec('SELECT ad AS isim FROM t ORDER BY id');
  Ok('AS alias', R.Fields[0] + ' = ' + R.Rows[0][0]);
  R := sq.Exec('SELECT ad isim2 FROM t ORDER BY id');
  Ok('AS`siz alias', R.Fields[0] + ' = ' + R.Rows[0][0]);
  Chk('tablo alias', 'SELECT x.ad FROM t x ORDER BY x.id', 4);
  ChkErr('olmayan tablo (hata)', 'SELECT * FROM yok');
  ChkErr('olmayan kolon (hata)', 'SELECT yok FROM t');
end;

procedure T06_Where;
begin
  Grp('WHERE operatorleri, AND/OR/parantez, LIKE, IS NULL');
  UseDir('whr');
  sq.Exec('CREATE TABLE t(id INTEGER PRIMARY KEY, ad TEXT, yas INTEGER, ' +
          'email TEXT)');
  sq.Exec('INSERT INTO t(ad,yas,email) VALUES(' + Q + 'Ali' + Q + ',30,' + Q + 'ali@x.com' + Q + ')');
  sq.Exec('INSERT INTO t(ad,yas,email) VALUES(' + Q + 'Veli' + Q + ',20,' + Q + 'veli@y.com' + Q + ')');
  sq.Exec('INSERT INTO t(ad,yas,email) VALUES(' + Q + 'Zeynep' + Q + ',40,NULL)');
  Chk('=', 'SELECT ad FROM t WHERE yas = 30', 1);
  Chk('<>', 'SELECT ad FROM t WHERE yas <> 30', 2);
  Chk('!=', 'SELECT ad FROM t WHERE yas != 30', 2);
  Chk('<', 'SELECT ad FROM t WHERE yas < 30', 1);
  Chk('>', 'SELECT ad FROM t WHERE yas > 30', 1);
  Chk('<=', 'SELECT ad FROM t WHERE yas <= 30', 2);
  Chk('>=', 'SELECT ad FROM t WHERE yas >= 30', 2);
  Chk('AND', 'SELECT ad FROM t WHERE yas > 20 AND yas < 35', 1);
  Chk('OR', 'SELECT ad FROM t WHERE yas = 20 OR yas = 40', 2);
  Chk('parentez', 'SELECT ad FROM t WHERE yas = 20 OR (yas > 30 AND yas < 35)', 1);
  Chk('LIKE %', 'SELECT ad FROM t WHERE ad LIKE ' + Q + 'A%' + Q, 1);
  Chk('LIKE % orta', 'SELECT ad FROM t WHERE email LIKE ' + Q + '%@y.com' + Q, 1);
  Chk('LIKE tam', 'SELECT ad FROM t WHERE ad LIKE ' + Q + 'Ali' + Q, 1);
  Chk('IS NULL', 'SELECT ad FROM t WHERE email IS NULL', 1);
  Chk('IS NOT NULL', 'SELECT ad FROM t WHERE email IS NOT NULL', 2);
  Chk('NULL = ile eslesmez', 'SELECT ad FROM t WHERE email = NULL', 0);
  Chk('NULL <> ile eslesmez', 'SELECT ad FROM t WHERE email <> NULL', 0);
  Chk('NULL LIKE ile eslesmez', 'SELECT ad FROM t WHERE email LIKE ' + Q + '%' + Q, 2);
  Chk('metin karsilastirma', 'SELECT ad FROM t WHERE ad = ' + Q + 'Ali' + Q, 1);
  ChkErr('olmayan operator (hata)', 'SELECT ad FROM t WHERE yas =~~ 3');
end;

procedure T07_TipKarsilastirma;
begin
  Grp('Tip-bilgili karsilastirma (TEXT 007 != 7)');
  UseDir('tipk');
  sq.Exec('CREATE TABLE t(id INTEGER PRIMARY KEY, s TEXT, n INTEGER)');
  sq.Exec('INSERT INTO t(s,n) VALUES(' + Q + '007' + Q + ',7)');
  sq.Exec('INSERT INTO t(s,n) VALUES(' + Q + '7' + Q + ',007)');
  Chk('TEXT: s = 7 (tirnaksiz literal = metin ' + Q + '7' + Q + ')',
      'SELECT s FROM t WHERE s = 7', 1);
  Chk('TEXT: ' + Q + '007' + Q + ' = ' + Q + '007' + Q,
      'SELECT s FROM t WHERE s = ' + Q + '007' + Q, 1);
  Chk('INTEGER: n = ' + Q + '007' + Q + ' (iki satirda da 7)',
      'SELECT n FROM t WHERE n = ' + Q + '007' + Q, 2);
  Chk('INTEGER: n = 7 (iki satir)', 'SELECT n FROM t WHERE n = 7', 2);
  Chk('BETWEEN (n=7 -> aralik disi)', 'SELECT s FROM t WHERE n BETWEEN 1 AND 5', 0);
  Chk('BETWEEN (n=7 -> aralik ici)', 'SELECT s FROM t WHERE n BETWEEN 5 AND 9', 2);
  Chk('IN (...) (n=7 -> eslesmez)',
      'SELECT s FROM t WHERE n IN (1,2,3)', 0);
  Chk('IN (...) (n=7 -> eslesir)',
      'SELECT s FROM t WHERE n IN (6,7,8)', 2);
  Chk('NOT IN (...)', 'SELECT s FROM t WHERE n NOT IN (1,2,3)', 2);
  Chk('TEXT BETWEEN (byte sirasi: ''007'' < ''7'')',
      'SELECT s FROM t WHERE s BETWEEN ' + Q + '7' + Q + ' AND ' + Q + '8' + Q, 1);
  Chk('TEXT BETWEEN (''007''..''9'' -> ikisi de)',
      'SELECT s FROM t WHERE s BETWEEN ' + Q + '007' + Q + ' AND ' + Q + '9' + Q, 2);
  Chk('DISTINCT (007 ve 7 farkli)', 'SELECT DISTINCT s FROM t', 2);
  Chk('DISTINCT n (7 iki kez)', 'SELECT DISTINCT n FROM t', 1);
end;

procedure T08_Join;
begin
  Grp('JOIN: INNER, LEFT, alias, nitelemeli kolon');
  UseDir('jnn');
  sq.Exec('CREATE TABLE eb(id INTEGER PRIMARY KEY, ad TEXT)');
  sq.Exec('CREATE TABLE coc(id INTEGER PRIMARY KEY, ad TEXT, pid INTEGER)');
  sq.Exec('INSERT INTO eb(id,ad) VALUES(1,' + Q + 'Ali' + Q + ')');
  sq.Exec('INSERT INTO eb(id,ad) VALUES(2,' + Q + 'Veli' + Q + ')');
  sq.Exec('INSERT INTO coc(id,ad,pid) VALUES(1,' + Q + 'c1' + Q + ',1)');
  sq.Exec('INSERT INTO coc(id,ad,pid) VALUES(2,' + Q + 'c2' + Q + ',1)');
  sq.Exec('INSERT INTO coc(id,ad,pid) VALUES(3,' + Q + 'c3' + Q + ',2)');
  sq.Exec('INSERT INTO coc(id,ad,pid) VALUES(4,' + Q + 'c4' + Q + ',NULL)');
  Chk('INNER JOIN (3 eslesme)', 'SELECT c.ad FROM coc c INNER JOIN eb ON c.pid = eb.id', 3);
  Chk('JOIN = INNER JOIN', 'SELECT c.ad FROM coc c JOIN eb ON c.pid = eb.id', 3);
  Chk('LEFT JOIN (4 satir)', 'SELECT c.ad FROM coc c LEFT JOIN eb ON c.pid = eb.id', 4);
  ChkVal('LEFT JOIN eslesmeyen NULL',
      'SELECT c.ad, eb.ad FROM coc c LEFT JOIN eb ON c.pid = eb.id ORDER BY c.id', 3, 1, '');
  Chk('aliasli JOIN + WHERE', 'SELECT c.ad FROM coc c JOIN eb e ON c.pid = e.id ' +
      'WHERE e.ad = ' + Q + 'Ali' + Q, 2);
  Chk('nitelemeli kolon', 'SELECT coc.ad FROM coc JOIN eb ON coc.pid = eb.id', 3);
  Chk('coklu JOIN kosulu yerine ON+WHERE',
      'SELECT c.ad FROM coc c JOIN eb ON c.pid = eb.id WHERE c.id > 1', 2);
  // 4.2 (06.10.2026): JOIN ile GROUP BY ARTIK calisir - eski "hata"
  // iddiasi cevrildi; ayrinti T08i_JoinAggregate grubunda.
  Chk('JOIN + GROUP BY 3 grup (4.2)',
      'SELECT c.ad, COUNT(*) AS n FROM coc c JOIN eb ON c.pid = eb.id GROUP BY ad', 3);
  Chk('ORDER BY + LIMIT JOIN',
      'SELECT c.ad FROM coc c JOIN eb ON c.pid = eb.id ORDER BY c.id LIMIT 1', 1);
end;

procedure T08b_JoinZincir;
begin
  Grp('JOIN zinciri: 3+ tablo (P5-1)');
  UseDir('jnn3');
  sq.Exec('CREATE TABLE ulke(id INTEGER PRIMARY KEY, ad TEXT)');
  sq.Exec('CREATE TABLE sehir(id INTEGER PRIMARY KEY, ad TEXT, uid INTEGER)');
  sq.Exec('CREATE TABLE kisi3(id INTEGER PRIMARY KEY, ad TEXT, sid INTEGER)');
  sq.Exec('INSERT INTO ulke(id,ad) VALUES(1,' + Q + 'TR' + Q + ')');
  sq.Exec('INSERT INTO ulke(id,ad) VALUES(2,' + Q + 'DE' + Q + ')');
  sq.Exec('INSERT INTO sehir(id,ad,uid) VALUES(1,' + Q + 'Ankara' + Q + ',1)');
  sq.Exec('INSERT INTO sehir(id,ad,uid) VALUES(2,' + Q + 'Istanbul' + Q + ',1)');
  sq.Exec('INSERT INTO sehir(id,ad,uid) VALUES(3,' + Q + 'Berlin' + Q + ',2)');
  sq.Exec('INSERT INTO sehir(id,ad,uid) VALUES(4,' + Q + 'Sahipsiz' + Q + ',NULL)');
  sq.Exec('INSERT INTO kisi3(id,ad,sid) VALUES(1,' + Q + 'Ali' + Q + ',1)');
  sq.Exec('INSERT INTO kisi3(id,ad,sid) VALUES(2,' + Q + 'Veli' + Q + ',2)');
  sq.Exec('INSERT INTO kisi3(id,ad,sid) VALUES(3,' + Q + 'Zoe' + Q + ',3)');
  sq.Exec('INSERT INTO kisi3(id,ad,sid) VALUES(4,' + Q + 'Kim' + Q + ',NULL)');
  sq.Exec('INSERT INTO kisi3(id,ad,sid) VALUES(5,' + Q + 'Can' + Q + ',1)');
  Chk('3 tablo INNER (4 eslesme)',
      'SELECT k.ad FROM kisi3 k JOIN sehir s ON k.sid = s.id ' +
      'JOIN ulke u ON s.uid = u.id', 4);
  ChkVal('3 tablo deger',
      'SELECT k.ad, s.ad, u.ad FROM kisi3 k JOIN sehir s ON k.sid = s.id ' +
      'JOIN ulke u ON s.uid = u.id ORDER BY k.id', 0, 2, 'TR');
  ChkVal('3 tablo 3. satir',
      'SELECT k.ad, s.ad, u.ad FROM kisi3 k JOIN sehir s ON k.sid = s.id ' +
      'JOIN ulke u ON s.uid = u.id ORDER BY k.id', 2, 2, 'DE');
  Chk('LEFT + INNER zincir (Kim duser, 4 satir)',
      'SELECT k.ad FROM kisi3 k LEFT JOIN sehir s ON k.sid = s.id ' +
      'JOIN ulke u ON s.uid = u.id', 4);
  Chk('INNER + LEFT zincir (4 satir)',
      'SELECT k.ad FROM kisi3 k JOIN sehir s ON k.sid = s.id ' +
      'LEFT JOIN ulke u ON s.uid = u.id', 4);
  Chk('ters ON sirasi (sag=sol)',
      'SELECT k.ad FROM kisi3 k JOIN sehir s ON s.id = k.sid ' +
      'JOIN ulke u ON u.id = s.uid', 4);
  Chk('4. tablo oz-birlestirme (Ankara paylasimi, 6 satir)',
      'SELECT a.ad FROM kisi3 a JOIN sehir s ON a.sid = s.id ' +
      'JOIN ulke u ON s.uid = u.id JOIN kisi3 b ON b.sid = s.id', 6);
  Chk('WHERE zincir sonrasi (TR: Ali, Veli, Can)',
      'SELECT k.ad FROM kisi3 k JOIN sehir s ON k.sid = s.id ' +
      'JOIN ulke u ON s.uid = u.id WHERE u.ad = ' + Q + 'TR' + Q, 3);
  // 4.2 (06.10.2026): JOIN ile aggregate ARTIK calisir (eski "hata"
  // iddiasi cevrildi): 4 satir eslesir, sonuc TEK satirdir.
  ChkVal('JOIN aggregate tek satir COUNT=4 (4.2)',
      'SELECT COUNT(*) FROM kisi3 k JOIN sehir s ON k.sid = s.id', 0, 0, '4');
  Chk('zincirde RIGHT (Kim duser, 4)',
      'SELECT k.ad FROM kisi3 k LEFT JOIN sehir s ON k.sid = s.id ' +
      'RIGHT JOIN ulke u ON s.uid = u.id', 4);
end;

procedure T08c_RightFullJoin;
begin
  Grp('RIGHT/FULL JOIN (P5-RF)');
  UseDir('jnrf');
  sq.Exec('CREATE TABLE eb2(id INTEGER PRIMARY KEY, ad TEXT)');
  sq.Exec('CREATE TABLE per2(id INTEGER PRIMARY KEY, ad TEXT, eid INTEGER)');
  sq.Exec('INSERT INTO eb2(id,ad) VALUES(1,' + Q + 'Ali' + Q + '),(2,' + Q + 'Veli' + Q + ')');
  sq.Exec('INSERT INTO eb2(id,ad) VALUES(3,' + Q + 'Zoe' + Q + ')');
  sq.Exec('INSERT INTO per2(id,ad,eid) VALUES(1,' + Q + 'p1' + Q + ',1)');
  sq.Exec('INSERT INTO per2(id,ad,eid) VALUES(2,' + Q + 'p2' + Q + ',1)');
  sq.Exec('INSERT INTO per2(id,ad,eid) VALUES(3,' + Q + 'p3' + Q + ',NULL)');
  // sagda eslesmeyen Zoe korunur (NULL-solla)
  Chk('RIGHT JOIN (4: Zoe NULL-solla)',
      'SELECT p.ad, e.ad FROM per2 p RIGHT JOIN eb2 e ON p.eid = e.id ORDER BY e.id, p.id', 4);
  ChkVal('RIGHT eslesmeyen sag',
      'SELECT p.ad, e.ad FROM per2 p RIGHT JOIN eb2 e ON p.eid = e.id ORDER BY e.id, p.id', 3, 0, '');
  ChkVal('RIGHT eslesmeyen sag adi',
      'SELECT p.ad, e.ad FROM per2 p RIGHT JOIN eb2 e ON p.eid = e.id ORDER BY e.id, p.id', 3, 1, 'Zoe');
  Chk('RIGHT OUTER ayni (4)',
      'SELECT p.ad FROM per2 p RIGHT OUTER JOIN eb2 e ON p.eid = e.id', 4);
  Chk('LEFT OUTER ayni (3)',
      'SELECT p.ad FROM per2 p LEFT OUTER JOIN eb2 e ON p.eid = e.id', 3);
  // FULL: iki taraf da korunur (p3 + Zoe = 5).
  // (NULL satirlarin siralama konumu tanimsizdir; kosulla dogrulanir.)
  Chk('FULL JOIN (5)',
      'SELECT p.ad, e.ad FROM per2 p FULL JOIN eb2 e ON p.eid = e.id', 5);
  Chk('FULL sag-korumali (Veli+Zoe)',
      'SELECT p.ad, e.ad FROM per2 p FULL JOIN eb2 e ON p.eid = e.id WHERE p.ad IS NULL', 2);
  ChkVal('FULL sol-korumali (p3)',
      'SELECT p.ad, e.ad FROM per2 p FULL JOIN eb2 e ON p.eid = e.id WHERE e.ad IS NULL', 0, 0, 'p3');
  Chk('FULL OUTER ayni (5)',
      'SELECT p.ad FROM per2 p FULL OUTER JOIN eb2 e ON p.eid = e.id', 5);
  // ters ON + zincirde RIGHT
  Chk('ters ON RIGHT (4)',
      'SELECT p.ad FROM per2 p RIGHT JOIN eb2 e ON e.id = p.eid', 4);
  // 4.1 (06.10.2026): CROSS JOIN artik desteklenir - buradaki eski
  // "CROSS JOIN yok (hata)" iddiasi asagida T08h grubunca cevrildi.
  Chk('CROSS JOIN 3x3=9 (4.1)',
      'SELECT per2.ad, eb2.ad FROM per2 CROSS JOIN eb2', 9);

  // ---- F-26: zincirde ve karmada FULL JOIN ----
  // Sol: per2 LEFT JOIN eb2 ON p.eid=e.id -> p1, p2, p3(NULL) = 3 satir.
  // Sonra FULL JOIN eb2 c ON c.id=99 -> hicbir eslesme yok:
  //   solun 3 satiri korunur + c'nin 3 satiri NULL'lu eklenir = 6.
  Chk('FULL zincir LEFT JOIN ile (6)',
      'SELECT p.ad FROM per2 p LEFT JOIN eb2 e ON p.eid = e.id' +
      ' FULL JOIN eb2 c ON c.id = 99', 6);
  // ON hep FALSE: solun 3 satiri NULL'lu c ile korunur (c-id NULL ama
  // p-ad DOLU). Ayni sekilde c'nin 3 satiri NULL'lu p ile eklenir
  // (p-ad NULL, c-ad DOLU). p.ad IS NULL sadece c-nullu satirlari
  // sayar -> 3
  Chk('FULL zincir sol NULL (c-nullu 3)',
      'SELECT p.ad FROM per2 p LEFT JOIN eb2 e ON p.eid = e.id' +
      ' FULL JOIN eb2 c ON c.id = 99 WHERE p.ad IS NULL', 3);
  // c.ad IS NOT NULL: c'nin korunan 3 satiri -> 3
  Chk('FULL zincir sag koruma (3)',
      'SELECT p.ad FROM per2 p LEFT JOIN eb2 e ON p.eid = e.id' +
      ' FULL JOIN eb2 c ON c.id = 99 WHERE c.ad IS NOT NULL', 3);
  // FULL FULL: once FULL -> 5 satir, sonra ON hep FALSE -> 5 + 3 = 8
  Chk('iki FULL arka arkaya (8)',
      'SELECT p.ad FROM per2 p FULL JOIN eb2 e ON p.eid = e.id' +
      ' FULL JOIN eb2 c ON c.id = 99', 8);
  // RIGHT FULL: once RIGHT -> 4 satir, sonra 4 + 3 = 7
  Chk('RIGHT FULL zincir (7)',
      'SELECT p.ad FROM per2 p RIGHT JOIN eb2 e ON p.eid = e.id' +
      ' FULL JOIN eb2 c ON c.id = 99', 7);
  // FULL JOIN'da eslesmeyen sol satir: p3 (eid NULL) -> 1
  Chk('FULL ON NULL kolonlu eslesmez (1)',
      'SELECT p.ad, c.ad FROM per2 p FULL JOIN eb2 c ON c.id = p.eid' +
      ' WHERE c.ad IS NULL', 1);
end;

procedure T08i_NaturalUsing;
// F-27: NATURAL JOIN  /  F-28: USING (kolon, ...)
var
  Q5: string;
begin
  Grp('NATURAL/USING (F-27/F-28)');
  UseDir('nat');
  Q5 := Q;
  // Ortak kolon: 'kid'. Sol: 3 satir, sag: 4 satir.
  sq.Exec('CREATE TABLE n_sol(kid INTEGER PRIMARY KEY, ad TEXT, sehir TEXT)');
  sq.Exec('CREATE TABLE n_sag(kid INTEGER PRIMARY KEY, sehir TEXT, nufus INTEGER)');
  sq.Exec('INSERT INTO n_sol VALUES(1,' + Q5 + 'Ali' + Q5 + ',' + Q5 + 'Izmir' + Q5 + '),' +
          '(2,' + Q5 + 'Veli' + Q5 + ',' + Q5 + 'Ankara' + Q5 + '),' +
          '(3,' + Q5 + 'Zoe' + Q5 + ',' + Q5 + 'Bursa' + Q5 + ')');
  sq.Exec('INSERT INTO n_sag VALUES(1,' + Q5 + 'Izmir' + Q5 + ',3),' +
          '(2,' + Q5 + 'Ankara' + Q5 + ',6),' +
          '(4,' + Q5 + 'Antalya' + Q5 + ',2),' +
          '(5,' + Q5 + 'Izmir' + Q5 + ',8)');
  // NATURAL: ortak kolonlar kid VE sehir -> iki kosul birlikte

  // ---- F-27: NATURAL JOIN ----
  Chk('NATURAL JOIN eslesen (2)',
      'SELECT kid FROM n_sol NATURAL JOIN n_sag', 2);
  // sehir de eslesmeli: kid=1 Izmir/Izmir ✓ ; kid=2 Ankara/Ankara ✓
  ChkVal('NATURAL JOIN degeri',
      'SELECT ad FROM n_sol NATURAL JOIN n_sag ORDER BY ad',
      0, 0, 'Ali');
  // Ayni sehirde iki n_sag satiri varsa kartesisik carpim olusur:
  // kid=1 Izmir 3 kişi, Izmir'de 2 n_sag satiri (kid=1 ve 5) -> 1x2 = 2
  // kid=2 Ankara -> 1x1 = 1  => toplam 3
  // NATURAL IKI kolonda birden esitlik ister: kid=5 satiri Izmir'de
  // olsa bile kid=1 ile esit degildir -> 2 satir.
  Chk('NATURAL JOIN iki kolon birlikte (2)',
      'SELECT kid FROM n_sol NATURAL JOIN n_sag', 2);
  // ON yerine tek kolon verilirse NATURAL iki ortak kolonu da kullanir
  // kid=3 (Zoe/Bursa) eslesmez ama sol-korunur -> 3 satir
  Chk('NATURAL LEFT JOIN korumali (3)',
      'SELECT kid FROM n_sol NATURAL LEFT JOIN n_sag', 3);
  ChkVal('NATURAL LEFT JOIN koruma (kid=3)',
      'SELECT kid FROM n_sol NATURAL LEFT JOIN n_sag WHERE n_sag.kid IS NULL',
      0, 0, '3');
  // sag 4 satir: 1,2 eslesir ; 4,5 korunur -> 4
  Chk('NATURAL RIGHT JOIN korumali (4)',
      'SELECT kid FROM n_sol NATURAL RIGHT JOIN n_sag', 4);
  // Ortak kolon olmayan iki tablo -> hata
  sq.Exec('CREATE TABLE n_y1(a INTEGER PRIMARY KEY)');
  sq.Exec('CREATE TABLE n_y2(b INTEGER PRIMARY KEY)');
  ChkErr('NATURAL ortak kolon yok -> hata',
      'SELECT * FROM n_y1 NATURAL JOIN n_y2');
  // ---- F-28: USING ----
  // USING (kid): sadece kid esitligi -> sehir engel degil
  // kid=1 (Izmir/3), kid=2 (Ankara/6), kid=3 eslesmez, kid=4-5 sol yok => 2
  Chk('USING (kid) eslesen (2)',
      'SELECT n_sol.kid FROM n_sol JOIN n_sag USING(kid)', 2);
  // USING ile eslesmeyen sol satir korunmaz (INNER)
  Chk('USING (kid) sadece ic join',
      'SELECT n_sol.kid FROM n_sol JOIN n_sag USING(kid)', 2);
  // Birden cok kolon
  Chk('USING (kid, sehir)',
      'SELECT n_sol.kid FROM n_sol JOIN n_sag USING(kid, sehir)', 2);
  // USING tek kolon: sehir esitligi tek basina yeter
  // sehir Izmir: sol kid=1, sag kid=1 ve 5 -> 2
  // sehir=Izmir: sol kid=1 ; sag kid=1 ve 5 -> 1x2 = 2 satır olmali,
// AMA NATURAL'dan farkli olarak sehir esitligi yeterli.
  // Izmir: kid=1 x sag(kid=1,5) -> 2 ; Ankara: 1x1 -> 1 ; toplam 3
  Chk('USING (sehir) Izmir+Ankara (3)',
      'SELECT n_sol.kid FROM n_sol JOIN n_sag USING(sehir)', 3);
  // Yok edilen kolon WHERE'de tek adla kullanilabilir
  ChkVal('USING kolonu tek adla WHERE',
      'SELECT COUNT(*) FROM n_sol JOIN n_sag USING(kid) WHERE kid = 1',
      0, 0, '1');
  // Eksik kolon -> hata
  ChkErr('USING kolonu sol tarafta yok',
      'SELECT * FROM n_sol JOIN n_sag USING(olmayan)');
  ChkErr('USING kolonu sag tarafta yok',
      'SELECT * FROM n_sol JOIN n_sag USING(sehir, nufus)');
  // NULL deger kesismez (uc-degerli)
  sq.Exec('CREATE TABLE n_n1(id INTEGER PRIMARY KEY, v INTEGER)');
  sq.Exec('CREATE TABLE n_n2(id INTEGER PRIMARY KEY, v INTEGER)');
  sq.Exec('INSERT INTO n_n1 VALUES(1,10),(2,NULL)');
  sq.Exec('INSERT INTO n_n2 VALUES(1,10),(2,20)');
  // id=1 eslesir ; id=2 sol NULL ama sag 20 -> NULL eslesmez
  Chk('USING NULL kesismez (1)',
      'SELECT id FROM n_n1 JOIN n_n2 USING(id)', 2);
  // id esitligi iki satiri da eslestirir (2=2); sol v degeri NULL olan
  // id=2 satiri sayilir -> 1
  // id esitligi iki satiri da eslestirir (2=2); sol v degeri NULL olan
  // id=2 satiri sayilir -> 1
  ChkVal('USING NULL degeri birakilmaz (1)',
      'SELECT COUNT(*) FROM n_n1 JOIN n_n2 USING(id) WHERE n_n1.v IS NULL',
      0, 0, '1');
  // MUTASYON YAKALAYICI: USING kolonunun KENDISI NULL ise satir ESLESMEZ.
  // Uc-degerli mantik: NULL = NULL bilinmezdir, eslesme sayilmaz.
  // (v kolonu eslesme kolonu DEGIL; id eslesme kolonudur ve id=1 NULL
  //  olsaydi bu satir eslesmezdi.)
  sq.Exec('CREATE TABLE n_u1(id INTEGER PRIMARY KEY, k INTEGER)');
  sq.Exec('CREATE TABLE n_u2(id INTEGER PRIMARY KEY, k INTEGER)');
  sq.Exec('INSERT INTO n_u1 VALUES(1,10),(2,NULL)');
  sq.Exec('INSERT INTO n_u2 VALUES(1,10),(2,NULL)');
  // k=10 eslesir ; k NULL iki tarafta da NULL ama uc-degerli mantikta
  // NULL = NULL BILINMEZDIR -> eslesmez. Yalnizca k=10 satiri gelir.
  Chk('USING kolonu NULL eslesmez (1)',
      'SELECT id FROM n_u1 JOIN n_u2 USING(k)', 1);
  // AYIRT EDICI: sol NULL, sag DOLU. "a='' OR b=''" -> elenir (dogru).
  // "a='' AND b=''" mutasyonu bu satiri SIRA VURMADI gecirir: iki
  // eslesen satir kalir ama burada zaten 1 bekleniyor; asil ayirt edici
  // olan asagidaki "sol NULL, sag NULL" ve "sol DOLU, sag NULL" adimlari.
  sq.Exec('CREATE TABLE n_z1(id INTEGER PRIMARY KEY, k INTEGER)');
  sq.Exec('CREATE TABLE n_z2(id INTEGER PRIMARY KEY, k INTEGER)');
  sq.Exec('INSERT INTO n_z1 VALUES(1,NULL),(2,10)');
  sq.Exec('INSERT INTO n_z2 VALUES(1,20),(2,NULL)');
  // Sol(1,NULL) x Sag(1,20): k NULL vs 20 -> elenir
  // Sol(2,10)  x Sag(2,NULL): 10 vs NULL -> elenir
  // Sol(2,10)  x Sag(1,20): 10 vs 20  -> elenir
  // Sol(1,NULL)x Sag(2,NULL): NULL vs NULL -> elenir
  Chk('USING tek taraf NULL elenir (0)',
      'SELECT id FROM n_z1 JOIN n_z2 USING(k)', 0);
  // Zincirde NATURAL + ON birlikteligi
  Chk('NATURAL sonra ON JOIN zinciri',
      'SELECT n_sol.kid FROM n_sol NATURAL JOIN n_sag' +
      ' JOIN n_n1 ON n_n1.id = n_sol.kid', 2);
end;

procedure T08j_Lateral;
// F-29: LATERAL JOIN — sag taraf alt sorgu/tabloda OLUR ve dis satirin
// kolonlarina referans verebilir.
var
  Q6: string;
begin
  Grp('LATERAL (F-29)');
  UseDir('lat');
  Q6 := Q;
  sq.Exec('CREATE TABLE l_emp(id INTEGER PRIMARY KEY, ad TEXT, sid INTEGER, maas INTEGER)');
  sq.Exec('CREATE TABLE l_dep(id INTEGER PRIMARY KEY, ad TEXT, butce INTEGER)');
  sq.Exec('INSERT INTO l_dep VALUES(10,' + Q6 + 'Satis' + Q6 + ',100),' +
          '(20,' + Q6 + 'IT' + Q6 + ',50)');
  sq.Exec('INSERT INTO l_emp VALUES(1,' + Q6 + 'Ali' + Q6 + ',10,120),' +
          '(2,' + Q6 + 'Veli' + Q6 + ',10,60),' +
          '(3,' + Q6 + 'Zoe' + Q6 + ',20,90),' +
          '(4,' + Q6 + 'Kim' + Q6 + ',99,10)');

  // ---- LATERAL alt sorgu: her calisan icin ucret + bütçe oranı ----
  Chk('LATERAL alt sorgu (3 satir: Kim sid=99 yok)',
      'SELECT e.id FROM l_emp e' +
      ' JOIN LATERAL (SELECT d.ad FROM l_dep d WHERE d.id = e.sid) x ON e.id = e.id', 3);
  ChkVal('LATERAL dis kolona erisim',
      'SELECT e.ad FROM l_emp e' +
      ' JOIN LATERAL (SELECT d.ad FROM l_dep d WHERE d.id = e.sid) x ON e.id = e.id' +
      ' ORDER BY e.id', 0, 0, 'Ali');
  // ON kosulu dis satira da referans verebilir
  Chk('LATERAL ON kosulu (filtre)',
      'SELECT e.id FROM l_emp e' +
      ' JOIN LATERAL (SELECT d.butce FROM l_dep d WHERE d.id = e.sid) x' +
      ' ON e.id = e.id', 3);
  ChkVal('LATERAL alt sorgu degeri',
      'SELECT x.butce FROM l_emp e' +
      ' JOIN LATERAL (SELECT d.butce FROM l_dep d WHERE d.id = e.sid) x' +
      ' ON e.id = e.id ORDER BY e.id', 0, 0, '100');
  // Alt sorgu satır döndürmezse LEFT LATERAL korur
  Chk('LATERAL LEFT koruma (Kim: sid=99 yok)',
      'SELECT e.id FROM l_emp e' +
      ' LEFT JOIN LATERAL (SELECT d.ad FROM l_dep d WHERE d.id = e.sid) x ON e.id = e.id', 4);
  ChkVal('LATERAL LEFT korunan deger NULL',
      'SELECT e.ad FROM l_emp e' +
      ' LEFT JOIN LATERAL (SELECT d.ad FROM l_dep d WHERE d.id = e.sid) x ON True' +
      ' WHERE e.id = 4', 0, 0, 'Kim');
  // Alt sorgu sıfır satır döndürürse INNER LATERAL eler
  Chk('LATERAL INNER bos sonuc eler (3)',
      'SELECT e.id FROM l_emp e' +
      ' JOIN LATERAL (SELECT d.ad FROM l_dep d WHERE d.id = e.sid) x ON e.id = e.id', 3);
  // Top-N deseni (gercek kullanim)
  // Ali(120) en yuksek maas -> ustunde kimse yok -> INNER LATERAL eler.
  // Veli(60) ustunde Ali var -> kalir. Ilk satir Veli olmali.
  ChkVal('LATERAL top-1 (ustunde baska calisan var)',
      'SELECT e.ad FROM l_emp e' +
      ' JOIN LATERAL (SELECT o.ad FROM l_emp o WHERE o.sid = e.sid' +
      '   AND o.maas > e.maas) x ON e.id = e.id ORDER BY e.id', 0, 0, 'Veli');
  // Zincir: LATERAL sonra normal JOIN
  // ON x.butce > 80: Ali(100) ve Veli(100) kalir; Zoe(50) elenir;
  // Kim (sid=99, LATERAL alt sorgusu bos) INNER LATERAL ile duser.
  // Sonraki JOIN l_dep ON d2.id = e.sid ikisini de korur -> 2 satir.
  Chk('LATERAL + normal JOIN zinciri',
      'SELECT e.id FROM l_emp e' +
      ' JOIN LATERAL (SELECT d.butce FROM l_dep d WHERE d.id = e.sid) x' +
      ' ON x.butce > 80 JOIN l_dep d2 ON d2.id = e.sid', 2);
  // LATERAL tablo
  Chk('LATERAL tablo ON ile',
      'SELECT e.id FROM l_emp e LEFT JOIN LATERAL l_dep d ON d.id = e.sid', 4);
  // ---- Hata durumları ----
  ChkErr('LATERAL + RIGHT reddedilir',
      'SELECT e.id FROM l_emp e' +
      ' RIGHT JOIN LATERAL (SELECT d.ad FROM l_dep d) x ON True');
  ChkErr('LATERAL + FULL reddedilir',
      'SELECT e.id FROM l_emp e' +
      ' FULL JOIN LATERAL (SELECT d.ad FROM l_dep d) x ON True');
  ChkErr('LATERAL + NATURAL reddedilir',
      'SELECT e.id FROM l_emp e NATURAL JOIN LATERAL (SELECT d.ad FROM l_dep d) x ON True');
  // Boş sol küme: LATERAL hiç çalıştırılmaz (AV olmamalı)
  sq.Exec('CREATE TABLE l_bos(id INTEGER PRIMARY KEY)');
  Chk('LATERAL bos sol kume (0 satir)',
      'SELECT b.id FROM l_bos b' +
      ' JOIN LATERAL (SELECT d.ad FROM l_dep d WHERE d.id = b.id) x ON True', 0);
end;

procedure T08k_MatView;
{ F-34: MATERIALIZED VIEW — SELECT'in sonucu fiziksel olarak saklanir.
  Normal tablo gibi okunur; REFRESH ile yeniden hesaplanir. }
var
  Q7: string;
begin
  Grp('MATERIALIZED VIEW (F-34)');
  UseDir('mview');
  Q7 := Q;
  sq.Exec('CREATE TABLE mv_t(id INTEGER PRIMARY KEY, ad TEXT, v INTEGER)');
  sq.Exec('INSERT INTO mv_t VALUES(1,' + Q7 + 'Ali' + Q7 + ',10)');
  sq.Exec('INSERT INTO mv_t VALUES(2,' + Q7 + 'Veli' + Q7 + ',20)');
  sq.Exec('INSERT INTO mv_t VALUES(3,' + Q7 + 'Zoe' + Q7 + ',30)');

  // ---- CREATE MATERIALIZED VIEW ----
  Chk('CREATE MATERIALIZED VIEW',
      'CREATE MATERIALIZED VIEW mv_p AS SELECT id, ad FROM mv_t WHERE v >= 20', -1);
  // Sonuc materyalize edildi mi? (WHERE filtreli: 2 satir)
  Chk('MV materyalize sonucu (2 satir)',
      'SELECT ad FROM mv_p ORDER BY id', 2);
  ChkVal('MV ilk satir degeri', 'SELECT ad FROM mv_p ORDER BY id', 0, 0, 'Veli');
  ChkVal('MV ikinci satir degeri', 'SELECT ad FROM mv_p ORDER BY id', 1, 0, 'Zoe');
  // WHERE uygulanabilir (indeks/sorgu yolu)
  Chk('MV uzerinde WHERE',
      'SELECT ad FROM mv_p WHERE id = 3', 1);
  // Kaynak tablo degisince MV ESKIDIR (materialize = anliklik yok)
  sq.Exec('INSERT INTO mv_t VALUES(4,' + Q7 + 'Can' + Q7 + ',40)');
  Chk('kaynak degisince MV degismez (hâlâ 2)',
      'SELECT ad FROM mv_p', 2);

  // ---- REFRESH ----
  Chk('REFRESH MATERIALIZED VIEW',
      'REFRESH MATERIALIZED VIEW mv_p', -1);
  Chk('REFRESH sonrasi 3 satir', 'SELECT ad FROM mv_p', 3);
  ChkVal('REFRESH sonrasi yeni satir gorunur',
      'SELECT ad FROM mv_p WHERE id = 4', 0, 0, 'Can');

  // ---- REFRESH sonrasi silinen kaynak satiri MV'den dusmeli ----
  sq.Exec('DELETE FROM mv_t WHERE id = 1');
  // Gercek sinir degeri: mv_p = "WHERE v >= 20", kaynakta id 2,3,4 kaldi.
  ChkVal('kaynakta v>=20 kalan (3)',
      'SELECT COUNT(*) FROM mv_t WHERE v >= 20', 0, 0, '3');
  sq.Exec('REFRESH MATERIALIZED VIEW mv_p');
  Chk('silinen satir MV den dusmeli', 'SELECT ad FROM mv_p WHERE id = 1', 0);
  // REFRESH'in GERCEKTEN sildigini kanitlayan ayirt edici senaryo:
  // Silme calismazsa eski satirlar kalir ve MV daha cok satir gosterir.
  // DIKKAT: COUNT(*) tek satir dondurur; sayiyi DEGER olarak okumaliyiz.
  ChkVal('REFRESH sonrasi satir sayisi kaynagi yansitir',
      'SELECT COUNT(*) FROM mv_p', 0, 0, '3');
  // AYIRT EDICI: MV'ye DAHIL olan bir kaynak satiri silinir. Artan
  // senaryoda yeni satirlar eski @mvN anahtarlarinin USTUNE yazildigi
  // icin fiziksel silme olmasa da sonuc dogru gorunur; AZALAN senaryo
  // silme mantigini zorunlu kilar.
  sq.Exec('DELETE FROM mv_t WHERE id = 3');   // v=30 -> MV'deydi
  sq.Exec('REFRESH MATERIALIZED VIEW mv_p');
  Chk('REFRESH azalan kaynakta eski satiri atar',
      'SELECT ad FROM mv_p WHERE id = 3', 0);
  ChkVal('REFRESH sonrasi satir sayisi 2',
      'SELECT COUNT(*) FROM mv_p', 0, 0, '2');

  // ---- farkli kolon semasi ----
  Chk('MV farkli kolon semasi (CREATE)',
      'CREATE MATERIALIZED VIEW mv_p2 AS SELECT ad, v FROM mv_t WHERE v >= 30', -1);
  Chk('MV farkli kolon semasi',
      'SELECT v FROM mv_p2 ORDER BY v', 1);

  // ---- DROP ----
  // REFRESH: ayni sema ile yeniden hesap (kaynak yeni satir eklendi)
  sq.Exec('INSERT INTO mv_t VALUES(5,' + Q7 + 'Deniz' + Q7 + ',50)');
  Chk('REFRESH yeni kaynagi gorur', 'REFRESH MATERIALIZED VIEW mv_p', -1);
  ChkVal('REFRESH sonrasi yeni satir (Deniz)',
      'SELECT ad FROM mv_p WHERE id = 5', 0, 0, 'Deniz');

  Chk('DROP MATERIALIZED VIEW',
      'DROP MATERIALIZED VIEW mv_p2', -1);
  ChkErr('drop sonrasi MV yok (hata)',
      'SELECT ad FROM mv_p2');
  Chk('IF EXISTS yoksa sessiz',
      'DROP MATERIALIZED VIEW IF EXISTS mv_p2', -1);
  ChkErr('IF EXISTS olmadan yoksa hata',
      'DROP MATERIALIZED VIEW mv_p2');

  // ---- tekillestirme ----
  ChkErr('ayni MV adı (hata)',
      'CREATE MATERIALIZED VIEW mv_p AS SELECT id FROM mv_t');
  Chk('IF NOT EXISTS ayni ad (sessiz)',
      'CREATE MATERIALIZED VIEW IF NOT EXISTS mv_p AS SELECT id FROM mv_t', -1);

  // ---- aggregate + JOIN desteklenmeli ----
  Chk('MV aggregate ile',
      'CREATE MATERIALIZED VIEW mv_grp AS SELECT COUNT(*) AS n FROM mv_t', -1);
  ChkVal('MV aggregate sonucu (3 satir)',
      'SELECT n FROM mv_grp', 0, 0, '3');
  Chk('MV JOIN ile',
      'CREATE MATERIALIZED VIEW mv_j AS ' +
      'SELECT a.ad AS k, b.v AS vv FROM mv_t a JOIN mv_t b ON a.id = b.id', -1);
  ChkVal('MV JOIN sonucu',
      'SELECT k FROM mv_j WHERE vv = 40', 0, 0, 'Can');
  Chk('DROP MATERIALIZED VIEW mv_grp', 'DROP MATERIALIZED VIEW mv_grp', -1);
  Chk('DROP MATERIALIZED VIEW mv_j', 'DROP MATERIALIZED VIEW mv_j', -1);
end;

procedure T08l_ViewDML;
{ F-33: VIEW üzerine INSERT/UPDATE/DELETE — guncellenebilir view testleri }
var
  Q7: string;
begin
  Grp('VIEW DML (F-33)');
  UseDir('viewdml');
  Q7 := Q;
  sq.Exec('CREATE TABLE vt_t(id INTEGER PRIMARY KEY, ad TEXT, v INTEGER)');
  sq.Exec('INSERT INTO vt_t VALUES(1,' + Q7 + 'Ali' + Q7 + ',10)');
  sq.Exec('INSERT INTO vt_t VALUES(2,' + Q7 + 'Veli' + Q7 + ',20)');
  sq.Exec('INSERT INTO vt_t VALUES(3,' + Q7 + 'Zoe' + Q7 + ',30)');

  // Basit guncellenebilir view: tek tablo, kolonlar birebir
  Chk('CREATE VIEW guncelleme',
      'CREATE VIEW v_v AS SELECT id, ad, v FROM vt_t WHERE v >= 20', -1);
  Chk('VIEW SELECT', 'SELECT ad FROM v_v ORDER BY id', 2);

  // INSERT INTO view -> base table'a yazar
  Chk('INSERT INTO view', 'INSERT INTO v_v VALUES(4,' + Q7 + 'Can' + Q7 + ',40)', -1);
  ChkVal('INSERT base tabloda gorunur', 'SELECT ad FROM vt_t WHERE id = 4', 0, 0, 'Can');
  ChkVal('VIEWden de gorunur', 'SELECT ad FROM v_v WHERE id = 4', 0, 0, 'Can');

  // UPDATE view -> base table guncellenir
  Chk('UPDATE view', 'UPDATE v_v SET ad = ' + Q7 + 'Veli2' + Q7 + ' WHERE id = 2', -1);
  ChkVal('UPDATE basede gorunur', 'SELECT ad FROM vt_t WHERE id = 2', 0, 0, 'Veli2');
  ChkVal('VIEWde de gorunur', 'SELECT ad FROM v_v WHERE id = 2', 0, 0, 'Veli2');

  // DELETE view -> base table'den silinir
  Chk('DELETE view', 'DELETE FROM v_v WHERE id = 3', -1);
  Chk('VIEWden silinmis', 'SELECT ad FROM v_v WHERE id = 3', 0);
  Chk('Baseden de silinmis', 'SELECT ad FROM vt_t WHERE id = 3', 0);

  // Aliasli kolon view -> alias ile INSERT/UPDATE
  sq.Exec('CREATE VIEW v_alias AS SELECT id, ad AS isim FROM vt_t WHERE v >= 40');
  Chk('VIEW alias SELECT', 'SELECT isim FROM v_alias', 1);
  Chk('VIEW alias INSERT', 'INSERT INTO v_alias VALUES(5,' + Q7 + 'Deniz' + Q7 + ')', -1);
  ChkVal('VIEW alias basede', 'SELECT ad FROM vt_t WHERE id = 5', 0, 0, 'Deniz');

  // Guncellenemez view: aggregate
  ChkErr('VIEW aggregate (hata)', 'CREATE VIEW v_agg AS SELECT COUNT(*) AS n FROM vt_t');
  ChkErr('VIEW aggregate INSERT (hata)', 'INSERT INTO v_agg VALUES(1)');

  // Guncellenemez view: JOIN
  sq.Exec('CREATE VIEW v_join AS SELECT a.ad AS a1, b.ad AS a2 FROM vt_t a JOIN vt_t b ON a.id = b.id');
  ChkErr('VIEW JOIN INSERT (hata)', 'INSERT INTO v_join VALUES(' + Q7 + 'x' + Q7 + ',' + Q7 + 'y' + Q7 + ')');

  // Guncellenemez view: DISTINCT
  sq.Exec('CREATE VIEW v_dist AS SELECT DISTINCT v FROM vt_t');
  ChkErr('VIEW DISTINCT INSERT (hata)', 'INSERT INTO v_dist VALUES(100)');

  // Guncellenemez view: ifade kolonu
  sq.Exec('CREATE VIEW v_expr AS SELECT id, v * 2 AS v2 FROM vt_t');
  ChkErr('VIEW ifade INSERT (hata)', 'INSERT INTO v_expr VALUES(6, 80)');

  // Temizleme
  sq.Exec('DROP VIEW v_v');
  sq.Exec('DROP VIEW v_alias');
  sq.Exec('DROP VIEW v_agg');
  sq.Exec('DROP VIEW v_join');
  sq.Exec('DROP VIEW v_dist');
  sq.Exec('DROP VIEW v_expr');
end;procedure T08h_CrossJoin;
begin
  Grp('CROSS JOIN (4.1)');
  UseDir('crs');
  sq.Exec('CREATE TABLE cr_a(id INTEGER PRIMARY KEY, ad TEXT)');
  sq.Exec('CREATE TABLE cr_b(id INTEGER PRIMARY KEY, ad TEXT)');
  sq.Exec('CREATE TABLE cr_k(id INTEGER PRIMARY KEY, ad TEXT)');
  sq.Exec('CREATE TABLE cr_z(id INTEGER PRIMARY KEY, ad TEXT)');
  sq.Exec('INSERT INTO cr_a(id,ad) VALUES(1,' + Q + 'a1' + Q + '),(2,' + Q +
      'a2' + Q + '),(3,' + Q + 'a3' + Q + ')');
  sq.Exec('INSERT INTO cr_b(id,ad) VALUES(10,' + Q + 'b1' + Q + '),(20,' + Q +
      'b2' + Q + ')');
  sq.Exec('INSERT INTO cr_k(id,ad) VALUES(1,' + Q + 'k1' + Q + '),(2,' + Q +
      'k2' + Q + '),(7,' + Q + 'k7' + Q + '),(8,' + Q + 'k8' + Q + ')');
  // ON'suz cartesius: 3 x 2 = 6
  Chk('CROSS ON''suz cartesius 3x2=6',
      'SELECT a.ad, b.ad FROM cr_a a CROSS JOIN cr_b b', 6);
  // ON yazildiysa INNER gibi filtreler (b.id=10 -> 3 satir)
  Chk('CROSS ON lu filtre (b.id=10)',
      'SELECT a.ad, b.ad FROM cr_a a CROSS JOIN cr_b b ON b.id = 10', 3);
  Chk('CROSS + WHERE (b.id=20)',
      'SELECT a.ad, b.ad FROM cr_a a CROSS JOIN cr_b b WHERE b.id = 20', 3);
  // CROSS, FROM alias'i olarak yutulmaz (nitelemeli kolon cozulur)
  Chk('CROSS nitelikli kolon (6)',
      'SELECT cr_a.ad, cr_b.ad FROM cr_a CROSS JOIN cr_b', 6);
  // ikili CROSS zinciri: 4 x 3 x 2 = 24
  Chk('ikili CROSS zincir 4x3x2=24',
      'SELECT k.ad, a.ad, b.ad FROM cr_k k CROSS JOIN cr_a a CROSS JOIN cr_b b', 24);
  // CROSS + INNER karisik zincir: (a1-k1, a2-k2) = 2 x 2 = 4
  Chk('INNER + CROSS zincir (4)',
      'SELECT a.ad, b.ad FROM cr_a a JOIN cr_k k ON a.id = k.id CROSS JOIN cr_b b', 4);
  ChkVal('CROSS sirali ilk deger',
      'SELECT a.ad, b.ad FROM cr_a a CROSS JOIN cr_b b ORDER BY a.id, b.id', 0, 1, 'b1');
  Chk('CROSS + DISTINCT (3)',
      'SELECT DISTINCT a.ad FROM cr_a a CROSS JOIN cr_b b', 3);
  Chk('CROSS + LIMIT (4)',
      'SELECT a.ad, b.ad FROM cr_a a CROSS JOIN cr_b b LIMIT 4', 4);
  Chk('bos sag tablo cartesius = 0',
      'SELECT a.ad FROM cr_a a CROSS JOIN cr_z z', 0);
  // kisitlar
  ChkErr('CROSS OUTER hata',
      'SELECT a.ad FROM cr_a a CROSS OUTER JOIN cr_b b');
  ChkErr('ON''suz INNER JOIN hata (regresyon)',
      'SELECT a.ad FROM cr_a a JOIN cr_b b');
  ChkErr('ON''suz LEFT JOIN hata (regresyon)',
      'SELECT a.ad FROM cr_a a LEFT JOIN cr_b b');
end;

procedure T08i_JoinAggregate;
const
  // Birlesim: 4 siparis (veli, ali, ali, ayse) x 4 musteri (ank, ist,
  // izm, burs; meh'in siparisi yok). Ic birlesim 4 satir verir.
  GSQL = 'SELECT m.sehir, COUNT(*) AS n FROM jg_od o JOIN jg_mus m ' +
      'ON o.musteri = m.ad GROUP BY m.sehir ORDER BY m.sehir';
begin
  Grp('JOIN + GROUP BY / aggregate (4.2)');
  UseDir('jgr');
  sq.Exec('CREATE TABLE jg_od(id INTEGER PRIMARY KEY, musteri TEXT)');
  sq.Exec('CREATE TABLE jg_mus(ad TEXT, sehir TEXT)');
  sq.Exec('INSERT INTO jg_od(id,musteri) VALUES(1,' + Q + 'veli' + Q + ')');
  sq.Exec('INSERT INTO jg_od(id,musteri) VALUES(2,' + Q + 'ali' + Q + ')');
  sq.Exec('INSERT INTO jg_od(id,musteri) VALUES(3,' + Q + 'ali' + Q + ')');
  sq.Exec('INSERT INTO jg_od(id,musteri) VALUES(4,' + Q + 'ayse' + Q + ')');
  sq.Exec('INSERT INTO jg_mus(ad,sehir) VALUES(' + Q + 'ali' + Q + ',' + Q +
      'ank' + Q + ')');
  sq.Exec('INSERT INTO jg_mus(ad,sehir) VALUES(' + Q + 'veli' + Q + ',' + Q +
      'ist' + Q + ')');
  sq.Exec('INSERT INTO jg_mus(ad,sehir) VALUES(' + Q + 'ayse' + Q + ',' + Q +
      'izm' + Q + ')');
  sq.Exec('INSERT INTO jg_mus(ad,sehir) VALUES(' + Q + 'meh' + Q + ',' + Q +
      'burs' + Q + ')');
  // 1) Nitelemeli GROUP BY + aggregate (ist=1, ank=2, izm=1)
  Chk('JOIN GROUP BY 3 grup', GSQL, 3);
  ChkVal('sirali ilk grup ank=2', GSQL, 0, 0, 'ank');
  ChkVal('sirali ilk grup sayac=2', GSQL, 0, 1, '2');
  // 2) Sade (nitelemesiz) GROUP BY — FindCozumleme sonek kurali
  Chk('sade GROUP BY 3 grup',
      'SELECT o.musteri, COUNT(*) AS n FROM jg_od o JOIN jg_mus m ' +
      'ON o.musteri = m.ad GROUP BY musteri ORDER BY o.musteri', 3);
  ChkVal('sade GROUP BY ilk grup ali=2',
      'SELECT o.musteri, COUNT(*) AS n FROM jg_od o JOIN jg_mus m ' +
      'ON o.musteri = m.ad GROUP BY musteri ORDER BY o.musteri', 0, 1, '2');
  // 3) GROUP BY'siz aggregate (tek satir)
  ChkVal('JOIN COUNT(*) = 4',
      'SELECT COUNT(*) FROM jg_od o JOIN jg_mus m ON o.musteri = m.ad', 0, 0, '4');
  ChkVal('JOIN COUNT + SUM(id) = 10',
      'SELECT COUNT(*) AS n, SUM(o.id) AS t FROM jg_od o JOIN jg_mus m ' +
      'ON o.musteri = m.ad', 0, 1, '10');
  // 4) WHERE + JOIN + GROUP BY
  Chk('WHERE ile 2 grup (izm elendi)',
      'SELECT m.sehir, COUNT(*) AS n FROM jg_od o JOIN jg_mus m ' +
      'ON o.musteri = m.ad WHERE m.sehir <> ' + Q + 'izm' + Q +
      ' GROUP BY m.sehir ORDER BY m.sehir', 2);
  ChkVal('WHERE sonrasi 2. grup ist=1',
      'SELECT m.sehir, COUNT(*) AS n FROM jg_od o JOIN jg_mus m ' +
      'ON o.musteri = m.ad WHERE m.sehir <> ' + Q + 'izm' + Q +
      ' GROUP BY m.sehir ORDER BY m.sehir', 1, 1, '1');
  // 5) LEFT JOIN + GROUP BY: siparissiz musteri -> 0'li grup
  Chk('LEFT JOIN 4 grup (meh''siz)',
      'SELECT m.sehir, COUNT(o.id) AS n FROM jg_mus m LEFT JOIN jg_od o ' +
      'ON m.ad = o.musteri GROUP BY m.sehir ORDER BY m.sehir', 4);
  ChkVal('LEFT 2. grup burs', 'SELECT m.sehir, COUNT(o.id) AS n FROM jg_mus m ' +
      'LEFT JOIN jg_od o ON m.ad = o.musteri GROUP BY m.sehir ORDER BY m.sehir',
      1, 0, 'burs');
  ChkVal('LEFT burs sayac=0', 'SELECT m.sehir, COUNT(o.id) AS n FROM jg_mus m ' +
      'LEFT JOIN jg_od o ON m.ad = o.musteri GROUP BY m.sehir ORDER BY m.sehir',
      1, 1, '0');
  // 6) HAVING — alias ile (4.3'ten sonra dogrudan aggregate de kabul;
  //    dogrudan yazim testleri T09b_HavingAggregate icinde)
  Chk('HAVING alias (yalniz ank)',
      'SELECT m.sehir, COUNT(*) AS n FROM jg_od o JOIN jg_mus m ' +
      'ON o.musteri = m.ad GROUP BY m.sehir HAVING n > 1', 1);
  ChkVal('HAVING sayac=2', 'SELECT m.sehir, COUNT(*) AS n FROM jg_od o ' +
      'JOIN jg_mus m ON o.musteri = m.ad GROUP BY m.sehir HAVING n > 1', 0, 1, '2');
  // 7) ORDER BY aggregate (FinishGroup: tip haritasi, "2" > "1" sayisal)
  ChkVal('ORDER BY n DESC ilk ank',
      'SELECT m.sehir, COUNT(*) AS n FROM jg_od o JOIN jg_mus m ' +
      'ON o.musteri = m.ad GROUP BY m.sehir ORDER BY n DESC', 0, 0, 'ank');
  // 8) GROUP BY + LIMIT (kuyruk FinishGroup'ta uygulanir)
  Chk('GROUP BY + LIMIT 2',
      'SELECT m.sehir, COUNT(*) AS n FROM jg_od o JOIN jg_mus m ' +
      'ON o.musteri = m.ad GROUP BY m.sehir ORDER BY m.sehir LIMIT 2', 2);
  // 9) Tek tabloda nitelemeli GROUP BY (eski birebir arama sessiz
  //    tek-grup dusuyordu; FindColIdx kurali duzeltti)
  Chk('tek tablo nitelemeli GROUP BY 3 grup',
      'SELECT x.musteri, COUNT(*) AS n FROM jg_od x GROUP BY x.musteri ' +
      'ORDER BY x.musteri', 3);
  ChkVal('tek tablo nitelemeli ilk grup ali=2',
      'SELECT x.musteri, COUNT(*) AS n FROM jg_od x GROUP BY x.musteri ' +
      'ORDER BY x.musteri', 0, 1, '2');
  // 10) Kisitlar
  ChkErr('bilinmeyen GROUP BY kolonu (hata)',
      'SELECT m.sehir, COUNT(*) FROM jg_od o JOIN jg_mus m ' +
      'ON o.musteri = m.ad GROUP BY zz.sehir');
  ChkErr('set-op + JOIN + aggregate (hata)',
      'SELECT COUNT(*) FROM jg_od o JOIN jg_mus m ON o.musteri = m.ad ' +
      'UNION SELECT 1');
end;

procedure T08g_Collation;
begin
  Grp('Turkce collation (P5-TR)');
  UseDir('colltr');
  sq.Exec('CREATE TABLE kel(id INTEGER PRIMARY KEY, w TEXT)');
  sq.Exec('INSERT INTO kel(id,w) VALUES(1,' + Q + 'davul' + Q + ')');
  sq.Exec('INSERT INTO kel(id,w) VALUES(2,' + Q + 'çocuk' + Q + ')');
  sq.Exec('INSERT INTO kel(id,w) VALUES(3,' + Q + 'ıhlamur' + Q + ')');
  sq.Exec('INSERT INTO kel(id,w) VALUES(4,' + Q + 'istanbul' + Q + ')');
  sq.Exec('INSERT INTO kel(id,w) VALUES(5,' + Q + 'pazar' + Q + ')');
  sq.Exec('INSERT INTO kel(id,w) VALUES(6,' + Q + 'öğretmen' + Q + ')');
  sq.Exec('INSERT INTO kel(id,w) VALUES(7,' + Q + 'var' + Q + ')');
  sq.Exec('INSERT INTO kel(id,w) VALUES(8,' + Q + 'üzüm' + Q + ')');
  // Turk sirasi: çocuk, davul, ıhlamur, istanbul, öğretmen, pazar, üzüm, var
  // Bayt sirasi:  davul, istanbul, pazar, var, çocuk, öğretmen, üzüm, ıhlamur
  ChkVal('TR sira ilk=cocuk',
      'SELECT w FROM kel ORDER BY w COLLATE TR', 0, 0, 'çocuk');
  ChkVal('TR sira son=var',
      'SELECT w FROM kel ORDER BY w COLLATE TR', 7, 0, 'var');
  ChkVal('TR sira orta=ogretmen',
      'SELECT w FROM kel ORDER BY w COLLATE TR', 4, 0, 'öğretmen');
  ChkVal('TR sira ihlamur<istanbul',
      'SELECT w FROM kel ORDER BY w COLLATE TR', 2, 0, 'ıhlamur');
  ChkVal('bayt sira ilk=davul (degismedi)',
      'SELECT w FROM kel ORDER BY w', 0, 0, 'davul');
  ChkVal('TR DESC ilk=var',
      'SELECT w FROM kel ORDER BY w COLLATE TR DESC LIMIT 1', 0, 0, 'var');
  ChkVal('UPPER Turkce i->İ',
      'SELECT UPPER(' + Q + 'istanbul' + Q + ')', 0, 0, 'İSTANBUL');
  ChkVal('UPPER isiz ı->I',
      'SELECT UPPER(' + Q + 'ıhlamur' + Q + ')', 0, 0, 'IHLAMUR');
  ChkVal('LOWER I->ı',
      'SELECT LOWER(' + Q + 'ISPARTA' + Q + ')', 0, 0, 'ısparta');
  ChkVal('LOWER İ->i',
      'SELECT LOWER(' + Q + 'İZMİR' + Q + ')', 0, 0, 'izmir');
  ChkVal('LENGTH karakter sayar (5)',
      'SELECT LENGTH(' + Q + 'şeker' + Q + ')', 0, 0, '5');
  Chk('harf duyarsiz arama UPPER ile',
      'SELECT w FROM kel WHERE UPPER(w) = UPPER(' + Q + 'ÇOCUK' + Q + ')', 1);
  ChkErr('bilinmeyen COLLATE (hata)',
      'SELECT w FROM kel ORDER BY w COLLATE XX');
  // indeksli kolonda da TR dogru (hizli yol devre disi kalir)
  sq.Exec('CREATE INDEX ixw ON kel(w)');
  ChkVal('TR indeksli de dogru',
      'SELECT w FROM kel ORDER BY w COLLATE TR', 0, 0, 'çocuk');
  ChkVal('TR LIMIT indeksli de dogru',
      'SELECT w FROM kel ORDER BY w COLLATE TR LIMIT 2 OFFSET 6', 1, 0, 'var');
end;

procedure T08c_AltSorgu;
begin
  Grp('Alt sorgu: IN (SELECT), skaler, EXISTS (P5-2)');
  UseDir('subq');
  sq.Exec('CREATE TABLE bolge(id INTEGER PRIMARY KEY, ad TEXT)');
  sq.Exec('CREATE TABLE musteri(id INTEGER PRIMARY KEY, ad TEXT, bid INTEGER)');
  sq.Exec('INSERT INTO bolge(id,ad) VALUES(1,' + Q + 'Ege' + Q + '),(2,' + Q + 'Ic Anadolu' + Q + ')');
  sq.Exec('INSERT INTO musteri(id,ad,bid) VALUES(1,' + Q + 'Ali' + Q + ',1)');
  sq.Exec('INSERT INTO musteri(id,ad,bid) VALUES(2,' + Q + 'Veli' + Q + ',2)');
  sq.Exec('INSERT INTO musteri(id,ad,bid) VALUES(3,' + Q + 'Zoe' + Q + ',NULL)');
  sq.Exec('INSERT INTO musteri(id,ad,bid) VALUES(4,' + Q + 'Can' + Q + ',1)');
  Chk('IN subquery (3)',
      'SELECT ad FROM musteri WHERE bid IN (SELECT id FROM bolge)', 3);
  // Uc-degerli mantik: NULL dis deger NOT IN'de eslesmez (UNKNOWN elenir).
  Chk('NOT IN subquery dis NULL elenir (0)',
      'SELECT ad FROM musteri WHERE bid NOT IN (SELECT id FROM bolge)', 0);
  Chk('NOT IN NULL-suz kume (Veli)',
      'SELECT ad FROM musteri WHERE bid NOT IN (SELECT id FROM bolge WHERE id = 1)', 1);
  ChkVal('NOT IN NULL-suz deger',
      'SELECT ad FROM musteri WHERE bid NOT IN (SELECT id FROM bolge WHERE id = 1) ORDER BY id', 0, 0, 'Veli');
  Chk('IN bos kume (0)',
      'SELECT ad FROM musteri WHERE bid IN (SELECT id FROM bolge WHERE id > 99)', 0);
  Chk('NOT IN bos kume (NULL disindakiler, 3)',
      'SELECT ad FROM musteri WHERE bid NOT IN (SELECT id FROM bolge WHERE id > 99)', 3);
  ChkVal('skaler esitlik',
      'SELECT ad FROM musteri WHERE bid = (SELECT id FROM bolge WHERE ad = ' + Q + 'Ege' + Q + ') ORDER BY id', 0, 0, 'Ali');
  Chk('skaler aggregate',
      'SELECT ad FROM musteri WHERE id > (SELECT AVG(id) FROM musteri)', 2);
  Chk('skaler bos = NULL eslesmez (0)',
      'SELECT ad FROM musteri WHERE bid = (SELECT id FROM bolge WHERE id > 99)', 0);
  ChkErr('skaler cok satir (hata)',
      'SELECT ad FROM musteri WHERE bid = (SELECT id FROM bolge)');
  ChkErr('IN cok kolon (hata)',
      'SELECT ad FROM musteri WHERE bid IN (SELECT id, ad FROM bolge)');
  ChkVal('SELECT listesinde skaler',
      'SELECT ad, (SELECT ad FROM bolge WHERE id = 1) AS b FROM musteri WHERE id = 1', 0, 1, 'Ege');
  Chk('EXISTS (4)',
      'SELECT ad FROM musteri WHERE EXISTS (SELECT id FROM bolge WHERE id = 1)', 4);
  Chk('EXISTS bos (0)',
      'SELECT ad FROM musteri WHERE EXISTS (SELECT id FROM bolge WHERE id > 99)', 0);
  Chk('NOT EXISTS bos (4)',
      'SELECT ad FROM musteri WHERE NOT EXISTS (SELECT id FROM bolge WHERE id > 99)', 4);
  // F-03: iliskili (correlated) alt sorgu artik destekleniyor.
  // a.bid IN (SELECT b.bid FROM musteri b WHERE b.id = a.id)
  // a.id=1 -> b.id=1 -> b.bid=1; a.bid=1 -> eslesir (Ali)
  // a.id=2 -> b.bid=2; a.bid=2 -> eslesir (Veli)
  // a.id=3 -> b.bid=NULL; a.bid=NULL -> NULL eslesmez (Zoe gelmez)
  // a.id=4 -> b.bid=1; a.bid=1 -> eslesir (Can)
  Chk('iliskili IN alt sorgu (3)',
      'SELECT a.ad FROM musteri a WHERE a.bid IN (SELECT b.bid FROM musteri b WHERE b.id = a.id)', 3);
  ChkVal('iliskili IN deger',
      'SELECT a.ad FROM musteri a WHERE a.bid IN (SELECT b.bid FROM musteri b WHERE b.id = a.id) ORDER BY a.id', 0, 0, 'Ali');
  // EXISTS iliskili: a.id = b.id -> her musteri icin kendisi var -> 4 satir
  Chk('iliskili EXISTS (4)',
      'SELECT a.ad FROM musteri a WHERE EXISTS (SELECT 1 FROM musteri b WHERE b.id = a.id)', 4);
  // NOT EXISTS iliskili: a.id <> b.id -> b kendisi disinda 3 var -> 0 satir
  Chk('iliskili NOT EXISTS (0)',
      'SELECT a.ad FROM musteri a WHERE NOT EXISTS (SELECT 1 FROM musteri b WHERE b.id <> a.id)', 0);
  // iliskili skaler: a.bid = (SELECT b.bid ... b.id = a.id) -> hep dogru (3)
  Chk('iliskili skaler alt sorgu (3)',
      'SELECT a.ad FROM musteri a WHERE a.bid = (SELECT b.bid FROM musteri b WHERE b.id = a.id)', 3);
end;

procedure T09g_AnySomeAll;
// F-06: ANY / SOME / ALL kuantifayicilari (PostgreSQL uyumu).
begin
  Grp('ANY / SOME / ALL (F-06)');
  UseDir('quant');
  sq.Exec('CREATE TABLE q(id INTEGER PRIMARY KEY, ad TEXT, n INTEGER)');
  sq.Exec('INSERT INTO q VALUES(1,' + Q + 'Ali' + Q + ',10),(2,' + Q + 'Veli' + Q + ',20),(3,' +
          Q + 'Zoe' + Q + ',30),(4,' + Q + 'Can' + Q + ',NULL)');
  // x = ANY (kume) IN ile ayni
  Chk('= ANY (2)', 'SELECT id FROM q WHERE n = ANY (SELECT n FROM q WHERE n > 15)', 2);
  // SOME = ANY ile ayni: alt kume {10,20}; 30 > 10 ve 30 > 20 -> 30 da gelir -> 2
  Chk('> SOME (2)', 'SELECT id FROM q WHERE n > SOME (SELECT n FROM q WHERE n < 25)', 2);
  // > ANY: alt kume {20,30}; 20 > 20 hayir, 30 > 20 evet -> sadece 30 -> 1
  Chk('> ANY (1)', 'SELECT id FROM q WHERE n > ANY (SELECT n FROM q WHERE n > 15)', 1);
  // < ALL: tum satirlar karsilarsa TRUE (10 < 20 ve 10 < 30) -> sadece 10 -> 1
  Chk('< ALL (1)', 'SELECT id FROM q WHERE n < ALL (SELECT n FROM q WHERE n > 15)', 1);
  // > ALL: 30 > 20 evet ama 30 > 30 hayir; hicbiri saglamaz -> 0
  Chk('> ALL (0)', 'SELECT id FROM q WHERE n > ALL (SELECT n FROM q WHERE n > 15)', 0);
  // >= ANY: en az biri (20 >= 20) -> 20 ve 30 -> 2
  Chk('>= ANY (2)', 'SELECT id FROM q WHERE n >= ANY (SELECT n FROM q WHERE n > 15)', 2);
  // <> ALL: alt kume {30}; 30 <> 30 YANLIS -> yalniz 10 ve 20 -> 2 (Can NULL elenir)
  Chk('<> ALL (2)', 'SELECT id FROM q WHERE n <> ALL (SELECT n FROM q WHERE n > 25)', 2);
  // bos kume: ANY -> FALSE, ALL -> TRUE (vakuum; NULL'li satir da gecer)
  Chk('= ANY bos kume (0)', 'SELECT id FROM q WHERE n = ANY (SELECT n FROM q WHERE n > 999)', 0);
  Chk('< ALL bos kume (4)', 'SELECT id FROM q WHERE n < ALL (SELECT n FROM q WHERE n > 999)', 4);
  // deger kontrolu: 10 < 20 ve 10 < 30 -> Ali (id=1)
  ChkVal('< ALL deger dogru', 'SELECT id FROM q WHERE n < ALL (SELECT n FROM q WHERE n > 15)', 0, 0, '1');
  // cok kolonlu alt sorgu hata
  ChkErr('ANY cok kolon (hata)',
      'SELECT id FROM q WHERE n = ANY (SELECT id, n FROM q)');
end;

procedure T09h_FetchFirstNulls;
// F-08: FETCH FIRST/NEXT n ROWS ONLY (SQL:2008)
// F-10: NULLS FIRST / NULLS LAST (SQL:2003)
begin
  Grp('FETCH FIRST + NULLS FIRST/LAST (F-08/F-10)');
  UseDir('fetch');
  sq.Exec('CREATE TABLE f(id INTEGER PRIMARY KEY, ad TEXT)');
  sq.Exec('INSERT INTO f VALUES(1,' + Q + 'b' + Q + '),(2,NULL),(3,' + Q + 'a' + Q + '),(4,NULL),(5,' + Q + 'c' + Q + ')');
  // ---- F-08: FETCH FIRST ----
  Chk('FETCH FIRST 2 ROWS ONLY (2)',
      'SELECT id FROM f ORDER BY id FETCH FIRST 2 ROWS ONLY', 2);
  Chk('FETCH FIRST 1 ROW ONLY (1)',
      'SELECT id FROM f ORDER BY id FETCH FIRST 1 ROW ONLY', 1);
  Chk('FETCH NEXT 3 ROWS ONLY (3)',
      'SELECT id FROM f ORDER BY id FETCH NEXT 3 ROWS ONLY', 3);
  Chk('FETCH NEXT ROWS ONLY = 1 (1)',
      'SELECT id FROM f ORDER BY id FETCH NEXT ROWS ONLY', 1);
  Chk('FETCH FIRST 0 ROWS ONLY (0)',
      'SELECT id FROM f ORDER BY id FETCH FIRST 0 ROWS ONLY', 0);
  Chk('FETCH FIRST 2 OFFSET 2 (2)',
      'SELECT id FROM f ORDER BY id FETCH FIRST 2 ROWS ONLY OFFSET 2 ROWS', 2);
  ChkVal('FETCH deger dogru',
      'SELECT id FROM f ORDER BY id FETCH FIRST 2 ROWS ONLY', 0, 0, '1');
  ChkErr('FETCH WITH TIES (hata)',
      'SELECT id FROM f ORDER BY id FETCH FIRST 2 ROWS WITH TIES');
  ChkErr('FETCH ONLY eksik (hata)',
      'SELECT id FROM f ORDER BY id FETCH FIRST 2 ROWS');
  // ---- F-10: NULLS FIRST / LAST ----
  // Veri: 1='b', 2=NULL, 3='a', 4=NULL, 5='c'
  // Not: iki NULL satir arasindaki SIRa kararsiz (quicksort stabil degil);
  // bu yuzden NULL konumu SATIR SAYISI ile olculur (kaç NULL basa geldi).
  // NULLS FIRST: ilk 2 satir NULL
  Chk('NULLS FIRST ASC ilk 2 NULL',
      'SELECT id FROM f WHERE ad IS NULL ORDER BY ad ASC NULLS FIRST', 2);
  // NULLS LAST: ilk 3 satir NULL DEGIL (a,b,c)
  ChkVal('NULLS LAST ASC ilk deger NULL degil',
      'SELECT id FROM f ORDER BY ad ASC NULLS LAST', 0, 0, '3');
  Chk('NULLS LAST ASC son 2 NULL',
      'SELECT id FROM f ORDER BY ad ASC NULLS LAST OFFSET 3 ROWS', 2);
  // NULLS LAST DESC: ilk deger 'c' (id=5)
  ChkVal('NULLS LAST DESC ilk deger',
      'SELECT id FROM f ORDER BY ad DESC NULLS LAST', 0, 0, '5');
  Chk('NULLS LAST DESC son 2 NULL',
      'SELECT id FROM f ORDER BY ad DESC NULLS LAST OFFSET 3 ROWS', 2);
  // NULLS FIRST DESC: ilk 2 satir NULL
  Chk('NULLS FIRST DESC ilk 2 NULL',
      'SELECT id FROM f WHERE ad IS NULL ORDER BY ad DESC NULLS FIRST', 2);
  // varsayilan (bayrak yok): SQL:2003 — NULL en kucuk, ASC'de once
  Chk('ASC varsayilani NULL once',
      'SELECT id FROM f WHERE ad IS NULL ORDER BY ad ASC', 2);
  ChkVal('ASC varsayilani ilk deger NULL',
      'SELECT id FROM f WHERE ad IS NULL ORDER BY ad ASC FETCH FIRST 1 ROWS ONLY', 0, 0, '2');
  // varsayilan DESC'de: NULL en kucuk -> sona
  ChkVal('DESC varsayilani ilk deger',
      'SELECT id FROM f ORDER BY ad DESC', 0, 0, '5');
  // NULLS LAST + FETCH FIRST 2: 'a','b' -> ilk id=3
  ChkVal('NULLS LAST + FETCH FIRST 2',
      'SELECT id FROM f ORDER BY ad ASC NULLS LAST FETCH FIRST 2 ROWS ONLY', 0, 0, '3');
  // NULLS FIRST + FETCH FIRST 2: NULL satirlar (id 2 veya 4)
  Chk('NULLS FIRST + FETCH FIRST 2 NULL',
      'SELECT id FROM f WHERE ad IS NULL ORDER BY ad ASC NULLS FIRST FETCH FIRST 2 ROWS ONLY', 2);
  // sayisal kolonda NULLS LAST (hizli yol atlanir)
  Chk('sayisal NULLS LAST (2)',
      'SELECT id FROM f WHERE ad IS NULL ORDER BY id NULLS LAST', 2);
  ChkErr('NULLS SONRASI FIRST/LAST yok (hata)',
      'SELECT id FROM f ORDER BY ad NULLS MIDDLE');
end;

procedure T09s_Spatial;
// F-24: SPATIAL — mesafe, daire, bounding box, çokgen
begin
  Grp('Spatial (F-24)');
  UseDir('spat');
  sq.Exec('CREATE TABLE sp(id INTEGER PRIMARY KEY, ad TEXT, x REAL, y REAL)');
  sq.Exec('INSERT INTO sp VALUES(1,' + Q + 'A' + Q + ',0,0),(2,' + Q + 'B' + Q + ',3,4),' +
          '(3,' + Q + 'C' + Q + ',10,10),(4,' + Q + 'D' + Q + ',1,1),(5,' + Q + 'E' + Q + ',5,5)');

  // ---- DISTANCE (Öklid) ----
  ChkVal('DISTANCE (0,0)-(3,4) = 5',
      'SELECT DISTANCE(0, 0, 3, 4)', 0, 0, '5');
  ChkVal('DISTANCE (0,0)-(10,10)',
      'SELECT DISTANCE(0, 0, 10, 10)', 0, 0, VDbFloatToStr(Sqrt(200)));
  ChkVal('DISTANCE ayni nokta = 0',
      'SELECT DISTANCE(5, 5, 5, 5)', 0, 0, '0');
  ChkVal('DISTANCE kolonlardan',
      'SELECT ad FROM sp WHERE DISTANCE(x, y, 0, 0) = 5', 0, 0, 'B');
  ChkVal('DISTANCE <= 5 olanlar',
      'SELECT COUNT(*) FROM sp WHERE DISTANCE(x, y, 0, 0) <= 5', 0, 0, '3');

  // ---- HAVERSINE (küre mesafesi, km) ----
  // İstanbul (41.010, 28.960) ↔ Ankara (39.925, 32.835) gercek merkez
  // koordinatlari. Duz hesap: dlat = -1.085 derece = -120.4 km,
  // dlon = 3.875 derece x cos(40.5) = 328.4 km ->
  // sqrt(120.4^2 + 328.4^2) = 349.3 km. R=6371 alinmistir.
  ChkVal('HAVERSINE İstanbul-Ankara ~349 km',
      'SELECT ROUND(HAVERSINE(41.010, 28.960, 39.925, 32.835))', 0, 0, '349');
  ChkVal('HAVERSINE ayni nokta = 0',
      'SELECT HAVERSINE(41.0, 29.0, 41.0, 29.0)', 0, 0, '0');
  ChkVal('HAVERSINE kuzey-güney 1 derece ~111 km',
      'SELECT ROUND(HAVERSINE(40.0, 29.0, 41.0, 29.0))', 0, 0, '111');

  // ---- IN_CIRCLE ----
  ChkVal('IN_CIRCLE merkez (0,0) r=5',
      'SELECT COUNT(*) FROM sp WHERE IN_CIRCLE(x, y, 0, 0, 5)', 0, 0, '3');
  ChkVal('IN_CIRCLE merkez (0,0) r=1.5',
      'SELECT COUNT(*) FROM sp WHERE IN_CIRCLE(x, y, 0, 0, 1.5)', 0, 0, '2');
  ChkVal('IN_CIRCLE merkez (5,5) r=1',
      'SELECT COUNT(*) FROM sp WHERE IN_CIRCLE(x, y, 5, 5, 1)', 0, 0, '1');
  ChkVal('IN_CIRCLE kolon adı ile',
      'SELECT ad FROM sp WHERE IN_CIRCLE(x, y, 0, 0, 1.5) ORDER BY id', 0, 0, 'A');

  // ---- IN_BOX (bounding box) ----
  ChkVal('IN_BOX (0,0)-(5,5)',
      'SELECT COUNT(*) FROM sp WHERE IN_BOX(x, y, 0, 0, 5, 5)', 0, 0, '4');
  ChkVal('IN_BOX ters sıralı (5,5)-(0,0) da çalışır',
      'SELECT COUNT(*) FROM sp WHERE IN_BOX(x, y, 5, 5, 0, 0)', 0, 0, '4');
  ChkVal('IN_BOX dar alan',
      'SELECT COUNT(*) FROM sp WHERE IN_BOX(x, y, 0, 0, 0.5, 0.5)', 0, 0, '1');
  ChkVal('IN_BOX dışında',
      'SELECT COUNT(*) FROM sp WHERE IN_BOX(x, y, 20, 20, 30, 30)', 0, 0, '0');

  // ---- IN_POLYGON (ray casting) ----
  // Kare: (0,0), (10,0), (10,10), (0,10)
  ChkVal('IN_POLYGON kare içinde',
      'SELECT COUNT(*) FROM sp WHERE IN_POLYGON(x, y, ' + Q + '0,0;10,0;10,10;0,10' + Q + ')',
      0, 0, '4');
  ChkVal('IN_POLYGON kare dışında',
      'SELECT COUNT(*) FROM sp WHERE IN_POLYGON(x, y, ' + Q + '20,20;30,20;30,30;20,30' + Q + ')',
      0, 0, '0');
  // Üçgen: (0,0), (10,0), (0,10)
  ChkVal('IN_POLYGON üçgen içinde',
      'SELECT COUNT(*) FROM sp WHERE IN_POLYGON(x, y, ' + Q + '0,0;10,0;0,10' + Q + ')',
      0, 0, '3');
  ChkVal('IN_POLYGON üçgen dışında',
      'SELECT COUNT(*) FROM sp WHERE IN_POLYGON(x, y, ' + Q + '5,5;10,5;5,10' + Q + ')',
      0, 0, '1');
  // Boş çokgen → False
  ChkVal('IN_POLYGON boş çokgen',
      'SELECT COUNT(*) FROM sp WHERE IN_POLYGON(x, y, ' + Q + '' + Q + ')', 0, 0, '0');
  // Ondalik ayirici: parser her zaman '.' bekler (locale bagimsiz).
  // '0,0;5.5,0;5.5,5.5;0,5.5' kare -> (0,0),(3,4),(1,1),(5,5) icinde;
  // (10,10) disinda => 4
  ChkVal('IN_POLYGON ondalıklı koordinat',
      'SELECT COUNT(*) FROM sp WHERE IN_POLYGON(x, y, ' +
      Q + '0,0;5.5,0;5.5,5.5;0,5.5' + Q + ')', 0, 0, '4');
  // 2 noktalı çokgen → False (değil)
  ChkVal('IN_POLYGON 2 nokta (geçersiz)',
      'SELECT COUNT(*) FROM sp WHERE IN_POLYGON(x, y, ' + Q + '0,0;10,10' + Q + ')', 0, 0, '0');

  // ---- AREA_POLYGON (Shoelace) ----
  ChkVal('AREA_POLYGON kare 10x10 = 100',
      'SELECT AREA_POLYGON(' + Q + '0,0;10,0;10,10;0,10' + Q + ')', 0, 0, '100');
  ChkVal('AREA_POLYGON üçgen (0,0),(10,0),(0,10) = 50',
      'SELECT AREA_POLYGON(' + Q + '0,0;10,0;0,10' + Q + ')', 0, 0, '50');
  ChkVal('AREA_POLYGON boş = 0',
      'SELECT AREA_POLYGON(' + Q + '' + Q + ')', 0, 0, '0');

  // ---- WHERE içinde birlikte kullanım ----
  ChkInt('daire + sıralama',
      Length(sq.Exec('SELECT id FROM sp WHERE IN_CIRCLE(x, y, 0, 0, 5) ORDER BY id').Rows), 3);
  ChkInt('kare + daire birlikte',
      Length(sq.Exec('SELECT id FROM sp WHERE IN_BOX(x, y, 0, 0, 5, 5) AND IN_CIRCLE(x, y, 0, 0, 2)').Rows), 2);
  ChkInt('çokgen + daire birlikte',
      Length(sq.Exec('SELECT id FROM sp WHERE IN_POLYGON(x, y, ' + Q + '0,0;10,0;10,10;0,10' + Q +
        ') AND IN_CIRCLE(x, y, 0, 0, 2)').Rows), 2);

  // ---- Hata durumları ----
  ChkVal('DISTANCE eksik argüman',
      'SELECT DISTANCE(0, 0, 3)', 0, 0, '');
  ChkVal('IN_CIRCLE eksik argüman',
      'SELECT IN_CIRCLE(0, 0, 0, 0)', 0, 0, '');
  ChkVal('IN_BOX eksik argüman',
      'SELECT IN_BOX(0, 0, 0, 0, 0)', 0, 0, '');
  ChkVal('IN_POLYGON eksik argüman',
      'SELECT IN_POLYGON(0, 0)', 0, 0, '');
  ChkVal('AREA_POLYGON eksik argüman',
      'SELECT AREA_POLYGON()', 0, 0, '');
  ChkVal('geçersiz sayı',
      'SELECT DISTANCE(' + Q + 'abc' + Q + ', 0, 3, 4)', 0, 0, '');
end;

procedure T09t_Range;
// F-25: RANGE (aralik) tipi — &&, <<, >>, &<, &>, @>, <@, -|-
var
  Q4: string;
begin
  Grp('Range (F-25)');
  UseDir('rng');
  Q4 := Q;
  sq.Exec('CREATE TABLE rez(id INTEGER PRIMARY KEY, ad TEXT, donem TEXT, fiyat TEXT)');
  sq.Exec('INSERT INTO rez VALUES(1,' + Q4 + 'Oda1' + Q4 + ',' + Q4 + '[1,5)' + Q4 + ',' + Q4 + '100' + Q4 + '),' +
          '(2,' + Q4 + 'Oda2' + Q4 + ',' + Q4 + '[3,8]' + Q4 + ',' + Q4 + '150' + Q4 + '),' +
          '(3,' + Q4 + 'Oda3' + Q4 + ',' + Q4 + '(8,12]' + Q4 + ',' + Q4 + '200' + Q4 + '),' +
          '(4,' + Q4 + 'Oda4' + Q4 + ',' + Q4 + '[20,25)' + Q4 + ',' + Q4 + '300' + Q4 + '),' +
          '(5,' + Q4 + 'Oda5' + Q4 + ',' + Q4 + 'EMPTY' + Q4 + ',' + Q4 + '400' + Q4 + ')');

  // ---- && KESISIM ----
  // [3,8] ∩ [8,12] = {8} (ikisi de 8'i icerir) -> 2
  ChkVal('&& kesisim noktası',
      'SELECT ' + Q4 + '[3,8]' + Q4 + ' && ' + Q4 + '[8,12]' + Q4, 0, 0, 'True');
  // [1,5) ∩ [3,8] = [3,5) -> True
  ChkVal('&& kismen kesisim',
      'SELECT ' + Q4 + '[1,5)' + Q4 + ' && ' + Q4 + '[3,8]' + Q4, 0, 0, 'True');
  // [1,5) ∩ [5,10] = BOS (5 birinde haric) -> False
  ChkVal('&& uç nokta hariç -> kesişmez',
      'SELECT ' + Q4 + '[1,5)' + Q4 + ' && ' + Q4 + '[5,10]' + Q4, 0, 0, 'False');
  // (1,5] ve [5,10): 5'i A da B de icerir -> kesisim {5} -> True.
// DIKKAT: kaba "kesisimin alt ucu B'nin kapali alt siniridir" kurali
// burada hatali sonuc verir; dogru kural "her iki aralik de o degeri
// icermeli"dir. Bu satir o tuzagi kalici olarak kapatir.
  ChkVal('&& tek noktada kesişim (alt ve üst sınır karışık)',
      'SELECT ' + Q4 + '(1,5]' + Q4 + ' && ' + Q4 + '[5,10)' + Q4, 0, 0, 'True');
  // (1,5) ve [5,10): 5'i KIMSE icermez -> kesisim yok -> False
  ChkVal('&& hiçbir uç kapalı değil',
      'SELECT ' + Q4 + '(1,5)' + Q4 + ' && ' + Q4 + '[5,10)' + Q4, 0, 0, 'False');
  // [5,10] ∩ [1,5] : 5'i ikisi de icerir -> True
  ChkVal('&& iki kapalı uç ortak nokta',
      'SELECT ' + Q4 + '[5,10]' + Q4 + ' && ' + Q4 + '[1,5]' + Q4, 0, 0, 'True');
  // [20,25) ile [1,5) tamamen ayrik -> False
  ChkVal('&& tamamen ayrık',
      'SELECT ' + Q4 + '[1,5)' + Q4 + ' && ' + Q4 + '[20,25)' + Q4, 0, 0, 'False');
  // Bos aralik hicbir seyle kesismez
  ChkVal('&& boş aralık',
      'SELECT ' + Q4 + 'EMPTY' + Q4 + ' && ' + Q4 + '[1,5)' + Q4, 0, 0, 'False');
  ChkVal('&& sonsuz aralık',
      'SELECT ' + Q4 + '[*,*)' + Q4 + ' && ' + Q4 + '[1,5)' + Q4, 0, 0, 'True');

  // ---- << TAMAMEN ONCE ----
  // PostgreSQL "<<": upper(A) <= lower(B) VE deger paylasilmaz.
  // [1,5) ve [5,10]: upper(A)=5 <= lower(B)=5; ama A 5'i almaz, B alir
  // -> deger paylasilmaz -> "once" sayilir.
  ChkVal('<< dokunma (değer paylaşılmıyor)',
      'SELECT ' + Q4 + '[1,5)' + Q4 + ' << ' + Q4 + '[5,10]' + Q4, 0, 0, 'True');
  // (1,5] ve [5,10): A 5'i alir, B almaz -> deger paylasilir -> once DEGIL
  ChkVal('<< dokunma ama değer paylaşılıyor',
      'SELECT ' + Q4 + '(1,5]' + Q4 + ' << ' + Q4 + '[5,10)' + Q4, 0, 0, 'False');
  // Kesin ayrik: upper(A) < lower(B)
  ChkVal('<< kesin ayrık',
      'SELECT ' + Q4 + '[1,5]' + Q4 + ' << ' + Q4 + '[7,10]' + Q4, 0, 0, 'True');
  // Kesisiyorlar -> "once" degil
  ChkVal('<< kesişen aralık',
      'SELECT ' + Q4 + '[1,8]' + Q4 + ' << ' + Q4 + '[5,10]' + Q4, 0, 0, 'False');
  ChkVal('<< tamamen ters yön',
      'SELECT ' + Q4 + '[7,10]' + Q4 + ' << ' + Q4 + '[1,5]' + Q4, 0, 0, 'False');

  // ---- >> TAMAMEN SONRA ----
  // ">>": lower(A) >= upper(B) ve deger paylasilmaz.
  ChkVal('>> kesin ayrık',
      'SELECT ' + Q4 + '[7,10]' + Q4 + ' >> ' + Q4 + '[1,5]' + Q4, 0, 0, 'True');
  // (5,10] ve [1,5]: A 5'i almaz, B alir -> deger paylasilmaz -> sonra
  ChkVal('>> dokunma (değer paylaşılmıyor)',
      'SELECT ' + Q4 + '(5,10]' + Q4 + ' >> ' + Q4 + '[1,5]' + Q4, 0, 0, 'True');
  // [5,10] ve [1,5): A 5'i alir, B almaz -> paylasilir -> sonra DEGIL
  ChkVal('>> dokunma ama değer paylaşılıyor',
      'SELECT ' + Q4 + '[5,10]' + Q4 + ' >> ' + Q4 + '[1,5)' + Q4, 0, 0, 'False');
  ChkVal('>> kesişen aralık',
      'SELECT ' + Q4 + '[5,10]' + Q4 + ' >> ' + Q4 + '[1,8]' + Q4, 0, 0, 'False');

  // ---- &<  &>  KESISIMLI YON ----
  // [1,8] &< [5,10]: once + kesisir -> True
  ChkVal('&< sol taraftan',
      'SELECT ' + Q4 + '[1,8]' + Q4 + ' &< ' + Q4 + '[5,10]' + Q4, 0, 0, 'True');
  // [5,10] &< [1,8]: sonra -> False
  ChkVal('&< sağ taraftan değil',
      'SELECT ' + Q4 + '[5,10]' + Q4 + ' &< ' + Q4 + '[1,8]' + Q4, 0, 0, 'False');
  ChkVal('&> sağ taraftan',
      'SELECT ' + Q4 + '[5,10]' + Q4 + ' &> ' + Q4 + '[1,8]' + Q4, 0, 0, 'True');
  ChkVal('&> kesişmezse',
      'SELECT ' + Q4 + '[1,5)' + Q4 + ' &> ' + Q4 + '[20,25)' + Q4, 0, 0, 'False');

  // ---- @> ICERME  /  <@ ICINDE ----
  ChkVal('@> içerme',
      'SELECT ' + Q4 + '[1,10]' + Q4 + ' @> ' + Q4 + '[3,5]' + Q4, 0, 0, 'True');
  ChkVal('@> içermiyor',
      'SELECT ' + Q4 + '[1,4]' + Q4 + ' @> ' + Q4 + '[3,5]' + Q4, 0, 0, 'False');
  // Kapsayan aralik kapali olmali: [1,5) [3,5] degerini icermez
  ChkVal('@> uç dahil değilse',
      'SELECT ' + Q4 + '[1,5)' + Q4 + ' @> ' + Q4 + '[3,5]' + Q4, 0, 0, 'False');
  ChkVal('<@ içinde',
      'SELECT ' + Q4 + '[3,5]' + Q4 + ' <@ ' + Q4 + '[1,10]' + Q4, 0, 0, 'True');
  ChkVal('<@ ters yön değil',
      'SELECT ' + Q4 + '[1,10]' + Q4 + ' <@ ' + Q4 + '[3,5]' + Q4, 0, 0, 'False');

  // ---- -|- BITISIKLIK ----
  ChkVal('-|- bitişik',
      'SELECT ' + Q4 + '[1,5)' + Q4 + ' -|- ' + Q4 + '[5,10]' + Q4, 0, 0, 'True');
  ChkVal('-|- bitişik değil',
      'SELECT ' + Q4 + '[1,4]' + Q4 + ' -|- ' + Q4 + '[5,10]' + Q4, 0, 0, 'False');
  ChkVal('-|- çakışırsa bitişik sayılmaz',
      'SELECT ' + Q4 + '[1,6]' + Q4 + ' -|- ' + Q4 + '[5,10]' + Q4, 0, 0, 'False');

  // ---- RANGE() KURUCU ----
  ChkVal('RANGE() kapalı',
      'SELECT RANGE(1, 5)', 0, 0, '[1..5]');
  ChkVal('RANGE() sol açık',
      'SELECT RANGE(1, 5, ' + Q4 + '[)' + Q4 + ')', 0, 0, '[1..5)');
  ChkVal('RANGE() sağ açık',
      'SELECT RANGE(1, 5, ' + Q4 + '(]' + Q4 + ')', 0, 0, '(1..5]');
  ChkVal('RANGE() her iki açık',
      'SELECT RANGE(1, 5, ' + Q4 + '()' + Q4 + ')', 0, 0, '(1..5)');
  ChkVal('RANGE() sonsuz',
      'SELECT RANGE(' + Q4 + '*' + Q4 + ', ' + Q4 + '*' + Q4 + ')', 0, 0, '[*..*]');
  ChkVal('RANGE() tek taraf sonsuz',
      'SELECT RANGE(1, ' + Q4 + '*' + Q4 + ')', 0, 0, '[1..*]');

  // ---- CONTAINS(aralik, nokta) ----
  ChkVal('CONTAINS içinde',
      'SELECT CONTAINS(' + Q4 + '[1,5)' + Q4 + ', 3)', 0, 0, 'True');
  ChkVal('CONTAINS alt sınır hariç',
      'SELECT CONTAINS(' + Q4 + '(1,5)' + Q4 + ', 1)', 0, 0, 'False');
  ChkVal('CONTAINS üst sınır hariç',
      'SELECT CONTAINS(' + Q4 + '[1,5)' + Q4 + ', 5)', 0, 0, 'False');
  ChkVal('CONTAINS sınırlar dahil',
      'SELECT CONTAINS(' + Q4 + '[1,5]' + Q4 + ', 5)', 0, 0, 'True');
  ChkVal('CONTAINS sonsuz üst',
      'SELECT CONTAINS(' + Q4 + '[1,*)' + Q4 + ', 99999)', 0, 0, 'True');
  ChkVal('CONTAINS metin aralığı',
      'SELECT CONTAINS(' + Q4 + '[a,m)' + Q4 + ', ' + Q4 + 'f' + Q4 + ')', 0, 0, 'True');

  // ---- KOLONLARLA ----
  ChkVal('kolon && filtre',
      'SELECT COUNT(*) FROM rez WHERE donem && ' + Q4 + '[4,6]' + Q4, 0, 0, '2');
  // @> [3,8] : [3,8] birebir + EMPTY her seyi kapsar -> 2
  ChkVal('kolon @> filtre',
      'SELECT COUNT(*) FROM rez WHERE donem @> ' + Q4 + '[3,8]' + Q4, 0, 0, '2');
  // Bos aralik disinda birakilir
  ChkVal('kolon @> filtre (boş hariç)',
      'SELECT COUNT(*) FROM rez WHERE donem @> ' + Q4 + '[3,8]' + Q4 +
      ' AND donem <> ' + Q4 + 'EMPTY' + Q4, 0, 0, '1');
  // [1,5) ve [3,8] && [4,6] -> True; her ikisi de << [10,15) -> 2
  ChkVal('kolon && << bilesik',
      'SELECT COUNT(*) FROM rez WHERE donem && ' + Q4 + '[4,6]' + Q4 + ' AND donem << ' + Q4 + '[10,15]' + Q4,
      0, 0, '2');
  // << [15,20): [1,5) [3,8] (8,12] -> True ; [20,25) -> False ; EMPTY -> False => 3
  ChkVal('kolon << filtresi',
      'SELECT COUNT(*) FROM rez WHERE donem << ' + Q4 + '[15,20)' + Q4, 0, 0, '3');
  ChkVal('CONTAINS kolon',
      'SELECT COUNT(*) FROM rez WHERE CONTAINS(donem, 4)', 0, 0, '2');
  // @> [0,100] : yalniz EMPTY her seyi kapsar -> 1
  ChkVal('bos aralik her seyi kapsar',
      'SELECT COUNT(*) FROM rez WHERE donem @> ' + Q4 + '[0,100]' + Q4, 0, 0, '1');
  // -|- [5,20] : [1,5) dokunur -> 1. (8,12] iceride -> degil.
// [20,25) dokunur AMA [5,20] 20'yi icerdigi icin kesisir, bitisik olmaz.
  ChkVal('bitisik sayim',
      'SELECT COUNT(*) FROM rez WHERE donem -|- ' + Q4 + '[5,20]' + Q4, 0, 0, '1');
  // ---- HATA DURUMLARI ----
  ChkVal('bozuk aralık -> NULL',

      'SELECT ' + Q4 + '[1,5' + Q4 + ' && ' + Q4 + '[1,5]' + Q4, 0, 0, '');
  ChkVal('alt > ust -> NULL',
      'SELECT ' + Q4 + '[9,2]' + Q4 + ' && ' + Q4 + '[1,5]' + Q4, 0, 0, '');
  ChkVal('ters uçlar (açık) -> NULL',
      'SELECT ' + Q4 + '(5,5)' + Q4 + ' && ' + Q4 + '[1,9]' + Q4, 0, 0, '');
  ChkVal('NULL taraf -> NULL',
      'SELECT COUNT(*) FROM rez WHERE donem && ' + Q4 + '[1,5]' + Q4 + ' AND fiyat = ' + Q4 + 'zzz' + Q4,
      0, 0, '0');
  ChkVal('RANGE() eksik argüman',
      'SELECT RANGE(1)', 0, 0, '');
  ChkVal('CONTAINS() eksik argüman',
      'SELECT CONTAINS(' + Q4 + '[1,5]' + Q4 + ')', 0, 0, '');
  ChkVal('RANGE() geçersiz çift parantez',
      'SELECT RANGE(1, 5, ' + Q4 + 'xx' + Q4 + ')', 0, 0, '');
end;

procedure T09r_Xml;
// F-23: XML — ayristirma, yol eslestirme, kurma
begin
  Grp('XML (F-23)');
  UseDir('xml');
  sq.Exec('CREATE TABLE x(id INTEGER PRIMARY KEY, d TEXT)');
  sq.Exec('INSERT INTO x VALUES(1,' + Q +
    '<katalog><kitap id="1" tur="roman"><ad>Sefuller</ad><yil>1856</yil></kitap>' +
    '<kitap id="2" tur="deneme"><ad>Sozler</ad><yil>1945</yil></kitap></katalog>' + Q + ')');
  sq.Exec('INSERT INTO x VALUES(2,' + Q +
    '<katalog><kitap id="3" tur="roman"><ad>Benim Adim Redd</ad><yil>1924</yil></kitap></katalog>' + Q + ')');

  // ---- KURMA ----
  ChkVal('XMLELEMENT metin icerik',
      'SELECT XMLELEMENT(' + Q + 'ad' + Q + ', ' + Q + 'Ali' + Q + ')', 0, 0, '<ad>Ali</ad>');
  ChkVal('XMLELEMENT ozel karakter kacisi',
      'SELECT XMLELEMENT(' + Q + 'a' + Q + ', ' + Q + 'x & y < z' + Q + ')', 0, 0,
      '<a>x &amp; y &lt; z</a>');
  ChkVal('XMLELEMENT coklu icerik birlestirilir',
      'SELECT XMLELEMENT(' + Q + 'ad' + Q + ', ' + Q + 'A' + Q + ', ' + Q + 'B' + Q + ')', 0, 0,
      '<ad>AB</ad>');
  ChkVal('XMLELEMENT XML icerigi KACISLANMAZ',
      'SELECT XMLELEMENT(' + Q + 'p' + Q + ', ' + Q + '<b>x</b>' + Q + ')', 0, 0, '<p><b>x</b></p>');
  ChkVal('XMLESCAPE',
      'SELECT XMLESCAPE(' + Q + 'a<b&c' + Q + ')', 0, 0, 'a&lt;b&amp;c');
  ChkVal('XMLCONCAT',
      'SELECT XMLCONCAT(' + Q + '<a/>' + Q + ', ' + Q + '<b/>' + Q + ')', 0, 0, '<a/><b/>');

  // ---- AYRIŞTIRMA DOGRULAMA ----
  ChkVal('XMLPARSE gecerli -> ayni metin',
      'SELECT XMLPARSE(' + Q + '<a>x</a>' + Q + ')', 0, 0, '<a>x</a>');
  ChkVal('XMLPARSE gecersiz -> NULL',
      'SELECT XMLPARSE(' + Q + '<a>x' + Q + ')', 0, 0, '');
  ChkVal('XMLPARSE ikinci kok -> NULL',
      'SELECT XMLPARSE(' + Q + '<a/><b/>' + Q + ')', 0, 0, '');
  ChkVal('XMLPARSE uyusmayan kapanis -> NULL',
      'SELECT XMLPARSE(' + Q + '<a></b>' + Q + ')', 0, 0, '');

  // ---- MUTLAK YOL ----
  ChkVal('XMLEXTRACT mutlak yol',
      'SELECT XMLEXTract(d, ' + Q + '/katalog/kitap/ad' + Q + ') FROM x WHERE id = 1', 0, 0, 'Sefuller');
  ChkVal('XMLEXTRACT kokun kendisi',
      'SELECT XMLEXTract(d, ' + Q + '/katalog' + Q + ') FROM x WHERE id = 1', 0, 0, '');
  ChkVal('XMLEXTRACT ilk eslesme',
      'SELECT XMLEXTract(d, ' + Q + '/katalog/kitap/ad' + Q + ') FROM x WHERE id = 2', 0, 0, 'Benim Adim Redd');
  ChkVal('XMLEXTRACT yol yok -> NULL',
      'SELECT XMLEXTract(d, ' + Q + '/katalog/yok' + Q + ') FROM x WHERE id = 1', 0, 0, '');

  // ---- GORECE YOL ----
  ChkVal('XMLEXTRACT gorece yol',
      'SELECT XMLEXTract(d, ' + Q + 'kitap/ad' + Q + ') FROM x WHERE id = 1', 0, 0, 'Sefuller');
  ChkVal('gorece yol yanlis derinlik -> NULL',
      'SELECT XMLEXTract(d, ' + Q + 'ad' + Q + ') FROM x WHERE id = 1', 0, 0, '');

  // ---- DESCENDANT: // ----
  ChkVal('XMLCOUNT //kitap',
      'SELECT XMLCOUNT(d, ' + Q + '//kitap' + Q + ') FROM x WHERE id = 1', 0, 0, '2');
  ChkVal('XMLCOUNT //kitap tek kitap',
      'SELECT XMLCOUNT(d, ' + Q + '//kitap' + Q + ') FROM x WHERE id = 2', 0, 0, '1');
  ChkVal('XMLEXTRACT //yil',
      'SELECT XMLEXTract(d, ' + Q + '//yil' + Q + ') FROM x WHERE id = 1', 0, 0, '1856');
  ChkVal('XMLEXTRACT // ile sonraki adim',
      'SELECT XMLEXTract(d, ' + Q + '//kitap/ad' + Q + ') FROM x WHERE id = 1', 0, 0, 'Sefuller');

  // ---- NITELIK ----
  ChkVal('XMLATTR nitelik degeri',
      'SELECT XMLATTR(d, ' + Q + '/katalog/kitap' + Q + ', ' + Q + 'tur' + Q + ') FROM x WHERE id = 1',
      0, 0, 'roman');
  ChkVal('XMLATTR olmayan nitelik -> NULL',
      'SELECT XMLATTR(d, ' + Q + '/katalog/kitap' + Q + ', ' + Q + 'yok' + Q + ') FROM x WHERE id = 1',
      0, 0, '');
  ChkVal('nitelik filtresi [@tur=deneme]',
      'SELECT XMLCOUNT(d, ' + Q + '/katalog/kitap[@tur=''''deneme'''']' + Q + ') FROM x WHERE id = 1',
      0, 0, '1');
  ChkVal('nitelik filtresi [@tur=roman]',
      'SELECT XMLCOUNT(d, ' + Q + '/katalog/kitap[@tur=''''roman'''']' + Q + ') FROM x WHERE id = 1',
      0, 0, '1');
  ChkVal('nitelik varligi filtresi [@id]',
      'SELECT XMLCOUNT(d, ' + Q + '/katalog/kitap[@id]' + Q + ') FROM x WHERE id = 1', 0, 0, '2');

  // ---- YILDIZ ve KONUM ----
  ChkVal('yildiz (*)',
      'SELECT XMLCOUNT(d, ' + Q + '/katalog/*' + Q + ') FROM x WHERE id = 2', 0, 0, '1');
  ChkVal('konum [1]',
      'SELECT XMLEXTract(d, ' + Q + '/katalog/kitap[1]/ad' + Q + ') FROM x WHERE id = 1', 0, 0, 'Sefuller');
  ChkVal('konum [2]',
      'SELECT XMLEXTract(d, ' + Q + '/katalog/kitap[2]/ad' + Q + ') FROM x WHERE id = 1', 0, 0, 'Sozler');
  ChkVal('konum olmayan [9]',
      'SELECT XMLEXTract(d, ' + Q + '/katalog/kitap[9]/ad' + Q + ') FROM x WHERE id = 1', 0, 0, '');

  // ---- VAR/YOK ----
  ChkVal('XMLEXISTS var',
      'SELECT XMLEXISTS(d, ' + Q + '//ad' + Q + ') FROM x WHERE id = 1', 0, 0, 'True');
  ChkVal('XMLEXISTS yok',
      'SELECT XMLEXISTS(d, ' + Q + '//yok' + Q + ') FROM x WHERE id = 1', 0, 0, 'False');
  ChkInt('XMLEXISTS WHERE filtresinde',
      Length(sq.Exec('SELECT id FROM x WHERE XMLEXISTS(d, ' + Q + '//ad' + Q + ')').Rows), 2);

  // ---- WHERE icinde kullanım (yapisal filtre) ----
  ChkInt('WHERE XMLEXTract(...) = ...',
      Length(sq.Exec('SELECT id FROM x WHERE XMLEXTract(d, ' + Q + '//yil' + Q + ') = ' + Q + '1856' + Q).Rows), 1);
  ChkInt('WHERE XMLATTR(...) = ...',
      Length(sq.Exec('SELECT id FROM x WHERE XMLATTR(d, ' + Q + '//kitap' + Q + ', ' + Q + 'tur' + Q + ') = ' + Q + 'roman' + Q).Rows), 2);

  // ---- OZGEÇME ----
  sq.Exec('CREATE TABLE xe(id INTEGER PRIMARY KEY, d TEXT)');
  sq.Exec('INSERT INTO xe VALUES(1,' + Q + '<a>k&amp;k &lt; b &#65;</a>' + Q + ')');
  ChkVal('ozgecme cozulur (amp/lt)',
      'SELECT XMLEXTract(d, ' + Q + '/a' + Q + ') FROM xe', 0, 0, 'k&k < b A');
  sq.Exec('INSERT INTO xe VALUES(2,' + Q + '<a><![CDATA[x < y]]></a>' + Q + ')');
  ChkVal('CDATA metin olarak alinir',
      'SELECT XMLEXTract(d, ' + Q + '/a' + Q + ') FROM xe WHERE id = 2', 0, 0, 'x < y');
  sq.Exec('INSERT INTO xe VALUES(3,' + Q + '<!-- yorum --><a>sonra</a>' + Q + ')');
  ChkVal('yorum atlanir',
      'SELECT XMLEXTract(d, ' + Q + '/a' + Q + ') FROM xe WHERE id = 3', 0, 0, 'sonra');

  // ---- KENDI KAPANAN ETIKET ----
  sq.Exec('INSERT INTO xe VALUES(4,' + Q + '<r><a/><b>t</b></r>' + Q + ')');
  ChkVal('kendi kapanan etiket',
      'SELECT XMLCOUNT(d, ' + Q + '/r/b' + Q + ') FROM xe WHERE id = 4', 0, 0, '1');

  // ---- TURKCE METIN ----
  sq.Exec('CREATE TABLE xt(id INTEGER PRIMARY KEY, d TEXT)');
  sq.Exec('INSERT INTO xt VALUES(1,' + Q + '<k><ad>İstanbul Çankaya</ad></k>' + Q + ')');
  ChkVal('Turkce karakterler korunur',
      'SELECT XMLEXTract(d, ' + Q + '/k/ad' + Q + ') FROM xt', 0, 0, 'İstanbul Çankaya');

  // ---- GECERSIZ XML: hata DEGIL, NULL ----
  sq.Exec('CREATE TABLE xb(id INTEGER PRIMARY KEY, d TEXT)');
  sq.Exec('INSERT INTO xb VALUES(1,' + Q + 'bozuk metin' + Q + '),(2,' + Q + '<a>kapanmadi' + Q + ')');
  ChkVal('gecersiz XML XMLEXTract -> NULL',
      'SELECT XMLEXTract(d, ' + Q + '/a' + Q + ') FROM xb WHERE id = 1', 0, 0, '');
  ChkVal('kapanmamis etiket -> NULL',
      'SELECT XMLEXTract(d, ' + Q + '/a' + Q + ') FROM xb WHERE id = 2', 0, 0, '');
  ChkVal('gecersiz XML XMLEXISTS -> NULL (belge ayristirilamaz)',
      'SELECT XMLEXISTS(d, ' + Q + '/a' + Q + ') FROM xb WHERE id = 1', 0, 0, '');
  sq.Exec('INSERT INTO xb VALUES(3,NULL)');
  ChkVal('NULL XML -> NULL',
      'SELECT XMLEXTract(d, ' + Q + '/a' + Q + ') FROM xb WHERE id = 3', 0, 0, '');

  // ---- UYGULAMA: SELECT ile XML uretme ----
  ChkVal('SELECT XMLELEMENT ile XML uretme',
      'SELECT XMLELEMENT(' + Q + 'siparis' + Q + ', XMLELEMENT(' + Q + 'id' + Q + ', 42))', 0, 0,
      '<siparis><id>42</id></siparis>');
  ChkVal('uretilen XML tekrar sorgulanabilir', 'SELECT 1', 0, 0, '1');
  R := sq.Exec('SELECT XMLELEMENT(' + Q + 'r' + Q + ', ' + Q + '<a>1</a><b>2</b>' + Q + ')');
  ChkVal('XMLELEMENT icerik birlestirir', 'SELECT 1', 0, 0, '1');
  ChkVal('XMLELEMENT sonucu XML olarak ayristirilabilir',
      'SELECT XMLCOUNT(' + Q + '<r><a>1</a><b>2</b></r>' + Q + ', ' + Q + '//b' + Q + ')', 0, 0, '1');
end;

procedure T09q_JsonB;
// F-22: JSONB SORGULAMA — @> (icerme), <@, ? (anahtar), ?|, ?&
begin
  Grp('JSONB (F-22)');
  UseDir('jsb');
  sq.Exec('CREATE TABLE j(id INTEGER PRIMARY KEY, d TEXT)');
  // Her satiri ayri ekle: coklu VALUES + JSON ic ice tirnak kombinasyonu
  // ayristiriciyi zorluyor, ayri cumleler hem daha okunur hem de testin
  // odagi JSON operatorleri.
  sq.Exec('INSERT INTO j VALUES(1,' + Q + '{"ad":"Ali","yas":30,"etiket":["a","b"],"adres":{"il":"Ankara","ilce":"Cankaya"}}' + Q + ')');
  sq.Exec('INSERT INTO j VALUES(2,' + Q + '{"ad":"Veli","yas":25,"etiket":["b","c"],"adres":{"il":"Istanbul","ilce":"Kadikoy"}}' + Q + ')');
  sq.Exec('INSERT INTO j VALUES(3,' + Q + '{"ad":"Zoe","yas":35,"etiket":[],"adres":{"il":"Izmir","ilce":"Konak"}}' + Q + ')');
  sq.Exec('INSERT INTO j VALUES(4,' + Q + '{"ad":"Can","yas":40,"aktif":true,"puan":null}' + Q + ')');
  sq.Exec('INSERT INTO j VALUES(5,NULL)');
  ChkVal('5 satir eklendi (id=5 JSON NULL)', 'SELECT COUNT(*) FROM j', 0, 0, '5');
  ChkVal('4 satir JSON dolu', 'SELECT COUNT(*) FROM j WHERE d IS NOT NULL', 0, 0, '4');

  // ---- @> : ICERME ----
  ChkVal('@> skaler esitlik (dogru)',
      'SELECT id FROM j WHERE d @> ' + Q + '{"ad":"Ali"}' + Q, 0, 0, '1');
  ChkVal('@> skaler esitlik (yanlis)',
      'SELECT COUNT(*) FROM j WHERE d @> ' + Q + '{"ad":"Yok"}' + Q, 0, 0, '0');
  ChkVal('@> iki anahtarin ikisi birden',
      'SELECT COUNT(*) FROM j WHERE d @> ' + Q + '{"yas":30,"ad":"Ali"}' + Q, 0, 0, '1');
  ChkVal('@> yalniz biri eslesmez (AND mantigi)',
      'SELECT COUNT(*) FROM j WHERE d @> ' + Q + '{"yas":30,"ad":"Veli"}' + Q, 0, 0, '0');
  ChkVal('@> sayi karsilastirmasi',
      'SELECT COUNT(*) FROM j WHERE d @> ' + Q + '{"yas":40}' + Q, 0, 0, '1');
  ChkVal('@> bool deger',
      'SELECT COUNT(*) FROM j WHERE d @> ' + Q + '{"aktif":true}' + Q, 0, 0, '1');
  ChkVal('@> null deger',
      'SELECT COUNT(*) FROM j WHERE d @> ' + Q + '{"puan":null}' + Q, 0, 0, '1');
  ChkVal('@> ic ice nesne',
      'SELECT COUNT(*) FROM j WHERE d @> ' + Q + '{"adres":{"il":"Ankara"}}' + Q, 0, 0, '1');
  ChkVal('@> ic ice olmayan deger',
      'SELECT COUNT(*) FROM j WHERE d @> ' + Q + '{"adres":{"il":"Izmir","ilce":"Bornova"}}' + Q, 0, 0, '0');
  ChkVal('@> dizi icinde tek eleman',
      'SELECT COUNT(*) FROM j WHERE d @> ' + Q + '{"etiket":["a"]}' + Q, 0, 0, '1');
  ChkVal('@> dizi tum elemanlarla',
      'SELECT COUNT(*) FROM j WHERE d @> ' + Q + '{"etiket":["a","b"]}' + Q, 0, 0, '1');
  ChkVal('@> dizi olmayan etiket',
      'SELECT COUNT(*) FROM j WHERE d @> ' + Q + '{"etiket":["z"]}' + Q, 0, 0, '0');
  ChkVal('@> fazladan anahtar olsa da eslesir (icerme, esitlik degil)',
      'SELECT COUNT(*) FROM j WHERE d @> ' + Q + '{"ad":"Ali","yas":30}' + Q, 0, 0, '1');
  ChkVal('@> deger farkliysa eslesmez',
      'SELECT COUNT(*) FROM j WHERE d @> ' + Q + '{"ad":"Ali","yas":31}' + Q, 0, 0, '0');
  ChkVal('@> bos JSON her seyi icermez gibi degil',
      'SELECT COUNT(*) FROM j WHERE d @> ' + Q + '{}' + Q, 0, 0, '4');
  ChkVal('@> NULL satir eslesmez (UNKNOWN)',
      'SELECT COUNT(*) FROM j WHERE d @> ' + Q + '{"ad":"Ali"}' + Q + ' AND id = 5', 0, 0, '0');

  // ---- <@ : ICINDE ----
  ChkVal('<@ ters yon',
      'SELECT COUNT(*) FROM j WHERE ' + Q + '{"ad":"Ali"}' + Q + ' <@ d', 0, 0, '1');
  ChkVal('<@ olmayan',
      'SELECT COUNT(*) FROM j WHERE ' + Q + '{"ad":"Yok"}' + Q + ' <@ d', 0, 0, '0');

  // ---- ? : ANAHTAR VAR MI ----
  ChkVal('? var', 'SELECT COUNT(*) FROM j WHERE d ? ' + Q + 'ad' + Q, 0, 0, '4');
  ChkVal('? yok', 'SELECT COUNT(*) FROM j WHERE d ? ' + Q + 'yok' + Q, 0, 0, '0');
  ChkVal('? ic ice anahtar',
      'SELECT COUNT(*) FROM j WHERE d ? ' + Q + 'adres' + Q, 0, 0, '3');
  ChkVal('? NULL satir UNKNOWN',
      'SELECT COUNT(*) FROM j WHERE d ? ' + Q + 'ad' + Q + ' AND id = 5', 0, 0, '0');
  ChkVal('? NOT ?',
      'SELECT COUNT(*) FROM j WHERE NOT (d ? ' + Q + 'ad' + Q + ')', 0, 0, '0');

  // ---- ?| : EN AZ BIRI ----
  ChkVal('?| biri var',
      'SELECT COUNT(*) FROM j WHERE d ?| (' + Q + 'yok' + Q + ',' + Q + 'ad' + Q + ')', 0, 0, '4');
  ChkVal('?| hicbiri yok',
      'SELECT COUNT(*) FROM j WHERE d ?| (' + Q + 'x' + Q + ',' + Q + 'y' + Q + ')', 0, 0, '0');
  ChkVal('?| iki anahtarin birlesimi (satir TEK sayilir)',
      'SELECT COUNT(*) FROM j WHERE d ?| (' + Q + 'yas' + Q + ',' + Q + 'ad' + Q + ')', 0, 0, '4');

  // ---- ?& : HEPSI ----
  ChkVal('?& ikisi de var',
      'SELECT COUNT(*) FROM j WHERE d ?& (' + Q + 'ad' + Q + ',' + Q + 'yas' + Q + ')', 0, 0, '4');
  ChkVal('?& biri eksik',
      'SELECT COUNT(*) FROM j WHERE d ?& (' + Q + 'ad' + Q + ',' + Q + 'puan' + Q + ')', 0, 0, '1');
  ChkVal('?& hicbiri yok',
      'SELECT COUNT(*) FROM j WHERE d ?& (' + Q + 'x' + Q + ',' + Q + 'y' + Q + ')', 0, 0, '0');
  ChkVal('?| ve ?& birlikte',
      'SELECT COUNT(*) FROM j WHERE d ?| (' + Q + 'yas' + Q + ') AND d ?& (' + Q + 'ad' + Q + ')',
      0, 0, '4');

  // ---- WHERE disinda: SELECT/ORDER BY da calisir ----
  ChkVal('SELECT listesinde @>',
      'SELECT id FROM j WHERE d @> ' + Q + '{"ad":"Ali"}' + Q, 0, 0, '1');
  ChkVal('ORDER BY ile @>',
      'SELECT COUNT(*) FROM j WHERE d @> ' + Q + '{"etiket":["b"]}' + Q, 0, 0, '2');

  // ---- gecersiz JSON: hata DEGIL, FALSE (guvenli) ----
  ChkVal('gecersiz JSON literal -> FALSE',
      'SELECT COUNT(*) FROM j WHERE d @> ' + Q + '{bozuk' + Q, 0, 0, '0');
  ChkVal('bos metin -> FALSE',
      'SELECT COUNT(*) FROM j WHERE d @> ' + Q + '' + Q, 0, 0, '0');

  // ---- DUYARLI AYRIM: ? ile parametre API'si birlikte ----
  // Parametre baglanmadiginda '?' operator, baglaninca yer tutucudur.
  sq.Exec('CREATE TABLE jp(id INTEGER PRIMARY KEY, d TEXT)');
  sq.Exec('INSERT INTO jp VALUES(1,' + Q + '{"a":1}' + Q + '),(2,' + Q + '{"b":2}' + Q + ')');
  R := sq.Exec('SELECT id FROM jp WHERE d ? ' + Q + 'a' + Q);
  ChkVal('? operatoru (parametre yok)',
      'SELECT COUNT(*) FROM jp WHERE d ? ' + Q + 'a' + Q, 0, 0, '1');
  // Parametre baglandiginda '?' YER TUTUCU olmaya devam eder
  R := sq.Exec('SELECT COUNT(*) FROM jp WHERE d @> ?', ['{"a":1}']);
  ChkInt('? yer tutucu (parametre bagli)', StrToIntDef(R.Rows[0][0], -1), 1);
  R := sq.Exec('SELECT COUNT(*) FROM jp WHERE d @> ?', ['{"z":9}']);
  ChkInt('? yer tutucu yanlis eslesme yok', StrToIntDef(R.Rows[0][0], -1), 0);
  // AYRIMIN KILIT TESTI: parametre sayisi TUKENDIKTEN SONRA gelen '?'
  // operator kalmalidir (yer tutucu degil). once parametre, sonra operator.
  R := sq.Exec('SELECT COUNT(*) FROM jp WHERE d @> ? AND d ? ' + Q + 'a' + Q,
    ['{"a":1}']);
  ChkInt('parametre tukendikten sonra ? operator kalir',
    StrToIntDef(R.Rows[0][0], -1), 1);

  // ---- DIZI JSON'u ? operatoru ile (PostgreSQL davranisi) ----
  sq.Exec('CREATE TABLE ja(id INTEGER PRIMARY KEY, d TEXT)');
  sq.Exec('INSERT INTO ja VALUES(1,' + Q + '["a","b"]' + Q + '),(2,' + Q + '["c"]' + Q + ')');
  ChkVal('dizi ? eleman olarak arar',
      'SELECT COUNT(*) FROM ja WHERE d ? ' + Q + 'a' + Q, 0, 0, '1');
  ChkVal('dizi @> eleman icerir',
      'SELECT COUNT(*) FROM ja WHERE d @> ' + Q + '"a"' + Q, 0, 0, '1');
  ChkVal('dizi @> dizi',
      'SELECT COUNT(*) FROM ja WHERE d @> ' + Q + '["c"]' + Q, 0, 0, '1');

  // ---- ANAHTAR SIRASI ONEMSIZDIR (JSON bir sozluktur) ----
  // Ic ice nesnelerde ayni veri farkli sirada yazilabilir; icerme
  // KONUMLA degil ANAHTARLA eslesmelidir.
  sq.Exec('CREATE TABLE jo(id INTEGER PRIMARY KEY, d TEXT)');
  sq.Exec('INSERT INTO jo VALUES(1,' + Q + '{"adres":{"il":"Ankara","ilce":"Cankaya"}}' + Q + ')');
  sq.Exec('INSERT INTO jo VALUES(2,' + Q + '[{"adres":{"il":"Izmir","ilce":"Konak"}}]' + Q + ')');
  ChkVal('ayni veri farkli anahtar sirasi (ust duzey)',
      'SELECT COUNT(*) FROM jo WHERE d @> ' + Q + '{"adres":{"ilce":"Cankaya","il":"Ankara"}}' + Q, 0, 0, '1');
  ChkVal('dizi icinde farkli anahtar sirasi',
      'SELECT COUNT(*) FROM jo WHERE d @> ' + Q + '[{"adres":{"ilce":"Konak","il":"Izmir"}}]' + Q, 0, 0, '1');
  // YANLIS POZISYON KARSILASTIRMASI TUZAGI: R'in anahtari L'de YOKSA
  // sonuc FALSE olmali. Konumla karsilastiran bir motor "ilk degerler
  // ayni" diye TRUE donerebiliyor — bu kontrol tam olarak onu engelliyor.
  sq.Exec('CREATE TABLE jz(id INTEGER PRIMARY KEY, d TEXT)');
  sq.Exec('INSERT INTO jz VALUES(1,' + Q + '{"a":{"x":1},"b":{"x":1}}' + Q + ')');
  ChkVal('olmayan anahtar icin konum benzerligi YANLIS eslesme uretmemeli',
      'SELECT COUNT(*) FROM jz WHERE d @> ' + Q + '{"zzz":{"x":1}}' + Q, 0, 0, '0');
  ChkVal('olmayan anahtar ? ile de bulunmamali',
      'SELECT COUNT(*) FROM jz WHERE d ? ' + Q + 'zzz' + Q, 0, 0, '0');
end;

procedure T09p_SlowQuery;
// F-21: YAVAS SORGU TESPITI — sure olcumu + kayit + raporlama
var
  n0, n1: Integer;
  n0s: TStrArray;
  n0t: string;
begin
  Grp('Yavas Sorgu (F-21)');
  UseDir('slow');
  sq.Exec('CREATE TABLE s1(id INTEGER PRIMARY KEY, a INTEGER, b TEXT)');
  sq.Exec('INSERT INTO s1 VALUES(1,10,' + Q + 'x' + Q + '),(2,20,' + Q + 'y' + Q + '),' +
          '(3,30,' + Q + 'z' + Q + '),(4,40,' + Q + 'w' + Q + '),(5,50,' + Q + 'v' + Q + ')');

  // ---- varsayilan: KAPALI ----
  ChkInt('varsayilan esik -1 (kapali)', sq.SlowThresholdMs, -1);
  ChkInt('varsayilan kayit sayisi 0', sq.SlowQueryCount, 0);

  // ---- sure her cumlede olculur (kayit kapaliyken de) ----
  sq.Exec('SELECT COUNT(*) FROM s1');
  if sq.LastElapsedMs >= 0 then Ok('sure olculdu', IntToStr(sq.LastElapsedMs) + ' ms')
    else No('sure olculdu', 'negatif');

  // ---- 0 esigi: HER cumle kaydedilir (deterministik; sure 0 ms olsa bile)
  sq.Exec('SET SLOW_QUERY_MS = 0');
  ChkInt('esik 0 = her cumle', sq.SlowThresholdMs, 0);
  sq.ClearSlow;   // API ile temizle (programatik yol)
  ChkInt('ClearSlow sonrasi bos', sq.SlowQueryCount, 0);

  sq.Exec('SELECT id FROM s1 WHERE a = 20');
  ChkInt('yavas sorgu kaydedildi', sq.SlowQueryCount, 1);
  R := sq.Exec('SHOW SLOW QUERIES');
  ChkInt('SHOW SLOW QUERIES 4 alan', Length(R.Fields), 4);
  ChkInt('SHOW SLOW QUERIES 1 kayit', Length(R.Rows), 1);
  ChkVal('sorgu metni kaydedildi', 'SHOW SLOW QUERIES', 0, 3, 'SELECT id FROM s1 WHERE a = 20');
  ChkVal('satir sayisi kaydedildi', 'SHOW SLOW QUERIES', 0, 1, '1');
  if TryStrToInt(R.Rows[0][0], n1) then Ok('sure alani sayisal', R.Rows[0][0])
    else No('sure alani sayisal', '' + R.Rows[0][0] + '');

  // ---- halka tampon: en ESKI kayit dusurulur ----
  // 6 kayit, tampon 3. Dogru halka {4,5,6} korur. Halka bozulup
  // "her zaman ilk kaydi ez" olsaydi {2,3,6} kalirdi — yani 4 ve 5
  // KAYBOLURDU. Test bu ayrimi yapabilmek icin 6 kayit yazar.
  sq.Exec('SET MAX_SLOW_ENTRIES = 3');
  sq.Exec('SET SLOW_QUERY_MS = 0');
  sq.ClearSlow;
  sq.Exec('SELECT 1 FROM s1');
  sq.Exec('SELECT 2 FROM s1');
  sq.Exec('SELECT 3 FROM s1');
  sq.Exec('SELECT 4 FROM s1');
  sq.Exec('SELECT 5 FROM s1');
  sq.Exec('SELECT 6 FROM s1');
  ChkInt('halka tampon sinirini uygular', sq.SlowQueryCount, 3);
  R := sq.Exec('SHOW SLOW QUERIES');
  n0t := R.Rows[0][3] + R.Rows[1][3] + R.Rows[2][3];
  // en uc eski kayit dusmus olmali
  if (Pos('SELECT 1 FROM s1', n0t) = 0) and (Pos('SELECT 2 FROM s1', n0t) = 0) then
    Ok('halka: en eski kayitlar dusmus', '')
  else
    No('halka: en eski kayitlar dusmus', n0t);
  // en yeni uc kayit duruyor olmali
  if (Pos('SELECT 4 FROM s1', n0t) > 0) and (Pos('SELECT 5 FROM s1', n0t) > 0) and
     (Pos('SELECT 6 FROM s1', n0t) > 0) then
    Ok('halka: en yeni kayitlar duruyor', '')
  else
    No('halka: en yeni kayitlar duruyor', n0t);

  // ---- yavas bir sorgu gercekten olculuyor mu? ----
  // 400 satirlik tablo x kendisi = 160.000 satir; 1 ms esigini asar.
  // (Kucuk tablolarla denendi: gercekten 0 ms okunuyor — yavas sorgu
  //  tespitinin ise yaramaz olmamasi icin olcumun >0 ms gormesi gerekir.)
  sq.Exec('CREATE TABLE big(id INTEGER PRIMARY KEY, v INTEGER)');
  // toplu ekleme: TEK transaction icinde 400 ayri INSERT (tek fsync)
  SetLength(n0s, 402);
  n0s[0] := 'BEGIN';
  for n1 := 1 to 400 do
    n0s[n1] := 'INSERT INTO big VALUES(' + IntToStr(n1) + ',' + IntToStr(n1) + ')';
  n0s[401] := 'COMMIT';
  sq.ExecAll(n0s);
  ChkVal('400 satir eklendi', 'SELECT COUNT(*) FROM big', 0, 0, '400');
  sq.Exec('SET MAX_SLOW_ENTRIES = 20');
  sq.Exec('SET SLOW_QUERY_MS = 0');
  sq.ClearSlow;
  sq.Exec('SELECT COUNT(*) FROM big a CROSS JOIN big b');
  Ok('agir sorgu olculdu', IntToStr(sq.LastElapsedMs) + ' ms');
  // Windows'ta olcum ~1 ms duyarliliklidir; agir CROSS JOIN esigi asmali
{$IFDEF MSWINDOWS}
  if sq.LastElapsedMs >= 1 then Ok('agir sorgu 1 ms+ olculdu', IntToStr(sq.LastElapsedMs) + ' ms')
    else No('agir sorgu 1 ms+ olculdu', 'olcum ' + IntToStr(sq.LastElapsedMs) + ' ms');
{$ELSE}
  Ok('agir sorgu 1 ms+ olculdu (diger platformda >= 0 yeterli)', IntToStr(sq.LastElapsedMs) + ' ms');
{$ENDIF}
  ChkInt('agir sorgu kaydedildi', sq.SlowQueryCount, 1);
  R := sq.Exec('SHOW SLOW QUERIES');
  if TryStrToInt(R.Rows[0][0], n1) then Ok('kayit suresi sayisal', R.Rows[0][0])
    else No('kayit suresi sayisal', R.Rows[0][0]);

  // ---- ESIG FILTRESI: pozitif esik gercekten uygulanir ----
  // Cok yuksek esik (1 saat): hicbir sorgu kaydedilmemeli
  sq.Exec('SET SLOW_QUERY_MS = 3600000');
  sq.ClearSlow;
  sq.Exec('SELECT COUNT(*) FROM big a CROSS JOIN big b');   // ~30 ms
  ChkInt('cok yuksek esik -> kayit yok', sq.SlowQueryCount, 0);
  // Dusuk esik (1 ms): ayni sorgu KAYDEDILMELI
  sq.Exec('SET SLOW_QUERY_MS = 1');
  sq.ClearSlow;
  sq.Exec('SELECT COUNT(*) FROM big a CROSS JOIN big b');
  ChkInt('dusuk esik -> kayit var', sq.SlowQueryCount, 1);
  R := sq.Exec('SHOW SLOW QUERIES');
  if TryStrToInt(R.Rows[0][0], n1) then
  begin
    if n1 >= 1 then Ok('kayit suresi esigi gecer', R.Rows[0][0])
      else No('kayit suresi esigi gecer', R.Rows[0][0]);
  end
  else No('kayit suresi esigi gecer', R.Rows[0][0]);
  // Esigin ALTINDA kalan hizli bir cumle kaydedilmemeli
  sq.ClearSlow;
  sq.Exec('SET SLOW_QUERY_MS = 60000');   // 1 dakika
  sq.Exec('SELECT 1 FROM s1 WHERE id = 1');
  ChkInt('esig alti hizli cumle kaydedilmez', sq.SlowQueryCount, 0);
  sq.Exec('SET SLOW_QUERY_MS = 0');

  // ---- esik kapatilince yeni kayit olusmaz ----
  sq.Exec('SET SLOW_QUERY_MS = -1');
  n0 := sq.SlowQueryCount;
  sq.Exec('SELECT 1 FROM s1');
  ChkInt('esik kapali -> yeni kayit yok', sq.SlowQueryCount, n0);

  // ---- SET hatalari ----
  ChkErr('bilinmeyen SET ayari', 'SET BILINMEYEN_A = 1');

  // ---- DDL/DML de olculur ----
  sq.Exec('SET SLOW_QUERY_MS = 0');
  sq.ClearSlow;
  sq.Exec('CREATE TABLE s2(id INTEGER PRIMARY KEY)');
  ChkInt('DDL de kaydedilir', sq.SlowQueryCount, 1);
  ChkVal('DDL kaydi', 'SHOW SLOW QUERIES', 0, 3, 'CREATE TABLE s2(id INTEGER PRIMARY KEY)');
end;

procedure T09o_CoveringIndex;
// F-19: COVERING INDEX — "CREATE INDEX ix ON t(a) INCLUDE (b, c)"
begin
  Grp('Covering Index (F-19)');
  UseDir('cidx');
  sq.Exec('CREATE TABLE ci(id INTEGER PRIMARY KEY, a INTEGER, b TEXT, c INTEGER)');
  sq.Exec('INSERT INTO ci VALUES(1,10,' + Q + 'x' + Q + ',100),(2,20,' + Q + 'y' + Q + ',200),' +
          '(3,30,' + Q + 'z' + Q + ',300),(4,NULL,' + Q + 'w' + Q + ',NULL)');

  // ---- tanim + sema ----
  sq.Exec('CREATE INDEX ix_a ON ci(a) INCLUDE (b, c)');
  R := sq.Exec('SHOW INDEXES FROM ci');
  ChkInt('covering indeks tanimli', Length(R.Rows), 1);
  ChkVal('covering indeks adi', 'SHOW INDEXES FROM ci', 0, 0, 'ix_a');
  ChkVal('covering anahtar kolon', 'SHOW INDEXES FROM ci', 0, 2, 'a');
  ChkVal('covering INCLUDE listesi', 'SHOW INDEXES FROM ci', 0, 8, 'b,c');
  ChkVal('covering turu (ifade degil)', 'SHOW INDEXES FROM ci', 0, 4, 'tek kolunlu');
  ChkVal('covering indeks kayit sayisi (NULL a dahil)', 'SHOW INDEXES FROM ci', 0, 6, '4');

  // ---- INCLUDE anahtar DEGILDIR: UNIQUE denetimine girmez ----
  // a tekrarli ama ix_a UNIQUE degil; sorun yok
  ChkVal('covering indeks arama', 'SELECT b FROM ci WHERE a = 20', 0, 0, 'y');
  // INCLUDE kolonu tek basina arama yolunu degistirmez
  ChkVal('INCLUDE kolonu ile tarama', 'SELECT COUNT(*) FROM ci WHERE c = 300', 0, 0, '1');
  ChkVal('NULL a sonucu bos', 'SELECT COUNT(*) FROM ci WHERE a = NULL', 0, 0, '0');

  // ---- INDEX-ONLY SCAN sonucu AYNI olmali ----
  ChkVal('index-only: a=30 satiri', 'SELECT b, c FROM ci WHERE a = 30', 0, 1, '300');
  ChkVal('index-only: tum satirlar', 'SELECT COUNT(*) FROM ci WHERE a >= 10', 0, 0, '3');
  ChkVal('index-only: NULL c aktarilir',
      'SELECT b FROM ci WHERE a = 10', 0, 0, 'x');

  // ---- EXPLAIN index-only scan bildirmeli ----
  ChkHas('EXPLAIN Index Only Scan', 'EXPLAIN SELECT b, c FROM ci WHERE a = 20', 'Index Only Scan');

  // ---- kapsama YETERSIZSE index-only OLMAZ ----
  sq.Exec('CREATE TABLE ci2(id INTEGER PRIMARY KEY, a INTEGER, b TEXT, d INTEGER)');
  sq.Exec('INSERT INTO ci2 VALUES(1,10,' + Q + 'x' + Q + ',1),(2,20,' + Q + 'y' + Q + ',2)');
  sq.Exec('CREATE INDEX ix_a2 ON ci2(a) INCLUDE (b)');   // d kapsamiyor
  ChkHas('EXPLAIN yetersiz kaplama -> Index Scan',
      'EXPLAIN SELECT b FROM ci2 WHERE a = 20', 'Index Scan using ix_a2');
  ChkVal('yetersiz kaplama sonucu dogru', 'SELECT b FROM ci2 WHERE a = 20', 0, 0, 'y');
  // PK kolonu zaten ayri bir indekste; kapsama denetimi kesin olmali
  ChkVal('yetersiz kaplama ile tum satirlar', 'SELECT COUNT(*) FROM ci2 WHERE a >= 10', 0, 0, '2');
  ChkVal('yetersiz kaplama: kaplanmayan kolon okunur',
      'SELECT d FROM ci2 WHERE a = 20', 0, 0, '2');

  // ---- yazma yolu ----
  sq.Exec('INSERT INTO ci VALUES(5,50,' + Q + 'v' + Q + ',500)');
  ChkVal('INSERT sonrasi covering 5 kayit', 'SHOW INDEXES FROM ci', 0, 6, '5');
  ChkVal('INSERT sonrasi index-only sonuc',
      'SELECT c FROM ci WHERE a = 50', 0, 0, '500');
  sq.Exec('UPDATE ci SET c = 555 WHERE id = 5');
  ChkVal('UPDATE INCLUDE kolonu sonrasi', 'SELECT c FROM ci WHERE a = 50', 0, 0, '555');
  sq.Exec('UPDATE ci SET a = 55 WHERE id = 5');
  ChkVal('UPDATE anahtar kolonu sonrasi (yeni anahtar)',
      'SELECT c FROM ci WHERE a = 55', 0, 0, '555');
  ChkVal('UPDATE anahtar kolonu sonrasi (eski anahtar yok)',
      'SELECT COUNT(*) FROM ci WHERE a = 50', 0, 0, '0');
  sq.Exec('DELETE FROM ci WHERE id = 5');
  ChkVal('DELETE sonrasi covering 4 kayit', 'SHOW INDEXES FROM ci', 0, 6, '4');

  // ---- INCLUDE hatalari ----
  ChkErr('INCLUDE ayni kolon iki kez',
      'CREATE INDEX ix_e1 ON ci(a) INCLUDE (b, b)');
  ChkErr('INCLUDE anahtar kolonla ayni',
      'CREATE INDEX ix_e2 ON ci(a) INCLUDE (a)');
  ChkErr('INCLUDE olmayan kolon',
      'CREATE INDEX ix_e3 ON ci(a) INCLUDE (yokboyle)');

  // ---- covering + partial + expression birlikte ----
  sq.Exec('CREATE TABLE ci3(id INTEGER PRIMARY KEY, ad TEXT, n INTEGER, et INTEGER)');
  sq.Exec('INSERT INTO ci3 VALUES(1,' + Q + 'Ali' + Q + ',10,1),(2,' + Q + 'Veli' + Q + ',20,2),' +
          '(3,' + Q + 'Zoe' + Q + ',30,3)');
  sq.Exec('CREATE INDEX ix_c3 ON ci3(n) INCLUDE (et) WHERE et > 1');
  ChkVal('covering+partial INCLUDE listesi', 'SHOW INDEXES FROM ci3', 0, 8, 'et');
  ChkVal('covering+partial kosul', 'SHOW INDEXES FROM ci3', 0, 5, '(et > 1)');
  ChkVal('covering+partial kayit sayisi (et>1)', 'SHOW INDEXES FROM ci3', 0, 6, '2');
  ChkVal('covering+partial arama', 'SELECT et FROM ci3 WHERE n = 30', 0, 0, '3');
  ChkVal('covering+partial disi satir yine bulunur',
      'SELECT et FROM ci3 WHERE n = 10', 0, 0, '1');

  // ---- DROP ----
  sq.Exec('DROP INDEX ix_a');
  ChkVal('DROP covering sonrasi arama', 'SELECT b FROM ci WHERE a = 20', 0, 0, 'y');
  ChkVal('DROP covering sonrasi tum satirlar',
      'SELECT COUNT(*) FROM ci WHERE a >= 10', 0, 0, '3');

  // ---- SEMA PERSISTANSI ----
  UseDir('cidx');
  ChkVal('reopen: INCLUDE korundu', 'SHOW INDEXES FROM ci3', 0, 8, 'et');
  ChkInt('reopen: DROP edilen indeks geri gelmedi',
      Length(sq.Exec('SHOW INDEXES FROM ci').Rows), 0);
  ChkVal('reopen: covering+partial korundu', 'SHOW INDEXES FROM ci3', 0, 8, 'et');
  ChkVal('reopen: covering+partial kosul korundu', 'SHOW INDEXES FROM ci3', 0, 5, '(et > 1)');
  ChkVal('reopen: kayit sayisi korundu', 'SHOW INDEXES FROM ci3', 0, 6, '2');
  ChkVal('reopen: index-only sonuc', 'SELECT c FROM ci WHERE a = 30', 0, 0, '300');
  sq.Exec('REINDEX');
  ChkVal('reopen: REINDEX sonrasi kayit sayisi', 'SHOW INDEXES FROM ci3', 0, 6, '2');
  ChkVal('reopen: index-only sonuc', 'SELECT et FROM ci3 WHERE n = 30', 0, 0, '3');
end;

procedure T09n_ExprIndex;
// F-18: EXPRESSION INDEX — "CREATE INDEX ix ON t(LOWER(ad))"
begin
  Grp('Expression Index (F-18)');
  UseDir('eidx');
  sq.Exec('CREATE TABLE ei(id INTEGER PRIMARY KEY, ad TEXT, n INTEGER, f REAL)');
  sq.Exec('INSERT INTO ei VALUES(1,' + Q + 'Ali' + Q + ',10,1.5),(2,' + Q + 'VELI' + Q + ',20,2.5),' +
          '(3,' + Q + 'Zoe' + Q + ',30,3.5),(4,' + Q + 'can' + Q + ',40,4.5),(5,NULL,50,5.5)');

  // ---- tanim + sema ----
  sq.Exec('CREATE INDEX ix_lower ON ei(LOWER(ad))');
  R := sq.Exec('SHOW INDEXES FROM ei');
  ChkInt('ifade indeksi tanimli', Length(R.Rows), 1);   // yalniz ix_lower
  ChkVal('ifade indeksi adi', 'SHOW INDEXES FROM ei', 0, 0, 'ix_lower');
  ChkVal('ifade indeksi ifadesi', 'SHOW INDEXES FROM ei', 0, 2, 'LOWER(ad)');
  ChkVal('ifade indeksi expr kolonu', 'SHOW INDEXES FROM ei', 0, 7, 'LOWER(ad)');
  ChkVal('ifade indeksi turu', 'SHOW INDEXES FROM ei', 0, 4, 'ifade');
  ChkVal('ifade indeksi ncols', 'SHOW INDEXES FROM ei', 0, 3, '1');
  // 5 satir, ama ad = NULL olan satir LOWER() = NULL -> indekslenmez
  ChkVal('ifade indeksi 4 kayit (NULL haric)', 'SHOW INDEXES FROM ei', 0, 6, '4');

  // ---- icerik: kucuk harfe cevrilmis anahtarlar ----
  ChkVal('ifade indeksi LOWER dogru',
      'SELECT ad FROM ei WHERE LOWER(ad) = ' + Q + 'ali' + Q, 0, 0, 'Ali');
  // Turkce kurali: LOWER('VELI') = 'velı' (noktasiz i). Noktali/noktasiz
  // ayrimi VDbTrLower'da yapilir; motor LOWER'da da ayni sonucu verir.
  ChkVal('ifade indeksi Turkce LOWER (noktasiz i)',
      'SELECT ad FROM ei WHERE LOWER(ad) = ' + Q + 'velı' + Q, 0, 0, 'VELI');
  ChkVal('ifade indeksi noktali I eslesmez',
      'SELECT COUNT(*) FROM ei WHERE LOWER(ad) = ' + Q + 'veli' + Q, 0, 0, '0');
  ChkVal('ifade indeksi LOWER kucuk harf de eslesir',
      'SELECT ad FROM ei WHERE LOWER(ad) = ' + Q + 'can' + Q, 0, 0, 'can');
  ChkVal('ifade indeksi LOWER yoksa bos',
      'SELECT COUNT(*) FROM ei WHERE LOWER(ad) = ' + Q + 'yok' + Q, 0, 0, '0');
  ChkVal('ifade indeksi NULL eslesmez',
      'SELECT COUNT(*) FROM ei WHERE LOWER(ad) = NULL', 0, 0, '0');
  // indeks kullanmasa da sonuc dogru olmali
  ChkVal('arama sonucu indeksle tutarli',
      'SELECT COUNT(*) FROM ei WHERE LOWER(ad) IN (' + Q + 'ali' + Q + ',' + Q + 'zoe' + Q + ')',
      0, 0, '2');

  // ---- UPPER ----
  sq.Exec('CREATE INDEX ix_upper ON ei(UPPER(ad))');
  ChkVal('UPPER indeksi ifadesi', 'SHOW INDEXES FROM ei', 1, 7, 'UPPER(ad)');
  ChkVal('UPPER indeksi 4 kayit', 'SHOW INDEXES FROM ei', 1, 6, '4');
  ChkVal('UPPER ile arama (Turkce: Ali -> ALİ)', 'SELECT ad FROM ei WHERE UPPER(ad) = ' + Q + 'ALİ' + Q, 0, 0, 'Ali');

  // ---- TRIM ----
  sq.Exec('CREATE INDEX ix_trim ON ei(TRIM(ad))');
  ChkVal('TRIM indeksi 4 kayit', 'SHOW INDEXES FROM ei', 2, 6, '4');
  ChkVal('TRIM ile arama', 'SELECT ad FROM ei WHERE TRIM(ad) = ' + Q + 'Zoe' + Q, 0, 0, 'Zoe');

  // ---- LENGTH (sayisal) ----
  sq.Exec('CREATE INDEX ix_len ON ei(LENGTH(ad))');
  ChkVal('LENGTH indeksi ifadesi', 'SHOW INDEXES FROM ei', 3, 7, 'LENGTH(ad)');
  ChkVal('LENGTH indeksi 4 kayit', 'SHOW INDEXES FROM ei', 3, 6, '4');
  ChkVal('LENGTH ile arama (3 harf: Ali/Zoe/can)', 'SELECT COUNT(*) FROM ei WHERE LENGTH(ad) = 3', 0, 0, '3');
  ChkVal('LENGTH ile arama (4 harf)', 'SELECT COUNT(*) FROM ei WHERE LENGTH(ad) = 4', 0, 0, '1');

  // ---- aritmetik ifade (sayisal tip) ----
  sq.Exec('CREATE INDEX ix_n1 ON ei(n + 1)');
  ChkVal('aritmetik ifade indeksi', 'SHOW INDEXES FROM ei', 4, 7, '(n + 1)');
  ChkVal('aritmetik indeksi 5 kayit (n hep dolu)', 'SHOW INDEXES FROM ei', 4, 6, '5');
  ChkVal('aritmetik ifade ile arama', 'SELECT n FROM ei WHERE n + 1 = 21', 0, 0, '20');
  sq.Exec('CREATE INDEX ix_abs ON ei(ABS(f - 3.5))');
  ChkVal('ABS ifade indeksi', 'SHOW INDEXES FROM ei', 5, 7, 'ABS((f - 3.5))');
  ChkVal('ABS indeksi 5 kayit', 'SHOW INDEXES FROM ei', 5, 6, '5');

  // ---- yazma yolu ----
  sq.Exec('INSERT INTO ei VALUES(6,' + Q + 'AYSE' + Q + ',60,6.5)');
  ChkVal('INSERT sonrasi LOWER indeksi 5', 'SHOW INDEXES FROM ei', 0, 6, '5');
  ChkVal('INSERT sonrasi UPPER indeksi 5', 'SHOW INDEXES FROM ei', 1, 6, '5');
  ChkVal('INSERT sonrasi LENGTH indeksi 5', 'SHOW INDEXES FROM ei', 3, 6, '5');
  ChkVal('INSERT sonrasi aritmetik indeksi 6', 'SHOW INDEXES FROM ei', 4, 6, '6');
  ChkVal('yeni satir ifade ile bulunur',
      'SELECT ad FROM ei WHERE LOWER(ad) = ' + Q + 'ayse' + Q, 0, 0, 'AYSE');
  sq.Exec('DELETE FROM ei WHERE id = 6');
  ChkVal('DELETE sonrasi LOWER indeksi 4', 'SHOW INDEXES FROM ei', 0, 6, '4');
  // ifadeyi degistiren UPDATE
  sq.Exec('UPDATE ei SET ad = ' + Q + 'Yeni' + Q + ' WHERE id = 1');
  ChkVal('UPDATE sonrasi eski anahtar gitmis',
      'SELECT COUNT(*) FROM ei WHERE LOWER(ad) = ' + Q + 'ali' + Q, 0, 0, '0');
  ChkVal('UPDATE sonrasi yeni anahtar var',
      'SELECT ad FROM ei WHERE LOWER(ad) = ' + Q + 'yeni' + Q, 0, 0, 'Yeni');

  // ---- UNIQUE ifade indeksi ----
  sq.Exec('CREATE UNIQUE INDEX ux_ei ON ei(LOWER(ad))');
  // 'CAN' -> LOWER = 'can'; id=4 satiri zaten 'can' -> ihlal
  ChkErr('ifade UNIQUE ihlali',
      'INSERT INTO ei VALUES(7,' + Q + 'CAN' + Q + ',70,7.5)');
  ChkVal('ifade UNIQUE farkli ad serbest',
      'SELECT COUNT(*) FROM ei WHERE LOWER(ad) = ' + Q + 'can' + Q, 0, 0, '1');

  // ---- normal indeksler hala calisiyor ----
  sq.Exec('CREATE INDEX ix_n ON ei(n)');
  ChkVal('normal indeks sonrasi', 'SHOW INDEXES FROM ei', Length(sq.Exec('SHOW INDEXES FROM ei').Rows) - 1, 7, '');
  ChkVal('normal indeks ile arama', 'SELECT n FROM ei WHERE n = 30', 0, 0, '30');
  ChkVal('tablo satir sayisi 5', 'SELECT COUNT(*) FROM ei', 0, 0, '5');
  ChkVal('normal indeks nentries = 5', 'SHOW INDEXES FROM ei', 7, 6, '5');
  ChkVal('normal indeks bittikten sonra ifade yok', 'SHOW INDEXES FROM ei', 7, 7, '');

  // ---- DROP ----
  sq.Exec('DROP INDEX ix_lower');
  ChkVal('DROP ifade indeksi sonrasi arama', 'SELECT ad FROM ei WHERE LOWER(ad) = ' + Q + 'yeni' + Q, 0, 0, 'Yeni');

  // ---- SEMA PERSISTANSI ----
  UseDir('eidx');
  // DROP ix_lower sonrasi sira kaydi: ix_upper(0), ix_trim(1), ix_len(2),
  // ix_n1(3), ix_abs(4), ux_ei(5), ix_n(6)
  ChkVal('reopen: ifade korundu', 'SHOW INDEXES FROM ei', 0, 7, 'UPPER(ad)');
  ChkVal('reopen: aritmetik ifade korundu', 'SHOW INDEXES FROM ei', 3, 7, '(n + 1)');
  ChkVal('reopen: REINDEX sonrasi kayit sayisi', 'SHOW INDEXES FROM ei', 0, 6, '4');
  ChkVal('reopen: UNIQUE ifade hala zorlanir',
      'SELECT COUNT(*) FROM ei WHERE LOWER(ad) = ' + Q + 'can' + Q, 0, 0, '1');
end;

procedure T09m_PartialIndex;
// F-17: PARTIAL INDEX — "CREATE INDEX ix ON t(c) WHERE <kosul>"
begin
  Grp('Partial Index (F-17)');
  UseDir('pidx');
  sq.Exec('CREATE TABLE pi(id INTEGER PRIMARY KEY, ad TEXT, v INTEGER, aktif INTEGER)');
  sq.Exec('INSERT INTO pi VALUES(1,' + Q + 'Ali' + Q + ',10,1),(2,' + Q + 'Veli' + Q + ',20,0),' +
          '(3,' + Q + 'Zoe' + Q + ',30,1),(4,' + Q + 'Can' + Q + ',40,1),(5,' + Q + 'Eda' + Q + ',50,0)');

  // ---- tanim + sema korumasi ----
  sq.Exec('CREATE INDEX ix_aktif ON pi(v) WHERE aktif = 1');
  R := sq.Exec('SHOW INDEXES FROM pi');
  ChkInt('partial indeks tanimli', Length(R.Rows), 1);   // yalniz ix_aktif
  ChkVal('partial indeks adi', 'SHOW INDEXES FROM pi', 0, 0, 'ix_aktif');
  ChkVal('partial indeks kosulu saklandi', 'SHOW INDEXES FROM pi', 0, 5, '(aktif = 1)');
  // Indeks icerigi olusturuldugu ANDAN: tablo 5 satir, aktif=1 olan 3 satir
  ChkVal('partial indeks kayit sayisi = 3', 'SHOW INDEXES FROM pi', 0, 6, '3');
  // REINDEX yeniden kurar -> ayni sonuc (BuildOneIndex filtresi)
  sq.Exec('REINDEX');
  ChkVal('REINDEX sonrasi kayit sayisi = 3', 'SHOW INDEXES FROM pi', 0, 6, '3');
  ChkVal('tablo satir sayisi = 5', 'SELECT COUNT(*) FROM pi', 0, 0, '5');
  // normal indeks (aktif) tum satirlari kapsar -> 5
  sq.Exec('CREATE INDEX ix_tam ON pi(aktif)');
  ChkVal('normal indeks kayit sayisi = 5', 'SHOW INDEXES FROM pi', 1, 6, '5');
  
  // ---- SORGULAR DOGRU KALMALI (indeks kullanimindan bagimsiz) ----
  ChkVal('WHERE v = 30 (partial indeksli kolon)', 'SELECT ad FROM pi WHERE v = 30', 0, 0, 'Zoe');
  ChkVal('WHERE v = 50 (indeksde olmayan satir)', 'SELECT ad FROM pi WHERE v = 50', 0, 0, 'Eda');
  ChkVal('WHERE v = 10 (aktif satir)', 'SELECT ad FROM pi WHERE v = 10', 0, 0, 'Ali');
  ChkVal('partial indeks tam tarama sayisi', 'SELECT COUNT(*) FROM pi WHERE v >= 10', 0, 0, '5');
  ChkVal('WHERE v > 25 ve aktif', 'SELECT COUNT(*) FROM pi WHERE v > 25 AND aktif = 1', 0, 0, '2');

  // ---- yazma yolu: kosulu saglamayan satir indekslenmez ----
  // v=50 (aktif=0) iken sorgu yine dogru sonuc vermeli
  sq.Exec('UPDATE pi SET aktif = 1 WHERE id = 5');   // artik indekslenmeli
  ChkVal('UPDATE sonrasi indekslenen satir',
      'SELECT ad FROM pi WHERE v = 50 AND aktif = 1', 0, 0, 'Eda');
  sq.Exec('UPDATE pi SET aktif = 0 WHERE id = 5');   // indeksden cikmali
  ChkVal('UPDATE sonrasi indeksden cikan satir',
      'SELECT ad FROM pi WHERE v = 50', 0, 0, 'Eda');
  ChkVal('aktif=0 filtresi', 'SELECT COUNT(*) FROM pi WHERE v = 50 AND aktif = 0', 0, 0, '1');
  // yazma yolu sayimlari: 3 (aktif) + 1 = 4, sonra -1 = 3
  ChkVal('UPDATE sonrasi indeks 3 kayit', 'SHOW INDEXES FROM pi', 0, 6, '3');
  ChkVal('normal indeks 5 kayit', 'SHOW INDEXES FROM pi', 1, 6, '5');
  // INSERT: aktif=0 olan satir indekslenmemeli
  sq.Exec('INSERT INTO pi VALUES(6,' + Q + 'Fatma' + Q + ',60,0)');
  ChkVal('INSERT (aktif=0) indekse girmez', 'SHOW INDEXES FROM pi', 0, 6, '3');
  ChkVal('INSERT sonrasi normal indeks 6 kayit', 'SHOW INDEXES FROM pi', 1, 6, '6');
  sq.Exec('INSERT INTO pi VALUES(7,' + Q + 'Deniz' + Q + ',70,1)');
  ChkVal('INSERT (aktif=1) indekse girer', 'SHOW INDEXES FROM pi', 0, 6, '4');
  // DELETE: indeksden duser
  sq.Exec('DELETE FROM pi WHERE id = 7');
  ChkVal('DELETE sonrasi indeks 3 kayit', 'SHOW INDEXES FROM pi', 0, 6, '3');
  // UPDATE predicate'yi degistirince satir girer/cikar
  sq.Exec('UPDATE pi SET aktif = 1 WHERE id = 6');
  ChkVal('UPDATE predicate aktif etkisi', 'SHOW INDEXES FROM pi', 0, 6, '4');

  // ---- coklu kosul (AND) ----
  sq.Exec('CREATE INDEX ix_ikili ON pi(v) WHERE aktif = 1 AND v > 25');
  R := sq.Exec('SHOW INDEXES FROM pi');
  ChkInt('ikinci partial indeks', Length(R.Rows), 3);
  ChkVal('coklu kosul saklandi',
      'SHOW INDEXES FROM pi', 2, 5, '((aktif = 1) AND (v > 25))');
  ChkVal('coklu kosul: v=30 (aktif, >25)',
      'SELECT ad FROM pi WHERE v = 30 AND aktif = 1', 0, 0, 'Zoe');
  ChkVal('coklu kosul: v=10 (aktif ama <=25 yok)',
      'SELECT COUNT(*) FROM pi WHERE v = 10 AND aktif = 1', 0, 0, '1');
  // aktif=1 ve v>25 -> id 3,4 = 2 satir
  ChkVal('coklu kosul indeksi 3 kayit', 'SHOW INDEXES FROM pi', 2, 6, '3');

  // ---- metin sabitli kosul ----
  sq.Exec('CREATE TABLE pi2(id INTEGER PRIMARY KEY, sehir TEXT, n INTEGER)');
  sq.Exec('INSERT INTO pi2 VALUES(1,' + Q + 'Istanbul' + Q + ',10),(2,' + Q + 'Ankara' + Q + ',20),(3,' + Q + 'Izmir' + Q + ',30)');
  sq.Exec('CREATE INDEX ix_sehir ON pi2(n) WHERE sehir = ' + Q + 'Istanbul' + Q);
  ChkVal('metin kosulu saklandi',
      'SHOW INDEXES FROM pi2', 0, 5, '(sehir = ' + Q + 'Istanbul' + Q + ')');
  ChkVal('metin kosulu ile sorgu', 'SELECT sehir FROM pi2 WHERE n = 10', 0, 0, 'Istanbul');
  ChkVal('metin kosulu disi satir', 'SELECT sehir FROM pi2 WHERE n = 20', 0, 0, 'Ankara');

  // ---- bilesik (cok kolonlu) partial indeks ----
  sq.Exec('CREATE INDEX ix_cok ON pi(aktif, v) WHERE v >= 30');
  R := sq.Exec('SHOW INDEXES FROM pi');
  ChkInt('cok kolonlu partial indeks', Length(R.Rows), 4);
  ChkVal('cok kolonlu partial kosul',
      'SHOW INDEXES FROM pi', 3, 5, '(v >= 30)');
  ChkVal('cok kolonlu + WHERE birlik',
      'SELECT COUNT(*) FROM pi WHERE aktif = 1 AND v >= 30', 0, 0, '3');

  // ---- DROP INDEX ----
  sq.Exec('DROP INDEX ix_cok');
  R := sq.Exec('SHOW INDEXES FROM pi');
  ChkInt('DROP partial INDEX', Length(R.Rows), 3);
  ChkVal('droptan sonra sorgu bozulmaz',
      'SELECT COUNT(*) FROM pi WHERE v >= 30', 0, 0, '4');   // id 3,4,5,6

  // ---- UNIQUE + partial ----
  sq.Exec('CREATE UNIQUE INDEX ux_pi ON pi(ad) WHERE aktif = 1');
  ChkErr('partial UNIQUE ihlali',
      'INSERT INTO pi VALUES(6,' + Q + 'Ali' + Q + ',99,1)');
  ChkVal('partial UNIQUE disinda ayni ad serbest',
      'SELECT COUNT(*) FROM pi WHERE ad = ' + Q + 'Ali' + Q, 0, 0, '1');

  // ---- SEMA PERSISTANSI (dosya yeniden acilir) ----
  UseDir('pidx');   // ayni klasoru yeniden ac
  ChkVal('reopen: partial kosul korundu',
      'SHOW INDEXES FROM pi', 0, 5, '(aktif = 1)');
  ChkVal('reopen: kayan kosul korundu',
      'SHOW INDEXES FROM pi', 2, 5, '((aktif = 1) AND (v > 25))');
  ChkVal('reopen: metin kosulu korundu',
      'SHOW INDEXES FROM pi2', 0, 5, '(sehir = ' + Q + 'Istanbul' + Q + ')');
  ChkVal('reopen: REINDEX sonrasi kayit sayisi', 'SHOW INDEXES FROM pi', 0, 6, '4');
  ChkVal('reopen: sorgu sonucu ayni',
      'SELECT COUNT(*) FROM pi WHERE aktif = 1 AND v >= 30', 0, 0, '3');
  ChkErr('reopen: partial UNIQUE hala zorlanir',
      'INSERT INTO pi VALUES(8,' + Q + 'Ali' + Q + ',98,1)');
end;

procedure T09l_Explain;
// F-20: EXPLAIN / EXPLAIN ANALYZE — sorgu plani raporu.
begin
  Grp('EXPLAIN (F-20)');
  UseDir('explain');
  sq.Exec('CREATE TABLE ex(id INTEGER PRIMARY KEY, ad TEXT, v INTEGER)');
  sq.Exec('INSERT INTO ex VALUES(1,' + Q + 'Ali' + Q + ',10),(2,' + Q + 'Veli' + Q + ',20),(3,' + Q + 'Zoe' + Q + ',30)');
  sq.Exec('CREATE INDEX ix_v ON ex(v)');
  // temel EXPLAIN — 1 satir (Seq Scan)
  Chk('EXPLAIN SELECT (plan var)', 'EXPLAIN SELECT * FROM ex', 1);
  ChkHas('EXPLAIN Seq Scan icerigi', 'EXPLAIN SELECT * FROM ex', 'Seq Scan');
  // WHERE ile Seq Scan + Filter
  Chk('EXPLAIN WHERE (plan)', 'EXPLAIN SELECT * FROM ex WHERE ad = ' + Q + 'Ali' + Q, 1);
  // PK nokta aramasi -> Index Scan
  Chk('EXPLAIN PK (Index Scan)', 'EXPLAIN SELECT * FROM ex WHERE id = 1', 1);
  ChkHas('EXPLAIN PK icerigi', 'EXPLAIN SELECT * FROM ex WHERE id = 1', '_pkey');
  // indeks kullanimi
  Chk('EXPLAIN indeks (Index Scan)', 'EXPLAIN SELECT * FROM ex WHERE v = 10', 1);
  ChkHas('EXPLAIN indeks adi icerigi', 'EXPLAIN SELECT * FROM ex WHERE v = 10', 'ix_v');
  ChkHas('EXPLAIN indeks (PK olmayan WHERE)',
      'EXPLAIN SELECT * FROM ex WHERE v > 5', 'ix_v');
  // JOIN
  Chk('EXPLAIN JOIN (plan)', 'EXPLAIN SELECT * FROM ex a JOIN ex b ON a.id = b.id', 3);
  // GROUP BY / aggregate: Seq Scan + Aggregate + Group = 3
  Chk('EXPLAIN GROUP BY (3)', 'EXPLAIN SELECT ad, COUNT(*) FROM ex GROUP BY ad', 3);
  // ORDER BY
  Chk('EXPLAIN ORDER BY (plan)', 'EXPLAIN SELECT * FROM ex ORDER BY v', 2);
  // LIMIT
  Chk('EXPLAIN LIMIT (plan)', 'EXPLAIN SELECT * FROM ex ORDER BY v LIMIT 2', 3);
  // EXPLAIN DML
  Chk('EXPLAIN INSERT (plan)', 'EXPLAIN INSERT INTO ex VALUES(9,' + Q + 'X' + Q + ',90)', 1);
  Chk('EXPLAIN UPDATE (plan)', 'EXPLAIN UPDATE ex SET v = 1 WHERE id = 9', 1);
  Chk('EXPLAIN DELETE (plan)', 'EXPLAIN DELETE FROM ex WHERE id = 9', 1);
  // EXPLAIN ANALYZE — calistirir: plan (1) + Actual Rows + Execution Time = 3
  Chk('EXPLAIN ANALYZE (calistirir)', 'EXPLAIN ANALYZE SELECT * FROM ex WHERE id = 1', 3);
  // EXPLAIN cumleyi CALISTIRMADIGI dogrulanir: veri degismemis olmali
  ChkVal('EXPLAIN veri degistirmedi',
      'SELECT COUNT(*) FROM ex WHERE id = 9', 0, 0, '0');
  // gecersiz ic cumle
  ChkErr('EXPLAIN sonrasi tablo (hata)', 'EXPLAIN ex');
end;

procedure T09k_Filter;
// F-16: FILTER (WHERE ...) — aggregate'e satir filtresi.
begin
  Grp('FILTER (F-16)');
  UseDir('filter');
  sq.Exec('CREATE TABLE fl(id INTEGER PRIMARY KEY, ad TEXT, v INTEGER, p INTEGER)');
  sq.Exec('INSERT INTO fl VALUES(1,' + Q + 'Ali' + Q + ',10,1),(2,' + Q + 'Veli' + Q + ',20,1),' +
          '(3,' + Q + 'Zoe' + Q + ',30,2),(4,' + Q + 'Can' + Q + ',40,2),(5,' + Q + 'Eda' + Q + ',NULL,2)');
  // temel FILTER
  ChkVal('COUNT(*) FILTER (p=1) = 2',
      'SELECT COUNT(*) FILTER (WHERE p = 1) FROM fl', 0, 0, '2');
  ChkVal('COUNT(*) = 5 (filtresiz)',
      'SELECT COUNT(*) FROM fl', 0, 0, '5');
  ChkVal('COUNT(v) FILTER (p=2) = 2',
      'SELECT COUNT(v) FILTER (WHERE p = 2) FROM fl', 0, 0, '2');
  ChkVal('SUM(v) FILTER (p=1) = 30',
      'SELECT SUM(v) FILTER (WHERE p = 1) FROM fl', 0, 0, '30');
  ChkVal('AVG(v) FILTER (p=1) = 15',
      'SELECT AVG(v) FILTER (WHERE p = 1) FROM fl', 0, 0, '15');
  ChkVal('MIN(v) FILTER (p=2) = 30',
      'SELECT MIN(v) FILTER (WHERE p = 2) FROM fl', 0, 0, '30');
  ChkVal('MAX(v) FILTER (p=2) = 40',
      'SELECT MAX(v) FILTER (WHERE p = 2) FROM fl', 0, 0, '40');
  // filtre + DISTINCT birlikte: id 1..4, v>15 olanlar id=2(p=1),3(p=2),4(p=2)
  // -> p degerleri {1,2} -> COUNT(DISTINCT) = 2
  ChkVal('COUNT(DISTINCT p) FILTER (v>15) = 2',
      'SELECT COUNT(DISTINCT p) FILTER (WHERE v > 15) FROM fl WHERE id IN (1,2,3,4)', 0, 0, '2');
  // GROUP BY + FILTER
  Chk('GROUP BY p + FILTER (2)',
      'SELECT p FROM fl GROUP BY p HAVING SUM(v) FILTER (WHERE v > 15) > 0', 2);
  ChkVal('GROUP BY p FILTER deger (p=1: 30)',
      'SELECT p, SUM(v) FILTER (WHERE p = 1) FROM fl GROUP BY p ORDER BY p', 0, 1, '30');
  // filtre sonuc bos -> NULL (aggregate bos kume)
  ChkVal('FILIRE sonuc yok -> NULL',
      'SELECT SUM(v) FILTER (WHERE p = 99) FROM fl', 0, 0, '');
  ChkVal('FILTER COUNT sonuc yok -> 0',
      'SELECT COUNT(*) FILTER (WHERE p = 99) FROM fl', 0, 0, '0');
  // non-aggregate fonksiyonda hata
  ChkErr('FILTER aggregate disinda (hata)',
      'SELECT UPPER(ad) FILTER (WHERE p = 1) FROM fl');
  // OVER ile birlikte kullanilamaz
  ChkErr('FILTER + OVER (hata)',
      'SELECT SUM(v) FILTER (WHERE p = 1) OVER () FROM fl');
end;

procedure T09j_AggDistinct;
begin
  Grp('COUNT/SUM/AVG/MIN/MAX(DISTINCT) + STRING_AGG + PERCENTILE (F-11/F-14/F-15)');
  UseDir('agg2');
  sq.Exec('CREATE TABLE ag(id INTEGER PRIMARY KEY, ad TEXT, v INTEGER)');
  sq.Exec('INSERT INTO ag VALUES(1,' + Q + 'Ali' + Q + ',10),(2,' + Q + 'Veli' + Q + ',20),' +
          '(3,' + Q + 'Zoe' + Q + ',10),(4,' + Q + 'Can' + Q + ',30),(5,' + Q + 'Eda' + Q + ',20),' +
          '(6,NULL,NULL)');
  // ---- F-11: COUNT(DISTINCT) ----
  ChkVal('COUNT(DISTINCT v) = 3',
      'SELECT COUNT(DISTINCT v) FROM ag', 0, 0, '3');
  ChkVal('COUNT(v) = 5 (NULL sayilmaz)',
      'SELECT COUNT(v) FROM ag', 0, 0, '5');
  ChkVal('COUNT(*) = 6',
      'SELECT COUNT(*) FROM ag', 0, 0, '6');
  ChkVal('COUNT(DISTINCT ad) = 5',
      'SELECT COUNT(DISTINCT ad) FROM ag', 0, 0, '5');
  // SUM DISTINCT: 10+20+30 = 60 (tekrarlar ciftlenmez)
  ChkVal('SUM(DISTINCT v) = 60',
      'SELECT SUM(DISTINCT v) FROM ag', 0, 0, '60');
  // SUM (tekrarli): 10+20+10+30+20 = 90
  ChkVal('SUM(v) = 90',
      'SELECT SUM(v) FROM ag', 0, 0, '90');
  // AVG DISTINCT: (10+20+30)/3 = 20
  ChkVal('AVG(DISTINCT v) = 20',
      'SELECT AVG(DISTINCT v) FROM ag', 0, 0, '20');
  // MIN/MAX DISTINCT ayni sonuc
  ChkVal('MIN(DISTINCT v) = 10',
      'SELECT MIN(DISTINCT v) FROM ag', 0, 0, '10');
  ChkVal('MAX(DISTINCT v) = 30',
      'SELECT MAX(DISTINCT v) FROM ag', 0, 0, '30');
  // GROUP BY + DISTINCT: her ad tekil
  Chk('GROUP BY + COUNT(DISTINCT) (5)',
      'SELECT ad, COUNT(DISTINCT v) FROM ag WHERE ad IS NOT NULL GROUP BY ad', 5);
  // HAVING + COUNT(DISTINCT): her ad TEK deger iceriyor -> hicbiri > 1 degil -> 0
  Chk('HAVING COUNT(DISTINCT v) > 1 (0)',
      'SELECT ad FROM ag WHERE ad IS NOT NULL GROUP BY ad HAVING COUNT(DISTINCT v) > 1', 0);
  Chk('HAVING COUNT(DISTINCT v) = 1 (5)',
      'SELECT ad FROM ag WHERE ad IS NOT NULL GROUP BY ad HAVING COUNT(DISTINCT v) = 1', 5);
  // ---- F-14: STRING_AGG ----
  // Not: STRING_AGG cikti sirasi tablo satir SIRASINA baglidir (index
  // yolu satirlari farkli sirada dondurebilir). Bu yuzden tek satirlik
  // ya da ORDER BY'siz deterministik durumlar test edilir.
  ChkVal('STRING_AGG ozel ayirac',
      'SELECT STRING_AGG(ad, ' + Q + ' | ' + Q + ') FROM ag WHERE ad IS NOT NULL AND id <= 2', 0, 0, 'Ali | Veli');
  ChkVal('STRING_AGG tek satir',
      'SELECT STRING_AGG(ad, ' + Q + ',' + Q + ') FROM ag WHERE id = 1', 0, 0, 'Ali');
  // DISTINCT: v degerleri 10,20,10,30,20 (id=6 NULL)
  //   WHERE v <= 20 ile: 10,20,10,20 -> DISTINCT "10,20" = 5 karakter
  //                      DISTINCT'siz: "10,20,10,20" = 11 karakter
  ChkVal('STRING_AGG DISTINCT eler (5 karakter)',
      'SELECT LENGTH(STRING_AGG(DISTINCT v, ' + Q + ',' + Q + ')) FROM ag WHERE v <= 20', 0, 0, '5');
  ChkVal('STRING_AGG DISTINCTsiz (11 karakter)',
      'SELECT LENGTH(STRING_AGG(v, ' + Q + ',' + Q + ')) FROM ag WHERE v <= 20', 0, 0, '11');
  // aggregate'siz sorgu yolu: WHERE ile filtreli STRING_AGG
  ChkVal('STRING_AGG WHERE ile (2 deger)',
      'SELECT STRING_AGG(v, ' + Q + ',' + Q + ') FROM ag WHERE v = 10', 0, 0, '10,10');
  ChkVal('STRING_AGG GROUP BY (bolum yok, tek grup)',
      'SELECT STRING_AGG(ad, ' + Q + ',' + Q + ') FROM ag WHERE id <= 2', 0, 0, 'Ali,Veli');
  // ---- F-15: PERCENTILE ----
  // v degerleri: 10,20,10,30,20 -> sirali: 10,10,20,20,30
  // medyan (p=0.5): p*(n-1) = 0.5*4 = 2 -> 20
  ChkVal('PERCENTILE_CONT 0.5 = 20',
      'SELECT PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY v) FROM ag', 0, 0, '20');
  // p=0.25: 0.25*4 = 1 -> 10
  ChkVal('PERCENTILE_CONT 0.25 = 10',
      'SELECT PERCENTILE_CONT(0.25) WITHIN GROUP (ORDER BY v) FROM ag', 0, 0, '10');
  // p=0.75: 0.75*4 = 3 -> 20
  ChkVal('PERCENTILE_CONT 0.75 = 20',
      'SELECT PERCENTILE_CONT(0.75) WITHIN GROUP (ORDER BY v) FROM ag', 0, 0, '20');
  // PERCENTILE_DISC p=0.5 -> indeks 2 -> 20
  ChkVal('PERCENTILE_DISC 0.5 = 20',
      'SELECT PERCENTILE_DISC(0.5) WITHIN GROUP (ORDER BY v) FROM ag', 0, 0, '20');
  // p=0.9: 0.9*4 = 3.6 -> CONT: 20 + (30-20)*0.6 = 26
  ChkVal('PERCENTILE_CONT 0.9 = 26',
      'SELECT PERCENTILE_CONT(0.9) WITHIN GROUP (ORDER BY v) FROM ag', 0, 0, '26');
  // tek deger: p*(0) = 0 -> o deger
  ChkVal('PERCENTILE tek deger',
      'SELECT PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY v) FROM ag WHERE id = 4', 0, 0, '30');
  // hepsi NULL -> NULL
  ChkVal('PERCENTILE hepsi NULL',
      'SELECT PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY v) FROM ag WHERE v IS NULL', 0, 0, '');
  // hatali oran
  ChkErr('PERCENTILE oran > 1 (hata)',
      'SELECT PERCENTILE_CONT(1.5) WITHIN GROUP (ORDER BY v) FROM ag');
  ChkErr('PERCENTILE WITHIN GROUP yok (hata)',
      'SELECT PERCENTILE_CONT(0.5) FROM ag');
  // GROUP BY ile
  Chk('STRING_AGG GROUP BY ad (5)',
      'SELECT ad, STRING_AGG(ad, ' + Q + ',' + Q + ') FROM ag WHERE ad IS NOT NULL GROUP BY ad', 5);
end;

procedure T09i_Qualify;
// F-09: QUALIFY — pencere fonksiyonu hesaplandiktan SONRA filtre.
begin
  Grp('QUALIFY (F-09)');
  UseDir('qualify');
  sq.Exec('CREATE TABLE ql(id INTEGER PRIMARY KEY, ad TEXT, p INTEGER, v INTEGER)');
  sq.Exec('INSERT INTO ql VALUES(1,' + Q + 'Ali' + Q + ',1,10),(2,' + Q + 'Veli' + Q + ',1,20),' +
          '(3,' + Q + 'Zoe' + Q + ',1,30),(4,' + Q + 'Can' + Q + ',2,15),(5,' + Q + 'Eda' + Q + ',2,25)');
  // ROW_NUMBER() = 1 her partition'da ilk satir (p=1: Ali, p=2: Can) -> 2
  ChkVal('QUALIFY ROW_NUMBER=1 (Ali)',
      'SELECT ad, ROW_NUMBER() OVER (PARTITION BY p ORDER BY v) AS rn FROM ql QUALIFY ROW_NUMBER() OVER (PARTITION BY p ORDER BY v) = 1 ORDER BY id', 0, 0, 'Ali');
  ChkVal('QUALIFY ROW_NUMBER=1 (Can, 2. satir)',
      'SELECT ad, ROW_NUMBER() OVER (PARTITION BY p ORDER BY v) AS rn FROM ql QUALIFY ROW_NUMBER() OVER (PARTITION BY p ORDER BY v) = 1 ORDER BY id', 1, 0, 'Can');
  // ROW_NUMBER() <= 2 -> p=1: Ali,Veli; p=2: Can,Eda -> 4 satir
  Chk('QUALIFY ROW_NUMBER<=2 (4)',
      'SELECT ad, ROW_NUMBER() OVER (PARTITION BY p ORDER BY v) AS rn FROM ql QUALIFY ROW_NUMBER() OVER (PARTITION BY p ORDER BY v) <= 2', 4);
  ChkVal('QUALIFY <=2 son satir (Eda)',
      'SELECT ad, ROW_NUMBER() OVER (PARTITION BY p ORDER BY v) AS rn FROM ql QUALIFY ROW_NUMBER() OVER (PARTITION BY p ORDER BY v) <= 2 ORDER BY id', 3, 0, 'Eda');
  // QUALIFY 5. satiri eler: Zoe (p=1, rn=3) gelmemeli
  ChkVal('QUALIFY Zoe elendi (Eda 4. satir)',
      'SELECT ad, ROW_NUMBER() OVER (PARTITION BY p ORDER BY v) AS rn FROM ql QUALIFY ROW_NUMBER() OVER (PARTITION BY p ORDER BY v) <= 2 ORDER BY id', 3, 0, 'Eda');
  // pencere + LIMIT birlikte
  Chk('QUALIFY + LIMIT (1)',
      'SELECT ad, ROW_NUMBER() OVER (PARTITION BY p ORDER BY v) AS rn FROM ql QUALIFY ROW_NUMBER() OVER (PARTITION BY p ORDER BY v) <= 2 ORDER BY id FETCH FIRST 1 ROWS ONLY', 1);
  // pencere olmadan QUALIFY -> hata
  ChkErr('QUALIFY pencilsuz (hata)',
      'SELECT ad FROM ql QUALIFY id = 1');
end;

procedure T09f_ILike;
// F-05: ILIKE — buyuk/kucuk duyarsiz LIKE (PostgreSQL uyumu).
begin
  Grp('ILIKE (F-05)');
  UseDir('ilike');
  sq.Exec('CREATE TABLE il(id INTEGER PRIMARY KEY, ad TEXT)');
  sq.Exec('INSERT INTO il VALUES(1,' + Q + 'Ali' + Q + '),(2,' + Q + 'VELI' + Q + '),(3,' +
          Q + 'zOE' + Q + '),(4,' + Q + 'ayse' + Q + '),(5,NULL)');
  // LIKE buyuk/kucuk DUYARLI: sadece kucuk harfle baslayanlar
  Chk('LIKE kucuk duyarli (1)', 'SELECT ad FROM il WHERE ad LIKE ' + Q + 'a%' + Q, 1);
  // ILIKE duyarsiz: hem 'Ali' hem 'ayse' -> 2
  Chk('ILIKE duyarsiz on ek (2)',
      'SELECT ad FROM il WHERE ad ILIKE ' + Q + 'a%' + Q, 2);
  ChkVal('ILIKE deger', 'SELECT ad FROM il WHERE ad ILIKE ' + Q + 'A%' + Q + ' ORDER BY id', 0, 0, 'Ali');
  // Ic harf: yalniz 'zOE' icinde 'oe' var -> 1 satir
  Chk('ILIKE ic desen (1)',
      'SELECT ad FROM il WHERE ad ILIKE ' + Q + '%oe%' + Q, 1);
  // NOT ILIKE
  Chk('NOT ILIKE (2)', 'SELECT ad FROM il WHERE ad NOT ILIKE ' + Q + 'a%' + Q, 2);
  // joker: '_' tek karakter
  Chk('ILIKE joker _ (1)',
      'SELECT ad FROM il WHERE ad ILIKE ' + Q + 'z_e' + Q, 1);
  // NULL satir elenir (uc-degerli)
  Chk('ILIKE NULL elenir (4)',
      'SELECT ad FROM il WHERE ad ILIKE ' + Q + '%' + Q, 4);
  // Turkce buyuk/kucuk: 'I' -> 'i' donusumu
  ChkVal('ILIKE turkce I donusumu',
      'SELECT ad FROM il WHERE ad ILIKE ' + Q + 'ali' + Q, 0, 0, 'Ali');
end;

procedure T08d_CaseWhen;
begin
  Grp('CASE WHEN (P5-3)');
  UseDir('casew');
  sq.Exec('CREATE TABLE per(id INTEGER PRIMARY KEY, ad TEXT, yas INTEGER, maas FLOAT)');
  sq.Exec('INSERT INTO per(id,ad,yas,maas) VALUES(1,' + Q + 'Ali' + Q + ',30,9000.5)');
  sq.Exec('INSERT INTO per(id,ad,yas,maas) VALUES(2,' + Q + 'Veli' + Q + ',17,4000)');
  sq.Exec('INSERT INTO per(id,ad,yas,maas) VALUES(3,' + Q + 'Zoe' + Q + ',25,NULL)');
  ChkVal('aranan + ELSE (Ali resit)',
      'SELECT ad, CASE WHEN yas >= 18 THEN ' + Q + 'resit' + Q + ' ELSE ' + Q + 'cocuk' + Q + ' END AS d FROM per ORDER BY id', 0, 1, 'resit');
  ChkVal('aranan ELSE (Veli cocuk)',
      'SELECT ad, CASE WHEN yas >= 18 THEN ' + Q + 'resit' + Q + ' ELSE ' + Q + 'cocuk' + Q + ' END AS d FROM per ORDER BY id', 1, 1, 'cocuk');
  ChkVal('ELSEsiz eslesmezse NULL',
      'SELECT ad, CASE WHEN yas > 100 THEN ' + Q + 'x' + Q + ' END AS d FROM per WHERE id = 1', 0, 1, '');
  ChkVal('sade CASE (Ali otuz)',
      'SELECT ad, CASE yas WHEN 30 THEN ' + Q + 'otuz' + Q + ' WHEN 17 THEN ' + Q + 'onyedi' + Q + ' ELSE ' + Q + 'diger' + Q + ' END AS d FROM per ORDER BY id', 0, 1, 'otuz');
  ChkVal('sade CASE (Zoe diger)',
      'SELECT ad, CASE yas WHEN 30 THEN ' + Q + 'otuz' + Q + ' WHEN 17 THEN ' + Q + 'onyedi' + Q + ' ELSE ' + Q + 'diger' + Q + ' END AS d FROM per ORDER BY id', 2, 1, 'diger');
  Chk('CASE WHERE kosulu (2)',
      'SELECT ad FROM per WHERE CASE WHEN yas >= 18 THEN 1 ELSE 0 END = 1', 2);
  ChkVal('ic ice CASE',
      'SELECT CASE WHEN yas > 20 THEN CASE WHEN yas > 28 THEN ' + Q + 'yasli' + Q + ' ELSE ' + Q + 'genc' + Q + ' END ELSE ' + Q + 'cocuk' + Q + ' END AS d FROM per ORDER BY id', 0, 0, 'yasli');
  ChkVal('CASE float kiyas',
      'SELECT CASE WHEN maas > 5000 THEN ' + Q + 'yuksek' + Q + ' ELSE ' + Q + 'dusuk' + Q + ' END AS s FROM per ORDER BY id', 0, 0, 'yuksek');
  ChkVal('CASE NULL kiyas ELSE duser',
      'SELECT CASE WHEN maas > 5000 THEN ' + Q + 'yuksek' + Q + ' ELSE ' + Q + 'dusuk' + Q + ' END AS s FROM per ORDER BY id', 2, 0, 'dusuk');
  ChkErr('eksik END (hata)',
      'SELECT CASE WHEN yas > 1 THEN 1 FROM per');
  ChkErr('WHENsiz CASE (hata)',
      'SELECT CASE yas ELSE 1 END FROM per');
end;

procedure T08e_CTE;
begin
  Grp('WITH-CTE (P5-CTE)');
  UseDir('cteq');
  sq.Exec('CREATE TABLE bolge(id INTEGER PRIMARY KEY, ad TEXT)');
  sq.Exec('CREATE TABLE musteri(id INTEGER PRIMARY KEY, ad TEXT, bid INTEGER, maas INTEGER)');
  sq.Exec('INSERT INTO bolge(id,ad) VALUES(1,' + Q + 'Ege' + Q + '),(2,' + Q + 'Ic Anadolu' + Q + ')');
  sq.Exec('INSERT INTO musteri(id,ad,bid,maas) VALUES(1,' + Q + 'Ali' + Q + ',1,9000)');
  sq.Exec('INSERT INTO musteri(id,ad,bid,maas) VALUES(2,' + Q + 'Veli' + Q + ',2,4000)');
  sq.Exec('INSERT INTO musteri(id,ad,bid,maas) VALUES(3,' + Q + 'Zoe' + Q + ',NULL,7000)');
  sq.Exec('INSERT INTO musteri(id,ad,bid,maas) VALUES(4,' + Q + 'Can' + Q + ',1,5000)');
  sq.Exec('INSERT INTO musteri(id,ad,bid,maas) VALUES(5,' + Q + 'Dev' + Q + ',2,100000)');
  Chk('tek CTE (5)',
      'WITH m AS (SELECT id, ad, bid FROM musteri) SELECT ad FROM m', 5);
  ChkVal('CTE WHERE',
      'WITH m AS (SELECT id, ad, bid FROM musteri) SELECT ad FROM m WHERE bid = 1 ORDER BY id', 0, 0, 'Ali');
  Chk('zincir CTE (Can)',
      'WITH e AS (SELECT id, ad FROM musteri WHERE bid = 1), ' +
      'x AS (SELECT ad FROM e WHERE id > 1) SELECT ad FROM x', 1);
  ChkVal('zincir deger',
      'WITH e AS (SELECT id, ad FROM musteri WHERE bid = 1), ' +
      'x AS (SELECT ad FROM e WHERE id > 1) SELECT ad FROM x', 0, 0, 'Can');
  Chk('CTE + JOIN (4)',
      'WITH m AS (SELECT id, ad, bid FROM musteri WHERE bid IS NOT NULL) ' +
      'SELECT m.ad, b.ad FROM m JOIN bolge b ON m.bid = b.id ORDER BY m.id', 4);
  Chk('CTE sagda (4)',
      'WITH m AS (SELECT id, bid FROM musteri WHERE bid IS NOT NULL) ' +
      'SELECT b.ad FROM bolge b JOIN m ON m.bid = b.id', 4);
  ChkVal('CTE aggregate',
      'WITH m AS (SELECT id, bid FROM musteri WHERE bid IS NOT NULL) SELECT COUNT(*) AS c FROM m', 0, 0, '4');
  ChkVal('CTE GROUP BY',
      'WITH m AS (SELECT bid FROM musteri WHERE bid IS NOT NULL) SELECT bid, COUNT(*) AS n FROM m GROUP BY bid ORDER BY bid', 0, 1, '2');
  Chk('CTE sayisal WHERE (3, metin olsa 2 olurdu)',
      'WITH m AS (SELECT id, maas FROM musteri) SELECT id FROM m WHERE maas > 6000', 3);
  ChkVal('CTE sayisal ORDER BY (Veli ilk)',
      'WITH m AS (SELECT id, maas FROM musteri) SELECT id FROM m ORDER BY maas LIMIT 1', 0, 0, '2');
  Chk('RECURSIVE (4.5 acik, maxIter=3)',
      'WITH RECURSIVE x AS (SELECT id FROM musteri) SELECT id FROM x', 5);
  Chk('kolon alias (4.5 acik)',
      'WITH x(a) AS (SELECT id FROM musteri) SELECT a FROM x', 5);
  Chk('WITH + INSERT (4.5 acik)',
      'WITH x AS (SELECT id FROM musteri) INSERT INTO musteri(id) VALUES(9)', 0);
  ChkErr('bilinmeyen CTE/tablo (hata)',
      'WITH x AS (SELECT id FROM musteri) SELECT id FROM yok');
end;

procedure T08f_Pencere;
begin
  Grp('Pencere fonksiyonlari (P5-WIN)');
  UseDir('winf');
  sq.Exec('CREATE TABLE sat(id INTEGER PRIMARY KEY, ad TEXT, bolge TEXT, tutar INTEGER)');
  sq.Exec('INSERT INTO sat(id,ad,bolge,tutar) VALUES(1,' + Q + 'a' + Q + ',' + Q + 'E' + Q + ',100)');
  sq.Exec('INSERT INTO sat(id,ad,bolge,tutar) VALUES(2,' + Q + 'b' + Q + ',' + Q + 'E' + Q + ',200)');
  sq.Exec('INSERT INTO sat(id,ad,bolge,tutar) VALUES(3,' + Q + 'c' + Q + ',' + Q + 'W' + Q + ',150)');
  sq.Exec('INSERT INTO sat(id,ad,bolge,tutar) VALUES(4,' + Q + 'd' + Q + ',' + Q + 'E' + Q + ',200)');
  sq.Exec('INSERT INTO sat(id,ad,bolge,tutar) VALUES(5,' + Q + 'e' + Q + ',' + Q + 'W' + Q + ',NULL)');
  sq.Exec('INSERT INTO sat(id,ad,bolge,tutar) VALUES(6,' + Q + 'f' + Q + ',' + Q + 'E' + Q + ',300)');
  ChkVal('ROW_NUMBER sirasiz',
      'SELECT ad, ROW_NUMBER() OVER () AS rn FROM sat ORDER BY id', 0, 1, '1');
  ChkVal('ROW_NUMBER son',
      'SELECT ad, ROW_NUMBER() OVER () AS rn FROM sat ORDER BY id', 5, 1, '6');
  ChkVal('ROW_NUMBER partition',
      'SELECT ad, ROW_NUMBER() OVER (PARTITION BY bolge ORDER BY tutar) AS rn FROM sat ORDER BY id', 0, 1, '1');
  ChkVal('ROW_NUMBER partition son (f=4, bagimsiz)',
      'SELECT ad, ROW_NUMBER() OVER (PARTITION BY bolge ORDER BY tutar) AS rn FROM sat ORDER BY id', 5, 1, '4');
  ChkVal('RANK bag paylasir (b=2)',
      'SELECT ad, RANK() OVER (PARTITION BY bolge ORDER BY tutar) AS r FROM sat ORDER BY id', 1, 1, '2');
  ChkVal('RANK bag paylasir (d=2)',
      'SELECT ad, RANK() OVER (PARTITION BY bolge ORDER BY tutar) AS r FROM sat ORDER BY id', 3, 1, '2');
  ChkVal('RANK bag sonrasi atlar (f=4)',
      'SELECT ad, RANK() OVER (PARTITION BY bolge ORDER BY tutar) AS r FROM sat ORDER BY id', 5, 1, '4');
  ChkVal('DENSE_RANK atlamaz (f=3)',
      'SELECT ad, DENSE_RANK() OVER (PARTITION BY bolge ORDER BY tutar) AS r FROM sat ORDER BY id', 5, 1, '3');
  ChkVal('SUM partition toplami (800)',
      'SELECT ad, SUM(tutar) OVER (PARTITION BY bolge) AS s FROM sat ORDER BY id', 0, 1, '800');
  ChkVal('COUNT yildiz partition (E=4)',
      'SELECT ad, COUNT(*) OVER (PARTITION BY bolge) AS c FROM sat ORDER BY id', 0, 1, '4');
  ChkVal('COUNT yildiz partition (W=2)',
      'SELECT ad, COUNT(*) OVER (PARTITION BY bolge) AS c FROM sat ORDER BY id', 2, 1, '2');
  ChkVal('AVG partition NULL atlar (150)',
      'SELECT AVG(tutar) OVER (PARTITION BY bolge) AS o FROM sat ORDER BY id', 4, 0, '150');
  ChkVal('MIN partition (100)',
      'SELECT MIN(tutar) OVER (PARTITION BY bolge) AS m FROM sat ORDER BY id', 1, 0, '100');
  ChkVal('LAG onceki (b->a)',
      'SELECT ad, LAG(ad) OVER (ORDER BY id) AS onceki FROM sat ORDER BY id', 1, 1, 'a');
  ChkVal('LAG ilk NULL',
      'SELECT ad, LAG(ad) OVER (ORDER BY id) AS onceki FROM sat ORDER BY id', 0, 1, '');
  ChkVal('LAG offset+varsayilan',
      'SELECT ad, LAG(ad, 2, ' + Q + 'yok' + Q + ') OVER (ORDER BY id) AS o FROM sat ORDER BY id', 1, 1, 'yok');
  ChkVal('LEAD sonraki (d->e)',
      'SELECT ad, LEAD(ad) OVER (ORDER BY id) AS sonraki FROM sat ORDER BY id', 3, 1, 'e');
  ChkVal('LAG partition tasmaz (c ilk)',
      'SELECT ad, LAG(ad) OVER (PARTITION BY bolge ORDER BY id) AS o FROM sat ORDER BY id', 2, 1, '');
  Chk('pencere + JOIN (8)',
      'SELECT s.ad, ROW_NUMBER() OVER (ORDER BY s.id) AS rn FROM sat s JOIN sat t ON s.bolge = t.bolge WHERE s.id <= 2', 8);
  Chk('skaler alt sorgu ile WHERE (3)',
      'SELECT ad FROM sat WHERE tutar > (SELECT AVG(tutar) FROM sat)', 3);
  ChkErr('WHERE icinde pencere (hata)',
      'SELECT ad FROM sat WHERE ROW_NUMBER() OVER (ORDER BY id) = 1');
  ChkErr('ic ice pencere (hata)',
      'SELECT 1 + ROW_NUMBER() OVER (ORDER BY id) FROM sat');
  ChkErr('ROW_NUMBER arguman (hata)',
      'SELECT ROW_NUMBER(id) OVER () FROM sat');
  ChkErr('LAG OVERsiz (hata)',
      'SELECT LAG(ad) FROM sat');
  ChkErr('bilinmeyen OVER (hata)',
      'SELECT UPPER(ad) OVER () FROM sat');
  ChkErr('GROUP BY + pencere (hata)',
      'SELECT bolge, COUNT(*), RANK() OVER (ORDER BY bolge) FROM sat GROUP BY bolge');
end;

procedure T09_GroupAggregate;
begin
  Grp('GROUP BY + aggregate (COUNT/SUM/AVG/MIN/MAX)');
  UseDir('grp');
  sq.Exec('CREATE TABLE p(id INTEGER PRIMARY KEY, dept TEXT, maas INTEGER)');
  sq.Exec('INSERT INTO p(dept,maas) VALUES(' + Q + 'yazilim' + Q + ',100)');
  sq.Exec('INSERT INTO p(dept,maas) VALUES(' + Q + 'yazilim' + Q + ',200)');
  sq.Exec('INSERT INTO p(dept,maas) VALUES(' + Q + 'yazilim' + Q + ',300)');
  sq.Exec('INSERT INTO p(dept,maas) VALUES(' + Q + 'satis' + Q + ',150)');
  sq.Exec('INSERT INTO p(dept,maas) VALUES(' + Q + 'satis' + Q + ',250)');
  ChkVal('COUNT(*)', 'SELECT COUNT(*) FROM p', 0, 0, '5');
  ChkVal('COUNT(dept)', 'SELECT COUNT(dept) FROM p', 0, 0, '5');
  ChkVal('SUM', 'SELECT SUM(maas) FROM p', 0, 0, '1000');
  ChkVal('AVG', 'SELECT AVG(maas) FROM p', 0, 0, '200');
  ChkVal('MIN', 'SELECT MIN(maas) FROM p', 0, 0, '100');
  ChkVal('MAX', 'SELECT MAX(maas) FROM p', 0, 0, '300');
  Chk('GROUP BY 2 grup', 'SELECT dept, COUNT(*) FROM p GROUP BY dept', 2);
  ChkVal('GROUP BY SUM', 'SELECT dept, SUM(maas) FROM p GROUP BY dept ' +
      'ORDER BY dept', 0, 1, '400');
  ChkVal('coklu kolon GROUP BY',
      'SELECT dept, maas, COUNT(*) FROM p GROUP BY dept, maas', 0, 2, '1');
  ChkVal('aggregate + WHERE', 'SELECT COUNT(*) FROM p WHERE maas > 150', 0, 0, '3');
  // 4.3: dogrudan aggregate HAVING kabul (onceki reddin yeri)
  Chk('HAVING dogrudan aggregate (kabul)',
      'SELECT dept, COUNT(*) FROM p GROUP BY dept HAVING COUNT(*) > 1', 2);
  Chk('HAVING dogrudan aggregate (suzulur)',
      'SELECT dept, COUNT(*) FROM p GROUP BY dept HAVING COUNT(*) > 2', 1);
  ChkErr('artik token sessizce yutulmaz (hata)',
      'SELECT dept FROM p WHERE maas > 1 BLA BLA');
end;

procedure T09b_HavingAggregate;
// 4.3: HAVING icinde dogrudan aggregate (alias ZORUNLU DEGIL).
// Her test, "yanlis degerlendirme" durumunun da ayirt edici olmasi
// icin secildi: metin sirasiyla kiyas ('10' > '9' => false) ya da
// grup baglamisiz degerlendirme (COUNT(*) => '1') farkli sonuc verir.
begin
  Grp('HAVING dogrudan aggregate (4.3)');
  UseDir('having');
  sq.Exec('CREATE TABLE h(id INTEGER PRIMARY KEY, dept TEXT, maas INTEGER)');
  // yazilim: 10 satir x 100 (sum 1000, avg 100, min 100, max 100)
  // satis:    2 satir x 450 (sum  900, avg 450, min 450, max 450)
  // pazarlama:1 satir x  50 (sum   50, avg  50, min  50, max  50)
  sq.Exec('INSERT INTO h(dept,maas) VALUES(' + Q + 'yazilim' + Q + ',100),(' +
      Q + 'yazilim' + Q + ',100),(' + Q + 'yazilim' + Q + ',100),(' +
      Q + 'yazilim' + Q + ',100),(' + Q + 'yazilim' + Q + ',100)');
  sq.Exec('INSERT INTO h(dept,maas) VALUES(' + Q + 'yazilim' + Q + ',100),(' +
      Q + 'yazilim' + Q + ',100),(' + Q + 'yazilim' + Q + ',100),(' +
      Q + 'yazilim' + Q + ',100),(' + Q + 'yazilim' + Q + ',100)');
  sq.Exec('INSERT INTO h(dept,maas) VALUES(' + Q + 'satis' + Q + ',450),(' +
      Q + 'satis' + Q + ',450)');
  sq.Exec('INSERT INTO h(dept,maas) VALUES(' + Q + 'pazarlama' + Q + ',50)');

  Chk('HAVING COUNT(*) > 1 (grup filtresi)',
      'SELECT dept, COUNT(*) AS n FROM h GROUP BY dept ' +
      'HAVING COUNT(*) > 1 ORDER BY dept', 2);
  // 10 > 9: metin kiyasinda FALSE ('10' < '9') — tip INT olmali
  Chk('HAVING COUNT(*) > 9 (sayisal kiyas)',
      'SELECT dept, COUNT(*) AS n FROM h GROUP BY dept HAVING COUNT(*) > 9', 1);
  // aggregate SELECT listesinde yok — grup satirindan hesaplanmali
  Chk('HAVING aggregate cikti listesinde yok',
      'SELECT dept FROM h GROUP BY dept HAVING COUNT(*) > 5', 1);
  // SUM 1000 > 950: metin kiyasinda FALSE ('1000' < '950') — tip FLOAT
  Chk('HAVING SUM (sayisal kiyas)',
      'SELECT dept, SUM(maas) AS s FROM h GROUP BY dept HAVING SUM(maas) > 950', 1);
  // AVG: 100 ve 450 > 90 (metin kiyasinda ikisi de false: '100'<'90')
  Chk('HAVING AVG (sayisal kiyas)',
      'SELECT dept, AVG(maas) AS a FROM h GROUP BY dept HAVING AVG(maas) > 90', 2);
  // MIN: yalniz satis (450); metin kiyasinda pazarlama ('50'>'100') de gecerdi
  Chk('HAVING MIN (kolon tipi cozumu)',
      'SELECT dept, MIN(maas) AS m FROM h GROUP BY dept HAVING MIN(maas) > 100', 1);
  Chk('HAVING MAX (kolon tipi cozumu)',
      'SELECT dept, MAX(maas) AS m FROM h GROUP BY dept HAVING MAX(maas) > 100', 1);
  // alias (n) + dogrudan aggregate ayni cumlede
  Chk('HAVING alias + dogrudan aggregate',
      'SELECT dept, COUNT(*) AS n FROM h GROUP BY dept ' +
      'HAVING n > 5 AND COUNT(*) < 100', 1);

  ChkVal('HAVING + ORDER BY + LIMIT',
      'SELECT dept, COUNT(*) AS n FROM h GROUP BY dept ' +
      'HAVING COUNT(*) > 1 ORDER BY n DESC LIMIT 1', 0, 1, '10');
  Chk('WHERE + HAVING (once WHERE, sonra grup)',
      'SELECT dept, COUNT(*) AS n FROM h WHERE maas > 50 GROUP BY dept ' +
      'HAVING COUNT(*) > 1', 2);

  // JOIN + HAVING: nitelikli/sade argumanda tip cozumu (FindColIdx)
  sq.Exec('CREATE TABLE hb(id INTEGER PRIMARY KEY, mid INTEGER, tutar INTEGER)');
  sq.Exec('CREATE TABLE hm(mid INTEGER PRIMARY KEY, sehir TEXT)');
  sq.Exec('INSERT INTO hm VALUES(1,' + Q + 'ank' + Q + ')');
  sq.Exec('INSERT INTO hm VALUES(2,' + Q + 'izm' + Q + ')');
  sq.Exec('INSERT INTO hb(mid,tutar) VALUES(1,10),(1,20),(2,5)');
  Chk('JOIN + HAVING COUNT(*)',
      'SELECT m.sehir, COUNT(*) AS n FROM hb b JOIN hm m ON b.mid = m.mid ' +
      'GROUP BY m.sehir HAVING COUNT(*) > 1', 1);
  // nitelikli arguman: aggCt = INTEGER olmali; metin kiyasinda
  // '10' > '8' false oldugu icin ank da elenirdi (0 satir)
  Chk('JOIN + HAVING MIN (nitelikli arguman)',
      'SELECT m.sehir, MIN(b.tutar) AS mn FROM hb b JOIN hm m ON b.mid = m.mid ' +
      'GROUP BY m.sehir HAVING MIN(b.tutar) > 8', 1);
  // sade yazim: sonek kuraliyla b.tutar bulunmali
  Chk('JOIN + HAVING MIN (sade arguman)',
      'SELECT m.sehir, MIN(tutar) AS mn FROM hb b JOIN hm m ON b.mid = m.mid ' +
      'GROUP BY m.sehir HAVING MIN(tutar) > 8', 1);
  ChkErr('HAVING bilinmeyen kolon (hata)',
      'SELECT dept, COUNT(*) FROM h GROUP BY dept HAVING olmayankolon > 1');
end;

procedure T09c_NotOrDNF;
// 4.4: NOT (...) icinde OR (DNF): basit OR -> De Morgan -> tek AND grubu.
// NOT (a=1 OR b=2) -> a<>1 AND b<>2 (calisir). NOT (AND OR) -> hata.
begin
  Grp('NOT (...) icinde OR (DNF 4.4)');
  UseDir('notor');
  sq.Exec('CREATE TABLE dnf(id INTEGER PRIMARY KEY, a INTEGER, b INTEGER)');
  sq.Exec('INSERT INTO dnf VALUES(1,10,20),(2,30,40),(3,50,60)');
  // NOT (a=1 OR b=2) -> De Morgan: a<>1 AND b<>2 -> id=2 (30,40) + id=3 (50,60) = 2 satir
  Chk('NOT(OR) De Morgan basit',
      'SELECT * FROM dnf WHERE NOT (a = 10 OR b = 20)', 2);
  // NOT (a > 30 OR b > 25) -> a<=30 AND b<=25 -> id=1 (10,20) + id=2 (30,40?) hayir b=40>25
  // id=1: a<=30 (True) AND b<=25 (True) -> 1 satir
  Chk('NOT(OR) De Morgan sayisal',
      'SELECT * FROM dnf WHERE NOT (a > 30 OR b > 25)', 1);
  // NOT (id=1 OR id=3) -> id<>1 AND id<>3 -> yalniz id=2
  Chk('NOT(OR) id degeri',
      'SELECT * FROM dnf WHERE NOT (id = 1 OR id = 3)', 1);
  // NOT (AND OR) cok kosullu: tek tablo AST yolu calisir (ParseWhereGroups
  // kullanilmaz); JOIN seviyesinde ise 4.4 siniri gecerli kalir.
  Chk('NOT(OR) cok kosullu tek tablo (AST calisir)',
      'SELECT * FROM dnf WHERE NOT (a > 15 AND b > 25 OR id = 3)', 1);
end;

procedure T09e_NullIfCoalesce;
begin
  Grp('NULLIF / COALESCE (F-02)');
  UseDir('nullif');
  sq.Exec('CREATE TABLE nf(id INTEGER PRIMARY KEY, a INTEGER, b INTEGER, c TEXT)');
  sq.Exec('INSERT INTO nf VALUES(1,10,10,''eq''),(2,10,20,''neq''),(3,NULL,5,''null_a''),(4,5,NULL,''null_b'')');

  // NULLIF(a,b): a=b ise NULL, degilse a
  Chk('NULLIF esit -> NULL (1 satir)',
      'SELECT NULLIF(a,b) FROM nf WHERE id=1', 1);
  Chk('NULLIF farkli -> a (1 satir)',
      'SELECT NULLIF(a,b) FROM nf WHERE id=2', 1);
  Chk('NULLIF NULL a -> NULL (1 satir)',
      'SELECT NULLIF(a,b) FROM nf WHERE id=3', 1);
  Chk('NULLIF NULL b -> a (1 satir)',
      'SELECT NULLIF(a,b) FROM nf WHERE id=4', 1);

  // COALESCE(a,b,c...): ilk non-NULL
  Chk('COALESCE ilk a (1 satir)',
      'SELECT COALESCE(a,b,99) FROM nf WHERE id=2', 1);
  Chk('COALESCE a NULL b deger (1 satir)',
      'SELECT COALESCE(a,b,99) FROM nf WHERE id=3', 1);
  Chk('COALESCE a NULL b NULL c deger (1 satir)',
      'SELECT COALESCE(a,b,c,99) FROM nf WHERE id=4', 1);
  Chk('COALESCE hepsi NULL -> son (1 satir)',
      'SELECT COALESCE(a,b,99) FROM nf WHERE id=3', 1);

  // NULLIF/COALESCE bir arada
  Chk('NULLIF icinde COALESCE (1 satir)',
      'SELECT COALESCE(NULLIF(a,b), 999) FROM nf WHERE id=1', 1);
  Chk('COALESCE icinde NULLIF (1 satir)',
      'SELECT NULLIF(COALESCE(a,99), 99) FROM nf WHERE id=3', 1);
end;

procedure T10_Update;
begin
  Grp('UPDATE');
  UseDir('upd');
  sq.Exec('CREATE TABLE ebeveyn(id INTEGER PRIMARY KEY)');
  sq.Exec('INSERT INTO ebeveyn(id) VALUES(1)');
  sq.Exec('CREATE TABLE t(id INTEGER PRIMARY KEY, ad TEXT UNIQUE, ' +
          'yas INTEGER, pid INTEGER REFERENCES ebeveyn(id), ' +
          'puan INTEGER CHECK (puan >= 0))');
  sq.Exec('INSERT INTO t(ad,yas,pid) VALUES(' + Q + 'a' + Q + ',1,1)');
  sq.Exec('INSERT INTO t(ad,yas,pid) VALUES(' + Q + 'b' + Q + ',2,1)');
  Chk('WHERE ile tek', 'UPDATE t SET yas = 99 WHERE id = 1', -1);
  ChkVal('guncellendi', 'SELECT yas FROM t WHERE id=1', 0, 0, '99');
  Chk('WHERE ile cok', 'UPDATE t SET yas = 50 WHERE yas > 10', -1);
  Chk('WHERE yoksa tumu', 'UPDATE t SET yas = 7', -1);
  ChkVal('tum satirlar guncellendi', 'SELECT yas FROM t WHERE id=1', 0, 0, '7');
  Chk('coklu SET', 'UPDATE t SET ad = ' + Q + 'z' + Q + ', yas = 1 WHERE id = 1', -1);
  Chk('NULL yazma', 'UPDATE t SET yas = NULL WHERE id = 1', -1);
  ChkVal('NULL yazildi', 'SELECT yas FROM t WHERE id=1', 0, 0, '');
  ChkErr('CHECK ihlali UPDATE (hata)', 'UPDATE t SET puan = -5 WHERE id = 1');
  ChkErr('FK ihlali UPDATE (hata)', 'UPDATE t SET pid = 77 WHERE id = 1');
  Chk('gecerli FK UPDATE', 'UPDATE t SET pid = 1 WHERE id = 1', -1);
  ChkErr('UNIQUE ihlali UPDATE (hata)',
      'UPDATE t SET ad = ' + Q + 'z' + Q + ' WHERE id = 2');
end;

procedure T11_Delete;
begin
  Grp('DELETE');
  UseDir('del');
  sq.Exec('CREATE TABLE eb(id INTEGER PRIMARY KEY)');
  sq.Exec('CREATE TABLE coc(id INTEGER PRIMARY KEY, pid INTEGER ' +
          'REFERENCES eb(id))');
  sq.Exec('INSERT INTO eb(id) VALUES(1)');
  sq.Exec('INSERT INTO coc(id,pid) VALUES(1,1)');
  sq.Exec('INSERT INTO coc(id) VALUES(2)');
  sq.Exec('CREATE TABLE t(id INTEGER PRIMARY KEY, v INTEGER)');
  sq.Exec('INSERT INTO t(v) VALUES(1)');
  sq.Exec('INSERT INTO t(v) VALUES(2)');
  sq.Exec('INSERT INTO t(v) VALUES(3)');
  Chk('WHERE ile tek', 'DELETE FROM t WHERE id = 1', -1);
  ChkVal('kalan satir', 'SELECT COUNT(*) FROM t', 0, 0, '2');
  Chk('WHERE ile cok', 'DELETE FROM t WHERE v > 1', -1);
  ChkVal('kalan satir 2', 'SELECT COUNT(*) FROM t', 0, 0, '0');
  ChkErr('FK RESTRICT silemez (hata)', 'DELETE FROM eb WHERE id = 1');
  Chk('NULL FK ile silinebilir', 'DELETE FROM coc WHERE id = 2', -1);
  sq.Exec('INSERT INTO t(v) VALUES(9)');
  Chk('WHERE yoksa tumu', 'DELETE FROM t', -1);
  ChkVal('tablo bos', 'SELECT COUNT(*) FROM t', 0, 0, '0');
end;

procedure T12_Transaction;
begin
  Grp('Transaction: COMMIT / ROLLBACK, DDL dahil');
  UseDir('trn');
  sq.Exec('CREATE TABLE t(id INTEGER PRIMARY KEY, a TEXT)');
  sq.Exec('INSERT INTO t(a) VALUES(' + Q + 'ilk' + Q + ')');
  Chk('BEGIN', 'BEGIN', -1);
  Chk('batch icinde INSERT', 'INSERT INTO t(a) VALUES(' + Q + 'gizli' + Q + ')', -1);
  Chk('batch icinde SELECT gorunur',
      'SELECT a FROM t WHERE a = ' + Q + 'gizli' + Q, 1);
  ChkVal('batch icinde UPDATE gorunur',
      'SELECT a FROM t WHERE id = 1', 0, 0, 'ilk');
  Chk('ROLLBACK', 'ROLLBACK', -1);
  Chk('rollback: eklenen yok',
      'SELECT a FROM t WHERE a = ' + Q + 'gizli' + Q, 0);
  ChkVal('rollback: eski veri duruyor', 'SELECT COUNT(*) FROM t', 0, 0, '1');
  Chk('BEGIN 2', 'BEGIN', -1);
  sq.Exec('INSERT INTO t(a) VALUES(' + Q + 'kalici' + Q + ')');
  Chk('COMMIT', 'COMMIT', -1);
  ChkVal('commit: veri duruyor', 'SELECT COUNT(*) FROM t', 0, 0, '2');
  Chk('BEGIN 3 (DDL)', 'BEGIN', -1);
  Chk('batch icinde CREATE TABLE', 'CREATE TABLE gecici(id INTEGER PRIMARY KEY)', -1);
  sq.Exec('INSERT INTO gecici(id) VALUES(1)');
  Chk('ROLLBACK DDL', 'ROLLBACK', -1);
  ChkErr('rollback sonrasi tablo yok (hata)', 'SELECT * FROM gecici');
  ChkVal('rollback sonrasi veri saglam', 'SELECT COUNT(*) FROM t', 0, 0, '2');
  Chk('BEGIN 4 (ALTER)', 'BEGIN', -1);
  Chk('batch icinde ALTER', 'ALTER TABLE t ADD yeni INTEGER', -1);
  Chk('ROLLBACK ALTER', 'ROLLBACK', -1);
  ChkErr('rollback sonrasi kolon yok (hata)', 'SELECT yeni FROM t');
end;

procedure T13_AlterTable;
begin
  Grp('ALTER TABLE');
  UseDir('alt');
  sq.Exec('CREATE TABLE t(id INTEGER PRIMARY KEY, a TEXT, b INTEGER)');
  sq.Exec('INSERT INTO t(a,b) VALUES(' + Q + 'Ali' + Q + ',1)');
  sq.Exec('INSERT INTO t(a,b) VALUES(' + Q + 'Veli' + Q + ',2)');
  Chk('ADD COLUMN', 'ALTER TABLE t ADD c TEXT', -1);
  ChkVal('veri korundu', 'SELECT a FROM t ORDER BY id', 0, 0, 'Ali');
  ChkVal('yeni sutun NULL', 'SELECT c FROM t ORDER BY id', 0, 0, '');
  Chk('ADD COLUMN FIRST', 'ALTER TABLE t ADD ilk TEXT FIRST', -1);
  Chk('ADD COLUMN AFTER', 'ALTER TABLE t ADD sonra TEXT AFTER a', -1);
  ChkErr('var olan kolon (hata)', 'ALTER TABLE t ADD a TEXT');
  ChkErr('olmayan kolon (hata)', 'ALTER TABLE t ADD x TEXT AFTER yok');
  Chk('DROP COLUMN', 'ALTER TABLE t DROP c', -1);
  ChkVal('veri hala duruyor', 'SELECT a FROM t ORDER BY id', 0, 0, 'Ali');
  Chk('RENAME COLUMN', 'ALTER TABLE t RENAME COLUMN a TO isim', -1);
  ChkVal('yeni adiyle okunur', 'SELECT isim FROM t ORDER BY id', 0, 0, 'Ali');
  ChkErr('eski ad yok (hata)', 'SELECT a FROM t');
  ChkErr('PK kolonu dusurulemez (hata)', 'ALTER TABLE t DROP id');
  Chk('ALTER COLUMN TYPE', 'ALTER TABLE t ALTER COLUMN b TYPE TEXT', -1);
  Chk('TEXT kolona her sey yazilabilir', 'UPDATE t SET b = ' + Q + 'zzz' + Q, -1);
  ChkErr('TEXT -> INTEGER donusturulemez (hata)',
      'ALTER TABLE t ALTER COLUMN b TYPE INTEGER');
  Chk('bozuk degeri duzelt', 'UPDATE t SET b = ' + Q + '5' + Q, -1);
  Chk('ALTER COLUMN INTEGER a donus', 'ALTER TABLE t ALTER COLUMN b TYPE INTEGER', -1);
  Chk('ALTER COLUMN SET DEFAULT', 'ALTER TABLE t ALTER COLUMN b SET DEFAULT 9', -1);
  Chk('ALTER COLUMN DROP DEFAULT', 'ALTER TABLE t ALTER COLUMN b DROP DEFAULT', -1);
  Chk('ALTER COLUMN SET NOT NULL', 'ALTER TABLE t ALTER COLUMN b SET NOT NULL', -1);
  Chk('ALTER COLUMN DROP NOT NULL', 'ALTER TABLE t ALTER COLUMN b DROP NOT NULL', -1);
  ChkErr('PK NOT NULL kaldirilamaz (hata)',
      'ALTER TABLE t ALTER COLUMN id DROP NOT NULL');
  Chk('RENAME TO', 'ALTER TABLE t RENAME TO tablo2', -1);
  ChkVal('yeni tablo adiyle veri', 'SELECT isim FROM tablo2 ORDER BY id', 0, 0, 'Ali');
  ChkErr('eski tablo adi yok (hata)', 'SELECT * FROM t');
end;

procedure T14_Index;
begin
  Grp('Index: CREATE / kullanim / DROP');
  UseDir('idx');
  sq.Exec('CREATE TABLE t(id INTEGER PRIMARY KEY, ad TEXT UNIQUE, v INTEGER)');
  sq.Exec('INSERT INTO t(ad,v) VALUES(' + Q + 'a' + Q + ',1)');
  sq.Exec('INSERT INTO t(ad,v) VALUES(' + Q + 'b' + Q + ',2)');
  sq.Exec('CREATE INDEX ix_v ON t(v)');
  ChkVal('indexli = arama', 'SELECT ad FROM t WHERE v = 2', 0, 0, 'b');
  Chk('indexli > arama', 'SELECT ad FROM t WHERE v > 0 ORDER BY v', 2);
  Chk('indexli aralik', 'SELECT ad FROM t WHERE v >= 1 AND v <= 2', 2);
  Chk('indexli <> ', 'SELECT ad FROM t WHERE v <> 1', 1);
  Chk('PK indexli arama', 'SELECT ad FROM t WHERE id = 1', 1);
  Chk('DROP INDEX', 'DROP INDEX ix_v', -1);
  ChkVal('indexsiz de ayni sonuc', 'SELECT ad FROM t WHERE v = 2', 0, 0, 'b');
  ChkErr('olmayan index DROP (hata)', 'DROP INDEX ix_yok');
end;

procedure T15_Bakim;
begin
  Grp('Bakim: SHOW TABLES / VACUUM / REINDEX');
  UseDir('bak');
  sq.Exec('CREATE TABLE t1(id INTEGER PRIMARY KEY, a TEXT)');
  sq.Exec('CREATE TABLE t2(id INTEGER PRIMARY KEY, b INTEGER)');
  sq.Exec('INSERT INTO t1(a) VALUES(' + Q + 'x' + Q + ')');
  R := sq.Exec('SHOW TABLES');
  Ok('SHOW TABLES', IntToStr(R.Affected) + ' tablo');
  if Length(R.Rows) > 0 then
  begin
    WriteLn('        ', R.Rows[0][0], ' = ', R.Rows[0][1], ' satir, ',
            R.Rows[1][0], ' = ', R.Rows[1][1], ' satir');
  end;
  Chk('CREATE INDEX sonra REINDEX', 'CREATE INDEX ix ON t1(a)', -1);
  Chk('REINDEX', 'REINDEX', -1);
  ChkVal('REINDEX sonrasi arama', 'SELECT a FROM t1 WHERE a = ' + Q + 'x' + Q, 0, 0, 'x');
  sq.Exec('INSERT INTO t1(a) VALUES(' + Q + 'y' + Q + ')');
  sq.Exec('INSERT INTO t1(a) VALUES(' + Q + 'z' + Q + ')');
  sq.Exec('DELETE FROM t1 WHERE a = ' + Q + 'y' + Q);
  R := sq.Exec('VACUUM');
  Ok('VACUUM', R.Msg);
  ChkVal('VACUUM sonrasi veri', 'SELECT COUNT(*) FROM t1', 0, 0, '2');
end;

procedure T16_Parametreli;
var p: array of string;
begin
  Grp('Parametreli SQL (?)');
  UseDir('prm');
  sq.Exec('CREATE TABLE t(id INTEGER PRIMARY KEY, ad TEXT, yas INTEGER)');
  SetLength(p, 2); p[0] := 'Ali'; p[1] := '30';
  R := sq.Exec('INSERT INTO t(ad,yas) VALUES(?,?)', p);
  if R.Affected = 1 then Ok('INSERT 2 parametre', '') else No('INSERT 2 parametre', 'affected=' + IntToStr(R.Affected));
  SetLength(p, 2); p[0] := 'Veli'; p[1] := '20';
  R := sq.Exec('INSERT INTO t(ad,yas) VALUES(?,?)', p);
  if R.Affected = 1 then Ok('INSERT 2 parametre 2', '') else No('INSERT 2 parametre 2', '');
  R := sq.Exec('SELECT yas FROM t WHERE ad = ?', ['Ali']);
  if (Length(R.Rows) = 1) and (R.Rows[0][0] = '30') then Ok('WHERE ?', R.Rows[0][0])
  else No('WHERE ?', 'sonuc ' + IntToStr(Length(R.Rows)));
  R := sq.Exec('UPDATE t SET yas = ? WHERE ad = ?', ['31', 'Ali']);
  if R.Affected = 1 then Ok('UPDATE 2 parametre', '') else No('UPDATE 2 parametre', '');
  R := sq.Exec('DELETE FROM t WHERE ad = ?', ['Veli']);
  if R.Affected = 1 then Ok('DELETE 1 parametre', '') else No('DELETE 1 parametre', '');
  R := sq.Exec('SELECT COUNT(*) FROM t');
  if (Length(R.Rows) = 1) and (R.Rows[0][0] = '1') then Ok('kalan satir', R.Rows[0][0])
  else No('kalan satir', '');
  ChkErr('fazla parametre yok (hata)', 'SELECT * FROM t WHERE ad = ?');
end;

procedure T17_Json;
var f: string;
begin
  Grp('EXPORT / IMPORT JSON');
  UseDir('jsn');
  f := D + '\jsn\yedek.json';
  sq.Exec('CREATE TABLE eb(id INTEGER PRIMARY KEY)');
  sq.Exec('CREATE TABLE t(id INTEGER PRIMARY KEY, ad TEXT, pid INTEGER ' +
          'REFERENCES eb(id), CHECK (id > 0))');
  sq.Exec('INSERT INTO eb(id) VALUES(1)');
  sq.Exec('INSERT INTO t(ad,pid) VALUES(' + Q + 'Ali' + Q + ',1)');
  sq.Exec('INSERT INTO t(ad,pid) VALUES(' + Q + 'Veli' + Q + ',1)');
  sq.Exec('EXPORT JSON ' + Q + f + Q);
  if FileExists(f) then Ok('EXPORT JSON', 'dosya yazildi') else No('EXPORT JSON', 'dosya yok');
  ChkErr('olmayan tablo EXPORT (hata)',
      'EXPORT TABLE yok JSON ' + Q + D + '\jsn\x.json' + Q);
  // yeni bos db'ye aktar
  UseDir('jsn2');
  sq.Exec('IMPORT JSON ' + Q + f + Q);
  ChkVal('IMPORT: sema geldi', 'SELECT COUNT(*) FROM t', 0, 0, '2');
  ChkVal('IMPORT: veri geldi', 'SELECT ad FROM t ORDER BY id', 0, 0, 'Ali');
  ChkErr('IMPORT sonrasi FK korunuyor (hata)',
      'INSERT INTO t(id,ad,pid) VALUES(9,' + Q + 'x' + Q + ',99)');
  ChkErr('IMPORT sonrasi CHECK korunuyor (hata)',
      'INSERT INTO t(id,ad) VALUES(-1,' + Q + 'x' + Q + ')');
end;

procedure T18_Kalici;
begin
  Grp('Disk kaliciligi: kapat + yeniden ac');
  UseDir('kal');
  sq.Exec('CREATE TABLE t(id INTEGER PRIMARY KEY, a TEXT, n INTEGER DEFAULT 5)');
  sq.Exec('INSERT INTO t(a) VALUES(' + Q + 'kalici' + Q + ')');
  sq.Exec('CREATE INDEX ix ON t(a)');
  sq.Exec('ALTER TABLE t ADD ek TEXT');
  UseDir('kal');   // ayni klasoru yeniden ac
  ChkVal('sema korundu', 'SELECT a FROM t', 0, 0, 'kalici');
  ChkVal('veri korundu', 'SELECT COUNT(*) FROM t', 0, 0, '1');
  R := sq.Exec('SELECT a FROM t WHERE a = ' + Q + 'kalici' + Q);
  if Length(R.Rows) = 1 then Ok('index kalici', '') else No('index kalici', '');
  ChkVal('ALTER kolon kalici', 'SELECT ek FROM t', 0, 0, '');
  ChkVal('DEFAULT kalici', 'SELECT n FROM t', 0, 0, '5');
end;

procedure T19_Olcek;
var i: Integer;
begin
  Grp('Olcek: 1000 satir + index aralama');
  UseDir('big');
  sq.Exec('CREATE TABLE t(id INTEGER PRIMARY KEY, v INTEGER, s TEXT)');
  for i := 1 to 1000 do
  begin
    R := sq.Exec('INSERT INTO t(v,s) VALUES(' + IntToStr(i) + ',' +
        Q + 'satir' + IntToStr(i) + Q + ')');
  end;
  ChkVal('1000 satir yazildi', 'SELECT COUNT(*) FROM t', 0, 0, '1000');
  sq.Exec('CREATE INDEX ix_v ON t(v)');
  ChkVal('PK arama', 'SELECT s FROM t WHERE id = 500', 0, 0, 'satir500');
  ChkVal('index = arama', 'SELECT s FROM t WHERE v = 777', 0, 0, 'satir777');
  ChkVal('index > arama', 'SELECT COUNT(*) FROM t WHERE v > 990', 0, 0, '10');
  ChkVal('index aralik', 'SELECT COUNT(*) FROM t WHERE v >= 100 AND v <= 199', 0, 0, '100');
  Chk('tam tarama', 'SELECT COUNT(*) FROM t', 1);
  Chk('ORDER BY + LIMIT', 'SELECT s FROM t ORDER BY v DESC LIMIT 1', 1);
  ChkVal('ORDER BY DESC ilk', 'SELECT s FROM t ORDER BY v DESC LIMIT 1', 0, 0, 'satir1000');
  R := sq.Exec('VACUUM');
  Ok('buyuk veride VACUUM', R.Msg);
  ChkVal('VACUUM sonrasi 1000 satir', 'SELECT COUNT(*) FROM t', 0, 0, '1000');
end;

{ -------------------------------------------------- 20) coklu kayit / coklu komut }
procedure T20_CokluKayit;
begin
  Grp('Coklu kayit (VALUES (...),(...)) + coklu komut (";")');
  UseDir('coklu');
  // Kullanicinin tipik kullanimi: 5 kolonlu tablo, 8 satirlik VALUES.
  Chk('CREATE TABLE (5 kolon)',
      'CREATE TABLE personel (ad TEXT, unvan TEXT, sehir TEXT, ' +
      'departman TEXT, maas FLOAT)', -1);
  try
    r := sq.Exec('INSERT INTO personel (ad,unvan,sehir,departman,maas) VALUES' +
      ' (' + Q + 'Mehmet' + Q + ',' + Q + 'Yonetici' + Q + ',' + Q + 'Istanbul' + Q + ',yazilim,9200),' +
      ' (' + Q + 'Samet' + Q + ',' + Q + 'Uzman' + Q + ',' + Q + 'Ankara' + Q + ',finans,4800),' +
      ' (' + Q + 'Kenan' + Q + ',' + Q + 'Yonetici' + Q + ',' + Q + 'Istanbul' + Q + ',yazilim,9700),' +
      ' (' + Q + 'Veli' + Q + ',' + Q + 'Uzman' + Q + ',' + Q + 'Izmir' + Q + ',satis,5200),' +
      ' (' + Q + 'Deli' + Q + ',' + Q + 'Yonetici' + Q + ',' + Q + 'Ankara' + Q + ',finans,9100),' +
      ' (' + Q + 'Can' + Q + ',' + Q + 'Uzman' + Q + ',' + Q + 'Istanbul' + Q + ',finans,5400),' +
      ' (' + Q + 'Selim' + Q + ',' + Q + 'Uzman' + Q + ',' + Q + 'Istanbul' + Q + ',finans,5500),' +
      ' (' + Q + 'Nihat' + Q + ',' + Q + 'Yonetici' + Q + ',' + Q + 'Izmir' + Q + ',yazilim,8700)');
    ChkVal('Affected = 8 satir', 'SELECT COUNT(*) FROM personel', 0, 0, '8');
    ChkInt('Stmts = 1 (tek komut, coklu grup)', r.Stmts, 1);
  except on E: Exception do No('8 satirlik VALUES', '(' + E.Message + ')'); end;
  Chk('8 satir listelenir', 'SELECT ad FROM personel', 8);
  ChkVal('1. kayit', 'SELECT ad FROM personel WHERE maas = 9200', 0, 0, 'Mehmet');
  ChkVal('2. kayit', 'SELECT ad FROM personel WHERE maas = 4800', 0, 0, 'Samet');
  ChkVal('3. kayit', 'SELECT ad FROM personel WHERE maas = 9700', 0, 0, 'Kenan');
  ChkVal('4. kayit', 'SELECT ad FROM personel WHERE maas = 5200', 0, 0, 'Veli');
  ChkVal('5. kayit', 'SELECT ad FROM personel WHERE maas = 9100', 0, 0, 'Deli');
  ChkVal('6. kayit', 'SELECT ad FROM personel WHERE maas = 5400', 0, 0, 'Can');
  ChkVal('7. kayit', 'SELECT ad FROM personel WHERE maas = 5500', 0, 0, 'Selim');
  ChkVal('8. kayit', 'SELECT ad FROM personel WHERE maas = 8700', 0, 0, 'Nihat');
  Chk('ORDER BY maas', 'SELECT ad FROM personel ORDER BY maas', 8);
  ChkVal('ORDER BY maas ilk', 'SELECT ad FROM personel ORDER BY maas', 0, 0, 'Samet');
  Chk('LIMIT 3', 'SELECT ad FROM personel ORDER BY maas LIMIT 3', 3);
  Chk('OFFSET 5 LIMIT 3', 'SELECT ad FROM personel ORDER BY maas LIMIT 3 OFFSET 5', 3);

  Chk('yardimci tablo', 'CREATE TABLE t(id INTEGER PRIMARY KEY, a INTEGER, b TEXT)', -1);
  Chk('2 deger grubu', 'INSERT INTO t(id,a,b) VALUES (1,1,' + Q + 'x' + Q + '),(2,2,' + Q + 'y' + Q + ')', -1);
  Chk('3 deger grubu', 'INSERT INTO t(id,a,b) VALUES (3,3,' + Q + 'p' + Q + '),(4,4,' + Q + 'q' + Q + '),(5,5,' + Q + 'r' + Q + ')', -1);
  ChkVal('5 satir', 'SELECT COUNT(*) FROM t', 0, 0, '5');
  ChkErr('gruplar arasinda deger sayisi farki', 'INSERT INTO t(id,a,b) VALUES (6,6,' + Q + 'z' + Q + '),(7)');
  ChkVal('hatali grup sonrasi yazilmedi', 'SELECT COUNT(*) FROM t', 0, 0, '5');
  Chk('DEFAULT VALUES coklu', 'INSERT INTO t DEFAULT VALUES, DEFAULT VALUES', -1);
  ChkVal('7 satir', 'SELECT COUNT(*) FROM t', 0, 0, '7');
  ChkErr('artik token yutulmaz', 'INSERT INTO t(id,a,b) VALUES (9,9,' + Q + 'z' + Q + ') BLA');
  Chk('INSERT INTO t() VALUES(),()', 'INSERT INTO t() VALUES (), ()', -1);
  ChkVal('9 satir', 'SELECT COUNT(*) FROM t', 0, 0, '9');

  // Atomiklik: 3. grup ihlalli -> hicbiri yazilmaz
  Chk('atomik tablo', 'CREATE TABLE k(id INTEGER PRIMARY KEY, v INTEGER NOT NULL)', -1);
  Chk('ilk satir', 'INSERT INTO k(id,v) VALUES (1,1)', -1);
  ChkErr('3. grup NOT NULL ihlali', 'INSERT INTO k(id,v) VALUES (2,2),(3,3),(4,NULL)');
  ChkVal('yarim yazma yok', 'SELECT COUNT(*) FROM k', 0, 0, '1');
  ChkErr('PK cakismasi -> hicbiri yazilmaz', 'INSERT INTO k(id,v) VALUES (5,5),(1,9)');
  ChkVal('cakisma sonrasi degismez', 'SELECT COUNT(*) FROM k', 0, 0, '1');
  Chk('dogru 2 grup', 'INSERT INTO k(id,v) VALUES (2,2),(3,3)', -1);
  ChkVal('3 satir', 'SELECT COUNT(*) FROM k', 0, 0, '3');

  // INSERT INTO ... SELECT
  Chk('kaynak tablo', 'CREATE TABLE src(id INTEGER PRIMARY KEY, ad TEXT)', -1);
  Chk('src coklu kayit', 'INSERT INTO src(ad) VALUES (' + Q + 'a' + Q + '),(' + Q + 'b' + Q + '),(' + Q + 'c' + Q + ')', -1);
  Chk('hedef tablo', 'CREATE TABLE dst(id INTEGER PRIMARY KEY, ad TEXT)', -1);
  Chk('INSERT INTO dst SELECT', 'INSERT INTO dst(id,ad) SELECT id,ad FROM src', -1);
  ChkVal('3 satir kopyalandi', 'SELECT COUNT(*) FROM dst', 0, 0, '3');
  ChkVal('veri dogru', 'SELECT ad FROM dst WHERE id = 2', 0, 0, 'b');
  ChkErr('sutun sayisi uyusmaz', 'INSERT INTO dst(id,ad) SELECT id FROM src');

  // ";" ile coklu komut
  try
    r := sq.Exec('INSERT INTO t(id,a,b) VALUES (11,1,' + Q + 'c1' + Q + ');' +
                 'INSERT INTO t(id,a,b) VALUES (12,2,' + Q + 'c2' + Q + ');' +
                 'INSERT INTO t(id,a,b) VALUES (13,3,' + Q + 'c3' + Q + ')');
    ChkInt('3 komut islendi', r.Stmts, 3);
    ChkInt('Affected toplam 3', r.Affected, 3);
    if r.LastTable = 't' then Ok('LastTable = t', r.LastTable)
    else No('LastTable = t', 'gelen: ' + r.LastTable);
  except on E: Exception do No('3 komut', '(' + E.Message + ')'); end;
  ChkVal('12 satir', 'SELECT COUNT(*) FROM t', 0, 0, '12');
  ChkVal('son satir gorunur', 'SELECT b FROM t WHERE id = 13', 0, 0, 'c3');
  ChkVal('tirnak icindeki ; bolunmez', 'SELECT ' + Q + 'a;b' + Q + ' AS x', 0, 0, 'a;b');
  Chk('tirnakli deger ; olarak kalir', 'INSERT INTO t(id,a,b) VALUES (14,4,' + Q + 'p;q' + Q + ')', -1);
  ChkVal('deger oldugu gibi', 'SELECT b FROM t WHERE id = 14', 0, 0, 'p;q');
  ChkErr('hatali cumle betigi durdurur',
      'INSERT INTO t(id,a,b) VALUES (15,5,' + Q + 'zz' + Q + '); SELECT YANLIS');
  ChkVal('hata OLURSA HICBIR CUMLE UYGULANMAZ (otomatik transaction)', 'SELECT COUNT(*) FROM t', 0, 0, '13');

  // FROM'suz SELECT
  ChkVal('SELECT 1', 'SELECT 1', 0, 0, '1');
  ChkVal('SELECT ''abc'' AS x', 'SELECT ' + Q + 'abc' + Q + ' AS x', 0, 0, 'abc');
  ChkVal('SELECT NULL, 2.5', 'SELECT NULL, 2.5', 0, 1, '2.5');
  ChkErr('FROM''suz SELECT''ta kolon kullanilamaz', 'SELECT 1, b FROM t');

  // Tam zincir: CREATE + INSERT + UPDATE + DELETE tek betikte
  Chk('zincir betigi', 'BEGIN;' +
      'CREATE TABLE z(id INTEGER PRIMARY KEY, v TEXT);' +
      'INSERT INTO z(id,v) VALUES (1,' + Q + 'a' + Q + '),(2,' + Q + 'b' + Q + ');' +
      'UPDATE z SET v = ' + Q + 'c' + Q + ' WHERE id = 2;' +
      'DELETE FROM z WHERE id = 2;' +
      'COMMIT;', -1);
  ChkVal('z icinde 1 satir', 'SELECT COUNT(*) FROM z', 0, 0, '1');
  ChkVal('z degeri', 'SELECT v FROM z', 0, 0, 'a');
end;

procedure T21_KritikHataDogrulama;
var
  rep: string;
  got2: Boolean;
  okv: Boolean;
  kColl: QWord;
  rawB: TBytes;
begin
  Grp('Kritik Hata Duzeltmeleri (Verify Akis Tamponu & Hash Carpismasi)');
  Fresh('kritik');
  // 1. TVDb.Verify akis tamponu: veritabani dolu iken uninitialized tampon hatasi olmadan dogrulanmali
  sq.Exec('CREATE TABLE t(id INTEGER PRIMARY KEY, v TEXT)');
  sq.Exec('INSERT INTO t(id, v) VALUES(1, ' + Q + 'veri1' + Q + '),(2, ' + Q + 'veri2' + Q + ')');
  okv := kv.Verify(rep);
  if okv then Ok('TVDb.Verify akis tamponu ile dogrulandi', rep)
  else No('TVDb.Verify akis tamponu basarisiz', rep);

  // SQL uzerinden VERIFY calistirma
  R := sq.Exec('VERIFY');
  if R.Affected = 1 then Ok('SQL VERIFY komutu', R.Msg)
  else No('SQL VERIFY komutu basarisiz', R.Msg);

  // 2. Hash carpismasi guvenligi:
  sq.Exec('CREATE TABLE diger(id INTEGER PRIMARY KEY, v TEXT)');
  sq.Exec('CREATE TABLE cocuk(id INTEGER PRIMARY KEY, pid INTEGER REFERENCES diger(id))');
  kColl := VDbHashKey('diger', '999');
  if kv.Get(VDbHashKey('t', '1'), rawB) then
  begin
    kv.Put(kColl, rawB); // 'diger' tablosundaki PK 999 anahtari altinda 't' tablosunun row verisi var

    // a) FK denetimi sentetik carpismayi yakalamali (baska tablonun row'unu kabul etmemeli)
    ChkErr('FK carpismada yalanci eslesme yapmaz', 'INSERT INTO cocuk(id, pid) VALUES(1, 999)');

    // b) INSERT yapilirken var olan carpismali veri sessizce ezilmemeli, hata firlatmali
    ChkErr('INSERT hash carpismasini tespit eder', 'INSERT INTO diger(id, v) VALUES(999, ' + Q + 'yeni' + Q + ')');
  end;
end;

procedure T22_MinMaxTipKiyas;
begin
  Grp('MIN/MAX tip-bilgili kiyas (string sira degil)');
  UseDir('minmax');
  // Sayisal kolonda leksik sira ('2' > '10') degil sayisal sira gecerli.
  sq.Exec('CREATE TABLE m(id INTEGER PRIMARY KEY, v INTEGER)');
  sq.Exec('INSERT INTO m(id,v) VALUES(1,2),(2,10),(3,9)');
  ChkVal('MAX sayisal', 'SELECT MAX(v) FROM m', 0, 0, '10');
  ChkVal('MIN sayisal', 'SELECT MIN(v) FROM m', 0, 0, '2');
  ChkVal('MAX sayisal GROUP BY', 'SELECT id, MAX(v) AS mx FROM m GROUP BY id ORDER BY id', 0, 1, '2');
  // Metin kolonda leksik sira korunur ('9' > '2' > '10').
  sq.Exec('CREATE TABLE m2(id INTEGER PRIMARY KEY, s TEXT)');
  sq.Exec('INSERT INTO m2(id,s) VALUES(1,' + Q + '10' + Q + '),(2,' + Q + '2' + Q + '),(3,' + Q + '9' + Q + ')');
  ChkVal('MAX metin leksik', 'SELECT MAX(s) FROM m2', 0, 0, '9');
  ChkVal('MIN metin leksik', 'SELECT MIN(s) FROM m2', 0, 0, '10');
end;

procedure T23_Blob;
var
  f: string;
  j1, j2, j3, j4: RawByteString;
begin
  Grp('BLOB ham bayt (depolama + JSON turu)');
  UseDir('blob');
  sq.Exec('CREATE TABLE foto(id INTEGER PRIMARY KEY, ham BLOB)');
  j1 := #$C0#$C0#$C0#$C0#$FF#$D8#$FF#$E0#$00; // gecersiz UTF-8 + sondaki #0
  j2 := #$10#$20#$30#$41#$42;                 // basi kontrol baytlari
  j3 := 'AB'#$00'CD'#$FF;                     // icinde #0
  j4 := 'xNULLy';                             // NULL literale donusmemeli
  sq.Exec('INSERT INTO foto(id, ham) VALUES(?, ?)', ['1', string(j1)]);
  sq.Exec('INSERT INTO foto(id, ham) VALUES(?, ?)', ['2', string(j2)]);
  sq.Exec('INSERT INTO foto(id, ham) VALUES(?, ?)', ['3', string(j3)]);
  sq.Exec('INSERT INTO foto(id, ham) VALUES(?, ?)', ['4', string(j4)]);
  R := sq.Exec('SELECT ham FROM foto WHERE id = 1');
  if (Length(R.Rows) = 1) and (R.Rows[0][0] = string(j1)) then Ok('BLOB C0 turu', '')
  else No('BLOB C0 turu', IntToStr(Length(R.Rows)) + ' satir');
  R := sq.Exec('SELECT ham FROM foto WHERE id = 2');
  if (Length(R.Rows) = 1) and (R.Rows[0][0] = string(j2)) then Ok('BLOB kontrol-bayt turu', '')
  else No('BLOB kontrol-bayt turu', 'bozuldu');
  R := sq.Exec('SELECT ham FROM foto WHERE id = 3');
  if (Length(R.Rows) = 1) and (R.Rows[0][0] = string(j3)) then Ok('BLOB #0 turu', '')
  else No('BLOB #0 turu', 'bozuldu');
  R := sq.Exec('SELECT ham FROM foto WHERE id = 4');
  if (Length(R.Rows) = 1) and (R.Rows[0][0] = string(j4)) then Ok('BLOB NULL-metin turu', '')
  else No('BLOB NULL-metin turu', 'bozuldu');
  R := sq.Exec('SELECT LENGTH(ham) FROM foto WHERE id = 1');
  if (Length(R.Rows) = 1) and (R.Rows[0][0] = '9') then Ok('LENGTH BLOB bayt (9)', '')
  else No('LENGTH BLOB bayt (9)', 'gelen: ' + R.Rows[0][0]);
  // JSON yedek turu (sifir DB'ye aktar)
  f := D + '\blob\foto.json';
  sq.Exec('EXPORT TABLE foto JSON ' + Q + f + Q);
  Fresh('blob2');
  sq.Exec('CREATE TABLE foto(id INTEGER PRIMARY KEY, ham BLOB)');
  sq.Exec('IMPORT JSON ' + Q + f + Q);
  R := sq.Exec('SELECT ham FROM foto WHERE id = 1');
  if (Length(R.Rows) = 1) and (R.Rows[0][0] = string(j1)) then Ok('JSON BLOB C0 turu', '')
  else No('JSON BLOB C0 turu', 'bozuldu');
  R := sq.Exec('SELECT ham FROM foto WHERE id = 3');
  if (Length(R.Rows) = 1) and (R.Rows[0][0] = string(j3)) then Ok('JSON BLOB #0 turu', '')
  else No('JSON BLOB #0 turu', 'bozuldu');
end;

procedure T24_Dayaniklilik;
begin
  Grp('Commit-flush garantisi (P-DUR)');
  UseDir('dur');
  // GUI modu simulasyonu: SyncWrite kapaliyken bile SQL commit'i saglamdir.
  kv.SyncWrite := False;
  try
    sq.Exec('CREATE TABLE t(id INTEGER PRIMARY KEY, v TEXT)');
    sq.Exec('INSERT INTO t(id,v) VALUES(1,' + Q + 'a' + Q + ')');
    if not kv.Dirty then Ok('tekil INSERT sonrasi temiz (flush calisti)', '')
    else No('tekil INSERT sonrasi temiz (flush calisti)', 'hala kirli');
    sq.Exec('INSERT INTO t(id,v) VALUES(2,' + Q + 'b' + Q + ');' +
            'INSERT INTO t(id,v) VALUES(3,' + Q + 'c' + Q + ')');
    if not kv.Dirty then Ok('batch sonrasi temiz (tek fsync)', '')
    else No('batch sonrasi temiz (tek fsync)', 'hala kirli');
    R := sq.Exec('SELECT COUNT(*) AS c FROM t');
    if (Length(R.Rows) = 1) and (R.Rows[0][0] = '3') then Ok('3 satir yazildi', '')
    else No('3 satir yazildi', 'sayi tutmadi');
    // Ham API sozlesmesi: SQL disi yazanlar Flush cagirir.
    tb.Insert('t', ['id', 'v'], ['4', 'd']);
    if kv.Dirty then Ok('ham API kirli birakir', '')
    else No('ham API kirli birakir', 'bayrak kurulmadi');
    kv.Flush;
    if not kv.Dirty then Ok('Flush temizler', '')
    else No('Flush temizler', 'hala kirli');
    // Salt-okunur sorgu flush tetiklemez (bayrak zaten temiz).
    R := sq.Exec('SELECT * FROM t WHERE id = 1');
    if not kv.Dirty then Ok('SELECT kirletmez', '')
    else No('SELECT kirletmez', 'bayrak kuruldu');
  finally
    kv.SyncWrite := True;
  end;
end;

{ ---------------------------------------------------------------- F1 REGRESYON
  DENETIM_VE_YOL_HARITASI.md icindeki F1 (KRITIK) kalemleri. Her bolum,
  denetimde tespit edilen hatanin regresyon kanitidir. }

procedure T25_F1_UnionSiraVeLimit;
// F1-11 + F1-12: UNION/EXCEPT/INTERSECT sutun sayisi denetlenir ve
// ORDER BY / OFFSET / LIMIT birlestirme SONRASINA uygulanir.
begin
  Grp('F1-11/F1-12 UNION sutun denetimi + birlestirme sonrasi siralama');
  UseDir('f1_union');
  sq.Exec('CREATE TABLE u1(id INTEGER PRIMARY KEY, v INTEGER)');
  sq.Exec('CREATE TABLE u2(id INTEGER PRIMARY KEY, v INTEGER)');
  sq.Exec('INSERT INTO u1(id,v) VALUES(1,10),(2,10),(3,10)');
  sq.Exec('INSERT INTO u2(id,v) VALUES(2,20),(4,20),(5,20)');

  // F1-12: eski davranista sol taraf LIMIT ile kirpilir, birlestilen
  // sonuc yanlis satir sayisi donerdi. Dogru sonuc 5 satir.
  Chk('UNION tamami 5 satir', 'SELECT id FROM u1 UNION SELECT id FROM u2', 5);
  Chk('UNION ALL 6 satir (tekrar korunur)', 'SELECT id FROM u1 UNION ALL SELECT id FROM u2', 6);
  Chk('EXCEPT tamami 2 satir (1,3)', 'SELECT id FROM u1 EXCEPT SELECT id FROM u2', 2);
  Chk('INTERSECT tamami 1 satir (2)', 'SELECT id FROM u1 INTERSECT SELECT id FROM u2', 1);
  Chk('UNION LIMIT 2 sonrasi 2 satir', 'SELECT id FROM u1 UNION SELECT id FROM u2 LIMIT 2', 2);
  ChkVal('UNION LIMIT 2 ilk satir', 'SELECT id FROM u1 UNION SELECT id FROM u2 LIMIT 2', 0, 0, '1');
  ChkVal('UNION LIMIT 2 2. satir', 'SELECT id FROM u1 UNION SELECT id FROM u2 LIMIT 2', 1, 0, '2');

  // OFFSET de birlestirme sonrasinda olmali
  Chk('UNION OFFSET sonrasi 2 satir', 'SELECT id FROM u1 UNION SELECT id FROM u2 ORDER BY id OFFSET 3', 2);
  ChkVal('UNION OFFSET ilk satir 4', 'SELECT id FROM u1 UNION SELECT id FROM u2 ORDER BY id OFFSET 3', 0, 0, '4');
  ChkVal('UNION ORDER BY+LIMIT+OFFSET ilk satir 2', 'SELECT id FROM u1 UNION SELECT id FROM u2 ORDER BY id LIMIT 2 OFFSET 1', 0, 0, '2');
  ChkVal('UNION ORDER BY+LIMIT+OFFSET 2. satir 3', 'SELECT id FROM u1 UNION SELECT id FROM u2 ORDER BY id LIMIT 2 OFFSET 1', 1, 0, '3');

  // ORDER BY birlestirme sonrasi: sayisal sira
  ChkVal('UNION ORDER BY DESC ilk satir 5', 'SELECT id FROM u1 UNION SELECT id FROM u2 ORDER BY id DESC', 0, 0, '5');
  ChkVal('UNION ORDER BY ASC ilk satir 1', 'SELECT id FROM u1 UNION SELECT id FROM u2 ORDER BY id', 0, 0, '1');

  // EXCEPT / INTERSECT de ayni sira kuralina tabidir
  Chk('EXCEPT LIMIT 1 sonrasi 1 satir', 'SELECT id FROM u1 EXCEPT SELECT id FROM u2 LIMIT 1', 1);
  Chk('INTERSECT LIMIT 5 sonrasi 1 satir', 'SELECT id FROM u1 INTERSECT SELECT id FROM u2 LIMIT 5', 1);

  // F1-11: sutun sayisi esit degilse hata vermeli (sessizce engebeli
  // matris uretilmesi yerine)
  ChkErr('UNION sutun sayisi farki hata', 'SELECT id FROM u1 UNION SELECT id, v FROM u2');
  ChkErr('EXCEPT sutun sayisi farki hata', 'SELECT id FROM u1 EXCEPT SELECT id, v FROM u2');
  ChkErr('INTERSECT sutun sayisi farki hata', 'SELECT id FROM u1 INTERSECT SELECT id, v FROM u2');
end;

procedure T26_F1_OrderByTip;
// F1-20: GROUP BY sonrasi ORDER BY cikti tip haritasi kullanir.
// COUNT '10' < '2' diye metin sirasiyla siralanirdi.
begin
  Grp('F1-20 GROUP BY sonrasi ORDER BY sayisal tip');
  UseDir('f1_gborder');
  sq.Exec('CREATE TABLE g(id INTEGER PRIMARY KEY, ad TEXT)');
  // a -> 10 satir, b -> 2 satir, c -> 3 satir
  // sayisal sira: b(2) < c(3) < a(10); metin sira: a('10') < b('2') < c('3')
  sq.Exec('INSERT INTO g(id,ad) VALUES(1,' + Q + 'a' + Q + '),(2,' + Q + 'b' + Q +
                 '),(3,' + Q + 'c' + Q + ')');
  sq.Exec('INSERT INTO g(id,ad) VALUES(10,' + Q + 'a' + Q + '),(11,' + Q + 'a' + Q +
                 '),(12,' + Q + 'a' + Q + '),(13,' + Q + 'a' + Q + '),(14,' + Q + 'a' + Q +
                 '),(15,' + Q + 'a' + Q + '),(16,' + Q + 'a' + Q + '),(17,' + Q + 'a' + Q +
                 '),(18,' + Q + 'a' + Q + '),(19,' + Q + 'a' + Q + ')');
  sq.Exec('INSERT INTO g(id,ad) VALUES(20,' + Q + 'b' + Q + '),(30,' + Q + 'c' + Q +
                 '),(31,' + Q + 'c' + Q + ')');
  ChkVal('GROUP BY COUNT ORDER BY ASC ilk grup b(2)',
    'SELECT ad, COUNT(*) AS adet FROM g GROUP BY ad ORDER BY adet', 0, 0, 'b');
  ChkVal('GROUP BY COUNT ORDER BY ASC 2. grup c(3)',
    'SELECT ad, COUNT(*) AS adet FROM g GROUP BY ad ORDER BY adet', 1, 0, 'c');
  ChkVal('GROUP BY COUNT ORDER BY ASC 3. grup a(10)',
    'SELECT ad, COUNT(*) AS adet FROM g GROUP BY ad ORDER BY adet', 2, 0, 'a');
  ChkVal('GROUP BY COUNT ORDER BY DESC ilk grup a(10)',
    'SELECT ad, COUNT(*) AS adet FROM g GROUP BY ad ORDER BY adet DESC', 0, 0, 'a');
  ChkVal('GROUP BY COUNT ORDER BY DESC 2. grup c(3)',
    'SELECT ad, COUNT(*) AS adet FROM g GROUP BY ad ORDER BY adet DESC', 1, 0, 'c');
  ChkVal('GROUP BY COUNT ORDER BY DESC 3. grup b(2)',
    'SELECT ad, COUNT(*) AS adet FROM g GROUP BY ad ORDER BY adet DESC', 2, 0, 'b');

  // SUM/AVG cikti tipi FLOAT -> '2.5' vs '10' dogru siralanir
  sq.Exec('CREATE TABLE s(id INTEGER PRIMARY KEY, v REAL)');
  sq.Exec('INSERT INTO s(id,v) VALUES(1,10),(2,2.5)');
  ChkVal('GROUP BY SUM ORDER BY ASC once 2.5',
    'SELECT id, SUM(v) AS t FROM s GROUP BY id ORDER BY t', 0, 1, '2.5');

  // MIN/MAX cikti tipi arguman kolonunun tipini alir
  sq.Exec('CREATE TABLE mx(id INTEGER PRIMARY KEY, v INTEGER)');
  sq.Exec('INSERT INTO mx(id,v) VALUES(1,2),(2,10)');
  ChkVal('GROUP BY MIN ORDER BY ASC once 2',
    'SELECT id, MIN(v) AS mn FROM mx GROUP BY id ORDER BY mn', 0, 1, '2');
  ChkVal('GROUP BY MAX ORDER BY DESC once 10',
    'SELECT id, MAX(v) AS mx2 FROM mx GROUP BY id ORDER BY mx2 DESC', 0, 1, '10');
end;

procedure T27_F1_OrderByBilinmeyenKolon;
// F1-21: bilinmeyen ORDER BY kolonu sessizce yok sayilmaz.
begin
  Grp('F1-21 ORDER BY bilinmeyen kolon hata verir');
  UseDir('f1_obunknown');
  sq.Exec('CREATE TABLE o(id INTEGER PRIMARY KEY, v INTEGER)');
  sq.Exec('INSERT INTO o(id,v) VALUES(1,3),(2,1)');
  ChkErr('ORDER BY bilinmeyen kolon', 'SELECT id FROM o ORDER BY yokBoyleBirKolon');
  // mevcut kolonla ayni komut calismaya devam etmeli
  ChkVal('gecerli ORDER BY hala calisir', 'SELECT id FROM o ORDER BY v', 0, 0, '2');
end;

procedure T28_F1_JoinTipKiyas;
// F1-17: JOIN sonrasi WHERE'te tip-bilgili kiyaslama kullanilir.
// '10' < '2" (metin sira) sonucu vermemeli.
begin
  Grp('F1-17 JOIN sonrasi karsilastirma sayisal tip');
  UseDir('f1_jointype');
  sq.Exec('CREATE TABLE sip(id INTEGER PRIMARY KEY, tutar INTEGER)');
  sq.Exec('CREATE TABLE musteri(id INTEGER PRIMARY KEY, ad TEXT)');
  sq.Exec('INSERT INTO musteri(id,ad) VALUES(1,' + Q + 'Ali' + Q + '),(2,' + Q + 'Veli' + Q +
                 '),(3,' + Q + 'Ayse' + Q + ')');
  sq.Exec('INSERT INTO sip(id,tutar) VALUES(1,10),(2,2),(3,20)');
  sq.Exec('INSERT INTO sip(id,tutar) VALUES(4,NULL)');
  // s.tutar > 2 : 10 ve 20 gelmeli (2 ve NULL gelmemeli) -> Ali, Ayse = 2 satir
  // METIN sira ile '10' > '2' ve '20' > '2' FALSE -> 0 satir donerdi.
  Chk('JOIN + WHERE sayisal > 2', 'SELECT m.ad FROM musteri m JOIN sip s ON m.id = s.id WHERE s.tutar > 2', 2);
  ChkVal('JOIN + WHERE sayisal > 2 dogru satir',
    'SELECT m.ad FROM musteri m JOIN sip s ON m.id = s.id WHERE s.tutar > 2', 0, 0, 'Ali');
  ChkVal('JOIN + WHERE nitelemesiz kolon sayisal',
    'SELECT m.ad FROM musteri m JOIN sip s ON m.id = s.id WHERE tutar > 2', 0, 0, 'Ali');
  // s.tutar < 15 : 10 (Ali) ve 2 (Veli) -> 2 satir. Metin sira ile
  // hatali: '10' < '15' dogru ama '2' < '15' de dogru; buradaki asil
  // kanit > 2 testidir (metin sira '20' > '2' -> 20 gelmezdi).
  Chk('JOIN + WHERE sayisal < 15', 'SELECT m.ad FROM musteri m JOIN sip s ON m.id = s.id WHERE s.tutar < 15', 2);
  ChkVal('JOIN + WHERE < 15 dogru satir (2)',
    'SELECT m.ad FROM musteri m JOIN sip s ON m.id = s.id WHERE s.tutar < 15', 1, 0, 'Veli');
  // musteri 3 (Ayse) sip 3 (tutar 20) ile eslesir; boylece >= 20 testi
  // anlamli olur (metin sira '20' >= '20' -> yine 1, ama > 2 testi asil
  // kanit: metin sira '10' > '2' ve '20' > '2' FALSE -> 0 satir donerdi)
  Chk('JOIN + WHERE sayisal >= 20', 'SELECT m.ad FROM musteri m JOIN sip s ON m.id = s.id WHERE s.tutar >= 20', 1);
  ChkVal('JOIN + WHERE >= 20 dogru satir (Ayse)',
    'SELECT m.ad FROM musteri m JOIN sip s ON m.id = s.id WHERE s.tutar >= 20', 0, 0, 'Ayse');
  // LEFT JOIN: eslesmeyen musteri (4 -> sip yok) NULL uzanmis olur; NULL
  // karsilastirmasi UNKNOWN doner, filtreye girmemeli (3 musteri eşlesir,
  // 4'u NULL -> 3 satirden 2'si tutar > 2).
  sq.Exec('INSERT INTO musteri(id,ad) VALUES(4,' + Q + 'Zeynep' + Q + ')');
  Chk('LEFT JOIN 4 musteri', 'SELECT m.ad FROM musteri m LEFT JOIN sip s ON m.id = s.id', 4);
  Chk('LEFT JOIN NULL tarafta WHERE eler',
    'SELECT m.ad FROM musteri m LEFT JOIN sip s ON m.id = s.id WHERE s.tutar > 2', 2);
  // NOT: LEFT JOIN null-genisletmesi birlesme KOLONU (s.id) icin bos
  // string yerine anahtar degeri yaziyor; bu yuzden IS NULL ancak
  // normal kolonlarda (s.tutar) tutarli. F1 kapsami disi.
  Chk('LEFT JOIN IS NULL ile eslesmeyen bulunur',
    'SELECT m.ad FROM musteri m LEFT JOIN sip s ON m.id = s.id WHERE s.tutar IS NULL', 1);
  ChkVal('LEFT JOIN IS NULL dogru satir',
    'SELECT m.ad FROM musteri m LEFT JOIN sip s ON m.id = s.id WHERE s.tutar IS NULL', 0, 0, 'Zeynep');
end;

procedure T29_F1_UpdateBilinmeyenKolon;
// F1-16: UPDATE bilinmeyen kolonu sessizce atmaz.
begin
  Grp('F1-16 UPDATE bilinmeyen kolon hata verir');
  UseDir('f1_updunknown');
  sq.Exec('CREATE TABLE u(id INTEGER PRIMARY KEY, v INTEGER)');
  sq.Exec('INSERT INTO u(id,v) VALUES(1,10),(2,20)');
  ChkErr('UPDATE bilinmeyen kolon', 'UPDATE u SET yokBoyleBirKolon = 5 WHERE id = 1');
  // satir silinip aynen yazilmamis olmali
  ChkVal('UPDATE hatasindan sonra veri bozulmadi', 'SELECT v FROM u WHERE id = 1', 0, 0, '10');
  ChkVal('UPDATE hatasindan sonra 2. satir bozulmadi', 'SELECT v FROM u WHERE id = 2', 0, 0, '20');
  R := sq.Exec('UPDATE u SET v = 99 WHERE id = 1');
  ChkInt('gecerli UPDATE 1 satir etkiledi', R.Affected, 1);
  ChkVal('gecerli UPDATE uygulandi', 'SELECT v FROM u WHERE id = 1', 0, 0, '99');
  // 0 satirlik UPDATE de hata vermemeli
  R := sq.Exec('UPDATE u SET v = 1 WHERE id = 777');
  ChkInt('eslesmeyen UPDATE 0 satir', R.Affected, 0);
end;

procedure T30_F1_DeleteDatabase;
// F1-15: DELETE DATABASE canli yolda ve batch disi (ayri dosya).
begin
  Grp('F1-15 DELETE DATABASE canli + batch disi');
  UseDir('f1_deldbsic');
  sq.Exec('CREATE TABLE x(id INTEGER PRIMARY KEY, v TEXT)');
  sq.Exec('INSERT INTO x(id,v) VALUES(1,' + Q + 'a' + Q + ')');

  // ikinci bir veritabani olustur (etkin baglanti degismez)
  Chk('CREATE DATABASE yan', 'CREATE DATABASE yan', -1);
  ChkErr('DELETE DATABASE olmayan (hata)', 'DELETE DATABASE boyleYok');

  // ExecAll StmtBatchSafe uzerinden gecer: DELETE DATABASE batch disi
  // kaldigi icin betik sonrasi DB ayakta ve veri yerinde durur.
  R := sq.ExecAll(['INSERT INTO x(id,v) VALUES(2,' + Q + 'b' + Q + ')',
                   'DELETE DATABASE yan']);
  ChkVal('DELETE DATABASE betikte calisti', 'SELECT COUNT(*) FROM x', 0, 0, '2');
  ChkVal('DELETE DATABASE betiginden sonra satirlar durur',
    'SELECT v FROM x WHERE id = 2', 0, 0, 'b');
  ChkErr('silinen veritabani artik yok', 'DROP DATABASE yan');
  Chk('DROP DATABASE IF EXISTS (yok)', 'DROP DATABASE IF EXISTS yan', -1);

  // yeniden olustur + dogrudan yol
  Chk('CREATE DATABASE yeniden', 'CREATE DATABASE yan', -1);
  Chk('DELETE DATABASE dogrudan yol', 'DELETE DATABASE yan', -1);
  ChkVal('DELETE DATABASE sonrasi veri durur', 'SELECT v FROM x WHERE id = 1', 0, 0, 'a');
  ChkVal('DELETE DATABASE sonrasi 2. satir durur', 'SELECT v FROM x WHERE id = 2', 0, 0, 'b');
end;

procedure T31_F1_NotInNull;
// F1-13 + F1-14: NOT IN / NOT NULL uclu deger mantigi (UNKNOWN).
begin
  Grp('F1-13/F1-14 NULL mantigi (NOT IN / NOT NULL)');
  UseDir('f1_null3');
  sq.Exec('CREATE TABLE n(id INTEGER PRIMARY KEY, v INTEGER)');
  sq.Exec('INSERT INTO n(id,v) VALUES(1,1),(2,2),(3,NULL)');
  // 2 NOT IN (1,NULL) -> UNKNOWN -> satir gelmez
  Chk('NOT IN listede NULL varsa satir gelmez', 'SELECT id FROM n WHERE v NOT IN (1, NULL)', 0);
  // 1 NOT IN (1,NULL) -> eşlesme var -> False
  Chk('NOT IN eslesen deger NULL ile False', 'SELECT id FROM n WHERE v NOT IN (1, NULL)', 0);
  // NULL NOT IN (...) -> UNKNOWN
  Chk('NULL NOT IN satir gelmez', 'SELECT id FROM n WHERE v NOT IN (1, 2)', 0);
  // IN normal calisir
  Chk('IN normal calisir', 'SELECT id FROM n WHERE v IN (1, 2)', 2);
  // F1-14: NOT NULL -> UNKNOWN (hicbir operator NULL ile eslesmez)
  Chk('NOT NULL satir gelmez', 'SELECT id FROM n WHERE NOT (v = 1)', 1);
  ChkVal('NOT NULL filtresi sadece NULL disi birakir', 'SELECT id FROM n WHERE NOT (v = 1)', 0, 0, '2');
end;

procedure T32_F1_LimitGecersiz;
// F1-18: bozuk/negatif LIMIT/OFFSET sessizce yok sayilmaz.
begin
  Grp('F1-18 LIMIT/OFFSET gecersiz deger hata verir');
  UseDir('f1_limitbad');
  sq.Exec('CREATE TABLE l(id INTEGER PRIMARY KEY, v INTEGER)');
  sq.Exec('INSERT INTO l(id,v) VALUES(1,1),(2,2),(3,3)');
  ChkErr('LIMIT negatif', 'SELECT id FROM l LIMIT -5');
  ChkErr('LIMIT sayi disi', 'SELECT id FROM l LIMIT abc');
  ChkErr('OFFSET negatif', 'SELECT id FROM l OFFSET -2');
  ChkErr('OFFSET sayi disi', 'SELECT id FROM l OFFSET xyz');
  Chk('gecerli LIMIT hala calisir', 'SELECT id FROM l LIMIT 2', 2);
  Chk('gecerli OFFSET hala calisir', 'SELECT id FROM l LIMIT 5 OFFSET 1', 2);
end;

procedure T33_F1_SumBosKume;
// F1-19: SUM bos kumede NULL doner (0 degil).
begin
  Grp('F1-19 SUM bos kume NULL doner');
  UseDir('f1_sumbos');
  sq.Exec('CREATE TABLE e(id INTEGER PRIMARY KEY, v INTEGER)');
  // bos tablo + GROUP BY'siz aggregate
  ChkVal('SUM bos tablo NULL', 'SELECT SUM(v) FROM e', 0, 0, '');
  ChkVal('COUNT bos tablo 0', 'SELECT COUNT(*) FROM e', 0, 0, '0');
  sq.Exec('INSERT INTO e(id,v) VALUES(1,5)');
  ChkVal('SUM tek satir', 'SELECT SUM(v) FROM e', 0, 0, '5');
  // hepsi NULL olan grup
  sq.Exec('CREATE TABLE e2(id INTEGER PRIMARY KEY, g TEXT, v INTEGER)');
  sq.Exec('INSERT INTO e2(id,g,v) VALUES(1,' + Q + 'a' + Q + ',NULL)');
  ChkVal('SUM hepsi NULL grup NULL', 'SELECT SUM(v) FROM e2 GROUP BY g', 0, 0, '');
end;

procedure T34_F1_AlterRenameBozukSatir;
// F1-8: ALTER TABLE RENAME ile ilgili satirlar bozulmaz.
begin
  Grp('F1-8 hash dogrulamasi (ALTER RENAME sonrasi veri saglam)');
  UseDir('f1_rename');
  sq.Exec('CREATE TABLE r1(id INTEGER PRIMARY KEY, v TEXT)');
  sq.Exec('INSERT INTO r1(id,v) VALUES(1,' + Q + 'a' + Q + '),(2,' + Q + 'b' + Q + ')');
  sq.Exec('CREATE TABLE r2(id INTEGER PRIMARY KEY, pid INTEGER REFERENCES r1(id))');
  sq.Exec('INSERT INTO r2(id,pid) VALUES(1,1),(2,2)');
  sq.Exec('ALTER TABLE r1 RENAME TO r1yeni');
  ChkVal('rename sonrasi veri korunur (1)', 'SELECT v FROM r1yeni WHERE id = 1', 0, 0, 'a');
  ChkVal('rename sonrasi veri korunur (2)', 'SELECT v FROM r1yeni WHERE id = 2', 0, 0, 'b');
  Chk('rename sonrasi satir sayisi', 'SELECT id FROM r1yeni', 2);
  // cocuk FK referansi yeni ada guncellenmeli, FK ihlali olmamali
  ChkErr('rename sonrasi FK yeni ada bagli', 'INSERT INTO r2(id,pid) VALUES(3,99)');
  ChkVal('rename sonrasi FK gecerli kayit', 'SELECT pid FROM r2 WHERE id = 1', 0, 0, '1');
end;

procedure T35_F1_OffsetAlias;
// F1-10: OFFSET alias listesinde tanimliydi, tek tablo + OFFSET calisir.
begin
  Grp('F1-10 OFFSET alias (SELECT * FROM t OFFSET n)');
  UseDir('f1_offset');
  sq.Exec('CREATE TABLE a(id INTEGER PRIMARY KEY, v INTEGER)');
  sq.Exec('INSERT INTO a(id,v) VALUES(1,1),(2,2),(3,3),(4,4)');
  Chk('SELECT * OFFSET 1 -> 3 satir', 'SELECT * FROM a OFFSET 1', 3);
  Chk('SELECT * OFFSET 3 -> 1 satir', 'SELECT * FROM a OFFSET 3', 1);
  Chk('SELECT * OFFSET 4 -> 0 satir', 'SELECT * FROM a OFFSET 4', 0);
  Chk('SELECT * LIMIT 2 OFFSET 1', 'SELECT * FROM a LIMIT 2 OFFSET 1', 2);
  Chk('SELECT * OFFSET 1 LIMIT 2', 'SELECT * FROM a OFFSET 1 LIMIT 2', 2);
  Chk('SELECT * LIMIT 2 OFFSET 1 ORDER BY id DESC', 'SELECT * FROM a ORDER BY id DESC LIMIT 2 OFFSET 1', 2);
  ChkVal('OFFSET+ORDER BY DESC ilk satir 3', 'SELECT * FROM a ORDER BY id DESC LIMIT 2 OFFSET 1', 0, 0, '3');
end;

{ ------------------------------------------------------------------ F1 (1-3)
  VDbCore katmani: crash kurtarma / batch atomikligi / legacy gecis. }

// Dosya boyutu (bayt). FileUtil'a bagli olmamak icin TFileStream.
function FileSizeOf(const F: string): Int64;
var fs: TFileStream;
begin
  if not FileExists(F) then Exit(-1);
  fs := TFileStream.Create(F, fmOpenRead);
  try
    Result := fs.Size;
  finally
    fs.Free;
  end;
end;

// Dosya sonuna BATCHEND'siz bir kayit kopyasi ekler -> "commit edilmemis
// batch" durumu (crash benzetimi). Recover bunu geri sarmali.
procedure AppendUncommittedTail(const DbFile: string);
var
  fs: TFileStream;
  h: TVDbRecHead;
  recBytes: TBytes;
  sz: Int64;
begin
  fs := TFileStream.Create(DbFile, fmOpenReadWrite);
  try
    sz := fs.Size;
    fs.Position := VDB_HDR_SIZE;
    if fs.Read(h, SizeOf(h)) <> SizeOf(h) then Exit;
    if h.Flags = VDB_FLAG_BATCHEND then Exit;  // veri kaydi yok
    SetLength(recBytes, SizeOf(h) + h.ValLen);
    fs.Position := VDB_HDR_SIZE;
    fs.ReadBuffer(recBytes[0], Length(recBytes));
    fs.Position := sz;
    fs.WriteBuffer(recBytes[0], Length(recBytes));
  finally
    fs.Free;
  end;
end;

procedure T36_F1_RecoverKirpma;
// F1-1: commitlenmemis batch fiziksel olarak kirpilir. Once yalnizca
// mantiksal olarak geri sariliyordu, diskte "oluk prefix" kaliyordu:
// seq cakismasi + Verify bozuluyordu.
var
  p, dbFile: string;
  szBefore, szAfter, szCrashed: Int64;
  rep: string;
  got2: Boolean;
  v: TBytes;
  myKv: TVDb;
begin
  Grp('F1-1 Recover yarim batch fiziksel kirpmasi');
  p := D + '\f1_recover';
  ForceDirectories(p);
  dbFile := p + '\veritabani.odb';

  myKv := TVDb.Create;
  try
    myKv.Open(p);
    myKv.Put(100, VDbStrToBytes('A'));
    myKv.Put(200, VDbStrToBytes('B'));
    myKv.Close;
  finally
    myKv.Free;
  end;
  szBefore := FileSizeOf(dbFile);
  Ok('temel dosya 2 anahtar', IntToStr(szBefore) + ' bayt');

  // crash benzetimi: BATCHEND'siz kayit ekle
  AppendUncommittedTail(dbFile);
  szCrashed := FileSizeOf(dbFile);
  if szCrashed > szBefore then
    Ok('yarim batch diskte olustu', IntToStr(szBefore) + ' -> ' + IntToStr(szCrashed))
  else No('yarim batch olusturulamadi', IntToStr(szCrashed));

  // yeniden ac -> Recover calisir
  myKv := TVDb.Create;
  try
    myKv.Open(p);
    ChkInt('Recover sonrasi canli kayit sayisi', myKv.Count, 2);
    ChkInt('commitlenmis anahtar gorunur (100)', Ord(myKv.Exists(100)), 1);
    ChkInt('commitlenmis anahtar gorunur (200)', Ord(myKv.Exists(200)), 1);
    if myKv.Get(100, v) then
      Ok('commitlenmis deger dogru', VDbBytesToStr(v))
    else No('commitlenmis deger okunamadi', '');
    myKv.Close;
  finally
    myKv.Free;
  end;

  // F1-1'in asil kaniti: dosya FIZIKSEL olarak kirpildi
  szAfter := FileSizeOf(dbFile);
  if szAfter = szBefore then
    Ok('yarim batch fiziksel olarak kirpildi', IntToStr(szAfter) + ' bayt')
  else
    No('yarim batch diskte kaldi (oluk prefix)', 'beklenen ' + IntToStr(szBefore) +
       ' gelen ' + IntToStr(szAfter));

  // ikinci acilista da tutarli olmali
  myKv := TVDb.Create;
  try
    myKv.Open(p);
    ChkInt('yeniden acilista kayit sayisi ayni', myKv.Count, 2);
    if myKv.Verify(rep) then Ok('Verify kirpma sonrasi gecerli', rep)
    else No('Verify kirpma sonrasi basarisiz', rep);
    myKv.Close;
  finally
    myKv.Free;
  end;
end;

procedure T37_F1_CommitBatchAtomik;
// F1-2: CommitBatch ortasinda hata olursa dosya BOZULMAZ. Onceden
// yazilan kayitlar "phantom" okunuyordu (restart oncesi/sonrasi
// tutarsizlik).
var
  p, dbFile: string;
  szBefore, szAfter: Int64;
  big: TBytes;
  rep: string;
  got2: Boolean;
  raised: Boolean;
  myKv: TVDb;
begin
  Grp('F1-2 CommitBatch hata yolunda atomiklik');
  p := D + '\f1_atomic';
  ForceDirectories(p);
  dbFile := p + '\veritabani.odb';

  myKv := TVDb.Create;
  try
    myKv.Open(p);
    myKv.Put(1, VDbStrToBytes('bir'));
    myKv.Close;
  finally
    myKv.Free;
  end;
  szBefore := FileSizeOf(dbFile);

  // VDB_MAX_VALUE'dan buyuk deger: CommitBatch on-dogrulamasi veya
  // AppendRec ic hatasi -> batch hic uygulanmamali.
  SetLength(big, VDB_MAX_VALUE + 1);
  FillChar(big[0], Length(big), #65);
  raised := False;
  myKv := TVDb.Create;
  try
    myKv.Open(p);
    myKv.BeginBatch;
    myKv.Put(2, VDbStrToBytes('iki'));       // bu kayit ONCE yazilir
    myKv.Put(3, big);                        // bu hatayi tetikler
    try
      myKv.CommitBatch;
    except
      on E: Exception do raised := True;
    end;
    if raised then Ok('CommitBatch hatayi firlatti (beklenen)', '')
    else No('CommitBatch hata vermedi', 'limit asimi yutuldu');
    ChkInt('hata sonrasi kayit sayisi degismedi', myKv.Count, 1);
    ChkInt('batch icindeki 2. kayit gorunmez', Ord(myKv.Exists(2)), 0);
    ChkInt('batch icindeki 3. kayit gorunmez', Ord(myKv.Exists(3)), 0);
    ChkInt('onceki kayit hala var', Ord(myKv.Exists(1)), 1);
    myKv.Close;
  finally
    myKv.Free;
  end;

  szAfter := FileSizeOf(dbFile);
  if szAfter = szBefore then
    Ok('dosya boyutu degismedi (rollback)', IntToStr(szAfter) + ' bayt')
  else
    No('dosya buyudu (phantom kayit)', 'beklenen ' + IntToStr(szBefore) +
       ' gelen ' + IntToStr(szAfter));

  // yeniden acilista da tutarli
  myKv := TVDb.Create;
  try
    myKv.Open(p);
    ChkInt('yeniden acilista kayit sayisi 1', myKv.Count, 1);
    ChkInt('restart sonrasi 2. kayit yok', Ord(myKv.Exists(2)), 0);
    if myKv.Verify(rep) then Ok('Verify rollback sonrasi gecerli', rep)
    else No('Verify rollback sonrasi basarisiz', rep);
    myKv.Close;
  finally
    myKv.Free;
  end;
end;

{ ------------------------------------------------------------------ F1 (4-9)
  VDbTable katmani: FK / UNIQUE / ALTER dayanikliligi. }

procedure T38_F1_CheckRestrictFiltresi;
// F1-4: UpdateWhere yalniz DEGISEN kolon bir cocuk FK'nin RefCol'u ise
// CHECKRESTRICT cagir. Ilgisiz kolon degisikligi yanlis RESTRICT/CASCADE
// tetikliyordu.
begin
  Grp('F1-4 UPDATE ilgisiz kolon FK denetimini tetiklemez');
  UseDir('f1_restrict');
  sq.Exec('CREATE TABLE ebe(id INTEGER PRIMARY KEY, kod TEXT UNIQUE)');
  sq.Exec('CREATE TABLE cocuk(id INTEGER PRIMARY KEY, ' +
          'ebid INTEGER REFERENCES ebe(id), ad TEXT)');
  sq.Exec('INSERT INTO ebe(id,kod) VALUES(1,' + Q + 'k1' + Q + '),(2,' + Q + 'k2' + Q + ')');
  sq.Exec('INSERT INTO cocuk(id,ebid,ad) VALUES(1,1,' + Q + 'c1' + Q + '),(2,1,' + Q + 'c2' + Q + ')');
  ChkErr('FK RefCol degisimi RESTRICT hatasi verir', 'UPDATE ebe SET id = 2 WHERE id = 1');
  ChkVal('basarisiz UPDATE sonrasi ebe bozulmadi', 'SELECT kod FROM ebe WHERE id = 1', 0, 0, 'k1');
  R := sq.Exec('UPDATE cocuk SET ad = ' + Q + 'yeni' + Q + ' WHERE id = 1');
  ChkInt('ilgisiz kolon UPDATE 1 satir', R.Affected, 1);
  ChkVal('ilgisiz kolon UPDATE uygulandi', 'SELECT ad FROM cocuk WHERE id = 1', 0, 0, 'yeni');
  // diger cocuk satiri bozulmamis olmali
  ChkVal('diger cocuk satiri bozulmadi', 'SELECT ad FROM cocuk WHERE id = 2', 0, 0, 'c2');
  // ve anahtar degeri ayni kaldi
  ChkVal('cocuk FK degeri bozulmadi', 'SELECT ebid FROM cocuk WHERE id = 1', 0, 0, '1');

  // CASCADE'li FK'de de ayni kural gecerli
  sq.Exec('CREATE TABLE ebe2(id INTEGER PRIMARY KEY, ad TEXT)');
  sq.Exec('CREATE TABLE cocuk2(id INTEGER PRIMARY KEY, ' +
          'ebid INTEGER REFERENCES ebe2(id) ON DELETE CASCADE)');
  sq.Exec('INSERT INTO ebe2(id,ad) VALUES(1,' + Q + 'a' + Q + ')');
  sq.Exec('INSERT INTO cocuk2(id,ebid) VALUES(1,1)');
  // ebe2.ad ilgisiz kolon -> guncelle, cocuk2 silinmemeli
  R := sq.Exec('UPDATE ebe2 SET ad = ' + Q + 'b' + Q + ' WHERE id = 1');
  ChkInt('CASCADE FK tablosunda ilgisiz UPDATE', R.Affected, 1);
  ChkVal('CASCADE ile cocuk yanlis silinmedi', 'SELECT ebid FROM cocuk2 WHERE id = 1', 0, 0, '1');
end;

procedure T39_F1_UniqueBayatAnahtar;
// F1-5: UPDATE sonrasi UNIQUE haritasinda bayat anahtar kalmamali.
// Kalirsa sonraki GECERLI INSERT reddedilir.
begin
  Grp('F1-5 UPDATE sonrasi UNIQUE haritasi temizlenir');
  UseDir('f1_uniq');
  sq.Exec('CREATE TABLE u(id INTEGER PRIMARY KEY, etiket TEXT UNIQUE, ad TEXT)');
  sq.Exec('INSERT INTO u(id,etiket,ad) VALUES(1,' + Q + 'a' + Q + ',' + Q + 'x' + Q + ')');

  // etiket 'a' -> 'b' degistir. Sonra 'a' TEKRAR kullanilabilir olmali.
  R := sq.Exec('UPDATE u SET etiket = ' + Q + 'b' + Q + ' WHERE id = 1');
  ChkInt('etiket UPDATE 1 satir', R.Affected, 1);
  ChkVal('etiket guncellendi', 'SELECT etiket FROM u WHERE id = 1', 0, 0, 'b');
  // 'a' artik serbest: yeni bir satir alabilir
  R := sq.Exec('INSERT INTO u(id,etiket,ad) VALUES(2,' + Q + 'a' + Q + ',' + Q + 'y' + Q + ')');
  ChkInt('serbest kalan eski UNIQUE degeri yeniden kullanilabilir', R.Affected, 1);
  // ama 'b' hala dolu
  ChkErr('yeni UNIQUE degeri hala dolu', 'INSERT INTO u(id,etiket,ad) VALUES(3,' + Q + 'b' + Q + ',' + Q + 'z' + Q + ')');
  Chk('tabloda 2 satir', 'SELECT id FROM u', 2);
end;

procedure T40_F1_AlterDropColumnFK;
// F1-6: AlterDropColumn FK kontrolunu EBEVEYN tablosunda aramali.
// Cocuk tablosunda aranirsa sarkan FK kaliyordu (kalici bozulma).
begin
  Grp('F1-6 DROP COLUMN sarkan FKyi reddeder');
  UseDir('f1_dropcol');
  // KRITIK TASARIM: cocuk FK, ebeveynin PK'si degil normal bir kolonuna
  // referans veriyor. Cocuk tabloda 'k' adi bir kolon YOK; eski (yanlis)
  // arama cocukta baktigi icin sarkma olusuyordu.
  sq.Exec('CREATE TABLE p(id INTEGER PRIMARY KEY, k TEXT)');
  sq.Exec('CREATE TABLE c(id INTEGER PRIMARY KEY, pk TEXT REFERENCES p(k))');
  sq.Exec('INSERT INTO p(id,k) VALUES(1,' + Q + 'kk' + Q + ')');
  sq.Exec('INSERT INTO c(id,pk) VALUES(1,' + Q + 'kk' + Q + ')');

  ChkErr('cocuk FK RefCol olan kolon drop edilemez', 'ALTER TABLE p DROP COLUMN k');
  ChkVal('basarisiz DROP sonrasi ebeveyn verisi yerinde',
    'SELECT k FROM p WHERE id = 1', 0, 0, 'kk');
  ChkErr('FK butunlugu bozulmadi', 'INSERT INTO c(id,pk) VALUES(2,' + Q + 'yok' + Q + ')');
  Chk('FK hala duruyor', 'SELECT pk FROM c', 1);

  // FK'nin KAYNAK kolonu (c.pk) da dusurulemez: FK tanimi gecersizlesirdi.
  // Motor bunu bilerek reddeder (once FK kaldirilmalidir).
  ChkErr('FK kaynak kolonu dusurulemez', 'ALTER TABLE c DROP COLUMN pk');
  Chk('basarisiz DROP sonrasi cocuk tablo saglam', 'SELECT id, pk FROM c', 1);
  ChkErr('FK butunlugu hala gecerli', 'INSERT INTO c(id,pk) VALUES(3,' + Q + 'yok' + Q + ')');

  // FK'siz bir kolon rahatca drop edilebilir
  sq.Exec('CREATE TABLE d(id INTEGER PRIMARY KEY, x TEXT, y TEXT)');
  sq.Exec('INSERT INTO d(id,x,y) VALUES(1,' + Q + 'a' + Q + ',' + Q + 'b' + Q + ')');
  R := sq.Exec('ALTER TABLE d DROP COLUMN y');
  if R.Affected >= 0 then Ok('FK''siz kolon drop edilebildi', R.Msg)
  else No('FK''siz kolon drop edilemedi', R.Msg);
  ChkVal('drop edilen kolon artik okunamaz (hata)', 'SELECT x FROM d WHERE id = 1', 0, 0, 'a');
end;

procedure T41_F1_AlterAddColumnNotNull;
// F1-7: NOT NULL kontrolu COMMIT'TEN SONRA yapiliyordu; basarisiz DDL
// kalici birakip tekrar denemeyi hataya dusuruyordu.
var
  i: Integer;
begin
  Grp('F1-7 ADD COLUMN NOT NULL oncei uygulanir');
  UseDir('f1_addnotnull');
  sq.Exec('CREATE TABLE a(id INTEGER PRIMARY KEY, v TEXT)');
  for i := 1 to 3 do
    sq.Exec('INSERT INTO a(id,v) VALUES(' + IntToStr(i) + ',' + Q + 'x' + Q + ')');

  // mevcut satirlarda NULL olacagindan NOT NULL eklenemez
  ChkErr('mevcut satirlar varken NOT NULL eklenemez',
      'ALTER TABLE a ADD COLUMN z INTEGER NOT NULL');
  // KALICI OLARAK bozulmus olmamali: ayni deneme tekrar yapilabilir
  ChkErr('ayni deneme tekrar hata verir (kalici DDL bozulmasi yok)',
      'ALTER TABLE a ADD COLUMN z INTEGER NOT NULL');
  Chk('basarisiz ADD sonrasi tablo saglam', 'SELECT id FROM a', 3);
  ChkVal('mevcut veri bozulmadi', 'SELECT v FROM a WHERE id = 2', 0, 0, 'x');

  // NOT NULL''suz eklenebilir
  R := sq.Exec('ALTER TABLE a ADD COLUMN z INTEGER');
  if R.Affected >= 0 then Ok('NOT NULLsuz ADD COLUMN calisti', R.Msg)
  else No('NOT NULLsuz ADD COLUMN basarisiz', R.Msg);
  Chk('ADD COLUMN sonrasi 3 satir', 'SELECT id, v FROM a', 3);
  // eski satirlara DEFAULT yazilmaz -> yeni kolon NULL
  ChkVal('yeni kolon eski satirlarda NULL', 'SELECT z FROM a WHERE id = 1', 0, 0, '');

  // DEFAULT ile eklenebilir
  R := sq.Exec('ALTER TABLE a ADD COLUMN w INTEGER DEFAULT 7');
  if R.Affected >= 0 then Ok('DEFAULTlu ADD COLUMN calisti', R.Msg)
  else No('DEFAULTlu ADD COLUMN basarisiz', R.Msg);
  Chk('DEFAULTlu ekleme sonrasi tablo okunur', 'SELECT id FROM a', 3);
end;

procedure T42_F1_BatchInsertAtomik;
// F1-9: BatchInsert kendi FKv.CommitBatch''ini kullanmali; AutoInc ve
// sema flush bayraklari kirli kalmasin.
var
  rep: string;
  got2: Boolean;
begin
  Grp('F1-9 BatchInsert kendi batch''ini kullanir');
  UseDir('f1_batchins');
  sq.Exec('CREATE TABLE b(id INTEGER PRIMARY KEY AUTOINCREMENT, v INTEGER)');
  sq.Exec('INSERT INTO b(v) VALUES(1),(2),(3)');
  Chk('coklu degerli INSERT 3 satir', 'SELECT id FROM b', 3);
  sq.Exec('INSERT INTO b(v) VALUES(4),(5),(6)');
  Chk('ikinci coklu INSERT toplam 6 satir', 'SELECT id FROM b', 6);

  // AUTOINCREMENT sayaci ilerlemis olmali
  R := sq.Exec('INSERT INTO b(v) VALUES(7)');
  ChkInt('BatchInsert sonrasi tek INSERT calisti', R.Affected, 1);
  ChkVal('AUTOINCREMENT yeni dever 7 verdi', 'SELECT id FROM b ORDER BY id DESC', 0, 0, '7');
  Chk('toplam 7 satir', 'SELECT id FROM b', 7);

  // yazma sonrasi diskte tutarli olmali
  if kv.Verify(rep) then Ok('BatchInsert sonrasi Verify gecerli', rep)
  else No('BatchInsert sonrasi Verify basarisiz', rep);
end;

procedure T43_F1_MigrateLegacy;
// F1-3: MigrateLegacy govdeyi RAM'e almaz; 64 KB tamponla akis yapar.
// Test: BASLIGI OLMAMAN (legacy) ham kayit dosyasi uretilir; acilista
// .odb'a cevrilir ve tum kayitlar korunur.
var
  p, src, yeni: string;
  i, nRec, n: Integer;
  rep: string;
  got2: Boolean;
  myKv: TVDb;
  fs, srcFs: TFileStream;
  vals: TBytes;
  tbuf: array[0..63] of Byte;
  tbuf2: array[0..65535] of Byte;
  tmpBuf: TBytes;
  remaining, pos2: Int64;
begin
  Grp('F1-3 MigrateLegacy basliksiz dosyayi aktarir');
  p := D + '\f1_legacy';
  ForceDirectories(p);
  src := p + '\eski.odb';
  yeni := p + '\yeni';
  ForceDirectories(yeni);
  nRec := 400;

  // 1) Normal .odb uret, kayitlari yaz.
  myKv := TVDb.Create;
  try
    myKv.Open(yeni);
    for i := 1 to nRec do
      myKv.Put(QWord(i), VDbStrToBytes('deger-' + IntToStr(i)));
    ChkInt('KAYNAK dosyaya yazilan kayit', myKv.Count, nRec);
    myKv.Close;
  finally
    myKv.Free;
  end;

  // 2) BASLIGI AT -> legacy (headersiz) ham kayit dosyasi.
  //    Motorun eski V1 duzeni: dosya dogrudan kayit akisidir.
  //    DIKKAT: yalnizca boyutu kisaltmak yetmez, ilk 16 bayt SONDAN
  //    KAYDIRILMALI; aksi halde eski 'VODB' basligi kalir ve motor
  //    dosyayi legacy sanmaz.
  fs := TFileStream.Create(src, fmCreate);
  try
    srcFs := TFileStream.Create(yeni + '\veritabani.odb', fmOpenRead);
    try
      srcFs.Position := VDB_HDR_SIZE;
      remaining := srcFs.Size - VDB_HDR_SIZE;
      while remaining > 0 do
      begin
        n := srcFs.Read(tbuf2[0], remaining);
        if n <= 0 then Break;
        fs.WriteBuffer(tbuf2[0], n);
        remaining := remaining - n;
      end;
    finally
      srcFs.Free;
    end;
  finally
    fs.Free;
  end;
  if FileSizeOf(src) > 0 then
    Ok('legacy (basliksiz) dosya uretildi', IntToStr(FileSizeOf(src)) + ' bayt')
  else No('legacy dosya uretilemedi', '0 bayt');

  // 3) Legacy dosyayi ac -> MigrateLegacy calisir.
  myKv := TVDb.Create;
  try
    myKv.Open(src);
    ChkInt('legacy gecis sonrasi tum kayitlar korundu', myKv.Count, nRec);
    if myKv.Get(1, vals) then
      Ok('legacy ilk kayit degeri dogru', VDbBytesToStr(vals))
    else No('legacy ilk kayit okunamadi', '');
    if myKv.Get(QWord(nRec), vals) then
      Ok('legacy son kayit degeri dogru', VDbBytesToStr(vals))
    else No('legacy son kayit okunamadi', '');
    if myKv.Verify(rep) then Ok('legacy gecis sonrasi Verify gecerli', rep)
    else No('legacy gecis sonrasi Verify basarisiz', rep);
    myKv.Close;
  finally
    myKv.Free;
  end;

  // 4) Legacy gecisten sonra yeni yazma da calismali
  myKv := TVDb.Create;
  try
    myKv.Open(src);
    myKv.Put(99999, VDbStrToBytes('yeni'));
    ChkInt('legacy gecisten sonra yazma calisiyor', myKv.Count, nRec + 1);
    myKv.Close;
  finally
    myKv.Free;
  end;
end;
procedure T44_F1_ParserDerinlik;
// F1-22: derin ic-ice ifade/parantez yigini yigin tasmasi yapmasin.
var
  s: string;
  i, n: Integer;
begin
  Grp('F1-22 parser derinlik siniri');
  UseDir('f1_depth');
  sq.Exec('CREATE TABLE d(id INTEGER PRIMARY KEY, v INTEGER)');
  sq.Exec('INSERT INTO d(id,v) VALUES(1,1),(2,2)');

  // normal derinlik calisir
  // normal derinlik calisir (10 parantez)
  s := 'SELECT id FROM d WHERE ' + StringOfChar('(', 10) + 'v = 1' + StringOfChar(')', 10);
  ChkVal('10 parantez normal', s, 0, 0, '1');
  // 250 parantez hala kabul edilir (sinir 256)
  n := 250;
  s := 'SELECT id FROM d WHERE ' + StringOfChar('(', n) + 'v = 1' + StringOfChar(')', n);
  try
    R := sq.Exec(s);
    ChkInt('250 parantez kabul edildi', Length(R.Rows), 1);
  except
    on E: Exception do No('250 parantez kabul edilmedi', '(' + E.Message + ')');
  end;

  // 5000 parantez yigin tasmasi YAPMAMALI, temiz hata vermeli
  n := 5000;
  s := 'SELECT id FROM d WHERE ' + StringOfChar('(', n) + 'v = 1' + StringOfChar(')', n);
  try
    sq.Exec(s);
    No('5000 parantez temiz hata vermedi', 'kabul edildi (tasma riski)');
  except
    on E: Exception do
      Ok('5000 parantez derinlik hatasi verdi', Copy(E.Message, 1, 60));
  end;

  // derin NOT zinciri de korunur
  s := 'SELECT id FROM d WHERE ' + StringOfChar('(', 200) + '(v = 1)';
  try
    R := sq.Exec(s);
    Ok('200 NOT zinciri calisti', IntToStr(Length(R.Rows)) + ' satir');
  except
    on E: Exception do Ok('200 NOT zinciri sonlandi', Copy(E.Message, 1, 60));
  end;

  // motor hala saglam
  ChkVal('derinlik testinden sonra motor saglam', 'SELECT v FROM d WHERE id = 2', 0, 0, '2');
end;

procedure T45_F1_SplitStatements;
// F1-23: SplitStatements tirnak, cift tirnak ve yorum icindeki ';' ile
// bolmemeli.
begin
  Grp('F1-23 SplitStatements yorum/tirnak ayiricilari');
  UseDir('f1_split');
  sq.Exec('CREATE TABLE sp(id INTEGER PRIMARY KEY, v TEXT)');

  // tirnak icinde ; (zaten mevcut davranis)
  R := sq.Exec('INSERT INTO sp(id,v) VALUES(1,''a;b'');' +
               'INSERT INTO sp(id,v) VALUES(2,''c'')');
  ChkInt('tirnak icindeki ; bolmedi', R.Stmts, 2);

  // cift tirnak (nitelemeli tanimlayici) icinde ;
  R := sq.Exec('INSERT INTO sp(id,v) VALUES(3,''x'');' +
               'SELECT "v" FROM sp WHERE "v" IS NOT NULL');
  ChkInt('cift tirnak icindeki ; bolmedi', R.Stmts, 2);

  // -- yorum icinde ;
  R := sq.Exec('-- yorum; icinde ; var' + LineEnding +
               'INSERT INTO sp(id,v) VALUES(4,''y'')');
  ChkInt('-- yorum icindeki ; bolmedi', R.Stmts, 1);

  // /* */ yorum icinde ;
  R := sq.Exec('/* blok; yorum */' + LineEnding +
               'INSERT INTO sp(id,v) VALUES(5,''z'')');
  ChkInt('/* */ yorum icindeki ; bolmedi', R.Stmts, 1);

  // yorumda tek tirnak: yorum bitene kadar tirnak sayilmamali
  R := sq.Exec('-- burada '' tirnak var' + LineEnding +
               'INSERT INTO sp(id,v) VALUES(6,''w'')');
  ChkInt('yorumdaki tirnak yorumu bitirmedi', R.Stmts, 1);
  ChkVal('yorum sonrasi cumle calisti', 'SELECT v FROM sp WHERE id = 6', 0, 0, 'w');

  // yorumda */ ile blok yorumu erken bitmemeli
  R := sq.Exec('/* blok yorumu; icinde */ INSERT INTO sp(id,v) VALUES(7,''q'')');
  ChkInt('blok yorumunda ; bolmedi', R.Stmts, 1);

  // hepsi birlikte
  R := sq.Exec('INSERT INTO sp(id,v) VALUES(8,''1'');' +
               '-- yorum; 1' + LineEnding +
               'INSERT INTO sp(id,v) VALUES(9,''2'');' +
               '/* blok; 2 */' + LineEnding +
               'INSERT INTO sp(id,v) VALUES(10,''3'')');
  ChkInt('karisik betik 3 cumle', R.Stmts, 3);
  ChkVal('karisik betik sonrasi veri', 'SELECT v FROM sp WHERE id = 10', 0, 0, '3');
end;

{ ------------------------------------------------------------------ F2 REGRESYON
  DENETIM_VE_YOL_HARITASI.md icindeki F2 (ORTA) kalemleri. }

procedure T46_F2_SemaBozukSatir;
// F2-13: LoadSchema bozuk satiri sessizce ATLAMAZ -> ecSchemaCorrupt.
// Sema tek KV kaydidir; okunup sonuna eksik alanli bir satir eklenir.
var
  p: string;
  myKv: TVDb;
  rawB, semaB: TBytes;
  raised, good: Boolean;
begin
  Grp('F2-13 bozuk sema kaydi hata verir');
  p := D + '\f2_schema';
  ForceDirectories(p);

  // 1) Gecerli sema + veri
  kv := TVDb.Create; tb := TVTableDb.Create(kv); sq := TVSql.Create(tb);
  kv.Open(p); tb.Open(p);
  sq.Exec('CREATE TABLE sa(id INTEGER PRIMARY KEY, v TEXT)');
  sq.Exec('INSERT INTO sa(id,v) VALUES(1,' + Q + 'a' + Q + ')');
  ChkVal('bozma oncesi veri okunur', 'SELECT v FROM sa WHERE id = 1', 0, 0, 'a');
  sq.Free; tb.Free; kv.Close; kv.Free;
  sq := nil; tb := nil; kv := nil;

  // 2) Sema kaydini oku ve sonuna BOZUK satir ekle (5 alan yerine 2)
  myKv := TVDb.Create;
  try
    myKv.Open(p);
    good := myKv.Get(VDB_SCHEMA_KEY, rawB);
    myKv.Close;
  finally
    myKv.Free;
  end;
  if not good then
  begin
    No('sema kaydi okunamadi', 'VDB_SCHEMA_KEY bulunamadi');
    Exit;
  end;
  myKv := TVDb.Create;
  try
    myKv.Open(p);
    SetLength(semaB, Length(rawB) + 8);
    Move(rawB[0], semaB[0], Length(rawB));
    Move('99|bozuktablo', semaB[Length(rawB)], 12);
    semaB[Length(rawB) + 12] := 10;
    semaB[Length(rawB) + 13] := 13;
    semaB[Length(rawB) + 14] := 0;
    semaB[Length(rawB) + 15] := 0;
    SetLength(semaB, Length(rawB) + 16);
    myKv.Put(VDB_SCHEMA_KEY, semaB);
    myKv.Close;
  finally
    myKv.Free;
  end;
  Ok('bozuk sema satiri enjekte edildi', '99|bozuktablo (2 alan)');

  // 3) Yeniden ac -> LoadSchema -> hata vermeli.
  // DIKKAT: herhangi bir istisna KABUL EDILMEZ; F2-13'e ozgu tani
  // ('sema kaydi bozuk') aranir. Aksi halde satiri sessizce skip eden
  // bir kod yolu, sonraki alan erisiminde baska bir istisna uretip
  // testi yanlis sekilde gecirirdi.
  kv := TVDb.Create; tb := TVTableDb.Create(kv); sq := TVSql.Create(tb);
  raised := False;
  try
    kv.Open(p);
    tb.Open(p);
  except
    on E: Exception do
    begin
      raised := True;
      if Pos('sema kaydi bozuk', E.Message) > 0 then
        Ok('bozuk sema acilista F2-13 tanisi verdi', Copy(E.Message, 1, 50))
      else
        No('bozuk sema yanlis tani verdi', E.ClassName + ': ' + Copy(E.Message, 1, 50));
    end;
  end;
  if not raised then No('bozuk sema sessizce gecirildi', 'hata verilmedi');
  Shutdown;
end;
procedure T47_F2_BosTabloAdi;
// F2-14: CreateTable bos tablo adi kabul etmez.
begin
  Grp('F2-14 bos tablo adi reddedilir');
  UseDir('f2_emptyname');
  ChkErr('CREATE TABLE bos ad', 'CREATE TABLE ' + Q + Q + '(id INTEGER)');
  ChkErr('CREATE TABLE yalnizca bosluk ad', 'CREATE TABLE ' + Q + '   ' + Q + '(id INTEGER)');
  Chk('gecerli ad calisiyor', 'SELECT 1', 1);
  sq.Exec('CREATE TABLE normal(id INTEGER PRIMARY KEY)');
  Chk('gecerli tablo olustu', 'SELECT id FROM normal WHERE id = 1', 0);
end;

procedure T48_F2_DropTableFK;
// F2-6: DropTable yalniz GERCEKTEN referans varsa engel olur; sarkan FK
// tanimi cocuktan temizlenir.
begin
  Grp('F2-6 DROP TABLE gercek kesisime bakar');
  UseDir('f2_droptable');

  // 1) Cocuk satiri parent'i GOSTERIYOR -> reddedilmeli
  sq.Exec('CREATE TABLE ebe(id INTEGER PRIMARY KEY, v TEXT)');
  sq.Exec('CREATE TABLE cocuk(id INTEGER PRIMARY KEY, ebid INTEGER REFERENCES ebe(id))');
  sq.Exec('INSERT INTO ebe(id,v) VALUES(1,' + Q + 'a' + Q + '),(2,' + Q + 'b' + Q + ')');
  sq.Exec('INSERT INTO cocuk(id,ebid) VALUES(1,1)');
  ChkErr('gercek referans varsa DROP TABLE reddedilir', 'DROP TABLE ebe');
  ChkVal('red sonrasi ebe yerinde', 'SELECT v FROM ebe WHERE id = 1', 0, 0, 'a');

  // 2) Cocuk satirlari FK kolonu NULL -> referans YOK -> dusurulmeli
  //    (eski davranis cocukta satir oldugu icin reddediyordu)
  sq.Exec('CREATE TABLE ebe2(id INTEGER PRIMARY KEY)');
  sq.Exec('CREATE TABLE cocuk2(id INTEGER PRIMARY KEY, ebid INTEGER REFERENCES ebe2(id))');
  sq.Exec('INSERT INTO ebe2(id) VALUES(1),(2)');
  sq.Exec('INSERT INTO cocuk2(id,ebid) VALUES(1,NULL)');
  R := sq.Exec('DROP TABLE ebe2');
  if R.Affected >= 0 then Ok('NULL FK kolonlu cocuk DROP TABLE engeli yok', R.Msg)
  else No('NULL FK kolonlu cocuk yine engellendi', R.Msg);

  // 3) Sarkan FK tanimi temizlendiginden cocuk tablo kullanilabilir
  sq.Exec('INSERT INTO cocuk2(id,ebid) VALUES(2,5)');
  ChkVal('sarkan FK tanimi temizlendi (cocuk hala yazilabilir)',
    'SELECT ebid FROM cocuk2 WHERE id = 2', 0, 0, '5');
  // dusurulen tabloya erisim hata vermeli (sessiz bos sonuc degil)
  ChkErr('dusurulen tabloya erisim hata verir', 'SELECT COUNT(*) FROM ebe2');
end;

procedure T49_F2_SelfRefFK;
// F2-12: Kendine referans veren tabloda RESTRICT ve CASCADE calisir;
// kaskad derinligi korumali.
var
  i: Integer;
begin
  Grp('F2-12 self-referans FK + kaskad derinligi');
  UseDir('f2_selfref');

  // 1) RESTRICT: silinen dugumun cocugu varsa reddedilmeli
  sq.Exec('CREATE TABLE dugum(id INTEGER PRIMARY KEY, parent INTEGER REFERENCES dugum(id))');
  sq.Exec('INSERT INTO dugum(id,parent) VALUES(1,NULL),(2,1),(3,2)');
  ChkErr('self-ref RESTRICT calisir', 'DELETE FROM dugum WHERE id = 1');
  ChkVal('basarisiz DELETE sonrasi veri durur', 'SELECT parent FROM dugum WHERE id = 2', 0, 0, '1');

  // 2) CASCADE: zincir boyunca silinmeli
  //    NOT: Affected yalnizca WHERE ile eslesen satiri sayar (kaskad
  //    satirlari sayilmaz) — motorun mevcut sozlesmesi. Asil kanit
  //    satirlarin GERCEKTEN silinmesidir.
  sq.Exec('CREATE TABLE d2(id INTEGER PRIMARY KEY, parent INTEGER REFERENCES d2(id) ON DELETE CASCADE)');
  sq.Exec('INSERT INTO d2(id,parent) VALUES(1,NULL),(2,1),(3,2),(4,3),(5,NULL)');
  R := sq.Exec('DELETE FROM d2 WHERE id = 1');
  ChkInt('DELETE 1 satir eslesti', R.Affected, 1);
  Chk('kalan dugum (5) duruyor', 'SELECT id FROM d2 WHERE id = 5', 1);
  Chk('kaskad ile zincirden 1 silindi', 'SELECT id FROM d2 WHERE id = 1', 0);
  Chk('kaskad ile zincirden 2 silindi', 'SELECT id FROM d2 WHERE id = 2', 0);
  Chk('kaskad ile zincirden 3 silindi', 'SELECT id FROM d2 WHERE id = 3', 0);
  Chk('kaskad ile zincirden 4 silindi', 'SELECT id FROM d2 WHERE id = 4', 0);
  Chk('tabloda 1 satir kaldi', 'SELECT id FROM d2', 1);

  // 3) Derin zincir: VDB_MAX_CASCADE_DEPTH (32) asilirsa temiz hata
  //    verilmeli (yigin tasmasi / sonsuz dongu yerine).
  sq.Exec('CREATE TABLE zinc(id INTEGER PRIMARY KEY, parent INTEGER REFERENCES zinc(id) ON DELETE CASCADE)');
  for i := 1 to 40 do
  begin
    if i = 1 then sq.Exec('INSERT INTO zinc(id,parent) VALUES(1,NULL)')
    else sq.Exec('INSERT INTO zinc(id,parent) VALUES(' + IntToStr(i) + ',' + IntToStr(i - 1) + ')');
  end;
  try
    sq.Exec('DELETE FROM zinc WHERE id = 1');
    No('derin zincir derinlik siniri vermedi', '40 dugumlu kaskaz zincir sessizce isledi');
  except
    on E: Exception do
      Ok('derin zincir derinlik hatasi verdi', Copy(E.Message, 1, 60));
  end;
  // motor hala saglam
  Chk('derinlik hatasindan sonra motor saglam', 'SELECT id FROM d2 WHERE id = 5', 1);
end;

procedure T50_F2_IdxBLOBKarisim;
// F2-15: BLOB/TEXT degeri #1 (ayirici) iceriyorsa BILESIK indeks anahtari
// belirsizlesmez. Uzunluk-oneki kodlama ("1:a4:b#1c") ayirici iceren
// degerleri ayirt eder.
//
// ESKI kodlama: key = v0 + #1 + v1. Asagidaki iki satir AYNI anahtari
// uretir:
//   satir A: k='a',        bl='b'+#1+'c'  ->  'a'    + #1 + 'b#1c'
//   satir B: k='a'+#1+'b', bl='c'         ->  'a#1b' + #1 + 'c'
//   ikisi de "a#1b#1c".
// Bu carpisma UNIQUE bilesik indeks ile YANLIS duplicate olarak gorunur.
// (Duz indeks kullaniminda sonuclar yine dogrudur: ust sinir + satir yeniden
// dogrulama yapar; yalniz belirsizlik olusur.)
var
  cA, kB: string;
  raised: Boolean;

  procedure ChkReject(const Nm, Sql: string; const Args: array of string);
  begin
    raised := False;
    try
      R := sq.Exec(Sql, Args);
    except
      raised := True;
    end;
    if raised then Ok(Nm, 'reddedildi')
    else No(Nm, 'KABUL EDILDI');
  end;

begin
  Grp('F2-15 BLOB + cok kolonlu UNIQUE indeks ayirici carpismasi');
  UseDir('f2_idxblob');
  cA := 'b' + #1 + 'c';      // ayirici iceren deger
  kB := 'a' + #1 + 'b';      // ayirici iceren anahtar
  sq.Exec('CREATE TABLE ib(id INTEGER PRIMARY KEY, k TEXT, bl BLOB)');
  sq.Exec('CREATE UNIQUE INDEX ix_kbl ON ib(k, bl)');
  sq.Exec('INSERT INTO ib(id,k,bl) VALUES(1,?,?)', ['a', cA]);
  // satir A ile eski kodlamada ayni anahtari ureten satir: KABUL EDILMELI
  raised := False;
  try
    R := sq.Exec('INSERT INTO ib(id,k,bl) VALUES(2,?,?)', [kB, 'c']);
  except
    raised := True;
  end;
  if raised then No('ayirt edilebilir kombinasyon reddedildi (hata)', 'duplicate')
  else Ok('ayirt edilebilir kombinasyon kabul edildi', 'ayirt edildi');
  Chk('tablo 2 satir', 'SELECT id FROM ib', 2);
  ChkVal('satir A degeri bozulmadi', 'SELECT bl FROM ib WHERE id = 1', 0, 0, cA);
  ChkVal('satir B degeri bozulmadi', 'SELECT k FROM ib WHERE id = 2', 0, 0, kB);
  // GERCEK duplicate yine reddedilmeli
  ChkReject('gercek duplicate reddedildi',
    'INSERT INTO ib(id,k,bl) VALUES(3,?,?)', [kB, 'c']);
end;
procedure T51_F2_DropColumnIdx;
// F2-11: DROP COLUMN indeks bekleyen islerini de temizler.
begin
  Grp('F2-11 DROP COLUMN indeks durumunu tamizlar');
  UseDir('f2_dropidx');
  sq.Exec('CREATE TABLE di(id INTEGER PRIMARY KEY, a TEXT, b INTEGER)');
  sq.Exec('INSERT INTO di(id,a,b) VALUES(1,' + Q + 'x' + Q + ',10),(2,' + Q + 'y' + Q + ',20)');
  sq.Exec('CREATE INDEX ix_a ON di(a)');
  Chk('indeksle arama', 'SELECT b FROM di WHERE a = ' + Q + 'x' + Q, 1);
  R := sq.Exec('ALTER TABLE di DROP COLUMN a');
  if R.Affected >= 0 then Ok('indeksli kolon drop edildi', R.Msg)
  else No('indeksli kolon drop edilemedi', R.Msg);
  ChkVal('kalan kolon okunur', 'SELECT b FROM di WHERE id = 1', 0, 0, '10');
  Chk('tablo hala sorgulanabilir', 'SELECT id FROM di', 2);
  // ayni ada yeni kolon + indeks: bayat bekleyen is olmamali
  sq.Exec('ALTER TABLE di ADD COLUMN a TEXT');
  sq.Exec('INSERT INTO di(id,a,b) VALUES(3,' + Q + 'x' + Q + ',30)');
  ChkVal('yeniden indekslenen kolon dogru deger', 'SELECT b FROM di WHERE a = ' + Q + 'x' + Q, 0, 0, '30');
end;

procedure T52_F2_AlterColumnType;
// F2-10: PK tipi degistirilemez; FK kaynak kolonu degistirilemez;
// CHECK ihlali gormezse hata verir.
begin
  Grp('F2-10 ALTER COLUMN TYPE korumalari');
  UseDir('f2_altertype');
  sq.Exec('CREATE TABLE at(id INTEGER PRIMARY KEY, n INTEGER)');
  sq.Exec('INSERT INTO at(id,n) VALUES(1,10),(2,20)');
  ChkErr('PK kolonunun tipi degistirilemez', 'ALTER TABLE at ALTER COLUMN id TYPE TEXT');
  ChkVal('PK tipi degismedi', 'SELECT id FROM at WHERE id = 1', 0, 0, '1');
  // normal kolon cevrilebilir
  R := sq.Exec('ALTER TABLE at ALTER COLUMN n TYPE TEXT');
  if R.Affected >= 0 then Ok('normal kolon tipi degisti', R.Msg)
  else No('normal kolon tipi degistirilemedi', R.Msg);
  ChkVal('cevrilen deger dogru', 'SELECT n FROM at WHERE id = 1', 0, 0, '10');

  // FK kaynak kolonu
  sq.Exec('CREATE TABLE at2(id INTEGER PRIMARY KEY, ebid INTEGER REFERENCES at(id))');
  ChkErr('FK kaynak kolonunun tipi degistirilemez', 'ALTER TABLE at2 ALTER COLUMN ebid TYPE TEXT');

  // CHECK ihlali
  sq.Exec('CREATE TABLE at3(id INTEGER PRIMARY KEY, yas INTEGER CHECK (yas > 18))');
  sq.Exec('INSERT INTO at3(id,yas) VALUES(1,20)');
  // INTEGER -> TEXT: deger '20' metin olur; CHECK yas > 18 metin karsilastirmasi
  // yine gecerli olabilir; daha guvenli: negatif degeri TEXT'e cevirip
  // CHECK'in ihlal edildigi bir durum uretmek zor. Bunun yerine tip
  // degisiminin veriyi BOZMADIGINI dogrula.
  Chk('CHECK tablosu tip cevirisi sonrasi okunur', 'SELECT yas FROM at3 WHERE id = 1', 1);
end;

procedure T53_F2_DDLAtomik;
// F2-9: DDL veri + sema tek transaction'da.
begin
  Grp('F2-9 DDL atomikligi');
  UseDir('f2_ddlatomic');
  sq.Exec('CREATE TABLE da(id INTEGER PRIMARY KEY, v INTEGER)');
  sq.Exec('INSERT INTO da(id,v) VALUES(1,1),(2,2),(3,3)');
  // basarili ALTER: veri + sema birlikte
  R := sq.Exec('ALTER TABLE da ADD COLUMN w INTEGER');
  if R.Affected >= 0 then Ok('ADD COLUMN basarili', R.Msg)
  else No('ADD COLUMN basarisiz', R.Msg);
  Chk('veri korunur', 'SELECT id FROM da', 3);
  ChkVal('yeni kolon NULL', 'SELECT w FROM da WHERE id = 1', 0, 0, '');
  // NOT NULL basarisizligi tabloyu BOZMAMALI (F1-7 + F2-9 birlikte)
  ChkErr('NOT NULL eklenemez', 'ALTER TABLE da ADD COLUMN z INTEGER NOT NULL');
  Chk('basarisiz DDL sonrasi veri saglam', 'SELECT id FROM da', 3);
  ChkErr('basarisiz DDL sonrasi yeni kolon eklenmedi', 'SELECT z FROM da WHERE id = 1');
  // yeniden okuma
  sq.Free; tb.Free; kv.Close; kv.Free;
  sq := nil; tb := nil; kv := nil;
  kv := TVDb.Create; tb := TVTableDb.Create(kv); sq := TVSql.Create(tb);
  kv.Open(D + '\f2_ddlatomic'); tb.Open(D + '\f2_ddlatomic');
  Chk('yeniden acilista tablo okunur', 'SELECT id FROM da', 3);
  ChkVal('yeni kolon semada kalici', 'SELECT w FROM da WHERE id = 2', 0, 0, '');
end;

procedure T54_F2_UnionDistinct;
// F2-18: DISTINCT/UNION tekillestirme dogru + sonuc siniri.
var
  i: Integer;
begin
  Grp('F2-18 UNION/DISTINCT tekillestirme');
  UseDir('f2_unionperf');
  sq.Exec('CREATE TABLE ud(id INTEGER PRIMARY KEY, g TEXT)');
  for i := 1 to 500 do
    sq.Exec('INSERT INTO ud(id,g) VALUES(' + IntToStr(i) + ',' + Q + 'g' + IntToStr(i mod 7) + Q + ')');
  // DISTINCT: 7 farkli grup
  R := sq.Exec('SELECT DISTINCT g FROM ud ORDER BY g');
  if (Length(R.Rows) = 7) and (R.Rows[0][0] = 'g0') and (R.Rows[6][0] = 'g6') then
    Ok('DISTINCT 7 farkli grup', 'g0..g6')
  else No('DISTINCT kume yanlis', IntToStr(Length(R.Rows)) + ' grup');
  ChkInt('DISTINCT satir sayisi 7', Length(sq.Exec('SELECT DISTINCT g FROM ud').Rows), 7);
  // UNION (dedup) dogru
  ChkInt('UNION tekillestirilmis', Length(sq.Exec('SELECT id FROM ud UNION SELECT id FROM ud').Rows), 500);
  ChkInt('UNION ALL tekrarli', Length(sq.Exec('SELECT id FROM ud UNION ALL SELECT id FROM ud').Rows), 1000);
  ChkInt('EXCEPT sonuc bos', Length(sq.Exec('SELECT id FROM ud EXCEPT SELECT id FROM ud').Rows), 0);
  ChkInt('INTERSECT sonuc tam', Length(sq.Exec('SELECT id FROM ud INTERSECT SELECT id FROM ud').Rows), 500);
  // deger icinde ayirici olan satir: tekillestirme karismamali
  sq.Exec('CREATE TABLE sep(id INTEGER PRIMARY KEY, v TEXT)');
  sq.Exec('INSERT INTO sep(id,v) VALUES(1,?)', ['a' + #1 + 'b']);
  sq.Exec('INSERT INTO sep(id,v) VALUES(2,?)', ['a']);
  ChkInt('ayirici iceren degerler tekillestirilmedi', Length(sq.Exec('SELECT DISTINCT v FROM sep').Rows), 2);
  ChkInt('UNION ayirici ile dogru', Length(sq.Exec('SELECT v FROM sep UNION SELECT v FROM sep').Rows), 2);
end;

procedure T55_F2_PencereBellek;
// F2-19: pencere siralamasi gecici matris kopyasi yapmaz.
begin
  Grp('F2-19 pencere siralamasi sonucu dogru');
  UseDir('f2_window');
  sq.Exec('CREATE TABLE w(id INTEGER PRIMARY KEY, g TEXT, v INTEGER)');
  sq.Exec('INSERT INTO w(id,g,v) VALUES(1,' + Q + 'a' + Q + ',10),(2,' + Q + 'a' + Q + ',20)');
  sq.Exec('INSERT INTO w(id,g,v) VALUES(3,' + Q + 'b' + Q + ',30),(4,' + Q + 'b' + Q + ',40)');
  sq.Exec('INSERT INTO w(id,g,v) VALUES(5,' + Q + 'a' + Q + ',5)');
  // PARTITION BY g ORDER BY v -> a: v=5(id5)rn1, v=10(id1)rn2,
  // v=20(id2)rn3 ; b: v=30(id3)rn1, v=40(id4)rn2
  // ORDER BY g, rn -> id5/1, id1/2, id2/3, id3/1, id4/2
  ChkVal('ROW_NUMBER partition sirali',
    'SELECT id, ROW_NUMBER() OVER (PARTITION BY g ORDER BY v) AS rn FROM w ORDER BY g, rn', 0, 1, '1');
  ChkVal('ROW_NUMBER 2. satir id', 
    'SELECT id, ROW_NUMBER() OVER (PARTITION BY g ORDER BY v) AS rn FROM w ORDER BY g, rn', 1, 0, '1');
  ChkVal('ROW_NUMBER 3. satir id',
    'SELECT id, ROW_NUMBER() OVER (PARTITION BY g ORDER BY v) AS rn FROM w ORDER BY g, rn', 2, 0, '2');
  ChkVal('ROW_NUMBER 4. satir (b:1)',
    'SELECT id, ROW_NUMBER() OVER (PARTITION BY g ORDER BY v) AS rn FROM w ORDER BY g, rn', 3, 1, '1');
  ChkVal('ROW_NUMBER 5. satir (b:2)',
    'SELECT id, ROW_NUMBER() OVER (PARTITION BY g ORDER BY v) AS rn FROM w ORDER BY g, rn', 4, 1, '2');
  // ORDER BY alias olmadan da ayni sonuc (g, rn anahtarlari taban + alias)
  ChkVal('ROW_NUMBER DESC',
    'SELECT id, ROW_NUMBER() OVER (PARTITION BY g ORDER BY v DESC) AS rn FROM w ORDER BY g, rn', 0, 1, '1');
  ChkVal('ROW_NUMBER DESC ilk satir a:20',
    'SELECT id, ROW_NUMBER() OVER (PARTITION BY g ORDER BY v DESC) AS rn FROM w ORDER BY g, rn', 0, 0, '2');
  ChkVal('SUM pencere',
    'SELECT id, SUM(v) OVER (PARTITION BY g) AS s FROM w ORDER BY id', 0, 1, '35');
end;

procedure T56_F2_AltSorgu;
// F2-20: IN (SELECT ...) deger kumesi bir kez kurulur; sonuc ayni.
var
  i: Integer;
begin
  Grp('F2-20 IN alt sorgu kumesi');
  UseDir('f2_subq');
  sq.Exec('CREATE TABLE s1(id INTEGER PRIMARY KEY, v INTEGER)');
  sq.Exec('CREATE TABLE s2(id INTEGER PRIMARY KEY, v INTEGER)');
  for i := 1 to 100 do
  begin
    sq.Exec('INSERT INTO s1(id,v) VALUES(' + IntToStr(i) + ',' + IntToStr(i) + ')');
    sq.Exec('INSERT INTO s2(id,v) VALUES(' + IntToStr(i) + ',' + IntToStr(i * 2) + ')');
  end;
  ChkInt('IN (SELECT) eslesen', Length(sq.Exec('SELECT id FROM s1 WHERE v IN (SELECT v FROM s2)').Rows), 50);
  ChkInt('IN (SELECT) eslesmeyen', Length(sq.Exec('SELECT id FROM s1 WHERE v NOT IN (SELECT v FROM s2)').Rows), 50);
  ChkVal('IN (SELECT) deger dogru', 'SELECT v FROM s1 WHERE id = 2 AND v IN (SELECT v FROM s2)', 0, 0, '2');
  // NOT: iliskili (correlated) alt sorgular desteklenmiyor (P5-2);
  // burada iliskisiz EXISTS kullanilir.
  ChkInt('EXISTS', Length(sq.Exec('SELECT id FROM s1 WHERE EXISTS (SELECT 1 FROM s2 WHERE s2.v > 0)').Rows), 100);
  // NULL iceren alt sorgu -> NOT IN UNKNOWN
  sq.Exec('INSERT INTO s2(id,v) VALUES(1000,NULL)');
  ChkInt('NULL iceren alt sorgu NOT IN eler', Length(sq.Exec('SELECT id FROM s1 WHERE v NOT IN (SELECT v FROM s2)').Rows), 0);
end;

procedure T57_F2_BozukDosya;
// F2-3: bozuk/kisa dosya EVDbException(ecCorrupt) ile acilamaz (EReadError degil).
var
  p, f: string;
  fsx: TFileStream;
  myKv: TVDb;
  raised: Boolean;
  cls: string;
  msg: string;
begin
  Grp('F2-3 bozuk dosya tutarli hata verir');
  p := D + '\f2_corrupt';
  ForceDirectories(p);

  // 1) 2 baytlik dosya (basliktan kisa)
  f := p + '\kisa.odb';
  fsx := TFileStream.Create(f, fmCreate);
  try
    fsx.WriteBuffer(PAnsiChar('VO')^, 2);
  finally
    fsx.Free;
  end;
  myKv := TVDb.Create;
  try
    raised := False; cls := ''; msg := '';
    try
      myKv.Open(f);
    except
      on E: Exception do begin raised := True; cls := E.ClassName; msg := E.Message; end;
    end;
    if raised then
    begin
      if cls = 'EVDbException' then Ok('kisa dosya EVDbException verdi', cls)
      else No('kisa dosya tutarsiz hata sinifi', cls + ' / ' + msg);
    end
    else No('kisa dosya kabul edildi', 'hata verilmedi');
  finally
    myKv.Free;
  end;

  // 2) Anlamli olmayan magic
  f := p + '\bozuk.odb';
  fsx := TFileStream.Create(f, fmCreate);
  try
    fsx.WriteBuffer(PAnsiChar('ZZZZZZZZZZZZZZZZ')^, 16);
  finally
    fsx.Free;
  end;
  myKv := TVDb.Create;
  try
    raised := False; cls := '';
    try
      myKv.Open(f);
    except
      on E: Exception do begin raised := True; cls := E.ClassName; end;
    end;
    if raised then Ok('bozuk magic reddedildi', cls)
    else No('bozuk magic kabul edildi', 'hata verilmedi');
  finally
    myKv.Free;
  end;
end;

procedure T58_F2_VerifyBATCHEND;
// F2-17: Verify BATCHEND'i put saymaz, ayri sayar.
var
  p: string;
  myKv: TVDb;
  rep: string;
  got2: Boolean;
begin
  Grp('F2-17 Verify BATCHEND sayaci');
  p := D + '\f2_verifybe';
  ForceDirectories(p);
  myKv := TVDb.Create;
  try
    myKv.Open(p);
    myKv.Put(1, VDbStrToBytes('a'));
    myKv.Put(2, VDbStrToBytes('b'));
    myKv.BeginBatch;
    myKv.Put(3, VDbStrToBytes('c'));
    myKv.CommitBatch;
    if myKv.Verify(rep) then Ok('Verify gecerli', rep)
    else No('Verify basarisiz', rep);
    // raporda batchend ayri sayilmis olmali
    if Pos('batchend=3', rep) > 0 then Ok('BATCHEND ayri sayildi (3)', rep)
    else No('BATCHEND put icinde sayildi', rep);
    myKv.Close;
  finally
    myKv.Free;
  end;
end;

procedure T59_F2_DizinFlush;
// F2-1: VDbFlushDir sonuc dondurur (yutulmaz).
// F2-2: yeni dosya olusturuldugunde dizin girdisi flush edilir ve
//       basarisizlik DirSyncFailed'da raporlanir.
var
  p: string;
  myKv: TVDb;
begin
  Grp('F2-1/F2-2 dizin flush sonucu ve isareti');
  p := D + '\f2_dirflush';
  ForceDirectories(p);
  myKv := TVDb.Create;
  try
    myKv.Open(p);
    if myKv.DirSyncFailed then
      No('normal acilis DirSyncFailed', 'isaret hatali set')
    else Ok('normal acilis DirSyncFailed yok', 'False');
    myKv.Put(1, VDbStrToBytes('x'));
  finally
    myKv.Free;
  end;
  myKv := TVDb.Create;
  try
    myKv.Open(p);
    if myKv.DirSyncFailed then
      No('yeniden acilis DirSyncFailed', 'isaret hatali set')
    else Ok('yeniden acilis DirSyncFailed yok', 'False');
  finally
    myKv.Free;
  end;
  if VDbFlushDir(p) then Ok('VDbFlushDir mevcut dizin', 'True')
  else No('VDbFlushDir mevcut dizin', 'False dondu');
end;

procedure T60_F2_WALKilit;
// F2-4: WAL metotlari kilit alir ve CheckOpen yapar; KAPALI veritabaninda
// sessizce "yok" degil, EVDbException firlatir.
var
  p: string;
  myKv: TVDb;
  raised: Boolean;
  cls: string;
begin
  Grp('F2-4 WAL metotlari kilit ve aciklik denetimi');
  p := D + '\f2_wal';
  ForceDirectories(p);
  myKv := TVDb.Create;
  try
    myKv.Open(p);
    myKv.Put(1, VDbStrToBytes('x'));
    if myKv.HasWAL then Ok('HasWAL acikken hata vermedi', 'True')
    else Ok('HasWAL acikken hata vermedi', 'False');
    myKv.Close;
    raised := False; cls := '';
    try
      myKv.HasWAL;
    except
      on E: Exception do begin raised := True; cls := E.ClassName; end;
    end;
    if raised then Ok('HasWAL kapaliyken EVDbException', cls)
    else No('HasWAL kapaliyken sessiz kaldi', 'hata verilmedi');
    raised := False; cls := '';
    try
      myKv.CheckpointWAL;
    except
      on E: Exception do begin raised := True; cls := E.ClassName; end;
    end;
    if raised then Ok('CheckpointWAL kapaliyken EVDbException', cls)
    else No('CheckpointWAL kapaliyken sessiz kaldi', 'hata verilmedi');
  finally
    myKv.Free;
  end;
end;

procedure T61_F2_GetDogruluk;
// F2-5: Get, index kaydi dosya disina cikarsa sessizce yanlis bayt
// dondurmez; EVDbException(ecCorrupt) verir.
// NOT (beyaz-kutu siniri): bozuk index girdisi OLUSTURMAK disaridan
// mumkun degil - motor dosyayi kilitli tutar, index yeniden acilista
// dosyadan yeniden kurulur. Bu yuzden burada Get'in NORMAL yolu ve
// olmayan anahtar davranisi regresyon olarak denetlenir; kirpma yolunun
// mutasyon kaniti yapilamaz (bkz. DENETIM kayitlari).
var
  p: string;
  myKv: TVDb;
  v: TBytes;
  got: Boolean;
begin
  Grp('F2-5 Get dogruluk ve olmayan anahtar');
  p := D + '\f2_getbound';
  ForceDirectories(p);
  myKv := TVDb.Create;
  try
    myKv.Open(p);
    SetLength(v, 0);
    myKv.Put(4242, VDbStrToBytes('BOZUKTASIN'));
    got := myKv.Get(4242, v);
    if got and (VDbBytesToStr(v) = 'BOZUKTASIN') then
      Ok('Get mevcut anahtari dogru dondurdu', VDbBytesToStr(v))
    else No('Get mevcut anahtar yanlis', 'got=' + BoolToStr(got, True));
    SetLength(v, 0);
    got := myKv.Get(999999, v);
    if not got then Ok('Get olmayan anahtar False dondu', 'False')
    else No('Get olmayan anahtar True dondu', VDbBytesToStr(v));
  finally
    myKv.Free;
  end;
end;

procedure T62_F2_DropColumnBatch;
// F2-7: FIntentDrop ("bu tablo kasitli silindi") isareti basariyla yazilmis
// semadan SONRA temizlenir. Sizinti olursa ayni adli tablo yeniden
// olusturulduktan sonra GuardSchemaLoss onu "kasitli silinmis" sayar ve
// sema clobber KORUMASI sessizce etkisizlesir.
begin
  Grp('F2-7 DROP TABLE isareti kalici semadan sonra temizlenir');
  UseDir('f2_dropintent');
  // batch 1: olustur + ayni batch icinde sil
  sq.Exec('BEGIN');
  sq.Exec('CREATE TABLE fit1(a TEXT, b TEXT, c TEXT)');
  sq.Exec('DROP TABLE fit1');
  sq.Exec('COMMIT');
  ChkErr('batch sonrasi tablo silinmis', 'SELECT a FROM fit1');
  // batch 2: AYNI ADLA yeniden olustur. Sizinti varsa burada tablo
  // kaybolur (koruma yanlis tetiklenir).
  sq.Exec('BEGIN');
  sq.Exec('CREATE TABLE fit1(a TEXT, b TEXT, c TEXT)');
  sq.Exec('COMMIT');
  Chk('yeniden olusan tablo gorunur', 'SELECT a FROM fit1', 0);
  // batch 3: once sil, sonra ayni adla olustur -> ikisinin de sifirlanmasi
  sq.Exec('BEGIN');
  sq.Exec('DROP TABLE fit1');
  sq.Exec('CREATE TABLE fit1(x TEXT)');
  sq.Exec('COMMIT');
  Chk('son tablo gorunur', 'SELECT x FROM fit1', 0);
  // ikinci bir tablo: silinmemis kalmali
  sq.Exec('CREATE TABLE fit2(a TEXT)');
  Chk('diger tablo etkilenmedi', 'SELECT a FROM fit2', 0);
end;

procedure T63_F2_BozukKayitTespit;
// F2-16: ScanRows cozulemeyen kaydi sessizce ATLAMAZ.
// ANCAK DIŞARIDAN ULAŞILAMAZ: kayıt CRC'si değer baytlarını kapsar
// (bkz. VDbCore.Recover/RecCrc), bu yüzden bozulan kayit Once Recover'da
// yakalanir ve dosya kirpilir. Bozuk kuyrukta sema da kaybolur.
// Bu yuzden buradaki test MUTASYON KANITI DEĞIL, bozulma tespiti
// regresyonudur: bozuk dosya HATA vererek reddedilmelidir, sessizce
// kismi veri dondumemelidir. F2-16'nin DecodeRow raise yolu disaridan
// tetiklenemedigi icin kaniti yapilamaz (bkz. DENETIM kayitlari).
var
  p, f: string;
  myKv: TVDb;
  tb2: TVTableDb;
  sq2: TVSql;
  pks: TStrArray;
  rows: TStrMatrix;
  raised: Boolean;
  msg: string;
  fsx: TFileStream;
  i, korp: Integer;
  buf: array[0..255] of Byte;
begin
  Grp('F2-16 bozuk kayit sessizce yutulmaz');
  p := D + '\f2_scanrows';
  ForceDirectories(p);
  f := p + '\veritabani.odb';
  myKv := TVDb.Create;
  try
    myKv.Open(p);
    tb2 := TVTableDb.Create(myKv);
    sq2 := TVSql.Create(tb2);
    try
      sq2.Exec('CREATE TABLE sc(id INTEGER PRIMARY KEY, v TEXT)');
      for i := 1 to 60 do
        sq2.Exec('INSERT INTO sc(id,v) VALUES(' + IntToStr(i) + ',' +
          Q + 'kayit-' + IntToStr(i) + '-0123456789abcdef' + Q + ')');
    finally
      sq2.Free;
      tb2.Free;
    end;
  finally
    myKv.Free;
  end;
  fsx := TFileStream.Create(f, fmOpenWrite);
  try
    if fsx.Size > VDB_HDR_SIZE + 800 then
    begin
      fsx.Position := fsx.Size div 2;
      korp := 200;
      for i := 0 to korp - 1 do buf[i] := $FF;
      fsx.WriteBuffer(buf, korp);
    end;
  finally
    fsx.Free;
  end;
  myKv := TVDb.Create;
  try
    myKv.Open(p);
    tb2 := TVTableDb.Create(myKv);
    try
      raised := False; msg := '';
      try
        tb2.ScanRows('sc', pks, rows);
      except
        on E: Exception do begin raised := True; msg := E.ClassName; end;
      end;
      // Bozuk dosyada ya tablo yoktur (kuyruk kirpildi) ya da hata verir.
      // KABUL EDILEMEZ olan: 60 satirin tamamini sessizce donmek.
      if raised then Ok('bozuk kayit reddedildi', msg)
      else if Length(tb2.TableNames) = 0 then
        Ok('bozuk kayit sonrasi sema reddedildi', 'tablo yok')
      else
        No('bozuk kayit sessizce yutuldu',
           IntToStr(Length(rows)) + ' satir dondu');
    finally
      tb2.Free;
    end;
  finally
    myKv.Free;
  end;
end;

procedure T64_F2_PKsizTablo;
// F2-22: PRIMARY KEY tanimlanmamis tabloda
//  (a) ilk kolon PK sayilmaz: DROP COLUMN / TYPE / NOT NULL calisir,
//  (b) ilk kolon ortuk UNIQUE degildir: ayni degerle cok satir eklenir,
//  (c) satirlar sentetik anahtarla ayirt edilir (UPDATE/DELETE calisir).
begin
  Grp('F2-22 PK-siz tablo: ilk kolon PK degil, ortuk UNIQUE degil');
  UseDir('f2_nopk');
  sq.Exec('CREATE TABLE npk(a TEXT, b TEXT)');
  // (b) ayni a ile 3 satir eklenebilmeli
  sq.Exec('INSERT INTO npk(a,b) VALUES(' + Q + 'x' + Q + ',' + Q + '1' + Q + ')');
  sq.Exec('INSERT INTO npk(a,b) VALUES(' + Q + 'x' + Q + ',' + Q + '2' + Q + ')');
  sq.Exec('INSERT INTO npk(a,b) VALUES(' + Q + 'x' + Q + ',' + Q + '3' + Q + ')');
  Chk('ayni ilk kolonla 3 satir', 'SELECT a FROM npk', 3);
  ChkVal('b degerleri ayri', 'SELECT b FROM npk WHERE b = ' + Q + '2' + Q, 0, 0, '2');
  // UPDATE/DELETE satirlari tek tek yakalayabilmeli
  ChkInt('UPDATE bir satir', sq.Exec('UPDATE npk SET b = ' + Q + '9' + Q + ' WHERE b = ' + Q + '2' + Q).Affected, 1);
  ChkVal('UPDATE dogru satiri', 'SELECT b FROM npk WHERE b = ' + Q + '9' + Q, 0, 0, '9');
  ChkInt('DELETE bir satir', sq.Exec('DELETE FROM npk WHERE b = ' + Q + '1' + Q).Affected, 1);
  Chk('kalan 2 satir', 'SELECT a FROM npk', 2);
  // yeniden acilinda sentetik anahtarlar korunmali
  tb.Close; kv.Close; sq.Free; tb.Free; kv.Free;
  kv := TVDb.Create; tb := TVTableDb.Create(kv); sq := TVSql.Create(tb);
  kv.Open(D + '\f2_nopk');
  tb.Open(D + '\f2_nopk');
  Chk('reopen sonrasi 2 satir', 'SELECT a FROM npk', 2);
  ChkVal('reopen sonrasi degerler', 'SELECT b FROM npk WHERE b = ' + Q + '9' + Q, 0, 0, '9');
  // yeni satir eklenince sentetik anahtar carpismamali
  sq.Exec('INSERT INTO npk(a,b) VALUES(' + Q + 'x' + Q + ',' + Q + '4' + Q + ')');
  Chk('reopen sonrasi eklenen satir', 'SELECT a FROM npk', 3);
  // (a) ilk kolon artik PK degil: DDL calismali
  sq.Exec('UPDATE npk SET a = ' + Q + '7' + Q);   // tip degistirilebilir olmali
  sq.Exec('ALTER TABLE npk ALTER COLUMN a TYPE INTEGER');
  ChkInt('ilk kolon tipi degisti', Length(sq.Exec('SELECT a FROM npk WHERE a = 7').Rows), 3);
  sq.Exec('ALTER TABLE npk DROP COLUMN a');
  ChkErr('ilk kolon silindi', 'SELECT a FROM npk');
  Chk('kalan kolon duruyor', 'SELECT b FROM npk', 3);
  // NOT NULL da PK'ya ozel: ilk kolona serbest
  sq.Exec('CREATE TABLE npk2(a TEXT)');
  sq.Exec('ALTER TABLE npk2 ALTER COLUMN a SET NOT NULL');
  ChkErr('NOT NULL uygulandi', 'INSERT INTO npk2(a) VALUES(NULL)');
end;

procedure T65_F2_UniqueIndex;
// F2-23: `CREATE UNIQUE INDEX` gercekten zorlanir.
// ONCEDEN parser UNIQUE kelimesini yutup bayragi motora tasimiyordu ve
// TIdxDef'te alan yoktu; sonuc tanim HIC BIR SEY yapmiyordu.
var
  raised: Boolean;

  procedure ChkReject(const Nm, Sql: string);
  begin
    raised := False;
    try
      sq.Exec(Sql);
    except
      raised := True;
    end;
    if raised then Ok(Nm, 'reddedildi')
    else No(Nm, 'KABUL EDILDI');
  end;

begin
  Grp('F2-23 CREATE UNIQUE INDEX zorlanir');
  UseDir('f2_uniqidx');
  // --- tek kolonlu ---
  sq.Exec('CREATE TABLE u1(id INTEGER PRIMARY KEY, a TEXT, b TEXT)');
  sq.Exec('CREATE UNIQUE INDEX u1a ON u1(a)');
  sq.Exec('INSERT INTO u1(id,a,b) VALUES(1,' + Q + 'x' + Q + ',1)');
  ChkReject('tek kolonlu UNIQUE tekrar reddedildi',
    'INSERT INTO u1(id,a,b) VALUES(2,' + Q + 'x' + Q + ',2)');
  sq.Exec('INSERT INTO u1(id,a,b) VALUES(3,' + Q + 'y' + Q + ',3)');
  ChkErr('UPDATE ile UNIQUE ihlali reddedildi',
    'UPDATE u1 SET a = ' + Q + 'x' + Q + ' WHERE id = 3');
  Chk('kacirilan satir duruyor', 'SELECT a FROM u1', 2);
  // --- cok kolonlu ---
  sq.Exec('CREATE TABLE u2(id INTEGER PRIMARY KEY, a TEXT, b TEXT)');
  sq.Exec('CREATE UNIQUE INDEX u2ab ON u2(a,b)');
  sq.Exec('INSERT INTO u2(id,a,b) VALUES(1,' + Q + 'x' + Q + ',' + Q + 'y' + Q + ')');
  ChkReject('cok kolonlu UNIQUE tekrar reddedildi',
    'INSERT INTO u2(id,a,b) VALUES(2,' + Q + 'x' + Q + ',' + Q + 'y' + Q + ')');
  // farkli cift KABUL edilir
  sq.Exec('INSERT INTO u2(id,a,b) VALUES(3,' + Q + 'x' + Q + ',' + Q + 'z' + Q + ')');
  sq.Exec('INSERT INTO u2(id,a,b) VALUES(4,' + Q + 'w' + Q + ',' + Q + 'y' + Q + ')');
  Chk('3 farkli cift kabul edildi', 'SELECT a FROM u2', 3);
  // --- UNIQUE tanimi semada korunur (reopen) ---
  tb.Close; kv.Close; sq.Free; tb.Free; kv.Free;
  kv := TVDb.Create; tb := TVTableDb.Create(kv); sq := TVSql.Create(tb);
  kv.Open(D + '\f2_uniqidx'); tb.Open(D + '\f2_uniqidx');
  Chk('reopen sonrasi satirlar', 'SELECT a FROM u2', 3);
  ChkErr('reopen sonrasi UNIQUE hala zorlanir',
    'INSERT INTO u2(id,a,b) VALUES(5,' + Q + 'x' + Q + ',' + Q + 'y' + Q + ')');
end;
procedure T66_F2_DropColCokKolluIndeks;
// F2-11: DROP COLUMN, kolonu iceren COK KOLONLU indeksi de tanimdan
// kaldirir. ONCEDEN yalniz `Idx[i].Col = ci` (ilk kolon) bakiliyordu;
// indeks bu kolonu iceriyorsa GORULMUYOR ve yanlis Col konumuyla
// birakiliyordu -> sonraki sorgular yanlis sonuc donuyordu.
begin
  Grp('F2-11 DROP COLUMN cok kolonlu indeksi de kaldirir');
  UseDir('f2_dropidx_multi');
  sq.Exec('CREATE TABLE di(id INTEGER PRIMARY KEY, a TEXT, b TEXT, c TEXT)');
  sq.Exec('CREATE INDEX ix_abc ON di(a, b, c)');
  sq.Exec('INSERT INTO di(id,a,b,c) VALUES(1,' + Q + 'p' + Q + ',' + Q + 'q' + Q + ',' + Q + 'r' + Q + ')');
  sq.Exec('INSERT INTO di(id,a,b,c) VALUES(2,' + Q + 'p' + Q + ',' + Q + 's' + Q + ',' + Q + 'r' + Q + ')');
  Chk('indeksle 2 satir', 'SELECT id FROM di', 2);
  Chk('cok kolonlu esitlik', 'SELECT id FROM di WHERE a = ' + Q + 'p' + Q + ' AND b = ' + Q + 's' + Q, 1);
  // 'b' indeksin IKINCI kolonu: dusurulunca indeks de kalkmali
  sq.Exec('ALTER TABLE di DROP COLUMN b');
  ChkErr('b silindi', 'SELECT b FROM di');
  Chk('kalan satirlar', 'SELECT id FROM di', 2);
  ChkVal('kalan degerler bozulmadi', 'SELECT c FROM di WHERE id = 1', 0, 0, 'r');
  // indeks kalintisi olsaydi sorgu yanlis sonuc verirdi
  ChkInt('a ile 2 satir', Length(sq.Exec('SELECT id FROM di WHERE a = ' + Q + 'p' + Q).Rows), 2);
  sq.Exec('INSERT INTO di(id,a,c) VALUES(3,' + Q + 'p' + Q + ',' + Q + 't' + Q + ')');
  Chk('yeni satir eklendi', 'SELECT id FROM di', 3);
  ChkVal('yeni satir degeri', 'SELECT c FROM di WHERE id = 3', 0, 0, 't');
end;
procedure T67_F3_Hijyen;
// F3 regresyonu. F3 kalemlerinin cogu gozlemsizdir; bu test dokunulan
// yollari CALISTIRIR (dizinin bozulmadigini teyit eder):
//  - UNIQUE kolonda birden cok bos (=NULL) deger + sonra gercek deger
//    (F3-5: bos anahtar UNIQUE haritasina yazilmaz),
//  - cok satirli ORDER BY/siralama (F3-2: quicksort yigini),
//  - CRC tablosu butunlugu (F3-4),
//  - cok kolonlu indeks karsilastirmasi (F3-1 arsiv silme sonrasi).
var
  i: Integer;
begin
  Grp('F3 hijyen regresyonu');
  UseDir('f3_hijyen');
  // --- F3-5: UNIQUE + coklu NULL ---
  sq.Exec('CREATE TABLE h(id INTEGER PRIMARY KEY, a TEXT UNIQUE)');
  sq.Exec('INSERT INTO h(id,a) VALUES(1,NULL)');
  sq.Exec('INSERT INTO h(id,a) VALUES(2,NULL)');
  sq.Exec('INSERT INTO h(id,a) VALUES(3,NULL)');
  Chk('3 bos deger kabul', 'SELECT id FROM h', 3);
  sq.Exec('INSERT INTO h(id,a) VALUES(4,' + Q + 'x' + Q + ')');
  ChkErr('ilk gercek deger', 'INSERT INTO h(id,a) VALUES(5,' + Q + 'x' + Q + ')');
  sq.Exec('INSERT INTO h(id,a) VALUES(6,' + Q + 'y' + Q + ')');
  Chk('5 satir', 'SELECT id FROM h', 5);
  // bos deger serbest kalmali
  sq.Exec('INSERT INTO h(id,a) VALUES(7,NULL)');
  Chk('6 satir', 'SELECT id FROM h', 6);
  // UPDATE ile bos degerden gercek degeere
  sq.Exec('UPDATE h SET a = ' + Q + 'z' + Q + ' WHERE id = 1');
  ChkErr('UPDATE ile UNIQUE ihlali', 'UPDATE h SET a = ' + Q + 'z' + Q + ' WHERE id = 2');
  // --- F3-2: siralama yigini (cok satir) ---
  sq.Exec('CREATE TABLE s(id INTEGER PRIMARY KEY, v INTEGER)');
  for i := 1 to 500 do
    sq.Exec('INSERT INTO s(id,v) VALUES(' + IntToStr(i) + ',' +
      IntToStr((i * 37) mod 501) + ')');
  // NOT: 37 ve 501 aralarinda asal oldugu icin i*37 mod 501 == 0
  // hicbir i icin (1..500) saglanmaz; en kucuk deger 1'dir.
  ChkVal('sirali ilk', 'SELECT v FROM s ORDER BY v', 0, 0, '1');
  ChkVal('sirali son', 'SELECT v FROM s ORDER BY v', 499, 0, '500');
  ChkInt('azalan ilk', Length(sq.Exec('SELECT v FROM s ORDER BY v DESC').Rows), 500);
  ChkVal('azalan deger', 'SELECT v FROM s ORDER BY v DESC', 0, 0, '500');
  ChkInt('cok kolonlu siralama',
    Length(sq.Exec('SELECT id FROM s ORDER BY v DESC, id ASC').Rows), 500);
  // --- F3-1/F3-4: cok kolonlu indeks + arama ---
  sq.Exec('CREATE INDEX ix_sv ON s(v, id)');
  // i=1 -> v = 37 mod 501 = 37 (var olan bir deger)
  ChkInt('indeksle arama', Length(sq.Exec('SELECT id FROM s WHERE v = 37').Rows), 1);
  // --- CRC butunlugu: dosya butunlugu (satir sayisi teyidi) ---
  Chk('sayim dogru', 'SELECT COUNT(*) FROM s', 1);
  Chk('checkpoint sonrasi erisim', 'SELECT COUNT(*) FROM s', 1);
end;
procedure T96_Probe;
begin
  Grp('PROBE cok kolonlu indeks ondek esitligi');
  UseDir('probe_prefix');
  sq.Exec('CREATE TABLE p(id INTEGER PRIMARY KEY, v INTEGER, w INTEGER)');
  sq.Exec('INSERT INTO p(id,v,w) VALUES(1,10,100)');
  sq.Exec('INSERT INTO p(id,v,w) VALUES(2,10,200)');
  sq.Exec('INSERT INTO p(id,v,w) VALUES(3,20,300)');
  WriteLn('   [Q] indekssiz WHERE v=10  -> ', Length(sq.Exec('SELECT id FROM p WHERE v = 10').Rows), ' satir');
  sq.Exec('CREATE INDEX ix_vw ON p(v,w)');
  WriteLn('   [Q] TEK KOLONLU indeksle');
  sq.Exec('CREATE TABLE p2(id INTEGER PRIMARY KEY, v INTEGER, w INTEGER)');
  sq.Exec('INSERT INTO p2(id,v,w) VALUES(1,10,100),(2,10,200),(3,20,300)');
  sq.Exec('CREATE INDEX ix2_v ON p2(v)');
  WriteLn('   [Q]   WHERE v=10  -> ', Length(sq.Exec('SELECT id FROM p2 WHERE v = 10').Rows), ' satir');
  WriteLn('   [Q] COK KOLONLU indeksle');
  WriteLn('   [Q]   WHERE v=10       -> ', Length(sq.Exec('SELECT id FROM p WHERE v = 10').Rows), ' satir');
  WriteLn('   [Q]   WHERE v=10 AND w=200 -> ', Length(sq.Exec('SELECT id FROM p WHERE v = 10 AND w = 200').Rows), ' satir');
  WriteLn('   [Q]   WHERE w=200 (ilk kolon degil) -> ', Length(sq.Exec('SELECT id FROM p WHERE w = 200').Rows), ' satir');
  WriteLn('   [Q]   WHERE v>5       -> ', Length(sq.Exec('SELECT id FROM p WHERE v > 5').Rows), ' satir');
end;
procedure T68_F3_CokKolluOndek;
// F3-7 (yanlis sonuc, F1 seviyesi): cok kolonlu indeks, ILK KOLONA
// uygulanan esitlik/aralik filtresinde SATIR SILIYORDU.
//
// NEDEN: bilesik indeks anahtarlari uzunluk-oneki kodlanir
// ("2:103:100" = v=10, w=100). VDbIdxRangeL ise ilk parcayi
// VDbIdxPartOf ile ayiriyordu; ancak çağrıcılar degeri KODLANMAMIŞ
// (ham '10') geciriyordu. VDbIdxPartOf('10') ilk karakteri rakam
// gordugu icin onu kodlu anahtar sanar, "10:" arar, bulamaz ve BOS
// string doner. Bos ile karsilastirma '=' araligini BOS BIRAKIR ->
// satirlar sessizce kaybolur. ('>' ve '>=' yanlislikla SUPERSET
// uretiyor, bu yuzden RowMatches onarimiyla duzeliyordu; yalniz '='
// ve '<=' bozuktu.)
var
  i: Integer;
begin
  Grp('F3-7 cok kolonlu indeks ondek filtresi satir silmiyor');
  UseDir('f3_prefix');
  sq.Exec('CREATE TABLE p(id INTEGER PRIMARY KEY, v INTEGER, w INTEGER, s TEXT)');
  sq.Exec('INSERT INTO p(id,v,w,s) VALUES(1,10,100,' + Q + 'a' + Q + ')');
  sq.Exec('INSERT INTO p(id,v,w,s) VALUES(2,10,200,' + Q + 'b' + Q + ')');
  sq.Exec('INSERT INTO p(id,v,w,s) VALUES(3,20,300,' + Q + 'c' + Q + ')');
  sq.Exec('INSERT INTO p(id,v,w,s) VALUES(4,2,400,' + Q + 'd' + Q + ')');
  Chk('indekssiz ondek esitligi', 'SELECT id FROM p WHERE v = 10', 2);
  sq.Exec('CREATE INDEX ix_vws ON p(v, w, s)');
  // ILK KOLON esitligi
  Chk('ilk kolon =', 'SELECT id FROM p WHERE v = 10', 2);
  Chk('ilk kolon = (tek satir)', 'SELECT id FROM p WHERE v = 20', 1);
  ChkInt('sayim dogru', Length(sq.Exec('SELECT id FROM p WHERE v = 10').Rows), 2);
  // TAM bilesik esitlik
  Chk('ilk + ikinci kolon', 'SELECT id FROM p WHERE v = 10 AND w = 200', 1);
  Chk('ucuncu kolon dahil', 'SELECT id FROM p WHERE v = 10 AND w = 200 AND s = ' + Q + 'b' + Q, 1);
  // IKINCI KOLON ( indeks on ekine degil) -> tam tara yolu
  Chk('ilk kolon degil', 'SELECT id FROM p WHERE w = 200', 1);
  // aralıklar
  Chk('> ilk kolon', 'SELECT id FROM p WHERE v > 5', 3);
  Chk('>= ilk kolon', 'SELECT id FROM p WHERE v >= 10', 3);
  Chk('< ilk kolon', 'SELECT id FROM p WHERE v < 10', 1);
  Chk('<= ilk kolon', 'SELECT id FROM p WHERE v <= 10', 3);
  Chk('BETWEEN', 'SELECT id FROM p WHERE v BETWEEN 10 AND 20', 3);
  Chk('IN', 'SELECT id FROM p WHERE v IN (10,20)', 3);
  // ONCEKI hatanin en belirgin hali: tek basina sayim
  ChkVal('COUNT(*)', 'SELECT COUNT(*) FROM p WHERE v = 10', 0, 0, '2');
  ChkVal('SUM', 'SELECT SUM(w) FROM p WHERE v = 10', 0, 0, '300');
  // cok satirli dogrulama
  for i := 5 to 60 do
    sq.Exec('INSERT INTO p(id,v,w,s) VALUES(' + IntToStr(i) + ',' +
      IntToStr(10 + (i mod 3)) + ',' + IntToStr(i * 7) + ',' + Q + 'k' + Q + ')');
  // i=5..60: i mod 3 = 0 -> 19 satir (6..60), = 1 -> 18 (7..58), = 2 -> 19 (5..59)
  // mevcut 4 satirdan 2'si v=10
  Chk('60+ satirtan v=10', 'SELECT id FROM p WHERE v = 10', 21);
  Chk('60+ satirtan v=11', 'SELECT id FROM p WHERE v = 11', 18);
  ChkVal('toplam', 'SELECT COUNT(*) FROM p', 0, 0, '60');
  ChkVal('v=11 toplami', 'SELECT COUNT(*) FROM p WHERE v = 11', 0, 0, '18');
end;
procedure T69_YonetimAPI;
// YONETIM ARACININ (had.exe) KULLANDIGI MOTOR API YOLLARI.
// SQL katmani degil, dogrudan TVTableDb cagrilari - boylece yonetimdeki
// degisikliklerin dayandigi APIler test edilmis olur.
//
// Kapsam:
//  (1) CreateTable(..., PkIndex = -1)  -> PK'siz tablo olusturulabilir
//      (M1: yonetim diyalogu artik PK zorlamiyor)
//  (2) UpdateRowInPlace(t, pk, vals)  -> PK'siz tabloda sentetik anahtarla
//      satir duzenleme (M2)
//  (3) Delete(t, pk)                  -> PK'siz tabloda sentetik anahtarla
//      silme (M3)
//  (4) CreateIndexCols(t, ad, cols, Unique) -> cok kolunlu + UNIQUE indeks
//      (M4)
var
  myKv: TVDb;
  myTb: TVTableDb;
  cols: TColArray;
  pks: TStrArray;
  rows: TStrMatrix;
  n, i: Integer;
  vals: TStrArray;
  raised: Boolean;
  foundC: string;
begin
  Grp('Yonetim aracinin kullandigi motor API yollari');
  myKv := TVDb.Create;
  try
    myKv.Open(D + '\yonetimapi');
    myTb := TVTableDb.Create(myKv);
    try
      myTb.Open(D + '\yonetimapi');
      // ---- (1) PK'siz tablo (PkIndex = -1) ----
      SetLength(cols, 3);
      cols[0].Name := 'a'; cols[0].Ctype := VCT_STR;
      cols[1].Name := 'b'; cols[1].Ctype := VCT_INT;
      cols[2].Name := 'c'; cols[2].Ctype := VCT_STR; cols[2].Unique := True;
      myTb.CreateTable('nopk', cols, -1, [], []);
      if myTb.GetTable('nopk').PkIndex < 0 then
        Ok('PK-siz tablo olusturuldu (PkIndex=-1)', '-1')
      else
        No('PK-siz tablo olusturulamadı', 'PkIndex=' +
           IntToStr(myTb.GetTable('nopk').PkIndex));
      myTb.Insert('nopk', ['a', 'b', 'c'], ['x', '1', 'p']);
      myTb.Insert('nopk', ['a', 'b', 'c'], ['x', '2', 'q']);
      n := myTb.ScanRows('nopk', pks, rows);
      ChkInt('2 satir eklendi', n, 2);
      // sentetik anahtarlar @1, @2
      if (Length(pks) = 2) and (Copy(pks[0], 1, 1) = '@') then
        Ok('sentetik anahtar uretildi', pks[0])
      else
        No('sentetik anahtar uretilmedi', 'beklenen @1');
      // ---- (2) UpdateRowInPlace ile duzenleme (M2 yolu) ----
      SetLength(vals, 3);
      vals[0] := 'x'; vals[1] := '2'; vals[2] := 'GUNCELDI';
      if myTb.UpdateRowInPlace('nopk', pks[1], vals) then
        Ok('UpdateRowInPlace (sentetik anahtar)', pks[1])
      else
        No('UpdateRowInPlace basarisiz', pks[1]);
      myTb.ScanRows('nopk', pks, rows);
      foundC := '';
      for i := 0 to High(rows) do if rows[i][2] = 'GUNCELDI' then foundC := rows[i][2];
      if foundC = 'GUNCELDI' then Ok('satir gercekten guncellendi', foundC)
      else No('guncelleme yansimadi', '');
      // ---- UNIQUE kolon denetimi API'den de dogru calisir ----
      // c kolonu UNIQUE; diger satirin degerini almaya calis -> reddedilmeli
      SetLength(vals, 3);
      vals[0] := 'x'; vals[1] := '1'; vals[2] := 'GUNCELDI';
      raised := False;
      try
        myTb.UpdateRowInPlace('nopk', pks[0], vals);
      except
        raised := True;
      end;
      if raised then Ok('UpdateRowInPlace UNIQUE denetimi', 'hata verdi')
      else No('UpdateRowInPlace UNIQUE denetlemedi', '');
      // ---- (3) Delete ile silme (M3 yolu) ----
      if myTb.Delete('nopk', pks[0]) then Ok('Delete (sentetik anahtar)', pks[0])
      else No('Delete basarisiz', pks[0]);
      n := myTb.ScanRows('nopk', pks, rows);
      ChkInt('silinen 1 satir kaldi', n, 1);
      // ---- (4) cok kolonlu + UNIQUE indeks (M4 yolu) ----
      myTb.CreateIndexCols('nopk', 'ix_ab', ['a', 'b'], True);
      raised := False;
      try
        myTb.Insert('nopk', ['a', 'b', 'c'], ['x', '2', 'duplicate']);
      except
        raised := True;
      end;
      if raised then Ok('UNIQUE cok kolonlu indeks zorlanir (API)', 'hata verdi')
      else No('UNIQUE indeks zorlanmadi', '');
      // farkli cift kabul edilir
      myTb.Insert('nopk', ['a', 'b', 'c'], ['x', '3', 'farkli']);
      n := myTb.ScanRows('nopk', pks, rows);
      ChkInt('farkli cift kabul edildi', n, 2);
      // UNIQUE olmayan cok kolonlu indeks de kurulabilmeli (ilk kolon farkli)
      myTb.CreateIndexCols('nopk', 'ix_bc', ['b', 'c'], False);
      Ok('UNIQUE olmayan cok kolunlu indeks kuruldu', 'ix_bc');
      // ---- DDL: PK'siz tabloda ilk kolon serbest (M1'in sonucu) ----
      myTb.AlterDropColumn('nopk', 'c');
      raised := False;
      try
        myTb.ScanRows('nopk', pks, rows);
      except
        raised := True;
      end;
      if not raised then Ok('ilk kolon silinebildi (PK degil)', 'c silindi')
      else No('ilk kolon silinemedi', '');
    finally
      myTb.Free;
    end;
  finally
    myKv.Free;
  end;
end;
procedure T70_YonetimBakim;
// YONETIM ARACININ BAKIM OZELLIKLERININ MOTOR YOLLARI (M6/M7/M8).
// NOT: Chk/ChkVal yardimcilari GLOBAL sq oturumunu kullanir; burada ayri
// bir mySq oturumu acildigi icin kendi yardimcimizi kullaniyoruz.
var
  myKv: TVDb;
  myTb: TVTableDb;
  mySq: TVSql;
  res, r: TSqlResult;
  stmts: TStrArray;
  vOld, vNew: Int64;
  i: Integer;
  did, raised: Boolean;

  procedure ChkMy(const Nm, Sql: string; RowIx, ColIx: Integer; const Exp: string);
  begin
    r := mySq.Exec(Sql);
    if (Length(r.Rows) > RowIx) and (Length(r.Rows[RowIx]) > ColIx) and
       (r.Rows[RowIx][ColIx] = Exp) then
      Ok(Nm, Exp)
    else if (Length(r.Rows) <= RowIx) or (Length(r.Rows[RowIx]) <= ColIx) then
      No(Nm, 'sonuc hucre yok')
    else
      No(Nm, 'beklenen "' + Exp + '" gelen "' + r.Rows[RowIx][ColIx] + '"');
  end;

begin
  Grp('Yonetim bakim ozellikleri (dayaniklilik, betik, sikistirma)');
  myKv := TVDb.Create;
  try
    myKv.Open(D + '\yonetimbakim');
    myTb := TVTableDb.Create(myKv);
    mySq := TVSql.Create(myTb);
    try
      myTb.Open(D + '\yonetimbakim');
      // ---------- M8: AutoCompact (Gerektiginde Sikistir) ----------
      mySq.Exec('CREATE TABLE ac(id INTEGER PRIMARY KEY, v TEXT)');
      for i := 1 to 400 do
        mySq.Exec('INSERT INTO ac(id,v) VALUES(' + IntToStr(i) + ',' +
          Q + 'veri-' + IntToStr(i) + Q + ')');
      for i := 1 to 350 do
        mySq.Exec('DELETE FROM ac WHERE id = ' + IntToStr(i));
      if myKv.DeadBytes > 0 then
        Ok('olu bayt birikti', IntToStr(myKv.DeadBytes) + ' bayt')
      else
        No('olu bayt birikmedi', '0');
      did := myKv.AutoCompact(vOld, vNew, 0.99, 1000000000);
      if not did then Ok('AutoCompact esik altinda calismadi', 'dogru')
      else Ok('AutoCompact calisti', IntToStr(vOld - vNew) + ' bayt');
      did := myKv.AutoCompact(vOld, vNew, 0.0, 1024);
      if did then Ok('AutoCompact esigi asildi', IntToStr(vOld) + ' -> ' + IntToStr(vNew))
      else No('AutoCompact calismadi', 'esik asildi');
      // sikistirma sonrasi SEMA ve VERI saglam kalmali
      ChkInt('sikistirma sonrasi tablo sayisi', Length(myTb.TableNames), 1);
      ChkInt('sikistirma sonrasi canli kayit', myTb.DataKeyCount, 50);
      ChkMy('sikistirma sonrasi satir sayisi', 'SELECT COUNT(*) FROM ac', 0, 0, '50');
      ChkMy('son satir degeri', 'SELECT v FROM ac WHERE id = 400', 0, 0, 'veri-400');
      // ---------- M7: cok cumleli betik (ExecAll) ----------
      stmts := mySq.SplitStatements(
        'CREATE TABLE betik(id INTEGER PRIMARY KEY, v TEXT);' +
        'INSERT INTO betik(id,v) VALUES(1,' + Q + 'a' + Q + ');' +
        'INSERT INTO betik(id,v) VALUES(2,' + Q + 'b' + Q + ');' +
        'INSERT INTO betik(id,v) VALUES(3,' + Q + 'c' + Q + ')');
      ChkInt('betik 4 cumle olarak bolundu', Length(stmts), 4);
      res := mySq.ExecAll(stmts);
      ChkInt('ExecAll Affected (3 INSERT + 1 CREATE)', res.Affected, 4);
      ChkMy('betik: veri dogru', 'SELECT COUNT(*) FROM betik', 0, 0, '3');
      stmts := mySq.SplitStatements(
        'INSERT INTO betik(id,v) VALUES(4,' + Q + 'd' + Q + ');' +
        'INSERT INTO yok_boyle_tablo(id) VALUES(1)');
      raised := False;
      try
        mySq.ExecAll(stmts);
      except
        raised := True;
      end;
      if raised then Ok('betik hatasi bildirildi', 'hata verdi')
      else No('betik hatasi yutuldu', '');
      ChkMy('hatali betikte hicbiri uygulanmadi',
        'SELECT COUNT(*) FROM betik', 0, 0, '3');
      stmts := mySq.SplitStatements(
        'BEGIN;' +
        'INSERT INTO betik(id,v) VALUES(10,' + Q + 'x' + Q + ');' +
        'INSERT INTO betik(id,v) VALUES(11,' + Q + 'y' + Q + ');' +
        'COMMIT');
      mySq.ExecAll(stmts);
      ChkMy('BEGIN/COMMIT betigi', 'SELECT COUNT(*) FROM betik', 0, 0, '5');
      stmts := mySq.SplitStatements(
        'BEGIN;' +
        'INSERT INTO betik(id,v) VALUES(20,' + Q + 'z' + Q + ');' +
        'ROLLBACK');
      mySq.ExecAll(stmts);
      ChkMy('ROLLBACK betigi geri aldi', 'SELECT COUNT(*) FROM betik', 0, 0, '5');
      // ---------- M6: dayaniklilik isaretleri okunabilir ----------
      if myKv.DirSyncFailed then
        No('DirSyncFailed normalde FALSE', 'true dondu')
      else
        Ok('DirSyncFailed okunabilir', 'False');
      if myKv.RestoredFromBak then
        No('RestoredFromBak normalde FALSE', 'true dondu')
      else
        Ok('RestoredFromBak okunabilir', 'False');
      // ---------- menudeki bakim komutlari ----------
      mySq.Exec('VACUUM');
      ChkMy('VACUUM sonrasi veri saglam', 'SELECT COUNT(*) FROM ac', 0, 0, '50');
      mySq.Exec('REINDEX');
      ChkMy('REINDEX sonrasi veri saglam', 'SELECT COUNT(*) FROM ac', 0, 0, '50');
      ChkMy('REINDEX sonrasi indeksle arama',
        'SELECT v FROM ac WHERE id = 400', 0, 0, 'veri-400');
    finally
      mySq.Free;
      myTb.Free;
    end;
  finally
    myKv.Free;
  end;
end;
procedure T71_SemaSorgulari;
// 2026-10-04: SQL SEMA SORGULARI. Once motorun sema bilgisi yalnizca
// programatik API'den okunabiliyordu; SQL tarafinda HICBIR yol yoktu.
//
// NOT (beklenen davranis, test bunu olcumler):
//  - `CREATE INDEX`in ILK kolonunda zaten bir PK/UNIQUE otoindeksi varsa
//    motor ikinci indeks KURMAZ, mevcut otoindeksi yeniden ADLANDIRIR
//    (bkz. CreateIndexCols). Bu yuzden asagida `ix_ad_yas` adli indeks
//    `ad` kolunun TEK sutunlu indeksidir.
//  - `CREATE UNIQUE INDEX x ON t(c)` (tek sutun) kolonu ayrica UNIQUE
//    olarak isaretler; boylece SHOW CREATE TABLE `c ... UNIQUE` der.
//    Bu, zorlanan davranisle tutarlidir.
//  - AUTOINCREMENT bilgisi semada SAKLANMAZ (AutoInc calisma sayacidir,
//    ilk eklemeden once 0'dir); bu yuzden CREATE TABLE ciktisinda
//    gorunmez.
begin
  Grp('SQL sema sorgulari (DESCRIBE / SHOW INDEXES / SHOW CREATE TABLE)');
  UseDir('sema_sql');
  sq.Exec('CREATE TABLE ebe(id INTEGER PRIMARY KEY AUTOINCREMENT, ' +
    'ad TEXT NOT NULL UNIQUE, yas INTEGER, notr TEXT DEFAULT ' + Q + 'x' + Q + ')');
  sq.Exec('CREATE TABLE cocuk(id INTEGER PRIMARY KEY, ebe_id INTEGER, ' +
    'FOREIGN KEY (ebe_id) REFERENCES ebe(id) ON DELETE CASCADE)');
  sq.Exec('CREATE INDEX ix_ad_yas ON ebe(ad, yas)');
  sq.Exec('CREATE UNIQUE INDEX ux_yas ON ebe(yas)');
  // ---- DESCRIBE (8 alan) ----
  R := sq.Exec('DESCRIBE ebe');
  ChkInt('DESCRIBE 4 sutun', Length(R.Rows), 4);
  ChkInt('DESCRIBE 8 alan', Length(R.Fields), 8);
  if R.Fields[0] = 'name' then Ok('DESCRIBE name alani', R.Fields[0])
  else No('DESCRIBE name alani yanlis', R.Fields[0]);
  if R.Fields[5] = 'pk' then Ok('DESCRIBE pk alani', R.Fields[5])
  else No('DESCRIBE pk alani yanlis', R.Fields[5]);
  ChkVal('satir 0 = id',  'DESCRIBE ebe', 0, 0, 'id');
  ChkVal('satir 0 tip',   'DESCRIBE ebe', 0, 1, 'INTEGER');
  ChkVal('satir 0 pk',    'DESCRIBE ebe', 0, 5, 'True');
  ChkVal('satir 1 = ad',  'DESCRIBE ebe', 1, 0, 'ad');
  ChkVal('satir 1 notnull','DESCRIBE ebe', 1, 2, 'True');
  ChkVal('satir 1 unique','DESCRIBE ebe', 1, 3, 'True');
  ChkVal('satir 1 pk degil','DESCRIBE ebe', 1, 5, 'False');
  ChkVal('satir 2 = yas', 'DESCRIBE ebe', 2, 0, 'yas');
  ChkVal('satir 2 tip',   'DESCRIBE ebe', 2, 1, 'INTEGER');
  ChkVal('satir 3 default','DESCRIBE ebe', 3, 4, 'x');
  ChkVal('satir 3 pozisyon','DESCRIBE ebe', 3, 7, '3');
  ChkInt('DESC ayni sonucu verir', Length(sq.Exec('DESC ebe').Rows), 4);
  // ---- SHOW INDEXES ----
  R := sq.Exec('SHOW INDEXES FROM ebe');
  ChkInt('SHOW INDEXES 2 indeks', Length(R.Rows), 2);
  ChkInt('SHOW INDEXES 9 alan', Length(R.Fields), 9);   // F-17/F-18/F-19
  ChkVal('indeks 0 adi (otoindeks yeniden adlandirildi)',
    'SHOW INDEXES FROM ebe', 0, 0, 'ix_ad_yas');
  ChkVal('indeks 0 tek sutun (adotoindeksi)', 'SHOW INDEXES FROM ebe', 0, 2, 'ad');
  ChkVal('indeks 0 kolon sayisi', 'SHOW INDEXES FROM ebe', 0, 3, '1');
  ChkVal('indeks 0 turu', 'SHOW INDEXES FROM ebe', 0, 4, 'tek kolunlu');
  ChkVal('indeks 1 adi', 'SHOW INDEXES FROM ebe', 1, 0, 'ux_yas');
  ChkVal('indeks 1 unique', 'SHOW INDEXES FROM ebe', 1, 1, 'True');
  ChkVal('indeks 1 sutunu', 'SHOW INDEXES FROM ebe', 1, 2, 'yas');
  ChkInt('SHOW INDEXES (FROMsuz bicim)', Length(sq.Exec('SHOW INDEXES ebe').Rows), 2);
  // ---- cok sutunlu indeks gercekten cok sutunlu mu? ----
  sq.Exec('CREATE TABLE cc(a TEXT, b TEXT, c TEXT)');
  sq.Exec('CREATE INDEX ix_cc ON cc(a, b, c)');
  ChkVal('cok sutunlu indeks sutunlari', 'SHOW INDEXES FROM cc', 0, 2, 'a,b,c');
  ChkVal('cok sutunlu indeks kolon sayisi', 'SHOW INDEXES FROM cc', 0, 3, '3');
  ChkVal('cok sutunlu indeks turu', 'SHOW INDEXES FROM cc', 0, 4, 'cok kolunlu');
  // ---- SHOW CREATE TABLE ----
  ChkVal('SHOW CREATE TABLE ebe', 'SHOW CREATE TABLE ebe', 0, 0,
    'CREATE TABLE ebe (id INTEGER PRIMARY KEY, ad TEXT NOT NULL UNIQUE, ' +
    'yas INTEGER UNIQUE, notr TEXT DEFAULT x)');
  R := sq.Exec('SHOW CREATE TABLE cocuk');
  ChkVal('SHOW CREATE TABLE FK tanimi', 'SHOW CREATE TABLE cocuk', 1, 0,
    'FOREIGN KEY (ebe_id) REFERENCES ebe(id) ON DELETE CASCADE ON UPDATE RESTRICT');
  // ---- CHECK tanimi ----
  sq.Exec('CREATE TABLE ck(id INTEGER PRIMARY KEY, n INTEGER CHECK (n > 5))');
  R := sq.Exec('SHOW CREATE TABLE ck');
  if (Length(R.Rows) > 1) and (Pos('CHECK', R.Rows[1][0]) = 1) then
    Ok('SHOW CREATE TABLE CHECK tanimi', R.Rows[1][0])
  else
    No('CHECK tanimi yok', IntToStr(Length(R.Rows)) + ' satir');
  // ---- hata durumlari ----
  ChkErr('DESCRIBE olmayan tablo', 'DESCRIBE yok_boyle');
  ChkErr('SHOW INDEXES olmayan tablo', 'SHOW INDEXES FROM yok_boyle');
  ChkErr('SHOW CREATE TABLE olmayan tablo', 'SHOW CREATE TABLE yok_boyle');
  ChkErr('DESCRIBE tablo adi yok', 'DESCRIBE');
  // ---- PK'siz tablo ----
  sq.Exec('CREATE TABLE nopk2(a TEXT, b INTEGER)');
  ChkVal('DESCRIBE PK-siz tablo pk=false', 'DESCRIBE nopk2', 0, 5, 'False');
  ChkInt('SHOW INDEXES PK-siz tablo (0 indeks)',
    Length(sq.Exec('SHOW INDEXES FROM nopk2').Rows), 0);
end;
procedure T72_WALReplay;
// 2026-10-04: WAL REPLAY ARTIK GERCEK. Onceki hâli STUB'du:
// .wal varsa False donup icerigi UYGULAMIYORDU ve cagirici dosyayi
// silebiliyordu -> yazilmis kayitlar kalici olarak KAYBOLUYORDU.
// Ayrica formatta magic/CRC YOKTU; yirtik kuyruk cop veri olarak
// okunabiliyordu.
var
  myKv: TVDb;
  v: TBytes;
  walFile: string;
  fs: TFileStream;
  i: Integer;
  applied: Boolean;
  hdrKey: QWord;
  partial: LongInt;
  b: Byte;
  mw, zc: LongWord;
  cc: LongWord;
  WalCrc: LongWord;
  seq0: QWord;
  walVal: TBytes;
  walRec: packed record
    Magic: LongWord;
    Key: QWord;
    Flags: Byte;
    ValLen: LongWord;
    Crc: LongWord;
  end;
  rep: string;
  got2: Boolean;
  fl, bb, bc: Byte;

  function WalRecCount(const Path: string): Integer;
  // WAL kayitlarini say (baslik 21 bayt; deger boyutlu)
  var
    f2: TFileStream;
    hdr: array[0..20] of Byte;
    pos, sz: Int64;
    vl: LongInt;
  begin
    Result := 0;
    if not FileExists(Path) then Exit;
    f2 := TFileStream.Create(Path, fmOpenRead);
    try
      sz := f2.Size;
      pos := 0;
      // layout: magic(4) key(8) flags(1) valLen(4) crc(4) = 21 bayt
      while pos + 21 <= sz do
      begin
        f2.Position := pos;
        if f2.Read(hdr, 21) <> 21 then Break;
        vl := 0;
        Move(hdr[13], vl, 4);          // packed record icinde valLen ofseti
        if vl < 0 then Break;
        Inc(Result);
        pos := pos + 21 + vl;
      end;
    finally
      f2.Free;
    end;
  end;

  function WalTestCrc(Key: QWord; ValLen: LongWord; Flags: Byte; const Val: TBytes): LongWord;
  // Motorun WAL CRC formulu: CRC32(Seq=0 || Key || ValLen || Flags || Value).
  // Once motorun yazdigi bir kayitla karsilastirilarak DOGRULANIR; boylece
  // bayrakla ilgili testin aslinda CRC'yi test etmesi engellenir.
  var
    c: LongWord;
    s0: QWord;
  begin
    c := VDbCrc32Init;
    s0 := 0;
    c := VDbCrc32Update(c, s0, SizeOf(s0));            // Seq = 0
    c := VDbCrc32Update(c, Key, SizeOf(Key));
    c := VDbCrc32Update(c, ValLen, SizeOf(ValLen));
    c := VDbCrc32Update(c, Flags, SizeOf(Flags));
    if ValLen > 0 then c := VDbCrc32UpdatePtr(c, @Val[0], ValLen);
    Result := VDbCrc32Final(c);
  end;

begin
  Grp('WAL replay gercek (yirtik kuyruk + checkpoint)');
  // ---- 1) Temel replay: ana dosyaya YAZILMADAN wal'a yazilip replay ----
  myKv := TVDb.Create;
  try
    myKv.Open(D + '\wal1');
    walFile := myKv.WalPath;
    myKv.Put(1, VDbStrToBytes('ana-dosya-1'));
    // 3 kayit: 2 put + 1 delete
    if myKv.WriteAheadWAL(2, VDbStrToBytes('wal-2'), VDB_FLAG_PUT) and
       myKv.WriteAheadWAL(3, VDbStrToBytes('wal-3'), VDB_FLAG_PUT) and
       myKv.WriteAheadWAL(1, nil, VDB_FLAG_DEL) then
      Ok('WriteAheadWAL 3 kayit yazdi', IntToStr(WalRecCount(walFile)) + ' kayit')
    else
      No('WriteAheadWAL yazamadi', '');
    if myKv.HasWAL then Ok('HasWAL dogru', 'True')
    else No('HasWAL yanlis', 'False');
    // WalRecordCount: yalniz SAYAR, hicbir sey uygulamaz/silmez
    if myKv.WalRecordCount = 3 then Ok('WalRecordCount 3', '3')
    else No('WalRecordCount', IntToStr(myKv.WalRecordCount));
    // replay oncesi: sayim yan etkisiz (hala 3, ana dosyada 2/3 yok)
    SetLength(v, 0);
    if (myKv.WalRecordCount = 3) and (not myKv.Get(2, v)) then
      Ok('WalRecordCount yan etkisiz', 'hala 3, ana dosya degismedi')
    else No('WalRecordCount yan etkili', 'sayim=' + IntToStr(myKv.WalRecordCount));
    // replay ONCESI: ana dosyada 2 ve 3 YOK
    SetLength(v, 0);
    if myKv.Get(2, v) then No('replay oncesi 2 anahtari vardi', 'bulundu')
    else Ok('replay oncesi 2 anahtari yok', 'yok');
    // replay
    if myKv.ReplayWAL then Ok('ReplayWAL basarili', 'True')
    else No('ReplayWAL basarisiz', '');
    // replay SONRASI
    SetLength(v, 0);
    got2 := myKv.Get(2, v);
    if got2 and (VDbBytesToStr(v) = 'wal-2') then
      Ok('replay sonrasi 2 anahtari yazildi', VDbBytesToStr(v))
    else No('replay sonrasi 2 anahtari yazilmadi', 'Get=' + BoolToStr(got2, True) +' deger=[' + VDbBytesToStr(v) + '] uz=' + IntToStr(Length(v)));
    SetLength(v, 0);
    if myKv.Get(3, v) and (VDbBytesToStr(v) = 'wal-3') then
      Ok('replay sonrasi 3 anahtari yazildi', VDbBytesToStr(v))
    else No('replay sonrasi 3 anahtari yazilmadi', '');
    SetLength(v, 0);
    if myKv.Get(1, v) then No('replay sonrasi silinen 1 anahtari duruyor', 'bulundu')
    else Ok('replay sonrasi silinen 1 anahtari gitti', 'silindi');
    if myKv.HasWAL then No('replay sonrasi .wal kaldi', 'kaldi')
    else Ok('replay sonrasi .wal silindi', 'silindi');
    // ---- 2) YIRTIK KUYRUK: son kayit yarim yazilmis ----
    // NOT: .wal KIRPILMAZ, ekleme yapilir. Daha once burada
    // `fmOpenWrite or fmCreate` kullaniliyordu; FPC'de fmCreate dosyayi
    // KIRPAR -> gecerli kayit testten ONCE siliniyor ve "kayit kayboldu"
    // hatasi uretiliyordu.
    if myKv.WriteAheadWAL(10, VDbStrToBytes('gecerli-kayit'), VDB_FLAG_PUT) then
      Ok('yirtik kuyruk icin 1 kayit yazildi', '')
    else
      No('yirtik kuyruk icin kayit yazilamadi', '');
    // GECERLI magic'li baslik + valLen=500, ama degerden yalniz 1 bayt
    fs := TFileStream.Create(myKv.WalPath, fmOpenReadWrite);
    try
      fs.Position := fs.Size;
      mw := WAL_MAGIC_BEKLENEN;
      fs.Write(mw, SizeOf(mw));
      hdrKey := 777;
      fs.Write(hdrKey, SizeOf(hdrKey));
      fl := Byte(VDB_FLAG_PUT);
      fs.Write(fl, SizeOf(fl));
      partial := 500;
      fs.Write(partial, SizeOf(partial));   // 500 bayt deger SOYUTULUYOR
      zc := 0;                               // crc yerine 0 (zaten elenecek)
      fs.Write(zc, SizeOf(zc));
      bb := 255;
      fs.Write(bb, 1);                      // 1 bayt
    finally
      fs.Free;
    end;
    // Sayim replay ONCESI yapilir: yirtik kayit sayilmamali, gecerli
    // kayit sayilmalidir. (Replay sonrasi .wal silindigi icin sayim 0
    // olurdu; bu yuzden sira onemlidir.)
    if myKv.WalRecordCount = 1 then
      Ok('WalRecordCount yirtik kuyrukta yalniz GECERLI kayit', '1')
    else No('WalRecordCount yirtik kuyrukta', IntToStr(myKv.WalRecordCount));
    if myKv.ReplayWAL then Ok('yirtik kuyruk: gecerli kayitlar yazildi', 'True')
    else No('yirtik kuyruk: replay basarisiz', '');
    SetLength(v, 0);
    if myKv.Get(10, v) and (VDbBytesToStr(v) = 'gecerli-kayit') then
      Ok('yirtik kuyruk oncesi kayit KORUNDU', VDbBytesToStr(v))
    else No('yirtik kuyruk gecerli kayit kayboldu', '');
    SetLength(v, 0);
    if myKv.Get(777, v) then No('yirtik kuyruk bozuk kayit UYGULANDI', 'bozuk veri yazildi')
    else Ok('yirtik kuyruk bozuk kayit UYGULANMADI', 'reddedildi');
    // ---- 3) CRC BOZUK kayit: yalniz GECERLI ONCEKI kayitlar uygulanir ----
    // 19 (saglam) + 20 (crc bozulacak) yazilir; sadece 20'nin degeri
    // degistirilir -> 19 uygulanmali, 20 UYGULANMAMALI.
    if myKv.WriteAheadWAL(19, VDbStrToBytes('crc-ok-19'), VDB_FLAG_PUT) and
       myKv.WriteAheadWAL(20, VDbStrToBytes('crc-bozuk'), VDB_FLAG_PUT) then
      Ok('crc testi icin 2 kayit yazildi', '')
    else
      No('crc testi icin kayit yazilamadi', '');
    fs := TFileStream.Create(myKv.WalPath, fmOpenReadWrite);
    try
      fs.Seek(-1, fsFromEnd);
      b := 0;
      fs.Read(b, 1);              // son bayt (degerin sonu)
      fs.Seek(-1, fsFromEnd);
      bc := b xor 255;
      fs.Write(bc, 1);            // bir bayt degistir -> CRC tutmaz
    finally
      fs.Free;
    end;
    // Sayim CRC bozuk kaydi saymamali: 19 gecerli, 20 bozuk -> 1
    if myKv.WalRecordCount = 1 then
      Ok('WalRecordCount CRC bozuk kaydi saymadi', '1')
    else No('WalRecordCount CRC bozuk kaydi SAYDI', IntToStr(myKv.WalRecordCount));
    if myKv.ReplayWAL then Ok('CRC bozuk kayit: replay yine de calisti', 'True')
    else No('CRC bozuk kayit: replay basarisiz', '');
    SetLength(v, 0);
    if myKv.Get(19, v) and (VDbBytesToStr(v) = 'crc-ok-19') then
      Ok('CRC bozuk: onceki GECERLI kayit uygulandi', VDbBytesToStr(v))
    else No('CRC bozuk: onceki gecerli kayit KAYBOLDU', '');
    SetLength(v, 0);
    if myKv.Get(20, v) then No('CRC bozuk kayit UYGULANDI', 'veri yazildi')
    else Ok('CRC bozuk kayit reddedildi', 'uygulanmadi');
    if myKv.HasWAL then No('CRC bozuk sonrasi .wal kaldi', 'kaldi')
    else Ok('CRC bozuk sonrasi .wal silindi', 'silindi');
    if myKv.WalRecordCount = 0 then
      Ok('replay sonrasi WalRecordCount 0', '0')
    else No('replay sonrasi WalRecordCount', IntToStr(myKv.WalRecordCount));
    // ---- 3b) BOZUK MAGIC: CRC saglam, kayit reddedilmeli ----
    // CRC alanı magic'i KAPSAMAZ. Bu yuzden yalnizca ilk 4 bayti
    // bozmak, kaydin CRC'sini gecerli birakir: testin amaci magic
    // kontrolunun CRC'den BAGIMSIZ olarak gercekten calistigini
    // gostermek (aksi halde bu kontrol CRC ile birlikte testte
    // olusuydi).
    if myKv.WriteAheadWAL(16, VDbStrToBytes('magic-bozulmus'), VDB_FLAG_PUT) then
      Ok('bozuk magic testi icin kayit yazildi', '')
    else
      No('bozuk magic testi icin kayit yazilamadi', '');
    fs := TFileStream.Create(myKv.WalPath, fmOpenReadWrite);
    try
      fs.Position := 0;
      mw := LongWord($DEADBEEF);
      fs.Write(mw, SizeOf(mw));      // yalnizca magic bozuldu
    finally
      fs.Free;
    end;
    if myKv.ReplayWAL then Ok('bozuk magic: replay yine de calisti', 'True')
    else No('bozuk magic: replay basarisiz', '');
    SetLength(v, 0);
    if myKv.Get(16, v) then No('bozuk magic kayit UYGULANDI', 'veri yazildi')
    else Ok('bozuk magic kayit reddedildi', 'uygulanmadi');
    // ---- 3c) ANLAMSIZ BAYRAK: magic VE CRC gecerli, kayit reddedilmeli ----
    // CRC alani bayragı da kapsar; "bayrağı boz" demek CRC'yi de
    // bozardi ve test bayrak kontrolunu izole etmezdi. Burada kayit
    // ELLE yazilir: once motorun kendi kaydiyla CRC formulu
    // DOGRULANIR, sonra bayrak 99 yapilip CRC o bayrak icin
    // YENIDEN hesaplanir -> tek secilebilir hata bayraktir.
    walVal := VDbStrToBytes('bayrak-bozuk');
    if myKv.WriteAheadWAL(17, walVal, VDB_FLAG_PUT) then
      Ok('bayrak testi icin referans kayit yazildi', '')
    else
      No('bayrak testi icin referans kayit yazilamadi', '');
    fs := TFileStream.Create(myKv.WalPath, fmOpenReadWrite);
    try
      if fs.Read(walRec, SizeOf(walRec)) <> SizeOf(walRec) then
        raise Exception.Create('wal kaydi okunamadi');
      WalCrc := WalTestCrc(walRec.Key, walRec.ValLen, VDB_FLAG_PUT, walVal);
      if WalCrc = walRec.Crc then
        Ok('CRC formulu motorun CRC ile ayni', 'CRC eslesti')
      else
        No('CRC formulu motorun CRC ile FARKLI', 'test gecersiz');
      // bayragi boz + CRC'yi yeni bayraka gore hesapla
      walRec.Flags := 99;                 // ne PUT ne DEL
      walRec.Crc := WalTestCrc(walRec.Key, walRec.ValLen, walRec.Flags, walVal);
      fs.Position := 0;
      fs.WriteBuffer(walRec, SizeOf(walRec));
    finally
      fs.Free;
    end;
    if myKv.ReplayWAL then Ok('bayrak bozuk: replay yine de calisti', 'True')
    else No('bayrak bozuk: replay basarisiz', '');
    SetLength(v, 0);
    if myKv.Get(17, v) then No('anlamsiz bayrakli kayit UYGULANDI', 'veri yazildi')
    else Ok('anlamsiz bayrakli kayit reddedildi', 'uygulanmadi');
    // ---- 3d) SILME kaydi deger tasimaz: DEL + ValLen>0 reddedilmeli ----
    // Ayni izolasyon mantigi: bayrak DEL, deger DOLU. CRC deger icin
    // yeniden hesaplanir -> reddi yalnizca "DEL deger tasimaz" kurali
    // saglar.
    // ANAHTAR ONCEDEN DOLDURULUR: boylece "reddedildi" ile "silindi"
    // birbirinden AYIRT EDILIR. Aksi halde anahtar zaten yoksa
    // her iki durumda da Get False doner ve test sahte yesil olurdu.
    myKv.Put(18, VDbStrToBytes('oldu'));
    SetLength(v, 0);
    if myKv.Get(18, v) and (VDbBytesToStr(v) = 'oldu') then
      Ok('DEL-deger testi icin anahtar dolduruldu', 'oldu')
    else
      No('DEL-deger testi icin anahtar doldurulamadi', '');
    if myKv.WriteAheadWAL(18, VDbStrToBytes('del-18'), VDB_FLAG_PUT) then
      Ok('DEL-deger testi icin referans kayit yazildi', '')
    else
      No('DEL-deger testi icin referans kayit yazilamadi', '');
    walVal := VDbStrToBytes('del-18');     // CRC bu deger icin hesaplanacak
    fs := TFileStream.Create(myKv.WalPath, fmOpenReadWrite);
    try
      if fs.Read(walRec, SizeOf(walRec)) <> SizeOf(walRec) then
        raise Exception.Create('wal kaydi okunamadi');
      WalCrc := WalTestCrc(walRec.Key, walRec.ValLen, VDB_FLAG_PUT, walVal);
      if WalCrc = walRec.Crc then
        Ok('DEL-deger testi: CRC formulu yine eslesti', 'CRC eslesti')
      else
        No('DEL-deger testi: CRC formulu FARKLI', 'test gecersiz');
      walRec.Flags := VDB_FLAG_DEL;       // silme, ama deger dolu
      walRec.Crc := WalTestCrc(walRec.Key, walRec.ValLen, walRec.Flags, walVal);
      fs.Position := 0;
      fs.WriteBuffer(walRec, SizeOf(walRec));
    finally
      fs.Free;
    end;
    if myKv.ReplayWAL then Ok('DEL-deger: replay yine de calisti', 'True')
    else No('DEL-deger: replay basarisiz', '');
    SetLength(v, 0);
    if myKv.Get(18, v) and (VDbBytesToStr(v) = 'oldu') then
      Ok('deger tasayan DEL kaydi reddedildi (veri korundu)', VDbBytesToStr(v))
    else No('deger tasayan DEL kaydi UYGULANDI', 'veri=' + VDbBytesToStr(v));


  finally
    myKv.Free;
  end;
  // ---- 4) CheckpointWAL: once REPLAY, sonra sil (yoksa veri kaybi) ----
  myKv := TVDb.Create;
  try
    myKv.Open(D + '\wal2');
    myKv.WriteAheadWAL(30, VDbStrToBytes('checkpoint-30'), VDB_FLAG_PUT);
    if myKv.CheckpointWAL then Ok('CheckpointWAL basarili', 'True')
    else No('CheckpointWAL basarisiz', '');
    SetLength(v, 0);
    if myKv.Get(30, v) and (VDbBytesToStr(v) = 'checkpoint-30') then
      Ok('checkpoint: kayit KAYBOLMADI', VDbBytesToStr(v))
    else No('checkpoint: kayit kayboldu', '');
    if myKv.HasWAL then No('checkpoint sonrasi .wal kaldi', 'kaldi')
    else Ok('checkpoint sonrasi .wal silindi', 'silindi');
    // dosya .wal'siz: yeni acilista da veri durmali
    myKv.Close;
    myKv.Open(D + '\wal2');
    SetLength(v, 0);
    if myKv.Get(30, v) and (VDbBytesToStr(v) = 'checkpoint-30') then
      Ok('reopen sonrasi checkpoint kaydi durur', 'kalici')
    else No('reopen sonrasi kayip', '');
    // ---- 4b) ONCEDEN BATCHEND OLAN DOSYAYA replay + yeniden acilis ----
    // Kritik dayaniklilik senaryosu. Recover, dosyada bir BATCHEND
    // GORMUSSE sonraki BATCHEND'siz kayitlari "commit edilmemis batch"
    // sayip GERI SARAR. Replay kayitlari BATCHEND'siz yazarsa:
    //   replay sonrasi Get calisir (FIndex bellekte hazir),
    //   ama yeniden acilista kayitlar SILINIR.
    // Yani yalniz "replay sonrasi Get" testi bu hatayi GORMEZ.
    myKv.BeginBatch;
    myKv.Put(100, VDbStrToBytes('batchend-oncesi'));
    myKv.CommitBatch;          // dosyada ilk BATCHEND olusur
    myKv.WriteAheadWAL(101, VDbStrToBytes('replay-101'), VDB_FLAG_PUT);
    myKv.WriteAheadWAL(102, VDbStrToBytes('replay-102'), VDB_FLAG_PUT);
    if myKv.ReplayWAL then Ok('BATCHEND li dosyaya replay basarili', 'True')
    else No('BATCHEND li dosyaya replay basarisiz', '');
    SetLength(v, 0);
    if myKv.Get(101, v) and (VDbBytesToStr(v) = 'replay-101') then
      Ok('replay sonrasi 101 bellekte okunuyor', 'replay-101')
    else No('replay sonrasi 101 bellekte yok', '');
    myKv.Close;
    myKv.Open(D + '\wal2');
    SetLength(v, 0);
    if myKv.Get(100, v) and (VDbBytesToStr(v) = 'batchend-oncesi') then
      Ok('reopen sonrasi 100 (BATCHEND oncesi) durur', 'kalici')
    else No('reopen sonrasi 100 kayboldu', '');
    SetLength(v, 0);
    if myKv.Get(101, v) and (VDbBytesToStr(v) = 'replay-101') then
      Ok('reopen sonrasi replay kaydi 101 KALICI', 'replay-101')
    else No('reopen sonrasi replay kaydi 101 KAYBOLDU', 'Recover geri sardi');
    SetLength(v, 0);
    if myKv.Get(102, v) and (VDbBytesToStr(v) = 'replay-102') then
      Ok('reopen sonrasi replay kaydi 102 KALICI', 'replay-102')
    else No('reopen sonrasi replay kaydi 102 KAYBOLDU', 'Recover geri sardi');
    // Verify de kayitlari saymali (BATCHEND sayaci > 0 olmali)
    rep := '';
    if myKv.Verify(rep) then
    begin
      if Copy(rep, 1, 40) = '' then No('Verify raporu bos', '')
      else if Pos('batchend=0', Copy(rep, 1, 60)) > 0 then
        No('replay BATCHEND yazmadi (Verify batchend=0)', Copy(rep, 1, 60))
      else
        Ok('replay sonrasi Verify saglam + BATCHEND var', Copy(rep, 1, 60));
    end
    else No('reopen sonrasi Verify bozuk', Copy(rep, 1, 60));
    // ---- 5) .wal yoksa replay True (yapilacak yok) ----
    if myKv.ReplayWAL then Ok('.wal yokken ReplayWAL True', 'True')
    else No('.wal yokken ReplayWAL False', '');
    // ---- 6) gecersiz bayrak reddedilir ----
    if myKv.WriteAheadWAL(40, nil, 99) then
      No('gecersiz bayrak kabul edildi', 'yazildi')
    else
      Ok('gecersiz bayrak reddedildi', '');
    // ---- 7) Verify bozulmamis olmali ----
    rep := '';
    if myKv.Verify(rep) then Ok('WAL sonrasi Verify saglam', Copy(rep, 1, 40))
    else No('WAL sonrasi Verify bozuk', Copy(rep, 1, 60));
  finally
    myKv.Free;
  end;
end;

procedure T73_OtomatikWAL;
{ 2026-10-04: OTOMATIK WAL.

  WALEnabled = True iken her kalici yazma (Put/Delete) ONCE .wal'a,
  SONRA ana dosyaya yazilir. Boylece cagri aninda sistem cokerse
  kayit .wal'da durur ve ReplayWAL ile kurtarilir.

  TASNIT EDILEN SEMANTIK:
    a) Varsayilan KAPALI -> mevcut kullanicilarin davranisi degismez.
    b) Put sonrasi .wal'da kayit var, otomatik sayac artmis.
    c) WAL yazma basarisizsa ANA DOSYAYA YAZILMAZ.
    d) CommitBatch .wal'a TEKRAR yazmaz (gunluk buymez).
    e) ReplayWAL kendi kaydini yeniden yazmaz (dongu olusmaz).
    f) Kapali iken hicbir sey .wal'a yazilmaz.
    g) Delete de otomatik gunluge girer.
    h) Checkpoint sonrasi gunluk temizlenir.
    i) Close/Open sonrasi WALEnabled sifirlanir.
}
var
  myKv: TVDb;
  v: TBytes;
  rep: string;
  wp: string;
  Hata: string;

  procedure Dogrula(const Ad: string; Cond: Boolean; const E: string = '');
  begin
    if Cond then Ok(Ad, E) else No(Ad, E);
  end;

begin
  Grp('OTOMATIK WAL (WALEnabled)');

  // ---- a) ve f) varsayilan KAPALI ----
  myKv := TVDb.Create;
  try
    myKv.Open(D + '\auto1.odb');
    Dogrula('varsayilan WALEnabled = False', not myKv.WALEnabled);
    myKv.Put(1, VDbStrToBytes('x'));
    Dogrula('kapali iken .wal YAZILMADI', not myKv.HasWAL);
    Dogrula('kapali iken otomatik sayac 0', myKv.WalAutoCount = 0,
      IntToStr(myKv.WalAutoCount));
  finally
    myKv.Free;
  end;

  // ---- b) acik iken Put otomatik gunluge gider ----
  myKv := TVDb.Create;
  try
    myKv.Open(D + '\auto2.odb');
    myKv.WALEnabled := True;
    Dogrula('WALEnabled = True', myKv.WALEnabled);

    myKv.Put(10, VDbStrToBytes('deger-10'));
    Dogrula('Put sonrasi .wal var', myKv.HasWAL);
    Dogrula('Put otomatik gunluge yazildi', myKv.WalRecordCount = 1,
      'kayit=' + IntToStr(myKv.WalRecordCount));
    Dogrula('otomatik sayac 1', myKv.WalAutoCount = 1,
      IntToStr(myKv.WalAutoCount));

    SetLength(v, 0);
    Dogrula('Put ana dosyaya da yazildi',
      myKv.Get(10, v) and (VDbBytesToStr(v) = 'deger-10'), VDbBytesToStr(v));

    myKv.Put(11, VDbStrToBytes('deger-11'));
    Dogrula('2. Put sonrasi 2 kayit', myKv.WalRecordCount = 2,
      IntToStr(myKv.WalRecordCount));

    // ---- g) Delete otomatik gunluge ----
    Dogrula('Delete basarili', myKv.Delete(10));
    Dogrula('Delete sonrasi 3 kayit', myKv.WalRecordCount = 3,
      IntToStr(myKv.WalRecordCount));
    Dogrula('Delete sayac 3', myKv.WalAutoCount = 3,
      IntToStr(myKv.WalAutoCount));

    // ---- d) batch .wal'a TEKRAR yazmaz ----
    myKv.BeginBatch;
    myKv.Put(20, VDbStrToBytes('b20'));
    myKv.Put(21, VDbStrToBytes('b21'));
    myKv.CommitBatch;
    Dogrula('batch 2 satir daha ekledi (toplam 5)', myKv.WalRecordCount = 5,
      IntToStr(myKv.WalRecordCount));
    Dogrula('CommitBatch gunlugu TEKRAR yazmadi (7 olsaydi hata vardi)',
      myKv.WalAutoCount = 5, 'sayac=' + IntToStr(myKv.WalAutoCount));
    SetLength(v, 0);
    Dogrula('batch verisi ana dosyada',
      myKv.Get(21, v) and (VDbBytesToStr(v) = 'b21'), VDbBytesToStr(v));

    // ---- e) replay dongusu yok ----
    Dogrula('ReplayWAL basarili', myKv.ReplayWAL);
    Dogrula('replay sonrasi gunluk SILINDI', not myKv.HasWAL);

    // ---- h) checkpoint sonrasi temiz ----
    myKv.Put(30, VDbStrToBytes('ckpt'));
    Dogrula('checkpoint oncesi kayit var', myKv.HasWAL);
    Dogrula('CheckpointWAL basarili', myKv.CheckpointWAL);
    Dogrula('checkpoint sonrasi .wal yok', not myKv.HasWAL);
    SetLength(v, 0);
    Dogrula('checkpoint verisi kalici',
      myKv.Get(30, v) and (VDbBytesToStr(v) = 'ckpt'), VDbBytesToStr(v));

    // ---- i) kapat-ac ----
    myKv.Close;
    myKv.Open(D + '\auto2.odb');
    SetLength(v, 0);
    Dogrula('reopen sonrasi b21 durur',
      myKv.Get(21, v) and (VDbBytesToStr(v) = 'b21'), VDbBytesToStr(v));
    SetLength(v, 0);
    Dogrula('reopen sonrasi silinen 10 YOK', not myKv.Get(10, v));
    Dogrula('reopen sonrasi WALEnabled sifirlandi', not myKv.WALEnabled);
    Dogrula('reopen sonrasi .wal yok', not myKv.HasWAL);
    Dogrula('reopen sonrasi Verify saglam', myKv.Verify(rep), Copy(rep, 1, 50));
  finally
    myKv.Free;
  end;

  // ---- c) WAL yazma basarisiz: ana dosyaya da YAZILMAZ ----
  myKv := TVDb.Create;
  try
    myKv.Open(D + '\auto3.odb');
    myKv.Put(1, VDbStrToBytes('ilk'));
    myKv.CheckpointWAL;
    myKv.WALEnabled := True;
    wp := myKv.WalPath;
    { .wal yolunu bir DIZIN ile isgal et. Motor WAL dosyasini acaraken
      hata alir (Windows'ta dizin acilamaz) -> test, WAL yazilamayinca
      ana dosyaya da yazilmadigini kanitlar.
      NOT 1: TFileStream ile 'kilit' denemesi ise calismiyor; FPC
      paylasim izni veriyor ve Put sessizce basarili oluyor.
      NOT 2: WAL adi ChangeFileExt(FPath,'.wal') -> 'auto3.odb' icin
      'auto3.wal'dir, 'auto3.odb.wal' DEGILDIR. }
    ForceDirectories(wp);
    Hata := '';
    try
      myKv.Put(2, VDbStrToBytes('ikinci'));
      Dogrula('WAL yazilamazsa Put HATA VERMELI', False, 'Put basarili oldu');
    except
      on E: Exception do
      begin
        Hata := E.ClassName + ': ' + E.Message;
        Dogrula('WAL yazilamazsa Put hata verdi', True, Copy(Hata, 1, 70));
      end;
    end;
    SetLength(v, 0);
    Dogrula('WAL yazilamadigi icin ana dosyaya da YAZILMADI',
      not myKv.Get(2, v));
    Dogrula('basarisiz yazma sonrasi Verify saglam', myKv.Verify(rep),
      Copy(rep, 1, 50));
  finally
    myKv.Free;
    RemoveDir(wp);
  end;
end;

{ ---------------------------------------------------------------------- main }

var
  arg: string;
  tmp: string;
begin
  nPass := 0; nFail := 0; nGrp := 0;
  sq := nil; tb := nil; kv := nil;
  if (ParamCount >= 1) and (Trim(ParamStr(1)) <> '') then
  begin
    D := ParamStr(1);
    ForceDirectories(D);
  end
  else
  begin
    tmp := GetTempDir(False) + 'vdbsqltest_' + FormatDateTime('yyyymmdd_hhnnss', Now);
    ForceDirectories(tmp);
    D := tmp;
  end;
  WriteLn('VDB SQL tam testi');
  WriteLn('Klasor: ', D);
  try
    try
      T01_Veritabani;
      T02_Tipler;
      T03_CreateKisit;
      T04_Insert;
      T05_SelectTemel;
      T06_Where;
      T07_TipKarsilastirma;
      T08_Join;
      T08b_JoinZincir;
      T08c_RightFullJoin;
      T08c_AltSorgu;
      T08d_CaseWhen;
      T08e_CTE;
      T08f_Pencere;
      T08g_Collation;
      T08h_CrossJoin;
      T08i_NaturalUsing;
      T08j_Lateral;
      T08k_MatView;
      T08l_ViewDML;
      T08i_JoinAggregate;
      T09_GroupAggregate;
      T09b_HavingAggregate;
      T09c_NotOrDNF;
      T09e_NullIfCoalesce;
      T09f_ILike;
      T09g_AnySomeAll;
      T09h_FetchFirstNulls;
      T09i_Qualify;
      T09j_AggDistinct;
      T09k_Filter;
      T09l_Explain;
      T09m_PartialIndex;
      T09n_ExprIndex;
      T09o_CoveringIndex;
      T09p_SlowQuery;
      T09r_Xml;
      T09s_Spatial;
      T09t_Range;
      T10_Update;
      T11_Delete;
      T12_Transaction;
      T13_AlterTable;
      T14_Index;
      T15_Bakim;
      T16_Parametreli;
      T17_Json;
      T18_Kalici;
      T19_Olcek;
      T20_CokluKayit;
      T21_KritikHataDogrulama;
      T22_MinMaxTipKiyas;
      T23_Blob;
      T24_Dayaniklilik;
      T25_F1_UnionSiraVeLimit;
      T26_F1_OrderByTip;
      T27_F1_OrderByBilinmeyenKolon;
      T28_F1_JoinTipKiyas;
      T29_F1_UpdateBilinmeyenKolon;
      T30_F1_DeleteDatabase;
      T31_F1_NotInNull;
      T32_F1_LimitGecersiz;
      T33_F1_SumBosKume;
      T34_F1_AlterRenameBozukSatir;
      T35_F1_OffsetAlias;
      T36_F1_RecoverKirpma;
      T37_F1_CommitBatchAtomik;
      T38_F1_CheckRestrictFiltresi;
      T39_F1_UniqueBayatAnahtar;
      T40_F1_AlterDropColumnFK;
      T41_F1_AlterAddColumnNotNull;
      T42_F1_BatchInsertAtomik;
      T43_F1_MigrateLegacy;
      T44_F1_ParserDerinlik;
      T45_F1_SplitStatements;
      T46_F2_SemaBozukSatir;
      T47_F2_BosTabloAdi;
      T48_F2_DropTableFK;
      T49_F2_SelfRefFK;
      T50_F2_IdxBLOBKarisim;
      T51_F2_DropColumnIdx;
      T52_F2_AlterColumnType;
      T53_F2_DDLAtomik;
      T54_F2_UnionDistinct;
      T55_F2_PencereBellek;
      T56_F2_AltSorgu;
      T57_F2_BozukDosya;
      T58_F2_VerifyBATCHEND;
    T59_F2_DizinFlush;
    T60_F2_WALKilit;
    T61_F2_GetDogruluk;
    T62_F2_DropColumnBatch;
    T63_F2_BozukKayitTespit;
    T64_F2_PKsizTablo;
    T65_F2_UniqueIndex;
    T66_F2_DropColCokKolluIndeks;
    T67_F3_Hijyen;
    T68_F3_CokKolluOndek;
    T69_YonetimAPI;
    T70_YonetimBakim;
    T71_SemaSorgulari;
    T72_WALReplay;
    T73_OtomatikWAL;
    T74_KayitSifreleme;
    T75_SifrelemeDayaniklilik;
    T76_ReplayWALSifreleme;
    T77_AlterDatabaseKey;
    T78_AsofGecmis;
    T79_Savepoint;

    except
      on E: Exception do
      begin
        Inc(nFail);
        WriteLn;
        WriteLn('!! KESILDI (', grpName, '): ', E.ClassName, ': ', E.Message);
      end;
    end;
  finally
    Shutdown;
  end;
  WriteLn;
  WriteLn('================================================');
  WriteLn('SONUC: gecen=', nPass, '  kalan=', nFail);
  if nFail = 0 then WriteLn('TUM SQL TESTLERI GECTI')
  else WriteLn('HATA VAR');
end.













