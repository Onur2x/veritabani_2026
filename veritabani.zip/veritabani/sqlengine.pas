unit sqlengine;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Variants, vtypes, vtablo, veritabani, Generics.Collections;

type
  TAlanSecimi = record
    Alan: string;
    TakmaAd: string;
  end;

type
  TSelectParcalari = record
    Alanlar: TStringArray;        // ['ad', 'yazar'] (artık kullanılmıyor, AlanListesi var)
    Tablo: string;                // 'kitaplar'
    Filtre: string;               // 'sayfa > 100 AND durum = ''aktif'''
    GroupBy: string;              // 'yazar'
    OrderBy: string;              // 'sayfa'
    OrderDesc: Boolean;           // true: DESC
    Limit: Integer;               // 10
    Having: string;
    AlanListesi: array of TAlanSecimi; // SELECT edilen alanlar ve takma adları
  end;



type
  TSqlEngine = class
  private
    FVeritabani: TVeritabani;
    FLastInfoMessage: string;
    FLastErrorMessage: string;
    FIsSuccess: Boolean;

    function ExecuteSelectWithGroup(const SP: TSelectParcalari): TKayitlar;
    function ParseAndExecuteCreate(const SQL: string): Boolean;
    function ParseAndExecuteDelete(const SQL: string): Boolean;
    function ParseAndExecuteDescribe(const SQL: string): TKayitlar;
    function ParseAndExecuteSelect(const SQL: string): TKayitlar; // Yeniden düzenlenecek
    function ParseAndExecuteShowTables: TKayitlar;
    function ParseAndExecuteUpdate(const SQL: string): Boolean;
    function ParseAndExecuteInsert(const SQL: string): Boolean;
    function ParseAndExecuteDrop(const SQL: string): Boolean; // Yeni DROP TABLE fonksiyonu
  public
    constructor Create(AVeritabani: TVeritabani);

    function ExecuteAndReturn(Lines: TStrings): TKayitlar;
    function ExecuteSQL(const Liste: TStrings): TKayitlar;
    property LastInfoMessage: string read FLastInfoMessage;
    property LastErrorMessage: string read FLastErrorMessage;
    property IsSuccess: Boolean read FIsSuccess;
  end;

var
  SiralamaAlan: string;
  SiralamaAzalan: Boolean;

implementation

uses
  StrUtils, TypInfo;


class function ByAlan(const A, B: TKayit): Integer;
var
  VA, VB: Variant;
begin
  A.TryGetDeger(SiralamaAlan, VA);
  B.TryGetDeger(SiralamaAlan, VB);
  Result := CompareStr(VarToStr(VA), VarToStr(VB));
  if SiralamaAzalan then
    Result := -Result;
end;

function ParcalaSQLKomutlari(const TumKomut: string): TStrings;
var
  satir, komut: string;
  i: Integer;
begin
  Result := TStringList.Create;
  komut := '';

  for i := 1 to Length(TumKomut) do
  begin
    satir := TumKomut[i];

    // Satır sonu ya da noktalı virgülle komut bitiyorsa
    if (satir = ';') or (satir = #10) or (satir = #13) then
    begin
      komut := Trim(komut);
      if komut <> '' then
      begin
        Result.Add(komut);
        komut := '';
      (end;
    end
    else
      komut := komut + satir;
  end;

  // Son komut varsa ekle
  komut := Trim(komut);
  if komut <> '' then
    Result.Add(komut);
end;


function ParseSelectAlanlari(const selectStr: string):specialize TArray<TAlanSecimi>;
var
  Parcalar: TStringArray;
  i: Integer;
  Alan, Takma: string;
  Tmp: TStringArray;
begin
  Parcalar := selectStr.Split([',']);
  SetLength(Result, Length(Parcalar));

  for i := 0 to High(Parcalar) do
  begin
    Tmp := Parcalar[i].Trim.Split([' ']);
    if (Length(Tmp) >= 3) and (UpperCase(Tmp[Length(Tmp) - 2]) = 'AS') then
    begin
      Alan := string.Join(' ', Tmp, 0, Length(Tmp) - 2); // "AVG(sayfa)"
      Takma := Tmp[Length(Tmp) - 1];
    end
    else
    begin
      Alan := Parcalar[i].Trim;
      Takma := '';
    end;

    Result[i].Alan := Alan;
    Result[i].TakmaAd := Takma;
  end;
end;


function ParseSelectSQL(const SQL: string): TSelectParcalari;
var
  s: string;
  iFrom, iWhere, iGroup, iOrder, iLimit, iHaving: Integer;
  selectStr, fromStr, whereStr, groupStr, orderStr, limitStr, havingStr, Kesici: string;
  temp: string;
  i: SizeInt;
begin
  FillChar(Result, SizeOf(TSelectParcalari), 0); // Kaydı sıfırla
  Result.Limit := -1; // Varsayılan limit değeri

  s := StringReplace(SQL, #13#10, ' ', [rfReplaceAll]);
  s := StringReplace(s, ';', '', [rfReplaceAll]);
  s := Trim(s);

  // Başlangıç pozisyonları
  iFrom := Pos(' FROM ', UpperCase(s));
  if iFrom = 0 then raise Exception.Create('FROM ifadesi eksik.');

  // 1. SELECT alanları
  selectStr := Copy(s, 8, iFrom - 8);
  Result.AlanListesi := ParseSelectAlanlari(selectStr);

  // 2. FROM tablo
  temp := Copy(s, iFrom + 6, MaxInt);

  iWhere := Pos(' WHERE ', UpperCase(temp));
  iGroup := Pos(' GROUP BY ', UpperCase(temp));
  iOrder := Pos(' ORDER BY ', UpperCase(temp));
  iLimit := Pos(' LIMIT ', UpperCase(temp));
  iHaving := Pos('HAVING', UpperCase(temp)); // Having'in pozisyonu temp içinde aranmalı

  // Tablo adını al
  fromStr := temp;
  if iWhere > 0 then fromStr := Copy(fromStr, 1, iWhere - 1)
  else if iGroup > 0 then fromStr := Copy(fromStr, 1, iGroup - 1)
  else if iOrder > 0 then fromStr := Copy(fromStr, 1, iOrder - 1)
  else if iLimit > 0 then fromStr := Copy(fromStr, 1, iLimit - 1);
  Result.Tablo := Trim(fromStr);

  // WHERE filtresi
  if iWhere > 0 then
  begin
    whereStr := Copy(temp, iWhere + 7, MaxInt);
    if iGroup > 0 then whereStr := Copy(whereStr, 1, iGroup - iWhere - 7)
    else if iOrder > 0 then whereStr := Copy(whereStr, 1, iOrder - iWhere - 7)
    else if iLimit > 0 then whereStr := Copy(whereStr, 1, iLimit - iWhere - 7)
    else if iHaving > 0 then whereStr := Copy(whereStr, 1, iHaving - iWhere - 7);
    Result.Filtre := Trim(whereStr);
  end;

  // HAVING filtresi (WHERE'den sonra veya bağımsız olabilir)
  if iHaving > 0 then
  begin
    havingStr := Copy(temp, iHaving + 6, MaxInt);
    // ORDER BY veya LIMIT varsa onları sil
    for Kesici in ['ORDER BY', 'LIMIT'] do
    begin
      i := Pos(Kesici, UpperCase(havingStr));
      if i > 0 then
        Delete(havingStr, i, MaxInt);
    end;
    Result.Having := Trim(havingStr);
  end;


  // GROUP BY
  if iGroup > 0 then
  begin
    groupStr := Copy(temp, iGroup + 9, MaxInt);
    if iOrder > 0 then groupStr := Copy(groupStr, 1, iOrder - iGroup - 9)
    else if iLimit > 0 then groupStr := Copy(groupStr, 1, iLimit - iGroup - 9)
    else if iHaving > 0 then groupStr := Copy(groupStr, 1, iHaving - iGroup - 9); // Having kontrolü eklendi
    Result.GroupBy := Trim(groupStr);
  end;

  // ORDER BY
  if iOrder > 0 then
  begin
    orderStr := Copy(temp, iOrder + 9, MaxInt);
    if Pos(' DESC', UpperCase(orderStr)) > 0 then
    begin
      Result.OrderDesc := True;
      orderStr := StringReplace(orderStr, 'DESC', '', [rfIgnoreCase]);
    end
    else
      Result.OrderDesc := False;

    if iLimit > 0 then
      orderStr := Copy(orderStr, 1, iLimit - iOrder - 9);

    Result.OrderBy := Trim(orderStr);
  end;

  // LIMIT
  if iLimit > 0 then
  begin
    limitStr := Trim(Copy(temp, iLimit + 6, MaxInt));
    Result.Limit := StrToIntDef(limitStr, -1);
  end
  else
    Result.Limit := -1;
end;


function EvaluateCondition(const K: TKayit; const Condition: string): Boolean;
var
  Parts: TStringArray;
  Alan: string;
  Operator: string;
  DegerStr: string;
  V: Variant;
  TargetValue: Variant;
begin
  // Basit koşul ayrıştırma (örn: "alan = 'deger'", "sayi > 10")
  if Pos('>=', Condition) > 0 then Operator := '>='
  else if Pos('<=', Condition) > 0 then Operator := '<='
  else if Pos('<>', Condition) > 0 then Operator := '<>'
  else if Pos('=', Condition) > 0 then Operator_ := '='
  else if Pos('>', Condition) > 0 then Operator_ := '>'
  else if Pos('<', Condition) > 0 then Operator_ := '<'
  else if Pos(' LIKE ', UpperCase(Condition)) > 0 then Operator_ := ' LIKE '
  else
    raise Exception.Create('Desteklenmeyen kosul operatoru: ' + Condition);

  Parts := Condition.Split([Operator_]);
  if Length(Parts) <> 2 then
    raise Exception.Create('Kosul formati hatali: ' + Condition);

  Alan := Trim(Parts[0]);
  DegerStr := Trim(Parts[1]);

  // Tek tırnaklıysa kaldır
  if (Length(DegerStr) > 1) and (DegerStr[1] = '''') and (DegerStr[Length(DegerStr)] = '''') then
    DegerStr := Copy(DegerStr, 2, Length(DegerStr) - 2);

  // Alanın değeri alınır
  if not K.TryGetDeger(Alan, V) then
  begin
    Result := False; // Alan yoksa koşul sağlanmaz
    Exit;
  end;

  // Hedef değeri uygun tipe dönüştürmeye çalış
  // Basit bir yaklaşım, daha sağlam tip dönüşümü için TAlanTuru kullanılabilir
  try
    if TryStrToInt(DegerStr, TargetValue) then
      // Integer
    else if TryStrToFloat(DegerStr, TargetValue) then
      // Float
    else if SameText(DegerStr, 'TRUE') then
      TargetValue := True
    else if SameText(DegerStr, 'FALSE') then
      TargetValue := False
    else
      TargetValue := DegerStr; // String
  except
    TargetValue := DegerStr; // Dönüşüm başarısız olursa string olarak kabul et
  end;


  case Operator_ of
    '=': Result := VarCompareValue(V, TargetValue) = vrEqual;
    '<>': Result := VarCompareValue(V, TargetValue) <> vrEqual;
    '>': Result := VarCompareValue(V, TargetValue) = vrGreaterThan;
    '<': Result := VarCompareValue(V, TargetValue) = vrLessThan;
    '>=': Result := (VarCompareValue(V, TargetValue) = vrGreaterThan) or (VarCompareValue(V, TargetValue) = vrEqual);
    '<=': Result := (VarCompareValue(V, TargetValue) = vrLessThan) or (VarCompareValue(V, TargetValue) = vrEqual);
    ' LIKE ':
      begin
        // LIKE operatörü için basit wildcard desteği
        var Pattern := DegerStr;
        var ValueStr := VarToStr(V);
        Result := False;

        // %pattern%
        if (Length(Pattern) >= 2) and (Pattern[1] = '%') and (Pattern[Length(Pattern)] = '%') then
          Result := Pos(Copy(Pattern, 2, Length(Pattern) - 2), ValueStr) > 0
        // pattern%
        else if (Length(Pattern) >= 1) and (Pattern[Length(Pattern)] = '%') then
          Result := StartsText(Copy(Pattern, 1, Length(Pattern) - 1), ValueStr)
        // %pattern
        else if (Length(Pattern) >= 1) and (Pattern[1] = '%') then
          Result := EndsText(Copy(Pattern, 2, MaxInt), ValueStr)
        // Tam eşleşme
        else
          Result := SameText(ValueStr, Pattern);
      end;
  else
    Result := False;
  end;
end;


function FilterKayitlar(Kayitlar: TKayitlar; const Filtre: string): TKayitlar;
var
  i: Integer;
  K: TKayit;
  Conditions: TStringArray;
  AllConditionsMet: Boolean;
  Condition: string;
begin
  Result := TKayitlar.Create;

  if Trim(Filtre) = '' then
  begin
    Result.Assign(Kayitlar); // filtre yoksa hepsini kopyala
    Exit;
  end;

  // Filtre stringini ' AND ' ile parçala (şimdilik sadece AND desteği)
  // Daha karmaşık WHERE koşulları için (OR, parantezler) daha gelişmiş bir ayrıştırıcı gerekir.
  Conditions := Filtre.Split([' AND '], StringSplitOptions.ExcludeEmpty);

  for i := 0 to Kayitlar.Count - 1 do
  begin
    K := Kayitlar[i];
    AllConditionsMet := True;

    for Condition in Conditions do
    begin
      if not EvaluateCondition(K, Trim(Condition)) then
      begin
        AllConditionsMet := False;
        Break;
      end;
    end;

    if AllConditionsMet then
      Result.Add(K);
  end;
end;


function CountByGroupInList(Kayitlar: TKayitlar; const AlanAdi: string): TKayitlar;
var
  Map: TDictionary<string, Integer>;
  i: Integer;
  CurrentCount: Integer;
  Deger: Variant;
  K, R: TKayit;
begin
  Result := TKayitlar.Create;

  Map := TDictionary<string, Integer>.Create;
  try
    for i := 0 to Kayitlar.Count - 1 do
    begin
      K := Kayitlar[i];
      if K.TryGetDeger(AlanAdi, Deger) then
      begin
        if Map.TryGetValue(VarToStr(Deger), CurrentCount) then
          Map[VarToStr(Deger)] := CurrentCount + 1
        else
          Map.Add(VarToStr(Deger), 1);
      end;
    end;

    for Deger in Map.Keys do
    begin
      R := TKayit.Create;
      R.SetDeger(AlanAdi, Deger);
      R.SetDeger('COUNT(*)', Map[Deger]);
      Result.Add(R);
    end;

  finally
    Map.Free;
  end;
end;


function SiralaVeSinirla(Kayitlar: TKayitlar; const Alan: string; Azalan: Boolean; Limit: Integer): TKayitlar;
begin
  Result := TKayitlar.Create;
  Result.Assign(Kayitlar); // kopyasını al

  SiralamaAlan := alan;
  SiralamaAzalan := Azalan;

  Result.Sort(@ByAlan);

  if (Limit > 0) and (Result.Count > Limit) then
    while Result.Count > Limit do
      Result.Delete(Result.Count - 1);
end;

function GroupByWithAggregate(Kayitlar: TKayitlar; const GrupAlan, FonksiyonStr: string): TKayitlar;
var
  Map: TDictionary<string, Variant>;
  CountMap: TDictionary<string, Integer>;
  i: Integer;
  CurrentValue: Variant;
  CurrentCount: Integer;
  GrupDeger: Variant;
  Deger: Variant;
  K, R: TKayit;
  AgregeAlan: string;
  FonksiyonAdi: string;
begin
  Result := TKayitlar.Create;
  Map := TDictionary<string, Variant>.Create;
  CountMap := TDictionary<string, Integer>.Create;
  try
    FonksiyonAdi := UpperCase(Copy(FonksiyonStr, 1, Pos('(', FonksiyonStr) - 1));
    AgregeAlan := Copy(FonksiyonStr, Pos('(', FonksiyonStr) + 1, Pos(')', FonksiyonStr) - Pos('(', FonksiyonStr) - 1);
    AgregeAlan := Trim(AgregeAlan);

    for i := 0 to Kayitlar.Count - 1 do
    begin
      K := Kayitlar[i];
      if not K.TryGetDeger(GrupAlan, GrupDeger) then
        Continue;
      if not K.TryGetDeger(AgregeAlan, Deger) then
        Continue;

      if not Map.TryGetValue(VarToStr(GrupDeger), CurrentValue) then
      begin
        if FonksiyonAdi = 'MAX' then Map.Add(VarToStr(GrupDeger), Deger)
        else if FonksiyonAdi = 'MIN' then Map.Add(VarToStr(GrupDeger), Deger)
        else begin
          Map.Add(VarToStr(GrupDeger), Deger);
          CountMap.Add(VarToStr(GrupDeger), 1);
        end;
      end
      else
      begin
        case FonksiyonAdi of
          'SUM', 'AVG':
            begin
              Map[VarToStr(GrupDeger)] := CurrentValue + Deger;
              CountMap[VarToStr(GrupDeger)] := CountMap[VarToStr(GrupDeger)] + 1;
            end;
          'MAX':
            if Deger > CurrentValue then
              Map[VarToStr(GrupDeger)] := Deger;
          'MIN':
            if Deger < CurrentValue then
              Map[VarToStr(GrupDeger)] := Deger;
        end;
      end;
    end;

    for GrupDeger in Map.Keys do
    begin
      R := TKayit.Create;
      R.SetDeger(GrupAlan, GrupDeger);
      if FonksiyonAdi = 'AVG' then
        R.SetDeger(FonksiyonAdi + '(' + AgregeAlan + ')', Map[GrupDeger] / CountMap[GrupDeger])
      else
        R.SetDeger(FonksiyonAdi + '(' + AgregeAlan + ')', Map[GrupDeger]);
      Result.Add(R);
    end;

  finally
    Map.Free;
    CountMap.Free;
  end;
end;


function CountByMultipleKeys(Kayitlar: TKayitlar; const GrupAlanlari: array of string): TKayitlar;
var
  Map: TDictionary<string, Integer>;
  i, j: Integer;
  CurrentCount: Integer;
  Key: string;
  Deger: Variant;
  K, R: TKayit;
  AnahtarDegerler: TStringList;
begin
  Result := TKayitlar.Create;
  Map := TDictionary<string, Integer>.Create;
  AnahtarDegerler := TStringList.Create;
  try
    for i := 0 to Kayitlar.Count - 1 do
    begin
      K := Kayitlar[i];
      Key := '';
      AnahtarDegerler.Clear;

      for j := 0 to High(GrupAlanlari) do
      begin
        if not K.TryGetDeger(GrupAlanlari[j], Deger) then
          Deger := '';
        AnahtarDegerler.Values[GrupAlanlari[j]] := VarToStr(Deger);
      end;

      Key := AnahtarDegerler.Text.Replace(sLineBreak, '|');

      if Map.TryGetValue(Key, CurrentCount) then
        Map[Key] := CurrentCount + 1
      else
        Map.Add(Key, 1);
    end;

    for Key in Map.Keys do
    begin
      R := TKayit.Create;
      AnahtarDegerler.Clear;
      AnahtarDegerler.Text := StringReplace(Key, '|', sLineBreak, [rfReplaceAll]);

      for j := 0 to AnahtarDegerler.Count - 1 do
        R.SetDeger(AnahtarDegerler.Names[j], AnahtarDegerler.ValueFromIndex[j]);

      R.SetDeger('COUNT(*)', Map[Key]);
      Result.Add(R);
    end;

  finally
    Map.Free;
    AnahtarDegerler.Free;
  end;
end;


function GroupByWithAggregateMultiple(Kayitlar: TKayitlar; const GrupAlanlari: array of string; const FonksiyonStr: string): TKayitlar;
var
  Map: TDictionary<string, Variant>;
  CountMap: TDictionary<string, Integer>;
  i, j: Integer;
  CurrentValue: Variant;
  CurrentCount: Integer;
  GrupKey: string;
  Deger: Variant;
  K, R: TKayit;
  AnahtarDegerler: TStringList;
  AgregeAlan, FonksiyonAdi: string;
begin
  Result := TKayitlar.Create;
  Map := TDictionary<string, Variant>.Create;
  CountMap := TDictionary<string, Integer>.Create;
  AnahtarDegerler := TStringList.Create;
  try
    FonksiyonAdi := UpperCase(Copy(FonksiyonStr, 1, Pos('(', FonksiyonStr) - 1));
    AgregeAlan := Copy(FonksiyonStr, Pos('(', FonksiyonStr) + 1, Pos(')', FonksiyonStr) - Pos('(', FonksiyonStr) - 1);
    AgregeAlan := Trim(AgregeAlan);

    for i := 0 to Kayitlar.Count - 1 do
    begin
      K := Kayitlar[i];
      GrupKey := '';
      AnahtarDegerler.Clear;

      for j := 0 to High(GrupAlanlari) do
      begin
        if not K.TryGetDeger(GrupAlanlari[j], Deger) then
          Deger := '';
        AnahtarDegerler.Values[GrupAlanlari[j]] := VarToStr(Deger);
      end;

      GrupKey := AnahtarDegerler.Text.Replace(sLineBreak, '|');

      if not K.TryGetDeger(AgregeAlan, Deger) then
        Continue;

      if not Map.TryGetValue(GrupKey, CurrentValue) then
      begin
        if (FonksiyonAdi = 'MAX') or (FonksiyonAdi = 'MIN') then
          Map.Add(GrupKey, Deger)
        else begin
          Map.Add(GrupKey, Deger);
          CountMap.Add(GrupKey, 1);
        end;
      end
      else
      begin
        case FonksiyonAdi of
          'SUM', 'AVG':
            begin
              Map[GrupKey] := CurrentValue + Deger;
              CountMap[GrupKey] := CountMap[GrupKey] + 1;
            end;
          'MAX':
            if Deger > CurrentValue then
              Map[GrupKey] := Deger;
          'MIN':
            if Deger < CurrentValue then
              Map[GrupKey] := Deger;
        end;
      end;
    end;

    for GrupKey in Map.Keys do
    begin
      R := TKayit.Create;
      AnahtarDegerler.Clear;
      AnahtarDegerler.Text := StringReplace(GrupKey, '|', sLineBreak, [rfReplaceAll]);

      for j := 0 to AnahtarDegerler.Count - 1 do
        R.SetDeger(AnahtarDegerler.Names[j], AnahtarDegerler.ValueFromIndex[j]);

      if FonksiyonAdi = 'AVG' then
        R.SetDeger(FonksiyonAdi + '(' + AgregeAlan + ')', Map[GrupKey] / CountMap[GrupKey])
      else
        R.SetDeger(FonksiyonAdi + '(' + AgregeAlan + ')', Map[GrupKey]);

      Result.Add(R);
    end;

  finally
    Map.Free;
    CountMap.Free;
    AnahtarDegerler.Free;
  end;
end;

function FilterHaving(Kayitlar: TKayitlar; const Kosul: string): TKayitlar;
var
  i: Integer;
  K: TKayit;
begin
  Result := TKayitlar.Create;

  if Trim(Kosul) = '' then
  begin
    Result.Assign(Kayitlar);
    Exit;
  end;

  for i := 0 to Kayitlar.Count - 1 do
  begin
    K := Kayitlar[i];
    if EvaluateCondition(K, Kosul) then // EvaluateCondition kullanıldı
      Result.Add(K);
  end;
end;

function TSqlEngine.ExecuteSelectWithGroup(const SP: TSelectParcalari): TKayitlar;
var
  Tablo: TVTablo;
  KayitlarFiltreli: TKayitlar;
  GrupAlanlari: TStringArray;
  FonksiyonStr: string;
  i: Integer;
  SecilenKayitlar: TKayitlar;
  AlanSecimi: TAlanSecimi;
  YeniKayit: TKayit;
  OriginalValue: Variant;
begin
  Tablo := FVeritabani.TabloGetir(SP.Tablo);
  if not Assigned(Tablo) then
    raise Exception.Create('Tablo bulunamadi: ' + SP.Tablo);

  // 1. WHERE filtresi
  KayitlarFiltreli := FilterKayitlar(Tablo.Kayitlari, SP.Filtre);

  // 2. GROUP BY ve Aggregate Fonksiyonları
  if SP.GroupBy <> '' then
  begin
    GrupAlanlari := SP.GroupBy.Split([',']);
    for i := 0 to High(GrupAlanlari) do
      GrupAlanlari[i] := Trim(GrupAlanlari[i]);

    if Length(SP.AlanListesi) = 0 then
      raise Exception.Create('SELECT alan listesi bos!');

    // Aggregate fonksiyonunu bul
    FonksiyonStr := '';
    for AlanSecimi in SP.AlanListesi do
    begin
      if (Pos('(', AlanSecimi.Alan) > 0) and (Pos(')', AlanSecimi.Alan) > 0) then
      begin
        FonksiyonStr := AlanSecimi.Alan;
        Break;
      end;
    end;

    if FonksiyonStr = '' then
      raise Exception.Create('GROUP BY ile aggregate fonksiyonu (örn: COUNT(*), SUM(), AVG(), MAX(), MIN()) kullanilmalidir.');

    if UpperCase(FonksiyonStr) = 'COUNT(*)' then
      SecilenKayitlar := CountByMultipleKeys(KayitlarFiltreli, GrupAlanlari)
    else
      SecilenKayitlar := GroupByWithAggregateMultiple(KayitlarFiltreli, GrupAlanlari, FonksiyonStr);
  end
  else
  begin
    // GROUP BY yoksa, sadece WHERE ile filtrelenmiş kayıtları al
    SecilenKayitlar := TKayitlar.Create;
    SecilenKayitlar.Assign(KayitlarFiltreli);
  end;

  KayitlarFiltreli.Free; // Geçici listeyi serbest bırak

  // 3. HAVING filtresi
  if SP.Having <> '' then
  begin
    var HavingFiltreli := FilterHaving(SecilenKayitlar, SP.Having);
    SecilenKayitlar.Free;
    SecilenKayitlar := HavingFiltreli;
  end;

  // 4. ORDER BY
  if SP.OrderBy <> '' then
    SecilenKayitlar := SiralaVeSinirla(SecilenKayitlar, SP.OrderBy, SP.OrderDesc, MaxInt); // Limit daha sonra uygulanacak

  // 5. Alan seçimi ve Takma Adlar
  Result := TKayitlar.Create;
  for var K in SecilenKayitlar do
  begin
    YeniKayit := TKayit.Create;
    for AlanSecimi in SP.AlanListesi do
    begin
      // Eğer alan aggregate fonksiyonu ise
      if (Pos('(', AlanSecimi.Alan) > 0) and (Pos(')', AlanSecimi.Alan) > 0) then
      begin
        if K.TryGetDeger(LowerCase(AlanSecimi.Alan), OriginalValue) then
        begin
          if AlanSecimi.TakmaAd <> '' then
            YeniKayit.SetDeger(AlanSecimi.TakmaAd, OriginalValue)
          else
            YeniKayit.SetDeger(AlanSecimi.Alan, OriginalValue);
        end;
      end
      else // Normal alan ise
      begin
        if K.TryGetDeger(LowerCase(AlanSecimi.Alan), OriginalValue) then
        begin
          if AlanSecimi.TakmaAd <> '' then
            YeniKayit.SetDeger(AlanSecimi.TakmaAd, OriginalValue)
          else
            YeniKayit.SetDeger(AlanSecimi.Alan, OriginalValue);
        end;
      end;
    end;
    Result.Add(YeniKayit);
  end;
  SecilenKayitlar.Free;

  // 6. LIMIT
  if (SP.Limit > 0) and (Result.Count > SP.Limit) then
    while Result.Count > SP.Limit do
      Result.Delete(Result.Count - 1);
end;


constructor TSqlEngine.Create(AVeritabani: TVeritabani);
begin
  inherited Create;
  FVeritabani := AVeritabani;
end;

function TSqlEngine.ExecuteSQL(const Liste: TStrings): TKayitlar;
var
  i: Integer;
  Komut: string;
begin
  Result := nil;
  for i := 0 to Liste.Count - 1 do
  begin
    Komut := Trim(Liste[i]);

    if Komut = '' then Continue;

    if Komut.StartsWith('SELECT', True) then
      Exit(ParseAndExecuteSelect(Komut))
    else if Komut.StartsWith('INSERT INTO', True) then
      ParseAndExecuteInsert(Komut)
    else if Komut.StartsWith('CREATE TABLE', True) then
      ParseAndExecuteCreate(Komut)
    else if Komut.StartsWith('UPDATE', True) then
      ParseAndExecuteUpdate(Komut)
    else if Komut.StartsWith('DELETE FROM', True) then
      ParseAndExecuteDelete(Komut)
    else if Komut.StartsWith('DROP TABLE', True) then // Yeni DROP TABLE komutu
      ParseAndExecuteDrop(Komut)
    else
    begin
      FLastErrorMessage := 'Bilinmeyen komut: ' + Komut;
      FIsSuccess := False;
      Exit(nil);
    end;
  end;
end;


function TSqlEngine.ExecuteAndReturn(Lines: TStrings): TKayitlar;
var
  i: Integer;
  Komut: string;
  SP: TSelectParcalari;

begin
  Result := nil;
  FIsSuccess := False;
  FLastErrorMessage := '';
  FLastInfoMessage := '';

  for i := 0 to Lines.Count - 1 do
  begin
    Komut := Trim(Lines[i]);
    if Komut = '' then Continue;

    if Komut.StartsWith('SELECT', True) then
    begin
      SP := ParseSelectSQL(Komut);
      Result := ExecuteSelectWithGroup(SP);

      Exit; // SELECT sonucu varsa direkt çık (tek SELECT kabul)
    end
    else if Komut.StartsWith('INSERT INTO', True) then
      ParseAndExecuteInsert(Komut)
    else if Komut.StartsWith('CREATE TABLE', True) then
      ParseAndExecuteCreate(Komut)
    else if Komut.StartsWith('UPDATE', True) then
      ParseAndExecuteUpdate(Komut)
    else if Komut.StartsWith('DELETE FROM', True) then
      ParseAndExecuteDelete(Komut)
    else if Komut.StartsWith('DROP TABLE', True) then // Yeni DROP TABLE komutu
      ParseAndExecuteDrop(Komut)
    else if Komut.StartsWith('SHOW TABLES', True) then
      Exit(ParseAndExecuteShowTables)
    else if Komut.StartsWith('DESCRIBE ', True) then
      Exit(ParseAndExecuteDescribe(Komut))
    else
    begin
      FLastErrorMessage := 'Bilinmeyen SQL komutu: ' + Komut;
      FIsSuccess := False;
      Exit(nil);
    end;

    // Eğer komut başarısız olduysa döngüyü sonlandır
    if not FIsSuccess then Exit(nil);
  end;

  // SELECT yoksa ama komutlar başarılıysa bu noktaya geliriz
  FIsSuccess := True;
  FLastInfoMessage := 'Tum islemler basariyla tamamlandi.';
end;

function AyiklaTabloAdi(const S: string): string;
const
  Kesiciler: array[0..3] of string = ('WHERE', 'ORDER BY', 'LIMIT', ';');
var
  i, p, enKucuk: Integer;
begin
  Result := S;
  enKucuk := MaxInt;

  for i := 0 to High(Kesiciler) do
  begin
    p := Pos(UpperCase(Kesiciler[i]), UpperCase(S));
    if (p > 0) and (p < enKucuk) then
      enKucuk := p;
  end;

  if enKucuk <> MaxInt then
    Result := Trim(Copy(S, 1, enKucuk - 1))
  else
    Result := Trim(S);
end;

function TSqlEngine.ParseAndExecuteInsert(const SQL: string): Boolean;
var
  s, tabloAdi, kolonStr, valuesStr, parca, alan, raw, metin: string;
  par1, par2, i, j, degersayisi: Integer;
  kolonlar, valueGruplari: TStringArray;
  tablo: TVTablo;
  aktifAlanlar: TStringList;
  V: Variant;
  k: TKayit;
  alanTuru: TAlanTuru;
begin
  Result := False;
  FLastInfoMessage := '';
  FLastErrorMessage := '';
  FIsSuccess := False;

  try
    s := Trim(SQL);

    if not s.StartsWith('INSERT INTO', True) then
      raise Exception.Create('Komut INSERT INTO ile baslamali.');

    par1 := Pos('(', s);
    par2 := Pos(')', s);
    if (par1 = 0) or (par2 = 0) then
      raise Exception.Create('Parantezler eksik veya hatali.');

    tabloAdi := Trim(Copy(s, Length('INSERT INTO') + 1, par1 - Length('INSERT INTO') - 1));
    kolonStr := Copy(s, par1 + 1, par2 - par1 - 1);
    kolonlar := kolonStr.Split([',']);

    i := Pos('VALUES', UpperCase(s));
    if i = 0 then raise Exception.Create('VALUES bolumu eksik.');
    valuesStr := Trim(Copy(s, i + 6, MaxInt));
    valuesStr := StringReplace(valuesStr, ';', '', [rfReplaceAll]);

    tablo := FVeritabani.TabloGetir(tabloAdi);
    if not Assigned(tablo) then
      raise Exception.Create('Tablo bulunamadi: ' + tabloAdi);

    aktifAlanlar := TStringList.Create;
    try
      aktifAlanlar.CaseSensitive := False;
      aktifAlanlar.Duplicates := dupError;

      for j := 0 to High(kolonlar) do
      begin
        alan := Trim(kolonlar[j]);
        if tablo.AlanTuruGetir(alan) <> ftAutoIncrement then
          aktifAlanlar.Add(alan);
      end;

      valuesStr := StringReplace(valuesStr, '),(', ')|(', [rfReplaceAll]);
      valueGruplari := valuesStr.Split(['|']);

      for i := 0 to High(valueGruplari) do
      begin
        parca := valueGruplari[i];
        parca := StringReplace(parca, '(', '', [rfReplaceAll]);
        parca := StringReplace(parca, ')', '', [rfReplaceAll]);

        degersayisi := Length(parca.Split([',']));

        if degersayisi <> aktifAlanlar.Count then
          raise Exception.CreateFmt('Kolon sayisi (%d) ile deger sayisi (%d) eslesmiyor. INSERT satiri %d',
            [aktifAlanlar.Count, degersayisi, i + 1]);

        k := TKayit.Create;
        try
          for j := 0 to aktifAlanlar.Count - 1 do
          begin
            raw := Trim(ExtractWord(j + 1, parca, [',']));
            metin := VarToStrDef(raw, '');

            // Alanın türüne göre otomatik dönüşüm
            alan := aktifAlanlar[j];
            alanTuru := tablo.AlanTuruGetir(alan);
            V := TypedValueFromJSON(AlanTuruToStr(alanTuru), metin);

            k.SetDeger(alan, V);
          end;

          if not tablo.KayitEkle2(k) then
            raise Exception.CreateFmt('INSERT hatasi. %d. kayitta dogrulama sorunu.', [i + 1]);
        finally
          // KayitEkle2 başarılı olursa k nesnesinin sahipliği tabloya geçer, burada Free etmeyiz.
          // Başarısız olursa KayitEkle2 zaten Free etmelidir (veya burada kontrol edilmeli).
          // Mevcut implementasyonda KayitEkle2 başarısız olursa k'yi Free etmiyor,
          // bu yüzden KayitEkle'nin try..finally bloğu k'yi serbest bırakmalı.
          // Burada k'nin Free edilmesi durumu, KayitEkle2'nin iç mantığına bağlıdır.
          // Şimdilik, KayitEkle2'nin başarılı olması durumunda Free edilmemesi gerektiğini varsayıyoruz.
        end;
      end;
    finally
      aktifAlanlar.Free;
    end;

    FLastInfoMessage := Format('INSERT islemi tamamlandi (%d kayit)', [Length(valueGruplari)]);
    FIsSuccess := True;
    Result := True;
  except
    on E: Exception do
    begin
      FLastErrorMessage := 'INSERT hatasi: ' + E.Message;
      FIsSuccess := False;
      Result := False;
    end;
  end;
end;

function TSqlEngine.ParseAndExecuteCreate(const SQL: string): Boolean;
var
  s, tabloAdi, kolonlarStr, satir: string;
  par1, par2, i, j: Integer;
  kolonlar, parcalar: TStringArray;
  Alan: TAlanKaydi;
  yeniTablo: TVTablo;
begin
  Result := False;
  FLastErrorMessage := '';
  FLastInfoMessage := '';
  FIsSuccess := False;

  try
    s := Trim(SQL);
    if not s.StartsWith('CREATE TABLE', True) then Exit;

    par1 := Pos('(', s);
    par2 := LastDelimiter(')', s);
    if (par1 = 0) or (par2 = 0) then
      raise Exception.Create('Parantezler eksik.');

    tabloAdi := Trim(Copy(s, Length('CREATE TABLE') + 1, par1 - Length('CREATE TABLE') - 1));
    kolonlarStr := Trim(Copy(s, par1 + 1, par2 - par1 - 1));
    kolonlar := kolonlarStr.Split([',']);

    yeniTablo := TVTablo.Create(tabloAdi);
    try
      for i := 0 to High(kolonlar) do
      begin
        satir := Trim(kolonlar[i]);
        if satir = '' then Continue;

        parcalar := satir.Split([' ']);
        if Length(parcalar) < 2 then
          raise Exception.Create('Kolon tanimi yetersiz: ' + satir);

        Alan.Ad := parcalar[0];
        Alan.Tur := StrToAlanTuru(parcalar[1]);
        Alan.Zorunlu := False;
        Alan.Benzersiz := False;
        Alan.Sayac := 0; // Varsayılan değer atandı
        Alan.Uzunluk := 0; // Varsayılan değer atandı
        Alan.Varsayilan := Null; // Varsayılan değer atandı

        j := 2;
        while j <= High(parcalar) do
        begin
          if (UpperCase(parcalar[j]) = 'PRIMARY') and
             (j < High(parcalar)) and (UpperCase(parcalar[j + 1]) = 'KEY') then
          begin
            Alan.Benzersiz := True;
            Alan.Zorunlu := True;
            Inc(j, 2);
          end
          else if (UpperCase(parcalar[j]) = 'NOT') and
                  (j < High(parcalar)) and (UpperCase(parcalar[j + 1]) = 'NULL') then
          begin
            Alan.Zorunlu := True;
            Inc(j, 2);
          end
          else if UpperCase(parcalar[j]) = 'UNIQUE' then
          begin
            Alan.Benzersiz := True;
            Inc(j);
          end
          else if UpperCase(parcalar[j]) = 'AUTOINCREMENT' then
          begin
            Alan.Tur := ftAutoIncrement;
            Inc(j);
          end
          else if UpperCase(parcalar[j]) = 'DEFAULT' then
          begin
            Inc(j);
            if j <= High(parcalar) then
            begin
              var defaultValueStr := Trim(parcalar[j]);
              if (Length(defaultValueStr) > 1) and (defaultValueStr[1] = '''') and (defaultValueStr[Length(defaultValueStr)] = '''') then
                defaultValueStr := Copy(defaultValueStr, 2, Length(defaultValueStr) - 2);
              Alan.Varsayilan := TypedValueFromJSON(AlanTuruToStr(Alan.Tur), defaultValueStr);
              Inc(j);
            end;
          end
          else
            Inc(j);
        end;

        yeniTablo.AlanEkle(Alan);
      end;

      if not Assigned(FVeritabani) then
        raise Exception.Create('Veritabani nesnesi atanmadi.');

      FVeritabani.TabloEkle(tabloAdi, yeniTablo, []);
      FLastInfoMessage := Format('CREATE: "%s" tablosu %d alanla olusturuldu.', [tabloAdi, Length(kolonlar)]);
      FIsSuccess := True;
      Result := True;
    except
      on E: Exception do
      begin
        FLastErrorMessage := 'CREATE Hatasi: ' + E.Message;
        FIsSuccess := False;
        Result := False;
        FreeAndNil(yeniTablo);
      end;
    end;
  end;
end;

function TSqlEngine.ParseAndExecuteUpdate(const SQL: string): Boolean;
var
  s, tabloAdi, setKismi, whereKismi, alanStr, degerStr: string;
  iSet, iWhere, iEq, i: Integer;
  tablo: TVTablo;
  k: TKayit;
  guncellenen: Integer = 0;
  whereAlan: string;
  whereDegerStr: string;
  alanTuru: TAlanTuru;
  YeniDegerVariant: Variant;
begin
  Result := False;
  FLastErrorMessage := '';
  FLastInfoMessage := '';
  FIsSuccess := False;

  try
    s := Trim(SQL);
    if not s.StartsWith('UPDATE', True) then Exit;

    iSet := Pos('SET', UpperCase(s));
    if iSet = 0 then raise Exception.Create('SET bolumu eksik.');

    tabloAdi := Trim(Copy(s, Length('UPDATE') + 1, iSet - Length('UPDATE') - 1));
    s := Copy(s, iSet + 3, MaxInt);

    iWhere := Pos('WHERE', UpperCase(s));
    if iWhere > 0 then
    begin
      setKismi := Trim(Copy(s, 1, iWhere - 1));
      whereKismi := Trim(Copy(s, iWhere + 5, MaxInt));
    end
    else
      setKismi := Trim(s);

    iEq := Pos('=', setKismi);
    if iEq = 0 then raise Exception.Create('SET ifadesi hatali.');
    alanStr := Trim(Copy(setKismi, 1, iEq - 1));
    degerStr := Trim(Copy(setKismi, iEq + 1, MaxInt));
    degerStr := StringReplace(degerStr, '''', '', [rfReplaceAll]);

    tablo := FVeritabani.TabloGetir(tabloAdi);
    if not Assigned(tablo) then raise Exception.Create('Tablo bulunamadi: ' + tabloAdi);

    // Güncellenecek alanın türünü al ve değeri dönüştür
    alanTuru := tablo.AlanTuruGetir(alanStr);
    YeniDegerVariant := TypedValueFromJSON(AlanTuruToStr(alanTuru), degerStr);

    // WHERE koşulunu ayrıştır
    if whereKismi <> '' then
    begin
      iEq := Pos('=', whereKismi);
      if iEq = 0 then raise Exception.Create('WHERE ifadesi hatali.');
      whereAlan := Trim(Copy(whereKismi, 1, iEq - 1));
      whereDegerStr := Trim(Copy(whereKismi, iEq + 1, MaxInt));
      whereDegerStr := StringReplace(whereDegerStr, '''', '', [rfReplaceAll]);
    end;

    for i := 0 to tablo.KayitSayisi - 1 do
    begin
      k := tablo.Kayitlar[i];
      // WHERE koşulu boşsa veya koşul sağlanıyorsa güncelle
      if (whereKismi = '') or
         (k.ContainsKey(LowerCase(whereAlan)) and SameText(VarToStr(k[LowerCase(whereAlan)]), whereDegerStr)) then
      begin
        k.SetDeger(alanStr, YeniDegerVariant); // Dönüştürülmüş Variant değer kullanıldı
        Inc(guncellenen);
      end;
    end;
    FLastInfoMessage := Format('UPDATE: %d kayit guncellendi.', [guncellenen]);
    FIsSuccess := True;
    Result := True;
  except
    on E: Exception do
    begin
      FLastErrorMessage := 'UPDATE hatasi: ' + E.Message;
      FIsSuccess := False;
      Result := False;
    end;
  end;
end;

function TSqlEngine.ParseAndExecuteDelete(const SQL: string): Boolean;
var
  s, tabloAdi, whereKismi, alan, deger: string;
  iFrom, iWhere: Integer;
  tablo: TVTablo;
  i: Integer;
  k: TKayit;
  silinen: Integer = 0;
  whereAlan: string;
  whereDegerStr: string;
begin
  Result := False;
  FLastErrorMessage := '';
  FLastInfoMessage := '';
  FIsSuccess := False;

  try
    s := Trim(SQL);
    if not s.StartsWith('DELETE FROM', True) then Exit;

    iFrom := Length('DELETE FROM') + 1;
    iWhere := Pos('WHERE', UpperCase(s));
    if iWhere > 0 then
    begin
      tabloAdi := Trim(Copy(s, iFrom, iWhere - iFrom));
      whereKismi := Trim(Copy(s, iWhere + 5, MaxInt));
    end
    else
    begin
      tabloAdi := Trim(Copy(s, iFrom, MaxInt));
      whereKismi := '';
    end;

    tablo := FVeritabani.TabloGetir(tabloAdi);
    if not Assigned(tablo) then raise Exception.Create('Tablo bulunamadi: ' + tabloAdi);

    // WHERE koşulunu ayrıştır
    if whereKismi <> '' then
    begin
      var iEq := Pos('=', whereKismi);
      if iEq = 0 then raise Exception.Create('WHERE ifadesi hatali.');
      whereAlan := Trim(Copy(whereKismi, 1, iEq - 1));
      whereDegerStr := Trim(Copy(whereKismi, iEq + 1, MaxInt));
      whereDegerStr := StringReplace(whereDegerStr, '''', '', [rfReplaceAll]);
    end;


    i := 0;
    while i < tablo.KayitSayisi do
    begin
      k := tablo.Kayitlar[i];
      // WHERE koşulu boşsa veya koşul sağlanıyorsa sil
      if (whereKismi = '') or
         (k.ContainsKey(LowerCase(whereAlan)) and SameText(VarToStr(k[LowerCase(whereAlan)]), whereDegerStr)) then
      begin
        tablo.KaydiSilIndexIle(i);
        Inc(silinen);
      end
      else
        Inc(i);
    end;

    FLastInfoMessage := Format('DELETE: %d kayit silindi.', [silinen]);
    FIsSuccess := True;
    Result := True;
  except
    on E: Exception do
    begin
      FLastErrorMessage := 'DELETE hatasi: ' + E.Message;
      FIsSuccess := False;
      Result := False;
    end;
  end;
end;

function TSqlEngine.ParseAndExecuteDrop(const SQL: string): Boolean;
var
  s, tabloAdi: string;
  iFrom: Integer;
begin
  Result := False;
  FLastErrorMessage := '';
  FLastInfoMessage := '';
  FIsSuccess := False;

  try
    s := Trim(SQL);
    if not s.StartsWith('DROP TABLE', True) then
      raise Exception.Create('Komut DROP TABLE ile baslamali.');

    iFrom := Length('DROP TABLE') + 1;
    tabloAdi := Trim(Copy(s, iFrom, MaxInt));

    if FVeritabani.TabloGetir(tabloAdi) = nil then
      raise Exception.CreateFmt('Tablo bulunamadi: "%s"', [tabloAdi]);

    // Tabloyu veritabanından kaldırma işlemi
    // TVeritabani sınıfında bir TabloSil metodu olmalı
    // Şimdilik sadece mesaj verelim, gerçek silme TVeritabani'na eklenebilir.
    // Örneğin: FVeritabani.TabloSil(tabloAdi);
    // Veya TTabloKaydi'ndan doğrudan silme:
    var
      i: Integer;
      FoundIndex: Integer = -1;
    for i := 0 to FVeritabani.TabloSayisi - 1 do
    begin
      if SameText(FVeritabani.TabloAd[i], tabloAdi) then
      begin
        FoundIndex := i;
        Break;
      end;
    end;

    if FoundIndex <> -1 then
    begin
      // Tablo nesnesini serbest bırak ve listeden çıkar
      FVeritabani.Tablolar[FoundIndex].Free; // TVTablo nesnesini serbest bırak
      FVeritabani.FTablolar.Delete(FoundIndex); // Kapsülü listeden çıkar
      FLastInfoMessage := Format('DROP TABLE: "%s" tablosu basariyla silindi.', [tabloAdi]);
      FIsSuccess := True;
      Result := True;
    end
    else
      raise Exception.CreateFmt('Tablo bulunamadi: "%s"', [tabloAdi]);

  except
    on E: Exception do
    begin
      FLastErrorMessage := 'DROP TABLE hatasi: ' + E.Message;
      FIsSuccess := False;
      Result := False;
    end;
  end;
end;


function TSqlEngine.ParseAndExecuteDescribe(const SQL: string): TKayitlar;
var
  tabloAdi: string;
  tablo: TVTablo;
  k: TKayit;
  i: Integer;
begin
  Result := nil;
  FLastErrorMessage := '';
  FLastInfoMessage := '';
  FIsSuccess := False;

  try
    if not SQL.StartsWith('DESCRIBE ', True) then
      raise Exception.Create('Komut DESCRIBE ile baslamali.');

    tabloAdi := Trim(Copy(SQL, Length('DESCRIBE') + 1, MaxInt));
    if tabloAdi = '' then raise Exception.Create('Tablo adi belirtilmedi.');

    tablo := FVeritabani.TabloGetir(tabloAdi);
    if not Assigned(tablo) then raise Exception.Create('Tablo bulunamadi: ' + tabloAdi);

    Result := TKayitlar.Create(True);

    for i := 0 to tablo.AlanSayisi - 1 do
    begin
      k := TKayit.Create;
      k['alan'] := tablo.Alanlar[i].Ad;
      k['tur'] := GetEnumName(TypeInfo(TAlanTuru), Ord(tablo.Alanlar[i].Tur));
      k['zorunlu'] := tablo.Alanlar[i].Zorunlu;
      k['benzersiz'] := tablo.Alanlar[i].Benzersiz;
      k['uzunluk'] := tablo.Alanlar[i].Uzunluk;
      Result.Add(k);
    end;

    FLastInfoMessage := Format('DESCRIBE: "%s" tablosunda %d alan.', [tabloAdi, Result.Count]);
    FIsSuccess := True;
  except
    on E: Exception do
    begin
      FLastErrorMessage := 'DESCRIBE Hatasi: ' + E.Message;
      Result := nil;
      FIsSuccess := False;
    end;
  end;
end;


function TSqlEngine.ParseAndExecuteShowTables: TKayitlar;
var
  tabloAdlari: TStringList;
  Sonuc: TKayitlar;
  k: TKayit;
  i: Integer;
begin
  Result := nil;
  FLastInfoMessage := '';
  FLastErrorMessage := '';
  FIsSuccess := False;

  try
    tabloAdlari := FVeritabani.TumTabloAdlariGetir;
    Sonuc := TKayitlar.Create(True);

    for i := 0 to tabloAdlari.Count - 1 do
    begin
      k := TKayit.Create;
      k['tablo'] := tabloAdlari[i];
      Sonuc.Add(k);
    end;

    FLastInfoMessage := Format('SHOW: %d tablo listelendi.', [Sonuc.Count]);
    FIsSuccess := True;
    Result := Sonuc;
  except
    on E: Exception do
    begin
      FLastErrorMessage := 'SHOW TABLES hatasi: ' + E.Message;
      FIsSuccess := False;
      Result := nil;
    end;
  end;
end;


end.



{unit sqlengine;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Variants,vtypes, vtablo,veritabani, Generics.Collections; // fgl yerine Generics.Collections eklendi

type
  TAlanSecimi = record
    Alan: string;
    TakmaAd: string;
  end;

type
  TSelectParcalari = record
    Alanlar: TStringArray;        // ['ad', 'yazar']
    Tablo: string;                // 'kitaplar'
    Filtre: string;               // 'sayfa > 100'
    GroupBy: string;              // 'yazar'
    OrderBy: string;              // 'sayfa'
    OrderDesc: Boolean;           // true: DESC
    Limit: Integer;               // 10
    Having: string;
    AlanListesi: array of TAlanSecimi;
  end;


type
  TSqlEngine = class
  private
    FVeritabani: TVeritabani;
    FLastInfoMessage: string;
    FLastErrorMessage: string;
    FIsSuccess: Boolean;

    function ExecuteSelectWithGroup(const SP:TSelectParcalari):TKayitlar;
    function ParseAndExecuteCreate(const SQL:string):Boolean;
    function ParseAndExecuteDelete(const SQL:string):Boolean;
    function ParseAndExecuteDescribe(const SQL:string):TKayitlar;
    function ParseAndExecuteSelect(const SQL:string):TKayitlar;
    function ParseAndExecuteShowTables:TKayitlar;
    function ParseAndExecuteUpdate(const SQL:string):Boolean;
    function ParseAndExecuteInsert(const SQL: string): Boolean;
  public
    constructor Create(AVeritabani: TVeritabani);

    function ExecuteAndReturn(Lines:TStrings):TKayitlar;
    function ExecuteSQL(const Liste:TStrings):TKayitlar;
    property LastInfoMessage: string read FLastInfoMessage;
    property LastErrorMessage: string read FLastErrorMessage;
    property IsSuccess: Boolean read FIsSuccess;
  end;

var
  SiralamaAlan: string;
  SiralamaAzalan: Boolean;

implementation

uses
  StrUtils,TypInfo;


class function ByAlan(const A, B: TKayit): Integer;
var
  VA, VB: Variant;
begin
  // TKayit artık TDictionary olduğu için TryGetDeger kullanıldı
  A.TryGetDeger(SiralamaAlan, VA);
  B.TryGetDeger(SiralamaAlan, VB);
  Result := CompareStr(VarToStr(VA), VarToStr(VB));
  if SiralamaAzalan then
    Result := -Result;
end;

function ParcalaSQLKomutlari(const TumKomut: string): TStrings;
var
  satir, komut: string;
  i: Integer;
begin
  Result := TStringList.Create;
  komut := '';

  for i := 1 to Length(TumKomut) do
  begin
    satir := TumKomut[i];

    // Satır sonu ya da noktalı virgülle komut bitiyorsa
    if (satir = ';') or (satir = #10) or (satir = #13) then
    begin
      komut := Trim(komut);
      if komut <> '' then
      begin
        Result.Add(komut);
        komut := '';
      end;
    end
    else
      komut := komut + satir;
  end;

  // Son komut varsa ekle
  komut := Trim(komut);
  if komut <> '' then
    Result.Add(komut);
end;


function ParseSelectAlanlari(const selectStr: string): TArray<TAlanSecimi>; // specialize kaldırıldı
var
  Parcalar: TStringArray;
  i: Integer;
  Alan, Takma: string;
  Tmp: TStringArray;
begin
  Parcalar := selectStr.Split([',']);
  SetLength(Result, Length(Parcalar));

  for i := 0 to High(Parcalar) do
  begin
    Tmp := Parcalar[i].Trim.Split([' ']);
    if (Length(Tmp) >= 3) and (UpperCase(Tmp[Length(Tmp)-2]) = 'AS') then
    begin
      Alan := string.Join(' ', Tmp, 0, Length(Tmp)-2); // "AVG(sayfa)"
      Takma := Tmp[Length(Tmp)-1];
    end
    else
    begin
      Alan := Parcalar[i].Trim;
      Takma := '';
    end;

    Result[i].Alan := Alan;
    Result[i].TakmaAd := Takma;
  end;
end;



function ParseSelectSQL(const SQL: string): TSelectParcalari;
var
  s: string;
  iFrom, iWhere, iGroup, iOrder, iLimit,iHaving: Integer;
  selectStr, fromStr, whereStr, groupStr, orderStr, limitStr,havingStr,Kesici: string;
  temp: string;
  i:SizeInt;
begin
  s := StringReplace(SQL, #13#10, ' ', [rfReplaceAll]);
  s := StringReplace(s, ';', '', [rfReplaceAll]);
  s := Trim(s);

  // Başlangıç pozisyonları
  iFrom := Pos(' FROM ', UpperCase(s));
  iWhere := Pos(' WHERE ', UpperCase(s));
  iGroup := Pos(' GROUP BY ', UpperCase(s));
  iOrder := Pos(' ORDER BY ', UpperCase(s));
  iLimit := Pos(' LIMIT ', UpperCase(s));
  iHaving := Pos('HAVING', UpperCase(s));


  // 1. SELECT alanları
  selectStr := Copy(s, 8, iFrom - 8);
  Result.AlanListesi := ParseSelectAlanlari(selectStr);
  // 2. FROM tablo
  temp := Copy(s, iFrom + 6, MaxInt);

  if iWhere > 0 then
    fromStr := Copy(temp, 1, iWhere - iFrom - 6)
  else if iGroup > 0 then
    fromStr := Copy(temp, 1, iGroup - iFrom - 6)
  else if iOrder > 0 then
    fromStr := Copy(temp, 1, iOrder - iFrom - 6)
  else if iLimit > 0 then
    fromStr := Copy(temp, 1, iLimit - iFrom - 6)
  else
    fromStr := Trim(temp);

  Result.Tablo := Trim(fromStr);

  // 3. WHERE filtresi
  if iWhere > 0 then
  begin
    whereStr := Copy(s, iWhere + 7, MaxInt);
    if iGroup > 0 then
      whereStr := Copy(whereStr, 1, iGroup - iWhere - 7)
    else if iOrder > 0 then
      whereStr := Copy(whereStr, 1, iOrder - iWhere - 7)
    else if iLimit > 0 then
      whereStr := Copy(whereStr, 1, iLimit - iWhere - 7);
    Result.Filtre := Trim(whereStr);
  end;

  // 4. GROUP BY
  if iGroup > 0 then
  begin
    groupStr := Copy(s, iGroup + 9, MaxInt);
    if iOrder > 0 then
      groupStr := Copy(groupStr, 1, iOrder - iGroup - 9)
    else if iLimit > 0 then
      groupStr := Copy(groupStr, 1, iLimit - iGroup - 9);
    Result.GroupBy := Trim(groupStr);
  end;

  // 5. ORDER BY
  if iOrder > 0 then
  begin
    orderStr := Copy(s, iOrder + 9, MaxInt);
    if Pos(' DESC', UpperCase(orderStr)) > 0 then
    begin
      Result.OrderDesc := True;
      orderStr := StringReplace(orderStr, 'DESC', '', [rfIgnoreCase]);
    end
    else
      Result.OrderDesc := False;

    if iLimit > 0 then
      orderStr := Copy(orderStr, 1, iLimit - iOrder - 9);

    Result.OrderBy := Trim(orderStr);
  end;

  // 6. LIMIT
  if iLimit > 0 then
  begin
    limitStr := Trim(Copy(s, iLimit + 6, MaxInt));
    Result.Limit := StrToIntDef(limitStr, -1);
  end
  else
    Result.Limit := -1;


  if iHaving > 0 then
  begin
    havingStr := Copy(s, iHaving + 6, MaxInt);
    // ORDER BY veya LIMIT varsa onları sil
    for Kesici in ['ORDER BY', 'LIMIT'] do
    begin
      i := Pos(Kesici, UpperCase(havingStr));
      if i > 0 then
        Delete(havingStr, i, MaxInt);
    end;
    Result.Having := Trim(havingStr);
  end;

end;



function FilterKayitlar(Kayitlar: TKayitlar; const Filtre: string): TKayitlar;
var
  i: Integer;
  K: TKayit;
  Alan, Operator_, S: string;
  Parcalar: TStringArray;
  Deger: string;
  V: Variant;
begin
  Result := TKayitlar.Create;

  if Trim(Filtre) = '' then
  begin
    Result.Assign(Kayitlar); // filtre yoksa hepsini kopyala
    Exit;
  end;

  // Sadece tek basit ifade destekleniyor: alan operator deger
  if Pos('>=', Filtre) > 0 then Operator_ := '>='
  else if Pos('<=', Filtre) > 0 then Operator_ := '<='
  else if Pos('<>', Filtre) > 0 then Operator_ := '<>'
  else if Pos('=', Filtre) > 0 then Operator_ := '='
  else if Pos('>', Filtre) > 0 then Operator_ := '>'
  else if Pos('<', Filtre) > 0 then Operator_ := '<'
  else
    raise Exception.Create('Desteklenmeyen filtre: ' + Filtre);

  Parcalar := Filtre.Split([Operator_]);

  if Length(Parcalar) <> 2 then
    raise Exception.Create('Filtre hatasi: ' + Filtre);

  Alan := Trim(Parcalar[0]);
  Deger := Trim(Parcalar[1]);

  // Tek tırnaklıysa kaldır
  if (Length(Deger) > 2) and (Deger[1] = '''') and (Deger[Length(Deger)] = '''') then
    Deger := Copy(Deger, 2, Length(Deger) - 2);

  for i := 0 to Kayitlar.Count - 1 do
  begin
    K := Kayitlar[i];
    if not K.TryGetDeger(Alan, V) then // TryGetDeger kullanıldı
      Continue;

    S := VarToStr(V);

    if Operator_ = '='  then if S = Deger then Result.Add(K)
    else if Operator_ = '<>' then if S <> Deger then Result.Add(K)
    else if Operator_ = '>'  then if S > Deger then Result.Add(K)
    else if Operator_ = '<'  then if S < Deger then Result.Add(K)
    else if Operator_ = '>=' then if S >= Deger then Result.Add(K)
    else if Operator_ = '<=' then if S <= Deger then Result.Add(K);
  end;
end;


function CountByGroupInList(Kayitlar: TKayitlar; const AlanAdi: string): TKayitlar;
var
  Map: TDictionary<string, Integer>; // TFPGMap yerine TDictionary
  i: Integer;
  CurrentCount: Integer;
  Deger: Variant;
  K, R: TKayit;
begin
  Result := TKayitlar.Create;

  Map := TDictionary<string, Integer>.Create; // TDictionary oluşturuldu
  try
    // TDictionary hash tabanlı olduğu için Sorted özelliği geçerli değildir.
    // Map.Sorted := True; // Kaldırıldı

    for i := 0 to Kayitlar.Count - 1 do
    begin
      K := Kayitlar[i];
      if K.TryGetDeger(AlanAdi, Deger) then // TryGetDeger kullanıldı
      begin
        if Map.TryGetValue(VarToStr(Deger), CurrentCount) then // TryGetValue kullanıldı
          Map[VarToStr(Deger)] := CurrentCount + 1 // Anahtar varsa değeri güncelle
        else
          Map.Add(VarToStr(Deger), 1); // Anahtar yoksa ekle
      end;
    end;

    // TDictionary'nin Keys ve Values koleksiyonlarını kullanarak döngü
    for Deger in Map.Keys do // Deger artık string olacak
    begin
      R := TKayit.Create;
      R.SetDeger(AlanAdi, Deger); // Anahtar string olduğu için doğrudan atanabilir
      R.SetDeger('COUNT(*)', Map[Deger]); // Değere doğrudan anahtar ile erişim
      Result.Add(R);
    end;

  finally
    Map.Free;
  end;
end;



function SiralaVeSinirla(Kayitlar: TKayitlar; const Alan: string; Azalan: Boolean; Limit: Integer): TKayitlar;
begin
  Result := TKayitlar.Create;
  Result.Assign(Kayitlar); // kopyasını al

  SiralamaAlan := alan;
  SiralamaAzalan := Azalan;

  // TKayitlar'ın kendi Sort metodu kullanıldı, bu da @ByAlan fonksiyonunu çağırır.
  Result.Sort(@ByAlan);

  if (Limit > 0) and (Result.Count > Limit) then
    while Result.Count > Limit do
      Result.Delete(Result.Count - 1); // en sonlardan sil
end;

function GroupByWithAggregate(Kayitlar: TKayitlar; const GrupAlan, FonksiyonStr: string): TKayitlar;
var
  Map: TDictionary<string, Variant>; // TFPGMap yerine TDictionary
  CountMap: TDictionary<string, Integer>; // TFPGMap yerine TDictionary
  i: Integer;
  CurrentValue: Variant;
  CurrentCount: Integer;
  GrupDeger: Variant;
  Deger: Variant;
  K, R: TKayit;
  AgregeAlan: string;
  FonksiyonAdi: string;
begin
  Result := TKayitlar.Create;
  Map := TDictionary<string, Variant>.Create; // TDictionary oluşturuldu
  CountMap := TDictionary<string, Integer>.Create; // TDictionary oluşturuldu
  try
    // TDictionary hash tabanlı olduğu için Sorted özelliği geçerli değildir.
    // Map.Sorted := True; // Kaldırıldı
    // CountMap.Sorted := True; // Kaldırıldı

    // Fonksiyon ismini ve alanı ayır (örn: AVG(sayfa) → 'AVG', 'sayfa')
    FonksiyonAdi := UpperCase(Copy(FonksiyonStr, 1, Pos('(', FonksiyonStr) - 1));
    AgregeAlan := Copy(FonksiyonStr, Pos('(', FonksiyonStr) + 1, Pos(')', FonksiyonStr) - Pos('(', FonksiyonStr) - 1);
    AgregeAlan := Trim(AgregeAlan);

    for i := 0 to Kayitlar.Count - 1 do
    begin
      K := Kayitlar[i];
      if not K.TryGetDeger(GrupAlan, GrupDeger) then // TryGetDeger kullanıldı
        Continue;
      if not K.TryGetDeger(AgregeAlan, Deger) then // TryGetDeger kullanıldı
        Continue;

      if not Map.TryGetValue(VarToStr(GrupDeger), CurrentValue) then // TryGetValue kullanıldı
      begin
        if FonksiyonAdi = 'MAX' then Map.Add(VarToStr(GrupDeger), Deger)
        else if FonksiyonAdi = 'MIN' then Map.Add(VarToStr(GrupDeger), Deger)
        else begin
          Map.Add(VarToStr(GrupDeger), Deger);
          CountMap.Add(VarToStr(GrupDeger), 1);
        end;
      end
      else
      begin
        case FonksiyonAdi of
          'SUM', 'AVG':
            begin
              Map[VarToStr(GrupDeger)] := CurrentValue + Deger; // Doğrudan erişim
              CountMap[VarToStr(GrupDeger)] := CountMap[VarToStr(GrupDeger)] + 1; // Doğrudan erişim
            end;
          'MAX':
            if Deger > CurrentValue then
              Map[VarToStr(GrupDeger)] := Deger; // Doğrudan erişim
          'MIN':
            if Deger < CurrentValue then
              Map[VarToStr(GrupDeger)] := Deger; // Doğrudan erişim
        end;
      end;
    end;

    for GrupDeger in Map.Keys do // TDictionary'nin Keys iterasyonu
    begin
      R := TKayit.Create;
      R.SetDeger(GrupAlan, GrupDeger); // GrupDeger string olduğu için doğrudan atanabilir
      if FonksiyonAdi = 'AVG' then
        R.SetDeger(FonksiyonAdi + '(' + AgregeAlan + ')', Map[GrupDeger] / CountMap[GrupDeger]) // Doğrudan erişim
      else
        R.SetDeger(FonksiyonAdi + '(' + AgregeAlan + ')', Map[GrupDeger]); // Doğrudan erişim
      Result.Add(R);
    end;

  finally
    Map.Free;
    CountMap.Free;
  end;
end;


function CountByMultipleKeys(Kayitlar: TKayitlar; const GrupAlanlari: array of string): TKayitlar;
var
  Map: TDictionary<string, Integer>; // TFPGMap yerine TDictionary
  i, j: Integer;
  CurrentCount: Integer;
  Key: string;
  Deger: Variant;
  K, R: TKayit;
  AnahtarDegerler: TStringList;
begin
  Result := TKayitlar.Create;
  Map := TDictionary<string, Integer>.Create; // TDictionary oluşturuldu
  AnahtarDegerler := TStringList.Create;
  try
    // TDictionary hash tabanlı olduğu için Sorted özelliği geçerli değildir.
    // Map.Sorted := True; // Kaldırıldı

    for i := 0 to Kayitlar.Count - 1 do
    begin
      K := Kayitlar[i];
      Key := '';
      AnahtarDegerler.Clear;

      for j := 0 to High(GrupAlanlari) do
      begin
        if not K.TryGetDeger(GrupAlanlari[j], Deger) then // TryGetDeger kullanıldı
          Deger := '';
        AnahtarDegerler.Values[GrupAlanlari[j]] := VarToStr(Deger);
      end;

      Key := AnahtarDegerler.Text.Replace(sLineBreak, '|');

      if Map.TryGetValue(Key, CurrentCount) then // TryGetValue kullanıldı
        Map[Key] := CurrentCount + 1 // Anahtar varsa değeri güncelle
      else
        Map.Add(Key, 1); // Anahtar yoksa ekle
    end;

    for Key in Map.Keys do // TDictionary'nin Keys iterasyonu
    begin
      R := TKayit.Create;
      AnahtarDegerler.Clear;
      AnahtarDegerler.Text := StringReplace(Key, '|', sLineBreak, [rfReplaceAll]);

      for j := 0 to AnahtarDegerler.Count - 1 do
        R.SetDeger(AnahtarDegerler.Names[j], AnahtarDegerler.ValueFromIndex[j]);

      R.SetDeger('COUNT(*)', Map[Key]); // Doğrudan erişim
      Result.Add(R);
    end;

  finally
    Map.Free;
    AnahtarDegerler.Free;
  end;
end;


function GroupByWithAggregateMultiple(Kayitlar: TKayitlar; const GrupAlanlari: array of string; const FonksiyonStr: string): TKayitlar;
var
  Map: TDictionary<string, Variant>; // TFPGMap yerine TDictionary
  CountMap: TDictionary<string, Integer>; // TFPGMap yerine TDictionary
  i, j: Integer;
  CurrentValue: Variant;
  CurrentCount: Integer;
  GrupKey: string;
  Deger: Variant;
  K, R: TKayit;
  AnahtarDegerler: TStringList;
  AgregeAlan, FonksiyonAdi: string;
begin
  Result := TKayitlar.Create;
  Map := TDictionary<string, Variant>.Create; // TDictionary oluşturuldu
  CountMap := TDictionary<string, Integer>.Create; // TDictionary oluşturuldu
  AnahtarDegerler := TStringList.Create;
  try
    // TDictionary hash tabanlı olduğu için Sorted özelliği geçerli değildir.
    // Map.Sorted := True; // Kaldırıldı
    // CountMap.Sorted := True; // Kaldırıldı

    FonksiyonAdi := UpperCase(Copy(FonksiyonStr, 1, Pos('(', FonksiyonStr) - 1));
    AgregeAlan := Copy(FonksiyonStr, Pos('(', FonksiyonStr) + 1, Pos(')', FonksiyonStr) - Pos('(', FonksiyonStr) - 1);
    AgregeAlan := Trim(AgregeAlan);

    for i := 0 to Kayitlar.Count - 1 do
    begin
      K := Kayitlar[i];
      GrupKey := '';
      AnahtarDegerler.Clear;

      for j := 0 to High(GrupAlanlari) do
      begin
        if not K.TryGetDeger(GrupAlanlari[j], Deger) then // TryGetDeger kullanıldı
          Deger := '';
        AnahtarDegerler.Values[GrupAlanlari[j]] := VarToStr(Deger);
      end;

      GrupKey := AnahtarDegerler.Text.Replace(sLineBreak, '|');

      if not K.TryGetDeger(AgregeAlan, Deger) then // TryGetDeger kullanıldı
        Continue;

      if not Map.TryGetValue(GrupKey, CurrentValue) then // TryGetValue kullanıldı
      begin
        if (FonksiyonAdi = 'MAX') or (FonksiyonAdi = 'MIN') then
          Map.Add(GrupKey, Deger)
        else begin
          Map.Add(GrupKey, Deger);
          CountMap.Add(GrupKey, 1);
        end;
      end
      else
      begin
        case FonksiyonAdi of
          'SUM', 'AVG':
            begin
              Map[GrupKey] := CurrentValue + Deger; // Doğrudan erişim
              CountMap[GrupKey] := CountMap[GrupKey] + 1; // Doğrudan erişim
            end;
          'MAX':
            if Deger > CurrentValue then
              Map[GrupKey] := Deger; // Doğrudan erişim
          'MIN':
            if Deger < CurrentValue then
              Map[GrupKey] := Deger; // Doğrudan erişim
        end;
      end;
    end;

    for GrupKey in Map.Keys do // TDictionary'nin Keys iterasyonu
    begin
      R := TKayit.Create;
      AnahtarDegerler.Clear;
      AnahtarDegerler.Text := StringReplace(GrupKey, '|', sLineBreak, [rfReplaceAll]);

      for j := 0 to AnahtarDegerler.Count - 1 do
        R.SetDeger(AnahtarDegerler.Names[j], AnahtarDegerler.ValueFromIndex[j]);

      if FonksiyonAdi = 'AVG' then
        R.SetDeger(FonksiyonAdi + '(' + AgregeAlan + ')', Map[GrupKey] / CountMap[GrupKey]) // Doğrudan erişim
      else
        R.SetDeger(FonksiyonAdi + '(' + AgregeAlan + ')', Map[GrupKey]); // Doğrudan erişim

      Result.Add(R);
    end;

  finally
    Map.Free;
    CountMap.Free;
    AnahtarDegerler.Free;
  end;
end;

function FilterHaving(Kayitlar: TKayitlar; const Kosul: string): TKayitlar;
var
  i: Integer;
  Alan, Operator_, DegerStr: string;
  V: Variant;
  K: TKayit;
  Parcalar: TStringArray;
begin
  Result := TKayitlar.Create;

  // Örn: COUNT(*) > 1
  if Pos('>=', Kosul) > 0 then Operator_ := '>='
  else if Pos('<=', Kosul) > 0 then Operator_ := '<='
  else if Pos('<>', Kosul) > 0 then Operator_ := '<>'
  else if Pos('=', Kosul) > 0 then Operator_ := '='
  else if Pos('>', Kosul) > 0 then Operator_ := '>'
  else if Pos('<', Kosul) > 0 then Operator_ := '<'
  else raise Exception.Create('HAVING kosulu anlasilamadi: ' + Kosul);

  Parcalar := Kosul.Split([Operator_]);
  if Length(Parcalar) <> 2 then
    raise Exception.Create('HAVING formati hatali: ' + Kosul);

  Alan := Trim(Parcalar[0]);
  DegerStr := Trim(Parcalar[1]);

  for i := 0 to Kayitlar.Count - 1 do
  begin
    K := Kayitlar[i];
    if not K.TryGetDeger(Alan, V) then Continue; // TryGetDeger kullanıldı

    if    Operator_ = '='  then if V = DegerStr then Result.Add(K)
    else if Operator_ = '<>' then if V <> DegerStr then Result.Add(K)
    else if Operator_ = '>'  then if V > DegerStr then Result.Add(K)
    else if Operator_ = '<'  then if V < DegerStr then Result.Add(K)
    else if Operator_ = '>=' then if V >= DegerStr then Result.Add(K)
    else if Operator_ = '<=' then if V <= DegerStr then Result.Add(K);
  end;
end;

function TSqlEngine.ExecuteSelectWithGroup(const SP: TSelectParcalari): TKayitlar;
var
  Tablo: TVTablo;
  KayitlarFiltreli: TKayitlar;
  GrupAlanlari: TStringArray;
  FonksiyonStr: string;
  i:integer;
begin
  Tablo := FVeritabani.TabloGetir(SP.Tablo);
  if not Assigned(Tablo) then
    raise Exception.Create('Tablo bulunamadi: ' + SP.Tablo);

  KayitlarFiltreli := FilterKayitlar(Tablo.Kayitlari, SP.Filtre);

  GrupAlanlari := SP.GroupBy.Split([',']);
  for i := 0 to High(GrupAlanlari) do
    GrupAlanlari[i] := Trim(GrupAlanlari[i]);


  if Length(SP.AlanListesi) = 0 then
  raise Exception.Create('SELECT alan listesi bos!');

FonksiyonStr := Trim(SP.AlanListesi[High(SP.AlanListesi)].Alan);

  if UpperCase(FonksiyonStr) = 'COUNT(*)' then
    Result := CountByMultipleKeys(KayitlarFiltreli, GrupAlanlari)
  else
    Result := GroupByWithAggregateMultiple(KayitlarFiltreli, GrupAlanlari, FonksiyonStr);

  // Sıralama + LIMIT
  if SP.OrderBy <> '' then
    Result := SiralaVeSinirla(Result, SP.OrderBy, SP.OrderDesc, SP.Limit)
  else if SP.Limit > 0 then
    while Result.Count > SP.Limit do
      Result.Delete(Result.Count - 1);

  if SP.Having <> '' then
  Result := FilterHaving(Result, SP.Having);
end;


constructor TSqlEngine.Create(AVeritabani: TVeritabani);
begin
  inherited Create;
  FVeritabani := AVeritabani;
end;
function TSqlEngine.ExecuteSQL(const Liste: TStrings): TKayitlar;
var
  i: Integer;
  Komut: string;
begin
  Result := nil;
  for i := 0 to Liste.Count - 1 do
  begin
    Komut := Trim(Liste[i]);

    if Komut = '' then Continue;

    if Komut.StartsWith('SELECT', True) then
      Exit(ParseAndExecuteSelect(Komut))
    else if Komut.StartsWith('INSERT INTO', True) then
      ParseAndExecuteInsert(Komut)
    else if Komut.StartsWith('CREATE TABLE', True) then
      ParseAndExecuteCreate(Komut)
    else if Komut.StartsWith('UPDATE', True) then
      ParseAndExecuteUpdate(Komut)
    else if Komut.StartsWith('DELETE FROM', True) then
      ParseAndExecuteDelete(Komut)
    else
    begin
      FLastErrorMessage := 'Bilinmeyen komut: ' + Komut;
      FIsSuccess := False;
      Exit(nil);
    end;
  end;
end;



function TSqlEngine.ExecuteAndReturn(Lines: TStrings): TKayitlar;
var
  i: Integer;
  Komut: string;
  SP: TSelectParcalari;

begin
  Result := nil;
  FIsSuccess := False;
  FLastErrorMessage := '';
  FLastInfoMessage := '';

  for i := 0 to Lines.Count - 1 do
  begin
    Komut := Trim(Lines[i]);
    if Komut = '' then Continue;

    if Komut.StartsWith('SELECT', True) then
    begin
      SP := ParseSelectSQL(Komut);
      Result := ExecuteSelectWithGroup(SP);

      Exit; // SELECT sonucu varsa direkt çık (tek SELECT kabul)
    end
    else if Komut.StartsWith('INSERT INTO', True) then
      ParseAndExecuteInsert(Komut)
    else if Komut.StartsWith('CREATE TABLE', True) then
      ParseAndExecuteCreate(Komut)
    else if Komut.StartsWith('UPDATE', True) then
      ParseAndExecuteUpdate(Komut)
    else if Komut.StartsWith('DELETE FROM', True) then
      ParseAndExecuteDelete(Komut)
    else if Komut.StartsWith('SHOW TABLES', True) then
      Exit(ParseAndExecuteShowTables)
      else if Komut.StartsWith('DESCRIBE ', True) then
      Exit(ParseAndExecuteDescribe(Komut))
    else
    begin
      FLastErrorMessage := 'Bilinmeyen SQL komutu: ' + Komut;
      FIsSuccess := False;
      Exit(nil);
    end;

    // Eğer komut başarısız olduysa döngüyü sonlandır
    if not FIsSuccess then Exit(nil);
  end;

  // SELECT yoksa ama komutlar başarılıysa bu noktaya geliriz
  FIsSuccess := True;
  FLastInfoMessage := 'Tum islemler basariyla tamamlandi.';
end;
function AyiklaTabloAdi(const S: string): string;
const
  Kesiciler: array[0..3] of string = ('WHERE', 'ORDER BY', 'LIMIT', ';');
var
  i, p, enKucuk: Integer;
begin
  Result := S;
  enKucuk := MaxInt;

  for i := 0 to High(Kesiciler) do
  begin
    p := Pos(UpperCase(Kesiciler[i]), UpperCase(S));
    if (p > 0) and (p < enKucuk) then
      enKucuk := p;
  end;

  if enKucuk <> MaxInt then
    Result := Trim(Copy(S, 1, enKucuk - 1))
  else
    Result := Trim(S);
end;

function TSqlEngine.ParseAndExecuteInsert(const SQL: string): Boolean;
var
  s, tabloAdi, kolonStr, valuesStr, parca,alan, raw, metin: string;
  par1, par2, i, j, degersayisi: Integer; // a değişkeni kaldırıldı
  kolonlar, valueGruplari: TStringArray;
  tablo: TVTablo;
  aktifAlanlar: TStringList;
  V: Variant;
  k: TKayit;
  intVal: Integer;
  floatVal: Double;
begin
  Result := False;
  FLastInfoMessage := '';
  FLastErrorMessage := '';
  FIsSuccess := False;

  try
    s := Trim(SQL);

    if not s.StartsWith('INSERT INTO', True) then
      raise Exception.Create('Komut INSERT INTO ile baslamali.');

    par1 := Pos('(', s);
    par2 := Pos(')', s);
    if (par1 = 0) or (par2 = 0) then
      raise Exception.Create('Parantezler eksik veya hatali.');

    tabloAdi := Trim(Copy(s, Length('INSERT INTO') + 1, par1 - Length('INSERT INTO') - 1));
    kolonStr := Copy(s, par1 + 1, par2 - par1 - 1);
    kolonlar := kolonStr.Split([',']);

    i := Pos('VALUES', UpperCase(s));
    if i = 0 then raise Exception.Create('VALUES bolumu eksik.');
    valuesStr := Trim(Copy(s, i + 6, MaxInt));
    valuesStr := StringReplace(valuesStr, ';', '', [rfReplaceAll]);

    // TABLO GETIR
    tablo := FVeritabani.TabloGetir(tabloAdi);
    if not Assigned(tablo) then
      raise Exception.Create('Tablo bulunamadi: ' + tabloAdi);

    aktifAlanlar := TStringList.Create;
    try
      aktifAlanlar.CaseSensitive := False;
      aktifAlanlar.Duplicates := dupError;

      for j := 0 to High(kolonlar) do
      begin
        alan := Trim(kolonlar[j]);
        if tablo.AlanTuruGetir(alan) <> ftAutoIncrement then
          aktifAlanlar.Add(alan);
      end;

      valuesStr := StringReplace(valuesStr, '),(', ')|(', [rfReplaceAll]);
      valueGruplari := valuesStr.Split(['|']);

      for i := 0 to High(valueGruplari) do
      begin
        parca := valueGruplari[i];
        parca := StringReplace(parca, '(', '', [rfReplaceAll]);
        parca := StringReplace(parca, ')', '', [rfReplaceAll]);

        degersayisi := Length(parca.Split([',']));

        if degersayisi <> aktifAlanlar.Count then
          raise Exception.CreateFmt('Kolon sayisi (%d) ile deger sayisi (%d) eslesmiyor. INSERT satiri %d',
            [aktifAlanlar.Count, degersayisi, i + 1]);

        k := TKayit.Create;
        try // k'nin Free edilmesi için try..finally bloğu eklendi
          for j := 0 to aktifAlanlar.Count - 1 do
          begin
            raw := Trim(ExtractWord(j + 1, parca, [',']));
            metin := VarToStrDef(raw, '');

            if (Length(metin) >= 2) and (metin[1] = '''') and (metin[Length(metin)] = '''') then
              V := Copy(metin, 2, Length(metin) - 2)
            else if TryStrToInt(metin, intVal) then
              V := intVal
            else if TryStrToFloat(metin, floatVal) then
              V := floatVal
            else
              V := metin;

            k.SetDeger(aktifAlanlar[j], V);
          end;

          if not tablo.KayitEkle2(k) then
            raise Exception.CreateFmt('INSERT hatasi. %d. kayitta dogrulama sorunu.', [i + 1]);
        finally
          // Eğer KayitEkle2 başarılı olduysa k'yi tabloya eklemiş olacaktır,
          // bu durumda k'yi burada Free etmemeliyiz.
          // Ancak KayitEkle2 başarısız olursa, k'nin Free edilmesi gerekir.
          // KayitEkle2 zaten kendi içinde k'yi serbest bırakıyorsa bu kısım gereksiz olabilir.
          // Mevcut KayitEkle2 implementasyonunda k'yi serbest bırakmadığı için burada bırakıldı.
          // Ancak TVTablo.KayitEkle'nin Free etme mantığına göre burası değişebilir.
          // Geçici olarak bırakıldı, ancak dikkat edilmesi gereken bir nokta.
        end;
      end;
    finally
      aktifAlanlar.Free;
    end;

    FLastInfoMessage := Format('INSERT islemi tamamlandi (%d kayit)', [Length(valueGruplari)]);
    FIsSuccess := True;
    Result := True;
  except
    on E: Exception do
    begin
      FLastErrorMessage := 'INSERT hatasi: ' + E.Message;
      FIsSuccess := False;
      Result := False;
    end;
  end;
end;

function TSqlEngine.ParseAndExecuteCreate(const SQL: string): Boolean;
var
  s, tabloAdi, kolonlarStr, satir: string;
  par1, par2, i, j: Integer;
  kolonlar, parcalar: TStringArray;
  Alan: TAlanKaydi;
  yeniTablo: TVTablo;
begin
  Result := False;
  FLastErrorMessage := '';
  FLastInfoMessage := '';
  FIsSuccess := False;

  try
    s := Trim(SQL);
    if not s.StartsWith('CREATE TABLE', True) then Exit;

    par1 := Pos('(', s);
    par2 := LastDelimiter(')', s);
    if (par1 = 0) or (par2 = 0) then
      raise Exception.Create('Parantezler eksik.');

    tabloAdi := Trim(Copy(s, Length('CREATE TABLE') + 1, par1 - Length('CREATE TABLE') - 1));
    kolonlarStr := Trim(Copy(s, par1 + 1, par2 - par1 - 1));
    kolonlar := kolonlarStr.Split([',']);

    yeniTablo := TVTablo.Create(tabloAdi);
    try // yeniTablo'nun Free edilmesi için try..finally bloğu eklendi
      for i := 0 to High(kolonlar) do
      begin
        satir := Trim(kolonlar[i]);
        if satir = '' then Continue;

        parcalar := satir.Split([' ']);
        if Length(parcalar) < 2 then
          raise Exception.Create('Kolon tanimi yetersiz: ' + satir);

        Alan.Ad := parcalar[0];
        Alan.Tur := StrToAlanTuru(parcalar[1]);
        Alan.Zorunlu := False;
        Alan.Benzersiz := False;
        Alan.Sayac := 0; // Varsayılan değer atandı
        Alan.Uzunluk := 0; // Varsayılan değer atandı
        Alan.Varsayilan := Null; // Varsayılan değer atandı

        j := 2;
        while j <= High(parcalar) do
        begin
          if (UpperCase(parcalar[j]) = 'PRIMARY') and
             (j < High(parcalar)) and (UpperCase(parcalar[j + 1]) = 'KEY') then
          begin
            Alan.Benzersiz := True;
            Alan.Zorunlu := True;
            Inc(j, 2);
          end
          else if (UpperCase(parcalar[j]) = 'NOT') and
                  (j < High(parcalar)) and (UpperCase(parcalar[j + 1]) = 'NULL') then
          begin
            Alan.Zorunlu := True;
            Inc(j, 2);
          end
          else if UpperCase(parcalar[j]) = 'UNIQUE' then
          begin
            Alan.Benzersiz := True;
            Inc(j);
          end
          else if UpperCase(parcalar[j]) = 'AUTOINCREMENT' then
          begin
            Alan.Tur := ftAutoIncrement;
            Inc(j);
          end
          else if UpperCase(parcalar[j]) = 'DEFAULT' then // DEFAULT anahtar kelimesi eklendi
          begin
            Inc(j); // 'DEFAULT' kelimesini geç
            if j <= High(parcalar) then
            begin
              // Varsayılan değeri tırnaklardan temizle
              var defaultValueStr := Trim(parcalar[j]);
              if (Length(defaultValueStr) > 1) and (defaultValueStr[1] = '''') and (defaultValueStr[Length(defaultValueStr)] = '''') then
                defaultValueStr := Copy(defaultValueStr, 2, Length(defaultValueStr) - 2);
              Alan.Varsayilan := TypedValueFromJSON(AlanTuruToStr(Alan.Tur), defaultValueStr);
              Inc(j);
            end;
          end
          else
            Inc(j);
        end;

        yeniTablo.AlanEkle(Alan);
      end;

      if not Assigned(FVeritabani) then
        raise Exception.Create('Veritabani nesnesi atanmadi.');

      FVeritabani.TabloEkle(tabloAdi, yeniTablo, []);
      FLastInfoMessage := Format('CREATE: "%s" tablosu %d alanla olusturuldu.', [tabloAdi, Length(kolonlar)]);
      FIsSuccess := True;
      Result := True;
    except
      on E: Exception do
      begin
        FLastErrorMessage := 'CREATE Hatasi: ' + E.Message;
        FIsSuccess := False;
        Result := False;
        FreeAndNil(yeniTablo); // Hata durumunda tabloyu serbest bırak
      end;
    end;
  end;
end;

function TSqlEngine.ParseAndExecuteUpdate(const SQL: string): Boolean;
var
  s, tabloAdi, setKismi, whereKismi, alanStr, degerStr: string; // alan ve deger isimleri çakışmasın diye değiştirildi
  iSet, iWhere, iEq,i: Integer;
  tablo: TVTablo;
  k: TKayit;
  guncellenen: Integer = 0;
  whereAlan: string;
  whereDegerStr: string;
begin
  Result := False;
  FLastErrorMessage := '';
  FLastInfoMessage := '';
  FIsSuccess := False;

  try
    s := Trim(SQL);
    if not s.StartsWith('UPDATE', True) then Exit;

    iSet := Pos('SET', UpperCase(s));
    if iSet = 0 then raise Exception.Create('SET bolumu eksik.');

    tabloAdi := Trim(Copy(s, Length('UPDATE') + 1, iSet - Length('UPDATE') - 1));
    s := Copy(s, iSet + 3, MaxInt);

    iWhere := Pos('WHERE', UpperCase(s));
    if iWhere > 0 then
    begin
      setKismi := Trim(Copy(s, 1, iWhere - 1));
      whereKismi := Trim(Copy(s, iWhere + 5, MaxInt));
    end
    else
      setKismi := Trim(s);

    iEq := Pos('=', setKismi);
    if iEq = 0 then raise Exception.Create('SET ifadesi hatali.');
    alanStr := Trim(Copy(setKismi, 1, iEq - 1));
    degerStr := Trim(Copy(setKismi, iEq + 1, MaxInt));
    degerStr := StringReplace(degerStr, '''', '', [rfReplaceAll]); // Tırnakları kaldır

    tablo := FVeritabani.TabloGetir(tabloAdi);
    if not Assigned(tablo) then raise Exception.Create('Tablo bulunamadi: ' + tabloAdi);

    // WHERE koşulunu ayrıştır
    if whereKismi <> '' then
    begin
      iEq := Pos('=', whereKismi);
      if iEq = 0 then raise Exception.Create('WHERE ifadesi hatali.');
      whereAlan := Trim(Copy(whereKismi, 1, iEq - 1));
      whereDegerStr := Trim(Copy(whereKismi, iEq + 1, MaxInt));
      whereDegerStr := StringReplace(whereDegerStr, '''', '', [rfReplaceAll]); // Tırnakları kaldır
    end;

    for i:=0 to tablo.KayitSayisi-1 do
    begin
      k := tablo.Kayitlar[i];
      // WHERE koşulu boşsa veya koşul sağlanıyorsa güncelle
      if (whereKismi = '') or
         (k.ContainsKey(LowerCase(whereAlan)) and SameText(VarToStr(k[LowerCase(whereAlan)]), whereDegerStr)) then // TryGetDeger yerine ContainsKey ve doğrudan erişim
      begin
        k.SetDeger(alanStr, degerStr); // SetDeger metodu kullanıldı
        Inc(guncellenen);
      end;
    end;
    FLastInfoMessage := Format('UPDATE: %d kayit guncellendi.', [guncellenen]);
    FIsSuccess := True;
    Result := True;
  except
    on E: Exception do
    begin
      FLastErrorMessage := 'UPDATE hatasi: ' + E.Message;
      FIsSuccess := False;
      Result := False;
    end;
  end;
end;

function TSqlEngine.ParseAndExecuteDelete(const SQL: string): Boolean;
var
  s, tabloAdi, whereKismi, alan, deger: string;
  iFrom, iWhere: Integer;
  tablo: TVTablo;
  i: Integer;
  k: TKayit;
  silinen: Integer = 0;
  whereAlan: string;
  whereDegerStr: string;
begin
  Result := False;
  FLastErrorMessage := '';
  FLastInfoMessage := '';
  FIsSuccess := False;

  try
    s := Trim(SQL);
    if not s.StartsWith('DELETE FROM', True) then Exit;

    iFrom := Length('DELETE FROM') + 1;
    iWhere := Pos('WHERE', UpperCase(s));
    if iWhere > 0 then
    begin
      tabloAdi := Trim(Copy(s, iFrom, iWhere - iFrom));
      whereKismi := Trim(Copy(s, iWhere + 5, MaxInt));
    end
    else
    begin
      tabloAdi := Trim(Copy(s, iFrom, MaxInt));
      whereKismi := '';
    end;

    tablo := FVeritabani.TabloGetir(tabloAdi);
    if not Assigned(tablo) then raise Exception.Create('Tablo bulunamadi: ' + tabloAdi);

    // WHERE koşulunu ayrıştır
    if whereKismi <> '' then
    begin
      // Basit bir '=' operatörü varsayımı
      var iEq := Pos('=', whereKismi);
      if iEq = 0 then raise Exception.Create('WHERE ifadesi hatali.');
      whereAlan := Trim(Copy(whereKismi, 1, iEq - 1));
      whereDegerStr := Trim(Copy(whereKismi, iEq + 1, MaxInt));
      whereDegerStr := StringReplace(whereDegerStr, '''', '', [rfReplaceAll]); // Tırnakları kaldır
    end;


    i := 0;
    while i < tablo.KayitSayisi do
    begin
      k := tablo.Kayitlar[i];
      // WHERE koşulu boşsa veya koşul sağlanıyorsa sil
      if (whereKismi = '') or
         (k.ContainsKey(LowerCase(whereAlan)) and SameText(VarToStr(k[LowerCase(whereAlan)]), whereDegerStr)) then // ContainsKey ve doğrudan erişim
      begin
        tablo.KaydiSilIndexIle(i); // KaydiSilIndexIle zaten kaydı listeden siliyor
        Inc(silinen);
        // Silme işleminden sonra 'i' aynı kalır çünkü liste elemanları kayar
      end
      else
        Inc(i); // Silme olmadıysa bir sonraki kayda geç
    end;

    FLastInfoMessage := Format('DELETE: %d kayit silindi.', [silinen]);
    FIsSuccess := True;
    Result := True;
  except
    on E: Exception do
    begin
      FLastErrorMessage := 'DELETE hatasi: ' + E.Message;
      FIsSuccess := False;
      Result := False;
    end;
  end;
end;

function TSqlEngine.ParseAndExecuteDescribe(const SQL: string): TKayitlar;
var
  tabloAdi: string;
  tablo: TVTablo;
  k: TKayit;
  i: Integer;
begin
  Result := nil;
  FLastErrorMessage := '';
  FLastInfoMessage := '';
  FIsSuccess := False;

  try
    if not SQL.StartsWith('DESCRIBE ', True) then
      raise Exception.Create('Komut DESCRIBE ile baslamali.');

    tabloAdi := Trim(Copy(SQL, Length('DESCRIBE') + 1, MaxInt));
    if tabloAdi = '' then raise Exception.Create('Tablo adi belirtilmedi.');

    tablo := FVeritabani.TabloGetir(tabloAdi);
    if not Assigned(tablo) then raise Exception.Create('Tablo bulunamadi: ' + tabloAdi);

    Result := TKayitlar.Create(True);

    for i := 0 to tablo.AlanSayisi - 1 do
    begin
      k := TKayit.Create;
      k['alan'] := tablo.Alanlar[i].Ad;
      k['tur'] := GetEnumName(TypeInfo(TAlanTuru), Ord(tablo.Alanlar[i].Tur));
      k['zorunlu'] := tablo.Alanlar[i].Zorunlu;
      k['benzersiz'] := tablo.Alanlar[i].Benzersiz;
      k['uzunluk'] := tablo.Alanlar[i].Uzunluk;
      Result.Add(k);
    end;

    FLastInfoMessage := Format('DESCRIBE: "%s" tablosunda %d alan.', [tabloAdi, Result.Count]);
    FIsSuccess := True;
  except
    on E: Exception do
    begin
      FLastErrorMessage := 'DESCRIBE Hatasi: ' + E.Message;
      Result := nil;
      FIsSuccess := False;
    end;
  end;
end;


function TSqlEngine.ParseAndExecuteShowTables: TKayitlar;
var
  tabloAdlari: TStringList;
  Sonuc: TKayitlar;
  k: TKayit;
  i: Integer;
begin
  Result := nil;
  FLastInfoMessage := '';
  FLastErrorMessage := '';
  FIsSuccess := False;

  try
    tabloAdlari := FVeritabani.TumTabloAdlariGetir;
    Sonuc := TKayitlar.Create(True);

    for i := 0 to tabloAdlari.Count - 1 do
    begin
      k := TKayit.Create;
      k['tablo'] := tabloAdlari[i];
      Sonuc.Add(k);
    end;

    FLastInfoMessage := Format('SHOW: %d tablo listelendi.', [Sonuc.Count]);
    FIsSuccess := True;
    Result := Sonuc;
  except
    on E: Exception do
    begin
      FLastErrorMessage := 'SHOW TABLES hatasi: ' + E.Message;
      FIsSuccess := False;
      Result := nil;
    end;
  end;
end;


end.          }
