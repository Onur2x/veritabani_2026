unit fMain;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, StdCtrls, Buttons, Dialogs,
  oVeritabani, fDataExplorer, fQueryBuilder, fExportCenter, fSchemaEditor, fTableWizard;

type
  TFormMain = class(TForm)
    BtnYeniDB: TButton;
    BtnDosyaAc: TButton;
    BtnExplorer: TButton;
    BtnQueryBuilder: TButton;
    BtnExport: TButton;
    BtnSchema: TButton;
    Button1: TButton;
    Button2: TButton;
    Button3: TButton;
    EditDBAd: TEdit;
    ComboBoxDBList: TComboBox;
    LabelAktifDB: TLabel;
    LabelDosya: TLabel;
    OpenDialog1: TOpenDialog;
    SaveDialog1: TSaveDialog;
    procedure Button1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure Button3Click(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure BtnYeniDBClick(Sender: TObject);
    procedure BtnDosyaAcClick(Sender: TObject);
    procedure ComboBoxDBListChange(Sender: TObject);
    procedure BtnExplorerClick(Sender: TObject);
    procedure BtnQueryBuilderClick(Sender: TObject);
    procedure BtnExportClick(Sender: TObject);
    procedure BtnSchemaClick(Sender: TObject);
  private
    FVeri: TVeritabani;
    procedure RefreshUI;
    procedure BaglantilariAktifEt;
  public
    property Veri: TVeritabani read FVeri;
  end;

var
  FormMain: TFormMain;

implementation

uses fpjson, jsonparser, oHelper;
  {$R *.lfm}

procedure TFormMain.FormCreate(Sender: TObject);
begin
  FVeri := TVeritabani.Create;
  RefreshUI;
end;

procedure TFormMain.Button2Click(Sender: TObject);
begin
  FormTableWizard.Initialize(Veri, ComboBoxDBList.Text);
  FormTableWizard.ShowModal;
  RefreshUI;
end;
procedure TFormMain.Button1Click(Sender: TObject);
var
  paket: TJSONObject;
begin
  if SaveDialog1.Execute then
  begin
    paket := FVeri.BuildODBPackage;
    SaveJSONToFile(paket, SaveDialog1.FileName); // dışa tek dosya
    paket.Free;
    ShowMessage('Veritabanı paketi başarıyla kaydedildi!');
  end;
end;

procedure TFormMain.Button3Click(Sender: TObject);
var
  json: TJSONObject;
begin
  if OpenDialog1.Execute then
  begin
    json := LoadJSONFromFile(OpenDialog1.FileName);
    FVeri.LoadODBPackage(json);
    json.Free;
    RefreshUI;
    ShowMessage('Veritabanı başarıyla yüklendi!');
  end;
end;




procedure TFormMain.RefreshUI;
var
  dbname: string;
begin
  ComboBoxDBList.Items.Clear;
  for dbName in FVeri.DataDict.Keys do
    ComboBoxDBList.Items.Add(dbName);

  if ComboBoxDBList.Items.Count > 0 then
    ComboBoxDBList.ItemIndex := 0;

  LabelDosya.Caption := 'Dosya: ' + FVeri.DosyaAdi;
  LabelAktifDB.Caption := 'Aktif DB: ' + ComboBoxDBList.Text;
end;

procedure TFormMain.ComboBoxDBListChange(Sender: TObject);
begin
  LabelAktifDB.Caption := 'Aktif DB: ' + ComboBoxDBList.Text;
  BaglantilariAktifEt;
end;

procedure TFormMain.BaglantilariAktifEt;
begin
  FormDataExplorer.Initialize(FVeri, ComboBoxDBList.Text);
  FormQueryBuilder.Initialize(FVeri, ComboBoxDBList.Text);
  FormExportCenter.Initialize(FVeri, ComboBoxDBList.Text);
  FormSchemaEditor.Initialize(FVeri, ComboBoxDBList.Text);
end;

procedure TFormMain.BtnYeniDBClick(Sender: TObject);
var
  yeniAd: string;
begin
  yeniAd := Trim(EditDBAd.Text);
  if yeniAd = '' then Exit;
  FVeri.CreateEmptyDatabase(yeniAd);
  RefreshUI;
  ComboBoxDBList.ItemIndex := ComboBoxDBList.Items.IndexOf(EditDBAd.Text);
  BaglantilariAktifEt;
end;

procedure TFormMain.BtnDosyaAcClick(Sender: TObject);
begin
  OpenDialog1.Filter := 'Veri Dosyaları|*.odb;*.json';
  if OpenDialog1.Execute then
  begin
    FVeri.YukleDosya(OpenDialog1.FileName);
    RefreshUI;
    BaglantilariAktifEt;
  end;
end;

procedure TFormMain.BtnExplorerClick(Sender: TObject);
begin
  FormDataExplorer.Show;
end;

procedure TFormMain.BtnQueryBuilderClick(Sender: TObject);
begin
  FormQueryBuilder.Show;
end;

procedure TFormMain.BtnExportClick(Sender: TObject);
begin
  FormExportCenter.Show;
end;

procedure TFormMain.BtnSchemaClick(Sender: TObject);
begin
  FormSchemaEditor.Show;
end;

end.
