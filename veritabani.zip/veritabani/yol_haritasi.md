 🗺️ Yol Haritası (Roadmap) — Öncelik Sırasına Göre

 Bu harita, mevcut 09-KARSILASTIRMA_VE_YOL_HARITASI.md ve
 DENETIM_VE_YOL_HARITASI.md belgelerindeki ✅ BITTI maddeleri baz alarak, eksik
 kritikal özelliklere odaklanmıştır.

 ### 🔴 FAZ 0: Temel Veri Bütünlüğü ve Eşzamanlılık (KRİTİK)

 ┌──────┬─────────────────┬──────────────────────────────────────────┬─────────┐
 │ ID   │ Özellik         │ Açıklama                                 │ Zorluk  │
 ├──────┼─────────────────┼──────────────────────────────────────────┼─────────┤
 │ R-01 │ MVCC / Snapshot │ Okuyucular yazıcıyı bloke etmez. Her     │ 🔴 Çok  │
 │      │ Isolation       │ transaction için seq snapshot'ı. WAL     │ Yüksek  │
 │      │                 │ zaten var → MVCC için seq tabanlı        │         │
 │      │                 │ görünüm yeterli.                         │         │
 ├──────┼─────────────────┼──────────────────────────────────────────┼─────────┤
 │ R-02 │ SAVEPOINT /     │ SAVEPOINT sp1; ROLLBACK TO sp1; DDL      │ 🟠      │
 │      │ Nested          │ dahil rollback zaten var → savepoint     │ Yüksek  │
 │      │ Transaction     │ için yedek alma eklenmeli.               │         │
 ├──────┼─────────────────┼──────────────────────────────────────────┼─────────┤
 │ R-03 │ UPSERT (ON      │ INSERT ... ON CONFLICT(pk) DO UPDATE SET │ 🟠      │
 │      │ CONFLICT)       │ ... / DO NOTHING. Unique/PK ihlalinde    │ Yüksek  │
 │      │                 │ çakışma çözümü.                          │         │
 ├──────┼─────────────────┼──────────────────────────────────────────┼─────────┤
 │ R-04 │ RETURNING       │ INSERT ... RETURNING id, ad → yeni       │ 🟡 Orta │
 │      │                 │ eklenen/güncellenen satırları döndür.    │         │
 └──────┴─────────────────┴──────────────────────────────────────────┴─────────┘

 ### 🟠 FAZ 1: SQL Standartları ve Gelişmiş İlişkisel Özellikler

 ┌──────┬───────────────────┬────────────────────────────────────────┬─────────┐
 │ ID   │ Özellik           │ Açıklama                               │ Zorluk  │
 ├──────┼───────────────────┼────────────────────────────────────────┼─────────┤
 │ R-05 │ Trigger           │ BEFORE/AFTER INSERT/UPDATE/DELETE FOR  │ 🔴 Çok  │
 │      │ Mekanizması       │ EACH ROW → audit, derived columns,     │ Yüksek  │
 │      │                   │ cascade logic.                         │         │
 ├──────┼───────────────────┼────────────────────────────────────────┼─────────┤
 │ R-06 │ View (Gerçek)     │ CREATE VIEW → TViewDef kataloğunda,    │ 🔴 Çok  │
 │      │                   │ ExecSelect rewriter ile expand. WITH   │ Yüksek  │
 │      │                   │ CHECK OPTION.                          │         │
 ├──────┼───────────────────┼────────────────────────────────────────┼─────────┤
 │ R-07 │ Materialized View │ CREATE MATERIALIZED VIEW + REFRESH     │ 🔴 Çok  │
 │      │                   │ MATERIALIZED VIEW (tam/artımlı).       │ Yüksek  │
 ├──────┼───────────────────┼────────────────────────────────────────┼─────────┤
 │ R-08 │ Stored Procedure  │ CREATE FUNCTION ... LANGUAGE SQL +     │ 🔴 Çok  │
 │      │ / Function        │ CALL / SELECT func(). PL/pgSQL alt     │ Yüksek  │
 │      │                   │ kümesi.                                │         │
 ├──────┼───────────────────┼────────────────────────────────────────┼─────────┤
 │ R-09 │ LATERAL JOIN      │ CROSS JOIN LATERAL (SELECT ...) →      │ 🟠      │
 │      │                   │ correlated subquery'nin set-returning  │ Yüksek  │
 │      │                   │ versiyonu.                             │         │
 ├──────┼───────────────────┼────────────────────────────────────────┼─────────┤
 │ R-10 │ CYCLE Detection   │ WITH RECURSIVE ... CYCLE col SET       │ 🟡 Orta │
 │      │ (Recursive CTE)   │ is_cycle USING path — sonsuz döngü     │         │
 │      │                   │ koruması.                              │         │
 ├──────┼───────────────────┼────────────────────────────────────────┼─────────┤
 │ R-11 │ DEFERRABLE        │ SET CONSTRAINTS ALL DEFERRED →         │ 🟡 Orta │
 │      │ Constraints       │ transaction sonuna kadar erteleme.     │         │
 └──────┴───────────────────┴────────────────────────────────────────┴─────────┘

 ### 🟡 FAZ 2: Ölçeklenebilirlik ve Performans

 ┌──────┬───────────────────────┬────────────────────────────────────┬─────────┐
 │ ID   │ Özellik               │ Açıklama                           │ Zorluk  │
 ├──────┼───────────────────────┼────────────────────────────────────┼─────────┤
 │ R-12 │ Connection Pool       │ TVDbPool şimdi tek motor. Shared   │ 🔴 Çok  │
 │      │ (Gerçek               │ memory / named pipe / TCP ile      │ Yüksek  │
 │      │ Multi-Process)        │ multi-process pool.                │         │
 ├──────┼───────────────────────┼────────────────────────────────────┼─────────┤
 │ R-13 │ Table Partitioning    │ PARTITION BY RANGE/HASH/LIST +     │ 🔴 Çok  │
 │      │                       │ partition pruning. VDbTable →      │ Yüksek  │
 │      │                       │ TPartitionedTable.                 │         │
 ├──────┼───────────────────────┼────────────────────────────────────┼─────────┤
 │ R-14 │ Parallel Query        │ EXPLAIN → Parallel Seq Scan,       │ 🔴 Çok  │
 │      │ Execution             │ Parallel Hash Join. Thread pool +  │ Yüksek  │
 │      │                       │ work stealing.                     │         │
 ├──────┼───────────────────────┼────────────────────────────────────┼─────────┤
 │ R-15 │ Cost-Based Optimizer  │ İstatistik toplama (ANALYZE),      │ 🔴 Çok  │
 │      │                       │ kartinalite tahmini, join          │ Yüksek  │
 │      │                       │ sıralaması, index seçimi.          │         │
 ├──────┼───────────────────────┼────────────────────────────────────┼─────────┤
 │ R-16 │ Incremental Backup /  │ pg_basebackup benzeri: WAL         │ 🟠      │
 │      │ WAL Archiving         │ segmentleri → archive klasörü →    │ Yüksek  │
 │      │                       │ PITR.                              │         │
 ├──────┼───────────────────────┼────────────────────────────────────┼─────────┤
 │ R-17 │ Streaming Replication │ Primary → Replica (async/sync).    │ 🔴 Çok  │
 │      │                       │ WALEnabled zaten var → replica     │ Yüksek  │
 │      │                       │ ReplayWAL loop.                    │         │
 └──────┴───────────────────────┴────────────────────────────────────┴─────────┘

 ### 🟢 FAZ 3: Platform, Güvenlik ve Ekosistem

 ┌──────┬──────────────────────┬─────────────────────────────────────┬─────────┐
 │ ID   │ Özellik              │ Açıklama                            │ Zorluk  │
 ├──────┼──────────────────────┼─────────────────────────────────────┼─────────┤
 │ R-18 │ RBAC / Role / GRANT  │ CREATE ROLE, GRANT SELECT ON t TO   │ 🟠      │
 │      │                      │ role, SET ROLE. TVSql context'te    │ Yüksek  │
 │      │                      │ CurrentRole.                        │         │
 ├──────┼──────────────────────┼─────────────────────────────────────┼─────────┤
 │ R-19 │ Row Level Security   │ ALTER TABLE ... ENABLE ROW LEVEL    │ 🟠      │
 │      │ (RLS)                │ SECURITY + CREATE POLICY.           │ Yüksek  │
 ├──────┼──────────────────────┼─────────────────────────────────────┼─────────┤
 │ R-20 │ ICU Collation        │ COLLATE "tr-TR-u-kn-ks" gibi.       │ 🟡 Orta │
 │      │ Desteği              │ VDbText genişletilecek.             │         │
 ├──────┼──────────────────────┼─────────────────────────────────────┼─────────┤
 │ R-21 │ Extension/Plugin     │ CREATE EXTENSION → dinamik          │ 🔴 Çok  │
 │      │ Mekanizması          │ yüklenebilir .so/.dll (custom type, │ Yüksek  │
 │      │                      │ function, index).                   │         │
 ├──────┼──────────────────────┼─────────────────────────────────────┼─────────┤
 │ R-22 │ Online DDL           │ CREATE INDEX CONCURRENTLY, ALTER    │ 🔴 Çok  │
 │      │ (CONCURRENTLY)       │ TABLE ... SET NOT NULL VALIDATE.    │ Yüksek  │
 ├──────┼──────────────────────┼─────────────────────────────────────┼─────────┤
 │ R-23 │ Cross-Platform DLL / │ vdbapi.dll → Linux .so, macOS       │ 🟡 Orta │
 │      │ C API                │ .dylib. CMake/Meson build.          │         │
 ├──────┼──────────────────────┼─────────────────────────────────────┼─────────┤
 │ R-24 │ Monitoring / pg_stat │ SHOW STATS, pg_stat_statements      │ 🟡 Orta │
 │      │ Benzeri              │ benzeri yavaş sorgu, cache hit      │         │
 │      │                      │ ratio, WAL yazma hızı.              │         │
 └──────┴──────────────────────┴─────────────────────────────────────┴─────────┘

 ───────────────────────────────────────────────────────────────────────────────

 🎯 Önerilen Başlangıç Noktası (İlk 3 Ay)

 Eğer bu projeyi production-ready bir embedded DB veya SQLite alternatifi haline
 getirmek istiyorsanız, şu sırayla gidin:

 ### 1. Hafta 1-2: UPSERT + RETURNING (R-03, R-04)

 - Parser: ON CONFLICT (kolon) DO UPDATE SET ... / DO NOTHING
 - Executor: ExecInsert → conflict detection → update path
 - Test: sqltest + mutation

 ### 2. Hafta 3-4: SAVEPOINT (R-02)

 - VDbCore: Savepoint(name) → FSeq + FIndex snapshot (copy-on-write)
 - ROLLBACK TO → snapshot geri yükle
 - RELEASE → snapshot sil

 ### 3. Hafta 5-8: MVCC Temelleri (R-01) — En Kritik

 - Her TVSql için SnapshotSeq (transaction başlangıç FSeq)
 - ExecSelect: WHERE filtresinde Row.Seq <= SnapshotSeq görünürlük kontrolü
 - UPDATE/DELETE: SELECT ... FOR UPDATE kilidi (yeni kilit türü)
 - COMMIT: SnapshotSeq = FSeq güncelle
 - Bu tek başına multi-user concurrency'yi çözer.

 ### 4. Hafta 9-12: Trigger + View (R-05, R-06)

 - TTriggerDef kataloğunda (event, timing, for each row, when, body)
 - ExecInsert/Update/Delete → trigger tetikleme (recursive guard ile)
 - CREATE VIEW → TViewDef + ExecSelect rewriter (inline expansion)

 ───────────────────────────────────────────────────────────────────────────────

 📝 Özet: VDB Hangi Durumlarda Uygun?

 ┌──────────────────────┬──────────────┬───────────────────────────────────────┐
 │ Senaryo              │ Uygun mu?    │ Neden                                 │
 ├──────────────────────┼──────────────┼───────────────────────────────────────┤
 │ Masaüstü / Mobil     │ ✅ Mükemmel  │ Tek dosya, sıfır kurulum, TDataSet,   │
 │ Uygulama (Tek        │              │ şifreleme, CDC                        │
 │ kullanıcı)           │              │                                       │
 ├──────────────────────┼──────────────┼───────────────────────────────────────┤
 │ IoT / Edge Cihaz     │ ✅ Çok İyi   │ Düşük kaynak, crash-safe, WAL,        │
 │                      │              │ yedekleme kolay                       │
 ├──────────────────────┼──────────────┼───────────────────────────────────────┤
 │ Küçük Web Uygulaması │ ⚠️ Kabul     │ Connection pool + tek process →       │
 │ (Düşük eşzamanlılık) │ Edilebilir   │ yeterli olabilir                      │
 ├──────────────────────┼──────────────┼───────────────────────────────────────┤
 │ Çoklu Kullanıcı      │ ❌ Uygun     │ MVCC, SAVEPOINT, replication, HA yok  │
 │ Sunucu / Web API     │ Değil        │                                       │
 ├──────────────────────┼──────────────┼───────────────────────────────────────┤
 │ Analitik / OLAP İş   │ ⚠️ Sınırlı   │ Paralel sorgu, partitioning,          │
 │ Yükleri              │              │ cost-based optimizer yok              │
 ├──────────────────────┼──────────────┼───────────────────────────────────────┤
 │ SQLite Yerine        │ ✅ Bazı      │ Daha fazla SQL özelliği (JSONB,       │
 │ Geçirme              │ durumlarda   │ Spatial, Range, Partial/Expr/Covering │
 │                      │              │ Index) ama concurrency zayıf          │
 └──────────────────────┴──────────────┴───────────────────────────────────────┘
