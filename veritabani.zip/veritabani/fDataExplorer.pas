unit fDataExplorer;

{$mode ObjFPC}{$H+}

interface

uses
   SysUtils, Forms, Controls, StdCtrls, ComCtrls, Grids,
  Classes,oTypes, oVeritabani, oViewModel, fRowEditor;

type
  TFormDataExplorer = class(TForm)
    Button1:TButton;
    Button2:TButton;
    Button3:TButton;
    TreeDB: TTreeView;
    GridTable: TStringGrid;
    ButtonRefresh: TButton;
    procedure Button1Click(Sender:TObject);
    procedure Button2Click(Sender:TObject);
    procedure Button3Click(Sender:TObject);
    procedure FormShow(Sender: TObject);
    procedure TreeDBSelectionChanged(Sender: TObject);
    procedure GridTableDblClick(Sender: TObject);
    procedure ButtonRefreshClick(Sender: TObject);
  private
    FVeri: TVeritabani;
    FAktifDB: string;
    FSilinmisSatirlar: array of array of string; // Silinen veri satırları
    FSilinmisIndexler: array of Integer;         // Silinen satır konumları

    function AlanYarat(const AlanAdi,DegerStr:string):TAlanVerisi;
    procedure PopulateTree;
    procedure LoadSelectedTable;
  public
    procedure Initialize(Veritabani: TVeritabani; const DBName: string);
  end;

var
  FormDataExplorer: TFormDataExplorer;

implementation
uses oTabloSchema,dialogs;
{$R *.lfm}

function TFormDataExplorer.AlanYarat(const AlanAdi, DegerStr: string): TAlanVerisi;
var
  tip: TAlanTuru;
  sayi: Double;
  intDeger: Integer;
  boolDeger: Boolean;
begin
  Result.Ad := AlanAdi;

  // Alanın tipi veritabanı şemasından alınmalı — örnek:
  tip := FVeri.GetFieldType(FAktifDB, TreeDB.Selected.Text, AlanAdi);

  case tip of
    ftInteger:
      if TryStrToInt(DegerStr, intDeger) then
        Result.Icerik := intDeger
      else
        Result.Icerik := 0;

    ftFloat:
      if TryStrToFloat(DegerStr, sayi) then
        Result.Icerik := sayi
      else
        Result.Icerik := 0.0;

    ftBoolean:
      Result.Icerik := LowerCase(DegerStr) = 'true';

    ftText, ftDate, ftTime, ftTimestamp, ftUUID:
      Result.Icerik := DegerStr;

    ftBlob:
      Result.Icerik := ''; // veya Base64Decode yapılabilir

    else
      Result.Icerik := DegerStr;
  end;
end;
procedure TFormDataExplorer.Initialize(Veritabani: TVeritabani; const DBName: string);
begin
  FVeri := Veritabani;
  FAktifDB := DBName;

end;

procedure TFormDataExplorer.FormShow(Sender: TObject);
begin
 PopulateTree;
end;

function TryParseRowFromGrid(const Grid: TStringGrid; const schema: TTabloSchema; satirIndex: Integer; out row: TRow): Boolean;
var
  j,intd: Integer;
  alanAdi: string;
  tip: TAlanTuru;
  degerStr: string;
  deger: Variant;
  ff:Double;
begin
  row := TRow.Create;
  Result := True;

  for j := 0 to schema.AlanSayisi - 1 do
  begin
    alanAdi := schema.AlanAdlari[j];//.Name;
     tip := schema.AlanTipi(alanAdi);
    degerStr := Grid.Cells[j, satirIndex];

    case tip of
      ftInteger:
        if TryStrToInt(degerStr, intd) then
          row.Add(alanAdi, Variant(intd))
        else
          Result := False;

      ftFloat:
        if TryStrToFloat(degerStr, ff ) then
          row.Add(alanAdi, Variant(ff))
        else
          Result := False;

      ftBoolean:
        row.Add(alanAdi, LowerCase(degerStr) = 'true'); // veya '1'

      ftText, ftDate, ftTime, ftTimestamp, ftUUID:
        row.Add(alanAdi, degerStr);

      else
        row.Add(alanAdi, degerStr);
    end;

    if not Result then
    begin
      row.Free;
      Exit;
    end;
  end;
end;

procedure TFormDataExplorer.Button1Click(Sender:TObject);
var
  dbName, tblName: string;
  i, j: Integer;
  satir: TRow;
  schema: TTabloSchema;
begin
  if TreeDB.Selected = nil then Exit;
  if TreeDB.Selected.Parent = nil then Exit;

  tblName := TreeDB.Selected.Text;
  dbName := TreeDB.Selected.Parent.Text;
  schema := FVeri.GetTableSchema(dbName, tblName);

 for i := 1 to GridTable.RowCount - 1 do
begin
  if TryParseRowFromGrid(GridTable, schema, i, satir) then
  begin
    FVeri.InsertRow(dbName, tblName, satir);
    satir.Free;
  end
  else
    ShowMessage('Satır ' + IntToStr(i) + ' geçersiz veri içeriyor ve eklenmedi.');
end;


  ShowMessage('Veriler eklendi.');
  LoadSelectedTable;
end;

procedure TFormDataExplorer.Button2Click(Sender:TObject);
var
  r, c: Integer;
  satir: array of string;
  i:Integer;
begin
  r := GridTable.Row;
  if r <= 0 then Exit;

  SetLength(satir, GridTable.ColCount);
  for c := 0 to GridTable.ColCount - 1 do
    satir[c] := GridTable.Cells[c, r];

  // Kuyruğa ekle


   // Diziyi 1 eleman büyüt
  SetLength(FSilinmisSatirlar, Length(FSilinmisSatirlar) + 1);

  // Elemanları sağa kaydır
  for i := High(FSilinmisSatirlar) downto 1 do
    FSilinmisSatirlar[i] := FSilinmisSatirlar[i - 1];

  // En başa ekle
  FSilinmisSatirlar[0] := satir;


  SetLength(FSilinmisIndexler, Length(FSilinmisIndexler) + 1);

  for i := High(FSilinmisIndexler) downto 1 do
    FSilinmisIndexler[i] := FSilinmisIndexler[i - 1];

  FSilinmisIndexler[0] := r;

  //system.Insert(FSilinmisSatirlar, satir, 0);
  //Insert(FSilinmisIndexler, r, 0);

  // Kuyruk kapasitesini sınırlayalım (max 5)
  if Length(FSilinmisSatirlar) > 5 then
    Delete(FSilinmisSatirlar, 5, 1);
  if Length(FSilinmisIndexler) > 5 then
    Delete(FSilinmisIndexler, 5, 1);

  GridTable.DeleteRow(r);
  Button3.Enabled:=true;
end;

procedure TFormDataExplorer.Button3Click(Sender:TObject);
var
  i, r: Integer;
  c:Integer;
begin
  if (Length(FSilinmisSatirlar) = 0) or (Length(FSilinmisIndexler) = 0) then
  begin
    ShowMessage('Geri alınacak satır yok.');
    Button3.Enabled:=false;
    Exit;
  end;

  r := FSilinmisIndexler[0];
  GridTable.RowCount := GridTable.RowCount + 1;

  // Aşağı kaydır
  for i := GridTable.RowCount - 1 downto r + 1 do
    for c := 0 to GridTable.ColCount - 1 do
      GridTable.Cells[c, i] := GridTable.Cells[c, i - 1];

  // Silinen veriyi yerleştir
  for i := 0 to GridTable.ColCount - 1 do
    GridTable.Cells[i, r] := FSilinmisSatirlar[0][i];

  // Stack'ten çıkar
  Delete(FSilinmisSatirlar, 0, 1);
  Delete(FSilinmisIndexler, 0, 1);

end;

procedure TFormDataExplorer.ButtonRefreshClick(Sender: TObject);
begin
  PopulateTree;
end;

procedure TFormDataExplorer.PopulateTree;
var
  dbName: string;
  dbNode: TTreeNode;
  tblName: string;
begin
  TreeDB.Items.Clear;
  for dbName in FVeri.GetDatabaseNames do
  begin
    dbNode := TreeDB.Items.Add(nil, dbName);
    for tblName in FVeri.GetTableNames(dbName) do
      TreeDB.Items.AddChild(dbNode, tblName);
  end;
end;

procedure TFormDataExplorer.TreeDBSelectionChanged(Sender: TObject);
begin
  LoadSelectedTable;
end;

procedure TFormDataExplorer.LoadSelectedTable;
var
  dbNode: TTreeNode;
  dbName, tblName: string;
  rows: TRowList;
  vms: specialize TObservableList<TRowViewModel>;
begin
  if TreeDB.Selected = nil then Exit;
  if TreeDB.Selected.Parent = nil then Exit;

  tblName := TreeDB.Selected.Text;
  dbNode := TreeDB.Selected.Parent;
  dbName := dbNode.Text;


  //  rows := FVeri.SelectFrom(dbName, tblName, [], '');
  rows := FVeri.SelectFrom(dbName, tblName, [], [], '', '', nil, -1, 0);

  vms := ToViewModelList(rows);
  BindViewModelsToGrid(GridTable, vms);
  vms.Free;
end;

procedure TFormDataExplorer.GridTableDblClick(Sender: TObject);
var
  rowIdx: integer;
  vm: TRowViewModel;
  newRow: TRow;
  rows: TRowList;
begin
  rowIdx := GridTable.Row - 1;
  if rowIdx < 0 then Exit;


  rows := FVeri.SelectFrom(TreeDB.Selected.Parent.Text, TreeDB.Selected.Text,
    [], [], '', '', nil, -1, 0);

  vm := TRowViewModel.Create(rows[rowIdx]);

  if FormRowEditor = nil then
    FormRowEditor := TFormRowEditor.Create(Self);
  FormRowEditor.LoadRow(vm);

  if FormRowEditor.ShowModal = mrOk then
  begin
    newRow := FormRowEditor.GetEditedRow;
    rows[rowIdx].Assign(newRow);
    newRow.Free;
    LoadSelectedTable;
  end;

  vm.Free;
end;

end.
