unit oDbPackage;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, Variants, Generics.Collections,
  fpjson, jsonparser, // JSON desteği
  ZStream,           // TZCompressionStream / TZDecompressionStream
  oTypes, oTabloSchema, oVeritabani;

type
  /// Paket biçimindeki .odb dosyasını oluşturur ve yükler
  TDbPackage = class
  public
    /// .odb paketine manifest, schema ve data dosyalarını yazar
    class procedure SavePackage(const FileName: string;
      const Manifest: TDbManifest; Schemas: specialize TArray<TTabloSchema>;
      DataRows: specialize TArray<TList<TRow>>);

    /// .odb paketini çözer ve manifest, schema ve data bilgilerine dönüştürür
    class procedure LoadPackage(const FileName: string;
      out Manifest: TDbManifest; out Schemas: specialize TList<TTabloSchema>;
      out DataRows: specialize TList<TList<TRow>>);
  end;

implementation

uses
  StrUtils, jsonwriter;

const
  // Paket içeriklerini önce memory'ye yazıyoruz; sonra tümü sıkıştırılır.
  // Her entry: [UInt16 pathLen][path UTF8][UInt32 dataLen][data]

{------------------------------------------------------------------------------}
procedure WriteEntry(OutStream: TStream; const RelPath: string; const Data: TBytes);
var
  pathLen: uint16;
  dataLen: uint32;
begin
  pathLen := Length(RelPath);
  OutStream.WriteBuffer(pathLen, SizeOf(pathLen));
  OutStream.WriteBuffer(Pointer(RelPath)^, pathLen);

  dataLen := Length(Data);
  OutStream.WriteBuffer(dataLen, SizeOf(dataLen));
  if dataLen > 0 then
    OutStream.WriteBuffer(Data[0], dataLen);
end;

{------------------------------------------------------------------------------}
function ReadEntry(InStream: TStream; out RelPath: string; out Data: TBytes): boolean;
var
  pathLen: uint16;
  dataLen: uint32;
begin
  Result := False;
  if InStream.Read(pathLen, SizeOf(pathLen)) <> SizeOf(pathLen) then Exit;
  SetLength(RelPath, pathLen);
  InStream.ReadBuffer(Pointer(RelPath)^, pathLen);

  InStream.ReadBuffer(dataLen, SizeOf(dataLen));
  SetLength(Data, dataLen);
  if dataLen > 0 then
    InStream.ReadBuffer(Data[0], dataLen);

  Result := True;
end;

{------------------------------------------------------------------------------}
function WriteTableDataBinaryToBytes(Schema: TTabloSchema;
  Rows: specialize TList<TRow>): TBytes;
var
  m: TMemoryStream;
  i, j: integer;
  flag: byte;
  fld: TAlanTanimi;
  v: variant;
  s: rawbytestring;
  len32: cardinal;
begin
  m := TMemoryStream.Create;
  try
    // 1) satır sayısı
    m.WriteBuffer(cardinal(Rows.Count), SizeOf(cardinal));
    // 2) her satır, her alan
    for i := 0 to Rows.Count - 1 do
    begin
      for j := 0 to Schema.AlanSayisi - 1 do
      begin
        fld := Schema.Alanlar[j];
        v := Rows[i].Values[fld.Name];
        // null bayrağı
        if VarIsNull(v) then flag := 0
        else
          flag := 1;
        m.WriteBuffer(flag, 1);
        if flag = 1 then
        begin
          case fld.Tip of
            ftAutoIncrement, ftInteger:
              m.WriteBuffer(int64(v), SizeOf(int64));
            ftFloat, ftDouble, ftCurrency, ftDate, ftTime, ftTimestamp:
              m.WriteBuffer(double(v), SizeOf(double));
            ftBoolean:
              m.WriteBuffer(byte(v), SizeOf(byte));
            ftChar, ftText, ftUUID, ftJSON, ftBlob, ftFile, ftImage, ftPhone:
            begin
              s := UTF8Encode(VarToStr(v));
              len32 := Length(s);
              m.WriteBuffer(len32, SizeOf(len32));
              m.WriteBuffer(Pointer(s)^, len32);
            end;
            else
              // bilinmeyen tipler → as string
              s := UTF8Encode(VarToStr(v));
              len32 := Length(s);
              m.WriteBuffer(len32, SizeOf(len32));
              m.WriteBuffer(Pointer(s)^, len32);
          end;
        end;
      end;
    end;

    // sonucu TBytes'e dök
    SetLength(Result, m.Size);
    m.Position := 0;
    m.ReadBuffer(Result[0], m.Size);
  finally
    m.Free;
  end;
end;

{------------------------------------------------------------------------------}
function ReadTableDataBinaryFromBytes(Schema: TTabloSchema;
  const Bytes: TBytes): specialize TList<TRow>;
var
  m: TMemoryStream;
  rowCount: cardinal;
  i, j: integer;
  flag: byte;
  fld: TAlanTanimi;
  ival: int64;
  dval: double;
  bval: byte;
  len32: cardinal;
  buf: rawbytestring;
  r: TRow;
begin
  m := TMemoryStream.Create;
  try
    m.WriteBuffer(Bytes[0], Length(Bytes));
    m.Position := 0;
    // 1) satır sayısı
    m.ReadBuffer(rowCount, SizeOf(cardinal));
    Result := specialize TList<TRow>.Create;
    // 2) satır döngüsü
    for i := 0 to rowCount - 1 do
    begin
      r := TRow.Create;
      for j := 0 to Schema.AlanSayisi - 1 do
      begin
        fld := Schema.Alanlar[j];
        m.ReadBuffer(flag, 1);
        if flag = 0 then
          r.Add(fld.Name, Null)
        else
        begin
          case fld.Tip of
            ftAutoIncrement, ftInteger:
            begin
              m.ReadBuffer(ival, SizeOf(int64));
              r.Add(fld.Name, ival);
            end;
            ftFloat, ftDouble, ftCurrency, ftDate, ftTime, ftTimestamp:
            begin
              m.ReadBuffer(dval, SizeOf(double));
              r.Add(fld.Name, dval);
            end;
            ftBoolean:
            begin
              m.ReadBuffer(bval, SizeOf(byte));
              r.Add(fld.Name, bval <> 0);
            end;
            ftChar, ftText, ftUUID, ftJSON, ftBlob, ftFile, ftImage, ftPhone:
            begin
              m.ReadBuffer(len32, SizeOf(cardinal));
              SetLength(buf, len32);
              m.ReadBuffer(Pointer(buf)^, len32);
              r.Add(fld.Name, UTF8Decode(buf));
            end;
            else
              // bilinmeyen tipler → string
              m.ReadBuffer(len32, SizeOf(cardinal));
              SetLength(buf, len32);
              m.ReadBuffer(Pointer(buf)^, len32);
              r.Add(fld.Name, UTF8Decode(buf));
          end;
        end;
      end;
      Result.Add(r);
    end;
  finally
    m.Free;
  end;
end;

{------------------------------------------------------------------------------}
function ParseManifestFromJSONBytes(const Bytes: TBytes): TDbManifest;
var
  str: string;
  json: TJSONData;
  obj: TJSONObject;
  i: integer;
  arr: TJSONArray;
  tm: TTableManifest;
begin
  str := TEncoding.UTF8.GetString(Bytes);
  json := GetJSON(str);
  try
    obj := json as TJSONObject;
    Result.UID := obj.Get('uid', '');
    Result.DatabaseName := obj.Get('databaseName', '');
    Result.CreatedAt := ISO8601ToDate(obj.Get('createdAt', ''));
    Result.Version := obj.Get('version', '1.0');

    arr := obj.Arrays['tables'];
    SetLength(Result.Tables, arr.Count);
    for i := 0 to arr.Count - 1 do
    begin
      tm.TableName := arr.Items[i].GetPath('name').AsString;
      tm.SchemaFile := arr.Items[i].GetPath('schemaFile').AsString;
      tm.DataFile := arr.Items[i].GetPath('dataFile').AsString;
      tm.RecordCount := arr.Items[i].GetPath('recordCount').AsInteger;
      tm.LastRecordId := arr.Items[i].GetPath('lastRecordId').AsInt64;
      Result.Tables[i] := tm;
    end;
  finally
    json.Free;
  end;
end;

{------------------------------------------------------------------------------}
class procedure TDbPackage.SavePackage(const FileName: string;
  const Manifest: TDbManifest; Schemas: specialize TArray<TTabloSchema>;
  DataRows: specialize TArray<TList<TRow>>);
var
  mem: TMemoryStream;
  comp: TZCompressionStream;
  fs: TFileStream;
  mj: TJSONObject;
  tblArr: TJSONArray;
  bytes: TBytes;
  i: integer;
begin
  // 1) manifest.json’u hazırla
  mj := TJSONObject.Create;
  try
    mj.Add('uid', Manifest.UID);
    mj.Add('databaseName', Manifest.DatabaseName);
    mj.Add('createdAt', DateTimeToISO8601(Manifest.CreatedAt));
    mj.Add('version', Manifest.Version);

    tblArr := TJSONArray.Create;
    for i := 0 to High(Manifest.Tables) do
      with Manifest.Tables[i] do
      begin
        var o := TJSONObject.Create;
        o.Add('name', TableName);
        o.Add('schemaFile', SchemaFile);
        o.Add('dataFile', DataFile);
        o.Add('recordCount', RecordCount);
        o.Add('lastRecordId', LastRecordId);
        tblArr.Add(o);
      end;
    mj.Add('tables', tblArr);

    bytes := TEncoding.UTF8.GetBytes(mj.FormatJSON([], 2));
  finally
    mj.Free;
  end;

  // 2) archive container
  mem := TMemoryStream.Create;
  try
    WriteEntry(mem, 'manifest.json', bytes);

    // schema dosyaları
    for i := 0 to High(Schemas) do
    begin
      bytes := TEncoding.UTF8.GetBytes(Schemas[i].ToJSON.FormatJSON([], 2));
      WriteEntry(mem, Format('tables/%s.schema.json', [Schemas[i].Ad]), bytes);
    end;

    // data.bin dosyaları
    for i := 0 to High(Schemas) do
    begin
      bytes := WriteTableDataBinaryToBytes(Schemas[i], DataRows[i]);
      WriteEntry(mem, Format('tables/%s.data.bin', [Schemas[i].Ad]), bytes);
    end;

    // 3) sıkıştır ve yaz
    fs := TFileStream.Create(FileName, fmCreate);
    try
      comp := TZCompressionStream.Create(clMax, fs);
      try
        mem.Position := 0;
        comp.CopyFrom(mem, mem.Size);
      finally
        comp.Free;
      end;
    finally
      fs.Free;
    end;
  finally
    mem.Free;
  end;
end;

{------------------------------------------------------------------------------}
class procedure TDbPackage.LoadPackage(const FileName: string;
  out Manifest: TDbManifest; out Schemas: specialize TList<TTabloSchema>;
  out DataRows: specialize TList<TList<TRow>>);
var
  fs: TFileStream;
  decomp: TZDecompressionStream;
  mem: TMemoryStream;
  relPath: string;
  Data: TBytes;
  tblSchema: TTabloSchema;
  tblRows: specialize TList<TRow>;
  jsonArr: TJSONArray;
begin
  Schemas := specialize TList<TTabloSchema>.Create;
  DataRows := specialize TList<TList<TRow>>.Create;

  fs := TFileStream.Create(FileName, fmOpenRead);
  try
    decomp := TZDecompressionStream.Create(fs);
    try
      mem := TMemoryStream.Create;
      try
        mem.CopyFrom(decomp, 0);
        mem.Position := 0;

        // tüm entry'leri oku
        while ReadEntry(mem, relPath, Data) do
        begin
          if relPath = 'manifest.json' then
            Manifest := ParseManifestFromJSONBytes(Data)
          else if relPath.EndsWith('.schema.json') then
          begin
            tblSchema := TTabloSchema.Create;
            jsonArr := TJSONArray(GetJSON(TEncoding.UTF8.GetString(Data)));
            tblSchema.FromJSON(jsonArr);
            tblSchema.Ad := ChangeFileExt(ExtractFileName(relPath), '');
            Schemas.Add(tblSchema);
          end
          else if relPath.EndsWith('.data.bin') then
          begin
            tblRows := ReadTableDataBinaryFromBytes(Schemas[Schemas.Count - 1], Data);
            DataRows.Add(tblRows);
          end;
          // signature.sig işlenmez (ileride ekleyebiliriz)
        end;
      finally
        mem.Free;
      end;
    finally
      decomp.Free;
    end;
  finally
    fs.Free;
  end;
end;

end.
