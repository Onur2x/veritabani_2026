unit oTabloKayit;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, Variants, Generics.Collections, otypes, oTabloSchema, fpjson;
type

  { TTabloKayit }

  TTabloKayit = class
  private
    FVeriler: specialize TDictionary<string, Variant>;
  public
    constructor Create;
    destructor Destroy; override;
    procedure DegerAta(const AlanAdi: string; const Deger: Variant);
    function DegerAl(const AlanAdi: string): Variant;
    function TryDegerAl(const AlanAdi:string;out Deger:Variant):Boolean;
    function Varmi(const AlanAdi:string):Boolean;
    function SerializeToBytes(const Schema: TTabloSchema): TBytes;
    procedure DeserializeFromBytes(const Schema: TTabloSchema; const KayitVerisi: TBytes);
    function ToJSON: TJSONObject;
    procedure FromJSON(J: TJSONObject);
    property Veriler: specialize TDictionary<string, Variant> read FVeriler;
  end;

implementation
uses odebug;
constructor TTabloKayit.Create;
begin
  inherited Create;
  FVeriler := specialize TDictionary<string, Variant>.Create;
end;

destructor TTabloKayit.Destroy;
begin
  FVeriler.Free;
  inherited Destroy;
end;

function TTabloKayit.Varmi(const AlanAdi: string): Boolean;
var
  Key: string;
begin
  for Key in FVeriler.Keys do
    if SameText(Key, AlanAdi) then
      Exit(True);
  Result := False;
end;


procedure TTabloKayit.DegerAta(const AlanAdi: string; const Deger: Variant);
begin
  FVeriler.AddOrSetValue(AlanAdi, Deger);
end;

function TTabloKayit.DegerAl(const AlanAdi: string): Variant;
begin
  if not FVeriler.TryGetValue(AlanAdi, Result) then
    raise Exception.Create('Alan bulunamadı: ' + AlanAdi);
// if not TryDegerAl(AlanAdi, Result) then
//    Result := Null; // ❗ otomatik NULL döndürür

end;

function TTabloKayit.TryDegerAl(const AlanAdi: string; out Deger: Variant): Boolean;
begin
  try
    Deger := DegerAl(AlanAdi);
    Result := True;
  except
    on E: Exception do
    begin
      Deger := Null;
      Result := False;
    end;
  end;
end;

function TTabloKayit.SerializeToBytes(const Schema: TTabloSchema): TBytes;
var
  i, Ofs, KayitBoyutu: Integer;
  Alan: TAlanTanimi;
  s: string;
  d: Double;
  i32: Integer;
  i64: Int64;
  b: Byte;
  deger:Variant;
begin
  KayitBoyutu := Schema.ToplamKayitBoyutu;
  SetLength(Result, KayitBoyutu);
  Ofs := 0;

  try

   for i := 0 to High(Schema.Alanlar) do
  begin
    Alan := Schema.Alanlar[i];

    // Başlangıçta alanı sıfırla
    FillChar(Result[Ofs], AlanBoyutu(Alan), 0);

    // Alan değeri varsa oku
    if not TryDegerAl(Alan.Name, Deger) then
    begin
      Inc(Ofs, AlanBoyutu(Alan));
      Continue;
    end;

    case Alan.Tip of
      ftInteger, ftAutoIncrement:
        begin
          if not VarIsNull(Deger) and TryStrToInt(VarToStr(Deger), i32) then
            Move(i32, Result[Ofs], 4);
        end;

      ftFloat, ftCurrency:
        begin
          if not VarIsNull(Deger) and TryStrToFloat(VarToStr(Deger), d) then
            Move(d, Result[Ofs], 8);
        end;

      ftBoolean:
        begin
          b := Ord(Boolean(Deger));
          Move(b, Result[Ofs], 1);
        end;

      ftDate, ftTime, ftTimestamp:
        begin
          if not VarIsNull(Deger) and TryStrToInt64(VarToStr(Deger), i64) then
            Move(i64, Result[Ofs], 8);
        end;

      else
        begin
          s := VarToStr(Deger);
          SetLength(s, Alan.Length);
          Move(s[1], Result[Ofs], Alan.Length);
        end;
    end;

    Inc(Ofs, AlanBoyutu(Alan));
  end;

  except
    on E: Exception do
      raise Exception.Create('Kayıt dönüştürme sırasında hata: ' + E.Message);
  end;
end;
procedure TTabloKayit.DeserializeFromBytes(const Schema:TTabloSchema;const
  KayitVerisi:TBytes);
var
  i, Ofs: Integer;
  Alan: TAlanTanimi;
  s: string;
  d: Double;
  i32: Integer;
  i64: Int64;
  b: Byte;
begin
  Ofs := 0;

  for i := 0 to High(Schema.Alanlar) do
  begin
    Alan := Schema.Alanlar[i];

    // Veri eksikse → varsayılan değer ata ve geç
    if (Ofs + AlanBoyutu(Alan)) > Length(KayitVerisi) then
    begin
      case Alan.Tip of
        ftInteger, ftAutoIncrement: DegerAta(Alan.Name, 0);
        ftFloat, ftCurrency:        DegerAta(Alan.Name, 0.0);
        ftBoolean:                  DegerAta(Alan.Name, False);
        ftDate, ftTime, ftTimestamp:DegerAta(Alan.Name, Int64(0));
      else
        DegerAta(Alan.Name, '');
      end;

      Continue;
    end;

    // Veri varsa → normal okuma
    case Alan.Tip of
      ftInteger, ftAutoIncrement:
        begin Move(KayitVerisi[Ofs], i32, 4); DegerAta(Alan.Name, i32); end;

      ftFloat, ftCurrency:
        begin Move(KayitVerisi[Ofs], d, 8); DegerAta(Alan.Name, d); end;

      ftBoolean:
        begin Move(KayitVerisi[Ofs], b, 1); DegerAta(Alan.Name, Boolean(b)); end;

      ftDate, ftTime, ftTimestamp:
        begin Move(KayitVerisi[Ofs], i64, 8); DegerAta(Alan.Name, i64); end;

      else
        begin
          SetLength(s, Alan.Length);
          Move(KayitVerisi[Ofs], s[1], Alan.Length);
          DegerAta(Alan.Name, TrimRight(s));
        end;
    end;

    Inc(Ofs, AlanBoyutu(Alan));
  end;
end;



function TTabloKayit.ToJSON: TJSONObject;
var
  J: TJSONObject;
  Key: string;
begin
  J := TJSONObject.Create;
  for Key in FVeriler.Keys do
    J.Add(Key, VarToStr(FVeriler[Key]));
  Result := J;
end;

procedure TTabloKayit.FromJSON(J: TJSONObject);
 var
  i: Integer;
  Key: string;
begin
  for i := 0 to J.Count - 1 do
  begin
    Key := J.Names[i];
    FVeriler.AddOrSetValue(Key, J.Get(Key, ''));
  end;
end;

end.
