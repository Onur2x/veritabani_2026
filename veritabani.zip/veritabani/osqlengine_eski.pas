unit osqlengine;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Variants, otypes, otablo, overitabani,oTabloKayit,oTabloSchema,
  Generics.Collections, Generics.Defaults,TypInfo,math;



type
  TSorguSonucu = class
  public
    Basarili: Boolean;
    SorguTipi: string;
    KayitSayisi: Integer;
    HataMesaji: string;
    HataKonumu: Integer;
    BilgiMesaji: string;
    Sure: TDateTime;
    SatirMesajlari: TStringList;
    Tablo: TVTablo;
    Veritabani:TVeritabani;
    constructor Create;
    destructor Destroy; override;
    procedure Temizle;
  end;

  { TSqlEngine }

  TSqlEngine = class
  private
    FVeritabani: TVeritabani;
    function KomutAlterTable(VT:TVeritabani;const SQL:string):TSorguSonucu;
    function KomutCreateDatabase(const SQL:string):TSorguSonucu;
    function KomutCreateTable(VT:TVeritabani;const SQL:string):TSorguSonucu;
    function KomutDelete(VT:TVeritabani;const SQL:string):TSorguSonucu;
    function KomutDescribeTable(VT: TVeritabani; const SQL: string
      ): TSorguSonucu;
    function KomutDropTable(VT:TVeritabani;const SQL:string):TSorguSonucu;
    function KomutInsertInto(VT:TVeritabani;const SQL:string):TSorguSonucu;
    function KomutSelect(VT:TVeritabani;const SQL:string):TSorguSonucu;
    function KomutShowTables(const SQL: string): TSorguSonucu;
    function KomutUpdate(VT:TVeritabani;const SQL:string):TSorguSonucu;
    procedure SerbestFiltre(Node:PFiltreNode);
  public
    constructor Create(AVeritabani: TVeritabani);
    function KomutYurut(const SQL:string):TSorguSonucu;
  end;




  type
  TTabloKayitMultiComparer = class(specialize TComparer<TTabloKayit>)
  private
    FAlanlar: array of string;
    FAlanTipleri: array of TAlanTuru;
    FDesc: Boolean;
  public
    constructor Create(const Alnlr:array of string;ADesc:Boolean;ASchema:
      TTabloSchema);
    function Compare(constref A,B:TTabloKayit):Integer; override;
  end;


 // SQL'in ana bölümlerini ayırır
function SplitSQLParts(const SQL: string): TSQLParts;
// Virgül içeren dizeyi parantez dengesiyle ayırır
function SplitFields(const List: string): TArray<string>;
// Tek bir sütunu (veya alias’lı fonksiyonu) işle
procedure ProcessColumn(const ColName: string; Src: TTabloSchema;
  out Rec: TAlanTanimi);
procedure ProcessColumnAs(const ColName: string; ColType: TAlanTuru;
  out Rec: TAlanTanimi);


    var
    GSonuc: TSorguSonucu;

implementation
uses strutils,Dialogs,FileUtil,odebug,Regex;




constructor TSorguSonucu.Create;
begin
  inherited Create;
  SatirMesajlari := TStringList.Create;
  Temizle;
end;
destructor TSorguSonucu.Destroy;
begin
  FreeAndNil(SatirMesajlari);
  inherited Destroy;
end;
procedure TSorguSonucu.Temizle;
begin
  Basarili    := False;
  SorguTipi   := '';
  KayitSayisi := 0;
  HataMesaji  := '';
  HataKonumu  := -1;
  BilgiMesaji := '';
  Sure        := 0;
  Tablo       := nil;
  SatirMesajlari.Clear;
end;
function TakmaIsimOrDefault(const A: TAlanSecimi): string;
begin
  if A.TakmaIsim <> '' then
    Result := A.TakmaIsim
  else
    Result := A.Alan;
end;
function ifthen(val:boolean;const iftrue:string; const iffalse:string='0') :string;
begin
  if val then result:=iftrue else result:=iffalse;
end;
function ifthen(val:boolean;const iftrue:integer; const iffalse:integer= 0) :integer;
begin
  if val then result:=iftrue else result:=iffalse;
end;
function ifthen(val:boolean;const iftrue:int64  ; const iffalse:int64 = 0)  :int64;
begin
  if val then result:=iftrue else result:=iffalse;
end;
function ifthen(val:boolean;const iftrue:double ; const iffalse:double =0.0):double;
begin
  if val then result:=iftrue else result:=iffalse;
end;


///////////////////////////////////////////////

function SplitSQLFields(const Str: string): specialize TArray<string>;
var
  i, paren: Integer;
  start: Integer;
  ch: Char;
  curr: string;
begin
  paren := 0; start := 1;
  SetLength(Result, 0);
  for i := 1 to Length(Str) do
  begin
    ch := Str[i];
    if ch = '(' then Inc(paren)
    else if ch = ')' then Dec(paren)
    else if (ch = ',') and (paren = 0) then
    begin
      curr := Trim(Copy(Str, start, i - start));
      Result := Result + [curr];
      start := i + 1;
    end;
  end;
  curr := Trim(Copy(Str, start, Length(Str)-start+1));
  if curr <> '' then
    Result := Result + [curr];
end;



function SplitSQLParts(const SQL: string): TSQLParts;
var
  up, tmp: string;
  idxSelect, idxFrom, idxWhere, idxGroup, idxHaving, idxOrder: Integer;
begin
  up := UpperCase(SQL);
  // Bulduğumuz pozisyonlar
  idxSelect := Pos('SELECT ', up);
  idxFrom   := Pos(' FROM ', up);
  idxWhere  := Pos(' WHERE ', up);
  idxGroup  := Pos(' GROUP BY ', up);
  idxHaving := Pos(' HAVING ', up);
  idxOrder  := Pos(' ORDER BY ', up);

  // SELECT … FROM arasını ayır
  Result.SelectList := Trim(
    Copy(SQL, idxSelect + 6, (idxFrom - idxSelect - 6))
  );

  // FROM … (WHERE|GROUP|ORDER|$) arasını al
  tmp := Copy(up, idxFrom + 6, MaxInt);
  // önceki keyword’leri en yakın olandan kır
  idxWhere  := IfThen(idxWhere>0, idxWhere - idxFrom - 5, 0);
  idxGroup  := IfThen(idxGroup>0, idxGroup - idxFrom - 5, 0);
  idxOrder  := IfThen(idxOrder>0, idxOrder - idxFrom - 5, 0);
  // en küçük pozisyonu seç
  idxWhere := IfThen((idxWhere>0) and ((idxWhere<idxGroup) or (idxGroup=0)), idxWhere, idxGroup);
  idxWhere := IfThen((idxWhere>0) and ((idxWhere<idxOrder) or (idxOrder=0)), idxWhere, idxOrder);

  if idxWhere>0 then
    Result.FromList := Trim(Copy(SQL, idxFrom + 6, idxWhere))
  else
    Result.FromList := Trim(Copy(SQL, idxFrom + 6, MaxInt));

  // WHERE kısmı
  if Pos(' WHERE ', up)>0 then
  begin
    idxWhere := Pos(' WHERE ', up);
    // WHERE’den sonra GROUP BY, ORDER BY veya sona kadar
    idxGroup := Pos(' GROUP BY ', up);
    idxOrder := Pos(' ORDER BY ', up);
    // en yakınını al
    idxFrom := IfThen((idxGroup>0) and ((idxGroup<idxOrder) or (idxOrder=0)), idxGroup, idxOrder);
    if idxFrom>0 then
      Result.WhereList := Trim(Copy(SQL, idxWhere + 6, idxFrom - idxWhere - 6))
    else
      Result.WhereList := Trim(Copy(SQL, idxWhere + 6, MaxInt));
  end;

  // GROUP BY kısmı
  if Pos(' GROUP BY ', up)>0 then
    Result.GroupList := Trim(
      Copy(SQL, Pos(' GROUP BY ', up)+9,
        IfThen(Pos(' HAVING ', up)>0, Pos(' HAVING ', up)-(Pos(' GROUP BY ', up)+9),
        IfThen(Pos(' ORDER BY ', up)>0, Pos(' ORDER BY ', up)-(Pos(' GROUP BY ', up)+9), MaxInt)))
    );

  // HAVING kısmı
  if Pos(' HAVING ', up)>0 then
    Result.HavingList := Trim(
      Copy(SQL, Pos(' HAVING ', up)+7,
        IfThen(Pos(' ORDER BY ', up)>0, Pos(' ORDER BY ', up)-(Pos(' HAVING ', up)+7), MaxInt))
    );

  // ORDER BY kısmı
  if Pos(' ORDER BY ', up)>0 then
    Result.OrderList := Trim(Copy(SQL, Pos(' ORDER BY ', up)+9, MaxInt));
end;


function SplitConditions(const Cond: string): TArray<string>;
begin
  // AND/OR’a göre böl: önce AND sonra OR
  Result := Cond.Split([' AND '], TStringSplitOptions.ExcludeEmpty)
    .FlatMap( c -> c.Split([' OR '], TStringSplitOptions.ExcludeEmpty) );
end;


///////////////////////////////////////////////

function CompareAlanDeger(const A, B: TTabloKayit; const Alan: string; Desc: Boolean): Integer;
var
  V1, V2: Variant;
begin

if not A.TryDegerAl(Alan, V1) then V1 := Null;
if not B.TryDegerAl(Alan, V2) then V2 := Null;
 if VarIsNull(V1) and not VarIsNull(V2) then    Exit(1)
else if not VarIsNull(V2) and VarIsNull(V1) then Exit(-1)
else if VarIsNull(V1) and VarIsNull(V2) then     Exit(0)
else
  Result := Integer(VarCompareValue(V1, V2));

  if Desc then Result := -Result;
end;
function StringListToArray(SL: TStringList):specialize TArray<string>;
var
  i: Integer;
begin
  SetLength(Result, SL.Count);
  for i := 0 to SL.Count - 1 do
    Result[i] := SL[i];
end;
constructor TTabloKayitMultiComparer.Create(const Alnlr:array of string;ADesc:
  Boolean; ASchema: TTabloSchema);
var
  i:Integer;
begin
// FAlanlar := Copy(Alanlar, 0, Length(Alanlar));
  //FAlanlar := Alnlr;
  SetLength(FAlanlar, Length(Alnlr));
  SetLength(FAlanTipleri, Length(Alnlr));

  for i := 0 to High(Alnlr) do
  begin
   FAlanlar[i] := Alnlr[i];

   if aSchema.VarMiAlan(FAlanlar[i]) then
      FAlanTipleri[i] := aSchema.AlanTipi(FAlanlar[i])
    else
      FAlanTipleri[i] := ftUnknown;

   //FAlanTipleri[i] :=ASchema.AlanTipi(Alnlr[i]);
   writeln('[DEBUG] Type: ', PTypeInfo(TypeInfo(FAlanTipleri[i]))^.Name);

   if Ord(FAlanTipleri[i]) <= Ord(High(TAlanTuru)) then
    writeln(GetEnumName(TypeInfo(TAlanTuru), Ord(FAlanTipleri[i])))
   else
    writeln('[HATA] Geçersiz enum değeri: ', Ord(FAlanTipleri[i]));


  end;

  FDesc := ADesc;
  // FAlanTipleri[i] := Alanlar[i].Tip; // ✅ enum atanıyor
end;

function CompareNumericValues(V1, V2: Variant): Integer;
var
  X, Y: Double;
begin
  X := StrToFloatDef(VarToStr(V1), 0);
  Y := StrToFloatDef(VarToStr(V2), 0);
  if X < Y then Exit(-1)
  else if X > Y then Exit(1)
  else Exit(0);
end;


function TTabloKayitMultiComparer.Compare(constref A,B:TTabloKayit):Integer;
var
  i, R: Integer;
  V1, V2: Variant;
  AlanTipi: TAlanTuru;
begin
  for i := 0 to High(FAlanlar) do
  begin
    if not A.TryDegerAl(FAlanlar[i], V1) then V1 := Null;
    if not B.TryDegerAl(FAlanlar[i], V2) then V2 := Null;

    if VarIsNull(V1) and not VarIsNull(V2) then Exit(1);
    if not VarIsNull(V1) and VarIsNull(V2) then Exit(-1);
    if VarIsNull(V1) and VarIsNull(V2) then Continue;




    case FAlanTipleri[i] of
      ftInteger, ftFloat:
        R := CompareNumericValues(V1, V2);
      ftText:
        R := CompareStr(VarToStr(V1), VarToStr(V2));
    else
      R := 0; // fallback
    end;

    if R <> 0 then
    begin
      if FDesc then R := -R;
      Exit(R);
    end;

   // AlanTipi := StrToAlanTuru(FAlanlar[i]);// A.Schema.Tipi(FAlanlar[i]);
    {AlanTipi :=FAlanTipleri[i];

   // writeln('^  ^  ',(AlanTipi));

   case AlanTipi of
      ftInteger:
      R := CompareValue(integer(VarAsType(V1, varInteger)), integer(VarAsType(V2, varInteger)));
      ftFloat:
        R := CompareValue(double(VarAsType(V1, varDouble)),Double(VarAsType(V2, varDouble)));
      ftText:
        R := CompareStr(VarToStr(V1), VarToStr(V2));
    else
      R := Integer(VarCompareValue(V1, V2)); // fallback
    end;  }

  // writeln('Compare: ', VarToStr(V1), ' vs ', VarToStr(V2), ' → R: ', R);
  //   writeln('[DEBUG] V1: ', VarToStr(V1), ' V2: ', VarToStr(V2));
   //  writeln('[DEBUG] AlanTipi: ', GetEnumName(TypeInfo(TAlanTuru), Integer(FAlanTipleri[i])));
 //    writeln('[DEBUG] AlanTipi: ',  Ord(FAlanTipleri[i]));
 //    writeln('[TIP]', Ord(FAlanTipleri[i]), ' - ', VarToStr(V1));
 //    writeln('[DEBUG] Karsilastirma Sonucu R: ', R);


   // R := Integer(VarCompareValue(V1, V2));
   // if R <> 0 then
   // begin
     // if FDesc then R := -R;
    //  Exit(R);
   // end;
  end;
  Result := 0;

end;



function SafeStrToFloat(const S: string): Double;
var
  FS: TFormatSettings;
  Clean: string;
begin
  FS := DefaultFormatSettings;
  FS.DecimalSeparator := '.';

  // Virgül varsa → noktaya çevir
  Clean := StringReplace(S, ',', '.', [rfReplaceAll]);

  try
    Result := StrToFloat(Clean, FS);
  except
    Result := 0.0; // fallback
  end;
end;
function TemizDeger(const S: string): string;
begin
  Result := S;
  if (Length(S) >= 2) and (S[1] = '''') and (S[Length(S)] = '''') then
    Result := Copy(S, 2, Length(S) - 2);
end;
function NormalizeSQL(const Source: string): string;
begin
  Result := StringReplace(Source, #13#10, ' ', [rfReplaceAll]);
  Result := StringReplace(Result, #10, ' ', [rfReplaceAll]);
  Result := StringReplace(Result, #13, ' ', [rfReplaceAll]);
end;
function TarihMi(const S: string): Boolean;
begin
  try
    StrToDate(S);
    Result := True;
  except
    Result := False;
  end;
end;
function ParseISODate(const S: string): TDateTime;
var
  FS: TFormatSettings;
begin
  FS.DateSeparator := '-';
  FS.ShortDateFormat := 'yyyy-mm-dd';
  Result := StrToDate(S, FS);
end;
function StrToDegerVariant(const S: string): Variant;
var
  FS: TFormatSettings;
  Clean: string;
  DT: TDateTime;
  A: Extended;
begin
  Clean := Trim(StringReplace(S, '''', '', [rfReplaceAll]));

  // ISO 'yyyy-mm-dd'
  FS.DateSeparator := '-';
  FS.ShortDateFormat := 'yyyy-mm-dd';
  if TryStrToDate(Clean, DT, FS) then
  begin
    Result := DT;
    Exit;
  end;

  // TR 'dd.mm.yyyy'
  FS.DateSeparator := '.';
  FS.ShortDateFormat := 'dd.mm.yyyy';
  if TryStrToDate(Clean, DT, FS) then
  begin
    Result := DT;
    Exit;
  end;

  // Sayı denemesi
  if TryStrToFloat(Clean, A, FS) then
  begin
    Result := A;
    Exit;
  end;

  // Geriye kalan her şey string
  Result := Clean;
end;
function Eslesir(const K: TTabloKayit; const Kosul: TFiltreKosulu): Boolean;
var
  DegerV: Variant;
  DegerStr, token: string;
  f1, f2: Double;
  f3: Extended;
  Liste: specialize TArray<string>;
  i: Integer;
  D1, D2,V: Variant;

begin
    if not K.TryDegerAl(Kosul.Alan, DegerV) then
    begin
      Exit(False);
    end;


  DegerStr := VarToStr(DegerV);

  case Kosul.Islem of
    opEqual:
      Result := SameText(DegerStr, Kosul.Deger);

    opNotEqual:
      Result := not SameText(DegerStr, Kosul.Deger);

    opGreater:
      Result := TryStrToFloat(DegerStr, f1) and
                TryStrToFloat(Kosul.Deger, f2) and
                (f1 > f2);

    opLess:
      Result := TryStrToFloat(DegerStr, f1) and
                TryStrToFloat(Kosul.Deger, f2) and
                (f1 < f2);

    opGreaterEqual:
      Result := TryStrToFloat(DegerStr, f1) and
                TryStrToFloat(Kosul.Deger, f2) and
                (f1 >= f2);

    opLessEqual:
      Result := TryStrToFloat(DegerStr, f1) and
                TryStrToFloat(Kosul.Deger, f2) and
                (f1 <= f2);

    opLike:
      Result := Pos(
        LowerCase(StringReplace(Kosul.Deger, '%', '', [rfReplaceAll])),
        LowerCase(DegerStr)
      ) > 0;

    opIn:
      begin
        Result := False;
        Liste := Kosul.Deger.Split([',']);
        for i := 0 to High(Liste) do
        begin
          token := Trim(Liste[i]);
          if (Length(token) >= 2) and (token[1] = '''') and (token[Length(token)] = '''') then
            token := Copy(token, 2, Length(token) - 2);

          if SameText(token, DegerStr) then
          begin
            Result := True;
            Exit;
          end;
        end;
      end;
    opBetween:
      begin

          V  := StrToDegerVariant(DegerStr);
          D1 := StrToDegerVariant(Kosul.Deger);
          D2 := StrToDegerVariant(Kosul.EkDeger);
          //Result := (V >= D1) and (V <= D2);

         // WriteLn(V,'  ',D1,'   ',D2);
          try
            if (VarType(V) = VarType(D1)) and (VarType(V) = VarType(D2)) then
              Result := (V >= D1) and (V <= D2)
            else
              Result := False;

          except
            Result := False;
          end;


      end;

    opIsNull:
    Result := VarIsNull(DegerV);
    opIsNotNull:
      Result := not VarIsNull(DegerV);
  else
    Result := False;
  end;
end;
function KokuEslesir(const K: TTabloKayit; const Node: TFiltreNode): Boolean;
var
  SonucSol, SonucSag: Boolean;
begin
  if Node.IsLeaf then
  begin
    Result := Eslesir(K, Node.Kosul);
    if Node.Mantik = loNot then
      Result := not Result;
    Exit;
  end;

  // Mantıksal bağlaçlar üzerinden sol-sağ dalları çöz
  case Node.Mantik of
    loAnd:
      begin
        if Assigned(Node.Sol) then SonucSol := KokuEslesir(K, Node.Sol^)
                              else SonucSol := True;

        if Assigned(Node.Sag) then SonucSag := KokuEslesir(K, Node.Sag^)
                              else SonucSag := True;

        Result := SonucSol and SonucSag;
      end;

    loOr:
      begin
        if Assigned(Node.Sol) then SonucSol := KokuEslesir(K, Node.Sol^)
                              else SonucSol := False;

        if Assigned(Node.Sag) then SonucSag := KokuEslesir(K, Node.Sag^)
                              else SonucSag := False;

        Result := SonucSol or SonucSag;
      end;

    loNot:
      begin
        if Assigned(Node.Sol) then Result := not KokuEslesir(K, Node.Sol^)
                              else Result := True;
      end;

  else
    Result := False;
  end;
end;
function KayitEslesir(const K: TTabloKayit; const Node: TFiltreNode): Boolean;
var
  SolSonuc, SagSonuc: Boolean;
begin
  if Node.IsLeaf then
  begin
    Result := Eslesir(K, Node.Kosul);
    if Node.Mantik = loNot then
      Result := not Result;
    Exit;
  end;

  case Node.Mantik of
    loAnd:
      begin
        SolSonuc := True;
        SagSonuc := True;

        if Assigned(Node.Sol) then SolSonuc := KayitEslesir(K, Node.Sol^);
        if Assigned(Node.Sag) then SagSonuc := KayitEslesir(K, Node.Sag^);

        Result := SolSonuc and SagSonuc;
      end;

    loOr:
      begin
        SolSonuc := False;
        SagSonuc := False;

        if Assigned(Node.Sol) then SolSonuc := KayitEslesir(K, Node.Sol^);
        if Assigned(Node.Sag) then SagSonuc := KayitEslesir(K, Node.Sag^);

        Result := SolSonuc or SagSonuc;
      end;

    loNot:
      begin
        if Assigned(Node.Sol) then
          Result := not KayitEslesir(K, Node.Sol^)
        else
          Result := True;
      end;

  else
    Result := False; // bilinmeyen mantık
  end;
end;
function ExtractTableName(const SQL: string; IntoPos, ValuesPos: SizeInt): string;
var
  RawSegment: string;
  ParenPos: Integer;
begin
  RawSegment := Trim(Copy(SQL, IntoPos, ValuesPos - IntoPos));
  ParenPos := Pos('(', RawSegment);
  if ParenPos > 0 then
    Result := Trim(Copy(RawSegment, 1, ParenPos - 1))
  else
    Result := RawSegment;
end;
procedure TamamlaEksikAlanlar(const Kayit: TTabloKayit; const Schema: TTabloSchema);
var
  i: Integer;
  Alan: TAlanTanimi;
begin
  for i := 0 to High(Schema.Alanlar) do
  begin
    Alan := Schema.Alanlar[i];
    if not Kayit.Varmi(Alan.Name) then
    begin
      // Varsayılan değer atama
      case Alan.Tip of
        ftInteger, ftAutoIncrement: Kayit.DegerAta(Alan.Name, 0);
        ftFloat, ftCurrency:        Kayit.DegerAta(Alan.Name, 0.0);
        ftBoolean:                  Kayit.DegerAta(Alan.Name, False);
        ftDate, ftTime, ftTimestamp:
                                    Kayit.DegerAta(Alan.Name, Int64(0));
      else
        Kayit.DegerAta(Alan.Name, '');
      end;
     end;
  end;
end;
constructor TSqlEngine.Create(AVeritabani: TVeritabani);

begin
  inherited Create;
  FVeritabani := AVeritabani;
end;
procedure TSqlEngine.SerbestFiltre(Node: PFiltreNode);
begin
  if Node = nil then Exit;

  if not Node^.IsLeaf then
  begin
    SerbestFiltre(Node^.Sol);
    SerbestFiltre(Node^.Sag);
  end;

  Dispose(Node);
end;
function TryParseAnyDate(const S: string; out DT: TDateTime): Boolean;
var
  FS: TFormatSettings;
begin
  FS := DefaultFormatSettings;

  // ISO yyyy-mm-dd
  FS.DateSeparator := '-';
  FS.ShortDateFormat := 'yyyy-mm-dd';
  if TryStrToDate(S, DT, FS) then Exit(True);

  // TR dd.mm.yyyy
  FS.DateSeparator := '.';
  FS.ShortDateFormat := 'dd.mm.yyyy';
  if TryStrToDate(S, DT, FS) then Exit(True);

  Result := False;
end;
function ParseDegerTipli(Tip: TAlanTuru; const DegerStr: string): Variant;
var
  Clean: string;
  DT: TDateTime;
  F: Extended;
 // FS: TFormatSettings;
begin
//  FS:=DefaultFormatSettings;
 // FS := FormatSettingsForDate;
  Clean := Trim(StringReplace(DegerStr, '''', '', [rfReplaceAll]));

  case Tip of
    ftDate:
      begin
        if not TryParseAnyDate(Clean, DT) then
          raise Exception.CreateFmt('Tarih değeri geçersiz: %s', [DegerStr]);
        Result := DT;
      end;

    ftFloat:
      begin
        if not TryStrToFloat(Clean, F) then
          raise Exception.CreateFmt('Sayısal değer geçersiz: %s', [DegerStr]);
        Result := F;
      end;

  else
    Result := Clean;
  end;
end;
function ParseWhereMantiksal(const S: string): TFiltreNode;

  function TrimOuterParens(const Str: string): string;
  begin
    Result := Trim(Str);
    if (LeftStr(Result, 1) = '(') and (RightStr(Result, 1) = ')') then
      Result := Copy(Result, 2, Length(Result) - 2);
  end;

  function ParseKosul(const S: string): TFiltreNode;
var
  K: TFiltreKosulu;
  eq: Integer;
  Alan, Deger, OpStr: string;
  iAnd: Integer;
  EkDeger, temp: string;
  iKes: SizeInt;

begin
  // İşlem türünü belirle (öncelik sırasıyla)
  if Pos('>=', S) > 0 then
    OpStr := '>='
  else if Pos('<=', S) > 0 then
    OpStr := '<='
  else if Pos('!=', S) > 0 then
    OpStr := '!='
  else if Pos('<>', S) > 0 then
    OpStr := '!='
  else if Pos('LIKE', UpperCase(S)) > 0 then
    OpStr := 'LIKE'
  else if Pos('IN', UpperCase(S)) > 0 then
    OpStr := 'IN'
  else if Pos('IS NULL', UpperCase(S)) > 0 then
    OpStr := 'IS NULL'
  else if Pos('IS NOT NULL', UpperCase(S)) > 0 then
    OpStr := 'IS NOT NULL'
  else if Pos('BETWEEN', UpperCase(S)) > 0 then
    OpStr := 'BETWEEN'
  else if Pos('NOT', UpperCase(S)) > 0 then
    OpStr := 'NOT'
  else if Pos('=', S) > 0 then
    OpStr := '='
  else if Pos('>', S) > 0 then
    OpStr := '>'
  else if Pos('<', S) > 0 then
    OpStr := '<'
  else
    OpStr := '='; // Varsayılan işlem

  // İşlem konumunu bul
  eq := Pos(OpStr, UpperCase(S));

  // Alan ve değer ayrıştır
  Alan := Trim(Copy(S, 1, eq - 1));
  Deger := Trim(Copy(S, eq + Length(OpStr), MaxInt));

  // Tırnakları temizle
  if (LeftStr(Deger, 1) = '''') and (RightStr(Deger, 1) = '''') then
    Deger := Copy(Deger, 2, Length(Deger) - 2);

  // Koşulu doldur
  K.Alan := Alan;
  K.Deger := Deger;

  case OpStr of
    '='   : K.Islem := opEqual;
    '!='  : K.Islem := opNotEqual;
    '<>'  : K.Islem := opNotEqual;
    '>'   : K.Islem := opGreater;
    '<'   : K.Islem := opLess;
    '>='  : K.Islem := opGreaterEqual;
    '<='  : K.Islem := opLessEqual;
    'LIKE': K.Islem := opLike;
    'IN'  : K.Islem := opIn;
    'IS NULL' : K.Islem := opIsNull;
    'IS NOT NULL' : K.Islem := opIsNotNull;
    'BETWEEN':
        begin
          eq := Pos('BETWEEN', UpperCase(S));
          if eq = 0 then
            raise Exception.Create('BETWEEN ifadesi bulunamadı.');

          // Arka kısmı al: '2025-07-01' AND '2025-07-10' ...
          temp := Trim(Copy(S, eq + Length('BETWEEN'), Length(S)));

          // GROUP BY, ORDER BY, LIMIT varsa kırp
          iKes := Length(temp) + 1;
          if Pos('GROUP BY', UpperCase(temp)) > 0 then
            iKes := Pos('GROUP BY', UpperCase(temp));
          if Pos('ORDER BY', UpperCase(temp)) > 0 then
            iKes := Min(iKes, Pos('ORDER BY', UpperCase(temp)));
          if Pos('LIMIT', UpperCase(temp)) > 0 then
            iKes := Min(iKes, Pos('LIMIT', UpperCase(temp)));

          temp := Trim(Copy(temp, 1, iKes - 1)); // 👉 Artık sadece BETWEEN içeriği kaldı!

          iAnd := Pos('AND', UpperCase(temp));
          if iAnd = 0 then
            raise Exception.Create('BETWEEN ifadesinde AND eksik: ' + temp);

          Alan := Trim(Copy(S, 1, eq - 1));
          Deger := Trim(Copy(temp, 1, iAnd - 1));
          EkDeger := Trim(Copy(temp, iAnd + Length('AND'), MaxInt));

          K.Alan := Alan;
          K.Islem := opBetween;
          K.Deger := Deger;
          K.EkDeger := EkDeger;
        end;
  else
    K.Islem := opEqual;
  end;

  K.Mantik := loAnd; // Şimdilik varsayılan mantık

  // Sonuç düğümünü oluştur
  Result.IsLeaf := True;
  Result.Kosul := K;
end;

var
  P: string;
  i: Integer;
  Parens: Integer;
begin
  P := TrimOuterParens(S);
  Parens := 0;

  for i := 1 to Length(P) do
  begin
    if P[i] = '(' then Inc(Parens)
    else if P[i] = ')' then Dec(Parens)
    else if (Parens = 0) and (UpperCase(Copy(P, i, 3)) = 'AND') and
   (Pos('BETWEEN', UpperCase(P)) = 0) then
    begin
      Result.IsLeaf := False;
      Result.Mantik := loAnd;
      New(Result.Sol);
      New(Result.Sag);
      Result.Sol^ := ParseWhereMantiksal(Copy(P, 1, i - 1));
      Result.Sag^ := ParseWhereMantiksal(Copy(P, i + 3, MaxInt));
      Exit;
    end
    else if (Parens = 0) and (UpperCase(Copy(P, i, 2)) = 'OR') then
    begin
      Result.IsLeaf := False;
      Result.Mantik := loOr;
      New(Result.Sol);
      New(Result.Sag);
      Result.Sol^ := ParseWhereMantiksal(Copy(P, 1, i - 1));
      Result.Sag^ := ParseWhereMantiksal(Copy(P, i + 2, MaxInt));
      Exit;
    end
    else if (Parens = 0) and (UpperCase(Copy(P, i, 3)) = 'NOT') then
    begin
      Result.IsLeaf := False;
      Result.Mantik := loNot;
      New(Result.Sol);
      Result.Sol^ := ParseWhereMantiksal(Copy(P, i + 3, MaxInt));
      Result.Sag := nil;
      Exit;
    end;

  end;

  Result := ParseKosul(P); // Eğer bağlaç yoksa → tek filtre
end;
function ParseWhereKosullari(const WhereStr: string): specialize TArray<TFiltreKosulu>;
var
  Kosullar: TStringList;
  i, eq: Integer;
  Parca, AlanAd, IslemStr, DegerStr: string;
begin
  Kosullar := TStringList.Create;
  try
    ExtractStrings([','], [], PChar(WhereStr), Kosullar); // virgül ile ayır → örnek: Puan >= 80, Ad = 'Onur'
    SetLength(Result, Kosullar.Count);

    for i := 0 to Kosullar.Count - 1 do
    begin
      Parca := Trim(Kosullar[i]);

      // İşlem türünü bul
      if Pos('>=', Parca) > 0 then IslemStr := '>='
      else if Pos('<=', Parca) > 0 then IslemStr := '<='
      else if Pos('<>', Parca) > 0 then IslemStr := '!='
      else if Pos('!=', Parca) > 0 then IslemStr := '!='
      else if Pos('=', Parca) > 0 then IslemStr := '='
      else if Pos('>', Parca) > 0 then IslemStr := '>'
      else if Pos('<', Parca) > 0 then IslemStr := '<'
      else if Pos('LIKE', UpperCase(Parca)) > 0 then IslemStr := 'LIKE'
      else IslemStr := '=';

      // Alan adı ve değer ayır
      eq := Pos(IslemStr, Parca);
      AlanAd := Trim(Copy(Parca, 1, eq - 1));
      DegerStr := Trim(Copy(Parca, eq + Length(IslemStr), MaxInt));

      // Tırnakları sil
      if (LeftStr(DegerStr, 1) = '''') and (RightStr(DegerStr, 1) = '''') then
        DegerStr := Copy(DegerStr, 2, Length(DegerStr) - 2);

      Result[i].Alan := AlanAd;
      Result[i].Deger := DegerStr;

      case IslemStr of
        '='  : Result[i].Islem := opEqual;
        '!=' : Result[i].Islem := opNotEqual;
        '<>' : Result[i].Islem := opNotEqual;
        '>'  : Result[i].Islem := opGreater;
        '<'  : Result[i].Islem := opLess;
        '>=' : Result[i].Islem := opGreaterEqual;
        '<=' : Result[i].Islem := opLessEqual;
        'LIKE': Result[i].Islem := opLike;
      else
        Result[i].Islem := opEqual;
      end;

      Result[i].Mantik := loAnd; // şimdilik varsayılan mantık operatörü
    end;
  finally
    Kosullar.Free;
  end;
end;
function ParseCreateTableKomut(
  const SQL: string;
  out TabloAdi: string;
  out Alanlar: specialize TArray<TAlanTanimi>
): Boolean;
var
  S, Satir, Kelime, DegerStr, ParTip: string;
  ParantezBasla, ParantezBit: Integer;
  AlanListesi, Kelimeler, AltKelimeler, KolonParc: TStringList;
  i, j, DefIdx: Integer;
  A: TAlanTanimi;
begin
  Result := False;
  TabloAdi := '';
  SetLength(Alanlar, 0);

  // 1) Temel CREATE TABLE kontrolü
  S := Trim(StringReplace(SQL, ';', '', [rfReplaceAll]));
  if Pos('CREATE TABLE ', UpperCase(S)) <> 1 then
    Exit;

  // 2) Parantez içini çıkar
  ParantezBasla := Pos('(', S);
  ParantezBit   := LastDelimiter(')', S);
  if (ParantezBasla = 0) or (ParantezBit <= ParantezBasla) then
    Exit;

  TabloAdi := Trim(Copy(S, 13, ParantezBasla - 13));

  // 3) Virgülle ayrılmış satırları al
  AlanListesi := TStringList.Create;
  try
    ExtractStrings([','], [], PChar(
      Copy(S, ParantezBasla + 1, ParantezBit - ParantezBasla - 1)
    ), AlanListesi);

    // 4) Boş veya tamamen numerik olan satırları sil
    for i := AlanListesi.Count - 1 downto 0 do
    begin
      Satir := Trim(AlanListesi[i]);
      if (Satir = '') or TryStrToInt(Satir, j) then
        AlanListesi.Delete(i);
    end;
    DebugLog('[DEBUG] AlanListesi: ' + AlanListesi.CommaText);

    // 5) Her sütun satırını parse et
    AlanListesi.BeginUpdate;
    try
      for i := 0 to AlanListesi.Count - 1 do
      begin
        Satir := Trim(AlanListesi[i]);
        if Satir = '' then
          Continue;

        // 5a) Tokenize
        Kelimeler := TStringList.Create;
        try
          ExtractStrings([' '], [], PChar(Satir), Kelimeler);
          if Kelimeler.Count < 2 then
          begin
            DebugLog('[UYARI] Alan tanımı yetersiz → ' + Satir);
            Continue;
          end;

          // 5b) Ad ve tip/parantezli tip ayrıştır
          A := Default(TAlanTanimi);
          A.Name := Kelimeler[0];
          // VARCHAR(n) gibi parantezli tip
          if Pos('(', Kelimeler[1]) > 0 then
          begin
            ParTip := StringReplace(Kelimeler[1], ')', '', []);
            ParTip := StringReplace(ParTip, '(', ' ', []);
            AltKelimeler := TStringList.Create;
            try
              ExtractStrings([' '], [], PChar(ParTip), AltKelimeler);
              if AltKelimeler.Count = 2 then
              begin
                Kelimeler[1] := AltKelimeler[0];
                Kelimeler.Insert(2, AltKelimeler[1]);
              end;
            finally
              AltKelimeler.Free;
            end;
          end;
          // Tip enum’a çevir
          A.Tip := StrToAlanTuru(UpperCase(Kelimeler[1]));
          // Uzunluk metinsel tipler için 0 gelmişse default ata
          A.Length := 0;
          // İleride, tip bazlı length setlenebilir

          // 5c) Diğer flag’ler
          for j := 1 to Kelimeler.Count - 1 do
          begin
            Kelime := UpperCase(Kelimeler[j]);
            // Uzunluk var mı?
            if TryStrToInt(Kelimeler[j], A.Length) then
            begin
              if A.Length > 1000 then
                A.Length := 255;
            end;
            // PRIMARY KEY
            if (Kelime = 'PRIMARY') and
               (j < Kelimeler.Count - 1) and
               (UpperCase(Kelimeler[j + 1]) = 'KEY') then
              A.PrimaryKey := True;
            // AUTOINCREMENT
            if (Kelime = 'AUTOINCREMENT') and (A.Tip = ftInteger) then
              A.AutoIncrement := True;
            // NOT NULL
            if (Kelime = 'NOT') and
               (j < Kelimeler.Count - 1) and
               (UpperCase(Kelimeler[j + 1]) = 'NULL') then
              A.NotNull := True;
            // DEFAULT
            if Kelime = 'DEFAULT' then
            begin
              if j < Kelimeler.Count - 1 then
              begin
                DegerStr := Kelimeler[j + 1];
                // tırnaklıysa temizle
                if (Length(DegerStr) >= 2) and
                   (DegerStr[1] = '''') and
                   (DegerStr[Length(DegerStr)] = '''') then
                  DegerStr := Copy(DegerStr, 2, Length(DegerStr) - 2);
                try
                  A.DefaultDeger := ParseDegerTipli(A.Tip, DegerStr);
                except
                  A.DefaultDeger := DegerStr;
                end;
              end;
            end;
          end;

          // 5d) Eksik tip/uzunluk düzeltmeleri
          if A.Tip = ftUnknown then
          begin
            DebugLog('[UYARI] Tip bulunamadı, ftText atanıyor → ' + A.Name);
            A.Tip := ftText;
          end;
          if (A.Tip = ftText) and (A.Length = 0) then
            A.Length := 255;

          // 5e) NOT NULL ama DEFAULT yoksa sistem dolgu
          if A.NotNull and VarIsEmpty(A.DefaultDeger) then
          begin
            case A.Tip of
              ftText:    A.DefaultDeger := '';
              ftInteger: A.DefaultDeger := 0;
              ftFloat:   A.DefaultDeger := 0.0;
              ftBoolean: A.DefaultDeger := False;
              ftDate:    A.DefaultDeger := Date;
            end;
          end;

          // 5f) Diziye ekle
          SetLength(Alanlar, Length(Alanlar) + 1);
          Alanlar[High(Alanlar)] := A;

        finally
          Kelimeler.Free;
        end;
      end;
    finally
      AlanListesi.EndUpdate;
    end;

    Result := True;
  finally
    AlanListesi.Free;
  end;
end;

{
function ParseCreateTableKomut(const SQL: string;
  out TabloAdi: string;
  out Alanlar: specialize TArray<TAlanTanimi>): Boolean;
var
  S, Satir, Kelime, DegerStr, ParTip: string;
  ParantezBasla, ParantezBit: Integer;
  AlanListesi, Kelimeler, AltKelimeler: TStringList;
  i, j: Integer;
  Alan: TAlanTanimi;
  KolonParc: TStringList;
  DefIdx: Integer;

begin
  Result := False;
  S := Trim(StringReplace(SQL, ';', '', [rfReplaceAll]));




  if Pos('CREATE TABLE ', UpperCase(S)) <> 1 then Exit;

  ParantezBasla := Pos('(', S);
  ParantezBit := Length(S);
  while (ParantezBit > 0) and (S[ParantezBit] <> ')') do Dec(ParantezBit);
  if (ParantezBasla = 0) or (ParantezBit <= ParantezBasla) then Exit;

  TabloAdi := Trim(Copy(S, 13, ParantezBasla - 13));
  AlanListesi := TStringList.Create;
  try
    ExtractStrings([','], [], PChar(Copy(S, ParantezBasla + 1, ParantezBit - ParantezBasla - 1)), AlanListesi);



    AlanListesi.BeginUpdate;

    for i := 0 to AlanListesi.Count - 1 do
     //for i := AlanListesi.Count - 1 downto 0 do

    begin
      Alan := Default(TAlanTanimi);
      Satir := Trim(AlanListesi[i]);

      Kelimeler := TStringList.Create;
      try
        ExtractStrings([' '], [], PChar(Satir), Kelimeler);



        if Kelimeler.Count < 2 then
        begin
          writeln('[UYARI] Alan tanımı yetersiz → ' + Satir);
          Continue;
        end;

        Alan.Name := Kelimeler[0];

        // VARCHAR(n) gibi tip-parantezli yapı
        if Pos('(', Kelimeler[1]) > 0 then
        begin
          ParTip := StringReplace(Kelimeler[1], ')', '', []);
          ParTip := StringReplace(ParTip, '(', ' ', []);
          AltKelimeler := TStringList.Create;
          try
            ExtractStrings([' '], [], PChar(ParTip), AltKelimeler);
            if AltKelimeler.Count = 2 then
            begin
              Kelimeler[1] := AltKelimeler[0];
              Kelimeler.Insert(2, AltKelimeler[1]); // Uzunluk
            end;
          finally
            AltKelimeler.Free;
          end;
        end;

        for j := 1 to Kelimeler.Count - 1 do
        begin
          Kelime := UpperCase(Kelimeler[j]);

          // Tip belirleme
          if Kelime = 'VARCHAR' then Alan.Tip := ftText
          else if Kelime = 'TEXT' then Alan.Tip := ftText
          else if Kelime = 'STRING' then Alan.Tip := ftText
          else if Kelime = 'INTEGER' then Alan.Tip := ftInteger
          else if Kelime = 'DOUBLE' then Alan.Tip := ftFloat
          else if Kelime = 'DATE' then Alan.Tip := ftDate
          else if Kelime = 'UUID' then Alan.Tip := ftUUID
          else if Kelime = 'BLOB' then Alan.Tip := ftBlob
          else if Kelime = 'BOOLEAN' then Alan.Tip := ftBoolean
          else if Kelime = 'AUTOINCREMENT' then
            if Alan.Tip = ftInteger then Alan.AutoIncrement := True;

          // Uzunluk
          if TryStrToInt(Kelimeler[j], Alan.Length) then
          begin
            if Alan.Length > 1000 then Alan.Length := 255;
          end;

          // PRIMARY KEY
          if (Kelime = 'PRIMARY') and (j < Kelimeler.Count - 1) and (UpperCase(Kelimeler[j + 1]) = 'KEY') then
            Alan.PrimaryKey := True;

          // NOT NULL
          if (Kelime = 'NOT') and (j < Kelimeler.Count - 1) and (UpperCase(Kelimeler[j + 1]) = 'NULL') then
            Alan.NotNull := True;

          // DEFAULT
          if Kelime = 'DEFAULT' then
          begin
            if j < Kelimeler.Count - 1 then
            begin
              DegerStr := Kelimeler[j + 1];
              if (Length(DegerStr) >= 2) and (DegerStr[1] = '''') and (DegerStr[Length(DegerStr)] = '''') then
                DegerStr := Copy(DegerStr, 2, Length(DegerStr) - 2);
              try
                Alan.DefaultDeger := ParseDegerTipli(Alan.Tip, DegerStr);
              except
                Alan.DefaultDeger := DegerStr;
              end;
            end;
          end;
        end;

        // Eksik tip → varsayılan
        if Alan.Tip = ftUnknown then
        begin
          DebugLog('[UYARI] Tip bulunamadı, ftText atanıyor → ' + Alan.Name);
          Alan.Tip := ftText;
        end;

        // Eksik uzunluk
        if (Alan.Tip = ftText) and (Alan.Length = 0) then Alan.Length := 255;

        // NOT NULL ama DEFAULT yoksa sistem dolgu ataması
        if Alan.NotNull and (VarIsEmpty(Alan.DefaultDeger) or VarIsNull(Alan.DefaultDeger) or (Trim(VarToStr(Alan.DefaultDeger)) = '')) then
          case Alan.Tip of
            ftText: Alan.DefaultDeger := '';
            ftInteger: Alan.DefaultDeger := 0;
            ftFloat: Alan.DefaultDeger := 0.0;
            ftBoolean: Alan.DefaultDeger := False;
            ftDate: Alan.DefaultDeger := Date;
          end;

        SetLength(Alanlar, Length(Alanlar) + 1);
        Alanlar[High(Alanlar)] := Alan;
      finally
        Kelimeler.Free;
      end;
    end;
    AlanListesi.EndUpdate;

    Result := True;
  finally
    AlanListesi.Free;
  end;
end;
}



function ParseDeleteKomut(const SQL: string): TSqlKomut;
  function ExtractTokens(const S: string): TStringArray;
  begin
    Result := S.Split([' '], TStringSplitOptions.ExcludeEmpty);
  end;
  function JoinStrings(const Arr: TStringArray; FromIndex, ToIndex: Integer): string;
  var
    i: Integer;
  begin
    Result := '';
    for i := FromIndex to ToIndex - 1 do
      Result := Result + Arr[i] + ' ';
    Result := TrimRight(Result);
  end;
var
  Temiz: string;
  Parca: TStringArray;
  i: Integer;
begin
  Temiz := Trim(SQL);

  // Sadece DELETE FROM destekleniyor
  if not StartsText('DELETE FROM', UpperCase(Temiz)) then
    raise Exception.Create('DELETE komutu geçersiz.');

  // Komutu parçalara ayır
  Parca := ExtractTokens(Temiz); // Yardımcı fonksiyon: kelimeleri ayır

  Result := Default(TSqlKomut);
  Result.SorguTipi := skDelete;// 'DELETE';

  // FROM sonrası tablo adı
  i := 2;
  if i >= Length(Parca) then
    raise Exception.Create('Tablo adı eksik.');

  Result.Tablo := Parca[i];

  // WHERE varsa
  Inc(i);
  if (i < Length(Parca)) and (UpperCase(Parca[i]) = 'WHERE') then
  begin
    Inc(i);
    Temiz := JoinStrings(Parca, i, Length(Parca)); // WHERE sonrası stringi birleştir
    New(Result.FiltreKoku);
    Result.FiltreKoku^ := ParseWhereMantiksal(Temiz);
  end;
end;
{
function ParseSelectKomut(const SQL: string): TSqlKomut;
var
  S: string;
  iGroup,iFrom, iWhere, iOrder, iLimit: Integer;
  AlanParca, TabloParca, WhereParca, OrderParca, LimitParca: string;
  TempList: TStringList;
  i: Integer;
  AlanAd, Takma: String;
  SonPoz: SizeInt;
  iJoin, iOn: Integer;
  AnaParca, JoinParca, Kosul: string;
  GroupParca: string;
begin
  FillChar(Result, SizeOf(Result), 0);
  Result.SorguTipi := skSelect;
  Result.Limit := -1;

  S := Trim(SQL);
  S := StringReplace(S, ';', '', [rfReplaceAll]);
  S := StringReplace(S, #13#10, ' ', [rfReplaceAll]);
  while Pos('  ', S) > 0 do
    S := StringReplace(S, '  ', ' ', [rfReplaceAll]);

  // Anahtar kelimelerin pozisyonlarını bul
  iFrom  := Pos(' FROM ', UpperCase(S));
  iWhere := Pos(' WHERE ', UpperCase(S));
  iOrder := Pos(' ORDER BY ', UpperCase(S));
  iLimit := Pos(' LIMIT ', UpperCase(S));
  iJoin  := Pos('JOIN ', UpperCase(S));
  iOn    := Pos(' ON ', UpperCase(S));
  iGroup := Pos('GROUP BY', UpperCase(S));

  // Alanları ayır
  AlanParca := Trim(Copy(S, Length('SELECT') + 1, iFrom - Length('SELECT') - 1));

  TempList := TStringList.Create;
  try
    ExtractStrings([','], [], PChar(AlanParca), TempList);
    SetLength(Result.Alanlar, TempList.Count);
    for i := 0 to TempList.Count - 1 do
    begin
      AlanAd := TempList[i];
      Takma := '';

      if Pos(' AS ', UpperCase(AlanAd)) > 0 then
      begin
        Takma := Trim(Copy(AlanAd, Pos(' AS ', UpperCase(AlanAd)) + 4, MaxInt));
        AlanAd := Trim(Copy(AlanAd, 1, Pos(' AS ', UpperCase(AlanAd)) - 1));
      end;

      Result.Alanlar[i].Alan := Trim(AlanAd);
      Result.Alanlar[i].TakmaIsim := Trim(Takma);
    end;
  finally
    TempList.Free;
  end;

  // Tablo adını ayır
  if iWhere > 0 then
    TabloParca := Trim(Copy(S, iFrom + 6, iWhere - iFrom - 6))
  else if iOrder > 0 then
    TabloParca := Trim(Copy(S, iFrom + 6, iOrder - iFrom - 6))
  else if iLimit > 0 then
    TabloParca := Trim(Copy(S, iFrom + 6, iLimit - iFrom - 6))
  else
    TabloParca := Trim(Copy(S, iFrom + 6, Length(S) - iFrom - 5));



  Result.Tablo := TabloParca;

  // WHERE filtresi varsa → FiltreKoku’yu oluştur
  if iWhere > 0 then
  begin
    SonPoz := Length(S) + 1;
    if iOrder > iWhere then SonPoz := iOrder;
    if iLimit > iWhere then SonPoz := iLimit;



    WhereParca := Trim(Copy(S, iWhere + 7, SonPoz - iWhere - 7));

    New(Result.FiltreKoku);
    Result.FiltreKoku^ := ParseWhereMantiksal(WhereParca);
  end;


   if iGroup > 0 then
  begin
    GroupParca := Trim(Copy(S, iGroup + Length('GROUP BY'), Length(S)));
    Result.GroupByAlan := GroupParca;

    // Gerekiyorsa ORDER/LIMIT'ten önce kes
    if Pos('ORDER BY', UpperCase(GroupParca)) > 0 then
      Result.GroupByAlan := Trim(Copy(GroupParca, 1, Pos('ORDER BY', UpperCase(GroupParca)) - 1));
  end;

  // ORDER BY varsa ayır
  if iOrder > 0 then
  begin
    OrderParca := Trim(Copy(S, iOrder + 10,
      IfThen(iLimit > iOrder, iLimit, Length(S) + 1) - iOrder - 10));

    Result.OrderDesc := EndsText(' DESC', UpperCase(OrderParca));
    if Result.OrderDesc then
      OrderParca := Trim(Copy(OrderParca, 1, Length(OrderParca) - 5));

    Result.OrderBy := OrderParca;
  end;

  // LIMIT varsa ayır
  if iLimit > 0 then
  begin
    LimitParca := Trim(Copy(S, iLimit + 6, Length(S)));
    TryStrToInt(LimitParca, Result.Limit);
  end;

  if (iJoin > 0) and (iOn > iJoin) then
  begin
    AnaParca := Trim(Copy(S, iFrom + 6, iJoin - iFrom - 6));
    Result.AnaTablo := ExtractWord(1, AnaParca, [' ']);
    Result.AnaAlias := ExtractWord(2, AnaParca, [' ']);
    if Result.AnaAlias = '' then Result.AnaAlias := Result.AnaTablo;

    JoinParca := Trim(Copy(S, iJoin + 5, iOn - iJoin - 5));
    Result.JoinTablo := ExtractWord(1, JoinParca, [' ']);
    Result.JoinAlias := ExtractWord(2, JoinParca, [' ']);
    if Result.JoinAlias = '' then Result.JoinAlias := Result.JoinTablo;

    Kosul := Trim(Copy(S, iOn + 4, MaxInt));
    Kosul := StringReplace(Kosul, '=', '|', []);
    Result.JoinKosulSol := Trim(ExtractWord(1, Kosul, ['|']));
    Result.JoinKosulSag := Trim(ExtractWord(2, Kosul, ['|']));
  end;

end;
}


function ParseSelectKomut(const SQL: string): TSqlKomut;
var
  S: string;
  iFrom, iWhere, iOrder, iLimit, iJoin, iOn, iGroup, iHaving: Integer;
  AlanParca, TabloParca, WhereParca, OrderParca, LimitParca: string;
  GroupParca, HavingParca: string;
  TempList: TStringList;
  i: Integer;
  AlanAd, Takma: String;
  SonPoz: SizeInt;
  AnaParca, JoinParca, Kosul: string;
begin
  FillChar(Result, SizeOf(Result), 0);
  Result.SorguTipi := skSelect;
  Result.Limit := -1;

  S := Trim(SQL);
  S := StringReplace(S, ';', '', [rfReplaceAll]);
  S := StringReplace(S, #13#10, ' ', [rfReplaceAll]);
  while Pos('  ', S) > 0 do
    S := StringReplace(S, '  ', ' ', [rfReplaceAll]);

  // Anahtar pozisyonlar
  iFrom   := Pos(' FROM ', UpperCase(S));
  iWhere  := Pos(' WHERE ', UpperCase(S));
  iOrder  := Pos(' ORDER BY ', UpperCase(S));
  iLimit  := Pos(' LIMIT ', UpperCase(S));
  iJoin   := Pos(' JOIN ', UpperCase(S));
  iOn     := Pos(' ON ', UpperCase(S));
  iGroup  := Pos(' GROUP BY ', UpperCase(S));
  iHaving := Pos(' HAVING ', UpperCase(S));

  // Alanlar
  AlanParca := Trim(Copy(S, Length('SELECT') + 1, iFrom - Length('SELECT') - 1));
  TempList := TStringList.Create;
  try
    ExtractStrings([','], [], PChar(AlanParca), TempList);
    SetLength(Result.Alanlar, TempList.Count);
    for i := 0 to TempList.Count - 1 do
    begin
      AlanAd := TempList[i];
      Takma := '';
      if Pos(' AS ', UpperCase(AlanAd)) > 0 then
      begin
        Takma := Trim(Copy(AlanAd, Pos(' AS ', UpperCase(AlanAd)) + 4, MaxInt));
        AlanAd := Trim(Copy(AlanAd, 1, Pos(' AS ', UpperCase(AlanAd)) - 1));
      end;

      Result.Alanlar[i].Alan := Trim(AlanAd);
      Result.Alanlar[i].TakmaIsim := Trim(Takma);
    end;
  finally
    TempList.Free;
  end;

  // JOIN varsa → özel çözüm
  if (iJoin > 0) and (iOn > iJoin) then
  begin
    AnaParca := Trim(Copy(S, iFrom + 6, iJoin - iFrom - 6));
    Result.AnaTablo := ExtractWord(1, AnaParca, [' ']);
    Result.AnaAlias := ExtractWord(2, AnaParca, [' ']);
    if Result.AnaAlias = '' then Result.AnaAlias := Result.AnaTablo;

    JoinParca := Trim(Copy(S, iJoin + 5, iOn - iJoin - 5));
    Result.JoinTablo := ExtractWord(1, JoinParca, [' ']);
    Result.JoinAlias := ExtractWord(2, JoinParca, [' ']);
    if Result.JoinAlias = '' then Result.JoinAlias := Result.JoinTablo;

    Kosul := Trim(Copy(S, iOn + 4, MaxInt));
    Kosul := StringReplace(Kosul, '=', '|', []);
    Result.JoinKosulSol := Trim(ExtractWord(1, Kosul, ['|']));
    Result.JoinKosulSag := Trim(ExtractWord(2, Kosul, ['|']));
  end
  else
  begin
    // JOIN yoksa → klasik tablo çözümü
    if iWhere > 0 then
      TabloParca := Trim(Copy(S, iFrom + 6, iWhere - iFrom - 6))
    else if iOrder > 0 then
      TabloParca := Trim(Copy(S, iFrom + 6, iOrder - iFrom - 6))
    else if iGroup > 0 then
      TabloParca := Trim(Copy(S, iFrom + 6, iGroup - iFrom - 6))
    else if iLimit > 0 then
      TabloParca := Trim(Copy(S, iFrom + 6, iLimit - iFrom - 6))
    else
      TabloParca := Trim(Copy(S, iFrom + 6, Length(S) - iFrom - 5));

    Result.Tablo := TabloParca;
  end;

  // WHERE filtresi
  if iWhere > 0 then
  begin
    SonPoz := Length(S) + 1;
    if iOrder > iWhere then SonPoz := iOrder;
    if iGroup > iWhere then SonPoz := iGroup;
    if iLimit > iWhere then SonPoz := iLimit;
    WhereParca := Trim(Copy(S, iWhere + 7, SonPoz - iWhere - 7));
    New(Result.FiltreKoku);
    Result.FiltreKoku^ := ParseWhereMantiksal(WhereParca);
  end;

  // ORDER BY
  if iOrder > 0 then
  begin
    OrderParca := Trim(Copy(S, iOrder + 10,
      IfThen(iLimit > iOrder, iLimit, Length(S) + 1) - iOrder - 10));
    Result.OrderDesc := EndsText(' DESC', UpperCase(OrderParca));
    if Result.OrderDesc then
      OrderParca := Trim(Copy(OrderParca, 1, Length(OrderParca) - 5))
    else if EndsText(' ASC', UpperCase(OrderParca)) then
      OrderParca := Trim(Copy(OrderParca, 1, Length(OrderParca) - 4));

    Result.OrderBy := OrderParca;
 //   writeln(' → Sıralama alanı: ', Result.OrderBy, ', yön: ', IfThen(Result.OrderDesc, 'DESC', 'ASC'));
  end;

  // LIMIT
  if iLimit > 0 then
  begin
    LimitParca := Trim(Copy(S, iLimit + 6, Length(S)));
    TryStrToInt(LimitParca, Result.Limit);
  end;

  // GROUP BY
  if iGroup > 0 then
  begin
    GroupParca := Trim(Copy(S, iGroup + 10,
      IfThen(iHaving > iGroup, iHaving, Length(S) + 1) - iGroup - 10));
    Result.GroupByAlan := GroupParca;
  end;

  // HAVING
  if iHaving > 0 then
  begin
    HavingParca := Trim(Copy(S, iHaving + 8, Length(S)));
    New(Result.HavingKoku);
    Result.HavingKoku^ := ParseWhereMantiksal(HavingParca);
    Result.UseHaving := True;
  end;
end;


function ParseUpdateKomut(const SQL: string): TSqlKomut;
var
  S, TabloAd, SetStr, WhereStr: string;
  iSet, iWhere, i, eq: Integer;
  TempList: TStringList;
  AlanAd, TakmaAd, DegerStr: string;
begin
  FillChar(Result, SizeOf(Result), 0);
  Result.SorguTipi := skUpdate;
  Result.Limit := -1;

  // Normalize SQL metni
  S := Trim(StringReplace(SQL, ';', '', [rfReplaceAll]));
  S := StringReplace(S, #13#10, ' ', [rfReplaceAll]);
  while Pos('  ', S) > 0 do
    S := StringReplace(S, '  ', ' ', [rfReplaceAll]);

  // SET ve WHERE pozisyonları
  iSet := Pos(' SET ', UpperCase(S));
  iWhere := Pos(' WHERE ', UpperCase(S));

  // Tablo adını ayır
  TabloAd := Trim(Copy(S, Length('UPDATE') + 1, iSet - Length('UPDATE') - 1));
  Result.Tablo := TabloAd;

  // SET kısmını ayır
  if iSet > 0 then
  begin
    SetStr := Trim(Copy(S, iSet + 5,
      IfThen(iWhere > iSet, iWhere, Length(S) + 1) - iSet - 5));

    TempList := TStringList.Create;
    try
      ExtractStrings([','], [], PChar(SetStr), TempList);
      SetLength(Result.Alanlar, TempList.Count);
      for i := 0 to TempList.Count - 1 do
      begin
        eq := Pos('=', TempList[i]);
        if eq = 0 then Continue;

        AlanAd := Trim(Copy(TempList[i], 1, eq - 1));
        DegerStr := Trim(Copy(TempList[i], eq + 1, MaxInt));

        // Tırnak varsa temizle
        if (LeftStr(DegerStr, 1) = '''') and (RightStr(DegerStr, 1) = '''') then
          DegerStr := Copy(DegerStr, 2, Length(DegerStr) - 2);

        Result.Alanlar[i].Alan := AlanAd;
        Result.Alanlar[i].TakmaIsim := ''; // UPDATE için gerekmez
        Result.Alanlar[i].Deger := DegerStr; // eger TAlanSecimi’ye Deger alanı eklendi ise
      end;
    finally
      TempList.Free;
    end;
  end;

  // WHERE kısmı varsa filtreleri ayır
  if iWhere > 0 then
  begin
    WhereStr := Trim(Copy(S, iWhere + 7, Length(S)));
    Result.Filtreler := ParseWhereKosullari(WhereStr);
  end;
end;

function TSqlEngine.KomutCreateDatabase(const SQL: string): TSorguSonucu;
var
  DBAdi: string;
  VT: TVeritabani;
begin
  Result := TSorguSonucu.Create;
 // Result.OriginalSQL := SQL;
  Result.SatirMesajlari.Add('Komut alındı: ' + SQL);
  Result.SorguTipi := 'CREATE DATABASE';

  // Adı SQL'den ayıkla
  DBAdi := Trim(Copy(SQL, Length('CREATE DATABASE') + 1, MaxInt));
  if DBAdi = '' then
  begin
    Result.Basarili := False;
    Result.HataMesaji := 'Veritabanı adı eksik!';
    Exit;
  end;

  // VT oluştur
  VT := TVeritabani.Create;
  VT.Ad := DBAdi;


  // Sonuçlara VT'yi ekle
  Result.Veritabani := VT;
  Result.BilgiMesaji := 'Veritabanı oluşturuldu: ' + DBAdi;
  Result.Basarili := True;
end;
function TSqlEngine.KomutCreateTable(VT: TVeritabani; const SQL: string): TSorguSonucu;
var
  TabloAd: string;
  Alanlar: specialize TArray<TAlanTanimi>;
  Schema: TTabloSchema;
  Tablo: TVTablo;
  i: Integer;
  A:TAlantanimi;
  //Secim: TAlanSecimi;
begin
  Result := TSorguSonucu.Create;
  Result.SatirMesajlari.Add('Komut alındı: ' + SQL);
  Result.SorguTipi := 'CREATE TABLE';

  if not ParseCreateTableKomut(SQL, TabloAd, Alanlar) then
  begin
    Result.Basarili := False;
    Result.HataMesaji := 'CREATE TABLE analiz edilemedi.';
    Exit;
  end;

  Schema := TTabloSchema.Create(TabloAd);
  for A in Alanlar do
      Schema.AlanEkleDetayli(A);

//  Vt.RegisterTableSchema(TabloAd, Schema);

  {for i := 0 to High(Alanlar) do
  begin
  //  Secim.Alan := Alanlar[i].Name;
  //  Secim.Takmaisim := Alanlar[i].TakmaAd;
  //  Secim.tip := AlanTuruToStr(Alanlar[i].Tip); // ftInteger → 'INTEGER' gibi
 //   Schema.AlanEkleDetayli(Secim);
    Schema.AlanEkleDetayli(Alanlar[i]); // Tam tanım aktarılıyor!
  end;  }

  Tablo := TVTablo.Create(TabloAd);
  Tablo.Schema := Schema;
  VT.TabloEkle(TabloAd, Tablo, [], '1.0');
  VT.RegisterTableSchema(TabloAd, Schema);

  Result.Basarili := True;
  Result.BilgiMesaji := 'Tablo oluşturuldu: ' + TabloAd;
  Result.Tablo := Tablo;
end;
function TSqlEngine.KomutInsertInto(VT: TVeritabani; const SQL: string): TSorguSonucu;
var
  TabloAd, AlanListeStr, DegerListeStr, Kelime, Deger: string;
  ParBasla, ParBitir: Integer;
  AlanList, DegerList: TStringList;
  i, Index: Integer;
  Tablo: TVTablo;
  Satir: TTabloKayit;
  Schema: TTabloSchema;
begin
  Result := TSorguSonucu.Create;
  Result.SorguTipi := 'INSERT INTO';
  DebugLog('INSERT komutu alındı: ' + SQL);

  ParBasla := Pos('(', SQL);
  ParBitir := Pos(')', SQL);
  if (ParBasla = 0) or (ParBitir = 0) then
  begin
    Result.Basarili := False;
    Result.HataMesaji := 'Parantez eksik.';
    Exit;
  end;

  TabloAd := Trim(Copy(SQL, 13, ParBasla - 13));
  AlanListeStr := Trim(Copy(SQL, ParBasla + 1, ParBitir - ParBasla - 1));

  ParBasla := Pos('VALUES', UpperCase(SQL));
  if ParBasla = 0 then
  begin
    Result.Basarili := False;
    Result.HataMesaji := 'VALUES bulunamadı.';
    Exit;
  end;

  ParBasla := PosEx('(', SQL, ParBasla);
  ParBitir := PosEx(')', SQL, ParBasla);
  if (ParBasla = 0) or (ParBitir = 0) then
  begin
    Result.Basarili := False;
    Result.HataMesaji := 'VALUES parantezleri eksik.';
    Exit;
  end;

  DegerListeStr := Trim(Copy(SQL, ParBasla + 1, ParBitir - ParBasla - 1));
  Tablo := VT.TabloByName[TabloAd];
  if Tablo = nil then
  begin
    Result.Basarili := False;
    Result.HataMesaji := 'Tablo bulunamadı.';
    Exit;
  end;

  Schema := Tablo.Schema;
  AlanList := TStringList.Create;
  DegerList := TStringList.Create;

  try
    ExtractStrings([','], [' '], PChar(AlanListeStr), AlanList);
    ExtractStrings([','], [' '], PChar(DegerListeStr), DegerList);

    if AlanList.Count <> DegerList.Count then
    begin
      Result.Basarili := False;
      Result.HataMesaji := 'Alan ve değer sayısı eşleşmiyor.';
      Exit;
    end;

    Satir := TTabloKayit.Create;

    for i := 0 to Schema.AlanSayisi - 1 do
    begin
      Kelime := Schema.Alanlar[i].Name;
      Index := AlanList.IndexOf(Kelime);

      if Index >= 0 then
      begin
        Deger := TemizDeger(DegerList[Index]);

        if Deger = '' then
        begin
          if Trim(VarToStr(Schema.Alanlar[i].DefaultDeger)) <> '' then
            Satir.DegerAta(Kelime, ParseDegerTipli(Schema.Alanlar[i].Tip, VarToStr(Schema.Alanlar[i].DefaultDeger)))
          else
            Satir.DegerAta(Kelime, Null);
        end
        else
        begin
          Satir.DegerAta(Kelime, ParseDegerTipli(Schema.Alanlar[i].Tip, Deger));
        end;
      end
      else
      begin
        if Schema.Alanlar[i].AutoIncrement and (Schema.Alanlar[i].Tip = ftInteger) then
        begin
          Satir.DegerAta(Kelime, Tablo.SonID + 1);
          Tablo.SonID := Tablo.SonID + 1;
        end
        else if Schema.Alanlar[i].NotNull then
        begin
          if Trim(VarToStr(Schema.Alanlar[i].DefaultDeger)) <> '' then
            Satir.DegerAta(Kelime, ParseDegerTipli(Schema.Alanlar[i].Tip, VarToStr(Schema.Alanlar[i].DefaultDeger)))
          else
          begin
            case Schema.Alanlar[i].Tip of
              ftText:    Satir.DegerAta(Kelime, '');
              ftFloat:   Satir.DegerAta(Kelime, 0.0);
              ftInteger: Satir.DegerAta(Kelime, 0);
            else
              Satir.DegerAta(Kelime, Null);
            end;
          end;
        end
        else if Trim(VarToStr(Schema.Alanlar[i].DefaultDeger)) <> '' then
        begin
          Satir.DegerAta(Kelime, ParseDegerTipli(Schema.Alanlar[i].Tip, VarToStr(Schema.Alanlar[i].DefaultDeger)));
        end
        else
        begin
          Satir.DegerAta(Kelime, Null);
        end;
      end;
    end;

    Tablo.KayitEkle(Satir);
    Result.Basarili := True;
    Result.BilgiMesaji := 'Satır eklendi: ' + TabloAd;

  finally
    AlanList.Free;
    DegerList.Free;
  end;
end;
function TSqlEngine.KomutDelete(VT: TVeritabani; const SQL: string): TSorguSonucu;
var
  Komut: TSqlKomut;
  Kaynak: TVTablo;
  i: Integer;
begin
  Result := TSorguSonucu.Create;
  Result.SorguTipi := 'DELETE';

  try
    Komut := ParseDeleteKomut(SQL);

    Kaynak := VT.TabloByName[Komut.Tablo];
    if Kaynak = nil then
    begin
      Result.Basarili := False;
      Result.HataMesaji := 'Tablo bulunamadı: ' + Komut.Tablo;
      Exit;
    end;

    for i := Kaynak.KayitSayisi - 1 downto 0 do
    begin
      if Assigned(Komut.FiltreKoku) and not KayitEslesir(Kaynak.Kayitlar[i], Komut.FiltreKoku^) then
        Continue;

      Kaynak.Kayitlar.Delete(i);
    end;

    Result.Basarili := True;
    Result.BilgiMesaji := 'Uygun kayıtlar silindi.';

    if Assigned(Komut.FiltreKoku) then
      SerbestFiltre(Komut.FiltreKoku);

  except
    on E: Exception do
    begin
      Result.Basarili := False;
      Result.HataMesaji := 'DELETE hatası: ' + E.Message;
    end;
  end;
end;
function TSqlEngine.KomutUpdate(VT: TVeritabani; const SQL: string): TSorguSonucu;
var
  Komut: TSqlKomut;
  Kaynak: TVTablo;
  K: TTabloKayit;
  Alan: string;
  Deger: Variant;
  i, Sayac: Integer;
begin
  Result := TSorguSonucu.Create;
  Result.SorguTipi := 'UPDATE';
  Sayac := 0;

  try
    Komut := ParseUpdateKomut(SQL);

    Kaynak := VT.TabloByName[Komut.Tablo];
    if Kaynak = nil then
    begin
      Result.Basarili := False;
      Result.HataMesaji := 'Tablo bulunamadı: ' + Komut.Tablo;
      Exit;
    end;

    for K in Kaynak.Kayitlar do
    begin
      if Assigned(Komut.FiltreKoku) and not KayitEslesir(K, Komut.FiltreKoku^) then
        Continue;

      // Alanları güncelle
      for i := Low(Komut.Alanlar) to High(Komut.Alanlar) do
      begin
        Alan := Komut.Alanlar[i].Alan;
        Deger := Komut.Alanlar[i].Deger;
        K.DegerAta(Alan, Deger);
      end;

      Inc(Sayac);
    end;

    Result.Basarili := True;
    Result.BilgiMesaji := Format('%d kayıt güncellendi.', [Sayac]);

    if Assigned(Komut.FiltreKoku) then
      SerbestFiltre(Komut.FiltreKoku);

  except
    on E: Exception do
    begin
      Result.Basarili := False;
      Result.HataMesaji := 'UPDATE hatası: ' + E.Message;
    end;
  end;
end;


function TSqlEngine.KomutSelect(VT: TVeritabani; const SQL: string): TSorguSonucu;
var
  Komut: TSqlKomut;
  TabloA, TabloB: TVTablo;
  K1, K2, Yeni: TTabloKayit;
  i, Count: Integer;
  Deger: Variant;
  Comparer: TTabloKayitMultiComparer;
  GrupDict: specialize TDictionary<string, Integer>;
  Anahtar: String;
  AT: TAlanTanimi;

  Sec: TAlanSecimi;
  Tanim: TAlanTanimi;
  TipStr: string;
  Names:TStringList;
  j:Integer;

  T: TAlanTuru;
  k:Integer;
  SrcSchema :TTabloSchema;
begin
  Result := TSorguSonucu.Create;
  Result.SatirMesajlari.Add('Komut alındı: ' + SQL);
  Result.SorguTipi := 'SELECT';





  DebugLog('[DEBUG][SELECT SQL] ' + SQL);

  try
    Komut := ParseSelectKomut(SQL);

    Result.Tablo := TVTablo.Create('QueryResult');
  //  Result.Tablo.Schema := TTabloSchema.Create('QueryResult');


    SrcSchema := Result.Veritabani.GetTableSchema(komut.tablo);

   Result.Tablo.Schema := SrcSchema;
   DebugLog('[DEBUG][SOURCE SCHEMA] ' + SrcSchema.CommaText);
 //  DebugLog('[DEBUG][SOURCE SCHEMA] ' + Result.Tablo.Schema.CommaText);
  // CommaText: Schema.Alanlar[i].Name listesini virgüllerle döndürür

    // SELECT alanlarını şemaya ekle
    for i := Low(Komut.Alanlar) to High(Komut.Alanlar) do
    begin
       Sec := Komut.Alanlar[i];

    // Şema’dan enum tipi oku
    T := Result.Tablo.Schema.AlanTipi(Sec.Alan);
    // String ve uzunluk ata
    Sec.Tip    := AlanTuruToStr(T);
    Sec.Length := AlanBoyutu(T);

    DebugLog(Format(
      '[DEBUG][SELECT->SEC] %s : Tip=%s, Len=%d',
      [Sec.Alan, Sec.Tip, Sec.Length]
    ));





        // ③ Şimdi TAlanTanimi record’unu doldur
        Tanim              := Default(TAlanTanimi);
        Tanim.Name         := Sec.Alan;
        Tanim.TakmaAd      := Sec.Takmaisim;
        Tanim.Tip          := StrToAlanTuru(AlanTuruToStr(Result.Tablo.Schema.AlanTipi(Sec.Alan))); //StrToAlanTuru(Sec.Tip);
        Tanim.Length       := AlanBoyutu(Tanim.Tip);//Sec.Length;
        Tanim.NotNull      := False;
        Tanim.PrimaryKey   := Result.Tablo.Schema.AlanPrimaryKeyMi(Sec.Alan);
        Tanim.AutoIncrement:= Result.Tablo.Schema.AlanAutoIncMi(Sec.Alan);
        Tanim.DefaultDeger := Result.Tablo.Schema.AlanDefaultDeger(Sec.Alan);

        Result.Tablo.Schema.AlanEkleDetayli(Tanim);




     // if Komut.Alanlar[i].Alan = 'Count(*)' then Continue;

    //  Result.Tablo.Schema.AlanEkle(Komut.Alanlar[i]);
    end;






    // JOIN yoksa normal tabloya eriş
    if Komut.JoinTablo = '' then
    begin
      TabloA := VT.TabloByName[Komut.Tablo];
      if TabloA = nil then
      begin
        Result.Basarili := False;
        Result.HataMesaji := 'Tablo bulunamadı: ' + Komut.Tablo;
        Exit;
      end;

      // SELECT * desteği
      if (Length(Komut.Alanlar) = 1) and (Komut.Alanlar[0].Alan = '*') then
      begin
        SetLength(Komut.Alanlar, TabloA.Schema.AlanSayisi);
        for i := 0 to TabloA.Schema.AlanSayisi - 1 do
        begin
          Komut.Alanlar[i].Alan := TabloA.Schema.Alanlar[i].Name;
          Komut.Alanlar[i].TakmaIsim := '';
        end;
      end;

      for K1 in TabloA.Kayitlar do
      begin
        if Assigned(Komut.FiltreKoku) and not KayitEslesir(K1, Komut.FiltreKoku^) then
          Continue;

        Yeni := TTabloKayit.Create;
        for i := Low(Komut.Alanlar) to High(Komut.Alanlar) do
        begin
          if Komut.Alanlar[i].Alan = 'Count(*)' then Continue;
          if not K1.TryDegerAl(Komut.Alanlar[i].Alan, Deger) then
            Deger := Null;
          Yeni.DegerAta(TakmaIsimOrDefault(Komut.Alanlar[i]), Deger);
        end;
        Result.Tablo.KayitEkle(Yeni);
      end;
    end
    else
    begin
      // JOIN varsa iki tabloya eriş
      TabloA := VT.TabloByName[Komut.AnaTablo];
      TabloB := VT.TabloByName[Komut.JoinTablo];
      for K1 in TabloA.Kayitlar do
        for K2 in TabloB.Kayitlar do
        begin
          if VarToStr(K1.DegerAl(Trim(ExtractDelimited(2, Komut.JoinKosulSol, ['.'])))) <>
             VarToStr(K2.DegerAl(Trim(ExtractDelimited(2, Komut.JoinKosulSag, ['.'])))) then Continue;

          Yeni := TTabloKayit.Create;
          for i := Low(Komut.Alanlar) to High(Komut.Alanlar) do
          begin
            if StartsText(Komut.AnaAlias + '.', Komut.Alanlar[i].Alan) then
              Yeni.DegerAta(TakmaIsimOrDefault(Komut.Alanlar[i]),
                K1.DegerAl(ExtractDelimited(2, Komut.Alanlar[i].Alan, ['.'])))
            else if StartsText(Komut.JoinAlias + '.', Komut.Alanlar[i].Alan) then
              Yeni.DegerAta(TakmaIsimOrDefault(Komut.Alanlar[i]),
                K2.DegerAl(ExtractDelimited(2, Komut.Alanlar[i].Alan, ['.'])));
          end;
          Result.Tablo.KayitEkle(Yeni);
        end;
    end;

    // COUNT(*) işlemi
    if Komut.AggregateTip = agCount then
    begin
      if Komut.GroupByAlan = '' then
      begin
        Count := 0;
        for K1 in TabloA.Kayitlar do
          if not Assigned(Komut.FiltreKoku) or KayitEslesir(K1, Komut.FiltreKoku^) then
            Inc(Count);

        FillChar(AT, SizeOf(AT), 0);
        AT.Name := 'Count(*)';

        AT.Tip := ftInteger;
        Result.Tablo.Schema.AlanEkleDetayli(AT);

        Yeni := TTabloKayit.Create;
        Yeni.DegerAta('Count(*)', Count);
        Result.Tablo.KayitEkle(Yeni);
      end
      else
      begin
        GrupDict := specialize TDictionary<string, Integer>.Create;
        for K1 in TabloA.Kayitlar do
        begin
          if Assigned(Komut.FiltreKoku) and not KayitEslesir(K1, Komut.FiltreKoku^) then Continue;
          Anahtar := VarToStr(K1.DegerAl(Komut.GroupByAlan));
          if GrupDict.ContainsKey(Anahtar) then
            GrupDict[Anahtar] := GrupDict[Anahtar] + 1
          else
            GrupDict.Add(Anahtar, 1);
        end;

        FillChar(AT, SizeOf(AT), 0);
        AT.Name := Komut.GroupByAlan;
        AT.Tip := ftText;
        Result.Tablo.Schema.AlanEkleDetayli(AT);

        FillChar(AT, SizeOf(AT), 0);
        AT.Name := 'Count(*)';
        AT.Tip := ftInteger;
        Result.Tablo.Schema.AlanEkleDetayli(AT);

        for Anahtar in GrupDict.Keys do
        begin
          Yeni := TTabloKayit.Create;
          Yeni.DegerAta(Komut.GroupByAlan, Anahtar);
          Yeni.DegerAta('Count(*)', GrupDict[Anahtar]);

          // HAVING filtresi
          if Komut.UseHaving and not KayitEslesir(Yeni, Komut.HavingKoku^) then Continue;

          Result.Tablo.KayitEkle(Yeni);
        end;

        GrupDict.Free;
      end;
    end;

    // ORDER BY
    if (Komut.OrderBy <> '') and (Result.Tablo.KayitSayisi > 1) then
    begin

     //   writeln('→ Siralama oncesi:');
    //    for i := 0 to Result.Tablo.KayitSayisi - 1 do
     //     writeln('  ', Result.Tablo.Kayitlar[i].DegerAl(Komut.OrderBy));

        Comparer := TTabloKayitMultiComparer.Create([Komut.OrderBy], Komut.OrderDesc, Result.Tablo.Schema);
        Result.Tablo.Kayitlar.Sort(Comparer);
        Comparer.Free;

    //    writeln('→ Siralama sonrasi:');
    //    for i := 0 to Result.Tablo.KayitSayisi - 1 do
    //      writeln('  ', Result.Tablo.Kayitlar[i].DegerAl(Komut.OrderBy));


        //  writeln('Sıralama yönü: ', IfThen(Komut.OrderDesc, 'DESC', 'ASC'));
      //    writeln(ord(Result.Tablo.Schema.AlanTipi('Stok')));
      //    writeln('[DEBUG] Alan tipi enum adi: ', GetEnumName(TypeInfo(TAlanTuru), ord(Result.Tablo.Schema.AlanTipi('Stok'))));
     { Comparer := TTabloKayitMultiComparer.Create([Komut.OrderBy], Komut.OrderDesc,Result.tablo.Schema);
      Result.Tablo.Kayitlar.Sort(Comparer);
      Comparer.Free;   }
    end;

    // LIMIT
    while (Komut.Limit > 0) and (Result.Tablo.KayitSayisi > Komut.Limit) do
      Result.Tablo.Kayitlar.Delete(Result.Tablo.KayitSayisi - 1);

    Result.Basarili := True;
    Result.BilgiMesaji := Format('%d kayıt döndürüldü.', [Result.Tablo.KayitSayisi]);

    if Assigned(Komut.FiltreKoku) then
      SerbestFiltre(Komut.FiltreKoku);
  except
    on E: Exception do
    begin
      Result.Basarili := False;
      Result.HataMesaji := 'SELECT hatası: ' + E.Message;
    end;
  end;
end;



function TSqlEngine.KomutDropTable(VT: TVeritabani; const SQL: string): TSorguSonucu;
var
  Komut: TStringArray;
  TabloAdi: string;
begin
  Result := TSorguSonucu.Create;
  Result.SorguTipi := 'DROP TABLE';

  Komut := SQL.Split([' '], TStringSplitOptions.ExcludeEmpty);
  if (Length(Komut) < 3) or (UpperCase(Komut[0]) <> 'DROP') or (UpperCase(Komut[1]) <> 'TABLE') then
  begin
    Result.Basarili := False;
    Result.HataMesaji := 'DROP TABLE komutu geçersiz.';
    Exit;
  end;

  TabloAdi := Komut[2];

  if VT.TabloByName[TabloAdi] = nil then
  begin
    Result.Basarili := False;
    Result.HataMesaji := 'Tablo bulunamadı: ' + TabloAdi;
    Exit;
  end;

  VT.TabloSil(TabloAdi);

  Result.Basarili := True;
  Result.BilgiMesaji := 'Tablo silindi: ' + TabloAdi;
end;
function TSqlEngine.KomutAlterTable(VT: TVeritabani; const SQL: string): TSorguSonucu;
var
  Parca: TStringArray;
  TabloAdi, AlanAdi, YeniDeger: string;
  i: Integer;
  YeniAlan: TAlanSecimi;
  Schema: TTabloSchema;
  Kayit: TTabloKayit;
begin
  Result := TSorguSonucu.Create;
  Result.SorguTipi := 'ALTER';

  Parca := SQL.Split([' '], TStringSplitOptions.ExcludeEmpty);
  if Length(Parca) < 4 then
  begin
    Result.Basarili := False;
    Result.HataMesaji := 'ALTER TABLE komutu eksik veya geçersiz.';
    Exit;
  end;

  if not (SameText(Parca[0], 'ALTER') and SameText(Parca[1], 'TABLE')) then
  begin
    Result.Basarili := False;
    Result.HataMesaji := 'ALTER TABLE sözdizimi hatalı.';
    Exit;
  end;

  TabloAdi := Parca[2];
  if not Assigned(VT.TabloByName[TabloAdi]) then
  begin
    Result.Basarili := False;
    Result.HataMesaji := 'Tablo bulunamadı: ' + TabloAdi;
    Exit;
  end;

  Schema := VT.TabloByName[TabloAdi].Schema;

  if SameText(Parca[3], 'ADD') and (Length(Parca) >= 6) then
  begin
    YeniAlan.Alan := Parca[4];
    YeniAlan.Tip := Parca[5];
    YeniAlan.TakmaIsim := '';
    YeniAlan.Deger := '';
    Schema.AlanEkle(YeniAlan);

    for i := 0 to VT.TabloByName[TabloAdi].KayitSayisi - 1 do
      TamamlaEksikAlanlar(VT.TabloByName[TabloAdi].Kayitlar[i], Schema);

    Result.Basarili := True;
    Result.BilgiMesaji := Format('Alan eklendi: %s → %s', [YeniAlan.Alan, TabloAdi]);
  end
  else if SameText(Parca[3], 'DROP') and (Length(Parca) >= 5) then
  begin
    AlanAdi := Parca[4];

    // Alanı şemadan kaldır
    for i := 0 to High(Schema.Alanlar) do
    begin
      if SameText(Schema.Alanlar[i].Name, AlanAdi) then
      begin
        Schema.AlanSil(AlanAdi);
        //Delete(Schema.FAlanlar, i, 1);
        Break;
      end;
    end;

    // Tüm kayıtlardan bu alanı kaldır
    for Kayit in VT.TabloByName[TabloAdi].Kayitlar do
      Kayit.Veriler.Remove(AlanAdi);

    Result.Basarili := True;
    Result.BilgiMesaji := Format('Alan silindi: %s → %s', [AlanAdi, TabloAdi]);
  end
  else if SameText(Parca[3], 'RENAME') and SameText(Parca[5], 'TO') and (Length(Parca) >= 6) then
  begin
    AlanAdi := Parca[4];
    YeniDeger := Parca[6];

    for i := 0 to High(Schema.Alanlar) do
    begin
      if SameText(Schema.Alanlar[i].Name, AlanAdi) then
      begin
        Schema.AlanAdiniDegistir(AlanAdi,YeniDeger);//FAlanlar[i].Name := YeniDeger;
        Break;
      end;
    end;

    for Kayit in VT.TabloByName[TabloAdi].Kayitlar do
    begin
      if Kayit.Veriler.ContainsKey(AlanAdi) then
      begin
        Kayit.DegerAta(YeniDeger, Kayit.DegerAl(AlanAdi));
        Kayit.Veriler.Remove(AlanAdi);
      end;
    end;

    Result.Basarili := True;
    Result.BilgiMesaji := Format('Alan yeniden adlandırıldı: %s → %s', [AlanAdi, YeniDeger]);
  end
  else if SameText(Parca[3], 'MODIFY') and (Length(Parca) >= 6) then
  begin
    AlanAdi := Parca[4];
    YeniDeger := Parca[5]; // yeni tip

    // Alanı bul
    for i := 0 to High(Schema.Alanlar) do
    begin
      if SameText(Schema.Alanlar[i].Name, AlanAdi) then
      begin
        Schema.AlanTipiniDegistir(alanadi,YeniDeger);// FAlanlar[i].Tip := StrToAlanTuru(YeniDeger);
       {
        // Uzunluk belirlemesi yapılabilir
        if Schema.FAlanlar[i].Tip = ftText then
          Schema.FAlanlar[i].Length := 255
        else if Schema.FAlanlar[i].Tip = ftInteger then
          Schema.FAlanlar[i].Length := 4
        else if Schema.FAlanlar[i].Tip = ftFloat then
          Schema.FAlanlar[i].Length := 8;
           }
        Break;
      end;
    end;

    // Kayıtlardaki verileri dönüştür
    for Kayit in VT.TabloByName[TabloAdi].Kayitlar do
    begin
      if not Kayit.Varmi(AlanAdi) then Continue;

      try
        case Schema.Alan(AlanAdi).Tip of
          ftInteger: Kayit.DegerAta(AlanAdi, StrToIntDef(VarToStr(Kayit.DegerAl(AlanAdi)), 0));
          ftFloat:   Kayit.DegerAta(AlanAdi, SafeStrToFloat(VarToStr(Kayit.DegerAl(AlanAdi))));
          ftText:    Kayit.DegerAta(AlanAdi, VarToStr(Kayit.DegerAl(AlanAdi)));
        else
          Kayit.DegerAta(AlanAdi, Kayit.DegerAl(AlanAdi)); // dönüşüm yapılmıyor
        end;
      except
        Kayit.DegerAta(AlanAdi, Null);
      end;
    end;

    Result.Basarili := True;
    Result.BilgiMesaji := Format('Alan tipi değiştirildi: %s → %s', [AlanAdi, YeniDeger]);
  end
  else
  begin
    Result.Basarili := False;
    Result.HataMesaji := 'ALTER TABLE komutu desteklenmiyor veya eksik parametre.';
  end;
end;
function TSqlEngine.KomutShowTables(const SQL: string): TSorguSonucu;
var
  i: Integer;
  Kapsul: TTabloKapsul;
  Satir: TTabloKayit;
begin
  Result := TSorguSonucu.Create;
  Result.SorguTipi := 'SHOW TABLES';
  Result.Tablo := TVTablo.Create('TabloListesi');
  Result.Tablo.Schema := TTabloSchema.Create('TabloListesi');

  // Sütunlar: name, version, kayit_sayisi
  Result.Tablo.Schema.AlanEkleDetayli(Default(TAlanTanimi)); with Result.Tablo.Schema.Alanlar[0] do begin Name := 'name'; Tip := ftText; Length := 128; end;
  Result.Tablo.Schema.AlanEkleDetayli(Default(TAlanTanimi)); with Result.Tablo.Schema.Alanlar[1] do begin Name := 'version'; Tip := ftText; Length := 32; end;
  Result.Tablo.Schema.AlanEkleDetayli(Default(TAlanTanimi)); with Result.Tablo.Schema.Alanlar[2] do begin Name := 'record_count'; Tip := ftInteger; end;

  for i := 0 to FVeritabani.TabloSayisi - 1 do
  begin
    Kapsul := FVeritabani.Kapsuller[i];
    Satir := TTabloKayit.Create;
    Satir.DegerAta('name', Kapsul.Ad);
    Satir.DegerAta('version', Kapsul.Version);
    Satir.DegerAta('record_count', Kapsul.Tablo.KayitSayisi);
    Result.Tablo.KayitEkle(Satir);
  end;

  Result.Basarili := True;
  Result.BilgiMesaji := 'Tablolar listelendi';
end;
function TSqlEngine.KomutDescribeTable(VT: TVeritabani; const SQL: string
  ): TSorguSonucu;
var
  Parca: TStringArray;
  TabloAdi: string;
  Schema: TTabloSchema;
  A: TAlanTanimi;
  K: TTabloKayit;
  i: Integer;
begin
  Result := TSorguSonucu.Create;
  Result.SorguTipi := 'DESCRIBE';

  Parca := SQL.Split([' '], TStringSplitOptions.ExcludeEmpty);
  if (Length(Parca) <> 2) or (UpperCase(Parca[0]) <> 'DESCRIBE') then
  begin
    Result.Basarili := False;
    Result.HataMesaji := 'Geçersiz DESCRIBE komutu.';
    Exit;
  end;

  TabloAdi := Parca[1];
  if VT.TabloByName[TabloAdi] = nil then
  begin
    Result.Basarili := False;
    Result.HataMesaji := 'Tablo bulunamadı: ' + TabloAdi;
    Exit;
  end;

  Schema := VT.TabloByName[TabloAdi].Schema;
  Result.Tablo := TVTablo.Create('Sema_' + TabloAdi);
  Result.Tablo.Schema := TTabloSchema.Create('Sema_' + TabloAdi);

  // Alanlar: name, type, length, notnull, primaryKey, autoIncrement, default
  with Result.Tablo.Schema do
  begin
    AlanEkleDetayli(Default(TAlanTanimi)); Alanlar[0].Name := 'name';           Alanlar[0].Tip := ftText; Alanlar[0].Length := 64;
    AlanEkleDetayli(Default(TAlanTanimi)); Alanlar[1].Name := 'type';           Alanlar[1].Tip := ftText; Alanlar[1].Length := 32;
    AlanEkleDetayli(Default(TAlanTanimi)); Alanlar[2].Name := 'length';         Alanlar[2].Tip := ftInteger;
    AlanEkleDetayli(Default(TAlanTanimi)); Alanlar[3].Name := 'notnull';        Alanlar[3].Tip := ftBoolean;
    AlanEkleDetayli(Default(TAlanTanimi)); Alanlar[4].Name := 'primaryKey';     Alanlar[4].Tip := ftBoolean;
    AlanEkleDetayli(Default(TAlanTanimi)); Alanlar[5].Name := 'autoIncrement';  Alanlar[5].Tip := ftBoolean;
    AlanEkleDetayli(Default(TAlanTanimi)); Alanlar[6].Name := 'default';        Alanlar[6].Tip := ftText; Alanlar[6].Length := 128;
  end;

  for i := 0 to Schema.AlanSayisi - 1 do
  begin
    A := Schema.Alanlar[i];
    K := TTabloKayit.Create;
    K.DegerAta('name', A.Name);
    K.DegerAta('type', AlanTuruToStr(A.Tip));
    K.DegerAta('length', A.Length);
    K.DegerAta('notnull', A.NotNull);
    K.DegerAta('primaryKey', A.PrimaryKey);
    K.DegerAta('autoIncrement', A.AutoIncrement);
    K.DegerAta('default', VarToStr(A.DefaultDeger));
    Result.Tablo.KayitEkle(K);
  end;

  Result.Basarili := True;
  Result.BilgiMesaji := 'Tablo şeması gösterildi: ' + TabloAdi;
end;

function TSqlEngine.KomutYurut(const SQL: string): TSorguSonucu;
var
  NormalSQL: string;
begin
  Result := TSorguSonucu.Create;
  //Result.OriginalSQL := SQL;
  Result.SatirMesajlari.Add('Komut alındı: ' + SQL);

  NormalSQL := NormalizeSQL(SQL); // çok satırlı SQL düzleştirme

  // CREATE DATABASE
  if StartsText('CREATE DATABASE', NormalSQL) then
  begin
    Result := KomutCreateDatabase(NormalSQL);
    FVeritabani:=Result.Veritabani;
    Exit;
  end;

  // Veritabanı olmadan diğer komutlar çalışamaz
  if FVeritabani = nil then
  begin
    Result.Basarili := False;
    Result.HataMesaji := 'Veritabanı oluşturulmadan işlem yapılamaz.';
    Exit;
  end;

  // CREATE TABLE
  if StartsText('CREATE TABLE', NormalSQL) then
  begin
    Result := KomutCreateTable(FVeritabani, NormalSQL);
    Exit;
  end;

  // INSERT INTO
  if StartsText('INSERT INTO', NormalSQL) then
  begin
    Result := KomutInsertInto(FVeritabani, NormalSQL);
    Exit;
  end;

  // SELECT
  if StartsText('SELECT', NormalSQL) then
  begin
    Result := KomutSelect(FVeritabani, NormalSQL);
    Exit;
  end;

   // UPDATE
  if StartsText('UPDATE', NormalSQL) then
  begin
    Result := KomutUpdate(FVeritabani, NormalSQL);
    Exit;
  end;

  // DELETE
  if StartsText('DELETE', NormalSQL) then
  begin
    Result := KomutDelete(FVeritabani, NormalSQL);
    Exit;
  end;

  if StartsText('DROP TABLE', NormalSQL) then
  begin
    Result := KomutDropTable(FVeritabani, NormalSQL);
    Exit;
  end;

  if StartsText('ALTER TABLE', NormalSQL) then
  begin
    Result := KomutAlterTable(FVeritabani, NormalSQL);
    Exit;
  end;

  if StartsText('SHOW TABLES', NormalSQL) then
  begin
    Result := KomutShowTables(NormalSQL);
    Exit;
  end;

  if StartsText('DESCRIBE', NormalSQL) then
  begin
    Result := KomutDescribeTable(FVeritabani, NormalSQL);
    Exit;
  end;

  // Diğer komutlar eklenebilir...
  Result.Basarili := False;
  Result.HataMesaji := 'Desteklenmeyen SQL komutu: ' + NormalSQL;
end;
end.

