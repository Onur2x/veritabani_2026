unit fJoinBuilder;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, StdCtrls, Grids, oVeritabani;

type
  TJoinInfo = record
    LeftTable: string;
    RightTable: string;
    LeftColumn: string;
    RightColumn: string;
  end;

  TFormJoinBuilder = class(TForm)
    ComboLeftTable: TComboBox;
    ComboRightTable: TComboBox;
    ComboLeftColumn: TComboBox;
    ComboRightColumn: TComboBox;
    ButtonJoin: TButton;
    MemoResult: TMemo;
    procedure ButtonJoinClick(Sender: TObject);
    procedure ComboLeftTableChange(Sender: TObject);
    procedure ComboRightTableChange(Sender: TObject);
  private
    FVeri: TVeritabani;
  public
    procedure Initialize(Veritabani: TVeritabani);
  end;

var
  FormJoinBuilder: TFormJoinBuilder;

implementation

{$R *.lfm}

procedure TFormJoinBuilder.Initialize(Veritabani: TVeritabani);
begin
  FVeri := Veritabani;
  ComboLeftTable.Items := FVeri.GetTableNames('Default');
  ComboRightTable.Items := FVeri.GetTableNames('Default');
end;

procedure TFormJoinBuilder.ComboLeftTableChange(Sender: TObject);
var
  i: integer;
  alnlar: specialize TArray<string>;
begin
  ComboLeftColumn.Items.Clear;
  alnlar := FVeri.GetTableSchema('Default', ComboLeftTable.Text).AlanAdlari;

  for i := 0 to High(alnlar) do
    ComboLeftColumn.Items.Add(alnlar[i]);

end;

procedure TFormJoinBuilder.ComboRightTableChange(Sender: TObject);
var
  i: integer;
  alnlar: specialize TArray<string>;
begin
  ComboLeftColumn.Items.Clear;
  alnlar := FVeri.GetTableSchema('Default', ComboRightTable.Text).AlanAdlari;
  for i := 0 to High(alnlar) do
    ComboRightColumn.Items.Add(alnlar[i]);

end;

procedure TFormJoinBuilder.ButtonJoinClick(Sender: TObject);
begin
  MemoResult.Lines.Text := Format('JOIN %s.%s ↔ %s.%s',
    [ComboLeftTable.Text, ComboLeftColumn.Text, ComboRightTable.Text,
    ComboRightColumn.Text]);
end;

end.
