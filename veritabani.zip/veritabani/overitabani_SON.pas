unit oVeritabani;

interface

uses
  SysUtils,
  Generics.Collections,
  Variants,Classes,
  fpjson, jsonparser,
  //System.IOUtils,
  oTabloSchema,
  oTypes,ZStream;

type
  // Bir satırı temsil eden sözlük
  TRow     = specialize TDictionary<string, Variant>;
  TRowList = specialize TList<TRow>;

  TVeritabani = class
  private
    FSchemaDict : specialize TDictionary<string, TTabloSchema>;
    FDataDict   : specialize TDictionary<string, TRowList>;
    FIdentity   : specialize TDictionary<string, Int64>;

    function BuildFullJSON:TJSONObject;
    procedure LoadTableFromJSON(const tblObj: TJSONObject);
    function  VariantFromJSON(const jv: TJSONData): Variant;
    function  JSONFromVariant(const v: Variant): TJSONData;
  public
    ad:String;
    constructor Create;
    destructor  Destroy; override;

    // --- meta / yönetim
    procedure CreateDatabase(const AName: string);
    procedure DropTable(const TableName: string);
    procedure CreateTable(const TableName: string; Schema: TTabloSchema);
    procedure UnregisterTableSchema(const TableName: string);
    procedure RegisterTableSchema(const TableName:string;Schema:TTabloSchema);
    function  GetTableSchema(const TableName: string): TTabloSchema;
    function  GetDataTable(const TableName: string): TRowList;

    function  TabloSayisi: Integer;
    function  TabloAdlari: specialize TArray<string>;


    procedure AlterTableAddColumn(const TableName: string;const ColDef: TAlanTanimi);


    // --- CRUD
    procedure InsertInto(
      const TableName: string;
      const Columns: specialize TArray<string>;
      const Values: specialize TArray<string>
    );
    function  SelectFrom(
      const TableName: string;
      const Columns: specialize TArray<string>;
      const Conditions: specialize TArray<TCondition>;
      const OrderBy:  string
    ): specialize TList<TRow>;

    // --- Persistence
    procedure SaveToFile(const FileName: string);
    procedure LoadFromFile(const FileName: string);
  end;

implementation
 procedure WriteTableDataBinary(
  const FileName: string;
  Schema: TTabloSchema;
  Rows: specialize TList<TRow>
);
var
  fs: TFileStream;
  zs: TZCompressionStream;
  i, j: Integer;
  fld: TAlanTanimi;
  val: Variant;
  s: string;
  len32: Cardinal;
  flag: Byte;
begin
  fs := TFileStream.Create(FileName, fmCreate);
  try
    // Tüm paketi sıkıştırmak istiyorsan:
    zs := TZCompressionStream.Create(clMax, fs);
    try
      // 1) Satır sayısı
      zs.WriteBuffer(Rows.Count, SizeOf(Cardinal));

      // 2) Her satırı yaz
      for i := 0 to Rows.Count - 1 do
      begin
        for j := 0 to Schema.AlanSayisi - 1 do
        begin
          fld := Schema.Alanlar[j];
          val := Rows[i].Values[fld.Name];

          // Null check
          if VarIsNull(val) then flag := 0 else flag := 1;
          zs.WriteBuffer(flag, 1);

          if flag = 1 then
          begin
            case fld.Tip of
              atInteger:
                begin
                  zs.WriteBuffer(Int64(val), SizeOf(Int64));
                end;
              atFloat:
                zs.WriteBuffer(Double(val), SizeOf(Double));
              atDateTime:
                zs.WriteBuffer(Double(val), SizeOf(Double));
              atBoolean:
                zs.WriteBuffer(Byte(val), SizeOf(Byte));
              atString:
                begin
                  s := UTF8Encode(VarToStr(val));
                  len32 := Length(s);
                  zs.WriteBuffer(len32, SizeOf(len32));
                  zs.WriteBuffer(Pointer(s)^, len32);
                end;
              // diğer tiplere göre genişlet…
            end;
          end;
        end;
      end;

    finally
      zs.Free;
    end;
  finally
    fs.Free;
  end;
end;

procedure ReadTableDataBinary(
  const FileName: string;
  Schema: TTabloSchema;
  out Rows: specialize TList<TRow>
);
var
  fs: TFileStream;
  zs: TZDecompressionStream;
  rowCount: Cardinal;
  i, j: Integer;
  fld: TAlanTanimi;
  flag: Byte;
  ival: Int64;
  dval: Double;
  bval: Byte;
  len32: Cardinal;
  buf: RawByteString;
  r: TRow;
begin
  fs := TFileStream.Create(FileName, fmOpenRead);
  try
    zs := TZDecompressionStream.Create(fs);
    try
      // 1) Satır sayısı
      zs.ReadBuffer(rowCount, SizeOf(Cardinal));
      Rows := TList<TRow>.Create;

      // 2) Okuma döngüsü
      for i := 0 to rowCount - 1 do
      begin
        r := TRow.Create;
        for j := 0 to Schema.AlanSayisi - 1 do
        begin
          fld := Schema.Alanlar[j];
          zs.ReadBuffer(flag, 1);
          if flag = 0 then
            r.Add(fld.Name, Null)
          else
          begin
            case fld.Tip of
              atInteger:
                begin
                  zs.ReadBuffer(ival, SizeOf(Int64));
                  r.Add(fld.Name, ival);
                end;
              atFloat, atDateTime:
                begin
                  zs.ReadBuffer(dval, SizeOf(Double));
                  r.Add(fld.Name, dval);
                end;
              atBoolean:
                begin
                  zs.ReadBuffer(bval, SizeOf(Byte));
                  r.Add(fld.Name, bval = 1);
                end;
              atString:
                begin
                  zs.ReadBuffer(len32, SizeOf(Cardinal));
                  SetLength(buf, len32);
                  zs.ReadBuffer(Pointer(buf)^, len32);
                  r.Add(fld.Name, UTF8Decode(buf));
                end;
            end;
          end;
        end;
        Rows.Add(r);
      end;

    finally
      zs.Free;
    end;
  finally
    fs.Free;
  end;
end;

end.
