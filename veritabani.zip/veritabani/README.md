# VDB Motor v2 â€” Dokumantasyon

Saf Free Pascal ile yazilmis, harici DLL gerektirmeyen, tek dosyali
(`.odb`) iliskisel veritabani motoru. Ayrinti `SQL.md`'dedir.

## Motor Yapisi

```
SQL metni -> VDbParser -> VDbAst -> VDbExecutor -> VDbTable -> VDbCore -> .odb
```

| Birim | Rol |
|---|---|
| `VDbCore.pas` | Dusuk seviye append-only KV motor + `TCriticalSection` kilit |
| `VDbTable.pas` | Tablo katmani (sema, indeks, `FK`, kisitlar) + tablo kilidi (`Lock/Unlock`) |
| `VDbAst.pas` | Tip-guvenli AST dugum modeli |
| `VDbParser.pas` | Tokenizer + recursive-descent parser |
| `VDbExecutor.pas` | AST yurytucu (filtre, birlestirme, gruplama, siralama) |
| `VDbSql.pas` | Dis cephe (`TVSql.Exec`): betik bolme, otomatik transaction, DB dosya yonetimi |
| `VDbErr.pas` | Hata kodlari (`TVDbErrorCode`) + `EVDbException` |
| `VDbText.pas` | Turkce metin (`TrUpper/Lower`, UTF-8 uzunluk, `COLLATE TR` kiyas) |
| `VDbDataSet.pas` | `TDataSet` baglantisi (`TVDbQuery`) + `VDbDataSetReg.pas` kayit birimi |
| `VDbJson.pas` | JSON disari/iceri (`EXPORT`/`IMPORT JSON`) |
| `VDbWal.pas` | OLU KOD: derlenebilir ama hicbir proje cagirmaz; **gercek WAL `VDbCore` icindedir** (asagidaki dayaniklilik notuna bak) |
| `VDbSync.pas` | `fsync` + dosya kilidi + dizin flush |
| `VDbCrc32.pas` | CRC32 (IEEE 802.3) |
| `VDbTest.pas` | OLU KOD: hicbir proje kullanmiyor |
| `VDbCrypt.pas` | Kayit seviyesi sifreleme: AES-256-CTR + HMAC-SHA256, PBKDF2, `.key` (bkz. *Sifreleme*) |
| `VDbCdc.pas` | WAL uzerinden degisiklik yakalama (bkz. *CDC / Time Travel*) |
| `VDbTimeTravel.pas` | WAL gecmisinden onceki deger (bkz. *CDC / Time Travel*) |
| `VDbPool.pas` | Tek motor uzerinde N `TVSql` havuzu (bkz. *Baglanti Havuzu*) |

Derin envanter (satir/byte olcumleri, akis semasi): `docs/01-MOTOR.md`;
dosya bicimleri `docs/02-DOSYA-FORMATI.md`; DLL katmani `docs/03-API-DLL.md`;
`db\` icerigi `docs/04-VERITABANI-DOSYALARI.md` â€” dortu de **06.10.2026**'da
tazelendi.

## Dogru Acilis Sirasi (4 tuzak)

```pascal
Kv := TVDb.Create;
Tb := TVTableDb.Create(Kv);
Sq := TVSql.Create(Tb);
try
  Kv.Open(Dir);    // veri klasoru (veritabani.odb burada aranir/olusturulur)
  Tb.Open(Dir);    // SART: semayi .odb icinden yukler
  ... Sq.Exec(...) ...
finally
  Sq.Free; Tb.Free; Kv.Free;
end;
```

1. `TVDb.Open` diye bir sey YOK. Dogrusu `TVDb.Create` + `Kv.Open(yol)`.
2. `Tb.Open(Dir)` SART. Atlanirsa sema yuklenmez: veri diskte dururken
   her sorgu `tablo yok` diye olur. (`CREATE TABLE` sirasinda fark edilmez,
   sunucu yeniden baslayinca patlar.)
3. `VDbWal.pas` olu kod. `ReplayWAL` stub: `.wal` varsa `False` doner,
   replay yapmaz. `WriteAheadWAL` her cagrida dosyayi bastan aciyordu
   (`fmCreate`); `PutRow` icindeki cagri kaldirildi.
4. `TVDb` + `TVTableDb` + `TVSql` sahipligi uygulamaya aittir (sirasiyla
   `Free` edilir); `Close` cagrisi zorunlu degildir ama `Tb.Close`
   sema sayaclarini kalici yapar.

## SQL Kapsami (ozet, ayrinti `SQL.md`)

`SELECT` (yildiz, alias, `DISTINCT`), `INNER/LEFT/RIGHT/FULL/CROSS JOIN`
(zincir serbest, soldan derin), `WHERE` (karsilastirma, `LIKE`, `IN`,
`BETWEEN`, `IS NULL`, `AND/OR/NOT`), `GROUP BY` + `HAVING` + aggregate
(`COUNT/SUM/AVG/MIN/MAX`), `ORDER BY` (+ `COLLATE TR`), `LIMIT/OFFSET`,
kume islemleri (`UNION [ALL]/EXCEPT/INTERSECT`), alt sorgular
(`IN (SELECT)`, skaler, `EXISTS` â€” iliskisiz), `WITH-CTE` (zincir,
`JOIN` ile birlikte), `CASE WHEN` (aranan + sade), pencere fonksiyonlari
(`ROW_NUMBER/RANK/DENSE_RANK/COUNT/SUM/AVG/MIN/MAX/LAG/LEAD OVER`),
`INSERT` (coklu `VALUES`, `INSERT...SELECT`), `UPDATE` (satir-basi
aritmetik), `DELETE`, `DML/DDL transaction` (`BEGIN/COMMIT/ROLLBACK`,
DDL dahil geri alma), `ALTER TABLE`, `CREATE/DROP INDEX`, `VACUUM`,
`REINDEX`, `VERIFY`, `BACKUP`, `SHOW/LIST`, `EXPORT/IMPORT JSON`,
`?` parametre, `UPPER/LOWER/LENGTH` (Turkce duyarli).

Yok (bilerek): iliskili alt sorgu, `WITH RECURSIVE`, pencere cercevesi
(`ROWS/RANGE`), CTE kolon alias'i.

## Hata Kodlari (`VDbErr.pas`)

Tum motor hatalari `EVDbException(ErrorCode)` ile firlar; mesaj metinleri
degismedi. Ornekler: `ecDuplicatePrimaryKey`, `ecUniqueViolation`,
`ecNotNullViolation`, `ecCheckViolation`, `ecForeignKeyViolation`,
`ecTableNotFound`, `ecColumnNotFound`, `ecSyntaxError`, `ecUnsupported`,
`ecDatabaseLocked`, `ecCorrupt`, `ecHashCollision`, `ecJsonError`.
`VDbErrorName(kod)` log/sunucu cevabi icin metin ad dondurur.

## Eszamanlilik

- `TVDb` (cekirdek) ve `TVTableDb` kendi kilitlerini tasir
  (`TCriticalSection`, recursive).
- `TVSql.Exec/ExecAll` cagrinin tamami tablo kilidi altinda calisir:
  ayni motoru paylasan thread'ler siralanir (okuma dahil).
- Dogrudan `TVTableDb` paylasan kod `Lock/Unlock` ile sarmalamalidir.
- Kaba taneli kilit: yazma sirasinda okumalar bekler.

## Baglanti Havuzu (`VDbPool.pas`)

`.odb` dosyasi exclusive kilitlidir: ayni dosyaya ikinci baglanti
acilamaz. Havuz bu yuzden tek motor (`TVDb`/`TVTableDb`) uzerinde `N`
adet `TVSql` ornegi yonetir â€” paralellik CARPMAZ, kaynak kullanimini
SINIRLAR (asiri yukte kuyruk + zaman asimi). Guvenlik P3 kilitleriyle
saglanir (her ornek bir thread'e aittir).

```pascal
Pool := TVDbPool.Create(TableDb, 8, 5000);  // boyut, zaman asimi (ms)
try
  Sq := Pool.Acquire;
  try
    R := Sq.Exec('SELECT ...', [...]);
  finally
    Pool.Release(Sq);
  end;
  R := Pool.Exec('SELECT ...');  // tek seferlik kisayol
finally
  Pool.Free;
end;
```

- `Acquire` bosta ornek yoksa `TimeoutMs` bekler, sonra `ecPoolTimeout`.
- `Close` yeni `Acquire` isteklerini reddeder (`ecPoolClosed`).
- Havuza ait olmayan ornek `Release` edilirse `ecInvalidArgument`.
- `Free` oncesi baglantilar geri verilmelidir.

## Turkce Destegi (`VDbText.pas`)

- `UPPER/LOWER`: `i->Ä°`, `I->Ä±` dogru cevrim (sistem yerel ayarindan bagimsiz).
- `LENGTH`: metinde karakter, `BLOB`'da bayt sayar.
- `ORDER BY x COLLATE TR`: Turk alfabesi sirasi
  (`...c,Ã§,d...g,ÄŸ,h,Ä±,i...o,Ã¶,p...s,ÅŸ,t...u,Ã¼,v...`); bilinmeyen ad hata
  verir. Indeks sirasi bayt duzeninde oldugu icin `COLLATE TR` indeksi
  kullanmaz (dogru ama yavas yola duser).
- Harf duyarsiz arama deyimi: `WHERE UPPER(ad) = UPPER('cocuk')`.
- `=` karsilastirmasi bayt-ayni kalir (degismedi).

---

## `.odb` Dosya Formati (`v2` â€” Bozulmadan)

```
[Header: 16 byte]
  Magic (4) = $42444F56 ('VODB' LE)
  Ver   (4) = 2 (VDB_FILE_VER)
  Flags (4) = 0 (varsayilan) | ENCRYPTED(4) | COMPRESSED(8)
  Crc   (4) = Header CRC32
[Kilitler: Append-Only]
  Magic (4) = $56444231
  Crc   (4) = Kayit CRC32
  Seq   (8) = Sira numarasi
  Key   (8) = Anahtar (UInt64)
  ValLen(4) = Veri uzunlugu
  Flags (1) = 0(PUT) | 1(DEL) | 2(BATCHEND)
  Value (ValLen byte)
```

---

## Dayaniklilik

Bu mimaride ayri WAL **gerekli degildir**: `.odb` dosyasinin kendisi
log'dur (append-only + `CRC32` + `BATCHEND` commit kaydi + acilis
recovery'si - Bitcask modeli). Ancak write-ahead gunluk de gercek bir
dosyadir ve **opt-in** olarak kullanilabilir.

### Omur ici (her zaman gecerli) guvenceler

- Kayit basi `CRC32`: bozuk kayit acilista tespit edilir, yirtik kuyruk
  budanir (`Verify` raporlar).
- Batch basi tek `fsync`: `COMMIT` ya hep ya hic yazar (`BATCHEND`
  isareti + recovery geri sarar).
- Commit-flush garantisi (P-DUR): basarili her `Exec` sonrasi kirli
  bayrak (`TVDb.Dirty`) kontrol edilir, yazma olduysa `Flush` cagrilir.
  `SyncWrite=False` olsa bile SQL katmaninda commit dayaniklidir;
  salt-okunur sorgularda syscall yok. Ham API (`TVTableDb` dogrudan)
  ile toplu yukleyenler bitince `Kv.Flush` cagirir.
- `Compact`: olu surumleri temizler (`.bak` birakir).
- JSON `.bak` zincirinden saglamdir; yedek icin `BACKUP`/`EXPORT JSON`
  kullanilir.

### Write-ahead gunluk (`WALEnabled`)

`WALEnabled = True` iken motor **her kalici yazmada** (`Put`, `DeleteKey`,
`CommitBatch`) once `.wal` gunlugune, **sonra** ana dosyaya yazar:

```
Put(k,v)  ->  .wal'a yaz (fsync)  ->  ana dosyaya yaz
```

Boylece yazma cagrisi donmeden sistem cokerse kayit `.wal`'da kalir ve
sonraki `ReplayWAL` ile kurtarilir. **WAL yazilamazsa islem hata doner
ve ana dosyaya hic yazilmaz** - yarim kayit olusmaz (tercih: "islem
basarisiz" > "sessiz veri kaybi").

| Konu | Davranis |
|---|---|
| Varsayilan | **KAPALI** (geriye donuk uyum; eski cagri kod degismez) |
| `CommitBatch` | Toplanan kayitlar **commit'te** gunluge yazar (batch ici yazmaz, gunkluge iki kez yazmaz) |
| `ReplayWAL` | Kendi kaydini gunluÄŸe **yeniden yazmaz** (dongu olusmaz) |
| `Close`/`Open` | Durum **sifirlanir**; yeni acilista gunkluge yazilmaz |
| Elle `WriteAheadWAL` | Otomatik mod acikken **kapatin** (cift yazim olur) |

> **Onemli uyari - `ReplayWAL` cift uygular.** Otomatik modda kayit
> ana dosyaya **zaten** yazildi; `ReplayWAL` ayni kayitlari **tekrar**
> uygular. `PUT`/`DEL` ayni sonucu verdigi icin veri bozulmaz, ama ayni
> kayit yeniden yazilir. Bu yuzden otomatik modda `CheckpointWAL`
> (gunlugu temizle) cogu zaman dogru islemdir; `ReplayWAL` yalniz
> "ana dosyaya yazilmamis kayit" senaryosu icin (yazma hatasi / surec
> cokmesi) yapilir. `had` arayuzu de bu ayrimi metinde belirtir.

`WalPath` = `ChangeFileExt(<odb yolu>, '.wal')`, yani `veritabani.odb`
icin `veritabani.wal`dir.

---

## Åifreleme (`VDbCrypt.pas` + `VDB_FLAG_ENCRYPTED`)

Kayit duzeyinde AES-256-CTR + HMAC-SHA256 (encrypt-then-MAC);
`kayit = IV(16) || len(4) || AES-256-CTR || Tag(32)`.

- Anahtar 2 katman: parola â†’ PBKDF2 (tuz + iterasyon) â†’ **master**,
  oradan `K_enc` / `K_mac` turetilir. `.key` dosyasi **sir tutmaz**
  (58 bayt: `VDBK` + surum + tuz + iterasyon + dogrulayici).
- Her kayit kendi `VDB_FLAG_ENCRYPTED` bayragini tasir â†’ **karisik**
  (sifreli + duz) dosyalar sorunsuz okunur; `Compact`/`BackupTo`
  bayragi korur.
- API: `CreateKeyFile/OpenKeyFile('...key','parola')`,
  `SetEncryptionKey(32 bayt)`, `ClearEncryptionKey`,
  `IsEncrypted`, `HasEncryptedRecords`, `KeyPath`,
  `EncryptionKeyFingerprint` (ilk 8 hex), `RekeyWithPassword`.
- SQL: `ALTER DATABASE KEY 'yeniParola'` â€” tum sifreli kayitlari
  yeni anahtarla yeniden yazar; `.key` guncellenir, eski `.odb`/`.key`
  `.bak` olarak kalir.
- **Anahtarsiz acilista** sifreli kayda `SIFRELI: anahtar yok` hatasi
  doner (sessizce bozuk veri degil). `Verify` raporu `sifreli=N` sayaci
  tasir.
- **WAL bilerek duz metin** yazar (acil durum kurtarma); tehdit modeli
  icin `SIFRELEME_PLANI.md` bolumune bak.

| Test | Kapsam | Durum |
|---|---|---|
| `sqltest` (T74/T75/T76/T77) | sifreli yaz-oku, dayaniklilik, WAL replay, `ALTER DATABASE KEY` | âœ… dahil (997/0) |
| `vdbcrypttest.lpr` | PBKDF2/HMAC/AES vektÃ¶rleri, `.key`, etiket, 68-konum dongusu | âœ… **60/60** |

---

## `CDC` / `Time Travel` (`VDbCdc.pas`, `VDbTimeTravel.pas`)

WAL Ã¼zerinden **deÄŸiÅŸiklik yakalama** ve **Ã¶nceki deÄŸerlere eriÅŸim** â€” ikisi de
2026-10-05'te kÃ¶kten onarÄ±ldÄ± (eski hÃ¢lleri test edilmeden "geÃ§iyordu").

### CDC (Change Data Capture)

```pascal
Cdc := TVDbCdc.Create(Tb);
Cdc.OnChange := @OlayYakala;   // procedure(const Ev: TCDCEvent)
Cdc.Start;                     // otomatik WAL'i AÃ‡AR
...
Cdc.Stop;                      // kalan olaylarÄ± iÅŸler + flush
```

| Konu | DavranÄ±ÅŸ |
|---|---|
| Kaynak | `.wal` dosyasÄ± (`TVDbWalHead` bicimi: `WALR` + Key + duz bayrak + Len + CRC) |
| Olay tipleri | `cdcInsert` (ilk gÃ¶rÃ¼lÃ¼ÅŸ), `cdcUpdate` (daha Ã¶nce gÃ¶rÃ¼lmÃ¼ÅŸ), `cdcDelete` |
| `OldValues` | PUT'larÄ±n Ã¶nceki hÃ¢li â€” silme kaydÄ± WAL'de boÅŸ olduÄŸu iÃ§in `FSeen` haritasÄ±ndan beslenir |
| SatÄ±r dÄ±ÅŸÄ± kayÄ±tlar | Åema kayÄ±tlarÄ± (`VSCH1...`) olay deÄŸildir, `SkippedCount` sayÄ±sÄ±na girer |
| Anahtar | Gerekmez: WAL **bilerek dÃ¼z metindir**, CDC anahtarsÄ±z Ã§alÄ±ÅŸÄ±r |
| GÃ¶zlemlenebilirlik | `EventCount`, `SkippedCount`, `PendingCount`, `FlushIntervalMs`, `DroppedCount` |
| **Teslim modu (2026-10-06)** | `OnChange` atanmÄ±ÅŸsa `Flush` olaylarÄ± callback'e taÅŸÄ±r; **atanmamÄ±ÅŸsa tampon olaylarÄ± tutar** ve `TryPeek`/`TryDequeue` ile istemci sÄ±rayla Ã§eker (**poll**) â€” DLL'deki `VdbCdcStart/VdbCdcPollSize/VdbCdcPoll/VdbCdcStop/VdbCdcStats` bu yoldur (bkz. `DLL_KULLANIM.md`). Tampon `MaxPending` (varsayÄ±lan 100000) sÄ±nÄ±rÄ±nÄ± aÅŸarsa **en eski** olay dÃ¼ÅŸer ve `DroppedCount` artar â€” sessiz kayÄ±p yoktur |

**SÄ±nÄ±rlar (gizlenmez):** WAL yalnÄ±zca **son checkpoint'ten sonraki** yazilari
tutar; CDC "tarihin tamamÄ±nÄ±" deÄŸil o pencereyi yakalar. Silme olayÄ±nÄ±n PK'si
yalnÄ±zca daha Ã¶nce WAL'e dÃ¼ÅŸen bir PUT varsa Ã¼retilebilir (CDC'yi yazmadan
Ã¶nce baÅŸlatmak en doÄŸrusu).

### Time Travel

```pascal
Tt := TVTimeTravel.Create(Tb);
ham := Tt.GetValueAt('tablo', 'pk', 6);            // WAL indeksi 6'ya kadar
Tt.GetRowAt('tablo', 'pk', 6, Degerler);           // satÄ±r olarak Ã§Ã¶zÃ¼lmÃ¼ÅŸ
Tt.HistoryCount;                                    // okunabilir geÃ§miÅŸ sayÄ±sÄ±
```

| Konu | DavranÄ±ÅŸ |
|---|---|
| `Seq` | WAL kayÄ±t **indeksi** (0 tabanlÄ±, `0 .. WalRecordCount-1`) â€” WAL'de sÄ±ra numarasÄ± alanÄ± yoktur |
| `GetValueAt` | O indekse kadarki **en son** yazÄ±mÄ± dÃ¶ndÃ¼rÃ¼r; bulunamazsa/silinmiÅŸse boÅŸ |
| `AS OF TIMESTAMP/VERSION/SEQUENCE` | `ParseSnapshotSpec` yalnÄ±zca metni doÄŸrular (ISO tarih; yerel ayar yedeÄŸi) |
| `SELECT ... AS OF SEQUENCE` | **SQL'e baÄŸlÄ±dÄ±r (2026-10-06):** tek tablo sorgularÄ± WAL geÃ§miÅŸindeki ana okur (`VDbExecutor.BuildAsOfRows`). `TIMESTAMP`/`VERSION`, `JOIN`, `WITH` ve geÃ§miÅŸ yoksa `ecUnsupported` ile **aÃ§Ä±kÃ§a hata verir** â€” sessizce yanlÄ±ÅŸ cevap dÃ¶nmez. AyrÄ±ntÄ±: `SQL.md` â†’ Â§0b |
| GeÃ§miÅŸ sÃ¼resi | `CheckpointWAL` geÃ§miÅŸ siler â†’ `HistoryCount = 0` (testle belgeli) |

API: `TVDb.ReadWalEntry` + `TVDb.WalRecordCount` (WAL baÅŸlÄ±ÄŸÄ± `VDbCore`
interface'ine taÅŸÄ±ndÄ±; doÄŸrulama tek yerde). Test: `cdc_test.lpi` **38/38**
(geÃ§ici klasÃ¶rde Ã§alÄ±ÅŸÄ±r, paylaÅŸÄ±lan veritabanÄ±na dokunmaz).
**DLL (2026-10-06):** `VdbValueAt(h, tbl, pk, seq, buf, len)` â€” WAL'deki
satÄ±r deÄŸeri JSON dizisi olarak, `VdbGet` sÃ¶zleÅŸmesiyle (`len=0` â†’
`-boyut`, `-1` = o noktada satÄ±r yok); `VdbHistoryCount(h)` â€” okunabilir
geÃ§miÅŸ sayÄ±sÄ±. SarmalayÄ±cÄ±: `TVDb.ValueAt` / `TVDb.HistoryCount`.

### `SELECT ... AS OF SEQUENCE` (SQL, 2026-10-06)

```sql
SELECT * FROM k AS OF SEQUENCE 12 ORDER BY id;      -- WAL indeksi 12'ye kadar
SELECT ad FROM k AS x AS OF SEQUENCE 12 WHERE id = 1;
SELECT COUNT(*) FROM k AS OF SEQUENCE 12;
```

- Tek tablo sorgusu; `WHERE`/`ORDER BY`/`LIMIT`/`GROUP BY`/aggregate
  geÃ§miÅŸ veriye aynen uygulanÄ±r (Ã¶nce geÃ§miÅŸ kurulur, sonra normal yol).
- **SilinmiÅŸ satÄ±r** o anki deÄŸeriyle geri gelir; **sonradan eklenen**
  satÄ±r o an gÃ¶rÃ¼nmez; UPDATE Ã¶ncesi deÄŸer okunur.
- `TIMESTAMP`/`VERSION` (WAL'de zaman damgasÄ±/sÃ¼rÃ¼m yok), `JOIN`, `WITH`,
  geÃ§miÅŸ yoksa (WAL kapalÄ± / checkpoint sonrasÄ±) ve `ALTER` sonrasÄ± farklÄ±
  kolon sayÄ±sÄ± â†’ **`ecUnsupported`** ile aÃ§Ä±k hata (sessiz yanlÄ±ÅŸ cevap yok).
- GeÃ§miÅŸ yalnÄ±zca **son checkpoint'ten** beriyi kapsar; ayrÄ±ntÄ± ve bilinen
  sÄ±nÄ±rÄ± `SQL.md` â†’ Â§0b "*`SELECT ... AS OF SEQUENCE`*". Test: `sqltest`
  **T78** (31 kontrol, dahil).

---

## `Faz D`: Motor Yenilikleri (`Iskelet`)

| Ozellik | `Flags` / `Durum` | `Acilama` |
|---|---|---|
| `Encryption` | `VDB_FLAG_ENCRYPTED = 4` | **Uygulandi**: `AES-256-CTR` + `HMAC-SHA256` (encrypt-then-MAC), `.key` + PBKDF2, `ALTER DATABASE KEY` â€” bkz. *Åifreleme* bolumu |
| `Compression` | `VDB_FLAG_COMPRESSED = 8` | `ZLIB` (`Value` sikistirilmis) â€” `Iskelet` |
| `Streaming` | `StreamCursor(StartKey, PageSize)` | `Pagination` (`O(1)` `Cursor`, `Memory` `OOM` onler) â€” `Iskelet` |
| `AutoBackup` | `AutoBackup(BackupDir)` | `Timer` tabanli `.bak` (`FPath` `.auto.bak`) â€” `Iskelet` |
| `Memory-Mapped` | `MMF` (`Windows` `mmap`) | `Zero-Copy` (`Read` `2-5x` hizli) â€” `Iskelet` |
| `Query Planner` | `VDbSql.pas` (`Plan` `Cost-Based`) | `Index Scan` vs `Table Scan` â€” `Iskelet` (`VDbAst.pas` bagli) |

---

## `Test`

| Paket | Kapsam | Durum |
|---|---|---|
| `sqltest.lpi` | 85+ grup, **1446 kontrol** (tipler, kisitlar, `FK`, `JOIN`, `CROSS JOIN`, `GROUP BY`/aggregate (JOIN dahil, HAVING dogrudan agg), kume, `ALTER`, transaction, alt sorgu, `CASE`, `CTE`, pencere, `RIGHT/FULL`, collation, `MIN/MAX` tip kiyasi, `BLOB`, crash kurtarma, legacy gecis, F1/F2/F3 regresyon, sema sorgulari (`DESCRIBE` / `SHOW INDEXES` / `SHOW CREATE TABLE`), **WAL replay** â€” yirtik kuyruk, CRC bozuk kayit, bozuk magic, anlamsiz bayrak, deger tasiyor silme kaydi, checkpoint kaliciligi, **otomatik WAL**: varsayilan kapali, Put/Delete'un otomatik gunluge girmesi, batch kayitlarinin CommitBatch'te gunluge girmesi, WAL yazilamayinca ana dosyaya yazilmamasi, kapat-ac sonrasi sifirlanma, **ÅŸifreleme**: sifreli yaz-oku, `.key` ile parola modu, dayaniklilik, WAL replay + ÅŸifreli, `ALTER DATABASE KEY`, **`AS OF SEQUENCE`** (T78: gecmis goruntu, silinen satirin donmesi, TIMESTAMP/VERSION/JOIN reddi, WAL yoksa hata)) | âœ… **997/0** |
| `vdbapitest.lpr` | DLL C ABI (170 kontrol; ÅŸifreleme + CDC/TimeTravel poll export'larÄ± dahil, 42 export Ã§Ã¶zÃ¼lÃ¼r) | **170/170** |
| `vdbclienttest.lpr` | Delphi `VDBClient` birimi (101 kontrol; CDC/TimeTravel sarmalayÄ±cÄ± grubu dahil) | **101/101** |
| `vdbcrypttest.lpr` | kripto birimi (PBKDF2/HMAC/AES/.key vektÃ¶rleri) | âœ… **60/60** |
| `cdc_test.lpi` | CDC + Time Travel (3 INSERT/1 UPDATE/1 DELETE olayÄ±, `OldValues`, sema kaydÄ± atlanma, WAL geÃ§miÅŸinde Ã¶nceki deÄŸer, `AS OF` ayrÄ±ÅŸtÄ±rma, checkpoint sÄ±nÄ±rÄ±; **geÃ§ici klasÃ¶rde**) | âœ… **38/38** |
| dscheck (harici) | `TVDbQuery`: gezinti, bookmark, tipler, parametre, duzenleme, hata yollari (53 kontrol) | âœ… 53/53 |
| `vmtcheck` (harici) | 8 thread x 250 eszamanli `INSERT`/`SELECT` | âœ… kayipsiz |
| `vdbgui.lpi` | Basit yonetim GUI'si | âœ… derleniyor + linkleniyor |
| `had.lpi` | Gelismis yonetim arayuzu | âœ… derleniyor + linkleniyor |
| `mtakipwebsrv.lpi` | Web sunucusu | âœ… derleniyor + linkleniyor (`OtherUnitFiles=..\..` + `LazUtils` + DCPcrypt yolu eklendi) |

> **F1 (KRITIK) denetim kalemlerinin 23/23'u uygulandi ve her biri mutasyon
> testiyle dogrulandi** (duzeltme geri alininca ilgili test kirmizi oluyor).
> Test sayisi 409 -> 830 -> 859 yukseldi (+450 assertion). Kanit tablosu:
> `DENETIM_VE_YOL_HARITASI.md` -> *F1 MUTASYON DOGRULAMA*.
> Degisikliklerin tamami `private` oldugu icin public API degismedi.
>
> **Bu turda bulunan, raporda olmayan ek hata:** SQL `UPDATE` satiri
> `Delete`+`Insert` ile yaziyordu; bu yuzden `ON DELETE CASCADE` bir
> UPDATE'in *silme* yarisiyla tetikleniyor ve **ilgisiz kolon**
> guncellenirken cocuk satirlari SILINIYORDU. Satir mantigi
> `TVTableDb.UpdateRowInPlace` ile tek kaynaga baglandi.

> **2026-10-04 WAL turunda bulunan iki gercek veri kaybi hatasi** (her ikisi
> de mutasyonla kanitlandi, ayrinti `DENETIM_VE_YOL_HARITASI.md`):
> 1. `ReplayWAL` uygulama dongusu `off-by-one` idi: gecersiz/yirtik son
>    kayit da bir tur DAHA uygulaniyor, cop veri ana dosyaya yaziliyordu.
> 2. `ReplayWAL` kayitlari `AppendRec` ile dogrudan yaziyordu; `CommitBatch`
>    `FPending` bos oldugu icin **BATCHEND yazmiyordu**. Dosyada daha once
>    bir BATCHEND varsa `Recover` bu kayitlari "commit edilmemis batch"
>    sayip **geri saruyor**, yani replay edilen veri yeniden acilista
>    KAYBOLUYORDU. Artik `AppendBatchEnd` elle yaziliyor.

## `Derleme` (`Build`)

```
lazbuild sqltest.lpi          # test paketi -> sqltest.exe
lazbuild cdc_test.lpi         # CDC + Time Travel testi -> cdc_test.exe (gecici klasor)
lazbuild vdbgui.lpi           # basit yonetim GUI'si
lazbuild vdbcomponents.lpk    # TDataSet paketi (RunTime)
```

`sqltest.lpi` `LazUtils` pakedine baglidir (dosya kilidi `FileUtil`
uzerinden gelir). `.lpi`'si olmayan testler (`vdbapitest`, `vdbclienttest`,
`vdbcrypttest`) dogrudan `ppc386` ile derlenir; DLL `build_dll.ps1` iledir.

---

## `TVDbQuery` â€” `TDataSet` Baglantisi (`VDbDataSet.pas`)

Standart veri bilesenleri (`TDBGrid`, `TDBEdit`, `TDBNavigator`,
`TDataSource`, FastReport) dogrudan baglanir. Paket:
`vdbcomponents.lpk` (RunTime; palet icin IDE'de `RunAndDesignTime`
secilir, bilesen `VDb` sayfasina gelir).

```pascal
Qry := TVDbQuery.Create(nil);
try
  Qry.SqlEngine := Sq;  // hazir TVSql ornegi (P3 kilidi paylasilir)
  Qry.SQL.Text := 'SELECT id, ad, maas FROM personel ORDER BY id';
  Qry.Open;
  DataSource1.DataSet := Qry;   // DBGrid'e bagla
  Qry.Edit;
  Qry.FieldByName('maas').AsFloat := 9500;
  Qry.Post;                     // UPDATE'ye cevrilir
finally
  Qry.Free;
end;
```

| Ozellik | Davranis |
|---|---|
| `Gezinti` | `First/Next/Prior/Last`, `RecNo/RecordCount`, bookmark |
| `Params` | `SQL`'deki `?` yer tutucularina sirayla karsilik gelir; sayi tutmazsa `ecInvalidArgument` |
| `Tipler` | Tek-tablo/sade sorguda semadan: `ftLargeint/ftFloat/ftBoolean/ftDate/ftTime/ftDateTime`; ifade/`JOIN` kolonlari `ftString` duser |
| `Duzenleme` | Tek tablo + sade kolonlar + ciktida `PK` sarti saglanirsa `Insert/Edit/Post/Delete` calisir (`CanModify=True`); saglanmazsa salt-okunur |
| `INSERT` | Yalniz dokunulan kolonlar yazilir (`DEFAULT` motora kalir); bos `AUTOINC` `PK` atlanir, deger uretilir |
| `PK` | Guncellenemez (`ecUnsupported`); once silip yeniden ekle |
| `NULL` | Motor `''` tasir: bos hucre `IsNull=True` |
| `Hata` | Tumu `EVDbException` + `ErrorCode` (metinler degismedi) |

Kurallar/kisitlar:
- `Open` yalniz satir donduren sonuc kabul eder (`SELECT`/`SHOW`/`LIST`).
  `INSERT` cumlesiyle `Open` denemesi cumleyi CALISTIRIR, sonra
  `ecInvalidArgument` verir (yan etkilidir).
- `Post` sirasinda kisit ihlali (or. `UNIQUE`, `NOT NULL`, `FK`) aynen
  yukari firlar; kayit duzenleme durumunda kalir (`Cancel` ile vazgec).
- `Post-insert` sonrasi imlec yeni satirdadir; `Post-update` konumu korur.
- Thread: ayni `TVSql`/`TVTableDb` paylasilabilir (`Exec` P3 kilidi altindadir).







