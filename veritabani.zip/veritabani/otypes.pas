unit oTypes;

{$mode ObjFPC}{$H+}

interface

uses
  SysUtils, Variants, Classes, Generics.Collections, fpjson, jsonparser;

type
  //--- Mevcut SQL tipi listeni koruyorum, ek ihtiyaç varsa buraya ekleyebilirsin
  TAlanOzelligi = set of (aoPrimaryKey, aoAutoIncrement, aoNotNull);
  TOperator = (opEqual, opNotEqual, opGreater, opLess,
    opGreaterEqual, opLessEqual, opLike, opIn,
    opIsNull, opIsNotNull, opBetween);
  TLogicOp = (loNone, loAnd, loOr, loNot);
  TAggregateTip = (agNone, agCount, agSum, agAvg, agMin, agMax);
  TFiltreNodeType = (ntKosul, ntGrup);
  TAlanTuru = (ftAutoIncrement, ftChar, ftText, ftInteger,
    ftFloat, ftDouble, ftCurrency, ftBoolean,
    ftDate, ftTime, ftTimestamp, ftUUID,
    ftList, ftJSON, ftBlob, ftFile, ftImage,
    ftPhone, ftNull, ftUnknown);
  TSorguTipi = (skBilinmiyor, skSelect, skInsert, skUpdate,
    skDelete, skCreateTable, skDropTable, skAlterTable,
    skShowTables, skExportJson, skImportJson, skHelp);

  //-------------- YENİ: .odb paketi manifest kayıtları ------------------

  // Tek bir tablo hakkında paket içinde tutulan meta
  TTableManifest = record
    TableName: string;    // Örn. 'Users'
    SchemaFile: string;    // 'tables/Users.schema.json'
    DataFile: string;    // 'tables/Users.data.bin'
    RecordCount: cardinal;  // Kaç satır var
    LastRecordId: int64;     // Otomatik artan alanın son değeri
  end;

  // Tüm paketin manifest bilgisi
  TDbManifest = record
    UID: string;              // Paket benzersiz kimliği
    DatabaseName: string;              // Paket içinde kullanılan DB adı
    CreatedAt: TDateTime;           // Oluşturulma zamanı
    Version: string;              // Format versiyonu (örn. '1.0')
    Tables: specialize TArray<TTableManifest>;
  end;

  //-------------- ORİJİNAL: Alan tanımı (senin eski TAlanTanimi) ------------

  TAlanTanimi = record
    Name: string;
    Tip: TAlanTuru;
    NotNull: boolean;
    PrimaryKey: boolean;
    AutoIncrement: boolean;
    Unique: boolean;
    DefaultDeger: variant;
    ForeignKey: string;   // "yazarlar.id"
    CheckIfade: string;
    Comment: string;
    Length: integer;  // TEXT, CHAR için
    Index: boolean;
    TakmaAd: string;   // alias
  end;

  TCondition = record
    Column: string;
    Op: string;    // '=', '<', '>=', vb.
    Value: string;    // literal veya parametre
  end;

  // Dinamik dizi olarak
  TConditionArray = array of TCondition;
  //-------------- YENİ: Satır verilerini dinamik saklayacak sınıf -----------


 type
  TAlanVerisi = record
    Ad: string;
    Icerik: Variant;
  end;

  TRow = class
  private
    FValues: specialize TDictionary<string, variant>;
    FData: specialize TDictionary<string, variant>;

  public
    constructor Create;
    destructor Destroy; override;
    /// Alan–değer ikilisini ekler / günceller
    procedure Add(const Key: string; const Value: variant);

    function Get(const Key: string): variant;
    function ContainsKey(const Key: string): boolean;
    procedure Assign(Source: TRow);
    function ToJSON: TJSONObject;
    class function FromJSON(json: TJSONObject): TRow;
    /// Okuma / Null dönerse Variant olarak Null
    function GetFieldNames: specialize TArray<string>;
    property Values[const FieldName: string]: variant read Get; default;
  end;

  //-------------- YENİ: SQL yürütme sonuç kaydı ----------------------------

  // type
  // TRowList = specialize TList<TRow>;

type
  TCustomRowList = class(specialize TObjectList<TRow>)
    function ToJSON: TJSONArray;
  end;

  // type
  //  TRowList = specialize TObjectList<TRow>;
type
  TRowList = TCustomRowList;

function AlanOlustur(const Ad, TipStr: string; PK: Boolean = False; AutoInc: Boolean = False): TAlanTanimi;
procedure AppendMessage(var A: specialize TArray<string>; const Msg: string);
function StrToAlanTuru(const s: string): TAlanTuru;
function AlanBoyutu(const Tip: TAlanTuru): integer; overload;
function AlanBoyutu(const Alan: TAlanTanimi): integer; overload;
function AlanVarsayilanUzunluk(const Tip: TAlanTuru): integer;
function AlanDegeriToStr(const A: TAlanTanimi): string;
function AlanTuruToStr(Tur: TAlanTuru): string;
function DefaultForType(T: TAlanTuru): variant;
function ParseDegerTipli(const Tip: TAlanTuru; const S: string): variant;
/// S: genelde tırnaklı metin, sayısal string ya da NULL
function StrToVariant(const S: string; const Def: TAlanTanimi): variant;
function VarToStrJSON(const V: variant): string;
function JSONToVariant(val: TJSONData): variant;

implementation

uses TypInfo, DateUtils;

  { TRow }


function VarToStrJSON(const V: variant): string;
begin
  case VarType(V) of
    varEmpty, varNull:
      Result := 'null';
    varBoolean:
      if boolean(V) then Result := 'true'
      else
        Result := 'false';
    varString, varUString:
      Result := '"' + StringReplace(V, '"', '\"', [rfReplaceAll]) + '"';
    varDouble, varCurrency, varSingle:
      Result := FloatToStr(V); // Lokal ayraç varsa yerine '.' kullanılabilir
    varInteger, varByte, varSmallInt, varLongWord, varInt64:
      Result := IntToStr(V);
    else
      Result := '"' + VarToStr(V) + '"'; // Varsayılan olarak string
  end;
end;

function JSONToVariant(val: TJSONData): variant;
begin
  case val.JSONType of
    jtNull: Result := Null;
    jtBoolean: Result := val.AsBoolean;
    jtNumber: Result := val.AsFloat;
    jtString: Result := val.AsString;
    else
      Result := VarToStr(val.AsJSON); // varsayılan olarak stringe çevir
  end;
end;


procedure AppendMessage(var A: specialize TArray<string>; const Msg: string);
begin
  SetLength(A, Length(A) + 1);
  A[High(A)] := Msg;
end;

constructor TRow.Create;
begin
  inherited Create;
  FValues := specialize TDictionary<string, variant>.Create;
end;

destructor TRow.Destroy;
begin
  FValues.Free;
  inherited Destroy;
end;

procedure TRow.Add(const Key: string; const Value: variant);
begin
  FValues[Key] := Value;
end;


function TRow.Get(const Key: string): variant;
begin
  if FValues.ContainsKey(Key) then
    Result := FValues[Key]
  else
    Result := Null;
end;

function TRow.ContainsKey(const Key: string): boolean;
begin
  Result := FValues.ContainsKey(Key);
end;

procedure TRow.Assign(Source: TRow);
var
  key: string;
begin
  FValues.Clear;
  for key in Source.FValues.Keys do
    FValues[key] := Source.FValues[key];
end;

function TRow.GetFieldNames: specialize TArray<string>;
begin
  Result := FValues.Keys.ToArray;
end;

function TRow.ToJSON: TJSONObject;
var
  key: string;
begin
  Result := TJSONObject.Create;
  for key in FValues.Keys do
    Result.Add('val_' + key, VarToStrJSON(FValues[key]));
  for key in FData.Keys do
    Result.Add('meta_' + key, VarToStrJSON(FData[key]));
end;

function TCustomRowList.ToJSON: TJSONArray;
var
  i: integer;
begin
  Result := TJSONArray.Create;
  for i := 0 to Self.Count - 1 do
    Result.Add(Self[i].ToJSON); // her satır kendi JSON çıktısını döner

end;

class function TRow.FromJSON(json: TJSONObject): TRow;
var
  i: integer;
  field: string;
begin
  Result := TRow.Create;
  for i := 0 to json.Count - 1 do
  begin
    field := json.Names[i];
    Result.Add(field, JSONToVariant(json.Items[i]));
  end;
end;


function AlanOlustur(const Ad, TipStr: string; PK: Boolean = False; AutoInc: Boolean = False): TAlanTanimi;
begin
  Result.Name := Ad;
  Result.Tip := StrToAlanTuru(TipStr);
  Result.Length := AlanVarsayilanUzunluk(Result.Tip);
  Result.PrimaryKey := PK;
  Result.AutoIncrement := AutoInc;
end;
function AlanVarsayilanUzunluk(const Tip: TAlanTuru): integer;
begin
  case Tip of
    ftText: Result := 255;
    ftInteger: Result := 4;
    ftFloat: Result := 8;
    ftCurrency: Result := 8;
    ftBoolean: Result := 1;
    ftDate,
    ftTime,
    ftTimestamp: Result := 12;
    ftAutoIncrement: Result := 4;
    else
      Result := 8;
  end;
end;

function AlanBoyutu(const Tip: TAlanTuru): integer;
begin
  case Tip of
    ftAutoIncrement: Result := SizeOf(integer);  // 4
    ftChar: Result := 1;                // tek karakter
    ftText: Result := 255;              // varsayılan metin uzunluğu
    ftInteger: Result := SizeOf(integer);  // 4
    ftFloat: Result := SizeOf(double);   // 8
    ftCurrency: Result := SizeOf(double);   // 8
    ftBoolean: Result := SizeOf(boolean);  // 1
    ftDate: Result := SizeOf(TDateTime); // 8
    ftTime: Result := SizeOf(TDateTime); // 8
    ftTimestamp: Result := SizeOf(TDateTime); // 8
    ftUUID: Result := 16;               // 16 byte GUID
    ftList: Result := 0;                // dinamik
    ftJSON: Result := 0;                // dinamik
    ftBlob: Result := 0;                // dinamik
    ftFile: Result := 0;                // dinamik
    ftImage: Result := 0;                // dinamik
    ftPhone: Result := 20;               // örnek telefon uzunluğu
    ftNull: Result := 0;                // hiç
    ftUnknown: Result := 0;                // bilinmiyor
    else
      Result := 0;
  end;
end;


function AlanBoyutu(const Alan: TAlanTanimi): integer;
begin
  Result := AlanBoyutu(alan.tip);
end;

function StrToVariant(const S: string; const Def: TAlanTanimi): variant;
var
  tmp: string;
begin
  case Def.Tip of
    ftText:
    begin
      // Eğer tırnaklıysa kırpıyoruz, yoksa direk veriyoruz
      if (Length(S) >= 2) and (S[1] = '''') and (S[Length(S)] = '''') then
        Result := Copy(S, 2, Length(S) - 2)
      else
        Result := S;
    end;

    ftInteger:
    begin
      // ondalıklı nokta veya virgül olabilir
      tmp := StringReplace(S, ',', '.', [rfReplaceAll]);
      Result := StrToIntDef(tmp, 0);
    end;

    ftFloat:
    begin
      tmp := StringReplace(S, ',', '.', [rfReplaceAll]);
      Result := StrToFloatDef(tmp, 0.0);
    end;

    else
      // Diğer türler için Null atıyoruz
      Result := Null;
  end;
end;

function DefaultForType(T: TAlanTuru): variant;
begin
  case T of
    ftText: Result := '';
    ftInteger: Result := 0;
    ftFloat: Result := 0.0;
    else
      Result := Null;
  end;
end;




function AlanDegeriToStr(const A: TAlanTanimi): string;
begin
  Result := A.Name + ': ' + TypInfo.GetEnumName(TypeInfo(TAlanTuru), Ord(A.tip));
end;


function AlanTuruToStr(Tur: TAlanTuru): string;
begin
  case Tur of
    ftAutoIncrement: Result := 'AutoIncrement';
    ftText: Result := 'Text';
    ftChar: Result := 'Char';
    ftInteger: Result := 'Integer';
    ftFloat: Result := 'Float';
    ftDouble: Result := 'Double';
    ftCurrency: Result := 'Currency';
    ftBoolean: Result := 'Boolean';
    ftDate: Result := 'Date';
    ftTime: Result := 'Time';
    ftTimestamp: Result := 'Timestamp';
    ftUUID: Result := 'UUID';
    ftList: Result := 'List';
    ftJSON: Result := 'JSON';
    ftBlob: Result := 'Blob';
    ftFile: Result := 'File';
    ftImage: Result := 'Image';
    ftPhone: Result := 'Phone';
    ftNull: Result := 'Null';
    ftUnknown: Result := 'Unknown';
  end;
end;

function StrToAlanTuru(const s: string): TAlanTuru;
begin
  if SameText(s, 'ftAutoIncrement') or SameText(s, 'AutoIncrement') then
    Exit(ftAutoIncrement)
  else if SameText(s, 'ftText') or SameText(s, 'Text') then
    Exit(ftText)
  else if SameText(s, 'ftChar') or SameText(s, 'Char') then
    Exit(ftChar)
  else if SameText(s, 'ftInteger') or SameText(s, 'Integer') then
    Exit(ftInteger)
  else if SameText(s, 'ftFloat') or SameText(s, 'Float') then
    Exit(ftFloat)
  else if SameText(s, 'ftdouble') or SameText(s, 'Double') then
    Exit(ftDouble)
  else if SameText(s, 'ftCurrency') or SameText(s, 'Currency') then
    Exit(ftCurrency)
  else if SameText(s, 'ftBoolean') or SameText(s, 'Boolean') then
    Exit(ftBoolean)
  else if SameText(s, 'ftDate') or SameText(s, 'Date') then
    Exit(ftDate)
  else if SameText(s, 'ftTime') or SameText(s, 'Time') then
    Exit(ftTime)
  else if SameText(s, 'ftTimestamp') or SameText(s, 'Timestamp') then
    Exit(ftTimestamp)
  else if SameText(s, 'ftUUID') or SameText(s, 'UUID') then
    Exit(ftUUID)
  else if SameText(s, 'ftList') or SameText(s, 'List') then
    Exit(ftList)
  else if SameText(s, 'ftJSON') or SameText(s, 'JSON') then
    Exit(ftJSON)
  else if SameText(s, 'ftBlob') or SameText(s, 'Blob') then
    Exit(ftBlob)
  else if SameText(s, 'ftFile') or SameText(s, 'File') then
    Exit(ftFile)
  else if SameText(s, 'ftImage') or SameText(s, 'Image') then
    Exit(ftImage)
  else if SameText(s, 'ftPhone') or SameText(s, 'Phone') then
    Exit(ftPhone)
  else if SameText(s, 'ftNull') or SameText(s, 'Null') then
    Exit(ftNull)
  else if SameText(s, 'ftUnknown') or SameText(s, 'Unknown') then
    Exit(ftUnknown)
  else
    // raise Exception.Create('Unknown field type: ' + s);
    raise Exception.Create('Bilinmeyen alan turu: ' + s);

end;


/// Alan tipine göre string → Variant dönüşümü
function ParseDegerTipli(const Tip: TAlanTuru; const S: string): variant;
var
  d, dt: TDateTime;
begin
  case Tip of
    ftText, ftChar, ftUUID, ftJSON, ftBlob, ftFile, ftImage, ftPhone, ftList:
      // Metinsel tipler olduğu gibi döner
      Result := S;

    ftInteger:
      // Tam sayı
      if S = '' then
        Result := 0
      else
        Result := StrToIntDef(S, 0);

    ftFloat, ftCurrency:
      // Ondalıklı sayı
      if S = '' then
        Result := 0.0
      else
        Result := StrToFloatDef(StringReplace(S, ',', DecimalSeparator, []), 0.0);

    ftBoolean:
      // TRUE/FALSE veya 1/0
      if SameText(S, 'TRUE') or (S = '1') then
        Result := True
      else
        Result := False;

    ftDate:
      // Tarih: 'YYYY-MM-DD' veya yerel format
      if TryStrToDate(S, d) then
        Result := d
      else
        Result := Date;  // hata ise bugünün tarihi

    ftTime:
      // Saat
      if TryStrToTime(S, d) then
        Result := d
      else
        Result := Time;  // hata ise şu an

    ftTimestamp:
      // Tarih+Saat
      if TryISO8601ToDate(S, dt) then
        Result := dt
      else if TryStrToDateTime(S, dt) then
        Result := dt
      else
        Result := Now;


    ftUnknown:
      // Bilinmeyen tipte raw string döner
      Result := S;

    else
      // Diğer tiplerde de string’i döndür
      Result := S;
  end;
end;

end.
