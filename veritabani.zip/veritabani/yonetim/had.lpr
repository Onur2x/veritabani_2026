program had;
{$R+}
uses
  Interfaces, Forms, hadmain;
begin
  Application.Initialize;
  Application.CreateForm(TfrmMain, frmMain);
  Application.Run;
end.

