unit fRowEditor;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, StdCtrls, ExtCtrls,
  Generics.Collections, oTypes, oViewModel;

type
  TFormRowEditor = class(TForm)
    PanelMain: TPanel;
    ButtonSave: TButton;
    ButtonCancel: TButton;
    procedure ButtonSaveClick(Sender: TObject);
    procedure ButtonCancelClick(Sender: TObject);
  private
    FViewModel: TRowViewModel;
    FFields: specialize TArray<string>;
    FEdits: specialize TDictionary<string, TEdit>;
  public
    procedure LoadRow(ViewModel: TRowViewModel);
    function GetEditedRow: TRow;
  end;

var
  FormRowEditor: TFormRowEditor;

implementation

{$R *.lfm}

procedure TFormRowEditor.LoadRow(ViewModel: TRowViewModel);
var
  toppos: integer;
  lbl: TLabel;
  edt: TEdit;
  field: string;
begin
  FViewModel := ViewModel;
  FFields := FViewModel.GetFieldNames;
  FEdits := specialize TDictionary<string, TEdit>.Create;

  topPos := 10;

  for field in FFields do
  begin
    lbl := TLabel.Create(Self);
    lbl.Parent := PanelMain;
    lbl.Caption := field;
    lbl.Top := topPos;
    lbl.Left := 10;

    edt := TEdit.Create(Self);
    edt.Parent := PanelMain;
    edt.Text := FViewModel.GetValue(field);
    edt.Top := topPos;
    edt.Left := 100;
    edt.Width := 200;

    FEdits.Add(field, edt);
    Inc(topPos, 30);
  end;
end;

function TFormRowEditor.GetEditedRow: TRow;
var
  field: string;
begin
  Result := TRow.Create;
  for field in FFields do
    Result.Add(field, FEdits[field].Text);
end;

procedure TFormRowEditor.ButtonSaveClick(Sender: TObject);
begin
  ModalResult := mrOk;
end;

procedure TFormRowEditor.ButtonCancelClick(Sender: TObject);
begin
  ModalResult := mrCancel;
end;

end.
