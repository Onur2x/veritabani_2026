unit yenivt;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils,Generics.Collections,
  Variants,
  fpjson, jsonparser, zstream,
  oTabloSchema,osqlengine,
  oTypes;

 type
  TRow             = specialize TDictionary<string, Variant>;
  TRowList         = specialize TList<TRow>;

  TVeritabani = class
  private
    FMeta      : TJSONObject;                             // db.meta.json içeriği
    FTablolar  : specialize TDictionary<string, TTabloSchema>;  // Tabloların şemaları
    FVeriler   : specialize TDictionary<string, TRowList>;      // Tabloların verileri
    procedure LoadFromPackage(const FileName:string);
    procedure SaveToPackage(const FileName:string);
  public
    constructor Create;
    destructor Destroy; override;

    // Dosya işlemleri
    procedure LoadPackage(const DosyaAd: string);
    procedure SavePackage(const DosyaAd: string);

    // Tablo işlemleri
    procedure AddTable(const Ad: string; Schema: TTabloSchema);
    procedure DropTable(const Ad: string);
    function  GetSchema(const Ad: string): TTabloSchema;
    function  GetData(const Ad: string): TRowList;

    // SQL benzeri komut işleyici
    function ExecuteSQL(const SQL: string): TSqlCommand;
  end;

implementation
function TVeritabani.ExecuteSQL(const SQL: string): TSqlCommand;
var
  engine: TSqlEngine;
  cmd: TSqlCommand;
begin
  engine := TSqlEngine.Create(Self);
  try
    engine.ExecuteSQL(SQL, cmd);
    Result := cmd;
  finally
    engine.Free;
  end;
end;
procedure TVeritabani.SaveToPackage(const FileName: string);
var
  mem : TMemoryStream;
  fs  : TFileStream;
  zip : TCompressionStream;
  rootJSON : TJSONObject;
begin
  // 1) Bellek akışı oluştur
  mem := TMemoryStream.Create;
  try
    // 2) JSON içeriği oluştur
    rootJSON := BuildFullJSON; // ← meta + şema + veri birleşik
    try
      mem.WriteBuffer(Pointer(rootJSON.FormatJSON)^, Length(rootJSON.FormatJSON));
    finally
      rootJSON.Free;
    end;

    // 3) Dosyaya sıkıştırılmış şekilde yaz
    fs  := TFileStream.Create(FileName, fmCreate or fmShareDenyWrite);
    try
      zip := TCompressionStream.Create(clDefault, fs);
      try
        zip.CopyFrom(mem, 0); // Belleği sıkıştırarak dosyaya aktar
      finally
        zip.Free;
      end;
    finally
      fs.Free;
    end;
  finally
    mem.Free;
  end;
end;

procedure TVeritabani.LoadFromPackage(const FileName: string);
var
  fs  : TFileStream;
  ds  : TDecompressionStream;
  mem : TMemoryStream;
  jsonText : string;
  rootJSON : TJSONData;
  tablesArr: TJSONArray;
  i: Integer;
begin
  // 1) Belleği ve veritabanını sıfırla
  CreateDatabase('');

  // 2) Sıkıştırılmış dosyayı aç
  fs := TFileStream.Create(FileName, fmOpenRead);
  try
    ds := TDecompressionStream.Create(fs);
    try
      mem := TMemoryStream.Create;
      try
        mem.CopyFrom(ds, 0);
        SetString(jsonText, PAnsiChar(mem.Memory), mem.Size);
      finally
        mem.Free;
      end;
    finally
      ds.Free;
    end;
  finally
    fs.Free;
  end;

  // 3) JSON'u parse et ve tablo yükle
  rootJSON := GetJSON(jsonText);
  try
    tablesArr := rootJSON.FindPath('Tables') as TJSONArray;
    for i := 0 to tablesArr.Count - 1 do
      LoadTableFromJSON(tablesArr.Objects[i]);
  finally
    rootJSON.Free;
  end;
end;

end.

