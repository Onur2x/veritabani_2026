unit fExportCenter;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, StdCtrls, Dialogs,
  oVeritabani, oModules, oSerial;

type
  TFormExportCenter = class(TForm)
    ComboDB: TComboBox;
    RadioJSON: TRadioButton;
    RadioBinary: TRadioButton;
    ButtonExport: TButton;
    SaveDialog1: TSaveDialog;
    procedure ButtonExportClick(Sender: TObject);
    procedure FormShow(Sender: TObject);
  private
    FVeri: TVeritabani;
    FModul: TModulYonetici;
    FAktifDB: string;
  public
    procedure Initialize(Veritabani: TVeritabani; const DBName: string);
  end;

var
  FormExportCenter: TFormExportCenter;

implementation

{$R *.lfm}

procedure TFormExportCenter.Initialize(Veritabani: TVeritabani; const DBName: string);
begin
  FVeri := Veritabani;
  FAktifDB := DBName;
  FModul := TModulYonetici.Create(FVeri);
end;

procedure TFormExportCenter.FormShow(Sender: TObject);
begin
  ComboDB.Items := FVeri.GetDatabaseNames;
end;

procedure TFormExportCenter.ButtonExportClick(Sender: TObject);
begin
  if ComboDB.Text = '' then Exit;

  SaveDialog1.Filter := 'JSON Files|*.json|Binary Files|*.odb';
  if SaveDialog1.Execute then
  begin
    if RadioJSON.Checked then
      FModul.ExportJSON(SaveDialog1.FileName)
    else if RadioBinary.Checked then
      SaveODB(FVeri, SaveDialog1.FileName); // oSerial.pas üzerinden
  end;
end;

end.
