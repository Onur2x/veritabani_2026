// ============================================================
// Makinist Takip - Token-based Authentication (Oturum Yönetimi)
// ============================================================

// === Global Ayarlar ===
// YH DEĞİŞKENI YOK - index.html tarafından tanımlanacak
// OTURUM: sessionStorage'daki token kaydı
let OTURUM = '';

// === Başlatma (sayfa yüklendiğinde çalışır) ===
document.addEventListener('DOMContentLoaded', () => {
  // 1. URL parametresinden hatı al (?hat=M8)
  // index.html'den window.YH al
  window.YH = window.YH || (new URLSearchParams(location.search).get('hat') || 'M8').trim().toLocaleUpperCase('tr-TR');
  localStorage.setItem('yhat', window.YH);

  // 2. Token'ı sessionStorage'dan al
  OTURUM = sessionStorage.getItem('oturum_' + window.YH) || '';

  // 3. Auth UI güncelleme
  updateAuthUI();
});

// === Auth UI Güncelleme ===
function updateAuthUI() {
  const token = sessionStorage.getItem('oturum_' + window.YH) || '';
  const yonetici = sessionStorage.getItem('yonetici') === '1';

  // Veriler sayfasına erişim kontrolü
  document.querySelectorAll('[data-p="veri"],[data-goto="veri"]').forEach(btn => {
    const show = yonetici || (token ? '1' : '0');
    btn.style.display = show ? '' : 'none';
  });

  // Hat bilgisini göster
  const yhatEl = document.getElementById('yhatAd');
  if (yhatEl) {
    yhatEl.textContent = window.YH + (yonetici ? ' (yönetici)' : '');
  }

  // Durum göstergesi
  const durumEl = document.getElementById('durum');
  if (durumEl) {
    durumEl.textContent = token ? '● aktif' : 'bağlanıyor...';
  }
}

// === API Fetch Wrapper ===
async function apiFetch(path, options = {}) {
  // Hat parametresini ekle
  let url = path;
  if (!url.includes('?hat=')) {
    const separator = url.includes('?') ? '&' : '?';
    url += separator + 'hat=' + encodeURIComponent(window.YH);
  }

  // Token'i Authorization header olarak ekle
  const token = sessionStorage.getItem('oturum_' + window.YH) || '';
  const headers = {
    ...(options.headers || {}),
    ...(token ? { 'Authorization': `Bearer ${token}` } : {})
  };

  const response = await fetch(url, {
    ...options,
    headers: headers
  });

  // 401 - Token süresi dolmuş
  if (response.status === 401 || response.status === 403) {
    sessionStorage.removeItem('oturum_' + window.YH);
    localStorage.removeItem('ys_' + window.YH);
    location.href = '/giris.html?' + new URLSearchParams({ hat: window.YH });
    throw new Error('Oturum süresi doldu.');
  }

  // 404 - Sayfa yoksa ana sayfaya geri
  if (response.status === 404) {
    location.href = '/pano.html?' + new URLSearchParams({ hat: window.YH });
  }

  return response;
}

// === Giriş Yap ===
async function login(sifre, yonetici = false) {
  const response = await apiFetch('api/giris', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ sifre: sifre, hat: window.YH, yonetici: yonetici })
  });

  const data = await response.json();

  if (data.oturma) {
    sessionStorage.setItem('oturum_' + window.YH, data.oturma);
    if (yonetici) {
      sessionStorage.setItem('yonetici', '1');
    }
    location.reload();
  } else {
    alert('Hatalı şifre: ' + (data.hata || 'Bilinmeyen hata'));
  }
}

// === Oturumu Kapat ===
function logout() {
  fetch('api/oturum-kapat', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ token: sessionStorage.getItem('oturum_' + window.YH) })
  }).then(() => {
    sessionStorage.removeItem('oturum_' + window.YH);
    localStorage.removeItem('ys_' + window.YH);
    localStorage.removeItem('yhat');
    location.href = '/giris.html?' + new URLSearchParams({ hat: window.YH });
  });
}

// === Token Otomasyon ===
setInterval(async () => {
  const token = sessionStorage.getItem('oturum_' + window.YH);
  if (!token) return;
  try {
    const r = await apiFetch('api/durum', {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    if (r.status === 401) {
      logout();
    }
  } catch (e) { console.log('Token kontrol hatası:', e.message); }
}, 300000);

// === Dışarıya Açık Fonksiyonlar ===
window.login = window.login || login;
window.logout = logout;
updateAuthUI = updateAuthUI;