@echo off
REM Kiosk PC uyku engelleme - ADMIN GEREKMEZ (masaustu + laptop).
REM Kurulum: Win+R -> shell:startup yaz -> bu dosyanin KISAYOLUNU
REM acilan klasore kopyalayin. Her giriste arka planda calisir.
REM 60 saniyede bir zararsiz F15 tusu gondererek uyku ve ekran
REM kararmasini engeller (F15 hicbir programda kullanilmaz).
start "" /min powershell -NoProfile -WindowStyle Hidden -Command "Add-Type -AssemblyName System.Windows.Forms; while($true){ [System.Windows.Forms.SendKeys]::SendWait('{F15}'); Start-Sleep 60 }"
