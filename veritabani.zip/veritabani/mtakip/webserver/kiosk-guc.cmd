@echo off
REM Kiosk PC guc ayarlari: uyku/hazirda bekletme KAPALI, ekran hep acik,
REM kapak ve guc dugmesi etkisiz. Bu PC'de YONETICI olarak bir kez calistirin.
powercfg /change standby-timeout-ac 0
powercfg /change standby-timeout-dc 0
powercfg /change monitor-timeout-ac 0
powercfg /change monitor-timeout-dc 0
powercfg /hibernate off
powercfg /setacvalueindex SCHEME_CURRENT SUB_BUTTONS LIDACTION 0
powercfg /setdcvalueindex SCHEME_CURRENT SUB_BUTTONS LIDACTION 0
powercfg /setacvalueindex SCHEME_CURRENT SUB_BUTTONS PBUTTONACTION 0
powercfg /setactive SCHEME_CURRENT
reg add "HKCU\Control Panel\Desktop" /v ScreenSaveActive /t REG_SZ /d 0 /f
echo.
echo bitti: uyku kapali, ekran hep acik, kapak/guc dugmesi etkisiz.
pause
