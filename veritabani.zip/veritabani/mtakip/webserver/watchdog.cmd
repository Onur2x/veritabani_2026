@echo off
REM Makinist Takip - kiosk saglik kontrolu: server cevap vermiyorsa yeniden baslat
REM Kullanim: watchdog.cmd [port]  (varsayilan 8900)
REM Zamanlanmis gorevden her 5 dakikada bir calistirin.
REM NOT: powershell exit kodu -Command icinde guvenilmez oldugu icin
REM saglik stdout metniyle (200) olculur.
set PORT=%1
if "%PORT%"=="" set PORT=8900
set PROBE=%TEMP%\mtakip_probe.txt
powershell -NoProfile -Command "try { [int](Invoke-WebRequest -UseBasicParsing http://127.0.0.1:%PORT%/api/durum -TimeoutSec 10).StatusCode } catch { 0 }" > "%PROBE%" 2>nul
findstr /R /C:"^200$" "%PROBE%" >nul
if errorlevel 1 (
  echo %date% %time% server cevap vermiyor, yeniden baslatiliyor >> "%~dp0watchdog.log"
  taskkill /F /IM mtakipwebsrv.exe >nul 2>&1
  timeout /t 3 /nobreak >nul
  call "%~dp0update-swap.cmd"
  start "mtakipwebsrv" "%~dp0mtakipwebsrv.exe" --port=%PORT%
  echo %date% %time% server baslatildi >> "%~dp0watchdog.log"
)
