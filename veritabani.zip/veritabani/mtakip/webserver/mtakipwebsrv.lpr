program mtakipwebsrv;

{ Makinist Takip Web Server - konsol uygulamasi (LCL yok).
  Veri TEK veritabani dosyasinda: data\mtakip.odb (tum hatlar).
  JSON depolama yok.

  Kullanim:
    mtakipwebsrv [--port=8900] [--data=..\data] [--web=..\web_prototype] [--hat=M8]
                [--tut=30]   (kaç yedek saklansın)
}

{$mode objfpc}{$H+}

uses
  {$IFDEF UNIX}
  cthreads,
  {$ENDIF}
  Classes, SysUtils, fphttpserver, DateUtils, websrv;

{$IFDEF WINDOWS}
function SetThreadExecutionState(esFlags: DWORD): DWORD; stdcall;
  external 'kernel32.dll' name 'SetThreadExecutionState';
const
  ES_CONTINUOUS = DWORD($80000000);
  ES_SYSTEM_REQUIRED = DWORD($00000001);
{$ENDIF}

{ Yedek zamanlayicisi.
  Politika (kullanici istegi):
    backup\saat\  saatlik, son 24 adet  -> tam 1 gun
    backup\gun\   gunluk,  son 14 adet  -> 2 hafta
  Toplam 38 dosya, iki duz klasor. Saatlik katman kisa sureli geri
  almayi, gunluk katman 3 gun sonra fark edilen hatayi kurtarmayi saglar. }
type
  TYedekZamanlayici = class(TThread)
  private
    FWeb: TWebSrv;
  protected
    procedure Execute; override;
  end;

procedure TYedekZamanlayici.Execute;
var
  Bekle: Integer;
  SaatK, GunK, Hedef: string;
begin
  Bekle := 30;
  WriteLn('Yedek zamanlayicisi basladi (saatlik 24 + gunluk 14)');
  Flush(Output);
  while not Terminated do
  begin
    Sleep(1000);
    if Terminated then Break;
    Dec(Bekle);
    if Bekle > 0 then Continue;
    Bekle := 300;   { 5 dakikada bir kontrol }
    try
      { 1) saatlik: son yedekten 55 dakika gectiyse }
      SaatK := FWeb.SaatKlasoru;
      if FWeb.YedekTazeliMi(SaatK, 55) then
      begin
        Hedef := IncludeTrailingPathDelimiter(SaatK) + 'mtakip_' +
          FormatDateTime('yyyymmdd_hh', Now) + '.odb';
        if FWeb.YedekAl(Hedef) then
        begin
          FWeb.YedekKirp(SaatK, 24);
          WriteLn(FormatDateTime('dd.mm.yyyy hh:nn', Now), ' saatlik yedek: ',
            ExtractFileName(Hedef));
        end;
      end;
      { 2) gunluk: bugun icin henuz yoksa }
      GunK := FWeb.GunKlasoru;
      if FWeb.GunlukYedekAl(GunK) then
      begin
        WriteLn(FormatDateTime('dd.mm.yyyy hh:nn', Now), ' gunluk yedek: ',
          FormatDateTime('yyyymmdd', Now));
        Flush(Output);
      end;
    except
      on E: Exception do
      begin
        WriteLn('Yedek hatasi: ', Copy(E.Message, 1, 120));
        Flush(Output);
      end;
    end;
  end;
end;

var
  Srv: TFPHTTPServer;
  W: TWebSrv;
  Zamanlayici: TYedekZamanlayici;
  Port: Integer;
  DataYol, WebDir, ExeDir, VarsayilanHat, P: string;
  i: Integer;

begin
  { Lazarus/LCL ile ayni davranis: tum string donusumleri UTF-8.
    Yoksa POST ile gelen Turkce her turda bir kat daha kodlanir. }
  SetMultiByteConversionCodePage(CP_UTF8);
  SetMultiByteFileSystemCodePage(CP_UTF8);
  ExeDir := ExtractFilePath(ParamStr(0));
  Port := 8900;

  DataYol := ExpandFileName(ExeDir + '..' + PathDelim + 'data');
  WebDir := ExpandFileName(ExeDir + '..' + PathDelim + 'web_prototype');
  VarsayilanHat := 'M8';
  for i := 1 to ParamCount do
  begin
    P := ParamStr(i);
    if Copy(P, 1, 7) = '--port=' then
      Port := StrToIntDef(Copy(P, 8, 999), Port)
    else if Copy(P, 1, 7) = '--data=' then
      DataYol := ExpandFileName(Copy(P, 8, 999))
    else if Copy(P, 1, 6) = '--web=' then
      WebDir := ExpandFileName(Copy(P, 7, 999))
    else if Copy(P, 1, 6) = '--hat=' then
      VarsayilanHat := UpperCase(Trim(Copy(P, 7, 999)))
    else if (P = '-h') or (P = '--help') then
    begin
      WriteLn('Kullanim: mtakipwebsrv [--port=8900] [--data=...] [--web=...]');
      WriteLn('                     [--hat=M8]');
      Halt(0);
    end;
  end;

  {$IFDEF WINDOWS}
  { PC uykuya gecmesin (server calistikca): yetki/betik gerekmez }
  SetThreadExecutionState(ES_CONTINUOUS or ES_SYSTEM_REQUIRED);
  {$ENDIF}
  WriteLn('Makinist Takip Web Server');
  WriteLn('  veri : ', DataYol);
  WriteLn('  web  : ', WebDir);
  WriteLn('  hat  : ', VarsayilanHat);
  if not DirectoryExists(WebDir) then
    WriteLn('UYARI: web klasoru yok, sadece API calisir.');

  W := TWebSrv.Olustur(DataYol, WebDir, VarsayilanHat);
  { Yedek yolunu gunluk olarak konusmadan da gorelim. }
  WriteLn('Veritabani   : ', IncludeTrailingPathDelimiter(DataYol) + 'mtakip.odb');
  WriteLn('Yedek        : backup\saat (24 adet) + backup\gun (14 adet)');
  Flush(Output);
  Srv := TFPHTTPServer.Create(nil);
  try
    Srv.Port := Port;
    Srv.Threaded := True;
    Srv.AcceptIdleTimeout := 100;
    Srv.OnRequest := @W.Istek;

    { DIKKAT: TFPHTTPServer.Active := True, FPC'nin fphttpserver'inde
      dinleme dongusune GIRER ve geri donmez. Bu yuzden asagidaki
      butun kurulum (ve yedek zamanlayicisi) Active'den ONCE yapilir;
      aksi halde hicbiri calismaz. }
    Zamanlayici := TYedekZamanlayici.Create(True);
    Zamanlayici.FreeOnTerminate := False;
    Zamanlayici.FWeb := W;
    Zamanlayici.Start;

    WriteLn('Dinleniyor: http://127.0.0.1:', Port, '/  (pano: /pano.html?hat=M8)');
    WriteLn('Yedek      : saat klasoru 24 adet (1 gun) + gun klasoru 14 adet (2 hafta)');
    WriteLn('Durdurmak icin: pencerayi kapatin (veya q + Enter)');
    Flush(Output);

    { Buradan sonra donmez: dinleme dongusu. }
    Srv.Active := True;
  finally
    Zamanlayici.Terminate;
    Zamanlayici.WaitFor;
    Zamanlayici.Free;
    Srv.Free;
    W.Free;
  end;
end.
