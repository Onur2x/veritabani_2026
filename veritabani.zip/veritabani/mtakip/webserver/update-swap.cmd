@echo off
REM Bekleyen guncelleme varsa exe'yi degistir (SERVER KAPALIYKEN cagrilir)
set EXE=%~dp0mtakipwebsrv.exe
set YENI=%~dp0update\mtakipwebsrv.exe
if exist "%YENI%" (
  echo %date% %time% guncelleme uygulaniyor >> "%~dp0watchdog.log"
  copy /Y "%YENI%" "%EXE%" >nul
  if errorlevel 1 (
    echo %date% %time% guncelleme KOPYALANAMADI >> "%~dp0watchdog.log"
    exit /b 1
  )
  del "%YENI%"
  echo %date% %time% guncelleme uygulandi >> "%~dp0watchdog.log"
)
exit /b 0
