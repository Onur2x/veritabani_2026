# mtakipwebsrv — Makinist Takip Web Server

DB'nin **tek sahibi** olan LCL'siz Lazarus konsol uygulaması.
Masaüstü pano exe'sindeki `TOnurVT` (veri) + `SiralamaYap` (hesap) mantığının web karşılığı.

## Çalıştırma

```
webserver\mtakipwebsrv.exe [--port=8900] [--data=...\data] [--web=...\web_prototype] [--hat=M8]
webserver\kiosk.cmd [port] [hat]  # orn: kiosk.cmd 8900 M8 (bu ekranda M8 panosu)
kur-startup.cmd [port] [hat]      # kiosk.cmd'yi Windows başlangıcına ekler
backup.cmd [kaynak] [hedef] [adet] # tarihli yedek (varsayılan: data\veri.json → backup\, 30 adet)
veri-yukle.cmd [port]             # sqlite master → veri.json + server'a yeniden yüklet
```

## Çoklu hat (her hat kendi dosyasında)

`--data` bir klasörse `veri_{HAT}.json` dosyaları yüklenir
(örn `data\veri_M8.json`, `data\veri_M5.json`).
Tüm API çağrıları `?hat=` alır (`/api/pano?hat=M8&...`); boşsa varsayılan hat.
Pano `?hat=` ile, yönetim paneli üstteki Hat menüsüyle hat seçer.
Yeni hat: yönetimden `+ Hat` veya `POST /api/hat {"hat":"M5"}`.
Çizelge yüklemeleri ayrıca `CIZELGE_YYYY_MM` arşiv tablosu yazar;
görüntüleyicide `Arşiv ...` seçeneklerinden eski aylar izlenir.

Varsayılanlar exe'nin konumuna göredir: `../data/veri.json`, `../web_prototype`.
Durdurma: konsolda `q` + Enter.

## Pano ve yönetim

- `http://sunucu:8900/pano.html` — pano (server varsa canlı `/api/pano`, yoksa statik).
  Üst bar yok (exe gibi tam ekran): `S` ayar paneli, `F`/çift tık tam ekran.
  Kiosk URL örneği: `pano.html?hat=M5&mod=numarali&yon=0&ttid=37`
  Font kuralı: sayılar flatpack, isimler Segoe UI.
- `http://sunucu:8900/yonetim.html` — komutlar + tablo görüntüleme
- `http://sunucu:8900/modern.html?hat=M8` — modern pano (tema: `?tema=cam|led|acik`, kiosk: `?kiosk=1`).
  Aynı API'ler; sefer bitince + dakikada bir tazeler. `kiosk-modern.cmd` ile tam ekran açılır.
- `web_prototype/hatlar.json` — hat uçları + istasyon kısaltmaları (T4/M8 işletmeden teyit edilecek)

## Veri akışı (tek-yazıcı kuralı)

`veri.json`'a **aynı anda iki program yazmaz**. Sahibi bu server'dır.

```
sqlite master (data\____veri.db3)
   |  veri-yukle.cmd  (veriaktar.exe db -> json)
   v
data\veri.json  ──>  server otomatik görür (dosya izleme) veya /api/yukle
   |
   +--> pano / yönetim (okuma: /api/*)
   +--> komutlar (yazma: /komut -> AYARLAR + kaydet)
```

Toplu güncelleme: `veri-yukle.cmd` (db→json + `/api/yukle` sinyali).
Not: toplu yükleme sqlite'taki AYARLAR satırını da getirir; `sirali/numarali`
gibi çalışma-anı komutları toplu yüklemeden sonra gerekirse tekrar gönderilir.

## Türkçe / UTF-8 notu

Tüm zincir UTF-8'dir: `veriaktar.pas` + `mtakipwebsrv.lpr` açılışta
`SetMultiByteConversionCodePage(CP_UTF8)` çağırır (Lazarus/LCL davranışı).
Bu satır silinirse POST ile gelen Türkçe her turda bir kat daha kodlanır ve
`veri.json` bozulur. Belirti: `SEFLİK` alanında `Ã` `Ä` gibi karakterler.

## Yönetim paneli (yonetim.html) — ayar programı

Masaüstü pano exe'si **kullanılmıyor**; pano salt görüntüler, her şey buradan.
Adres: `yonetim.html?hat=M8` (hat menüsünden de değişir).

**Giriş kapısı:** `yonetim.html?hat=M8` o hattın şifresini ister. Şifreler
`data/sifreler.json` dosyasında sabittir (`{"M8":"...","M5":"..."`) ve
panelden değiştirilemez. Şifresiz hat açıktır. Giriş sonrası hatta bağlı
oturum anahtarı verilir; sayfa hep açıktır (pano).

- Komutlar (`/komut`): numaralı/sıralı/flash... → pano ~2sn'de uygular
- **Tarife planı**: otomatik/manuel, 7 günün tarifesi, yön, manuel tarife
- **Operasyon**: şeflik, tur süresi, akşam saati, sabah/akşam numaraları,
  gruplar, başmakinistler, HAT kısaltmaları (HAT_M8...), sistem/flash/kayan yazı
- Ayarlar: ham anahtar/değer düzenleyici + yeni satır ekleme
- **Kaza rekoru**: son kaza tarihi (T4 panosundaki sayaç buradan beslenir)

- Ayarlar: getir → düzenle → kaydet (`POST /api/ayarlar`)
- **Excel yükleme**: tablo başına dosya, Türkçe başlıklar (SİCİL, ADI SOYADI,
  1..31, TARİFE ID, GÖREV NO, SAAT...). ID eşleşen **güncellenir**,
  ID'siz satır **eklenir**, dosyada olmayan korunur. Şablon + KILAVUZ sayfası
  panelden indirilir. Eşleme: `web_prototype/lib/excel-map.js`
- **Çizelge (SMAMP sayfası)**: aylık kadro dosyası aynen okunur, dosya sırasıyla
  komple değişir. Eşleme: `lib/excel-cizelge.js`. Master şablon panelden üretilir.
- **Time-table (ANAHAT sayfası)**: sol blok gidiş, sağ blok dönüş, yeşil/kırmızı
  bloklar giriş/çıkış. Mod: Düzenle (TTID+Görev+Saat eşleşir) veya Yeniden yaz
  (tarife temizlenir). Yeni satırlara DİZİ/HAT paneldeki değerler yazılır
  (DİZİ: M5=6 diğer=4; HAT: `HAT_M8` gibi ayarlardan). Eşleme: `lib/excel-timetable.js`
- **Fotoğraf**: sicil + jpg/png → `POST /api/resim?sicil=`

## Endpoint'ler

| Yöntem | Yol | Açıklama |
|---|---|---|
| GET | `/`, `/pano.html`, `/yonetim.html`, `/veri_37.json`, `/hatlar.json` | statik |
| GET | `/api/durum` | versiyon, saat, tablo sayıları |
| GET | `/api/ayarlar` | AYARLAR |
| GET/POST | `/api/tablo/ADI` (eski: `/tablo/ADI`) | tablo okuma / komple yazma |
| GET | `/api/pano?ttid=&gun=&suan=&yon=&mod=&hat=` | hesaplanmış pano (boş = otomatik) |
| GET | `/api/hatlar` | hat listesi |
| POST | `/api/hat {"hat":"M5"}` | yeni boş hat dosyası |
| GET | `/api/tablolar` | tablo adları (arşiv keşfi) |
| GET | `/api/resim?sicil=` | makinist fotoğrafı (JPEG) |
| POST | `/komut`, `/api/komut` | `sirali, numarali, flash, flashi, kayanyazi, ...` |
| POST | `/dosyaal?adi=` | eski istemci uyumluluğu |
| GET/POST | `/api/yukle` | diskteki dosyayı belleğe zorla al |
| GET | `/api/islemgunlugu?hat=H\|TUMU&oturma=&sifre=&n=&ay=YYYY-MM` | işlem günlüğü (TUMU sadece yönetici; LOG-GÜNLÜK sayfası) |
| GET | `/api/yedekler?hat=` | `backup/veri_HAT_*.json` listesi |
| POST | `/api/geri-yukle {"yedek":"..."}` | yedekten geri yükleme (sadece yönetici; önce `_onceki` alır) |
| POST | `/api/admin-sifre {"yeni":"..."}` | yönetici şifresi değiştir (sha1 özet yazılır, en az 6 karakter) |
| GET | `/api/oturumlar` | aktif oturumlar (sadece yönetici) |
| POST | `/api/oturum-kapat {"token":"..."}` | oturum düşür (sadece yönetici) |
| POST | `/api/hat-sifre {"hat":"M5","yeni":"..."}` | hat şifresi belirle (sadece yönetici) |
| GET | `/api/yedek-indir?hat=&ad=` | yedek dosyası indir |
| POST | `/api/guncelle-yukle` | exe yükle (update klasörü, MZ kontrollü, sadece yönetici) |
| POST | `/api/yeniden-baslat` | serverı kapat (watchdog güncelleyip açar, sadece yönetici) |

## Roller

- **Hat kullanıcısı**: hat şifresiyle girer, kendi hattını yönetir. Veriler sayfasını görmez.
- **Yönetici (süper kullanıcı)**: `sifreler.json` içindeki `ADMIN` şifresiyle **herhangi bir hatta** girer,
  tüm hatlarda yetkilidir (`*:token`), Veriler sayfasını görür, hat açar, yedek yükler, şifre değiştirir.
  `ADMIN` değeri `sha1:<hex>` özetidir (tuz: `mtakip-admin:`); dosyadan okunamaz, panelden değiştirilemez
  (yönetici kendisi Ayarlar'dan değiştirebilir).

## ATS halka modeli (pano)

İki şerit açılmış tek 3840px halka kabul edilir. Her tarife kendi tur süresini sefer
saatlerinden türetir (medyan): `T1` = gidiş bacağı, `T2` = dönüş bacağı (M8: 1605+1450=3055sn).
Tren PAR kalkışına göre halkadaki fazına yerleşir; kopya tren olmaz. Türetilemezse eski
pencere davranışına düşer. Panodaki tren adedi canlı sayımdır.

## Vardiya döngüsü (grup)

12 günlük döngü: 4 sabah, 2 izin, 4 akşam, 2 izin. Referans 27.09.2026 = 1. Grup akşam
2. günü; gruplar 4'er gün faz farklı. Tarih matematiğiyle bulunur (kadro sırasından bağımsız).

## Yedekleme + geri yükleme + watchdog

- `backup.cmd data backup 7` → `backup\` altına tarihli yedek (veri + şifreler + günlük).
  Zamanlanmış görev `MTAKIP-Gunluk-Yedek` her gece 03:00'te çalışır, 7 gün tutar.
- Geri yükleme: Veriler sayfası → yedek seç → onayla (mevcut durum `_onceki` olarak saklanır).
- `webserver\watchdog.cmd [port]` server cevap vermezse yeniden başlatır;
  `MTAKIP-Watchdog` görevi her 5 dakikada çalıştırır.

## Derleme

Lazarus 4.6+ ile: `lazbuild -B --build-mode=Debug webserver\mtakipwebsrv.lpi`
