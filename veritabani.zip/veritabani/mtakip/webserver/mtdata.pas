unit MtData;

(* MTAKIP - Veritabani katmani.
  Tek .odb dosyasi; TUM hatlar bu dosyanin icinde.
  JSON depolama YOK.

  Hat izolasyonu:
    Fiziksel tablo adi her zaman {HAT}_{Tablo}. Hat adi oturumdan gelir,
    istemciden alinmaz. Hat ve tablo adi asagidaki kurala uymak
    zorundadir; gecersizse hicbir SQL metni uretilmez:
      hat   : ^[A-Z0-9_]{1,20}$
      tablo : ^[A-Z0-9_]{1,40}$
    Boylece bir hat, baska bir hatin tablosuna ne hat degistirerek ne de
    SQL enjeksiyonu ile erisabilir.

  Motor kullanimi (olculerek dogrulandi):
    TVDb.Create -> Kv.Open(dosya) -> TVTableDb.Create -> Tdb.Open(dizin)
    -> TVSql.Create.  Tdb.Open ATLANIRSA sema yuklenmez ve "tablo yok"
    hatasi verilir.
    TVSql.Exec tamamen kilitlidir (tek mutex) => butun sorgular seri.
    OPEN/CLOSE DATABASE, BACKUP, DROP DATABASE kilitlenmemistir; calisma
    sirasinda cagrilmaz. Yedekleme icin Kv.BackupTo kullanilir.

  NOT: Bu birim bilerek tamamen ASCII yazilmistir (motor birimleri gibi).
  Turkce karakterler yalnizca calisma aninda veri olarak akitilir; motor
  degerleri UTF-8 olarak saklar ve test edildi (byte birebir korunuyor).
*)

{$mode objfpc}{$H+}

interface

uses
Classes, SysUtils, StrUtils, FileUtil, VDbCore, VDbTable, VDbSql, VDbErr;

type
  TMtDb = class
  private
    FDosya: string;
    FKv: TVDb;
    FTdb: TVTableDb;
    FSql: TVSql;
    FVersiyon: QWord;
    procedure Kontrol(const Hat, Tablo: string);
    function HazirMi: Boolean;
    function Dizin: string;
    function Calistir(const Sql: string): TSqlResult;
    function CalistirK(const Sql: string; const Params: TStringList): TSqlResult;
    function Sl(const Vals: array of string): TStringList;
    procedure SurumArtir;
  public
    { Yazma sayaci. Okuma onbellegi bunu izler; veri degisince onbellek
      gecersizlesir. Motorun her tablo taramasinda dosyanin tamamini
      okuyup CRC dogruladigi icin (sabit ~33 ms) onbellek sart. }
    function Versiyon: QWord;

    constructor Create(const DosyaYolu: string);
    destructor Destroy; override;

    procedure Ac;
    procedure Kapat;
    function ACIKMIs: Boolean;
    function DosyaYol: string;
    function DizinYolu: string;

    { --- global katalog (tum hatlar) --- }
    function Hatlar: TStringList;
    function HatVar(const Hat: string): Boolean;
    function HatEkle(const Hat: string): Boolean;
    function HatSil(const Hat: string): Boolean;

    { --- hat izole tablo islemleri --- }
    function TabloVar(const Hat, Tablo: string): Boolean;
    function TabloOlustur(const Hat, Tablo: string; const Sutunlar: TStringList;
      const Anahtar: TStringList): Boolean;
    function TabloSil(const Hat, Tablo: string): Boolean;
    function HatTabloListesi(const Hat: string): TStringList;
    function Sutunlar(const Hat, Tablo: string): TStringList;
    function AnahtarAlani(const Hat, Tablo: string): string;
    function SatirSayisi(const Hat, Tablo: string): Integer;

    { --- satir islemleri --- }
    function Satirlar(const Hat, Tablo, Sart: string;
      const Params: TStringList): TSqlResult;
    function TumSatirlar(const Hat, Tablo: string): TSqlResult;
    procedure Ekle(const Hat, Tablo: string; const Alanlar,
      Degerler: TStringList);
    procedure Degistir(const Hat, Tablo, AnahtarAlan, AnahtarDeger: string;
      const Alanlar, Degerler: TStringList);
    procedure Sil(const Hat, Tablo, AnahtarAlan, AnahtarDeger: string);
    procedure Bosalt(const Hat, Tablo: string);
    function SonrakiId(const Hat, Tablo: string): string;

    { --- ayarlar --- }
    function AyarOku(const Hat, Ana: string): string;
    procedure AyarYaz(const Hat, Ana, Deger: string);
    function AyarAnahtarlari(const Hat: string): TStringList;

    { --- fotograf (BLOB) --- }
    procedure FotoYaz(const Hat, Sicil: string; const Bayt: AnsiString);
    function FotoOku(const Hat, Sicil: string): AnsiString;
    procedure FotoSil(const Hat, Sicil: string);
    function FotoListesi(const Hat: string): TStringList;

    { --- sifreler --- }
    function SifreOku(const Anahtar: string): string;
    procedure SifreYaz(const Anahtar, Deger: string);

    { --- islem gunlugu --- }
    procedure GunlukEkle(const Hat, Kullanici, Yontem, Yol, Detay: string;
      Kod: Integer);
    function GunlukOku(const Ay: string; Limit: Integer;
      const YalHat: string = ''): TSqlResult;

    { --- bakim --- }
    function Dogrula(out Rapor: string): Boolean;
    procedure Sikistir;
    { Yedek alir ve SONUCU DOGRULAR. Dosya olustu demek yeterli degildir:
      bos/kisa bir kopyayi yedek saymak, gun icinde bir daha
      duzeltilmeyen (bkz. GunlukYedekAl) yaniltici bir yedek birakir.
      True doner ancak kopya kaynakla ayni canli kayit sayisina sahipse
      ve Verify ile butunluk denetiminden gecerse. }
    function YedekAl(const Hedef: string; out Hata: string): Boolean;
    function KayitSayisi: Integer;
  end;

function HatGecerli(const Hat: string): Boolean;
function TabloGecerli(const Tablo: string): Boolean;

var
  Vt: TMtDb;

implementation

uses
  DateUtils;

const
  DB_SIFRE = 'VT_SIFRE';

  { Sabit hat tablolari:  adi | kolonlar | anahtar
    Ilk kolon NOT NULL. RESIM kolonu BLOB olur.
    CIZELGE'nin ID kolonu SENTETIKtir: JSON dizisindeki sirayi korur
    (SIRANO 4 haftada tekrar ettigi icin tekil degildir, pano dizi
    sirasina gore okur). }
  HAT_TABLOLARI: array[0..8] of string = (
    'TTDETAY|ID,ADI,HAFTAICISONU,YAZKIS,SILINMIS|ID',
    'TIMETABLE|ID,TTID,NUMARA,SAAT,RUN,DIZI,HATID,ARACCIKAR,ARACCIKAR1,' +
      'ARACGIRER,ARACGIRER1,ARACSDISI,ARACKONTROL,SILINMIS|ID',
    'TIMETABLECEK|ID,TTID,NUMARA,SAAT,RUN,DIZI,HATID,ARACCIKAR,ARACCIKAR1,' +
      'ARACGIRER,ARACGIRER1,ARACSDISI,ARACKONTROL,SILINMIS|ID',
    'CIZELGE|ID,SIRANO,SICIL,ADI,GOREVI,G1,G2,G3,G4,G5,G6,G7,G8,G9,G10,G11,' +
      'G12,G13,G14,G15,G16,G17,G18,G19,G20,G21,G22,G23,G24,G25,G26,G27,' +
      'G28,G29,G30,G31,SILINMIS|ID',
    'MAKINISTRESIM|SICILID,ID,RESIM,SILINMIS|SICILID',
    'MAKINISTEMESAJ|ID,MESAJ,BASLAMA,BITIS,SILINMIS|ID',
    'MANEVRA|ID,GOREVNO,TTID,BASLANGICSAATI,BITISSAATI,SILINMIS|ID',
    'ARACGRSLISTESI|ID,SAAT,TTID,HANGIYON,GIRISMI,SILINMIS|ID',
    'KAZAREKOR|ID,SONKAZATARIH,SONREKORGUNU|ID'
  );

  { indeks: tablo | kolon }
  HAT_INDEXLER: array[0..2] of string = (
    'TIMETABLE|TTID', 'TIMETABLECEK|TTID', 'MANEVRA|GOREVNO'
  );

{ ============================================================== dogrulama }

function HatGecerli(const Hat: string): Boolean;
var
  I: Integer;
begin
  Result := False;
  if (Hat = '') or (Length(Hat) > 20) then Exit;
  for I := 1 to Length(Hat) do
    if not (Hat[I] in ['A'..'Z', '0'..'9', '_']) then Exit;
  Result := True;
end;

function TabloGecerli(const Tablo: string): Boolean;
var
  I: Integer;
begin
  Result := False;
  if (Tablo = '') or (Length(Tablo) > 40) then Exit;
  for I := 1 to Length(Tablo) do
    if not (Tablo[I] in ['A'..'Z', '0'..'9', '_']) then Exit;
  Result := True;
end;

{ ============================================================== yasam dongusu }

constructor TMtDb.Create(const DosyaYolu: string);
begin
  inherited Create;
  FDosya := ExpandFileName(DosyaYolu);
  FVersiyon := 1;
end;

procedure TMtDb.SurumArtir;
begin
  Inc(FVersiyon);
end;

function TMtDb.Versiyon: QWord;
begin
  Result := FVersiyon;
end;

destructor TMtDb.Destroy;
begin
  Kapat;
  inherited Destroy;
end;

function TMtDb.Dizin: string;
begin
  Result := ExtractFileDir(FDosya);
end;

function TMtDb.DosyaYol: string;
begin
  Result := FDosya;
end;

function TMtDb.DizinYolu: string;
begin
  Result := Dizin;
end;

function TMtDb.HazirMi: Boolean;
begin
  Result := Assigned(FSql);
end;

function TMtDb.ACIKMIs: Boolean;
begin
  Result := HazirMi;
end;

procedure TMtDb.Kontrol(const Hat, Tablo: string);
begin
  if not HatGecerli(Hat) then
    raise Exception.Create('VT: gecersiz hat adi');
  if (Tablo <> '') and not TabloGecerli(Tablo) then
    raise Exception.Create('VT: gecersiz tablo adi');
end;

function TMtDb.Sl(const Vals: array of string): TStringList;
   var
   I: Integer;
   begin
   Result := TStringList.Create;
   for I := 0 to High(Vals) do Result.Add(Vals[I]);
   end;

   { Sorgu sonucunda Satir/Sutun guvenli erisim. Motor satiri kisaltirsa
     veya sutun yoksa bos string doner - cagiran taraf IndexOf hatasina
     dusmez. }
   function SutunDeger(const R: TSqlResult; Satir, Sutun: Integer): string;
   begin
   Result := '';
   if (Satir < 0) or (Satir > High(R.Rows)) then Exit;
   if (Sutun < 0) or (Sutun > High(R.Rows[Satir])) then Exit;
   Result := R.Rows[Satir][Sutun];
   end;
   
function TMtDb.Calistir(const Sql: string): TSqlResult;
begin
  if not HazirMi then Ac;
  Result := FSql.Exec(Sql);
end;

function TMtDb.CalistirK(const Sql: string;
  const Params: TStringList): TSqlResult;
var
  P: array of string;
  I: Integer;
begin
  if not HazirMi then Ac;
  if (Params = nil) or (Params.Count = 0) then
  begin
    Result := FSql.Exec(Sql);
    Exit;
  end;
  SetLength(P, Params.Count);
  for I := 0 to Params.Count - 1 do P[I] := Params[I];
  Result := FSql.Exec(Sql, P);
end;

procedure TMtDb.Ac;
var
  Rapor: string;
begin
  if HazirMi then Exit;
  ForceDirectories(Dizin);
  FKv := TVDb.Create;
  FKv.Open(FDosya);
  FTdb := TVTableDb.Create(FKv);
  FTdb.Open(Dizin);              { semayi yukleyen tek cagiri }
  FSql := TVSql.Create(FTdb);

  { Global katalog + sifre + ayar. HATLISTESI her hatta DEGIL, tek ve
    globaldir; boylece admin tum hatlari tek yerden gorur. }
  Calistir('CREATE TABLE IF NOT EXISTS HATLISTESI ' +
    '(HATADI TEXT NOT NULL, SILINMIS TEXT, PRIMARY KEY(HATADI))');
  Calistir('CREATE TABLE IF NOT EXISTS ' + DB_SIFRE + ' ' +
    '(ANAHTAR TEXT NOT NULL, DEGER TEXT, PRIMARY KEY(ANAHTAR))');
  Calistir('CREATE TABLE IF NOT EXISTS VT_AYAR ' +
    '(ANA TEXT NOT NULL, DEGER TEXT, PRIMARY KEY(ANA))');

  if not FKv.Verify(Rapor) then
    WriteLn('VT: butunluk uyarisi - ', Rapor);
end;

procedure TMtDb.Kapat;
begin
  FSql.Free;  FSql := nil;
  FTdb.Free;  FTdb := nil;
  FKv.Free;   FKv := nil;
end;

{ ============================================================== hat katalogu }

function TMtDb.Hatlar: TStringList;
var
  R: TSqlResult;
  I: Integer;
begin
  Result := TStringList.Create;
  Result.Sorted := True;
  Result.Duplicates := dupIgnore;
  if not HazirMi then Ac;
  R := CalistirK('SELECT HATADI FROM HATLISTESI WHERE SILINMIS = ? ' +
    'ORDER BY HATADI', Sl(['0']));
  for I := 0 to High(R.Rows) do
    if HatGecerli(R.Rows[I][0]) then Result.Add(R.Rows[I][0]);
end;

function TMtDb.HatVar(const Hat: string): Boolean;
var
  R: TSqlResult;
  P: TStringList;
begin
  Result := False;
  if not HatGecerli(Hat) then Exit;
  if not HazirMi then Ac;
  P := TStringList.Create;
  try
    P.Add(Hat);
    P.Add('0');
    R := CalistirK('SELECT HATADI FROM HATLISTESI WHERE HATADI = ? AND SILINMIS = ?', P);
  finally
    P.Free;
  end;
  Result := Length(R.Rows) > 0;
end;

procedure HatSemasiKur(ASql: TVSql; const Hat: string);
var
  I, K: Integer;
  Kayit, Sutunlar, Anahtar: TStringList;
  SutunMetni, TAdi: string;
begin
  ASql.Exec('CREATE TABLE IF NOT EXISTS ' + Hat + '_AYAR ' +
    '(ANA TEXT NOT NULL, DEGER TEXT, PRIMARY KEY(ANA))');
  ASql.Exec('CREATE TABLE IF NOT EXISTS ' + Hat + '_ISLEMGUNLUGU ' +
    '(ZAMAN TEXT NOT NULL, KULLANICI TEXT, YONTEM TEXT, YOL TEXT, ' +
    'DETAY TEXT, SONU TEXT, KOD INTEGER, PRIMARY KEY(ZAMAN))');

  Kayit := TStringList.Create;
  Sutunlar := TStringList.Create;
  Anahtar := TStringList.Create;
  try
    for I := 0 to High(HAT_TABLOLARI) do
    begin
      Kayit.Delimiter := '|';
      Kayit.StrictDelimiter := True;
      Kayit.DelimitedText := HAT_TABLOLARI[I];
      TAdi := Kayit[0];

      Sutunlar.Delimiter := ',';
      Sutunlar.StrictDelimiter := True;
      Sutunlar.DelimitedText := Kayit[1];
      Anahtar.Delimiter := ',';
      Anahtar.StrictDelimiter := True;
      Anahtar.DelimitedText := Kayit[2];

      SutunMetni := '';
      for K := 0 to Sutunlar.Count - 1 do
      begin
        if K > 0 then SutunMetni := SutunMetni + ',';
        if Sutunlar[K] = 'RESIM' then
          SutunMetni := SutunMetni + 'RESIM BLOB'
        else if K = 0 then
          SutunMetni := SutunMetni + Sutunlar[K] + ' TEXT NOT NULL'
        else
          SutunMetni := SutunMetni + Sutunlar[K] + ' TEXT';
      end;
      { Anahtar kolonlari tanimda gercekten var olmali. Kolonlar eklendigi
        icin burada her zaman virgul ile ayrilir. }
      for K := 0 to Anahtar.Count - 1 do
      begin
        if Sutunlar.IndexOf(Anahtar[K]) < 0 then
          raise Exception.CreateFmt('VT: %s tablosunda anahtar kolonu yok: %s',
            [TAdi, Anahtar[K]]);
        SutunMetni := SutunMetni + ',PRIMARY KEY(' + Anahtar[K] + ')';
      end;
      ASql.Exec('CREATE TABLE IF NOT EXISTS ' + Hat + '_' + TAdi +
        ' (' + SutunMetni + ')');
    end;

    { CREATE INDEX ... IF NOT EXISTS desteklenmiyor; var olan index
      hata verir, bu yuzden yutulur (idempotent olsun diye). }
    for I := 0 to High(HAT_INDEXLER) do
    begin
      Kayit.Delimiter := '|';
      Kayit.StrictDelimiter := True;
      Kayit.DelimitedText := HAT_INDEXLER[I];
      try
        ASql.Exec('CREATE INDEX ix_' + Hat + '_' + Kayit[1] +
          ' ON ' + Hat + '_' + Kayit[0] + '(' + Kayit[1] + ')');
      except
        on E: EVDbException do
          if E.ErrorCode <> ecIndexExists then raise;
      end;
    end;
  finally
    Kayit.Free; Sutunlar.Free; Anahtar.Free;
  end;
end;

function TMtDb.HatEkle(const Hat: string): Boolean;
var
  P: TStringList;
begin
  Result := False;
  if not HatGecerli(Hat) then Exit;
  if not HazirMi then Ac;
  HatSemasiKur(FSql, Hat);
  if not HatVar(Hat) then
  begin
    P := TStringList.Create;
    try
      P.Add(Hat);
      P.Add('0');
      CalistirK('INSERT INTO HATLISTESI(HATADI, SILINMIS) VALUES (?, ?)', P);
    finally
      P.Free;
    end;
  end;
  Result := True;
end;

function TMtDb.HatSil(const Hat: string): Boolean;
var
  L: TStringList;
  I: Integer;
  P: TStringList;
begin
  Result := False;
  if not HatGecerli(Hat) then Exit;
  if not HatVar(Hat) then Exit;
  L := HatTabloListesi(Hat);
  try
    for I := 0 to L.Count - 1 do
      try
        Calistir('DROP TABLE ' + Hat + '_' + L[I]);
      except
        on E: Exception do ;
      end;
  finally
    L.Free;
  end;
  P := TStringList.Create;
  try
    P.Add('1');
    P.Add(Hat);
    CalistirK('UPDATE HATLISTESI SET SILINMIS = ? WHERE HATADI = ?', P);
  finally
    P.Free;
  end;
  Result := True;
end;

{ ============================================================== tablo islemleri }

function TMtDb.TabloVar(const Hat, Tablo: string): Boolean;
begin
  Result := False;
  if not (HatGecerli(Hat) and TabloGecerli(Tablo)) then Exit;
  if not HatVar(Hat) then Exit;
  try
    Calistir('SELECT * FROM ' + Hat + '_' + Tablo + ' LIMIT 0');
    Result := True;
  except
    on E: Exception do Result := False;
  end;
end;

function TMtDb.HatTabloListesi(const Hat: string): TStringList;
var
  R: TSqlResult;
  I: Integer;
  Onek, Ad: string;
begin
  Result := TStringList.Create;
  Result.Sorted := True;
  if not HatGecerli(Hat) then Exit;
  if not HazirMi then Ac;
  Onek := LowerCase(Hat + '_');
  R := Calistir('SHOW TABLES');
  for I := 0 to High(R.Rows) do
  begin
    Ad := LowerCase(R.Rows[I][0]);
    if (Pos(Onek, Ad) = 1) and (Length(Ad) > Length(Onek)) then
      Result.Add(Copy(Ad, Length(Onek) + 1, MaxInt));
  end;
end;

function TMtDb.TabloOlustur(const Hat, Tablo: string; const Sutunlar: TStringList;
  const Anahtar: TStringList): Boolean;
var
  I: Integer;
  Metin: string;
begin
  Result := False;
  Kontrol(Hat, Tablo);
  if not HatVar(Hat) then Exit;
  if (Sutunlar = nil) or (Sutunlar.Count = 0) then Exit;
  Metin := '';
  for I := 0 to Sutunlar.Count - 1 do
  begin
    if not TabloGecerli(Sutunlar[I]) then
      raise Exception.Create('VT: gecersiz kolon adi');
    if I > 0 then Metin := Metin + ',';
    { Kolonlar bos deger kabul eder; NOT NULL yalnizca birincil anahtarda
      gecerlidir (motor PK'i zaten NOT NULL sayar). CIZELGE arsivlerinde
      G1..G6 cogunlukla bos oldugu icin bu onemlidir. }
    Metin := Metin + Sutunlar[I] + ' TEXT';
  end;
  if (Anahtar <> nil) and (Anahtar.Count > 0) then
  begin
    if not TabloGecerli(Anahtar[0]) then
      raise Exception.Create('VT: gecersiz anahtar kolonu');
    Metin := Metin + ',PRIMARY KEY(' + Anahtar[0] + ')';
  end;
  try
    Calistir('CREATE TABLE ' + Hat + '_' + Tablo + ' (' + Metin + ')');
    Result := True;
  except
    on E: Exception do
      WriteLn('VT: tablo olusturulamadi ', Hat, '_', Tablo, ' - ', E.Message);
  end;
end;

function TMtDb.TabloSil(const Hat, Tablo: string): Boolean;
begin
  Result := False;
  Kontrol(Hat, Tablo);
  if not HatVar(Hat) then Exit;
  try
    Calistir('DROP TABLE ' + Hat + '_' + Tablo);
    Result := True;
  except
    on E: Exception do ;
  end;
end;

function TMtDb.Sutunlar(const Hat, Tablo: string): TStringList;
var
  R: TSqlResult;
  I: Integer;
begin
  { SIRA KORUNUR: INSERT INTO t(col,col,...) degerleri sirayla eslesir,
    alfabetik siralama veri yerlestirir. }
  Result := TStringList.Create;
  if not (HatGecerli(Hat) and TabloGecerli(Tablo)) then Exit;
  if not HazirMi then Exit;
  try
    R := Calistir('SELECT * FROM ' + Hat + '_' + Tablo + ' LIMIT 0');
    for I := 0 to High(R.Fields) do
      Result.Add(UpperCase(R.Fields[I]));
  except
    on E: Exception do ;
  end;
end;

{ Tablonun birincil anahtar kolonu. Satir sirasi bu kolona gore verilir;
  CIZELGE gibi dizi sirasina bagli tablolarda bu zorunludur. }
function TMtDb.AnahtarAlani(const Hat, Tablo: string): string;
var
  T: TTableDef;
begin
  Result := '';
  if not (HatGecerli(Hat) and TabloGecerli(Tablo)) then Exit;
  if not HazirMi then Exit;
  T := FTdb.GetTable(LowerCase(Hat + '_' + Tablo));
  if (T.PkIndex >= 0) and (T.PkIndex < Length(T.Cols)) then
    Result := UpperCase(T.Cols[T.PkIndex].Name);
end;

function TMtDb.SatirSayisi(const Hat, Tablo: string): Integer;
var
  R: TSqlResult;
begin
  Result := 0;
  if not (HatGecerli(Hat) and TabloGecerli(Tablo)) then Exit;
  if not HazirMi then Exit;
  try
    R := Calistir('SELECT COUNT(*) FROM ' + Hat + '_' + Tablo);
    if (Length(R.Rows) = 1) and (Length(R.Rows[0]) > 0) then
      Result := StrToIntDef(R.Rows[0][0], 0);
  except
    on E: Exception do Result := 0;
  end;
end;

function TMtDb.SonrakiId(const Hat, Tablo: string): string;
var
  R: TSqlResult;
  I, V, EnBuyuk: Integer;
begin
  Kontrol(Hat, Tablo);
  EnBuyuk := 0;
  R := TumSatirlar(Hat, Tablo);
  for I := 0 to High(R.Rows) do
  begin
    if Length(R.Rows[I]) = 0 then Continue;
    if TryStrToInt(R.Rows[I][0], V) and (V > EnBuyuk) then EnBuyuk := V;
  end;
  Result := IntToStr(EnBuyuk + 1);
end;

{ ============================================================== satir islemleri }

{ Satirlari okur. varsayilan olarak birincil anahtara gore SIRALANIR:
  motor hash sirasinda dondurur, oysa CIZELGE gibi tablolar dizi
  sirasina baglidir. }
function TMtDb.Satirlar(const Hat, Tablo, Sart: string;
  const Params: TStringList): TSqlResult;
var
  Metin, Pk: string;
begin
  Kontrol(Hat, Tablo);
  if not HazirMi then Ac;
  Metin := 'SELECT * FROM ' + Hat + '_' + Tablo;
  if Trim(Sart) <> '' then Metin := Metin + ' WHERE ' + Sart;
  Pk := AnahtarAlani(Hat, Tablo);
  if Pk <> '' then Metin := Metin + ' ORDER BY ' + Pk;
  Result := CalistirK(Metin, Params);
end;

function TMtDb.TumSatirlar(const Hat, Tablo: string): TSqlResult;
begin
  Result := Satirlar(Hat, Tablo, '', nil);
end;

procedure TMtDb.Ekle(const Hat, Tablo: string; const Alanlar,
  Degerler: TStringList);
var
  I: Integer;
  SutunListesi, YerListesi, Metin: string;
begin
  Kontrol(Hat, Tablo);
  if (Alanlar = nil) or (Degerler = nil) then Exit;
  if Alanlar.Count <> Degerler.Count then
    raise Exception.Create('VT: alan/deger sayisi farkli');
  if Alanlar.Count = 0 then Exit;
  SutunListesi := '';
  YerListesi := '';
  for I := 0 to Alanlar.Count - 1 do
  begin
    if not TabloGecerli(Alanlar[I]) then
      raise Exception.Create('VT: gecersiz alan adi');
    if I > 0 then
    begin
      SutunListesi := SutunListesi + ',';
      YerListesi := YerListesi + ',';
    end;
    SutunListesi := SutunListesi + Alanlar[I];
    YerListesi := YerListesi + '?';
  end;
  Metin := 'INSERT INTO ' + Hat + '_' + Tablo + '(' + SutunListesi +
    ') VALUES(' + YerListesi + ')';
  CalistirK(Metin, Degerler);
  SurumArtir;
end;

procedure TMtDb.Degistir(const Hat, Tablo, AnahtarAlan, AnahtarDeger: string;
  const Alanlar, Degerler: TStringList);
var
  I: Integer;
  Atama, Metin: string;
  P: TStringList;
begin
  Kontrol(Hat, Tablo);
  if not TabloGecerli(AnahtarAlan) then
    raise Exception.Create('VT: gecersiz anahtar alani');
  if (Alanlar = nil) or (Degerler = nil) then Exit;
  if Alanlar.Count <> Degerler.Count then Exit;
  Atama := '';
  for I := 0 to Alanlar.Count - 1 do
  begin
    if not TabloGecerli(Alanlar[I]) then
      raise Exception.Create('VT: gecersiz alan adi');
    if I > 0 then Atama := Atama + ',';
    Atama := Atama + Alanlar[I] + ' = ?';
  end;
  Metin := 'UPDATE ' + Hat + '_' + Tablo + ' SET ' + Atama +
    ' WHERE ' + AnahtarAlan + ' = ?';
  P := TStringList.Create;
  try
    for I := 0 to Degerler.Count - 1 do P.Add(Degerler[I]);
    P.Add(AnahtarDeger);
    CalistirK(Metin, P);
    SurumArtir;
  finally
    P.Free;
  end;
end;

procedure TMtDb.Sil(const Hat, Tablo, AnahtarAlan, AnahtarDeger: string);
var
  P: TStringList;
begin
  Kontrol(Hat, Tablo);
  if not TabloGecerli(AnahtarAlan) then
    raise Exception.Create('VT: gecersiz anahtar alani');
  P := TStringList.Create;
  try
    P.Add(AnahtarDeger);
    CalistirK('DELETE FROM ' + Hat + '_' + Tablo +
      ' WHERE ' + AnahtarAlan + ' = ?', P);
    SurumArtir;
  finally
    P.Free;
  end;
end;

procedure TMtDb.Bosalt(const Hat, Tablo: string);
begin
  Kontrol(Hat, Tablo);
  Calistir('DELETE FROM ' + Hat + '_' + Tablo);
  SurumArtir;
end;

{ ============================================================== ayarlar }

function TMtDb.AyarOku(const Hat, Ana: string): string;
var
  R: TSqlResult;
  P: TStringList;
begin
  Result := '';
  if not HatGecerli(Hat) then Exit;
  if not HazirMi then Ac;
  P := TStringList.Create;
  try
    P.Add(Ana);
    R := CalistirK('SELECT DEGER FROM ' + Hat + '_AYAR WHERE ANA = ?', P);
  finally
    P.Free;
  end;
  if (Length(R.Rows) = 1) and (Length(R.Rows[0]) > 0) then
    Result := R.Rows[0][0];
end;

procedure TMtDb.AyarYaz(const Hat, Ana, Deger: string);
var
  P: TStringList;
begin
  if not HatGecerli(Hat) then Exit;
  if not HazirMi then Ac;
  P := TStringList.Create;
  try
    P.Add(Ana);
    CalistirK('DELETE FROM ' + Hat + '_AYAR WHERE ANA = ?', P);
    P.Clear;
    P.Add(Ana);
    P.Add(Deger);
    CalistirK('INSERT INTO ' + Hat + '_AYAR(ANA, DEGER) VALUES (?, ?)', P);
    SurumArtir;
  finally
    P.Free;
  end;
end;

function TMtDb.AyarAnahtarlari(const Hat: string): TStringList;
var
  R: TSqlResult;
  I: Integer;
begin
  Result := TStringList.Create;
  Result.Sorted := True;
  if not HatGecerli(Hat) then Exit;
  R := TumSatirlar(Hat, 'AYAR');
  for I := 0 to High(R.Rows) do
    if Length(R.Rows[I]) > 0 then Result.Add(R.Rows[I][0]);
end;

{ ============================================================== fotograf }

procedure TMtDb.FotoYaz(const Hat, Sicil: string; const Bayt: AnsiString);
var
  P: TStringList;
begin
  if not HatGecerli(Hat) then Exit;
  if not HazirMi then Ac;
  P := TStringList.Create;
  try
    P.Add(Sicil);
    CalistirK('DELETE FROM ' + Hat + '_MAKINISTRESIM WHERE SICILID = ?', P);
    P.Clear;
    P.Add(Sicil);
    P.Add(Sicil);
    P.Add(Bayt);
    P.Add('0');
    CalistirK('INSERT INTO ' + Hat +
      '_MAKINISTRESIM(SICILID, ID, RESIM, SILINMIS) VALUES (?, ?, ?, ?)', P);
    SurumArtir;
  finally
    P.Free;
  end;
end;

function TMtDb.FotoOku(const Hat, Sicil: string): AnsiString;
var
  R: TSqlResult;
  I: Integer;
  P: TStringList;
begin
  Result := '';
  if not HatGecerli(Hat) then Exit;
  if not HazirMi then Exit;
  P := TStringList.Create;
  try
    P.Add(Sicil);
    R := CalistirK('SELECT RESIM FROM ' + Hat +
      '_MAKINISTRESIM WHERE SICILID = ?', P);
  finally
    P.Free;
  end;
  if Length(R.Rows) = 1 then
    for I := 0 to High(R.Fields) do
      if UpperCase(R.Fields[I]) = 'RESIM' then
      begin
        Result := R.Rows[0][I];
        Exit;
      end;
end;

procedure TMtDb.FotoSil(const Hat, Sicil: string);
var
  P: TStringList;
begin
  if not HatGecerli(Hat) then Exit;
  P := TStringList.Create;
  try
    P.Add(Sicil);
    CalistirK('DELETE FROM ' + Hat + '_MAKINISTRESIM WHERE SICILID = ?', P);
    SurumArtir;
  finally
    P.Free;
  end;
end;

function TMtDb.FotoListesi(const Hat: string): TStringList;
var
  R: TSqlResult;
  I: Integer;
begin
  Result := TStringList.Create;
  Result.Sorted := True;
  if not HatGecerli(Hat) then Exit;
  R := TumSatirlar(Hat, 'MAKINISTRESIM');
  for I := 0 to High(R.Rows) do
    if Length(R.Rows[I]) > 0 then Result.Add(R.Rows[I][0]);
end;

{ ============================================================== sifreler }

function TMtDb.SifreOku(const Anahtar: string): string;
var
  R: TSqlResult;
  P: TStringList;
begin
  Result := '';
  if not HazirMi then Ac;
  P := TStringList.Create;
  try
    P.Add(Anahtar);
    R := CalistirK('SELECT DEGER FROM ' + DB_SIFRE + ' WHERE ANAHTAR = ?', P);
  finally
    P.Free;
  end;
  if (Length(R.Rows) = 1) and (Length(R.Rows[0]) > 0) then
    Result := R.Rows[0][0];
end;

procedure TMtDb.SifreYaz(const Anahtar, Deger: string);
var
  P: TStringList;
begin
  if not HazirMi then Ac;
  P := TStringList.Create;
  try
    P.Add(Anahtar);
    CalistirK('DELETE FROM ' + DB_SIFRE + ' WHERE ANAHTAR = ?', P);
    P.Clear;
    P.Add(Anahtar);
    P.Add(Deger);
    CalistirK('INSERT INTO ' + DB_SIFRE + '(ANAHTAR, DEGER) VALUES (?, ?)', P);
    SurumArtir;
  finally
    P.Free;
  end;
end;

{ ============================================================== gunluk }

procedure TMtDb.GunlukEkle(const Hat, Kullanici, Yontem, Yol, Detay: string;
  Kod: Integer);
var
  Damga: string;
  P: TStringList;
begin
  if not HatGecerli(Hat) then Exit;
  if not HazirMi then Exit;
  Damga := FormatDateTime('yyyy-mm-dd hh:nn:ss.zzz', Now) + '#' +
    IntToStr(GetTickCount64 and $FFFFFFF);
  P := TStringList.Create;
  try
    P.Add(Damga);
    P.Add(Kullanici);
    P.Add(Yontem);
    P.Add(Yol);
    P.Add(Detay);
    P.Add('OK');
    P.Add(IntToStr(Kod));
    try
      CalistirK('INSERT INTO ' + Hat + '_ISLEMGUNLUGU' +
        '(ZAMAN, KULLANICI, YONTEM, YOL, DETAY, SONU, KOD)' +
        ' VALUES (?, ?, ?, ?, ?, ?, ?)', P);
    except
      on E: Exception do ;
    end;
  finally
    P.Free;
  end;
end;

function TMtDb.GunlukOku(const Ay: string; Limit: Integer;
  const YalHat: string = ''): TSqlResult;
var
  H, Satir: TStringList;
  I, J, N, P, B: Integer;
  R: TSqlResult;
  HataIlk: string;
  AyGecerli: Boolean;
  Sat: string;
begin
  if not HazirMi then Ac;
  SetLength(Result.Fields, 0);
  SetLength(Result.Rows, 0);
  Result.Fields := ['ZAMAN', 'HAT', 'KULLANICI', 'YONTEM', 'YOL', 'DETAY',
    'SONU', 'KOD'];

  { Ay her zaman HTTP katmanindan gelir; SQL'e girmeden once dogrulanir. }
  AyGecerli := (Length(Ay) = 7) and (Ay[5] = '-');
  if AyGecerli then
    for I := 1 to 7 do
      if (I <> 5) and not (Ay[I] in ['0'..'9']) then AyGecerli := False;
  if not AyGecerli then Exit;
  if Limit < 1 then Exit;

  { Motorda iki kisit var, ikisi de bu yolu zorunlu kiliyor:
    1) UNION ALL calisiyor, ama "SELECT kolon, 'sabit' AS alias FROM tablo"
       bicimi kromlanmiyor (FROM'suz SELECT saniliyor). Hat adi bu yuzden
       SQL'e degil, burada ekleniyor.
    2) Gunluk her hatta ayri tabloda; tek sorgu zaten mumkun degil.
    Satirlar #1 ile birlestirilir, sozelik siraya dizilir (ZAMAN ISO
    bicimi oldugu icin sozelik = tarih), sonra kirpilir ve ters cevrilir.
    YalHat verilmisse (belirli bir hattin gunlugu) YALNIZCA o tablo
    okunur; 5 hat icin 5 kez tarama yapilmasina gerek kalmaz. }
  Satir := TStringList.Create;
  if HatGecerli(YalHat) then
  begin
    H := TStringList.Create;
    try
      H.Add(YalHat);
    except
      H.Free;
      raise;
    end;
  end
  else
    H := Hatlar;
  try
    try
      for I := 0 to H.Count - 1 do
      begin
        try
          R := Calistir('SELECT ZAMAN, KULLANICI, YONTEM, YOL, DETAY, SONU, KOD ' +
            'FROM ' + H[I] + '_ISLEMGUNLUGU WHERE ZAMAN LIKE ''' + Ay +
            '%'' ORDER BY ZAMAN DESC LIMIT ' + IntToStr(Limit));
          for J := 0 to High(R.Rows) do
            Satir.Add(R.Rows[J][0] + #1 + H[I] + #1 +
              SutunDeger(R, J, 1) + #1 + SutunDeger(R, J, 2) + #1 +
              SutunDeger(R, J, 3) + #1 + SutunDeger(R, J, 4) + #1 +
              SutunDeger(R, J, 5) + #1 + SutunDeger(R, J, 6));
        except
          on E: Exception do
            if HataIlk = '' then HataIlk := E.Message;
        end;
      end;
    finally
      H.Free;
    end;

    Satir.Sorted := True;
    Satir.Sort;

    N := Satir.Count;
    if N > Limit then N := Limit;
    SetLength(Result.Rows, N);
    for I := 0 to N - 1 do
    begin
      { Satir artan sirada; en yeniden baslayarak geriye dogru aliyoruz. }
      Sat := Satir[Satir.Count - 1 - I];
      SetLength(Result.Rows[I], 8);
      B := 1;
      for J := 0 to 7 do
      begin
        P := PosEx(#1, Sat, B);
        if P = 0 then
        begin
          Result.Rows[I][J] := Copy(Sat, B, MaxInt);
          break;
        end;
        Result.Rows[I][J] := Copy(Sat, B, P - B);
        B := P + 1;
      end;
    end;
  finally
    Satir.Free;
  end;

  if HataIlk <> '' then
    WriteLn('VT: gunluk okunamadi - ', HataIlk);
end;

{ ============================================================== bakim }

function TMtDb.Dogrula(out Rapor: string): Boolean;
begin
  Rapor := '';
  if not HazirMi then Exit;
  Result := FKv.Verify(Rapor);
end;

procedure TMtDb.Sikistir;
begin
  if not HazirMi then Exit;
  try
    Calistir('VACUUM');
  except
    on E: Exception do WriteLn('VT: sikistirma - ', E.Message);
  end;
end;

function TMtDb.YedekAl(const Hedef: string; out Hata: string): Boolean;
var
  Beklenen: Integer;
  Kopya: TVDb;
  KopyaTb: TVTableDb;
  KopyaYol: string;
begin
  Result := False;
  Hata := '';
  if not HazirMi then begin Hata := 'veritabani kapali'; Exit; end;
  if Hedef = '' then begin Hata := 'hedef yol bos'; Exit; end;
  Beklenen := FKv.Count;
  try
    FKv.BackupTo(Hedef);
  except
    on E: Exception do begin Hata := 'yedek yazilamadi: ' + E.Message; Exit; end;
  end;
  if not FileExists(Hedef) then begin Hata := 'dosya olusmadi'; Exit; end;

  { --- DOGRULAMA ---
    Yedek "basarili" sayilmasi icin:
      1) dosya ayaga kalkabilmeli (acma + sema + butunluk)
      2) kaynakla AYNI canli kayit sayisini tasimali
    Aksi halde 0 satirlik/yarim kopyalar sessizce yedek sayilirdi. }
  KopyaYol := GetTempDir(False) + 'vtyedekdogrulama';
  ForceDirectories(KopyaYol);
  // Dogrulama icin gecici adi kullanilir; kopyanin kendisi silinmez.
  if FileExists(KopyaYol + '\veritabani.odb') then
    DeleteFile(KopyaYol + '\veritabani.odb');
  if not CopyFile(Hedef, KopyaYol + '\veritabani.odb', True) then
  begin
    Hata := 'kopya dogrulama icin acilamadi';
    Exit;
  end;
  Kopya := nil; KopyaTb := nil;
  try
    Kopya := TVDb.Create;
    Kopya.SyncWrite := False;
    Kopya.Open(KopyaYol);
    if not Kopya.Verify(Hata) then
    begin
      Hata := 'butunluk denetimi basarisiz: ' + Hata;
      Exit;
    end;
    if Kopya.Count <> Beklenen then
    begin
      Hata := Format('kayit sayisi tutmuyor (kaynak %d, kopya %d)',
        [Beklenen, Kopya.Count]);
      Exit;
    end;
    KopyaTb := TVTableDb.Create(Kopya);
    KopyaTb.Open(KopyaYol);
    if Length(KopyaTb.TableNames) = 0 then
    begin
      Hata := 'kopyada tablo yok';
      Exit;
    end;
    KopyaTb.Close;
    Result := True;
  except
    on E: Exception do begin Hata := 'dogrulama hatasi: ' + E.Message; Result := False; end;
  end;
  FreeAndNil(KopyaTb);
  FreeAndNil(Kopya);
end;

function TMtDb.KayitSayisi: Integer;
begin
  if not HazirMi then Exit;
  Result := FKv.Count;
end;

end.
