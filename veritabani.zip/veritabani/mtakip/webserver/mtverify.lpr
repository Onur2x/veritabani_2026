program mtverify;

{ JSON -> .odbaktariminin KAYIPSIZ oldugunu dogrular.
  Her hat icin, her tablo icin satir sayisi ve satir icerigi karsilastirilir.
  Fotograflar base64 cozulup bayt bayt karsilastirilir. }

{$mode objfpc}{$H+}

uses
  Classes, SysUtils, fpjson, jsonparser, base64, VDbSql, MtData;

var
  DataYol, OdbYol: string;
  Vt: TMtDb;
  ToplamHata: Integer;
  Rapor: TStringList;

function DosyaOku(const Yol: string): string;
var
  S: TFileStream;
begin
  Result := '';
  if not FileExists(Yol) then Exit;
  S := TFileStream.Create(Yol, fmOpenRead or fmShareDenyNone);
  try
    SetLength(Result, S.Size);
    if S.Size > 0 then S.ReadBuffer(Result[1], S.Size);
  finally
    S.Free;
  end;
end;

procedure Hata(const Metin: string);
begin
  Inc(ToplamHata);
  if Rapor.Count < 60 then Rapor.Add(Metin);
end;

function TamamMi(const A, B: Boolean): string;
begin
  if A and B then Result := 'TAMAM' else Result := 'FARKLI';
end;

{ Fotograf iceriginin kisa ozeti: uzunluk + ilk/son bayt. }
function FotoIz(const Ham: AnsiString): string;
var
  B1, B2: string;
begin
  if Length(Ham) > 0 then B1 := IntToHex(PByte(@Ham[1])^, 2) else B1 := '-';
  if Length(Ham) > 1 then B2 := IntToHex(PByte(@Ham[Length(Ham)])^, 2) else B2 := '-';
  Result := Format('FOTO:%d:%s:%s', [Length(Ham), B1, B2]);
end;

function SutunIndeksi(const R: TSqlResult; const Ad: string): Integer;
var
  I: Integer;
begin
  Result := -1;
  for I := 0 to High(R.Fields) do
    if UpperCase(R.Fields[I]) = Ad then Exit(I);
end;

procedure SatirlariKarsilastir(const Etiket: string; const Dizi: TJSONArray;
  const Sutunlar: TStringList; const Hat, Tablo: string;
  SentetikId: Boolean; FotoTablosu: Boolean);
var
  I, K, SB, Kb: Integer;
  Satir: TJSONObject;
  Sut: TJSONData;
  R: TSqlResult;
  Beklenen, Gercek: string;
  IdMap: array of string;
  Kalan: TStringList;
  Ham: AnsiString;
  ToplamBeklenen, ToplamGercek: Int64;
  Eslesen: Integer;
  B: string;

  function AlanDeger(S: TJSONObject; const Ad: string): string;
  var
    D: TJSONData;
  begin
    D := S.Find(Ad);
    if (D = nil) or (D.JSONType = jtNull) then Result := ''
    else if D.JSONType = jtBoolean then Result := BoolToStr(D.AsBoolean, True)
    else Result := D.AsString;
  end;

begin
  R := Vt.TumSatirlar(Hat, Tablo);
  ToplamBeklenen := Dizi.Count;
  ToplamGercek := Length(R.Rows);

  if ToplamBeklenen <> ToplamGercek then
    Hata(Format('%s: satir sayisi JSON=%d DB=%d', [Etiket, ToplamBeklenen, ToplamGercek]));

  if Dizi.Count = 0 then Exit;

  { Her JSON satirinin tum alanlarini birlestirip bir dizeye koy }
  SetLength(IdMap, Dizi.Count);
  Kalan := TStringList.Create;
  try
    Kalan.Sorted := True;
    Kalan.Duplicates := dupIgnore;
    for I := 0 to Dizi.Count - 1 do
    begin
      Satir := TJSONObject(Dizi.Items[I]);
      if Satir.JSONType <> jtObject then Continue;
      if FotoTablosu then
      begin
        Sut := Satir.Find('RESIM');
        Ham := '';
        if (Sut <> nil) and (Sut.JSONType = jtString) and (Sut.AsString <> '') then
          Ham := DecodeStringBase64(Sut.AsString);
        { uzunluk + ilk/son bayt + basit toplam: carpisma riski minimum }
        IdMap[I] := FotoIz(Ham);
      end
      else
      begin
        B := '';
        for K := 0 to Sutunlar.Count - 1 do
        begin
          if K > 0 then B := B + #1;
          { CIZELGE'de JSON'da ID yoktur; iceri aktarici dizi sirasina gore
            sentetik ID yazar. Beklenen tarafta da aynisi uretilir. }
          if SentetikId and (K = 0) then
            B := B + IntToStr(I + 1)
          else
            B := B + AlanDeger(Satir, Sutunlar[K]);
        end;
        IdMap[I] := B;
      end;
      Kalan.Add(IdMap[I]);
    end;

    { DB tarafi: ayni sekilde dize uret, kalanlardan dus }
    Eslesen := 0;
    for I := 0 to High(R.Rows) do
    begin
      if FotoTablosu then
      begin
        SB := SutunIndeksi(R, 'RESIM');
        Ham := '';
        if SB >= 0 then Ham := R.Rows[I][SB];
        B := FotoIz(Ham);
      end
      else
      begin
        B := '';
        for K := 0 to Sutunlar.Count - 1 do
        begin
          SB := SutunIndeksi(R, Sutunlar[K]);
          if K > 0 then B := B + #1;
          if SB >= 0 then B := B + R.Rows[I][SB];
        end;
      end;
      Kb := Kalan.IndexOf(B);
      if Kb >= 0 then
      begin
        Kalan.Delete(Kb);
        Inc(Eslesen);
      end;
    end;

    if Kalan.Count > 0 then
    begin
      Hata(Format('%s: %d satir DBde bulunamadi (ilk: %s)',
        [Etiket, Kalan.Count, Copy(Kalan[0], 1, 90)]));
    end;
    WriteLn(Format('    %-22s JSON %5d / DB %5d  eslesen %5d %s',
      [Tablo, ToplamBeklenen, ToplamGercek, Eslesen,
       TamamMi(Kalan.Count = 0, ToplamBeklenen = ToplamGercek)]));
  finally
    Kalan.Free;
  end;
end;

procedure AyarlariKarsilastir(const Hat: string; const Ay: TJSONObject);
var
  I: Integer;
  Ana, Beklenen, Gercek: string;
  Sut: TJSONData;
  Fark: Integer;
begin
  Fark := 0;
  for I := 0 to Ay.Count - 1 do
  begin
    Ana := Ay.Names[I];
    Sut := Ay.Items[I];
    if (Sut = nil) or (Sut.JSONType = jtNull) then Beklenen := ''
    else if Sut.JSONType = jtBoolean then Beklenen := BoolToStr(Sut.AsBoolean, True)
    else Beklenen := Sut.AsString;
    Gercek := Vt.AyarOku(Hat, Ana);
    if Beklenen <> Gercek then
    begin
      Inc(Fark);
      if Fark <= 3 then
        Hata(Format('AYAR %s: JSON="%s" DB="%s"', [Ana, Beklenen, Gercek]));
    end;
  end;
  WriteLn(Format('    %-22s JSON %5d ayar  fark %d %s', ['AYARLAR', Ay.Count, Fark,
    TamamMi(Fark = 0, True)]));
end;

var
  I, J: Integer;
  VeriYol, HatAdi: string;
  Json: TJSONData;
  Kok: TJSONObject;
  Sutunlar: TStringList;
  Sut: TJSONData;
  Ad: string;
  Hatlar: TStringList;
  Arama: TSearchRec;
  Tamam: Boolean;
  ButunlukRaporu: string;

begin
  SetMultiByteConversionCodePage(CP_UTF8);
  SetMultiByteFileSystemCodePage(CP_UTF8);
  DataYol := ExpandFileName(ExtractFilePath(ParamStr(0)) + '..' + PathDelim + 'data');
  OdbYol := '';
  for I := 1 to ParamCount do
  begin
    if Copy(ParamStr(I), 1, 7) = '--data=' then DataYol := ExpandFileName(Copy(ParamStr(I), 8, 999))
    else if Copy(ParamStr(I), 1, 6) = '--odb=' then OdbYol := ExpandFileName(Copy(ParamStr(I), 7, 999));
  end;
  if OdbYol = '' then OdbYol := IncludeTrailingPathDelimiter(DataYol) + 'mtakip.odb';

  WriteLn('==============================================');
  WriteLn(' JSON  <->  VERITABANI DOGRULAMA');
  WriteLn('==============================================');
  WriteLn(' json : ', DataYol);
  WriteLn(' odb  : ', OdbYol);
  WriteLn;

  ToplamHata := 0;
  Rapor := TStringList.Create;
  Vt := TMtDb.Create(OdbYol);
  Hatlar := TStringList.Create;
  try
    Vt.Ac;
    if FindFirst(IncludeTrailingPathDelimiter(DataYol) + 'veri_*.json',
        faAnyFile, Arama) = 0 then
    try
      repeat
        Ad := ExtractFileName(Arama.Name);
        Ad := UpperCase(Copy(Ad, 6, Length(Ad) - 5 - 5));
        if HatGecerli(Ad) then Hatlar.Add(Ad);
      until FindNext(Arama) <> 0;
    finally
      FindClose(Arama);
    end;

    for I := 0 to Hatlar.Count - 1 do
    begin
      HatAdi := Hatlar[I];
      VeriYol := IncludeTrailingPathDelimiter(DataYol) + 'veri_' + HatAdi + '.json';
      Json := GetJSON(DosyaOku(VeriYol));
      if Json = nil then Continue;
      if Json.JSONType <> jtObject then begin Json.Free; Continue; end;
      Kok := TJSONObject(Json);
      WriteLn('--- HAT ', HatAdi, ' ---');

      if not Vt.HatVar(HatAdi) then
        Hata('hat veritabaninda yok: ' + HatAdi);

      Sut := Kok.Find('AYARLAR');
      if (Sut <> nil) and (Sut.JSONType = jtObject) then
        AyarlariKarsilastir(HatAdi, TJSONObject(Sut));

      Sutunlar := Vt.Sutunlar(HatAdi, 'TTDETAY');
      try
        for J := 0 to 8 do
        begin
          Ad := '';
          case J of
            0: Ad := 'TTDETAY';
            1: Ad := 'TIMETABLE';
            2: Ad := 'TIMETABLECEK';
            3: Ad := 'CIZELGE';
            4: Ad := 'MAKINISTEMESAJ';
            5: Ad := 'MANEVRA';
            6: Ad := 'ARACGRSLISTESI';
            7: Ad := 'KAZAREKOR';
          end;
          if Ad = '' then Continue;
          Sutunlar.Free;
          Sutunlar := Vt.Sutunlar(HatAdi, Ad);
          if Sutunlar.Count = 0 then Continue;
          Sut := Kok.Find(Ad);
          if (Sut <> nil) and (Sut.JSONType = jtArray) then
            SatirlariKarsilastir(HatAdi + '.' + Ad, TJSONArray(Sut), Sutunlar,
              HatAdi, Ad, Ad = 'CIZELGE', False);
        end;
      finally
        Sutunlar.Free;
      end;

      { fotograf }
      Sut := Kok.Find('MAKINISTRESIM');
      if (Sut <> nil) and (Sut.JSONType = jtArray) then
      begin
        Sutunlar := TStringList.Create;
        try
          SatirlariKarsilastir(HatAdi + '.MAKINISTRESIM', TJSONArray(Sut),
            Sutunlar, HatAdi, 'MAKINISTRESIM', False, True);
        finally
          Sutunlar.Free;
        end;
      end;

      { aylik arsivler }
      for J := 0 to Kok.Count - 1 do
      begin
        if (Pos('CIZELGE_', UpperCase(Kok.Names[J])) <> 1) then Continue;
        if Kok.Items[J].JSONType <> jtArray then Continue;
        Sutunlar := Vt.Sutunlar(HatAdi, UpperCase(Kok.Names[J]));
        try
          if Sutunlar.Count > 0 then
            SatirlariKarsilastir(HatAdi + '.' + Kok.Names[J],
              TJSONArray(Kok.Items[J]), Sutunlar, HatAdi,
              UpperCase(Kok.Names[J]), True, False);
        finally
          Sutunlar.Free;
        end;
      end;

      Kok.Free;
      WriteLn;
    end;

    { sifreler }
    WriteLn('--- SIFRELER ---');
    Json := GetJSON(DosyaOku(IncludeTrailingPathDelimiter(DataYol) + 'sifreler.json'));
    if (Json <> nil) and (Json.JSONType = jtObject) then
      for I := 0 to TJSONObject(Json).Count - 1 do
      begin
        if Vt.SifreOku(TJSONObject(Json).Names[I]) <> TJSONObject(Json).Items[I].AsString then
          Hata('sifre farkli: ' + TJSONObject(Json).Names[I]);
      end;
    Json.Free;
    WriteLn('    sifreler tamam');
    WriteLn;

    { butunluk }
    WriteLn('--- BUTUNLUK ---');
    if Vt.Dogrula(ButunlukRaporu) then
      WriteLn('    VERIFY OK: ', ButunlukRaporu)
    else
      WriteLn('    VERIFY HATA: ', ButunlukRaporu);
  finally
    Vt.Free;
    Hatlar.Free;
  end;

  WriteLn('==============================================');
  if ToplamHata = 0 then
    WriteLn(' SONUC: JSON ve VERITABANI birebir ayni')
  else
  begin
    WriteLn(' SONUC: ', ToplamHata, ' FARK var:');
    for I := 0 to Rapor.Count - 1 do
      if I < 60 then WriteLn('   - ', Rapor[I]);
  end;
  WriteLn('==============================================');
  Rapor.Free;
  if ToplamHata <> 0 then Halt(1);
end.
