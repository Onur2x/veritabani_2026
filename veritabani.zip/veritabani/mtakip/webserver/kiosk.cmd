@echo off
REM Makinist Takip - kiosk baslatici (server + tam ekran pano)
REM Kullanim: kiosk.cmd [port] [hat]
REM   orn: kiosk.cmd 8900 M8   -> bu ekranda M8 panosu acar
REM   Her pano PC'sinde istenen hatla calistirin; server ortaktir.
set PORT=%1
if "%PORT%"=="" set PORT=8900
set HAT=%2
set PHAT=
if not "%HAT%"=="" set PHAT=?hat=%HAT%
call "%~dp0update-swap.cmd"
start "mtakipwebsrv" "%~dp0mtakipwebsrv.exe" --port=%PORT%
echo Server bekleniyor...
powershell -NoProfile -Command "$i=0; while($i -lt 30){ try { if ((Invoke-WebRequest -UseBasicParsing http://127.0.0.1:%PORT%/api/durum -TimeoutSec 2).StatusCode -eq 200) { break } } catch { }; Start-Sleep 1; $i++ }; if ($i -ge 30) { 'UYARI: server 30sn icinde hazir olmadi' } else { 'server hazir' }"
REM   if exist "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe" (
REM     start "" "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe" --kiosk http://127.0.0.1:%PORT%/pano.html%PHAT% --fullscreen
REM   ) else if exist "C:\Program Files\Google\Chrome\Application\chrome.exe" (
REM     start "" "C:\Program Files\Google\Chrome\Application\chrome.exe" --kiosk http://127.0.0.1:%PORT%/pano.html%PHAT%
REM   ) else (
 REM    start http://127.0.0.1:%PORT%/pano.html%PHAT%
REM   )
