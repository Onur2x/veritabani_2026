@echo off
REM Makinist Takip - modern pano kiosk baslatici (server + tam ekran modern pano)
REM Kullanim: kiosk-modern.cmd [port] [hat]
REM   orn: kiosk-modern.cmd 8900 M8
set PORT=%1
if "%PORT%"=="" set PORT=8900
set HAT=%2
if "%HAT%"=="" set HAT=M8
call "%~dp0update-swap.cmd"
start "mtakipwebsrv" "%~dp0mtakipwebsrv.exe" --port=%PORT%
echo Server bekleniyor...
powershell -NoProfile -Command "$i=0; while($i -lt 30){ try { if ((Invoke-WebRequest -UseBasicParsing http://127.0.0.1:%PORT%/api/durum -TimeoutSec 2).StatusCode -eq 200) { break } } catch { }; Start-Sleep 1; $i++ }; if ($i -ge 30) { 'UYARI: server 30sn icinde hazir olmadi' } else { 'server hazir' }"
start http://127.0.0.1:%PORT%/modern.html?hat=%HAT%&kiosk=1
