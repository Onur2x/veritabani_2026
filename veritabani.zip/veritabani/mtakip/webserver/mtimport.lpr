program mtimport;

{ MTAKIP - JSON -> .odb iceri aktarici (TEK KEZ calisir).
  Girdi : data\veri_{HAT}.json  + data\sifreler.json
  Cikti: data\mtakip.odb  (TUM hatlar, hat onekli tablolar)

  JSON dosyalari bundan sonra calisma icin GEREKMEZ; islem bitince
  arsive tasinabilir. Sunucu yalnizca .odb okur.

  Kullanim:
    mtimport [--data=..\data] [--odb=..\data\mtakip.odb] [--hat=M8,M5,...]
            [--temiz]      (hedef .odb varsa once siler)
}

{$mode objfpc}{$H+}

uses
  Classes, SysUtils, fpjson, jsonparser, base64, DateUtils, MtData;

var
  DataYol, OdbYol, HatListesi: string;
  Vt: TMtDb;
  ToplamSatir, ToplamHata: Integer;
  HataListesi: TStringList;
  Arama: TSearchRec;

function OdbBoyut: Int64;
var
  S: TFileStream;
begin
  Result := -1;
  if not FileExists(OdbYol) then Exit;
  try
    S := TFileStream.Create(OdbYol, fmOpenRead or fmShareDenyNone);
    try Result := S.Size; finally S.Free; end;
  except
    Result := -1;
  end;
end;

{ Dosyayi tam olarak metin olarak okur (UTF-8). }
function DosyaOku(const Yol: string): string;
var
  S: TFileStream;
begin
  Result := '';
  if not FileExists(Yol) then Exit;
  S := TFileStream.Create(Yol, fmOpenRead or fmShareDenyNone);
  try
    SetLength(Result, S.Size);
    if S.Size > 0 then S.ReadBuffer(Result[1], S.Size);
  finally
    S.Free;
  end;
end;

{ data\veri_*.json dosyalarini tarar }
procedure HatleriBul(L: TStringList);
var
  Ad: string;
begin
  L.Clear;
  if FindFirst(IncludeTrailingPathDelimiter(DataYol) + 'veri_*.json',
      faAnyFile, Arama) = 0 then
  try
    repeat
      { veri_M8.json -> M8 }
      Ad := ExtractFileName(Arama.Name);
      Ad := Copy(Ad, 6, Length(Ad) - 5 - 5);
      Ad := UpperCase(Ad);
      if HatGecerli(Ad) then L.Add(Ad);
    until FindNext(Arama) <> 0;
  finally
    FindClose(Arama);
  end;
  L.Sorted := True;
end;

procedure Kullanim;
begin
  WriteLn('Kullanim: mtimport [--data=..\data] [--odb=..\data\mtakip.odb]');
  WriteLn('                 [--hat=M8,M5,M4,T4] [--temiz]');
end;

{ JSON degerini guvenli metne cevirir. Bos/NULL -> ''. }
function Metin(const V: string): string;
begin
  if V = '' then Result := ''
  else if V = 'null' then Result := ''
  else Result := V;
end;

procedure HataEkle(const Baglam, Mesaj: string);
begin
  Inc(ToplamHata);
  HataListesi.Add(Baglam + ' :: ' + Mesaj);
end;

{ Bir tabloyu JSON dizisinden aktarir.
  Sutunlar semadaki sirayla verilir; JSON'da olmayanlar bos gider. }
procedure TabloAktar(const Hat, Tablo: string; const Dizi: TJSONArray;
  const Sutunlar: TStringList; AnahtarAlan: string; SentetikId: Boolean);
var
  I, K, S: Integer;
  Satir: TJSONObject;
  Alanlar, Degerler: TStringList;
  Sut: TJSONData;
  MetinDeger, AnahtarDeger: string;
  Toplam: Integer;
begin
  Toplam := 0;
  Alanlar := TStringList.Create;
  Degerler := TStringList.Create;
  try
    for I := 0 to Dizi.Count - 1 do
    begin
      Satir := TJSONObject(Dizi.Items[I]);
      if Satir.JSONType <> jtObject then Continue;
      Alanlar.Clear;
      Degerler.Clear;
      for K := 0 to Sutunlar.Count - 1 do
      begin
        Alanlar.Add(Sutunlar[K]);
        Sut := Satir.Find(Sutunlar[K]);
        if (Sut = nil) or (Sut.JSONType = jtNull) then
          Degerler.Add('')
        else if (Sut.JSONType = jtString) then
          Degerler.Add(Metin(TJSONData(Sut).AsString))
        else
          Degerler.Add(Metin(TJSONData(Sut).AsString));
      end;
      { SentetikId: ilk sutun sirayla 1..N (dizi sirasini korur) }
      if SentetikId then Degerler[0] := IntToStr(I + 1);
      try
        Vt.Ekle(Hat, Tablo, Alanlar, Degerler);
        Inc(Toplam);
      except
        on E: Exception do
          HataEkle(Hat + '.' + Tablo + '[' + IntToStr(I) + ']', E.Message);
      end;
    end;
  finally
    Alanlar.Free; Degerler.Free;
  end;
  Inc(ToplamSatir, Toplam);
  WriteLn(Format('    %-22s %5d satir', [Tablo, Toplam]));
end;

{ Fotograflar: base64 -> ham bayt (BLOB). }
procedure FotolarAktar(const Hat: string; const Dizi: TJSONArray);
var
  I, S: Integer;
  Satir: TJSONObject;
  Sut: TJSONData;
  Alanlar, Degerler: TStringList;
  Ham: AnsiString;
  Sayac, Hata, ToplamBayt: Int64;
  Sicil: string;
begin
  Sayac := 0;
  Hata := 0;
  ToplamBayt := 0;
  Alanlar := TStringList.Create;
  Degerler := TStringList.Create;
  try
    for I := 0 to Dizi.Count - 1 do
    begin
      Satir := TJSONObject(Dizi.Items[I]);
      if Satir.JSONType <> jtObject then Continue;
      Sicil := '';
      Sut := Satir.Find('SICILID');
      if (Sut <> nil) and (Sut.JSONType = jtString) then Sicil := Sut.AsString;
      if Sicil = '' then begin Inc(Hata); Continue; end;
      Ham := '';
      Sut := Satir.Find('RESIM');
      if (Sut <> nil) and (Sut.JSONType = jtString) and (Sut.AsString <> '') then
        Ham := DecodeStringBase64(Sut.AsString);
      if Ham = '' then begin Inc(Hata); Continue; end;
      try
        Vt.FotoYaz(Hat, Sicil, Ham);
        Inc(Sayac);
        Inc(ToplamBayt, Length(Ham));
      except
        on E: Exception do
        begin
          Inc(Hata);
          HataEkle(Hat + '.MAKINISTRESIM[' + Sicil + ']', E.Message);
        end;
      end;
    end;
  finally
    Alanlar.Free; Degerler.Free;
  end;
  Inc(ToplamSatir, Sayac);
  WriteLn(Format('    %-22s %5d fotograf, %7d KB', ['MAKINISTRESIM',
    Sayac, ToplamBayt div 1024]));
  if Hata > 0 then
    WriteLn(Format('      %d fotograf atlandi', [Hata]));
end;

procedure AyarlariAktar(const Hat: string; const Ay: TJSONObject);
var
  I: Integer;
  Ana: string;
  Sut: TJSONData;
  Deger: string;
  Sayac: Integer;
begin
  Sayac := 0;
  for I := 0 to Ay.Count - 1 do
  begin
    Ana := Ay.Names[I];
    if not TabloGecerli(UpperCase(Ana)) then
    begin
      HataEkle(Hat + '.AYARLAR[' + Ana + ']', 'gecersiz anahtar adi');
      Continue;
    end;
    Sut := Ay.Items[I];
    if (Sut = nil) or (Sut.JSONType = jtNull) then Deger := ''
    else if Sut.JSONType = jtString then Deger := Sut.AsString
    else if Sut.JSONType = jtBoolean then Deger := BoolToStr(Sut.AsBoolean, True)
    else if Sut.JSONType = jtNumber then Deger := Sut.AsString
    else Deger := '';
    try
      Vt.AyarYaz(Hat, Ana, Deger);
      Inc(Sayac);
    except
      on E: Exception do HataEkle(Hat + '.AYARLAR[' + Ana + ']', E.Message);
    end;
  end;
  Inc(ToplamSatir, Sayac);
  WriteLn(Format('    %-22s %5d ayar', ['AYARLAR', Sayac]));
end;

{ CIZELGE_YYYY_MM aylik arsiv: semasi CIZELGE ile ayni, dinamik olusturulur. }
procedure CizelgeArsivAktar(const Hat, Tablo: string; const Dizi: TJSONArray);
var
  Sutunlar, Anahtar: TStringList;
  I: Integer;
  Olusturuldu: Boolean;
begin
  Olusturuldu := False;
  if Vt.TabloVar(Hat, Tablo) then
    Sutunlar := Vt.Sutunlar(Hat, Tablo)
  else
  begin
    { semayi CIZELGE'den al (yoksa varsayilan listeyi kur) }
    Sutunlar := Vt.Sutunlar(Hat, 'CIZELGE');
    if Sutunlar.Count = 0 then
    begin
      Sutunlar.Add('ID'); Sutunlar.Add('SIRANO'); Sutunlar.Add('SICIL');
      Sutunlar.Add('ADI'); Sutunlar.Add('GOREVI');
      for I := 1 to 31 do Sutunlar.Add('G' + IntToStr(I));
      Sutunlar.Add('SILINMIS');
    end;
    Anahtar := TStringList.Create;
    try
      Anahtar.Add('ID');
      if Vt.TabloOlustur(Hat, Tablo, Sutunlar, Anahtar) then Olusturuldu := True
      else WriteLn('    ! arsiv tablosu olusturulamadi: ', Tablo);
    finally
      Anahtar.Free;
    end;
  end;
  try
    if Olusturuldu or Vt.TabloVar(Hat, Tablo) then
      TabloAktar(Hat, Tablo, Dizi, Sutunlar, 'ID', True);
  finally
    Sutunlar.Free;
  end;
end;

{ Sifreler: data\sifreler.json -> VT_SIFRE }
procedure SifreAktar(const Yol: string);
var
  Json: TJSONData;
  I: Integer;
  Anahtar, Deger: string;
begin
  if not FileExists(Yol) then
  begin
    WriteLn('  sifreler.json yok - atlaniyor');
    Exit;
  end;
  Json := GetJSON(DosyaOku(Yol));
  if (Json = nil) or (Json.JSONType <> jtObject) then
  begin
    Json.Free;
    WriteLn('  sifreler.json okunamadi');
    Exit;
  end;
  try
    for I := 0 to TJSONObject(Json).Count - 1 do
    begin
      Anahtar := TJSONObject(Json).Names[I];
      if TJSONObject(Json).Items[I].JSONType = jtString then
        Deger := TJSONObject(Json).Items[I].AsString
      else
        Deger := '';
      Vt.SifreYaz(Anahtar, Deger);
      WriteLn('    sifre ', Anahtar, ' = ', Copy(Deger, 1, 4), '***');
    end;
  finally
    Json.Free;
  end;
end;

var
  Hatlar: TStringList;
  I, K, J: Integer;
  VeriYol: string;
  Buf: string;
  Json: TJSONData;
  Kok: TJSONObject;
  Dizi: TJSONArray;
  Sutunlar, Anahtar: TStringList;
  Sut: TJSONData;
  HatAdi: string;
  Baslangic: QWord;
  CizAdi: string;
  Skip: Boolean;
  Rapor: string;


begin
  SetMultiByteConversionCodePage(CP_UTF8);
  SetMultiByteFileSystemCodePage(CP_UTF8);
  DataYol := ExpandFileName(ExtractFilePath(ParamStr(0)) + '..' + PathDelim + 'data');
  OdbYol := '';
  HatListesi := '';
  Skip := False;
  I := 1;
  while I <= ParamCount do
  begin
    Buf := ParamStr(I);
    if Copy(Buf, 1, 7) = '--data=' then DataYol := ExpandFileName(Copy(Buf, 8, 999))
    else if Copy(Buf, 1, 6) = '--odb=' then OdbYol := ExpandFileName(Copy(Buf, 7, 999))
    else if Copy(Buf, 1, 6) = '--hat=' then HatListesi := UpperCase(Copy(Buf, 7, 999))
    else if Buf = '--temiz' then Skip := True
    else if (Buf = '-h') or (Buf = '--help') then begin Kullanim; Halt(0); end;
    Inc(I);
  end;
  if OdbYol = '' then OdbYol := IncludeTrailingPathDelimiter(DataYol) + 'mtakip.odb';

  if Skip and FileExists(OdbYol) then
  begin
    DeleteFile(OdbYol);
    WriteLn('eski .odb silindi: ', OdbYol);
  end;

  WriteLn('==============================================');
  WriteLn(' MTAKIP JSON -> VERITABANI iceri aktarma');
  WriteLn('==============================================');
  WriteLn(' veri : ', DataYol);
  WriteLn(' odb  : ', OdbYol);
  WriteLn;

  ToplamSatir := 0;
  ToplamHata := 0;
  HataListesi := TStringList.Create;
  Hatlar := TStringList.Create;
  Baslangic := GetTickCount64;

  Vt := TMtDb.Create(OdbYol);
  try
    WriteLn('--- veritabani aciliyor ---');
    Vt.Ac;
    WriteLn('    sema yuklendi, kayit sayisi: ', Vt.KayitSayisi);
    WriteLn;

    { HATLISTESI global: tum JSON dosyalarindan birlestirilir }
    if HatListesi <> '' then
      Hatlar.CommaText := HatListesi
    else
    begin
      HatleriBul(Hatlar);
      if Hatlar.Count = 0 then
      begin
        WriteLn('HATA: data klasorunde veri_*.json bulunamadi');
        WriteLn('      ', DataYol);
        Halt(1);
      end;
    end;
    Write('    bulunan hatlar:');
    for I := 0 to Hatlar.Count - 1 do Write(' ', Hatlar[I]);
    WriteLn;
    WriteLn;

    for I := 0 to Hatlar.Count - 1 do
    begin
      HatAdi := Hatlar[I];
      VeriYol := IncludeTrailingPathDelimiter(DataYol) + 'veri_' + HatAdi + '.json';
      WriteLn('--- HAT ', HatAdi, ' ---');
      if not FileExists(VeriYol) then
      begin
        WriteLn('    dosya yok, atlandi: ', VeriYol);
        Continue;
      end;

      Vt.HatEkle(HatAdi);

      Json := GetJSON(DosyaOku(VeriYol));
      if (Json = nil) or (Json.JSONType <> jtObject) then
      begin
        Json.Free;
        HataEkle(HatAdi, 'JSON okunamadi');
        Continue;
      end;
      Kok := TJSONObject(Json);
      try
        { AYARLAR }
        Sut := Kok.Find('AYARLAR');
        if (Sut <> nil) and (Sut.JSONType = jtObject) then
          AyarlariAktar(HatAdi, TJSONObject(Sut))
        else
          WriteLn('    AYARLAR yok');

        { sabit tablolar }
        for K := 0 to 8 do
        begin
          CizAdi := '';
          case K of
            0: CizAdi := 'TTDETAY';
            1: CizAdi := 'TIMETABLE';
            2: CizAdi := 'TIMETABLECEK';
            3: CizAdi := 'CIZELGE';
            4: CizAdi := 'MAKINISTEMESAJ';
            5: CizAdi := 'MANEVRA';
            6: CizAdi := 'ARACGRSLISTESI';
            7: CizAdi := 'KAZAREKOR';
          end;
          if CizAdi = '' then Continue;
          Sutunlar := Vt.Sutunlar(HatAdi, CizAdi);
          try
            if Sutunlar.Count = 0 then Continue;
            Sut := Kok.Find(CizAdi);
            if (Sut = nil) or (Sut.JSONType <> jtArray) then
            begin
              WriteLn(Format('    %-22s (yok)', [CizAdi]));
              Continue;
            end;
            TabloAktar(HatAdi, CizAdi, TJSONArray(Sut), Sutunlar,
              Sutunlar[0], CizAdi = 'CIZELGE');
          finally
            Sutunlar.Free;
          end;
        end;

        { MAKINISTRESIM ayri islenir (BLOB) }
        Sut := Kok.Find('MAKINISTRESIM');
        if (Sut <> nil) and (Sut.JSONType = jtArray) then
          FotolarAktar(HatAdi, TJSONArray(Sut))
        else
          WriteLn('    MAKINISTRESIM         (yok)');

        { aylik arsivler: CIZELGE_YYYY_MM }
        for J := 0 to Kok.Count - 1 do
        begin
          if (Pos('CIZELGE_', UpperCase(Kok.Names[J])) <> 1) then Continue;
          if (Kok.Items[J].JSONType <> jtArray) then Continue;
          WriteLn('    arsiv: ', Kok.Names[J]);
          CizelgeArsivAktar(HatAdi, UpperCase(Kok.Names[J]), TJSONArray(Kok.Items[J]));
        end;
      finally
        Kok.Free;
      end;
      WriteLn;
    end;

    { HATLISTESI tablosunu JSON'dan da doldur }
    WriteLn('--- HATLISTESI (global) ---');
    for I := 0 to Hatlar.Count - 1 do
    begin
      VeriYol := IncludeTrailingPathDelimiter(DataYol) + 'veri_' + Hatlar[I] + '.json';
      if not FileExists(VeriYol) then Continue;
      Buf := DosyaOku(VeriYol);
      Json := GetJSON(Buf);
      if Json = nil then Continue;
      Sut := TJSONObject(Json).Find('HATLISTESI');
      if (Sut <> nil) and (Sut.JSONType = jtArray) then
        for K := 0 to TJSONArray(Sut).Count - 1 do
        begin
          Buf := TJSONObject(TJSONArray(Sut).Items[K]).Find('HATADI').AsString;
          if HatGecerli(Buf) then
          begin
            if not Vt.HatVar(Buf) then Vt.HatEkle(Buf);
          end;
        end;
      Json.Free;
    end;
    WriteLn('    hatlar: ');
    Hatlar.Free;
    Hatlar := Vt.Hatlar;
    for I := 0 to Hatlar.Count - 1 do Write(' ', Hatlar[I]);
    WriteLn;
    WriteLn;

    WriteLn('--- sifreler ---');
    SifreAktar(IncludeTrailingPathDelimiter(DataYol) + 'sifreler.json');
    WriteLn;

    WriteLn('--- butunluk ---');
    if Vt.Dogrula(Rapor) then
      WriteLn('    VERIFY OK: ', Rapor)
    else
      WriteLn('    VERIFY HATA: ', Rapor);

    WriteLn;
    WriteLn('--- istatistik ---');
    WriteLn('    toplam satir : ', ToplamSatir);
    WriteLn('    hata         : ', ToplamHata);
    WriteLn('    sure         : ', Format('%.1f sn', [(GetTickCount64 - Baslangic) / 1000]));
    if ToplamHata > 0 then
    begin
      WriteLn;
      WriteLn('--- HATALAR (ilk 30) ---');
      for I := 0 to HataListesi.Count - 1 do
        if I < 30 then WriteLn('    ', HataListesi[I]);
    end;
  finally
    Vt.Free;
    Hatlar.Free;
    HataListesi.Free;
  end;
  WriteLn('    .odb boyutu  : ', Format('%.0f KB', [OdbBoyut / 1024]),
    '   (dosya kilidi acildiktan sonra olculdu)');
end.
