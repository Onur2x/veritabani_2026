unit odebug;

{$mode objfpc}{$H+}

interface

uses
  SysUtils;

procedure DebugLog(const Mesaj: string);

implementation

procedure DebugLog(const Mesaj: string);
{$IFDEF DEBUG}
var
  F: TextFile;
  LogYolu: string;
begin
  LogYolu := ExtractFilePath(ParamStr(0)) + 'debug.log';
  AssignFile(F, LogYolu);
  {$I-}
  Append(F);
  if IOResult <> 0 then
    Rewrite(F);
  {$I+}
  WriteLn(F, FormatDateTime('hh:nn:ss.zzz', Now) + ' | ' + Mesaj);
  CloseFile(F);
end;
{$ELSE}
begin
  // Debug kapalıysa hiçbir şey yapma
end;
{$ENDIF}
end.
