unit UTabloDuzenle;

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls, Grids,otablo,oTabloSchema;

type
  TFTabloDuzenle = class(TForm)
    Label1: TLabel;
    EditTabloAdi: TEdit;
    BtnEkleSatir: TButton;
    BtnKaydet: TButton;
    GridAlanlar: TStringGrid;
    MemoJSON: TMemo;
    BtnJSONGoster: TButton;

    procedure FormCreate(Sender: TObject);
    procedure BtnEkleSatirClick(Sender: TObject);
    procedure BtnKaydetClick(Sender: TObject);
    procedure BtnJSONGosterClick(Sender: TObject);
  private
    procedure AlanlariOkuVeKaydet;
    procedure GridHazirla;
  public
    procedure TabloyuYukle(const Tablo: TVTablo);
  end;

var
  FTabloDuzenle: TFTabloDuzenle;
  YeniTablo: TvTablo;
implementation

uses otypes,unit1;

{$R *.lfm}

procedure TFTabloDuzenle.FormCreate(Sender: TObject);
begin
  GridHazirla;
end;

procedure TFTabloDuzenle.GridHazirla;
begin
  GridAlanlar.ColCount := 7;
  GridAlanlar.RowCount := 2;
  GridAlanlar.Cells[0,0] := 'Alan Adı';
  GridAlanlar.Cells[1,0] := 'Tip';
  GridAlanlar.Cells[2,0] := 'Uzunluk';
  GridAlanlar.Cells[3,0] := 'PK';
  GridAlanlar.Cells[4,0] := 'AI';
  GridAlanlar.Cells[5,0] := 'NN';
  GridAlanlar.Cells[6,0] := 'Varsayılan';
end;

procedure TFTabloDuzenle.BtnEkleSatirClick(Sender: TObject);
begin
  GridAlanlar.RowCount := GridAlanlar.RowCount + 1;
end;

procedure TFTabloDuzenle.BtnKaydetClick(Sender: TObject);
begin
  AlanlariOkuVeKaydet;
end;

procedure TFTabloDuzenle.AlanlariOkuVeKaydet;
var
  Alan: TAlanTanimi;
  i, AlanSayisi: Integer;
  sm: TTabloSchema;
//    AlanlarTemp: specialize TArray<TAlanTanimi>;
begin
  YeniTablo := TvTablo.Create(EditTabloAdi.Text);
  YeniTablo.Ad := EditTabloAdi.Text;

  AlanSayisi := GridAlanlar.RowCount - 1;
  sm := TTabloSchema.Create(YeniTablo.Ad);

//  SetLength(AlanlarTemp, AlanSayisi);
  /// doldur: AlanlarTemp[i] := ...
//  sm.Alanlar := AlanlarTemp;  // sonunda aktar


 // SetLength(sm.Alanlar, AlanSayisi);  // ❗ ÖNEMLİ: dizi boyutunu ayarla


  for i := 1 to GridAlanlar.RowCount - 1 do
  begin
    Alan := Default(TAlanTanimi);
    Alan.Name := GridAlanlar.Cells[0, i];
    Alan.Tip := StrToAlanTuru(GridAlanlar.Cells[1, i]);
    Alan.Length := StrToIntDef(GridAlanlar.Cells[2, i], 64);
    Alan.PrimaryKey := LowerCase(GridAlanlar.Cells[3, i]) = 'true';
    Alan.AutoIncrement := LowerCase(GridAlanlar.Cells[4, i]) = 'true';
    Alan.NotNull := LowerCase(GridAlanlar.Cells[5, i]) = 'true';

    if Trim(GridAlanlar.Cells[6, i]) <> '' then
      Alan.DefaultDeger := GridAlanlar.Cells[6, i];

   // sm.Alanlar[i - 1] := Alan;  // index 0'dan başlıyor
    sm.AlanEkleDetayli(alan);
  end;
  // YeniTablo.Schema := sm;
  AktifVT.RegisterTableSchema(EditTabloAdi.text,sm);
 // AktifVT.TabloEkle(YeniTablo.Ad, YeniTablo, []);
  ShowMessage('✅ Tablo eklendi: ' + YeniTablo.Ad);
end;

procedure TFTabloDuzenle.BtnJSONGosterClick(Sender: TObject);
begin
  MemoJSON.Text := YeniTablo.Schema.ToJSON.AsJSON;
end;

procedure TFTabloDuzenle.TabloyuYukle(const Tablo:TVTablo);
var
  i:Integer;
  Alan:TAlanTanimi;
begin
  EditTabloAdi.Text := Tablo.Ad;

  for i := 1 to tablo.Schema.AlanSayisi - 1 do
  begin
    Alan := Default(TAlanTanimi);
    alan:=tablo.Schema.Alanlar[i];
    GridAlanlar.Cells[0,i]:=Alan.Name;
    GridAlanlar.Cells[1,i]:=AlanTuruToStr(Alan.Tip);
    GridAlanlar.Cells[2,i]:=inttostr(Alan.Length);
    GridAlanlar.Cells[3,i]:=BoolToStr(Alan.PrimaryKey);
    GridAlanlar.Cells[4,i]:=BoolToStr(Alan.AutoIncrement);
    GridAlanlar.Cells[5,i]:=BoolToStr(Alan.NotNull);
    GridAlanlar.Cells[6,i]:=Alan.DefaultDeger;
     GridAlanlar.RowCount := GridAlanlar.RowCount +1;
   // YeniTablo.Schema.Alanlar[i - 1] := Alan;
  end;
  // Alanları Grid'e dökmek için ek fonksiyon yazılabilir
end;

end.
