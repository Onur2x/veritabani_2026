unit UTabloOlustur;

interface

uses
  Classes,Grids,SysUtils,Forms,Controls,Graphics,Dialogs,StdCtrls,ExtCtrls,
  ComCtrls;

type
  TFTabloOlustur = class(TForm)
    Panel1: TPanel;
    Label1: TLabel;
    EditTabloAdi: TEdit;
    BtnAlanEkle: TButton;
    BtnOlustur: TButton;
    BtnExportJSON: TButton;
    MemoJSON: TMemo;

    GroupBoxAlan: TGroupBox;
    EditAlanAdi: TEdit;
    ComboTip: TComboBox;
    EditUzunluk: TEdit;
    CheckPK: TCheckBox;
    CheckAutoInc: TCheckBox;
    CheckNotNull: TCheckBox;
    EditDefault: TEdit;
    StringGrid1:TStringGrid;

    procedure FormCreate(Sender: TObject);
    procedure BtnAlanEkleClick(Sender: TObject);
    procedure BtnExportJSONClick(Sender: TObject);
    procedure BtnOlusturClick(Sender: TObject);
  private
    procedure GriddenAlanlariOku;
    procedure TemizleAlanGirisi;
  public
    { public declarations }
  end;

var
  FTabloOlustur: TFTabloOlustur;

implementation

uses
 unit1,otypes,otablo,overitabani,odebug,oTabloSchema;//, UTabloVerisi, UJSONYazici; // Bu unitleri senin projen destekliyor olmalı

 VAR
 sm:TTabloSchema;
{$R *.lfm}

procedure TFTabloOlustur.GriddenAlanlariOku;
var
  i: Integer;
  Alan: TAlanTanimi;
   S: TTabloSchema;

begin
  for i := 1 to StringGrid1.RowCount - 1 do
  begin
    Alan := Default(TAlanTanimi);
    Alan.Name := StringGrid1.Cells[0, i];
    Alan.Tip := StrToAlanTuru(StringGrid1.Cells[1, i]);
    Alan.Length := StrToIntDef(StringGrid1.Cells[2, i], 255);
    Alan.PrimaryKey := LowerCase(StringGrid1.Cells[3, i]) = 'true';
    Alan.AutoIncrement := LowerCase(StringGrid1.Cells[4, i]) = 'true';
    Alan.NotNull := LowerCase(StringGrid1.Cells[5, i]) = 'true';
    if Trim(StringGrid1.Cells[6, i]) <> '' then
      Alan.DefaultDeger := StringGrid1.Cells[6, i];


   S := AktifVT.GetTableSchema(EditTabloAdi.Text);
   S.AlanEkleDetayli(Alan);

  // AktifVT.TabloByName[EditTabloAdi.Text].Schema.AlanEkleDetayli(Alan);
  end;
end;

procedure TFTabloOlustur.FormCreate(Sender: TObject);
begin
  ComboTip.Items.AddStrings(['Text', 'Integer', 'Float']);
  ComboTip.ItemIndex := 0;
  with StringGrid1 do
  begin
    RowCount := 2; // Başlık + 1 örnek satır
    ColCount := 7;

    Cells[0, 0] := 'Alan Adı';
    Cells[1, 0] := 'Tip';
    Cells[2, 0] := 'Uzunluk';
    Cells[3, 0] := 'PK';
    Cells[4, 0] := 'AI';
    Cells[5, 0] := 'NN';
    Cells[6, 0] := 'DEFAULT';
  end;
end;

procedure TFTabloOlustur.BtnAlanEkleClick(Sender: TObject);
var
 a:TAlanTanimi;
 S: TTabloSchema;
begin
  a.AutoIncrement := CheckAutoInc.Checked;
  a.name := EditAlanAdi.Text;
  a.Tip := StrToAlanTuru(ComboTip.Text);
  a.Length:= StrToIntDef(EditUzunluk.Text, 255);
  a.PrimaryKey:=CheckPK.Checked;
  a.NotNull:= CheckNotNull.Checked;
  a.DefaultDeger:=EditDefault.Text;
  s.AlanEkleDetayli(a);
  AktifVT.RegisterTableSchema(EditTabloAdi.Text,S);

//  AktifVT.TabloByName[EditTabloAdi.Text].Schema :=sm;
//  S := AktifVT.GetTableSchema(EditTabloAdi.Text);

  TemizleAlanGirisi;
end;

procedure TFTabloOlustur.BtnOlusturClick(Sender: TObject);
//var
//  YeniTablo: TvTablo;
begin
 // YeniTablo := TvTablo.Create(EditTabloAdi.text);
  try
//    YeniTablo.Ad := EditTabloAdi.Text;
//    YeniTablo.Schema := Tablo; // Şema aktarımı
 //   YeniTablo.SonID := 0;
 //
   // AktifVT.TabloEkle(EditTabloAdi.Text,YeniTablo,[]); // Veritabanına ekleme
    sm:=TTabloSchema.Create('SEMA');

    AktifVT.CreateTable(EditTabloAdi.Text,sm);
    DebugLog('✅ Tablo eklendi → ' );
  except
    on E: Exception do
      DebugLog('❌ Tablo eklenemedi: ' + E.Message);
  end;
//end;

//begin
//AktifVT.TabloEkle(EditTabloAdi.Text,,[]);

//  AktifVT.TabloByName[EditTabloAdi.name].Ad:=(EditTabloAdi.Text);
//  ShowMessage('✅ Tablo oluşturuldu: ' + AktifVT.TabloByName[EditTabloAdi.name].Ad);
end;

procedure TFTabloOlustur.BtnExportJSONClick(Sender: TObject);
begin
//  MemoJSON.Text := AktifVT.TabloByName[EditTabloAdi.Text].Schema.ToJSON.AsString;
end;

procedure TFTabloOlustur.TemizleAlanGirisi;
begin
  EditAlanAdi.Text := '';
  ComboTip.ItemIndex := 0;
  EditUzunluk.Text := '';
  CheckPK.Checked := False;
  CheckAutoInc.Checked := False;
  CheckNotNull.Checked := False;
  EditDefault.Text := '';
end;

end.
