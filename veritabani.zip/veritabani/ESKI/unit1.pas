unit Unit1;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, Variants,
  Forms, Controls, Graphics, Dialogs,
  Grids, ComCtrls, ExtCtrls, Menus, StdCtrls,
  Generics.Collections,
  oVeritabani, oTypes, osqlengine,oTabloSchema;

type
  TLogSeviyesi = (lsInfo, lsUyari, lsHata, lsDebug);

  { TForm1 }

  TForm1 = class(TForm)
    Edit1:TEdit;
    LV:TListView;
    MainMenu1: TMainMenu;
    MenuItem1: TMenuItem;
    MenuItem2: TMenuItem; // Yeni DB
    MenuItem3: TMenuItem; // Load
    MenuItem4: TMenuItem; // Save
    PageControl1:TPageControl;
    Panel1:TPanel;
    Panel2:TPanel;
    Panel3:TPanel;
    Panel4:TPanel;
    Panel5:TPanel;
    Separator1: TMenuItem;
    Separator2: TMenuItem;
    MenuItem5: TMenuItem;
    MenuItem6: TMenuItem;
    MenuItem7: TMenuItem;
    MenuItem8: TMenuItem;
    MenuItem9: TMenuItem;
    MenuItem10: TMenuItem;
    MenuItem11: TMenuItem;
    SmallImages:TImageList;
    Splitter1:TSplitter;
    Splitter2:TSplitter;
    TabSheet1:TTabSheet;
    TabSheet2:TTabSheet;

    ToolBar1: TToolBar;
    ToolButton1: TToolButton;

    Button1: TButton;
    Button2: TButton;
    Button3: TButton;
    Button4: TButton;
    Button5: TButton; // SQL yürüt
    Button6: TButton;
    Button7: TButton; // 10 kayıt ekle örnek
    Button8: TButton;
    Button9: TButton; // Düzenle

    OpenDialog1: TOpenDialog;
    SaveDialog1: TSaveDialog;

    TreeView1: TTreeView;
    StringGrid1: TStringGrid;
    MemoSQL: TMemo;
    LabelSonuc: TLabel;
    LabelDBInfo: TLabel;
    ListView1: TListView;

    procedure FormCreate(Sender: TObject);
    procedure FormClose(Sender: TObject; var CloseAction: TCloseAction);

    procedure MenuItem2Click(Sender: TObject);
    procedure MenuItem3Click(Sender: TObject);
    procedure MenuItem4Click(Sender: TObject);

    procedure Button5Click(Sender: TObject);
    procedure Button7Click(Sender: TObject);
    procedure Button9Click(Sender: TObject);
    procedure MenuItem7Click(Sender:TObject);
    procedure TreeView1SelectionChanged(Sender: TObject);

  private
    VeritabaniListesi: specialize TObjectList<TVeritabani>;
    AktifVT: TVeritabani;

    procedure ShowTableInGrid(const Database,TableName:string);
    procedure TreeViewEkranaYukle;
    procedure TreeViewVeritabaniEkle(VT: TVeritabani);
    procedure GridDoldur(const VT: TVeritabani; const TableName: string);
    procedure GridDoldur(const Schema: TTabloSchema; const Rows: specialize TList<TRow>);
    procedure LogEkle(const Mesaj: string; Seviye: TLogSeviyesi);

    function NormalizeSQL(const Source: string): string;
    procedure UpdateTreeView;
  public
  end;

var
  Form1: TForm1;

implementation

uses
  jsonparser,DateUtils,StrUtils,fRowEditor;

{$R *.lfm}


procedure TForm1.GridDoldur(const Schema: TTabloSchema; const Rows: specialize TList<TRow>);
var
  colCount, rowCount, i, j: Integer;
  r: TRow;
begin
  colCount := Schema.AlanSayisi;
  rowCount := Rows.Count;

  StringGrid1.ColCount := colCount;
  StringGrid1.RowCount := rowCount + 1;

  for i := 0 to colCount - 1 do
    StringGrid1.Cells[i,0] := Schema.Alanlar[i].Name;

  for j := 0 to rowCount - 1 do
  begin
    r := Rows[j];
    for i := 0 to colCount - 1 do
      StringGrid1.Cells[i, j+1] :=
        VarToStrDef(r[Schema.Alanlar[i].Name], '');
  end;

  LabelSonuc.Caption := Format('🔔 %d kayıt gösterildi.', [rowCount]);
end;

{-------------------------------------------------------------------------------
  FormCreate / FormClose
-------------------------------------------------------------------------------}
procedure TForm1.FormCreate(Sender: TObject);
begin
  VeritabaniListesi := specialize TObjectList<TVeritabani>.Create(True);

  // Başlangıçta bir boş VT
  AktifVT := TVeritabani.Create;
  AktifVT.Ad := 'YeniVT';
  VeritabaniListesi.Add(AktifVT);

  TreeViewEkranaYukle;
  LabelDBInfo.Caption := 'Aktif: ' + AktifVT.Ad;
end;

procedure TForm1.FormClose(Sender: TObject; var CloseAction: TCloseAction);
begin
  VeritabaniListesi.Free;
end;

{-------------------------------------------------------------------------------
  MenuItem – Yeni / Load / Save
-------------------------------------------------------------------------------}
procedure TForm1.MenuItem2Click(Sender: TObject);
begin
  // Yeni veritabanı
  AktifVT := TVeritabani.Create;
  AktifVT.Ad := 'Veritabani' + IntToStr(VeritabaniListesi.Count);
  VeritabaniListesi.Add(AktifVT);
  TreeViewEkranaYukle;
  LogEkle('🛠 Yeni VT: ' + AktifVT.Ad, lsInfo);
end;

procedure TForm1.MenuItem3Click(Sender: TObject);
begin
  // Load compressed JSON
  if OpenDialog1.Execute then
  begin
    AktifVT := TVeritabani.Create;
    AktifVT.LoadFromFile(OpenDialog1.FileName);
    VeritabaniListesi.Add(AktifVT);
    TreeViewEkranaYukle;
    LogEkle('📂 Yüklendi: ' + AktifVT.Ad, lsInfo);
  end;
end;

procedure TForm1.MenuItem4Click(Sender: TObject);
begin
  // Save compressed JSON
  if SaveDialog1.Execute then
  begin
    AktifVT.SaveToFile(SaveDialog1.FileName);
    LogEkle('💾 Kaydedildi: ' + AktifVT.Ad, lsInfo);
  end;
end;

{-------------------------------------------------------------------------------
  TreeView doldurma ve seçim
-------------------------------------------------------------------------------}
procedure TForm1.TreeViewEkranaYukle;
var
  i: Integer;
begin
  TreeView1.Items.BeginUpdate;
  try
    TreeView1.Items.Clear;
    for i := 0 to VeritabaniListesi.Count - 1 do
      TreeViewVeritabaniEkle(VeritabaniListesi[i]);
  finally
    TreeView1.Items.EndUpdate;
  end;
end;

procedure TForm1.TreeViewVeritabaniEkle(VT: TVeritabani);
var
  root: TTreeNode;
  names: specialize TArray<string>;
  i: Integer;
begin
  root := TreeView1.Items.Add(nil, VT.Ad);
  root.Data := VT;
  // Çocuklar = tablo adları
  names := VT.TabloAdlari;
  for i := 0 to High(names) do
    TreeView1.Items.AddChild(root, names[i]);
end;



procedure TForm1.ShowTableInGrid(const Database, TableName: string);
var
  rows: specialize TList<TRow>;
  schema: TTabloSchema;
  i, j: Integer;
begin
  rows := AktifVT.GetRows(TableName);
  schema := AktifVT.GetTableSchema(TableName);

  StringGrid1.RowCount := rows.Count + 1;
  StringGrid1.ColCount := schema.AlanSayisi;

  // Sütun başlıklarını ata
  for j := 0 to schema.AlanSayisi - 1 do
    StringGrid1.Cells[j,0] := schema.Alanlar[j].Name;

  // Satırları doldur
  for i := 0 to rows.Count - 1 do
    for j := 0 to schema.AlanSayisi - 1 do
      StringGrid1.Cells[j, i+1] := VarToStr(rows[i].Values[schema.Alanlar[j].Name]);
end;


procedure TForm1.TreeView1SelectionChanged(Sender: TObject);
var
  node: TTreeNode;
  dbName,tblName: string;
begin
if (Node = nil) or (Node.Parent = nil) then
    Exit; // Veritabanı düğümü → tablo değil!

  dbName := Node.Parent.Text;
  tblName := Node.Text;

  LabelDBInfo.Caption:=(Format('Seçilen: %s.%s', [dbName, tblName]));
  ShowTableInGrid(dbName, tblName);
 { node := TreeView1.Selected;
  if not Assigned(node) then Exit;

  if node.Level = 0 then
  begin
    // Veritabanı seçildi
    AktifVT := TVeritabani(node.Data);
    LabelDBInfo.Caption := 'Aktif: ' + AktifVT.Ad;
    LogEkle('Seçildi VT: ' + AktifVT.Ad, lsInfo);
  end
  else if node.Level = 1 then
  begin
    // Tablo seçildi
    AktifVT := TVeritabani(node.Parent.Data);
    tblName := node.Text;
    LabelDBInfo.Caption := Format('VT: %s | Tablo: %s', [AktifVT.Ad, tblName]);
    LogEkle(Format('Seçildi Tablo: %s.%s', [AktifVT.Ad, tblName]), lsInfo);
    GridDoldur(AktifVT, tblName);
  end;     }
end;


procedure TForm1.UpdateTreeView;
var
  dbNode, tblNode: TTreeNode;
  dbList, tblList: TStringList;
  i, j: Integer;
begin
  TreeView1.Items.BeginUpdate;
  try
    TreeView1.Items.Clear;

    dbList := AktifVT.GetDatabaseNames;
    try
      for i := 0 to dbList.Count - 1 do
      begin
        dbNode := TreeView1.Items.Add(nil, dbList[i]);
        dbNode.ImageIndex := 0; dbNode.SelectedIndex := 0;

        tblList := AktifVT.GetTableNames(dbList[i]);
        try
          for j := 0 to tblList.Count - 1 do
          begin
            tblNode := TreeView1.Items.AddChild(dbNode, tblList[j]);
            tblNode.ImageIndex := 1; tblNode.SelectedIndex := 1;
          end;
        finally
          tblList.Free;
        end;

        dbNode.Expand(False);
      end;
    finally
      dbList.Free;
    end;
  finally
    TreeView1.Items.EndUpdate;
  end;
end;



{-------------------------------------------------------------------------------
  Grid doldurma – yeni sisteme göre
-------------------------------------------------------------------------------}
procedure TForm1.GridDoldur(const VT: TVeritabani; const TableName: string);
var
  schema : TTabloSchema;
  rows   : specialize TList<TRow>;
  colCount, rowCount: Integer;
  i, j   : Integer;
  r      : TRow;
begin
  // Şema ve satırlar
  schema := VT.GetTableSchema(TableName);
  rows   := VT.GetDataTable(TableName);

  colCount := schema.AlanSayisi;
  rowCount := rows.Count;

  StringGrid1.ColCount := colCount;
  StringGrid1.RowCount := rowCount + 1;

  // Header
  for i := 0 to colCount - 1 do
    StringGrid1.Cells[i,0] := schema.Alanlar[i].Name;

  // Veriler
  for j := 0 to rowCount - 1 do
  begin
    r := rows[j];
    for i := 0 to colCount - 1 do
      StringGrid1.Cells[i,j+1] :=
        VarToStrDef(r[schema.Alanlar[i].Name], '');
  end;

  LabelSonuc.Caption := Format('🔔 %d kayıt gösterildi.', [rowCount]);
end;


function NormalizeSQL(const Source: string): string;
begin
  Result := StringReplace(Source, #13#10, ' ', [rfReplaceAll]);
  Result := StringReplace(Result, #10, ' ', [rfReplaceAll]);
  Result := StringReplace(Result, #13, ' ', [rfReplaceAll]);
end;
{-------------------------------------------------------------------------------
  Button5 – SQL yürüt
-------------------------------------------------------------------------------}
procedure TForm1.Button5Click(Sender: TObject);
var
  Komutlar: TStringList;
  Engine  : TSqlEngine;
  R       : TSqlCommand;
  SQL     : string;
  i, j    : Integer;
  satir   : string;
  Cmd     : TSqlCommand;
  CmdHistory: specialize TList<TSqlCommand>;
  dbNode, tblNode: TTreeNode;

begin
    SQL := NormalizeSQL(MemoSQL.Text);
    Engine := TSqlEngine.Create(AktifVT);
    // 1) SQL’i çalıştır
    Engine.ExecuteSQL(SQL,R);
    // 2) Oluşturulan tüm komutları al
    CmdHistory := Engine.CommandHistory;

    // 3) Her komutu tek tek kontrol et
  for i := 0 to CmdHistory.Count-1 do
  begin
    case CmdHistory[i].CmdType of

      ctCreateDatabase:
        begin
          // Aynı isimde bir düğüm yoksa ekle
          if TreeView1.Items.FindNodeWithText(CmdHistory[i].DatabaseName)=nil then
            TreeView1.Items.Add(nil, CmdHistory[i].DatabaseName);
        end;

      ctCreateTable:
        begin
          // Önce oluşturulduğu DB düğümünü bul

          WriteLn(CmdHistory[i].DatabaseName,'  ',CmdHistory[i].TableName);
          dbNode := TreeView1.Items.FindNodeWithText(CmdHistory[i].DatabaseName);
          if Assigned(dbNode) then
          begin
            if TreeView1.Items.FindNodeWithText(CmdHistory[i].TableName) = nil then
              TreeView1.Items.AddChild(dbNode, CmdHistory[i].TableName);
          end;
        end;
        ctDropTable:
        begin
          tblNode := TreeView1.Items.FindNodeWithText(Cmd.TableName);
          if Assigned(tblNode) then
            tblNode.Free;
        end;
        ctSelect:
        begin
             ShowTableInGrid(CmdHistory[i].DatabaseName, CmdHistory[i].TableName);
        end;
      // Drop/Alter işlemlerini de benzer şekilde yakalayabilirsiniz
    end;

    for j := 0 to High(CmdHistory[i].SatirMesajlari) do
     LogEkle(CmdHistory[i].SatirMesajlari[j], lsDebug);

    LogEkle(CmdHistory[i].OriginalSQL + ' → ' +
      strutils.IfThen(CmdHistory[i].Basarili, 'BAŞARILI✅ '+CmdHistory[i].SorguTipi, 'HATA ❌ '+CmdHistory[i].HataMesaji),lsInfo);

  end;





 { try
    if R.Basarili then
    begin
      if R.SorguTipi = 'SELECT' then
        GridDoldur(R.Schema, R.Data);
     { else
        GridDoldur(R.Veritabani, R.TableName);
       }
      LogEkle(Format('%s → %d kayıt (%.3fs)',
        [R.SorguTipi, R.KayitSayisi, MilliSecondsBetween(0, R.Sure)/1000]), lsInfo);
    end
    else
      LogEkle('HATA: ' + R.HataMesaji, lsHata);
  }
    // Debug detayları
  //  lv.Lines.AddStrings(R.SatirMesajlari);

   //  for j := 0 to High(R.SatirMesajlari) do
  //        LogEkle(R.SatirMesajlari[j], lsDebug);

    // Hepsini görmek istersen:
{  for Cmd in Engine.CommandHistory do
  begin
    for j := 0 to High(cmd.SatirMesajlari) do
     LogEkle(cmd.SatirMesajlari[j], lsDebug);

    LogEkle(Cmd.OriginalSQL + ' → ' +
      strutils.IfThen(Cmd.Basarili, 'BAŞARILI✅ '+Cmd.SorguTipi, 'HATA ❌ '+Cmd.HataMesaji),lsInfo);
     //if Cmd.SorguTipi = 'SELECT' then
   //     GridDoldur(Cmd.Schema, Cmd.Data);
  end;   }

  //finally
   // R.Free;
 // end;

//  Komutlar := TStringList.Create;
 { try
    SQL := NormalizeSQL(MemoSQL.Text);
    Engine := TSqlEngine.Create(AktifVT);
    try
      ExtractStrings([';'], [], PChar(SQL), Komutlar);
      for i := 0 to Komutlar.Count-1 do
      begin
        satir := Trim(Komutlar[i]);
        if satir = '' then Continue;
        R := Engine.KomutYurut(satir);
        try
          if not R.Basarili then
          begin
            LogEkle('❌ Hata: ' + R.HataMesaji, lsHata);
            Continue;
          end;

          // Yeni db oluşturma
          if R.SorguTipi = 'CREATE DATABASE' then
          begin
            AktifVT := R.Veritabani;
            VeritabaniListesi.Add(AktifVT);
            TreeViewEkranaYukle;
            LogEkle('🛠 Veritabanı oluşturuldu: ' + AktifVT.Ad, lsInfo);
          end;

          // CREATE TABLE / ALTER TABLE
          if (R.SorguTipi = 'CREATE TABLE') or (R.SorguTipi = 'ALTER TABLE') then
          begin
            TreeViewEkranaYukle;
            LogEkle('📦 Tablo şeması güncellendi.', lsInfo);
          end;

          // SELECT veya INSERT/UPDATE/DELETE sonrası tablo güncelle
          if Assigned(R.Tablo) then
          begin
            GridDoldur(AktifVT, R.Tablo.Ad);
            LogEkle(Format('✅ %s: %d kayıt', [R.SorguTipi, R.Tablo.KayitSayisi]), lsInfo);
          end
          else
            LogEkle('✅ ' + satir, lsInfo);

          // Debug satırlar
          for j := 0 to R.SatirMesajlari.Count-1 do
            LogEkle(R.SatirMesajlari[j], lsDebug);

        finally
          R.Free;
        end;
      end;
    finally
      Engine.Free;
    end;
  finally
    Komutlar.Free;
  end;
  }
end;

{-------------------------------------------------------------------------------
  Button7 – 10 adet test kaydı ekle
-------------------------------------------------------------------------------}
procedure TForm1.Button7Click(Sender: TObject);
var
  cols, vals: specialize TArray<string>;
  i: Integer;
  tbl: string;
begin
  tbl := 'DENEME'; // örnek tablo adı
  // Kolon isimleri
  cols := ['ID','AD'];
  for i := 1 to 10 do
  begin
    vals := [IntToStr(i), 'Kayit'+IntToStr(i)];
    AktifVT.InsertInto(tbl, cols, vals);
  end;
  GridDoldur(AktifVT, tbl);
  LogEkle(Format('📥 %d kayıt eklendi: %s', [10, tbl]), lsInfo);
end;

{-------------------------------------------------------------------------------
  Button9 – Tablo Düzenle (varsa)
-------------------------------------------------------------------------------}
procedure TForm1.Button9Click(Sender: TObject);
begin
  // Eskiden TVTablo kullanıyordunuz. Yeni sisteme göre, schema'ya
  // doğrudan erişip eklemek / bir form açmak isterseniz:
  // var schema := AktifVT.GetTableSchema(EditTabloAdi.Text);
  // vs.
  ShowMessage('Tablo Düzenle formu burada açılacak.');
end;

procedure TForm1.MenuItem7Click(Sender:TObject);
begin
close;
end;

{-------------------------------------------------------------------------------
  Log ekleme
-------------------------------------------------------------------------------}
procedure TForm1.LogEkle(const Mesaj: string; Seviye: TLogSeviyesi);
var
  itm: TListItem;
  saat: string;
begin
  saat := FormatDateTime('hh:nn:ss', Now);
  itm := LV.Items.Insert(0);
  itm.Caption := saat;
  itm.SubItems.Add(Mesaj);
  case Seviye of
    lsInfo: itm.ImageIndex := 0;
    lsUyari: itm.ImageIndex := 1;
    lsHata: itm.ImageIndex := 2;
    lsDebug: itm.ImageIndex := 3;
  end;
end;

{-------------------------------------------------------------------------------
  SQL normalize (tek satıra indirme)
-------------------------------------------------------------------------------}
function TForm1.NormalizeSQL(const Source: string): string;
begin
  Result := StringReplace(Source, #13#10, ' ', [rfReplaceAll]);
  Result := StringReplace(Result, #13,   ' ', [rfReplaceAll]);
  Result := StringReplace(Result, #10,   ' ', [rfReplaceAll]);
end;

end.
