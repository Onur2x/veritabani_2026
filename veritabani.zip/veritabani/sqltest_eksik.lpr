program sqltest_eksik;
{ VDB SQL - EKSIK TESTLER (sql.md'e gore sqltest.lpr'de kapsanmamis 3 madde).
  Bu dosya sqltest.lpr ile AYNI cerceveyi (Grp/Chk/ChkVal/ChkErr/ChkInt/
  UseDir/Shutdown) kullanir; yalnizca eksik kalan test gruplari eklenmistir.
  Derleme:  lazbuild sqltest_eksik.lpi
  Calistirma: sqltest_eksik.exe <calisma-klasoru>
  (klasor verilmezse gecici klasor kullanilir.)

  Kapsananlar:
    T79 - OPEN/USE/CLOSE DATABASE + 64 karakter guvenlik siniri
    T80 - BACKUP TO 'dosya.odb' (tutarli yedek, icerik dogrulamasi)
    T81 - UPDATE ... SET aritmetigi (tam bolme, /0, %0, metin hata, NULL+1)

  NOT: sql.md bolum 4 ve 7 bu davranislari "var" olarak listeler; sqltest.lpr
  ise bunlari hic test etmiyordu (grep ile dogrulandi). }

{$mode delphi}{$H+}

uses
  SysUtils, Classes, VDbCore, VDbTable, VDbSql, VDbSync, VDbCrc32, VDbCrypt;

var
  D: string;
  kv: TVDb;
  tb: TVTableDb;
  sq: TVSql;
  R: TSqlResult;
  nPass, nFail, nGrp: Integer;
  grpName: string;

const
  Q = '''';   // tek tirnak
  WAL_MAGIC_BEKLENEN = LongWord($57414C52);   // 'WALR'

{ ------------------------------------------------------------ yardimcilar }

procedure Grp(const N: string);
begin
  Inc(nGrp);
  grpName := N;
  WriteLn;
  WriteLn('== ', nGrp, '. ', N);
end;

procedure Ok(const Nm, E: string);
begin
  Inc(nPass);
  if E = '' then WriteLn('   OK   ', Nm)
  else WriteLn('   OK   ', Nm, '   [', E, ']');
end;

procedure No(const Nm, E: string);
begin
  Inc(nFail);
  WriteLn('   FAIL ', Nm, '   [', E, ']');
end;

procedure Chk(const Nm, Sql: string; const ExpectRows: Integer);
var e: string;
begin
  try
    R := sq.Exec(Sql);
    if ExpectRows >= 0 then
    begin
      if Length(R.Rows) = ExpectRows then Ok(Nm, IntToStr(Length(R.Rows)) + ' satir')
      else No(Nm, 'beklenen ' + IntToStr(ExpectRows) + ' satir, gelen ' +
                 IntToStr(Length(R.Rows)));
    end
    else Ok(Nm, '');
  except
    on E: Exception do No(Nm, '(' + E.Message + ')');
  end;
end;

procedure ChkVal(const Nm, Sql: string; RowIx, ColIx: Integer;
  const Want: string);
var got: string;
begin
  try
    R := sq.Exec(Sql);
    if (RowIx >= Length(R.Rows)) or (ColIx >= Length(R.Rows[RowIx])) then
    begin
      No(Nm, 'sonuc hucre yok (satir ' + IntToStr(RowIx) + '/' +
              IntToStr(Length(R.Rows)) + ')');
      Exit;
    end;
    got := R.Rows[RowIx][ColIx];
    if got = Want then Ok(Nm, got)
    else No(Nm, 'beklenen "' + Want + '" gelen "' + got + '"');
  except
    on E: Exception do No(Nm, '(' + E.Message + ')');
  end;
end;

procedure ChkHas(const Nm, Sql, Want: string);
var
  all: string;
  k: Integer;
begin
  try
    R := sq.Exec(Sql);
    all := '';
    for k := 0 to High(R.Rows) do
      all := all + R.Rows[k][0] + ' | ';
    if Pos(Want, all) > 0 then Ok(Nm, 'bulundu: ' + Want)
    else No(Nm, '"' + Want + '" bulunamadi; plan: ' + all);
  except
    on E: Exception do No(Nm, '(' + E.Message + ')');
  end;
end;

procedure ChkHas2(const Nm, Sql, Want: string);
var
  all: string;
  k, c: Integer;
begin
  try
    R := sq.Exec(Sql);
    all := '';
    for k := 0 to High(R.Rows) do
      for c := 0 to High(R.Rows[k]) do
        all := all + R.Rows[k][c] + ' | ';
    if Pos(Want, all) > 0 then Ok(Nm, 'bulundu: ' + Want)
    else No(Nm, '"' + Want + '" bulunamadi; icerik: ' + all);
  except
    on E: Exception do No(Nm, '(' + E.Message + ')');
  end;
end;

procedure Dump(const Nm, Sql: string);
var
  acc: string;
  k: Integer;
begin
  try
    R := sq.Exec(Sql);
    acc := '';
    for k := 0 to High(R.Rows) do
    begin
      if k > 0 then acc := acc + ' | ';
      acc := acc + R.Rows[k][0];
    end;
    Ok(Nm, acc);
  except
    on E: Exception do Ok(Nm, 'HATA: ' + E.Message);
  end;
end;

procedure ChkErr(const Nm, Sql: string);
begin
  try
    sq.Exec(Sql);
    No(Nm, 'HATA VERMEDI (kabul edildi)');
  except
    on E: Exception do Ok(Nm, E.Message);
  end;
end;

procedure ChkInt(const Nm: string; const Got, Expect: Integer);
begin
  if Got = Expect then Ok(Nm, IntToStr(Got))
  else No(Nm, 'beklenen ' + IntToStr(Expect) + ', gelen ' + IntToStr(Got));
end;

procedure Fresh(const Nm: string);
var p: string;
begin
  p := D + '\' + Nm;
  ForceDirectories(p);
  if tb <> nil then begin tb.Close; kv.Close; sq.Free; tb.Free; kv.Free; end;
  kv := TVDb.Create; tb := TVTableDb.Create(kv); sq := TVSql.Create(tb);
  kv.Open(p);
  tb.Open(p);
end;

procedure UseDir(const Nm: string);
var p: string;
begin
  p := D + '\' + Nm;
  ForceDirectories(p);
  if tb <> nil then begin tb.Close; kv.Close; sq.Free; tb.Free; kv.Free; end;
  kv := TVDb.Create; tb := TVTableDb.Create(kv); sq := TVSql.Create(tb);
  kv.Open(p);
  tb.Open(p);
end;

procedure Shutdown;
begin
  if tb <> nil then
  begin
    tb.Close; kv.Close; sq.Free; tb.Free; kv.Free;
    sq := nil; tb := nil; kv := nil;
  end;
end;

{ ============================================================ T79
  Veritabani yonetim: OPEN / USE / CLOSE DATABASE + guvenlik siniri.
  sql.md bolum 4: OPEN/USE etkin db degistirir + otomatik Verify;
  CLOSE sonrasi her komut net hata ('veritabani kapali ...');
  ad 64 karakterden uzun / yol ayirici / '..' reddedilir.
  T01_Veritabani CREATE/DROP/LIST/SHOW + yol ayirici/..'i kapsar ama
  OPEN/USE/CLOSE ve 64 karakter sinirini KAPSAMAZ. }

procedure T79_VeritabaniYonetim;
begin
  Grp('Veritabani yonetim: OPEN/USE/CLOSE DATABASE + guvenlik (64 karakter)');
  UseDir('yon');
  Chk('CREATE DATABASE satis', 'CREATE DATABASE satis', -1);
  Chk('CREATE DATABASE baska', 'CREATE DATABASE baska', -1);

  // OPEN DATABASE: etkin db degistirir (motor nesnesi ayni kalir)
  Chk('OPEN DATABASE satis', 'OPEN DATABASE satis', -1);
  // USE: OPEN DATABASE kisayolu
  Chk('USE baska (OPEN kisayolu)', 'USE baska', -1);
  R := sq.Exec('LIST DATABASES');
  Ok('LIST DATABASES calisti', IntToStr(R.Affected) + ' veritabani');
  R := sq.Exec('SHOW DATABASES');
  Ok('SHOW DATABASES = LIST', IntToStr(R.Affected));

  // CLOSE DATABASE sonrasi diger tum komutlar net hata verir
  Chk('CLOSE DATABASE', 'CLOSE DATABASE', -1);
  ChkErr('CLOSE sonrasi SELECT hata', 'SELECT 1');
  ChkErr('CLOSE sonrasi CREATE TABLE hata', 'CREATE TABLE x(id INTEGER PRIMARY KEY)');
  ChkErr('CLOSE sonrasi INSERT hata', 'INSERT INTO x(id) VALUES(1)');

  // yeniden ac (ayni referanslar gecerli kalir)
  Chk('OPEN DATABASE ile yeniden ac', 'OPEN DATABASE baska', -1);
  Chk('yeniden ac sonrasi SELECT calisir', 'SELECT 1', 1);

  // var olmayan veritabani acilamaz (bos dosya olusturulmaz)
  ChkErr('OPEN olmayan veritabani (hata)', 'OPEN DATABASE yokboyle');

  // guvenlik: 64+ karakter reddedilir
  ChkErr('veritabani adi 64+ karakter (hata)',
      'CREATE DATABASE ' + Q + StringOfChar('x', 65) + Q);

  // OPEN yoluyla da yol ayirici / '..' reddedilmeli (CREATE disinda da)
  ChkErr('OPEN ile yol ayirici (hata)', 'OPEN DATABASE ' + Q + 'a\b' + Q);
  ChkErr('OPEN ile .. (hata)', 'OPEN DATABASE ' + Q + '..' + Q);

  // DROP DATABASE etkini silemez (T01'de de var; burada satir seviyesinde)
  ChkErr('DROP DATABASE etkini silemez', 'DROP DATABASE baska');
end;

{ ============================================================ T80
  BACKUP TO 'dosya.odb' (sql.md bolum 4: "tutarli yedek al").
  sqltest.lpr'de BU STRING HIC GECMIYOR -> SQL yolu test edilmemis.
  API yolu (myKv.BackupTo) T75'te var; burada SQL komutu + icerik
  dogrulamasi (ayri oturumla yedek dosyasi acilir). }

procedure T80_BackupTo;
var
  yedek: string;
  myKv2: TVDb;
  myTb2: TVTableDb;
  mySq2: TVSql;
  r2: TSqlResult;
begin
  Grp('BACKUP TO (tutarli yedek alma - SQL yolu)');
  UseDir('bak');
  sq.Exec('CREATE TABLE t(id INTEGER PRIMARY KEY, a TEXT)');
  sq.Exec('INSERT INTO t(a) VALUES(' + Q + 'bir' + Q + ')');
  sq.Exec('INSERT INTO t(a) VALUES(' + Q + 'iki' + Q + ')');
  ChkVal('kaynakta 2 satir', 'SELECT COUNT(*) FROM t', 0, 0, '2');

  yedek := D + '\bak_yedek.odb';
  if FileExists(yedek) then DeleteFile(yedek);
  Chk('BACKUP TO calisti', 'BACKUP TO ' + Q + yedek + Q, -1);
  if FileExists(yedek) then Ok('yedek dosyasi olustu', yedek)
  else No('yedek dosyasi olustu', 'yok');

  // icerik dogrulama: yedek DOSYASI ayri bir oturumla acilir
  myKv2 := TVDb.Create;
  myTb2 := TVTableDb.Create(myKv2);
  mySq2 := TVSql.Create(myTb2);
  try
    myKv2.Open(yedek);
    myTb2.Open(yedek);
    r2 := mySq2.Exec('SELECT COUNT(*) FROM t');
    if (Length(r2.Rows) = 1) and (r2.Rows[0][0] = '2') then
      Ok('yedek icerigi dogru (2 satir)', '2')
    else if Length(r2.Rows) = 0 then
      No('yedek icerigi', 'tablo yok')
    else
      No('yedek icerigi', 'satir=' + IntToStr(Length(r2.Rows)) +
         ' deger=' + r2.Rows[0][0]);
    r2 := mySq2.Exec('SELECT a FROM t ORDER BY id');
    if (Length(r2.Rows) = 2) and (r2.Rows[0][0] = 'bir') and
       (r2.Rows[1][0] = 'iki') then
      Ok('yedek verileri dogru (bir, iki)', r2.Rows[0][0] + ',' + r2.Rows[1][0])
    else
      No('yedek verileri', 'eksik/karisik');
  finally
    mySq2.Free; myTb2.Free; myKv2.Free;
  end;

  // kaynak etkilenmedi
  ChkVal('kaynak hala 2 satir', 'SELECT COUNT(*) FROM t', 0, 0, '2');
end;

{ ============================================================ T81
  UPDATE ... SET aritmetigi (sql.md bolum 7).
  Kurallar: + - * / % yalniz sayisal kolonda; metin kolonda aritmetik
  HATA; INTEGER '/' TAM BOLME (7/2 -> 3); FLOAT '/' kayan nokta;
  /0 ve %0 HATA; NULL baslayan kolonda NULL+1 -> NULL.
  sqltest.lpr'de UPDATE aritmetigi HIC test edilmemis. }

procedure T81_UpdateAritmetik;
begin
  Grp('UPDATE ... SET aritmetigi (tam bolme, /0, %0, metin hata, NULL+1)');
  UseDir('uar');
  sq.Exec('CREATE TABLE ua(id INTEGER PRIMARY KEY, n INTEGER, t TEXT)');
  sq.Exec('INSERT INTO ua(id,n,t) VALUES(1, 7, ' + Q + 'a' + Q + ')');
  sq.Exec('INSERT INTO ua(id,n,t) VALUES(2, 10, ' + Q + 'b' + Q + ')');
  sq.Exec('INSERT INTO ua(id,n,t) VALUES(3, NULL, ' + Q + 'c' + Q + ')');

  // INTEGER tam bolme: 7 / 2 -> 3
  Chk('UPDATE tam bolme (n = n / 2)', 'UPDATE ua SET n = n / 2 WHERE id = 1', -1);
  ChkVal('tam bolme 7/2 = 3', 'SELECT n FROM ua WHERE id = 1', 0, 0, '3');

  // modulo pozitif: 10 % 3 -> 1
  Chk('UPDATE modulo (n = n % 3)', 'UPDATE ua SET n = n % 3 WHERE id = 2', -1);
  ChkVal('modulo 10%3 = 1', 'SELECT n FROM ua WHERE id = 2', 0, 0, '1');

  // carpma / toplama / cikarma (dogruluk)
  Chk('UPDATE carpma (n = n * 2)', 'UPDATE ua SET n = n * 2 WHERE id = 1', -1);
  ChkVal('carpma 3*2 = 6', 'SELECT n FROM ua WHERE id = 1', 0, 0, '6');
  Chk('UPDATE toplama (n = n + 1)', 'UPDATE ua SET n = n + 1 WHERE id = 1', -1);
  ChkVal('toplama 6+1 = 7', 'SELECT n FROM ua WHERE id = 1', 0, 0, '7');
  Chk('UPDATE cikarma (n = n - 4)', 'UPDATE ua SET n = n - 4 WHERE id = 1', -1);
  ChkVal('cikarma 7-4 = 3', 'SELECT n FROM ua WHERE id = 1', 0, 0, '3');

  // NULL + 1 -> NULL kalir
  Chk('UPDATE NULL + 1', 'UPDATE ua SET n = n + 1 WHERE id = 3', -1);
  ChkVal('NULL + 1 NULL kaldi', 'SELECT n FROM ua WHERE id = 3', 0, 0, '');

  // sifira bolme HATA (veri bozulmaz: id=2 hala 1)
  ChkErr('sifira bolme HATA', 'UPDATE ua SET n = n / 0 WHERE id = 2');
  ChkVal('bolme hatasi sonrasi veri saglam (1)', 'SELECT n FROM ua WHERE id = 2', 0, 0, '1');

  // sifira modulo HATA (veri bozulmaz)
  ChkErr('sifira modulo HATA', 'UPDATE ua SET n = n % 0 WHERE id = 2');
  ChkVal('modulo hatasi sonrasi veri saglam (1)', 'SELECT n FROM ua WHERE id = 2', 0, 0, '1');

  // metin kolonda aritmetik HATA (veri bozulmaz: id=1 t hala 'a')
  ChkErr('metin kolonda aritmetik HATA', 'UPDATE ua SET t = t + 1 WHERE id = 1');
  ChkVal('metin aritmetik hatasi sonrasi veri saglam', 'SELECT t FROM ua WHERE id = 1', 0, 0, 'a');

  // FLOAT bolme: kayan nokta (7.0 / 2 -> 3.5)
  sq.Exec('CREATE TABLE uf(id INTEGER PRIMARY KEY, f FLOAT)');
  sq.Exec('INSERT INTO uf(id,f) VALUES(1, 7.0)');
  Chk('UPDATE FLOAT bolme', 'UPDATE uf SET f = f / 2 WHERE id = 1', -1);
  ChkVal('FLOAT 7.0/2 = 3.5', 'SELECT f FROM uf WHERE id = 1', 0, 0, '3.5');
end;

{ ---------------------------------------------------------------------- main }

var
  arg: string;
  tmp: string;
begin
  nPass := 0; nFail := 0; nGrp := 0;
  sq := nil; tb := nil; kv := nil;
  if (ParamCount >= 1) and (Trim(ParamStr(1)) <> '') then
  begin
    D := ParamStr(1);
    ForceDirectories(D);
  end
  else
  begin
    tmp := GetTempDir(False) + 'vdbsqltest_eksik_' + FormatDateTime('yyyymmdd_hhnnss', Now);
    ForceDirectories(tmp);
    D := tmp;
  end;
  WriteLn('VDB SQL EKSIK TESTLER');
  WriteLn('Klasor: ', D);
  try
    try
      T79_VeritabaniYonetim;
      T80_BackupTo;
      T81_UpdateAritmetik;
    except
      on E: Exception do
      begin
        Inc(nFail);
        WriteLn;
        WriteLn('!! KESILDI (', grpName, '): ', E.ClassName, ': ', E.Message);
      end;
    end;
  finally
    Shutdown;
  end;
  WriteLn;
  WriteLn('================================================');
  WriteLn('SONUC: gecen=', nPass, '  kalan=', nFail);
  if nFail = 0 then WriteLn('TUM EKSIK TESTLER GECTI')
  else WriteLn('HATA VAR');
end.
