unit oTabloSchema;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, Variants, fpjson, jsonparser, oTypes;

type
  TTabloSchema = class
  private
    FAd: string;
    FAlanlar: array of TAlanTanimi;

    procedure SchemaTemizle;
    function IndexOfAlan(const AName: string): integer;
    function GetCommaText: string;
    function GetAlanAdlari: specialize TArray<string>;
  public
    constructor Create; overload;
    constructor Create(const AName: string);

    procedure AlanEkleDetayli(const A: TAlanTanimi);
    procedure AlanEkle(const Ad, TipStr: string);
    procedure AlanSil(const AlanAdi: string);
    procedure AlanAdiniDegistir(const EskiAd, YeniAd: string);
    procedure AlanTipiniDegistir(const AlanAdi, YeniTipStr: string);

    function AlanSayisi: integer;
    function Alan(const Ad: string): TAlanTanimi;
    function AlanIndex(const Ad: string): integer;
    function AlanByName(const AlanAdi: string): TAlanTanimi;
    function AlanTipi(const AName: string): TAlanTuru;
    function AlanPrimaryKeyMi(const AName: string): boolean;
    function AlanAutoIncMi(const AName: string): boolean;
    function AlanDefaultDeger(const AName: string): variant;
    function VarMiAlan(const AlanAdi: string): boolean;
    function ToplamKayitBoyutu: integer;

    function ToJSON: TJSONArray;
    procedure FromJSON(A: TJSONArray);

    property Ad: string read FAd write FAd;
    property CommaText: string read GetCommaText;
    property AlanAdlari: specialize TArray<string> read GetAlanAdlari;

  end;

implementation

uses oDebug;

  { TTabloSchema }

constructor TTabloSchema.Create;
begin
  inherited Create;
  FAd := '';
  SetLength(FAlanlar, 0);
end;

constructor TTabloSchema.Create(const AName: string);
begin
  Create;
  FAd := AName;
end;

function TTabloSchema.GetAlanAdlari: specialize TArray<string>;
var
  i: integer;
begin
  SetLength(Result, Length(FAlanlar));
  for i := 0 to High(FAlanlar) do
    Result[i] := FAlanlar[i].Name;
end;

function TTabloSchema.GetCommaText: string;
begin
  Result := string.Join(',', GetAlanAdlari);
end;

function TTabloSchema.IndexOfAlan(const AName: string): integer;
var
  i: integer;
begin
  for i := 0 to High(FAlanlar) do
    if SameText(FAlanlar[i].Name, AName) then
      Exit(i);
  Result := -1;
end;

function TTabloSchema.VarMiAlan(const AlanAdi: string): boolean;
begin
  Result := IndexOfAlan(AlanAdi) <> -1;
end;

function TTabloSchema.AlanTipi(const AName: string): TAlanTuru;
var
  idx: integer;
begin
  idx := IndexOfAlan(AName);
  if idx >= 0 then
    Result := FAlanlar[idx].Tip
  else
    Result := ftUnknown;
end;

function TTabloSchema.AlanDefaultDeger(const AName: string): variant;
var
  idx: integer;
begin
  idx := IndexOfAlan(AName);
  if idx >= 0 then
    Result := FAlanlar[idx].DefaultDeger
  else
    Result := Null;
end;

function TTabloSchema.AlanPrimaryKeyMi(const AName: string): boolean;
var
  idx: integer;
begin
  idx := IndexOfAlan(AName);
  Result := (idx >= 0) and FAlanlar[idx].PrimaryKey;
end;

function TTabloSchema.AlanAutoIncMi(const AName: string): boolean;
var
  idx: integer;
begin
  idx := IndexOfAlan(AName);
  Result := (idx >= 0) and FAlanlar[idx].AutoIncrement;
end;

function TTabloSchema.AlanIndex(const Ad: string): integer;
begin
  Result := IndexOfAlan(Ad);
end;

function TTabloSchema.Alan(const Ad: string): TAlanTanimi;
var
  idx: integer;
begin
  idx := IndexOfAlan(Ad);
  if idx < 0 then
    raise Exception.Create('Alan bulunamadı: ' + Ad);
  Result := FAlanlar[idx];
end;

function TTabloSchema.AlanByName(const AlanAdi: string): TAlanTanimi;
begin
  Result := Alan(AlanAdi);
end;
 {
procedure TTabloSchema.AlanEkle(const Ad, TipStr: string);
var
  a: TAlanTanimi;
begin
  a.Name := Ad;
  a.Tip := StrToAlanTuru(TipStr);
  a.Length := AlanVarsayilanUzunluk(a.Tip);
  FAlanlar := FAlanlar + [a];  // Dinamik diziye ekleme
end;  }

procedure TTabloSchema.AlanEkle(const Ad, TipStr: string);
var
  a: TAlanTanimi;
  len: integer;
begin
  a.Name := Ad;
  a.Tip := StrToAlanTuru(TipStr);
  a.Length := AlanVarsayilanUzunluk(a.Tip);

  len := Length(FAlanlar);
  SetLength(FAlanlar, len + 1);
  FAlanlar[len] := a;
end;



procedure TTabloSchema.AlanEkleDetayli(const A: TAlanTanimi);
begin
  SetLength(FAlanlar, Length(FAlanlar) + 1);
  FAlanlar[High(FAlanlar)] := A;
end;

procedure TTabloSchema.AlanSil(const AlanAdi: string);
var
  i: integer;
begin
  for i := 0 to High(FAlanlar) do
    if SameText(FAlanlar[i].Name, AlanAdi) then
    begin
      Delete(FAlanlar, i, 1);
      Exit;
    end;
end;

procedure TTabloSchema.AlanAdiniDegistir(const EskiAd, YeniAd: string);
var
  idx: integer;
begin
  idx := IndexOfAlan(EskiAd);
  if idx >= 0 then
    FAlanlar[idx].Name := YeniAd;
end;

procedure TTabloSchema.AlanTipiniDegistir(const AlanAdi, YeniTipStr: string);
var
  idx: integer;
  YeniTip: TAlanTuru;
begin
  idx := IndexOfAlan(AlanAdi);
  if idx < 0 then Exit;

  YeniTip := StrToAlanTuru(YeniTipStr);
  FAlanlar[idx].Tip := YeniTip;

  case YeniTip of
    ftText: FAlanlar[idx].Length := 255;
    ftInteger: FAlanlar[idx].Length := 4;
    ftFloat: FAlanlar[idx].Length := 8;
  end;
end;

function TTabloSchema.AlanSayisi: integer;
begin
  Result := Length(FAlanlar);
end;

function TTabloSchema.ToplamKayitBoyutu: integer;
var
  i: integer;
begin
  Result := 0;
  for i := 0 to High(FAlanlar) do
    Inc(Result, AlanBoyutu(FAlanlar[i]));
end;

procedure TTabloSchema.SchemaTemizle;
var
  i: integer;
begin
  for i := 0 to High(FAlanlar) do
  begin
    if (FAlanlar[i].AutoIncrement) and (FAlanlar[i].Tip <> ftInteger) then
      FAlanlar[i].AutoIncrement := False;

    if FAlanlar[i].Length > 1000 then
      FAlanlar[i].Length := 255;

    if VarIsEmpty(FAlanlar[i].DefaultDeger) or VarIsNull(FAlanlar[i].DefaultDeger) or
      (Trim(VarToStr(FAlanlar[i].DefaultDeger)) = '') then
      FAlanlar[i].DefaultDeger := Unassigned;
  end;
end;

function TTabloSchema.ToJSON: TJSONArray;
var
  jArr: TJSONArray;
  obj: TJSONObject;
  A: TAlanTanimi;
  i: integer;
begin
  jArr := TJSONArray.Create;
  for i := 0 to High(FAlanlar) do
  begin
    A := FAlanlar[i];
    obj := TJSONObject.Create;

    obj.Add('name', A.Name);
    obj.Add('type', AlanTuruToStr(A.Tip));
    obj.Add('length', A.Length);

    if A.PrimaryKey then obj.Add('primaryKey', True);
    if A.AutoIncrement then obj.Add('autoIncrement', True);
    if A.NotNull then obj.Add('notNull', True);
    if A.Unique then obj.Add('unique', True);
    if A.Index then obj.Add('index', True);

    if not VarIsEmpty(A.DefaultDeger) and not VarIsNull(A.DefaultDeger) and
      (Trim(VarToStr(A.DefaultDeger)) <> '') then
      obj.Add('default', VarToStr(A.DefaultDeger));

    obj.Add('foreignKey', A.ForeignKey);
    obj.Add('check', A.CheckIfade);
    obj.Add('comment', A.Comment);

    jArr.Add(obj);
  end;

  Result := jArr;
end;

procedure TTabloSchema.FromJSON(A: TJSONArray);
var
  i: integer;
  obj: TJSONObject;
  alanTanimi: TAlanTanimi;
begin
  SetLength(FAlanlar, A.Count);
  for i := 0 to A.Count - 1 do
  begin
    obj := A.Objects[i];

    alanTanimi.Name := obj.Get('name', '');
    alanTanimi.Tip := StrToAlanTuru(obj.Get('type', 'Text'));
    alanTanimi.Length := obj.Get('length', 255);
    alanTanimi.PrimaryKey := obj.Get('primaryKey', False);
    alanTanimi.AutoIncrement := obj.Get('autoIncrement', False);
    alanTanimi.NotNull := obj.Get('notNull', False);
    alanTanimi.Unique := obj.Get('unique', False);
    alanTanimi.Index := obj.Get('index', False);

    if obj.Find('default') <> nil then
      alanTanimi.DefaultDeger := ParseDegerTipli(alanTanimi.Tip, obj.Get('default', ''))
    else
      alanTanimi.DefaultDeger := Unassigned;

    alanTanimi.ForeignKey := obj.Get('foreignKey', '');
    alanTanimi.CheckIfade := obj.Get('check', '');
    alanTanimi.Comment := obj.Get('comment', '');

    FAlanlar[i] := alanTanimi;
  end;
end;

end.
