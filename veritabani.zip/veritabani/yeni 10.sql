CREATE TABLE AYARLAR (
    ID              AUTOINCREMENT,
    NUMARALI          TEXT,
    TARIFEOROMANUEL   TEXT,
    TARIFEYAZKIS      TEXT,
    TIMETABLE_ID      TEXT,
    TIMETABLEYAZH_ID  TEXT,
    TIMETABLEYAZC_ID  TEXT,
    TIMETABLEYAZP_ID  TEXT,
    TIMETABLEKISH_ID  TEXT,
    TIMETABLEKISC_ID  TEXT,
    TIMETABLEKISP_ID  TEXT,
    FLASHYAPSIN       TEXT,
    YAZIKAYSIN        TEXT,
    SABAHNUMARALARI   TEXT,
    AKSAMNUMARALARI   TEXT,
    GRUP1             TEXT,
    GRUP2             TEXT,
    GRUP3             TEXT,
    TOPLAMTURSURESI   TEXT,
    AKSAMBASLAMASAATI INTEGER,
    HAT_ID            TEXT,
    BASMAKINIST1      TEXT,
    BASMAKINIST2      TEXT,
    BASMAKINIST3      TEXT,
    SEFLIK            TEXT,
    VERSIYON          TEXT,
    EKRANRESMI        BLOB,
    TIMETABLEPZT_ID   TEXT,
    TIMETABLESAL_ID   TEXT,
    TIMETABLECAR_ID   TEXT,
    TIMETABLEPER_ID   TEXT,
    TIMETABLECUM_ID   TEXT,
    TIMETABLECMT_ID   TEXT,
    TIMETABLEPZR_ID   TEXT,
    YON               TEXT  
);


CREATE TABLE CIZELGE (
    ID      AUTOINCREMENT,
    CIZID    TEXT,
    SIRANO   TEXT,
    SICIL    TEXT,
    ADI      TEXT,
    GOREVI   TEXT,
    G1       TEXT,
    G2       TEXT,
    G3       TEXT,
    G4       TEXT,
    G5       TEXT,
    G6       TEXT,
    G7       TEXT,
    G8       TEXT,
    G9       TEXT,
    G10      TEXT,
    G11      TEXT,
    G12      TEXT,
    G13      TEXT,
    G14      TEXT,
    G15      TEXT,
    G16      TEXT,
    G17      TEXT,
    G18      TEXT,
    G19      TEXT,
    G20      TEXT,
    G21      TEXT,
    G22      TEXT,
    G23      TEXT,
    G24      TEXT,
    G25      TEXT,
    G26      TEXT,
    G27      TEXT,
    G28      TEXT,
    G29      TEXT,
    G30      TEXT,
    G31      TEXT,
    SILINMIS INTEGER
);

CREATE TABLE ARACGRSLISTESI (
    ID       AUTOINCREMENT,
    SAAT     TEXT,
    TTID     TEXT,
    HANGIYON TEXT,
    GIRISMI  TEXT,
    SILINMIS INTEGER
);

CREATE TABLE HATLISTESI (
    ID       AUTOINCREMENT,
    HATADI   TEXT,
    SILINMIS INTEGER
);
CREATE TABLE MAKINISTEMESAJ (
    ID       AUTOINCREMENT,
    MESAJ    TEXT,
    SILINMIS INTEGER
);
CREATE TABLE MAKINISTRESIM (
    ID       AUTOINCREMENT,
    SICILID  TEXT,
    RESIM    BLOB,
    SILINMIS INTEGER
);

CREATE TABLE MANEVRA (
    ID             AUTOINCREMENT,
    GOREVNO        TEXT,
    TTID           TEXT,
    BASLANGICSAATI INTEGER,
    BITISSAATI     INTEGER,
    SILINMIS       INTEGER
);

CREATE TABLE TIMETABLE (
    ID         AUTOINCREMENT,
    TTID       TEXT,
    NUMARA     TEXT,
    SAAT       TEXT,
    RUN        TEXT,
    DIZI       TEXT,
    HATID      TEXT,
    ARACCIKAR  INTEGER,
    ARACCIKAR1 INTEGER,
    ARACGIRER  INTEGER,
    ARACGIRER1 INTEGER,
    SILINMIS   INTEGER
);



CREATE TABLE TIMETABLECEK (
    ID       AUTOINCREMENT,
    TTID     INTEGER,
    NUMARA   TEXT,
    SAAT     TEXT,
    RUN      TEXT,
    DIZI     TEXT,
    HATID    TEXT,
    SILINMIS INTEGER
);

CREATE TABLE TTDETAY (
    ID           AUTOINCREMENT,
    ADI          TEXT,
    HAFTAICISONU TEXT,
    YAZKIS       TEXT,
    SILINMIS     INTEGER
);




