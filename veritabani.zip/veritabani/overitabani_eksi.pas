unit oVeritabani;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, Generics.Collections, otypes, oTabloSchema, oTabloKayit,
  oTablo, fpjson, jsonparser, zstream,dialogs;

type
  TTabloKapsul = class
    UID          : string;
    Ad           : string;
    Tablo        : TVTablo;
    Version      : string;
    Dependencies : TStringList;
    SonID        : string;
    constructor Create;
    destructor Destroy; override;
  end;

  type
  // Bir satırı field→value sözlüğü olarak tutarız
  TRow = specialize TDictionary<string, Variant>;
  TRowList = specialize TList<TRow>;
  TTabloListesi = specialize TObjectList<TTabloKapsul>;

  TVeritabani = class
  private
    FAd: string;
    FTablolar: TTabloListesi;
    FDataDict  : specialize TDictionary<string, TRowList>;
    FSchemaDict: specialize TDictionary<string, TTabloSchema>;
    function GenerateUID: string;
    function GetTablo(Index: Integer): TVTablo;
    function GetTabloByName(const Aname:string):TVTablo;
    function GetKapsul(Index: Integer): TTabloKapsul;
  public
    constructor Create;
    destructor Destroy; override;
    procedure CreateDatabase(const AName: string);

    procedure RegisterTableSchema(const TableName: string; Schema: TTabloSchema);
    // SELECT sırasında çekmek için:
    function GetTableSchema(const TableName: string): TTabloSchema;

    procedure InsertInto(const TableName: string; const Columns: specialize TArray<string>;  const Values: specialize TArray<string>
    );

    /// SELECT columns FROM TableName WHERE … ORDER BY …
    function SelectFrom( const TableName: string; const Columns: specialize TArray<string>;  const Conditions: specialize TArray<TCondition>;
      const OrderBy: string):specialize TList< specialize TDictionary<string,Variant>>;


    procedure TabloEkle(const Ad: string; Tablo: TVTablo; Dependencies: array of string; const Version: string = '1.0');
    procedure TabloSil(const TabloAdi: string);

    function TabloSayisi: Integer;

    procedure SaveToFile(const FileName: string);
    procedure LoadFromFile(const FileName: string);

    property Ad: string read FAd write FAd;
    property Tablolar[Index: Integer]: TVTablo read GetTablo;
    property TabloByName[const name: string]: TVTablo read GetTabloByName;
    property Kapsuller[Index: Integer]: TTabloKapsul read GetKapsul;
  end;

implementation

uses
  DateUtils,odebug;

function CalcCRC32(const Buffer; Len: Cardinal): Cardinal;
const
  Polynomial = $EDB88320;
var
  i, j: Integer;
  CRC: Cardinal;
  Table: array[0..255] of Cardinal;
  P: PByte;
begin
  for i := 0 to 255 do
  begin
    CRC := i;
    for j := 0 to 7 do
      if (CRC and 1) <> 0 then
        CRC := (CRC shr 1) xor Polynomial
      else
        CRC := CRC shr 1;
    Table[i] := CRC;
  end;

  CRC := $FFFFFFFF;
  P := @Buffer;
  for i := 0 to Len - 1 do
    CRC := (CRC shr 8) xor Table[(CRC xor P^) and $FF];
  Result := CRC xor $FFFFFFFF;
end;

constructor TTabloKapsul.Create;
begin
  inherited Create;
  Dependencies := TStringList.Create;
end;

destructor TTabloKapsul.Destroy;
begin
  Dependencies.Free;
  inherited Destroy;
end;




constructor TVeritabani.Create;
begin
  inherited Create;
  FTablolar := TTabloListesi.Create(True);
  FSchemaDict := specialize TDictionary<string, TTabloSchema>.Create;
end;

destructor TVeritabani.Destroy;
var
  Schema: TTabloSchema;
begin
  FTablolar.Free;
  for Schema in FSchemaDict.Values do
  Schema.Free;

  FSchemaDict.Free;
  inherited Destroy;
end;

procedure TVeritabani.CreateDatabase(const AName:string);
begin

  // 1) Veritabanı adını güncelle
  FAd := AName;
  // 2) Mevcut tabloları temizle
  FTablolar.Clear; // TObjectList otomatik olarak içindekileri de Free eder
  // 3) (İsterseniz) SonID gibi sayaçları sıfırlayın:
  // SonID := '';
  FSchemaDict.Clear;
end;

function TVeritabani.GenerateUID: string;
var
  G: TGUID;
begin
  CreateGUID(G);
  Result := GUIDToString(G);
end;


procedure TVeritabani.RegisterTableSchema(
  const TableName: string; Schema: TTabloSchema);
begin
  // Üst üste kaydetmeyi engellemek için önce sil:
  FSchemaDict.Remove(UpperCase(TableName));
  FSchemaDict.Add(UpperCase(TableName), Schema);
end;

function TVeritabani.GetTableSchema(
  const TableName: string): TTabloSchema;
begin
  if not FSchemaDict.TryGetValue(UpperCase(TableName), Result) then
    raise Exception.CreateFmt('Şema bulunamadı: %s', [TableName]);
end;

procedure TVeritabani.InsertInto(const TableName:string;const Columns:
  specialize TArray<string>;const Values:specialize TArray<string>);
var
  schema  : TTabloSchema;
  row     : specialize TDictionary<string,Variant>;
  i       : Integer;
  v       : Variant;
begin
  schema := GetTableSchema(TableName);
  // Bu örnekte veri depolamanız için bir FDataDict[TableName] olduğunu varsayıyoruz.
  // Eğer farklı bir koleksiyon kullanıyorsanız, onu Replace edin.
  row := specialize TDictionary<string,Variant>.Create;
  for i := 0 to High(Columns) do
  begin
    // ParseDegerTipli: oTypes.pas içindeki helper
    v := ParseDegerTipli(
      schema.AlanTipi(Columns[i]),
      Values[i]
    );
    row.Add(Columns[i], v);
  end;
  // FDataDict: TableName→List<row> eşlemesi
  FDataDict[UpperCase(TableName)].Add(row);
end;


function TVeritabani.SelectFrom(const TableName:string;const Columns:specialize
  TArray<string>;const Conditions:specialize TArray<TCondition>;const OrderBy:
  string):specialize TList<specialize TDictionary<string,Variant>>;
var
  allRows, filtered, sorted: specialize TList<specialize TDictionary<string,Variant>>;
  cond: TCondition;
  rec: specialize TDictionary<string,Variant>;
  ok: Boolean;
  i, j: Integer;
begin
  // 1) Tüm satırları al
  allRows := FDataDict[UpperCase(TableName)];
  filtered :=specialize TList< specialize TDictionary<string,Variant>>.Create;
  // 2) Koşullara göre filtrele
  for rec in allRows do
  begin
    ok := True;
    for cond in Conditions do
    begin
      // Çok basit = ve >,< mantığı; geliştirilebilir
      if cond.Op = '=' then
        ok := rec[cond.Column] = cond.Value
      else if cond.Op = '>' then
        ok := rec[cond.Column] > cond.Value
      else if cond.Op = '<' then
        ok := rec[cond.Column] < cond.Value;
      if not ok then Break;
    end;
    if ok then
      filtered.Add(rec);
  end;

  // 3) ORDER BY
  if OrderBy <> '' then
  begin
    // Basit tek sutun sıralama (ASC assumed)
    filtered.Sort(
      function(const A, B: TDictionary<string,Variant>): Integer
      begin
        if A[OrderBy] < B[OrderBy] then Result := -1
        else if A[OrderBy] > B[OrderBy] then Result := 1
        else Result := 0;
      end
    );
  end;

  // 4) Sonuçta yalnızca istenen kolonları içeren yeni liste üret
  Result := TList<TDictionary<string,Variant>>.Create;
  for rec in filtered do
  begin
    var proj := TDictionary<string,Variant>.Create;
    for i := 0 to High(Columns) do
      proj.Add(Columns[i], rec[Columns[i]]);
    Result.Add(proj);
  end;

  // arada kullanılan listeyi serbest bırakıyoruz (satır nesneleri proj ve allRows tarafından korunur)
  filtered.Free;
end;



procedure TVeritabani.TabloEkle(const Ad:string;Tablo:TVTablo;Dependencies:
  array of string;const Version:string);
var
  K: TTabloKapsul;
  i:Integer;
begin
  K := TTabloKapsul.Create;
  K.UID := GenerateUID;
  K.Ad := Ad;
  K.Tablo := Tablo;
  K.Version := Version;
  for i := 0 to High(Dependencies) do
    K.Dependencies.Add(Dependencies[i]);

  FTablolar.Add(K);
end;


procedure TVeritabani.TabloSil(const TabloAdi: string);
var
  i: Integer;
begin
  for i := FTablolar.Count - 1 downto 0 do
  begin
    if SameText(Tablolar[i].Ad, TabloAdi) then
    begin
      Tablolar[i].Free;
      FTablolar.Delete(i);
      Break;
    end;
  end;
end;

function TVeritabani.TabloSayisi: Integer;
begin
  Result := FTablolar.Count;
end;

function TVeritabani.GetTablo(Index: Integer): TVTablo;
begin
  Result := FTablolar[Index].Tablo;
end;

function TVeritabani.GetTabloByName(const Aname: string): TVTablo;
var
  i: Integer;
begin
//  for i := 0 to FTablolar.Count - 1 do
  for i:=0 to TabloSayisi-1 do
    if SameText(FTablolar[i].Ad, Aname) then
      Exit(FTablolar[i].Tablo);

  raise Exception.Create('Tablo bulunamadı: ' + Aname);
end;

function TVeritabani.GetKapsul(Index: Integer): TTabloKapsul;
begin
  Result := FTablolar[Index];
end;

function StringListToJSONArray(List: TStrings): TJSONArray;
var
  i: Integer;
begin
  Result := TJSONArray.Create;
  for i := 0 to List.Count - 1 do
    Result.Add(List[i]);
end;
procedure TVeritabani.SaveToFile(const FileName: string);
var
  Header: TJSONObject;
  Listi: TJSONArray;
  TObj: TJSONObject;
  FS, CompStream: TMemoryStream;
  ZOut: TCompressionStream;
  SchemaStr: string;
  SchemaBytes: TBytes;
  i: Integer;
  crc: Cardinal;
begin
  FS := TMemoryStream.Create;
  CompStream := TMemoryStream.Create;
  try
    // Header JSON hazırlığı
    Listi := TJSONArray.Create;
    Header := TJSONObject.Create;
    try
      Header.Add('tables', Listi);
      Header.Add('datetime', FormatDateTime('dd.mm.yyyy hh:nn:ss', Now));

      for i := 0 to FTablolar.Count - 1 do
      begin
        TObj := TJSONObject.Create;
        TObj.Add('uid', FTablolar[i].UID);
        TObj.Add('name', FTablolar[i].Ad);
        TObj.Add('version', FTablolar[i].Version);
        TObj.Add('LastID', FTablolar[i].Tablo.SonID);
        TObj.Add('dependencies', StringListToJSONArray(FTablolar[i].Dependencies));
        TObj.Add('schema', FTablolar[i].Tablo.Schema.ToJSON);//FTablolar[i].Tablo.TabloyuJsonSemaOlarakAl);
        Listi.Add(TObj);

        DebugLog('📦 Kayıtlanacak Tablo: ' + FTablolar[i].Tablo.Ad);

         DebugLog('🧠 JSON Şema → ' + FTablolar[i].Tablo.Schema.ToJSON.AsJSON);

         // Optional: Satır sayısı kontrolü
         DebugLog('📊 Kayıt Sayısı: ' + IntToStr(FTablolar[i].Tablo.KayitSayisi));

      end;

      // JSON → byte[]
      SchemaStr := Header.AsJSON;
      SchemaBytes := TEncoding.UTF8.GetBytes(SchemaStr);
      FS.WriteQWord(Length(SchemaBytes));
      FS.WriteBuffer(SchemaBytes[0], Length(SchemaBytes));
    finally
      Header.Free;
    end;

    DebugLog('--- Veritabanı Kaydı Başlatılıyor ---');
    DebugLog('Tablo sayısı: ' + IntToStr(FTablolar.Count));

    // Tabloların sıkıştırılmış içeriği yaz
    for i := 0 to FTablolar.Count - 1 do
    begin
      CompStream.Clear;
      ZOut := TCompressionStream.Create(clDefault, CompStream);
      try

        //DebugLog('Tablo: ' + FTablolar[i].Ad + ' | Kayıt sayısı: ' + IntToStr(FTablolar[i].Tablo.KayitSayisi));
        FTablolar[i].Tablo.SaveToStream(ZOut);

        ZOut.Flush;
      finally
        ZOut.Free;
      end;

      FS.WriteQWord(CompStream.Size);
      FS.WriteBuffer(CompStream.Memory^, CompStream.Size);

      crc := CalcCRC32(CompStream.Memory^, CompStream.Size);
      FS.WriteDWord(crc);
    end;

    FS.SaveToFile(FileName);

  finally
    FS.Free;
    CompStream.Free;
  end;
end;

procedure TVeritabani.LoadFromFile(const FileName: string);
var
  FS: TFileStream;
  HeadSize, DataSize,sonid: QWord;
  HeaderBuf: TBytes;
  HeaderStr, SchemaStr, UID, TabloAdi, Version: string;
  HeaderJSON: TJSONObject;
  Listi: TJSONArray;
  i: Integer;
  Decomp: TDecompressionStream;
  TempMem: TMemoryStream;
  DataBuf: TBytes;
  crcFromFile, crcCalc: Cardinal;
  Tablo: TVTablo;
  depsArr: TJSONArray;
  depsList: TStringList;
  SchemaJSON: TJSONArray;
  FSchema : TTabloSchema;
begin
  FS := TFileStream.Create(FileName, fmOpenRead or fmShareDenyNone);
  try
    FTablolar.Clear;

    HeadSize:= FS.ReadQWord();
    SetLength(HeaderBuf, HeadSize);
    FS.ReadBuffer(HeaderBuf[0], HeadSize);
    HeaderStr := TEncoding.UTF8.GetString(HeaderBuf);
    HeaderJSON := TJSONObject(GetJSON(HeaderStr));
    ad :=ExtractFileName(FileName);
    try
      Listi := HeaderJSON.Arrays['tables'];
      for i := 0 to Listi.Count - 1 do
      begin
        TabloAdi := Listi.Objects[i].Get('name', '');
        UID := Listi.Objects[i].Get('uid', '');
        Version := Listi.Objects[i].Get('version', '1.0');
        SchemaStr := Listi.Objects[i].Get('schema', '[]');
        depsArr := Listi.Objects[i].Arrays['dependencies'];
        Sonid   :=Listi.Objects[i].Get('LastID',0);


        depsList := TStringList.Create;
        try
          depsList.Delimiter := ',';
          depsList.QuoteChar := '"';
          depsList.DelimitedText := depsArr.AsJSON;

          DataSize:=FS.ReadQWord();
          SetLength(DataBuf, DataSize);
          FS.ReadBuffer(DataBuf[0], DataSize);
          crcFromFile:=FS.ReadDWord();

          crcCalc := CalcCRC32(DataBuf[0], DataSize);
          if crcCalc <> crcFromFile then
            raise Exception.CreateFmt('CRC uyuşmazlığı! Tablo: %s', [TabloAdi]);

          Tablo := TVTablo.Create(TabloAdi);
          FSchema := TTabloSchema.Create(TabloAdi);
          FSchema.FromJSON(Listi.Objects[i].Arrays['schema']);
          Tablo.Schema:=FSchema;
          Tablo.SonID:=sonid;


          TempMem := TMemoryStream.Create;
          try
            TempMem.WriteBuffer(DataBuf[0], DataSize);
            TempMem.Position := 0;
            Decomp := TDecompressionStream.Create(TempMem);
            try
              Tablo.LoadFromStream(Decomp);
            finally
              Decomp.Free;
            end;
          finally
            TempMem.Free;
          end;

          TabloEkle(TabloAdi, Tablo, depsList.ToStringArray, Version);
          FTablolar[FTablolar.Count - 1].UID := UID;
        finally
          depsList.Free;
        end;
      end;
    finally
      HeaderJSON.Free;
    end;
  finally
    FS.Free;
  end;
end;

end.
