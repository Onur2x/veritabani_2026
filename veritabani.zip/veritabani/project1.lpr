program project1;

{$mode objfpc}{$H+}

uses
  fMain,
  fDataExplorer,
  fExportCenter,
  fJoinBuilder,
  fQueryBuilder,
  fRowEditor,
  fSchemaEditor,
  fTableWizard,
  Interfaces, // this includes the LCL widgetset
  Forms;

  {$R *.res}

begin
  RequireDerivedFormResource := True;
  Application.Scaled:=True;
  Application.{%H-}MainFormOnTaskbar := True;
  Application.Initialize;
  Application.CreateForm(TFormMain, FormMain);
  Application.CreateForm(TFormJoinBuilder, FormJoinBuilder);
  Application.CreateForm(TFormRowEditor, FormRowEditor);
  Application.CreateForm(TFormDataExplorer, FormDataExplorer);
  Application.CreateForm(TFormSchemaEditor, FormSchemaEditor);
  Application.CreateForm(TFormTableWizard, FormTableWizard);
  Application.CreateForm(TFormExportCenter, FormExportCenter);
  Application.CreateForm(TFormQueryBuilder, FormQueryBuilder);
  Application.Run;
end.
