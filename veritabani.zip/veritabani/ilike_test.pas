program ilike_test;

{$mode delphi}

uses
  SysUtils, Classes, VDbCore, VDbTable, VDbSql, VDbParser, VDbExecutor, VDbAst, VDbErr;

var
  Kv: TVDb;
  Tb: TVTableDb;
  Sq: TVSql;
  Res: TSqlResult;
  Dir: string;
begin
  Dir := 'D:/veritabani/test_ilike_db';
  if DirectoryExists(Dir) then
  begin
    DeleteFile(Dir + '\veritabani.odb');
    DeleteFile(Dir + '\schema.dat');
    RemoveDir(Dir);
  end;
  ForceDirectories(Dir);

  Kv := TVDb.Create;
  Tb := TVTableDb.Create(Kv);
  Sq := TVSql.Create(Tb);
  try
    Kv.Open(Dir);
    Tb.Open(Dir);

    // Tablo oluştur
    Res := Sq.Exec('CREATE TABLE users(id INTEGER PRIMARY KEY, name TEXT, city TEXT)');
    WriteLn('CREATE TABLE: ', Res.Msg);

    // Veri ekle
    Sq.Exec("INSERT INTO users(name, city) VALUES('Ali', 'İstanbul')");
    Sq.Exec("INSERT INTO users(name, city) VALUES('ali', 'Ankara')");
    Sq.Exec("INSERT INTO users(name, city) VALUES('ALİ', 'İzmir')");
    Sq.Exec("INSERT INTO users(name, city) VALUES('Veli', 'Bursa')");
    Sq.Exec("INSERT INTO users(name, city) VALUES('Ayşe', 'Adana')");

    // Test 1: LIKE (case-sensitive)
    Res := Sq.Exec("SELECT name, city FROM users WHERE name LIKE 'ali%'");
    WriteLn('Test 1 - LIKE ''ali%'' (case-sensitive):');
    for var r in Res.Rows do WriteLn('  ', r[0], ' - ', r[1]);
    WriteLn('  Count: ', Length(Res.Rows));

    // Test 2: ILIKE (case-insensitive)
    Res := Sq.Exec("SELECT name, city FROM users WHERE name ILIKE 'ali%'");
    WriteLn('Test 2 - ILIKE ''ali%'' (case-insensitive):');
    for var r in Res.Rows do WriteLn('  ', r[0], ' - ', r[1]);
    WriteLn('  Count: ', Length(Res.Rows));

    // Test 3: ILIKE with Turkish characters
    Res := Sq.Exec("SELECT name, city FROM users WHERE city ILIKE 'istanbul'");
    WriteLn('Test 3 - ILIKE ''istanbul'' (Turkish İ/i):');
    for var r in Res.Rows do WriteLn('  ', r[0], ' - ', r[1]);
    WriteLn('  Count: ', Length(Res.Rows));

    // Test 4: NOT ILIKE
    Res := Sq.Exec("SELECT name, city FROM users WHERE name NOT ILIKE 'ali%'");
    WriteLn('Test 4 - NOT ILIKE ''ali%'':');
    for var r in Res.Rows do WriteLn('  ', r[0], ' - ', r[1]);
    WriteLn('  Count: ', Length(Res.Rows));

    // Test 5: ILIKE with wildcard
    Res := Sq.Exec("SELECT name FROM users WHERE name ILIKE '%li%'");
    WriteLn('Test 5 - ILIKE ''%li%'':');
    for var r in Res.Rows do WriteLn('  ', r[0]);
    WriteLn('  Count: ', Length(Res.Rows));

    WriteLn('Tüm testler başarılı!');

  except
    on E: Exception do
      WriteLn('HATA: ', E.Message);
  end;

  Sq.Free;
  Tb.Free;
  Kv.Free;
  
  // Temizlik
  DeleteFile(Dir + '\veritabani.odb');
  DeleteFile(Dir + '\schema.dat');
  RemoveDir(Dir);
end.