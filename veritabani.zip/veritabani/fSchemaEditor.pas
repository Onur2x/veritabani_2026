unit fSchemaEditor;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, StdCtrls, Grids, oTabloSchema, oTypes, oVeritabani;

type
  TFormSchemaEditor = class(TForm)
    GridSchema: TStringGrid;
    ButtonSave: TButton;
    ButtonCancel: TButton;
    procedure ButtonSaveClick(Sender: TObject);
    procedure ButtonCancelClick(Sender: TObject);
  private
    FSchema: TTabloSchema;
    FVeri: TVeritabani;
    FAktifDB: string;
  public
    procedure LoadSchema(S: TTabloSchema);
    function GetEditedSchema: TTabloSchema;
    procedure Initialize(Veritabani: TVeritabani; const DBName: string);
  end;

var
  FormSchemaEditor: TFormSchemaEditor;

implementation

{$R *.lfm}

procedure TFormSchemaEditor.Initialize(Veritabani: TVeritabani; const DBName: string);
begin
  FVeri := Veritabani;
  FAktifDB := DBName;

end;

procedure TFormSchemaEditor.LoadSchema(S: TTabloSchema);
var
  i: integer;
begin
  FSchema := S;
  GridSchema.RowCount := Length(S.AlanAdlari) + 1;
  GridSchema.ColCount := 2;
  GridSchema.Cells[0, 0] := 'Alan Adı';
  GridSchema.Cells[1, 0] := 'Alan Tipi';

  for i := 0 to High(S.AlanAdlari) do
  begin
    GridSchema.Cells[0, i + 1] := S.AlanAdlari[i];
    GridSchema.Cells[1, i + 1] := AlanTuruToStr(S.AlanTipi(S.AlanAdlari[i]));
  end;
end;

function TFormSchemaEditor.GetEditedSchema: TTabloSchema;
var
  i: integer;
  ad, tip: string;
begin
  Result := TTabloSchema.Create;
  for i := 1 to GridSchema.RowCount - 1 do
  begin
    ad := GridSchema.Cells[0, i];
    tip := GridSchema.Cells[1, i];
    if ad <> '' then
      Result.AlanEkle(ad, tip);
  end;
end;

procedure TFormSchemaEditor.ButtonSaveClick(Sender: TObject);
begin
  ModalResult := mrOk;
end;

procedure TFormSchemaEditor.ButtonCancelClick(Sender: TObject);
begin
  ModalResult := mrCancel;
end;

end.
