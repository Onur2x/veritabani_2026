# vdbapi.dll â€” Kendi ProgramÄ±nÄ±zda KullanÄ±m

## Ne Ä°ÅŸe Yarar

Bu veritabanÄ± motoru Pascal/FPC ile yazÄ±ldÄ±. **Delphi derleyicisi FPC ile
Ã¼retilmiÅŸ `.ppu` dosyalarÄ±nÄ± baÄŸlayamaz** â€” iki derleyicinin birim biÃ§imi
uyumsuzdur. Bu yÃ¼zden tek yol bir **DLL**'dir.

`vdbapi.dll` motorun tamamÄ±nÄ± **C ABI** ile dÄ±ÅŸa aÃ§ar. AynÄ± dosya Delphi,
C#, Python, C, Rust ve diÄŸer dillerden Ã§aÄŸrÄ±labilir; her dil iÃ§in yalnÄ±zca
birkaÃ§ satÄ±rlÄ±k bir baÄŸlayÄ±cÄ± gerekir.

## Dosyalar

| Dosya | Ä°ÅŸlev |
|---|---|
| `vdbapi.dll` | **Motorun kendisi.** ProgramÄ±nÄ±zÄ±n yanÄ±nda olmalÄ±. |
| `vdbapi.h` | C/C++ iÃ§in fonksiyon bildirimleri |
| `VDBClient.pas` | **Delphi/Pascal iÃ§in hazÄ±r birim.** `uses VDbClient;` yeter. |
| `build_dll.ps1` | DLL'i yeniden derler |
| `vdbapitest.exe` | ABI testi (170 kontrol) |
| `vdbclienttest.exe` | Delphi birim testi (101 kontrol) |
| `vdbclientdemo.exe` | Ã‡alÄ±ÅŸtÄ±rÄ±labilir kullanÄ±m Ã¶rneÄŸi |

## Delphi'de KullanÄ±m (Senin Durumun)

### 1. DosyalarÄ± kopyala

`vdbapi.dll` ve `VDBClient.pas` dosyalarÄ±nÄ± Delphi projenin klasÃ¶rÃ¼ne kopyala.

### 2. Projeye ekle

`VDBClient.pas` dosyasÄ±nÄ± projeye "Existing Unit" olarak ekle ve
`uses VDbClient;` yaz.

### 3. Platform: 32-bit

**DLL 32-bit (x86) olarak derlenmiÅŸtir.** Delphi projen de 32-bit olmalÄ±:

```
Project > Options > Delphi Compiler > Target Platforms > 32-bit Windows
```

64-bit projede `vdbapi.dll` yÃ¼klenemez.

### 4. Kullan

```pascal
uses VDbClient;

var
  Db: TVDb;
  R: TVDbResult;
begin
  Db := TVDb.Open('C:\veriler\veritabani.odb');
  try
    Db.SQL('CREATE TABLE kisi (id INTEGER PRIMARY KEY, ad TEXT NOT NULL, yas INTEGER)').Free;

    Db.SQL('INSERT INTO kisi (id, ad, yas) VALUES ' +
           '(1, ''Ali'', 30), (2, ''Veli'', 25)').Free;

    R := Db.SQL('SELECT id, ad FROM kisi ORDER BY id');
    try
      ShowMessage(IntToStr(R.RowCount) + ' satir');
      ShowMessage(R.FieldName(1) + ' = ' + R.Value(0, 1));   // ad = Ali
    finally
      R.Free;
    end;

    // KÄ±sÄ±t hatasÄ± istisna olarak gelir
    try
      Db.SQL('INSERT INTO kisi (id, ad) VALUES (3, NULL)').Free;
    except
      on E: EVDbApiError do
        ShowMessage('KÄ±sÄ±t hatasÄ± (kod ' + IntToStr(E.Code) + '): ' + E.Message);
    end;
  finally
    Db.Free;
  end;
end;
```

Ã‡alÄ±ÅŸan tam Ã¶rnek: `vdbclientdemo.exe`

```
cd veritabani
vdbclientdemo.exe
```

## Ã–nemli Kurallar

### Metinler UTF-8

TÃ¼m metinler **UTF-8** ve NUL ile sonlanÄ±r. Kaynak kodunuzda TÃ¼rkÃ§e
karakter kullanacaksanÄ±z dosyayÄ± UTF-8 olarak kaydedin:

```pascal
Db.SQL('INSERT INTO kisi (id, ad) VALUES (1, ''Ahmet Ã‡elik'')');
```

### AynÄ± VeritabanÄ± AynÄ± Anda Tek Programda AÃ§Ä±k Olabilir

Motor dosyayÄ± **iÅŸlemler arasÄ± kilitler** (`LockFileEx`). Ä°kinci bir
program aynÄ± dosyayÄ± aÃ§maya Ã§alÄ±ÅŸÄ±rsa `VDB_E_OPEN` hatasÄ± alÄ±r:

```pascal
if not TVDb.TryOpen(Yol, True, Db, Hata) then
  ShowMessage('AÃ§Ä±lamadÄ±: ' + Hata);   // baÅŸka program aÃ§Ä±k
```

Yani `had.exe` ile kendi programÄ±nÄ± **aynÄ± anda Ã§alÄ±ÅŸtÄ±ramazsÄ±n**. YÃ¶netimi
kullanacaksan Ã¶nce onu kapat.

### WAL Ä°steÄŸe BaÄŸlÄ±

`Put`/`Delete` otomatik olarak WAL yazmaz. `WalWrite` Ã§aÄŸrÄ±ldÄ±ÄŸÄ±nda kayÄ±t
`.wal` dosyasÄ±na yazÄ±lÄ±r ve **ana dosyaya yazÄ±lmaz**; veri ancak
`WalReplay` veya `WalCheckpoint` ile kalÄ±cÄ± hÃ¢le gelir.

```pascal
Db.WalWrite(1001, 'Ã¶nemli bilgi');   // ana dosyaya YAZILMAZ
Db.WalReplay;                         // ÅŸimdi yazÄ±lÄ±r
```

Normal veri iÃ§in `Put` kullan; WAL yalnÄ±zca "ana dosyaya yazmadan kayÄ±t
tutmak" istediÄŸinde gerekir (Ã¶rn. toplu yÃ¼kleme sÄ±rasÄ±nda Ã§Ã¶kerse veri
kaybolmasÄ±n).

### Hata YÃ¶netimi

Her Ã§aÄŸrÄ± `VDB_OK` (0) dÃ¶nerse baÅŸarÄ±lÄ±dÄ±r. `VDBClient` hatalarÄ±
`EVDbApiError` istisnasÄ± olarak fÄ±rlatÄ±r; `E.Code` ABI hata kodudur.

| Kod | AnlamÄ± |
|---|---|
| `-2` | GeÃ§ersiz handle |
| `-3` | VeritabanÄ± aÃ§Ä±lamadÄ± (baÅŸka program aÃ§Ä±k olabilir) |
| `-4` | SQL hatasÄ± |
| `-9` | Anahtar/tablo bulunamadÄ± |
| `-10` | UNIQUE veya PK ihlali |
| `-11` | FK / CHECK / NOT NULL ihlali |

### `VdbGet` Ä°ki AÅŸamalÄ±dÄ±r

DoÄŸrudan DLL'i kullanÄ±rsan deÄŸeri okumak iki Ã§aÄŸrÄ± ister:

```c
int need = VdbGet(h, key, NULL, 0);   /* gerekli boyut */
if (need == -1) { /* anahtar yok */ }
else if (need < 0) { need = -need; }  /* negatif = boyut */
char buf[need];
VdbGet(h, key, buf, need);            /* asÄ±l okuma */
```

`VDBClient.pas` bunu sizin iÃ§in yapar â€” `GetStr` / `GetBytes` kullanÄ±n.

## BaÅŸka Diller Ä°Ã§in

`vdbapi.h` dosyasÄ±ndaki imzalarÄ± kullan. Ã–rnek C:

```c
#include "vdbapi.h"

uint32_t db = VdbOpen("C:\\veriler\\veritabani.odb", 1);
if (db == 0) {
    printf("Hata %d: %s\n", VdbLastErrorCodeGet(), VdbLastError());
    return 1;
}

uint32_t r = VdbExec(db, "SELECT id, ad FROM kisi", 0);
if (r) {
    int n = VdbResultRowCount(r);
    for (int i = 0; i < n; i++)
        printf("%s\n", VdbResultValue(r, i, 1));
    VdbResultFree(r);
}
VdbClose(db);
```

## Derleme

DLL'i yeniden derlemek iÃ§in:

```powershell
powershell -ExecutionPolicy Bypass -File build_dll.ps1
```

> **Not:** Lazarus'un `.lpi` XML'inde kÃ¼tÃ¼phane tÃ¼rÃ¼ iÅŸareti bu kurulumda
> okunmadÄ±ÄŸÄ± ve proje `.exe` olarak baÄŸlandÄ±ÄŸÄ± iÃ§in DLL derlemesi FPC'yi
> doÄŸrudan Ã§aÄŸÄ±ran `build_dll.ps1` ile yapÄ±lÄ±r. AynÄ± nedenle derleme
> betiÄŸinde `-Mdelphi` **bilinÃ§li olarak verilmez**: `VDbCrc32.pas` iÃ§indeki
> bir yorumda `{$mode delphi}` dizisi geÃ§iyor ve delphi modunda derleme
> kÄ±rÄ±lÄ±yor (FPC yorumu `}` ile kapatÄ±p satÄ±rÄ±n kalanÄ±nÄ± kod sanÄ±yor).

## DoÄŸrulama Durumu

| Test | Kapsam | SonuÃ§ |
|---|---|---|
| `sqltest.exe` | Motor (1446 kontrol) | âœ… 1446/1446 |
| `vdbapitest.exe` | DLL ABI (170 kontrol) | âœ… 170/170 |
| `vdbclienttest.exe` | Delphi birimi (101 kontrol) | âœ… 101/101 |

`vdbapitest.exe` DLL'i **`LoadLibrary` ile dinamik yÃ¼kler** ve her export'u
`GetProcAddress` ile adres alarak Ã§aÄŸÄ±rÄ±r â€” yani gerÃ§ekten harici bir
programÄ±n yaptÄ±ÄŸÄ±nÄ± yapar. Eksik bir export sessizce geÃ§mez, test
hata durur.

---

## Otomatik WAL (write-ahead) - `VdbWalSetAuto`

WAL'i **elle** kullanmak (`VdbWalWrite`) hataya acik: cagirmayi unutursan
kayit yalniz bellekte kalir. Otomatik modda motor **her yazmada** once
`.wal`'a, sonra ana dosyaya yazar.

```c
/* ac: bundan sonraki her Put/DeleteOnce once .wal'a */
VdbWalSetAuto(hDb, 1);

/* ... normal yazma islemleri ... */

int n = VdbWalAutoCount(hDb);   /* bu agaza kadar gunluge yazilan kayit */
int acik = VdbWalIsAuto(hDb);   /* 1 = acik */

/* gunlugu temizle (veri zaten ana dosyada) */
VdbWalCheckpoint(hDb);

/* kapat: geriye donuk uyumlu eski davranis */
VdbWalSetAuto(hDb, 0);
```

Delphi'de:

```pascal
Db.WalAutoEnabled := True;   // veya Db.SetWalAuto(True)
Db.Put(1, 'deger');          // once .wal, sonra ana dosya
Db.WalAutoCount;              // 1
```

Kurallar:

- **Varsayilan KAPALI.** Cagirmazsaniz hicbir sey degismez.
- **WAL yazilamazsa** yazma hata doner ve **ana dosyaya yazilmaz**.
- `Close` durumu **sifirlar**; yeniden `Open` edince `VdbWalIsAuto = 0`.
- Elle `VdbWalWrite` kullanacaksaniz otomatik modu **kapatin** (cift yazim).
- `VdbWalReplay` otomatik modda kayitlari **iki kez** uygular (veri
  bozulmaz, `PUT`/`DEL` idempotent; ama ayni kayit tekrar yazilir). Bu
  yuzden otomatik modda `VdbWalCheckpoint` kullanin.

Hata sozlesmesi: hata halinde donus degeri **negatiftir**
(`VDB_E_GENERAL`), spesifik kod `VdbErrCode()` ile alinir
(`VDB_E_BAD_HANDLE` vb.). Sorgu donduruculer (`VdbWalIsAuto`,
`VdbWalAutoCount`, `VdbWalHas`, `VdbWalRecordCount`) `0` donerek hatayi
gizlemez.

---

## Åifreleme - `VdbEncrypt*` (2026-10-05)

Kayitlari AES-256-CTR + HMAC-SHA256 ile sifreler. **Donus sozlesmesi
farklidir**: bu fonksiyonlar `1 = basari`, `0 = hata` dondurur (hata
ayrintisi `VdbLastError()` / `VdbErrCode()`).

```c
/* 1) parola (.key) modu - oncelikle kullanilan yol */
VdbEncryptCreateKeyFile(hDb, "C:\\db\\veritabani.key", "guclu-parola");
/* artik yazilan TUM kayitlar sifrelidir */

/* acilista: yanlis parola -> 0 doner (istisna/crash yok) */
if (!VdbEncryptOpenKeyFile(hDb, "C:\\db\\veritabani.key", "guclu-parola"))
    printf("parola hatali: %s", VdbLastError());

/* 2) ham 32 bayt anahtar modu (parola olmadan, uygulama yonetir) */
unsigned char key[32] = { /* ... */ };
VdbEncryptEnable(hDb, key, 32);
memset(key, 0, sizeof key);          /* DLL kopyasini bellekte tutar */

/* durum sor */
int enc  = VdbEncryptIsEncrypted(hDb);           /* 1 = anahtar aktif */
int hev  = VdbHasEncryptedRecords(hDb);          /* 1 = dosyada sifreli kayit var */

char fp[32];
VdbEncryptFingerprint(hDb, fp, sizeof fp);       /* or. "D641A587" (hash, sifir degil) */

/* parola rotasyonu (eski anahtar aktifken cagir) */
VdbRekeyWithPassword(hDb, "yeni-parola");        /* .key guncellenir, .bak kalir */

/* kapat */
VdbEncryptDisable(hDb);
```

Kurallar:

- `.key` dosyasi **sir tutmaz** (tuz + iterasyon + dogrulayici). Sirl
  paroladir; parolayi sizdirmayin.
- `VdbEncryptEnable` sadece **yeni** yazilari sifreler; mevcut karisik
  (duz + sifreli) dosyalar aynen okunur (her kayit kendi bayragini tasir).
- Sifreli kayit **anahtarsiz okunursa** hata doner
  (`SIFRELI: anahtar yok`) â€” sessizce bozuk veri degil.
- `VdbRekeyWithPassword` once yeni `.key`'i (`.key.tmp`), sonra veriyi
  tmp cikisi + atomik rename ile yeniden yazar; eski `.odb` `.odb.bak`,
  eski `.key` `.key.bak` olarak kalir. Batch acikken cagrilamaz.
- `VdbVerify` raporunda `sifreli=N` alani vardir.
- **WAL (`VdbWalWrite`) veriyi duz metin yazar** (acil durum kurtarma
  icin bilincli); WAL dosyasi da parola korumali degildir.

Delphi (`VDBClient.pas`): `Db.SetEncryptKey`, `Db.CreateKeyFile`,
`Db.OpenKeyFile`, `Db.IsEncrypted`, `Db.HasEncryptedRecords`,
`Db.KeyPath`, `Db.GetEncryptionKeyFingerprint`,
`Db.RekeyWithPassword`, `Db.ClearEncryptKey`.

Test: `vdbapitest.exe` (170/170), `vdbclienttest.exe` (101/101),
`vdbcrypttest.exe` (60/60).

---

## CDC / Time Travel - `VdbCdc*` + `VdbValueAt` (2026-10-06)

CDC (Change Data Capture), `.wal` dosyasindaki satir degisikliklerini
(INSERT/UPDATE/DELETE) olay olarak verir; Time Travel (`VdbValueAt`) ayni
gecmisten bir satirin o anki degerini okur. **Callback DLL sinirini
gecmez**: olaylar istemci tarafindan **poll** edilir (C/Delphi icin en
guvenli yon). ABI surumu bu eklemeye 1.0 -> **1.1** oldu (geriye uyumlu).

```c
VdbCdcStart(hDb);              /* otomatik WAL acilir; ~50ms'de bir taranir */

/* ... VdbPut / VdbExec ile yazmalar ... */

for (;;)
{
    int n = VdbCdcPollSize(hDb);       /* >0 olay boyutu, 0 = olay yok */
    if (n <= 0) break;                 /* negatif = hata kodu */
    char buf[4096];
    if (n > (int)sizeof buf) n = (int)sizeof buf;
    int got = VdbCdcPoll(hDb, buf, n); /* kopyalar VE tuketir */
    if (got == 0) break;               /* olay yok */
    if (got < 0) break;                /* VDB_E_BUFFER: olay tamponda KALIR */
    /* buf[0..got-1] = paket; alanlar #30 (RS) ile ayrili */
}

VdbCdcStop(hDb);               /* durdurur; kalan olaylar tamponda KALIR */
```

Paket (UTF-8, NUL'suz, alan ayirici `#30` = RS):

    kind #30 seq #30 table #30 pk #30 oldJson #30 newJson

| Alan | Anlam |
|---|---|
| `kind` | `0` insert, `1` update, `2` delete |
| `seq` | CDC olay sira numarasi (WAL'de bu alan YOKTUR, DLL'de uretilir) |
| `table` / `pk` | tablo adi ve satirin birincil anahtari |
| `oldJson` / `newJson` | kolon degerleri JSON dizisi: `["1","bir"]` (bos taraf `[]`) |
| Zaman damgasi | **pakette YOKTUR** - istemci kendi UTC epoch-ms damgasini eklesin |

`VdbCdcStats(hDb, &ev, &skip, &pend, &drop)` tanilama sayaclari (NULL
gecilebilir): uretilen olay, atlanan WAL kaydi (sema kaydi degeri olmayan
silme), tampondaki bekleyen, tampon siniri asilirsa dusen.

Kurallar:

- **Tek istemci**: ayni anda iki `VdbCdcPoll` cagirilmaz.
- Tampon siniri 100000 olaydir; tasarsa **en eski** olay duser ve `drop`
  artar - sessiz kayip yoktur.
- `VdbClose` CDC nesnesini thread'iyle birlikte serbest birakir; calisirken
  kapatmak guvenlidir. Handle kapaninca CDC baglantisi da sifirlanir
  (yeniden acinca `VdbCdcStart` tekrar cagirilir).
- CDC baslamadan `VdbCdcPoll*`/`VdbCdcStats` cagirilirsa hata doner
  (`VDB_E_ENGINE`), `VdbCdcStop` ayni sekilde.
- CDC yalnizca **son checkpoint'ten sonraki** yazilari gorur; silme
  olayinin PK'si daha once WAL'e dusen bir PUT varsa uretilebilir
  (CDC'yi yazmadan once baslatmak en dogrusu).

### Time Travel - `VdbValueAt`

```c
char js[256];
int need = VdbValueAt(hDb, "tablo", "pk", 6, NULL, 0);
/* donus sozlesmesi VdbGet ile ayni:
     <0  -> gerekli boyut = -sonuc  (ALen=0 boyut sorgusu)
     -1  -> o noktada satir YOK (silinmis/hic yazilmamis)
     >0  -> kopyalanan bayt */
if (need < -1) {
    need = -need;
    int got = VdbValueAt(hDb, "tablo", "pk", 6, js, need);
    /* js = ["1","bir"] */
}

int history = VdbHistoryCount(hDb);   /* okunabilir gecmis sayisi (>=0) */
```

- `aSeq` = WAL kayit **indeksi** (0 tabanli, o indeks **dahil** uygulanmis
  goruntu); `n >= WalRecordCount` son kayda kirpilir.
- Gecmis yalnizca **son checkpoint'ten** beriyi kapsar (`VdbHistoryCount`
  0 donebilir) - "tarihin tamami" degildir.
- `VdbValueAt` her cagrida WAL'i tarar (scan); sik sorgulanacak degerler
  icin istemci kendi onbelleini tutmalidir.

Delphi (`VDBClient.pas`): `Db.CdcStart`, `Db.CdcStop`, `Db.CdcPollSize`,
`Db.CdcPoll(pkt)` (True = olay var, hata `EVDbApiError`),
`Db.CdcStats(ev, skip, pend, drop)`, `Db.ValueAt(tbl, pk, seq, js)`
(True = satir var; yasayan API yalnizca True/False dondurur),
`Db.HistoryCount`.

Test: `vdbapitest.exe` (170/170 - "CDC (poll) + TIME TRAVEL" grubu),
`vdbclienttest.exe` (101/101).






