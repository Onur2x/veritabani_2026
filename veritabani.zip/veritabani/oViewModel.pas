unit oViewModel;

{$mode ObjFPC}{$H+}

interface

uses
  SysUtils, Classes, Generics.Collections,
  Grids, ComCtrls, Variants, oTypes;

type
  TRowViewModel = class
  private
    FRow: TRow;
  public
    constructor Create(ARow: TRow);
    function GetFieldNames: specialize TArray<string>;
    function GetValue(const FieldName: string): string;
    property RawRow: TRow read FRow;
  end;

type
  generic TObservableList<T> = class
  private
  type TInternalList = specialize TList<T>;
  private
    FItems: TInternalList;
    // FItems: specialize TList<T>;
  public
    constructor Create;
    destructor Destroy; override;
    procedure Add(Item: T);
    procedure Clear;
    function ToArray: specialize TArray<T>;
    property Items: specialize TList<T> read FItems;
  end;


// Liste dönüşüm
function ToViewModelList(const Rows: TRowList): specialize TObservableList<
  TRowViewModel>;

// GUI bağlayıcılar
procedure BindViewModelsToGrid(Grid: TStringGrid;
  const ViewModels: specialize TObservableList<TRowViewModel>);
procedure BindViewModelsToListView(ListView: TListView;
  const ViewModels: specialize TObservableList<TRowViewModel>);

implementation

{ TRowViewModel }

constructor TRowViewModel.Create(ARow: TRow);
begin
  inherited Create;
  FRow := ARow;
end;

function TRowViewModel.GetFieldNames: specialize TArray<string>;
begin
  Result := FRow.GetFieldNames;
end;

function TRowViewModel.GetValue(const FieldName: string): string;
begin
  Result := VarToStr(FRow[FieldName]);
end;

{ TObservableList<T> }
constructor TObservableList.Create;
begin
  inherited Create;
  FItems := TInternalList.Create;
  //  FItems := TList.Create;
end;

destructor TObservableList.Destroy;
begin
  FItems.Free;
  inherited Destroy;
end;

procedure TObservableList.Add(Item: T);
begin
  FItems.Add(Item);
end;

procedure TObservableList.Clear;
begin
  FItems.Clear;
end;

function TObservableList.ToArray: specialize TArray<T>;
begin
  Result := FItems.ToArray;
end;

{ Liste dönüşümü }

function ToViewModelList(const Rows: TRowList): specialize TObservableList<
TRowViewModel>;
var
  r: TRow;
begin
  Result := specialize TObservableList<TRowViewModel>.Create;
  for r in Rows do
    Result.Add(TRowViewModel.Create(r));
end;

{ TStringGrid bağlama }

procedure BindViewModelsToGrid(Grid: TStringGrid;
  const ViewModels: specialize TObservableList<TRowViewModel>);
var
  i, j: integer;
  fields: specialize TArray<string>;
begin
  Grid.RowCount := ViewModels.Items.Count + 1;
  if ViewModels.Items.Count = 0 then Exit;

  fields := ViewModels.Items[0].GetFieldNames;
  Grid.ColCount := Length(fields);

  // Başlık satırı
  for j := 0 to High(fields) do
    Grid.Cells[j, 0] := fields[j];

  // Veri satırları
  for i := 0 to ViewModels.Items.Count - 1 do
    for j := 0 to High(fields) do
      Grid.Cells[j, i + 1] := ViewModels.Items[i].GetValue(fields[j]);
end;

{ TListView bağlama }

procedure BindViewModelsToListView(ListView: TListView;
  const ViewModels: specialize TObservableList<TRowViewModel>);
var
  i: integer;
  fields: specialize TArray<string>;
  vm: TRowViewModel;
  item: TListItem;
  field: string;
begin
  ListView.Items.BeginUpdate;
  try
    ListView.Clear;

    if ViewModels.Items.Count = 0 then Exit;
    fields := ViewModels.Items[0].GetFieldNames;

    // Sütunları ayarla (vsReport modunda)
    ListView.ViewStyle := vsReport;
    ListView.Columns.Clear;
    for field in fields do
      ListView.Columns.Add.Caption := field;

    // Satırları ekle
    for vm in ViewModels.Items do
    begin
      item := ListView.Items.Add;
      item.Caption := vm.GetValue(fields[0]); // ilk alan

      for i := 1 to High(fields) do
        item.SubItems.Add(vm.GetValue(fields[i]));
    end;
  finally
    ListView.Items.EndUpdate;
  end;
end;

end.
