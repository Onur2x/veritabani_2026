unit OTablo;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, Variants, Generics.Collections,
   OTabloSchema, oTabloKayit, fpjson;

type
  { TVTablo }

  TVTablo = class
  private
    FAd: string;
    FSchema: TTabloSchema;
    FInTransaction: Boolean;
    FKayitlar: specialize TObjectList<TTabloKayit>;
    FTempKayitlar: specialize TObjectList<TTabloKayit>;
    FSonID: Integer;
    procedure SetSchema(S: TTabloSchema);
    procedure TamamlaEksikAlanlar(const K:TTabloKayit;const Schema:TTabloSchema;
      const SonID:Integer);
  public
    constructor Create(const AAd: string);
    destructor Destroy; override;

    function VarmiAyniPrimaryKey(const K:TTabloKayit):Boolean;
    procedure KayitEkle(K: TTabloKayit);
    procedure Temizle;
    procedure BeginTransaction;
    procedure CommitTransaction;
    procedure RollbackTransaction;
    function Kayit(Index: Integer): TTabloKayit;
    function KayitSayisi: Integer;
    function ToJSONArray: TJSONArray;
    procedure FromJSONArray(A: TJSONArray);

    function TabloyuJsonSemaOlarakAl: string;
    procedure TabloyuJsonSemaIleKurFromString(JSONStr: string);
    procedure SaveToStream(S: TStream);
    procedure LoadFromStream(S: TStream);
    property Ad: string read FAd write FAd;
    property Schema: TTabloSchema read FSchema write SetSchema;
    property Kayitlar: specialize TObjectList<TTabloKayit> read FKayitlar;
    property SonID: Integer read FSonID write FSonID;
  end;

implementation

uses
  jsonparser,odebug,Math,otypes;


function DegerlerAyni(const A, B: Variant): Boolean;
begin
  Result := (VarCompareValue(A, B) = vrEqual);
end;


constructor TVTablo.Create(const AAd: string);
begin
  inherited Create;
  FAd := AAd;
  FKayitlar := specialize TObjectList<TTabloKayit>.Create(True); // Sahiplik var
  FSchema := nil;
  FTempKayitlar := specialize TObjectList<TTabloKayit>.Create(True);
  FInTransaction := False;
  FSonID := 0;
end;

destructor TVTablo.Destroy;
begin
  FKayitlar.Free;
  FTempKayitlar.Free;
  if Assigned(FSchema) then
    FSchema.Free;
  inherited Destroy;
end;




procedure TVTablo.SetSchema(S: TTabloSchema);
begin
  if Assigned(FSchema) then
    FSchema.Free;
  FSchema := S;
end;





procedure TVTablo.Temizle;
begin
  FKayitlar.Clear;
end;

function TVTablo.Kayit(Index: Integer): TTabloKayit;
begin
  if (Index < 0) or (Index >= FKayitlar.Count) then
    raise Exception.CreateFmt('Kayıt index dışı: %d', [Index]);
  Result := FKayitlar[Index];
end;

function TVTablo.KayitSayisi: Integer;
begin
if Assigned(FKayitlar) then
  Result := FKayitlar.Count
else
  Result := 0;
 // Result := FKayitlar.Count;
end;

function TVTablo.VarmiAyniPrimaryKey(const K: TTabloKayit): Boolean;
var
  Mevcut: TTabloKayit;
  i: Integer;
  Alani: TAlanTanimi;
begin
  Result := False;
  for i := 0 to High(FSchema.Alanlar) do
  begin
    Alani := FSchema.Alanlar[i];
    if not Alani.PrimaryKey then Continue;

    for Mevcut in FKayitlar do
      if DegerlerAyni(Mevcut.DegerAl(Alani.Name), K.DegerAl(Alani.Name)) then
        Exit(True);
  end;
end;

procedure TVTablo.TamamlaEksikAlanlar(const K:TTabloKayit; const Schema: TTabloSchema; const SonID: Integer);
var
  i: Integer;
  Alan: TAlanTanimi;
  YeniID: Integer;
begin
  for i := 0 to Schema.AlanSayisi - 1 do
  begin
    Alan := Schema.Alanlar[i];

    // 🧠 Alan zaten doluysa geç
    if k.Varmi(Alan.Name) then
      Continue;

    // 🔢 AUTO_INCREMENT alanlar için benzersiz ID üret
    if Alan.AutoIncrement and (Alan.Tip = ftInteger) then
    begin
      YeniID := SonID + 1;
      while VarmiAyniPrimaryKey(k) do //Alan.Name, YeniID) do
        Inc(YeniID);

      k.DegerAta(Alan.Name, YeniID);
      //DebugLog('✅ AUTOINC tamamlandı: ' + Alan.Name + ' → ' + IntToStr(YeniID));
    end
    // 🎯 NOT NULL + DEFAULT varsa → DEFAULT uygulanır
    else if Alan.NotNull and
            (VarType(Alan.DefaultDeger) <> varEmpty) and
            (VarType(Alan.DefaultDeger) <> varNull) and
            (Trim(VarToStr(Alan.DefaultDeger)) <> '') then
    begin
      k.DegerAta(Alan.Name, Alan.DefaultDeger);
   //   DebugLog('🎯 DEFAULT tamamlandı (NOT NULL): ' + Alan.Name + ' → ' + VarToStr(Alan.DefaultDeger));
    end
    // 🧩 NOT NULL ama DEFAULT yoksa → sistem dolgu
    else if Alan.NotNull then
    begin
      case Alan.Tip of
        ftText:    K.DegerAta(Alan.Name, '');
        ftFloat:   K.DegerAta(Alan.Name, 0.0);
        ftInteger: K.DegerAta(Alan.Name, 0);
      else
        K.DegerAta(Alan.Name, Null);
      end;
   //   DebugLog('🧩 Sistem dolgu uygulandı (NOT NULL): ' + Alan.Name + ' → ' + VarToStr(K.DegerAl(Alan.Name)));
    end
    // 🔘 Opsiyonel alanlar için DEFAULT varsa → uygula
    else if (VarType(Alan.DefaultDeger) <> varEmpty) and
            (VarType(Alan.DefaultDeger) <> varNull) and
            (Trim(VarToStr(Alan.DefaultDeger)) <> '') then
    begin
      K.DegerAta(Alan.Name, Alan.DefaultDeger);
    //  DebugLog('🎯 DEFAULT uygulandı (opsiyonel): ' + Alan.Name + ' → ' + VarToStr(Alan.DefaultDeger));
    end
    // ➖ Opsiyonel ve boş bırakılabilir alanlar
    else
    begin
      K.DegerAta(Alan.Name, Null);
    //  DebugLog('🔘 Opsiyonel alan boş bırakıldı: ' + Alan.Name);
    end;
  end;
end;

procedure TVTablo.KayitEkle(K: TTabloKayit);
begin

  if not Assigned(FSchema) then
    raise Exception.Create('Şema tanımlanmamış!');


//  DebugLog('Tammala eksik alanlar başlatıldı');
  TamamlaEksikAlanlar(K,FSchema, FSonID);
 // DebugLog('Tammala eksik alanlar bitti');


   // 🚫 PRIMARY KEY çakışma kontrolü
 // if VarmiAyniPrimaryKey(K) then
//    raise Exception.Create('Zaten aynı PRIMARY KEY değerine sahip kayıt mevcut!');

//  if K.Varmi('ID') then
//  if VarType(K.DegerAl('ID')) in [varSmallInt, varInteger, varByte] then
//    FSonID := Max(FSonID, Integer(K.DegerAl('ID')));


  if FInTransaction then
    FTempKayitlar.Add(K)
  else
    FKayitlar.Add(K);


end;



procedure TVTablo.SaveToStream(S: TStream);
var
  i: Integer;
  Veri: TBytes;
  KayitSay: QWord;
begin
  if not Assigned(FSchema) then
    raise Exception.Create('Şema tanımlı değil!');

  KayitSay := FKayitlar.Count;
//  DebugLog('SaveToStream başlatıldı: ' + FAd + ' | Kayıt sayısı: ' + IntToStr(KayitSay));

  // Kayıt sayısı yazılır
  S.WriteQWord(KayitSay);

  if KayitSay > 0 then
  begin
  // Boş bile olsa tablo serialize edilir
    for i := 0 to KayitSay - 1 do
    begin
      Veri := FKayitlar[i].SerializeToBytes(FSchema);
      S.WriteBuffer(Veri[0], Length(Veri));
    end;
 // end
//  else
//  begin
//      DebugLog('Boş veri atlandı → Kayıt #' + IntToStr(i));
  end;
end;

procedure TVTablo.LoadFromStream(S: TStream);
var
  K: TTabloKayit;
  KayitBoyutu: Integer;
  Veri: TBytes;
  KayitSay: QWord;
  i: Integer;
begin
  if not Assigned(FSchema) then
    raise Exception.Create('Şema tanımlı değil!');

  //ReadQWord(S, KayitSay); // 👈 kayıt sayısını oku
  KayitSay:=S.ReadQWord;
  KayitBoyutu := FSchema.ToplamKayitBoyutu;
  SetLength(Veri, KayitBoyutu);
  Temizle;

  try
    for i := 1 to KayitSay do
    begin
      S.ReadBuffer(Veri[0], KayitBoyutu);
      K := TTabloKayit.Create;
      K.DeserializeFromBytes(FSchema, Veri);
      FKayitlar.Add(K);
    end;
  except
    on E: Exception do
      raise Exception.Create('Kayıtları okurken hata: ' + E.Message);
  end;
end;


function TVTablo.ToJSONArray: TJSONArray;
var
  i: Integer;
begin
  Result := TJSONArray.Create;
  for i := 0 to FKayitlar.Count - 1 do
    Result.Add(FKayitlar[i].ToJSON);
end;

procedure TVTablo.FromJSONArray(A: TJSONArray);
var
  i: Integer;
  K: TTabloKayit;
begin
  Temizle;
  for i := 0 to A.Count - 1 do
  begin
    K := TTabloKayit.Create;
    K.FromJSON(A.Objects[i]);
    FKayitlar.Add(K);
  end;
end;

function TVTablo.TabloyuJsonSemaOlarakAl: string;
begin
  if not Assigned(FSchema) then
    raise Exception.Create('Şema tanımsız!');
  Result := FSchema.ToJSON.AsJSON;
end;

procedure TVTablo.TabloyuJsonSemaIleKurFromString(JSONStr: string);
var
  J: TJSONArray;
  P: TJSONParser;
begin
  P := TJSONParser.Create(JSONStr);
  try
    J := P.Parse as TJSONArray;
    FSchema := TTabloSchema.Create(FAd);
    FSchema.FromJSON(J);
  finally
    P.Free;
  end;
end;
procedure TVTablo.BeginTransaction;
begin
  if FInTransaction then Exit;
  FTempKayitlar := specialize TObjectList<TTabloKayit>.Create(True);
  FInTransaction := True;
end;

procedure TVTablo.CommitTransaction;
begin
  if not FInTransaction then Exit;
  FKayitlar.AddRange(FTempKayitlar);
  FTempKayitlar.Free;
  FInTransaction := False;
end;

procedure TVTablo.RollbackTransaction;
begin
  if not FInTransaction then Exit;
  FTempKayitlar.Free;
  FInTransaction := False;
end;
end.

