unit oHelper;

{$mode ObjFPC}{$H+}

interface

uses
  SysUtils, Classes, Variants, fpjson, jsonparser;

function SplitCSV(const S: string): specialize TArray<string>;
function ToVariantArray(const Values: specialize TArray<string>):
  specialize TArray<variant>;
function SafeCompare(const A, B: variant): integer;
function IsTruthy(const V: variant): boolean;
procedure SaveJSONToFile(const JSON: TJSONData; const DosyaAd: string);
function LoadJSONFromFile(const FileName: string): TJSONObject;


implementation

function LoadJSONFromFile(const FileName: string): TJSONObject;
var
  jsonParser: TJSONParser;
  jsonData: TJSONData;
  fileStream: TFileStream;
  utf8Text: string;
begin
  Result := nil;
  fileStream := TFileStream.Create(FileName, fmOpenRead or fmShareDenyNone);
  try
    SetLength(utf8Text, fileStream.Size);
    fileStream.ReadBuffer(utf8Text[1], Length(utf8Text));
    jsonParser := TJSONParser.Create(utf8Text);
    try
      jsonData := jsonParser.Parse;
      if jsonData.JSONType = jtObject then
        Result := TJSONObject(jsonData)
      else
        jsonData.Free;
    finally
      jsonParser.Free;
    end;
  finally
    fileStream.Free;
  end;
end;


procedure SaveJSONToFile(const JSON: TJSONData; const DosyaAd: string);
var
  sstream: TStringStream;
begin
  sstream := TStringStream.Create(JSON.AsJSON, TEncoding.UTF8);
  try
    sstream.SaveToFile(DosyaAd);
  finally
    sstream.Free;
  end;
end;

function SplitCSV(const S: string): specialize TArray<string>;
var
  i: integer;
begin
  Result := S.Split([',']);
  for i := 0 to High(Result) do
    Result[i] := Trim(Result[i]);
end;

function ToVariantArray(const Values: specialize TArray<string>): specialize
TArray<variant>;
var
  i: integer;
begin
  SetLength(Result, Length(Values));
  for i := 0 to High(Values) do
    Result[i] := Values[i];
end;



function SafeCompare(const A, B: variant): integer;
begin
  if VarType(A) in [varDouble, varCurrency] then
  begin
    if A < B then Result := -1
    else if A > B then Result := 1
    else
      Result := 0;
  end
  else if VarType(A) = varInteger then
    Result := A - B
  else
    Result := CompareStr(VarToStr(A), VarToStr(B));
end;

function IsTruthy(const V: variant): boolean;
begin
  Result := (VarToStr(V) = '1') or SameText(VarToStr(V), 'True');
end;

end.
