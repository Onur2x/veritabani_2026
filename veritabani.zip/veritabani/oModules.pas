unit oModules;

{$mode ObjFPC}{$H+}

interface

uses
  SysUtils, Classes, oVeritabani;

type
  TModulYonetici = class
  private
    FVeritabani: TVeritabani;
    FEnableJSON: boolean;
    FEnableGUI: boolean;
    FEnableSerialization: boolean;
  public
    constructor Create(Veritabani: TVeritabani);

    procedure ExportJSON(const FileName: string);
    procedure ImportJSON(const FileName: string);

    property EnableJSON: boolean read FEnableJSON write FEnableJSON;
    property EnableGUI: boolean read FEnableGUI write FEnableGUI;
    property EnableSerialization: boolean read FEnableSerialization
      write FEnableSerialization;
  end;

implementation

constructor TModulYonetici.Create(Veritabani: TVeritabani);
begin
  inherited Create;
  FVeritabani := Veritabani;
  FEnableJSON := True;
  FEnableGUI := True;
  FEnableSerialization := False; // ilerde eklenecek
end;

procedure TModulYonetici.ExportJSON(const FileName: string);
begin
  if not FEnableJSON then Exit;
  FVeritabani.SaveToFile(FileName);
end;

procedure TModulYonetici.ImportJSON(const FileName: string);
begin
  if not FEnableJSON then Exit;
  FVeritabani.LoadFromFile(FileName);
end;


end.
