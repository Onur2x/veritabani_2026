unit oModulesGUI;

{$mode ObjFPC}{$H+}

interface

uses
  SysUtils, Classes, Grids, ComCtrls,
  oTypes, oVeritabani, oViewModel;

procedure LoadTableToGrid(const Veri: TVeritabani; Grid: TStringGrid;
  const DBName, TableName: string; const Columns: specialize TArray<string>);

procedure LoadTableToListView(const Veri: TVeritabani; ListView: TListView;
  const DBName, TableName: string; const Columns: specialize TArray<string>);

implementation

procedure LoadTableToGrid(const Veri: TVeritabani; Grid: TStringGrid;
  const DBName, TableName: string; const Columns: specialize TArray<string>);
var
  rows: TRowList;
  vms: TObservableList<TRowViewModel>;
begin
  rows := Veri.SelectFrom(DBName, TableName, Columns, []);
  vms := ToViewModelList(rows);
  BindViewModelsToGrid(Grid, vms);
  vms.Free;
end;

procedure LoadTableToListView(const Veri: TVeritabani; ListView: TListView;
  const DBName, TableName: string; const Columns: specialize TArray<string>);
var
  rows: TRowList;
  vms: TObservableList<TRowViewModel>;
begin
  rows := Veri.SelectFrom(DBName, TableName, Columns, []);
  vms := ToViewModelList(rows);
  BindViewModelsToListView(ListView, vms);
  vms.Free;
end;

end.
