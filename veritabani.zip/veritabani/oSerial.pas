unit oSerial;

{$mode ObjFPC}{$H+}

interface

uses
  SysUtils, Classes, oTypes, oVeritabani, fpjson;

procedure SaveODB(const Veri: TVeritabani; const FileName: string);
procedure LoadODB(const Veri: TVeritabani; const FileName: string);

implementation

procedure SaveJSONToFile(const JSON: TJSONData; const DosyaAd: string);
var
  stream: TStringStream;
begin
  stream := TStringStream.Create(JSON.AsJSON, TEncoding.UTF8);
  try
    stream.SaveToFile(DosyaAd);
  finally
    stream.Free;
  end;
end;


procedure SaveODB(const Veri: TVeritabani; const FileName: string);
var
  schemaJSON: TJSONObject;
begin
  schemaJSON := Veri.BuildFullJSON;
  SaveJSONToFile(schemaJSON, FileName);
  schemaJSON.Free;
end;

procedure LoadODB(const Veri: TVeritabani; const FileName: string);
var
  stream: TFileStream;
  jObj: TJSONObject;
  i: integer;
begin
  stream := TFileStream.Create(FileName, fmOpenRead);
  try
    jObj := TJSONObject(GetJSON(stream));
    for i := 0 to jObj.Count - 1 do
      Veri.LoadTableFromJSON(jObj.Objects[jObj.Names[i]]);
    jObj.Free;
  finally
    stream.Free;
  end;
end;


end.
