unit osqlengine;

{$mode ObjFPC}{$H+}

interface

uses
  SysUtils, StrUtils, Generics.Collections,
  Classes,
  oVeritabani, oTabloSchema, oTypes;

type
  // Komut tipi
  TSqlCommandType = (
    ctUnknown,
    ctCreateDatabase,
    ctCreateTable,
    ctAlterTable,
    ctShowTable,
    ctInsert,
    ctSelect,
    ctDropTable
    );


  // Ayrıştırılmış SQL komutu
  TSqlCommand = record
    CmdType: TSqlCommandType;
    OriginalSQL: string;
    TableName: string;
    ColumnsDef: specialize TArray<TAlanTanimi>;      // CREATE TABLE / ALTER
    SelectCols: specialize TArray<string>;           // SELECT
    Conditions: specialize TArray<TCondition>;       // SELECT
    InsertCols: specialize TArray<string>;           // INSERT
    InsertValues: specialize TArray<string>;           // INSERT
    ResultRows: specialize TList<TRow>;              // SELECT/SHOW sonuc

    Basarili: boolean;
    SorguTipi: string;
    KayitSayisi: integer;
    HataMesaji: string;
    Sure: TDateTime;
    SatirMesajlari: specialize TArray<string>;
    Schema: TTabloSchema;  // SELECT sonrası klon
    Data: specialize TList<TRow>;   // SELECT sonrası satırlar
    Veritabani: TVeritabani;
    DatabaseName: string;

  end;

  // SQL motoru
  TSqlEngine = class
  private
    FDB: TVeritabani;
    FCommandHistory: specialize TList<TSqlCommand>;

    // Parser yardımcıları
    function Between(const A, StartTok, EndTok: string): string;
    function ExtractParenContent(const S: string; StartPos: integer;
      out Content: string; out EndPos: integer): boolean;
    procedure ParseInsertParts(const SQL: string; out Tbl: string;
      out Cols, Vals: specialize TArray<string>);
    procedure SplitBalanced(const List: string; out Arr: specialize TArray<string>);
    procedure ParseConditions(const CondStr: string;
      out Conds: specialize TArray<TCondition>);
    function ParseCommand(const SQL: string; out Cmd: TSqlCommand): boolean;
    function SplitColumnDefs(const ParenList: string): specialize TArray<TAlanTanimi>;
    function SplitColumnDefs2(const ParenList: string):
      specialize TArray<TAlanTanimi>;
    function SplitStatements(const SQL: string): specialize TArray<string>;
    function SplitTopLevel(const S: string; Delim: char): specialize TArray<string>;
    /// Tek bir SQL ifadesini parse edip çalıştırır
    procedure ExecuteSQLsingle(const SQL: string; out Cmd: TSqlCommand);
  public
    constructor Create(ADatabase: TVeritabani);
    destructor Destroy; override;
    property CommandHistory: specialize TList<TSqlCommand> read FCommandHistory;
    procedure ExecuteSQL(const SQL: string; out Cmd: TSqlCommand);
  end;

implementation

uses
  TypInfo, DateUtils;

  { TSorguSonucu }



  { TSqlEngine }

constructor TSqlEngine.Create(ADatabase: TVeritabani);
begin
  inherited Create;
  FDB := ADatabase;
  FCommandHistory := specialize TList<TSqlCommand>.Create;
end;

destructor TSqlEngine.Destroy;
var
  c: TSqlCommand;
begin
  // her record içindeki TStringList ve TList<TRow>'u serbest bırak
  for c in FCommandHistory do
  begin
    //   c.SatirMesajlari;
    c.Data.Free;
  end;
  FCommandHistory.Free;
  inherited;
end;

function TSqlEngine.SplitTopLevel(const S: string;
  Delim: char): specialize TArray<string>;
var
  inQ: boolean;
  lvl, i, start: integer;
  c: char;
  seg: string;
begin
  inQ := False;
  lvl := 0;
  start := 1;
  for i := 1 to Length(S) do
  begin
    c := S[i];
    if c = '''' then
      inQ := not inQ
    else if not inQ then
    begin
      if c = '(' then Inc(lvl)
      else if c = ')' then Dec(lvl)
      else if (c = Delim) and (lvl = 0) then
      begin
        seg := Trim(Copy(S, start, i - start));
        //Result := Result + [seg];
        SetLength(Result, Length(Result) + 1);
        Result[High(Result)] := seg;

        start := i + 1;
      end;
    end;
  end;
  seg := Trim(Copy(S, start, MaxInt));
  if seg <> '' then
  begin
    // Result := Result + [seg];
    SetLength(Result, Length(Result) + 1);
    Result[High(Result)] := seg;

  end;
end;



// Arada kalan metotlar

function TSqlEngine.Between(const A, StartTok, EndTok: string): string;
var
  p1, p2: integer;
begin
  p1 := Pos(StartTok, A);
  if p1 = 0 then Exit('');
  Inc(p1, Length(StartTok));
  if EndTok = '' then
    p2 := Length(A) + 1
  else
  begin
    p2 := PosEx(EndTok, A, p1);
    if p2 = 0 then p2 := Length(A) + 1;
  end;
  Result := Trim(Copy(A, p1, p2 - p1));
end;

procedure TSqlEngine.SplitBalanced(const List: string;
  out Arr: specialize TArray<string>);
var
  lvl, start, i: integer;
  ch, tmp: char;
begin
  lvl := 0;
  start := 1;
  for i := 1 to Length(List) do
  begin
    ch := List[i];
    if ch = '(' then Inc(lvl)
    else if ch = ')' then Dec(lvl)
    else if (ch = ',') and (lvl = 0) then
    begin
      SetLength(Arr, Length(Arr) + 1);
      Arr[High(Arr)] := Trim(Copy(List, start, i - start));
      start := i + 1;
    end;
  end;
  tmp := #0;
  if start <= Length(List) then
  begin
    SetLength(Arr, Length(Arr) + 1);
    Arr[High(Arr)] := Trim(Copy(List, start, MaxInt));
  end;
  //  Arr := Arr + [Trim(Copy(List, start, MaxInt))];
end;


procedure TSqlEngine.ParseConditions(const CondStr: string;
  out Conds: specialize TArray<TCondition>);
var
  parts: specialize TArray<string>;
  i: integer;
  expr: string;
  op: string;
  c: TCondition;
  sl: TStringList;
begin
  Conds := nil;

  // 1) Böl ve trim
  sl := TStringList.Create;
  try
    sl.Delimiter := ' ';
    sl.StrictDelimiter := False;
    sl.DelimitedText := StringReplace(CondStr, ' AND ', '|', [rfIgnoreCase]);
    parts := sl.DelimitedText.Split(['|']);
  finally
    sl.Free;
  end;

  // 2) Her parçayı operatöre göre ayrıştır
  for i := 0 to High(parts) do
  begin
    expr := Trim(parts[i]);
    if expr = '' then
      Continue;

    // Önemli: önce 2 karakterli operatörler
    for op in ['<=', '>=', '<>'] do
      if Pos(op, expr) > 0 then
        Break;

    // Eğer henüz op bulunmadıysa tek karakterli dene
    if op = '' then
      for op in ['=', '<', '>'] do
        if Pos(op, expr) > 0 then
          Break;

    if op = '' then
      Continue; // operatör yoksa atla

    // kolon, op, değer ataması
    c.Column := Trim(Copy(expr, 1, Pos(op, expr) - 1));
    c.Op := op;
    c.Value := Trim(Copy(expr, Pos(op, expr) + Length(op), MaxInt));

    // diziye ekle
    SetLength(Conds, Length(Conds) + 1);
    Conds[High(Conds)] := c;
  end;
end;

function TSqlEngine.SplitColumnDefs(const ParenList: string):
specialize TArray<TAlanTanimi>;
var
  segments: specialize TArray<string>;
  i: integer;
  rawDef: string;
  def: TAlanTanimi;
  toks: TStringList;
begin
  // 1) Parantez dışı en üst seviye virgüllerle böl
  SplitBalanced(ParenList, segments);

  // 2) Sonuç dizisinin boyutunu ayarla
  SetLength(Result, Length(segments));

  // 3) Her bir tanımı parse et
  for i := 0 to High(segments) do
  begin
    rawDef := segments[i];      // Şimdi rawDef kullanabiliriz

    // Tokenize et (boşluklara göre parçala)
    toks := TStringList.Create;
    try
      ExtractStrings([' '], [], PChar(rawDef), toks);

      // Varsayılan alan tanımı
      def := Default(TAlanTanimi);

      // 1. token = kolon adı, 2. token = tip
      if toks.Count > 0 then
        def.Name := toks[0];
      if toks.Count > 1 then
        def.Tip := StrToAlanTuru(toks[1]);

      // Uzunluk bilgisi (örneğin VARCHAR(50) gibi parantezli tipler
      // için ParenList içinden ayrıştırmak gerekebilir; basit örnek:)
      if (toks.Count > 2) and TryStrToInt(toks[2], def.Length) then
      // uzunluk okundu
      else
        def.Length := AlanBoyutu(def.Tip);

      // Bayraklar: AUTOINCREMENT, PRIMARY KEY, NOT NULL
      rawDef := UpperCase(rawDef);
      def.AutoIncrement := Pos('AUTOINCREMENT', rawDef) > 0;
      def.PrimaryKey := Pos('PRIMARY KEY', rawDef) > 0;
      def.NotNull := Pos('NOT NULL', rawDef) > 0;

      // DEFAULT değeri (varsa)
      if Pos('DEFAULT', rawDef) > 0 then
      begin
        // Between fonksiyonu veya regex ile DEFAULT sonrası değeri alın
        def.DefaultDeger := Trim(Between(rawDef, 'DEFAULT', ''));
      end;

    finally
      toks.Free;
    end;

    Result[i] := def;
  end;
end;




function TSqlEngine.SplitColumnDefs2(const ParenList: string):
specialize TArray<TAlanTanimi>;
var
  i, lvl, start: integer;
  ch: char;
  segs: specialize TArray<string>;
  raw: string;
  rec: TAlanTanimi;
  toks: TStringList;
begin
  // 1) Parantez dengeli virgül bölme → segs[]
  lvl := 0;
  start := 1;
  for i := 1 to Length(ParenList) do
  begin
    ch := ParenList[i];
    if ch = '(' then Inc(lvl)
    else if ch = ')' then Dec(lvl)
    else if (ch = ',') and (lvl = 0) then
    begin
      raw := Trim(Copy(ParenList, start, i - start));
      SetLength(segs, Length(segs) + 1);
      segs[High(segs)] := raw;
      start := i + 1;
    end;
  end;
  raw := Trim(Copy(ParenList, start, MaxInt));
  if raw <> '' then
  begin
    SetLength(segs, Length(segs) + 1);
    segs[High(segs)] := raw;
  end;

  // 2) Her bir satırı parse edip TAlanTanimi dizisine ekle
  SetLength(Result, Length(segs));
  for i := 0 to High(segs) do
  begin
    toks := TStringList.Create;

    // ParseColumnDef: sizin mevcut ParseCreateTable içinde kullandığınız kod parçası
    // Örneğin:
    //   rec.Name        := …
    //   rec.Tip         := StrToAlanTuru(…)
    //   rec.Length      := AlanBoyutu(rec.Tip)
    //   rec.PrimaryKey  := …
    //   rec.AutoIncrement := …
    //   rec.NotNull     := …
    //   rec.DefaultDeger:= …
    rec := Default(TAlanTanimi);

    // basit tokenize ve atama; orijinal ParseCreateTable’dan alın
    //with TStringList.Create do
    try
      ExtractStrings([' '], [], PChar(segs[i]), toks);
      rec.Name := toks[0];
      // Parantezli tip (VARCHAR(50)) vs.
      // … kendi kodunuza uygun devam
      rec.Tip := StrToAlanTuru(toks[1]);
      // length flag default vs…
      // Örnek:
      if (toks.Count > 2) and TryStrToInt(toks[2], rec.Length) then
      // uzunluk ayarlandı
      else
        rec.Length := AlanBoyutu(rec.Tip);

      //  rec.Length := IfThen(rec.Tip = ftText, 255, AlanBoyutu(rec.Tip));
    finally
      toks.Free;
    end;

    Result[i] := rec;
  end;
end;

function TSqlEngine.SplitStatements(const SQL: string): specialize TArray<string>;
var
  inQ: boolean;
  lvl, i, startIdx: integer;
  c: char;
  stmt: string;
begin
  inQ := False;
  lvl := 0;
  startIdx := 1;
  SetLength(Result, 0);

  for i := 1 to Length(SQL) do
  begin
    c := SQL[i];
    if c = '''' then
      inQ := not inQ
    else if not inQ then
    begin
      if c = '(' then Inc(lvl)
      else if c = ')' then Dec(lvl)
      else if (c = ';') and (lvl = 0) then
      begin
        stmt := Trim(Copy(SQL, startIdx, i - startIdx));
        if stmt <> '' then
        begin
          SetLength(Result, Length(Result) + 1);
          Result[High(Result)] := stmt;
        end;
        startIdx := i + 1;
      end;
    end;
  end;

  // Son parça
  stmt := Trim(Copy(SQL, startIdx, MaxInt));
  if stmt <> '' then
  begin
    SetLength(Result, Length(Result) + 1);
    Result[High(Result)] := stmt;
  end;
end;

function TSqlEngine.ExtractParenContent(const S: string; StartPos: integer;
  out Content: string; out EndPos: integer): boolean;
var
  lvl, i: integer;
begin
  lvl := 0;
  for i := StartPos to Length(S) do
  begin
    if S[i] = '(' then
      Inc(lvl)
    else if S[i] = ')' then
    begin
      Dec(lvl);
      if lvl = 0 then
      begin
        Content := Copy(S, StartPos + 1, i - StartPos - 1);
        EndPos := i;
        Exit(True);
      end;
    end;
  end;
  Result := False;
end;


procedure TSqlEngine.ParseInsertParts(const SQL: string; out Tbl: string;
  out Cols, Vals: specialize TArray<string>);
var
  upSQL: string;
  pIns, pVals: integer;
  open1, close1, open2, close2: integer;
  colsText, valsText: string;
  tmp: specialize TArray<string>;
  j: integer;
begin
  upSQL := UpperCase(SQL);

  // 1) Tablo adını al
  pIns := PosEx('INSERT INTO', upSQL) + Length('INSERT INTO');
  // sonrasındaki boşlukları atla
  while (pIns <= Length(SQL)) and (SQL[pIns] = ' ') do Inc(pIns);
  // ilk '('
  open1 := PosEx('(', SQL, pIns);
  Tbl := Trim(Copy(SQL, pIns, open1 - pIns));

  // 2) Sütun listesini çıkar
  if not ExtractParenContent(SQL, open1, colsText, close1) then
    raise Exception.Create('Kolon listesi parantez hatası');
  Cols := SplitTopLevel(colsText, ',');
  // DEBUG:
  //Writeln('colsText: '+colsText);
  // for j := 0 to High(Cols) do
  //  Writeln(Format('  Col[%d]=%s',[j,Cols[j]]));

  // 3) VALUES parantezi için aramayı close1+1’den başlat
  pVals := PosEx('VALUES', upSQL, close1) + Length('VALUES');
  open2 := PosEx('(', SQL, pVals);

  // 4) Değer listesini çıkar
  if not ExtractParenContent(SQL, open2, valsText, close2) then
    raise Exception.Create('Values listesi parantez hatası');
  // DEBUG:
  //Writeln('valsText: '+valsText);

  // 5) Sadece valsText’i böl
  tmp := SplitTopLevel(valsText, ',');
  Vals := tmp;  // kesinlikle eski ParenList’i kullanma

  // DEBUG:
  //Writeln(Format('SplitTopLevel(valsText) len=%d',[Length(tmp)]));
  //for j := 0 to High(tmp) do
  //  Writeln(Format('  Val[%d]=%s',[j,tmp[j]]));
end;

{var
  up: string;
  p1, p2: Integer;
  colsText, valsText: string;
  j:Integer;
begin
  up := UpperCase(SQL);

  // 1) Tablo adını al
  p1 := Pos('INSERT INTO ', up) + Length('INSERT INTO ');
  while (p1 <= Length(SQL)) and (SQL[p1] = ' ') do Inc(p1);
  p2 := PosEx('(', SQL, p1);
  Tbl := Trim(Copy(SQL, p1, p2-p1));

  // 2) Sütun listesini parantezlerden çıkar
  if not ExtractParenContent(SQL, p2, colsText, p2) then
    raise Exception.Create('Kolon listesi parantez hatası');
  Cols := SplitTopLevel(colsText, ',');

  // debug
  //Writeln('colsText: '+colsText);

  // 3) VALUES parantezini bulup içeriği çıkar
  p1 := PosEx('VALUES', up, p2) + Length('VALUES');
  p2 := PosEx('(', SQL, p1);
  if not ExtractParenContent(SQL, p2, valsText, p2) then
    raise Exception.Create('VALUES listesi parantez hatası');
  Vals := SplitTopLevel(valsText, ',');

  // debug
 // Writeln('valsText: '+valsText);

  for j := 0 to High(Vals) do
  begin
   Writeln(Format('  Col[%d] = "%s"',[j,Cols[j]]));
   Writeln(Format('  Val[%d] = "%s"',[j,Vals[j]]));
  end;
end; }




// Komut parse edip CmdType/table/args doldurur

function TSqlEngine.ParseCommand(const SQL: string; out Cmd: TSqlCommand): boolean;
var
  up: string;
  selPart: string;
begin
  Cmd.CmdType := ctUnknown;
  up := UpperCase(Trim(SQL));

  if StartsText('CREATE DATABASE ', up) then
  begin
    Cmd.CmdType := ctCreateDatabase;
    Cmd.DatabaseName := Between(SQL, 'CREATE DATABASE ', '');
  end
  else if StartsText('DROP TABLE ', up) then
  begin
    Cmd.CmdType := ctDropTable;
    Cmd.TableName := Between(SQL, 'DROP TABLE ', '');
  end
  else if StartsText('CREATE TABLE ', up) then
  begin
    Cmd.CmdType := ctCreateTable;
    Cmd.TableName := Between(SQL, 'CREATE TABLE ', '(');
    Cmd.ColumnsDef := SplitColumnDefs(Between(SQL, '(', ')'));
  end
  else if StartsText('ALTER TABLE ', up) then
  begin
    Cmd.CmdType := ctAlterTable;
    Cmd.TableName := Between(SQL, 'ALTER TABLE ', ' ADD ');
    Cmd.ColumnsDef := SplitColumnDefs(Between(SQL, 'ADD ', ''));
  end
  else if StartsText('SHOW TABLE ', up) then
  begin
    Cmd.CmdType := ctShowTable;
    Cmd.TableName := Between(SQL, 'SHOW TABLE ', '');
  end
  else if StartsText('INSERT INTO ', up) then
  begin
    Cmd.CmdType := ctInsert;
   { Cmd.TableName := Between(SQL, 'INSERT INTO ', '(');
    Cmd.InsertCols   := SplitString(Between(SQL, '(', ')'), ',');
    Cmd.InsertValues := SplitString(Between(SQL, 'VALUES(', ')'), ',');  }
    ParseInsertParts(SQL, Cmd.TableName, Cmd.InsertCols, Cmd.InsertValues);

  end
  else if StartsText('SELECT ', up) then
  begin
    Cmd.CmdType := ctSelect;
    selPart := Between(SQL, 'SELECT ', 'FROM ');
    SplitBalanced(selPart, Cmd.SelectCols);
    Cmd.TableName := Between(SQL, 'FROM ', 'WHERE ');
    ParseConditions(Between(SQL, 'WHERE ', 'ORDER BY'), Cmd.Conditions);
  end;

  Result := Cmd.CmdType <> ctUnknown;
end;



// Ana iş akışı
procedure TSqlEngine.ExecuteSQLsingle(const SQL: string; out Cmd: TSqlCommand);
var
  startTime: TDateTime;
  dbName, colDef: string;
  colDefs, cols, vals: specialize TArray<string>;
  conds: specialize TArray<TCondition>;
  i: integer;
  schema: TTabloSchema;
  //  SRG:TSorguSonucu;
  row: TRow;
  def: TAlanTanimi;
begin
  Cmd := Default(TSqlCommand);
  Cmd.OriginalSQL := SQL;
  Cmd.ResultRows := specialize TList<TRow>.Create;

  //AppendMessage(Cmd.SatirMesajlari, 'Parse başlıyor: ' + Stmt);

  startTime := Now;
  try
    if not ParseCommand(SQL, Cmd) then
      raise Exception.Create('Parser hatası: ' + SQL);

    case Cmd.CmdType of
      ctCreateDatabase:
      begin
        Cmd.SorguTipi := 'CREATE DATABASE';
        FDB.CreateDatabase(Cmd.DatabaseName);
        Cmd.Basarili := True;
      end;

      ctDropTable:
      begin
        Cmd.SorguTipi := 'DROP TABLE';
        FDB.DropTable(Cmd.TableName);
        Cmd.Basarili := True;
      end;

      ctCreateTable:
      begin
        Cmd.SorguTipi := 'CREATE TABLE';
        schema := TTabloSchema.Create(Cmd.TableName);
        for i := 0 to High(Cmd.ColumnsDef) do
          schema.AlanEkleDetayli(Cmd.ColumnsDef[i]);
        FDB.RegisterTableSchema(Cmd.TableName, schema);
        Cmd.Basarili := True;
      end;

      ctAlterTable:
      begin
        Cmd.SorguTipi := 'ALTER TABLE';
        // ilk tanım kolon, geri kalanlar opsiyonel
        FDB.AlterTableAddColumn(Cmd.TableName, Cmd.ColumnsDef[0]);
        Cmd.Basarili := True;
      end;

      ctShowTable:
      begin
        Cmd.SorguTipi := 'SHOW TABLE';
        schema := FDB.GetTableSchema(Cmd.TableName);
        for i := 0 to schema.AlanSayisi - 1 do
        begin
          row := TRow.Create;
          def := schema.Alanlar[i];
          row.Add('Name', def.Name);
          row.Add('Type', GetEnumName(TypeInfo(TAlanTuru), Ord(def.Tip)));
          row.Add('Length', def.Length);
          Cmd.ResultRows.Add(row);
        end;
        Cmd.Basarili := True;
      end;

      ctInsert:
      begin
        Cmd.SorguTipi := 'INSERT';
        FDB.InsertInto(Cmd.TableName, Cmd.InsertCols, Cmd.InsertValues);
        // ExecuteSQL içinde
        if Length(Cmd.InsertCols) <> Length(Cmd.InsertValues) then
          raise Exception.CreateFmt(
            'Kolon sayısı %d, değer sayısı %d uyumsuz!',
            [Length(Cmd.InsertCols), Length(Cmd.InsertValues)]);
        Cmd.Basarili := True;
      end;

      ctSelect:
      begin
        Cmd.SorguTipi := 'SELECT';
        // klon şema + satırlar
        Cmd.Schema := FDB.GetTableSchema(Cmd.TableName);
        Cmd.Data := FDB.SelectFrom(Cmd.TableName, Cmd.SelectCols,
          Cmd.Conditions, '');
        Cmd.Basarili := True;
      end;
    end;

  except
    on E: Exception do
    begin
      Cmd.Basarili := False;
      Cmd.HataMesaji := E.Message;
    end;
  end;

 { Cmd.Sure := Now - startTime;
  SetLength(Cmd.SatirMesajlari, Length(Cmd.SatirMesajlari) + 1);
  Cmd.SatirMesajlari[High(Cmd.SatirMesajlari)] := ('Süre: ' + FormatDateTime('ss.zzz', Cmd.Sure));
  }Cmd.Sure := Now - Cmd.Sure;
  AppendMessage(Cmd.SatirMesajlari,
    Format('Süre: %0:.3f sn', [MilliSecondsBetween(Now, Now - Cmd.Sure) / 1000]));
  Cmd.Basarili := Cmd.HataMesaji = '';
end;

procedure TSqlEngine.ExecuteSQL(const SQL: string; out Cmd: TSqlCommand);
var
  stmts: specialize TArray<string>;
  i: integer;
  singleCmd: TSqlCommand;
begin
  // 1) Geçmişi temizle
  for singleCmd in FCommandHistory do
  begin
    //  singleCmd.SatirMesajlari.Free;
    singleCmd.Data.Free;
  end;
  FCommandHistory.Clear;

  // 2) SQL’i parçalara böl ve çalıştır
  stmts := SplitStatements(SQL);
  for i := 0 to High(stmts) do
  begin
    ExecuteSQLSingle(stmts[i], singleCmd);
    FCommandHistory.Add(singleCmd);
  end;

  // 3) out parametreye son sonucu ver
  if FCommandHistory.Count > 0 then
    Cmd := FCommandHistory.Last
  else
    Cmd := Default(TSqlCommand);
end;

end.
