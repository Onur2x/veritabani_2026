# 03 — API / DLL Katmanı

> Kaynak: `vdbapi_core.pas` (1754 satır / 50074 byte), `vdbapi.h` (220 satır /
> 11453 byte), `vdbapi.lpr` (352 satır / 11380 byte),
> `VDBClient.pas` (926 satır / 30326 byte),
> `DLL_KULLANIM.md`, `build_dll.ps1` (2392 byte). Salt okuma.
> **Tazeleme: 06.10.2026** — otomatik-WAL (3) ve şifreleme (9) export'u
> eklendi; ayrıca **CDC / Time Travel poll export'u (7)** eklendi ve ABI
> **1.0 → 1.1** oldu; toplam **54 export**. `vdbapi.h`'ye bu tazelemede
> **eksik kalmış `VdbEncrypt*` bildirimleri** de eklendi (export'lar
> 2026-10-05'te açılmıştı, başlık unutulmuştu). Ayrıca
> `lazbuild vdbapi.lpi` bu makinede **.exe** üretir (LibraryType bayrağı
> yok sayılır); geçerli DLL yalnız `build_dll.ps1` ile üretilir
> (`vdbapi.dll`, 1251328 byte, 32-bit x86).

## Neden DLL?

Motor FPC ile yazıldı; Delphi derleyicisi FPC `.ppu` dosyalarını bağlayamaz.
Tek yol C ABI sunan bir DLL'dir (`vdbapi.dll`, 1251328 byte, 32-bit x86, `stdcall`).

## Katmanlar

```
Motor (VDbCore/Table/Sql + VDbCdc/VDbTimeTravel)
  -> vdbapi_core.pas (gerçek mantık, 54 export fonksiyon)
  -> vdbapi.lpr (ince sarmalayıcı: FPC `exports` kısıtı yüzünden her API için 1 satırlık wrapper + exports listesi)
  -> vdbapi.dll
  -> vdbapi.h (C/C#/Python/Rust başlığı) | VDBClient.pas (Delphi istemcisi)
```

## Tasarım kuralları (değiştirilmemeli)

1. Hiçbir istisna DLL sınırını geçmez (`try/except` + hata kodu + son-hata metni).
2. Metinler UTF-8, NUL-sonlu.
3. Handle `0` daima hata; bozuk handle crash değil hata kodudur (`VDB_E_BAD_HANDLE`).
4. Sonuç tamponu **bir sonraki çağrıya kadar** geçerli; iki işaretçi aynı anda tutulmaz.
5. Bellek sahipliği DLL'dedir; çağıran yalnız kendi buffer'ını yönetir (`ResultFree` sonuç handle'ını kapatır).
6. Aynı DB dosyası aynı anda tek işlem tarafından açılır.

## Hata kodları

| Kod | Ad | Anlam |
|---|---|---|
| `0` | `VDB_OK` | Başarı |
| `-1` | `VDB_E_GENERAL` | Sınıflandırılmamış |
| `-2` | `VDB_E_BAD_HANDLE` | Geçersiz handle |
| `-3` | `VDB_E_OPEN` | Açılamadı (kilitli vb.) |
| `-4` | `VDB_E_SQL` | SQL hatası (`VdbLastError` ayrıntı) |
| `-5` | `VDB_E_READONLY` | Yazma desteklenmiyor |
| `-6` | `VDB_E_BUFFER` | Tampon küçük (gerekli boyut negatif döner) |
| `-7` | `VDB_E_RANGE` | İndis sınır dışı |
| `-8` | `VDB_E_ENGINE` | Motor hatası |
| `-9` | `VDB_E_NOT_FOUND` | Anahtar/tablo yok |
| `-10` | `VDB_E_DUPLICATE` | UNIQUE/PK ihlali |
| `-11` | `VDB_E_CONSTRAINT` | FK/CHECK/NOT NULL ihlali |

`VDB_API_VERSION = $00010100 (1.1)`, `VDB_SQL_AUTOTXN = $0001`.
(Geriye uyumlu ekleme kuralı: minor arttı, `VDBClient.pas` ve
`vdbapitest.lpr` aynı sürümü bekler — uyuşmazlık `VdbOpen`'den önce hata
verir.)

## Fonksiyon listesi (54 export)

- Sürüm/hata: `VdbApiVersion, VdbVersion, VdbLastError, VdbLastErrorCodeGet, VdbSetLastErrorCode`
- Aç/kapa: `VdbOpen(APath,ASyncWrite)->handle, VdbClose, VdbCloseAll`
- KV: `VdbCount, VdbPut, VdbGet, VdbExists, VdbDelete, VdbKeys, VdbFlush`
- SQL/sonuç: `VdbExec->result, VdbResultFieldCount/RowCount/FieldName/Value/Affected/Stmts/Message/LastTable/ResultFree`
- Bakım/WAL: `VdbVerify, VdbWalHas, VdbWalRecordCount, VdbWalWrite, VdbWalWriteDelete, VdbWalReplay, VdbWalCheckpoint, VdbFileSize, VdbDeadBytes, VdbAutoCompact`
- **Otomatik WAL (2026-10-04):** `VdbWalSetAuto(h,0|1), VdbWalIsAuto(h), VdbWalAutoCount(h)`
- **Şifreleme (2026-10-05):** `VdbEncryptEnable(h,key,len), VdbEncryptDisable, VdbEncryptIsEncrypted, VdbEncryptCreateKeyFile(h,path,pass), VdbEncryptOpenKeyFile, VdbEncryptKeyPath, VdbEncryptFingerprint, VdbHasEncryptedRecords, VdbRekeyWithPassword`
- **CDC / Time Travel — poll (2026-10-06):** `VdbCdcStart(h), VdbCdcStop(h), VdbCdcPollSize(h), VdbCdcPoll(h,buf,len), VdbCdcStats(h,ev,skip,pend,drop), VdbValueAt(h,tbl,pk,seq,buf,len), VdbHistoryCount(h)`

### CDC / Time Travel (poll) — yeni (2026-10-06)

Callback DLL sınırını geçmez; istemci olayları **çekerek** alır (poll):

```
VdbCdcStart(h)            otomatik WAL açılır, ~50ms'de bir WAL taranır
n = VdbCdcPollSize(h)     >0 olay boyutu / 0 = olay yok / <0 hata
VdbCdcPoll(h, buf, n)     kopyalar VE tüketti (>0 boyut, 0 yok,
                           VDB_E_BUFFER = tampon küçük, olay KALIR)
VdbCdcStop(h)             durdurur; tampondaki olaylar KALIR (drain edilir)
VdbCdcStats(h, ...)       ev/skip/pend/drop sayacı (NULL olan yazılmaz)
```

Paket (UTF-8, NUL'suz, alan ayracı `#30` = RS):

```
kind #30 seq #30 table #30 pk #30 oldJson #30 newJson
kind: 0=insert, 1=update, 2=delete   json: kolon değerleri dizisi
```

- `seq` = CDC olay sıra numarası (WAL'de alan olarak **yoktur**; DLL'de
  üretildi). Zaman damgası pakette **yoktur** — istemci kendi UTC
  epoch-ms damgasını ekler (`TCDCEvent.Timestamp` DLL sınırında bilinçli
  olarak kaybolur).
- **Tek istemci varsayılır**: aynı anda iki `VdbCdcPoll` çağrılmaz.
- Tampon sınırı: `TVDbCdc.MaxPending` = 100000; taşarsa en eski olay
  düşer ve `VdbCdcStats`'in `dropped` sayacı artar (sessiz kayıp yok).
- `VdbClose`, CDC nesnesini thread'iyle birlikte serbest bırakır
  (çalışırken kapatmak güvenlidir).

`VdbValueAt(h, tbl, pk, seq, buf, len)` — **Time Travel**: WAL geçmişinde
`seq` indeksine (0 tabanlı, dahil) kadar satırın **son değeri**, JSON
dizisi olarak. `VdbGet` sözleşmesi: `len=0` → `-gerekli boyut`;
yetersiz tampon → `-n` (dokunulmaz); yeterli → kopyalanan bayt;
**o noktada satir yok → `-1`** (silinmiş/hic yazılmamış). `seq >=
WalRecordCount` son kayda kırpılır; geçmiş yalnızca **son checkpoint'ten
beriyi** kapsar (`VdbHistoryCount`, 0 dönebilir).

Notlar: `VdbGet` iki aşamalı çağrılır (`need = VdbGet(h,key,NULL,0)` ile boyut öğrenilir).
WAL opt-in'dir: `WalWrite` tek başına yazmaz; `WalReplay/Checkpoint` yazar.
**Dönüş sözleşmesi iki türlüdür:** genel API'de **`0 = başarı`** ve negatif
hata kodudur; buna karşılık **`VdbEncrypt*` / `VdbRekeyWithPassword`
işlevlerinde `1 = başarılı, 0 = başarısız`** döner (bazıları zaten 1/0
döndüren `VdbExists`/`VdbVerify` gibi). `VDBClient` sarmalayıcıları bu
işlevler için `Check()` kullanmaz.

## Delphi istemcisi (`VDBClient.pas`)

- `DLL_NAME='vdbapi.dll'`, proje **Win32** olmalı, DLL exe yanında (veya PATH'te) olmalı.
- `TVDb.Open(...).SQL(...).Query` akışı; `EVDbApiError(Code)` istisnası.
- `TVDb`: `Put/PutBytes/GetStr/GetBytes/Exists/DeleteKey/Flush, SQL, Verify, AutoCompact, HasWAL, WalWrite/WalWriteDelete/WalReplay/WalCheckpoint, Size/DeadBytes/Count`,
  + **şifreleme bölümü**: `SetEncryptKey, ClearEncryptKey, CreateKeyFile, OpenKeyFile, KeyPath, Fingerprint, HasEncryptedRecords, RekeyWithPassword, IsEncrypted` (hepsi `1=başarı` sözleşmesini `Check()`'siz ele alır).
  + **CDC/TimeTravel bölümü (2026-10-06)**: `CdcStart, CdcStop,
    CdcPollSize, CdcPoll(out APacket): Boolean, CdcStats(out ...),
    ValueAt(tbl,pk,seq,out AJson): Boolean, HistoryCount`.
    Sarmalayıcı iki aşamayı ve `VdbGet`-tipi dönüş sözleşmesini yutar:
    `CdcPoll` olay yokken `False` (hata değil), hata kodları
    `EVDbApiError` fırlatır; `ValueAt` yalınca `True/False` döner.

## Test / demo / hız programları

| Dosya | Boyut | Amaç |
|---|---|---|
| `vdbapitest.lpr` / `.exe` (38377 / 250368) | DLL'yi `LoadLibrary+GetProcAddress` ile dinamik yükleyip **9 grupta** (sürüm/açılış/KV/UTF-8/SQL/bakım/WAL/şifreleme/**CDC+TimeTravel**) gerçek harici-program davranışını test eder — **170/170** (42 export çözüldü) |
| `vdbclienttest.lpr` / `.exe` (18121 / 248832) | `VDBClient` sarmalayıcı katman testi, şifreleme + CDC/TimeTravel grupları dahil — **101/101** |
| `vdbclientdemo.lpr` (5202; exe bu makinede derlenmemiş) | `VDBClient` ile çalışan örnek (tablo kur + INSERT + SELECT + hata yolları + Verify) |
| `vdbspeed.lpr` (8428; exe bu makinede derlenmemiş) | 4 ölçüm: saf DLL çağrı maliyeti, KV DLL-vs-direkt, istemci sarmalayıcı, büyük SELECT ölçeklenmesi |
| `build_dll.ps1` (2392) | DLL'yi 32-bit `i386-win32` derleyen betik (`ppc386.exe` doğrudan, yol: `C:\lazarus\fpc\3.2.4\bin\i386-win32\ppc386.exe`; `-Mdelphi` bilinçli verilmez) |

Ayrıntı için `DLL_KULLANIM.md` (kullanıcı kılavuzu) geçerlidir.
