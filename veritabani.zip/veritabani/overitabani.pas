unit oVeritabani;

{$mode ObjFPC}{$H+}

interface

uses
  SysUtils, Classes, Variants, Generics.Collections,
  fpjson, jsonparser,oTypes, oTabloSchema,zstream;

type
  TTabloDict = specialize TDictionary<string, TTabloSchema>;
  TVeriDict  = specialize TDictionary<string, TTabloDict>;

  TRowFilter = function(Row: TRow): Boolean of object;
  TRowUpdater = procedure(Row: TRow) of object;

  TVeritabani = class
  private
    FDosyaAdi: string;
    FSchemaDict: specialize TDictionary<string, TTabloDict>; // DB → Şemalar
    FDataDict: specialize TDictionary<string, specialize TDictionary<string, TRowList>>; // DB → Tablo → Satırlar
    FIdentity: specialize TDictionary<string, Int64>;
    procedure ClearAll;



    procedure ReplaceTableRows(const dbName,tableName:string;newRows:TRowList);

//    procedure ReplaceTableRows(const dbName,tableName:string;newRows:TRowList);

  public
    constructor Create;
    destructor Destroy; override;

    function SonId(const DBName:string):Int64;
    procedure YukleDosya(const DosyaYolu:string);

    function GetTableSchema(const DBName, TableName: string): TTabloSchema;
    function GetDataTable(const DBName, TableName: string): TRowList;
    function MatchesCondition(const Row: TRow; const Cond: TCondition): Boolean;

    procedure CreateEmptyDatabase(const DBName:string);
    procedure CreateDatabase(const AName: string);
    procedure InsertRow(const dbName,tblName:string;row:TRow);

    procedure AddEmptyTable(const DBName,TableName:string);
    procedure CreateTable(const DBName, TableName: string; Schema: TTabloSchema);
    procedure DropTable(const DBName, TableName: string);
    function GetFieldType(const DBName,TableName,AlanAdi:string):TAlanTuru;

    procedure AddOrReplaceTable(const DBName,TableName:string;const Schema:
      TTabloSchema;const Rows:TRowList);

    procedure InsertInto(const DBName, TableName: string;
      const Columns, Values: specialize TArray<string>);


    function SelectFrom(const DBName,TableName:string;const Columns:specialize
      TArray<string>;const Conditions:specialize TArray<TCondition>;const
      OrderBy:string;const GroupBy:string;const Having:specialize TArray<
      TCondition>;const Limit,Offset:Integer):TRowList;


    procedure UpdateRows(const DBName, TableName: string;
      Filter: TRowFilter; Updater: TRowUpdater);

    procedure DeleteRows(const DBName, TableName: string;
      Filter: TRowFilter);

   { function BuildFullJSON: TJSONObject;
    procedure LoadTableFromJSON(const tblObj: TJSONObject);
    function BuildODBPackage: TJSONObject;
    procedure LoadODBPackage(json:TJSONObject);

    procedure SaveToFile(const FileName: string);
    procedure LoadFromFile(const FileName: string); }

    function GetDatabaseNames: TStringList;
    function GetTableNames(const DBName: string): TStringList;

    procedure LoadODBPackage(const PackageYolu:string);
    procedure SaveAsODB(const PackageYolu:string);

    property DosyaAdi: string read FDosyaAdi write FDosyaAdi;
    property DataDict: specialize TDictionary<string, specialize TDictionary<string, TRowList>> read FDataDict;


  end;

  type
  TRowComparer = class
  private
    FColumn: string;
  public
    constructor Create(const Col: string);
    function Compare(const A, B: TRow): Integer;
  end;

implementation


constructor TRowComparer.Create(const Col: string);
begin
  FColumn := Col;
end;

function TRowComparer.Compare(const A, B: TRow): Integer;
begin
  Result := CompareText(VarToStr(A[FColumn]), VarToStr(B[FColumn]));
end;

{ TVeritabani }
function CompareTRowByColumn(const A, B: TRow; const ColumnName: string): Integer;
begin
  Result := CompareText(VarToStr(A[ColumnName]), VarToStr(B[ColumnName]));
end;

procedure SortRowsByColumn(const Rows: TRowList; const ColumnName: string);
var
  i, j: Integer;
begin
  for i := 0 to Rows.Count - 2 do
    for j := i + 1 to Rows.Count - 1 do
      if CompareTRowByColumn(Rows[i], Rows[j], ColumnName) > 0 then
      begin
        Rows.Exchange(i, j);
      end;
end;

function AlanOlustur(const Ad, TipStr: string; PK: Boolean = False; AutoInc: Boolean = False): TAlanTanimi;
begin
  Result.Name := Ad;
  Result.Tip := StrToAlanTuru(TipStr);
  Result.Length := AlanVarsayilanUzunluk(Result.Tip);
  Result.PrimaryKey := PK;
  Result.AutoIncrement := AutoInc;
end;



constructor TVeritabani.Create;
begin
  inherited Create;

  FDataDict := specialize TDictionary<string, specialize TDictionary<string, TRowList>>.Create;
  FSchemaDict := specialize TDictionary<string, specialize TDictionary<string, TTabloSchema>>.Create;
  FIdentity := specialize TDictionary<string, Int64>.Create;
end;



destructor TVeritabani.Destroy;
var
  dbName: string;
  schemaTbl: TTabloDict;
  dataTbls : specialize TDictionary<string, TRowList>;
  schema:TTabloSchema;
  lst:TRowList;
begin
  for dbName in FSchemaDict.Keys do
    if FSchemaDict.TryGetValue(dbName, schemaTbl) then
    begin
      for schema in schemaTbl.Values do schema.Free;
      schemaTbl.Free;
    end;
  FSchemaDict.Free;

  for dbName in FDataDict.Keys do
    if FDataDict.TryGetValue(dbName, dataTbls) then
    begin
      for lst in dataTbls.Values do lst.Free;
      dataTbls.Free;
    end;
  FDataDict.Free;

  FIdentity.Free;
  inherited;
end;


function TVeritabani.GetFieldType(const DBName, TableName, AlanAdi: string): TAlanTuru;
var
  schema: TTabloSchema;
begin
  schema := GetTableSchema(DBName, TableName);
  Result := schema.AlanTipi(AlanAdi);//  GetAlanTuru(AlanAdi);
end;


procedure TVeritabani.ClearAll;
var
  db: string;
  tableDict: specialize TDictionary<string, TRowList>;
  table: string;
begin
  for db in FDataDict.Keys.ToArray do
  begin
    tableDict := FDataDict[db];
    for table in tableDict.Keys.ToArray do
    begin
      tableDict[table].Free;
    end;
    tableDict.Free;
  end;
  FDataDict.Clear;

  for db in FSchemaDict.Keys.ToArray do
  begin
    FSchemaDict[db].Clear;
  end;

  FIdentity.Clear;
end;

procedure TVeritabani.InsertRow(const dbName, tblName: string; row: TRow);
var
  tabDict: specialize TDictionary<string, TRowList>;
begin
  if not FDataDict.ContainsKey(dbName) then Exit;
  tabDict := FDataDict[dbName]; // tip dönüşümü burada
  if not tabDict.ContainsKey(tblName) then Exit;

  {begin
  if not FDataDict.ContainsKey(dbName) then Exit;
  if not FDataDict[dbName].ContainsKey(tblName) then Exit;
  }
  tabDict[tblName].Add(row);
end;


procedure TVeritabani.CreateEmptyDatabase(const DBName: string);
begin
  if FDataDict.ContainsKey(DBName) then
    FDataDict[DBName].Clear
  else
    FDataDict.Add(DBName, specialize TDictionary<string, TRowList>.Create);

  if FSchemaDict.ContainsKey(DBName) then
    FSchemaDict[DBName].Clear
  else
    FSchemaDict.Add(DBName, TTabloDict.Create);

  FIdentity.AddOrSetValue(DBName, 0);
  FDosyaAdi := Format('%s.odb', [DBName]);

 // AddEmptyTable(DBName,'Urunler');
end;





procedure TVeritabani.CreateDatabase(const AName: string);
var
  schemaTbl: TTabloDict;
  dataTbls : specialize TDictionary<string, TRowList>;
  schema:TTabloSchema;
  lst:TRowList;
begin
  if FSchemaDict.TryGetValue(AName, schemaTbl) then
  begin
    for schema in schemaTbl.Values do schema.Free;
    schemaTbl.Free;
    FSchemaDict.Remove(AName);
  end;

  if FDataDict.TryGetValue(AName, dataTbls) then
  begin
    for lst in dataTbls.Values do lst.Free;
    dataTbls.Free;
    FDataDict.Remove(AName);
  end;
end;




procedure TVeritabani.AddOrReplaceTable(
  const DBName, TableName: string;
  const Schema: TTabloSchema;
  const Rows: TRowList);
begin
  if not FDataDict.ContainsKey(DBName) then
    FDataDict.Add(DBName, specialize TDictionary<string, TRowList>.Create);

  FDataDict[DBName].AddOrSetValue(TableName, Rows);

  if not FSchemaDict.ContainsKey(DBName) then
    FSchemaDict.Add(DBName, TTabloDict.Create);

  FSchemaDict[DBName].AddOrSetValue(TableName, Schema);
end;


procedure TVeritabani.AddEmptyTable(const DBName, TableName: string);
var
  schema: TTabloSchema;
begin
  schema := TTabloSchema.Create(TableName);
  schema.AlanEkleDetayli(AlanOlustur('ID', 'Integer', True, True));
  schema.AlanEkleDetayli(AlanOlustur('Adi', 'Text'));
  schema.AlanEkleDetayli(AlanOlustur('Fiyat', 'Float'));

  AddOrReplaceTable(DBName, TableName, schema, TRowList.Create);
end;

function TVeritabani.SonId(const DBName: string): Int64;
begin
  if not FIdentity.ContainsKey(DBName) then
    Result := 0
  else
    Result := FIdentity[DBName];
end;


procedure TVeritabani.DropTable(const DBName, TableName: string);
var
  schemaTbl: TTabloDict;
  dataTbls : specialize TDictionary<string, TRowList>;
begin
  if FSchemaDict.TryGetValue(DBName, schemaTbl) then
    if schemaTbl.ContainsKey(TableName) then
    begin
      schemaTbl[TableName].Free;
      schemaTbl.Remove(TableName);
    end;

  if FDataDict.TryGetValue(DBName, dataTbls) then
    if dataTbls.ContainsKey(TableName) then
    begin
      dataTbls[TableName].Free;
      dataTbls.Remove(TableName);
    end;
end;

procedure TVeritabani.CreateTable(const DBName, TableName: string; Schema: TTabloSchema);
var
  schemaTbl: TTabloDict;
  dataTbls : specialize TDictionary<string, TRowList>;
begin
  DropTable(DBName, TableName);

  if not FSchemaDict.TryGetValue(DBName, schemaTbl) then
  begin
    schemaTbl := TTabloDict.Create;
    FSchemaDict.Add(DBName, schemaTbl);
  end;
  schemaTbl.Add(TableName, Schema);

  if not FDataDict.TryGetValue(DBName, dataTbls) then
  begin
    dataTbls := specialize TDictionary<string, TRowList>.Create;
    FDataDict.Add(DBName, dataTbls);
  end;
  dataTbls.Add(TableName, TRowList.Create);
end;

function TVeritabani.GetTableSchema(const DBName, TableName: string): TTabloSchema;
var
  schemaTbl: TTabloDict;
begin
  if FSchemaDict.TryGetValue(DBName, schemaTbl) then
    if schemaTbl.TryGetValue(TableName, Result) then
      Exit;
  Result := nil;
end;

function TVeritabani.GetDataTable(const DBName, TableName: string): TRowList;
var
  dataTbls: specialize TDictionary<string, TRowList>;
begin
  if FDataDict.TryGetValue(DBName, dataTbls) then
    if dataTbls.TryGetValue(TableName, Result) then
      Exit;
  Result := nil;
end;

procedure TVeritabani.InsertInto(
  const DBName, TableName: string;
  const Columns, Values: specialize TArray<string>);
var
  Row: TRow;
  Schema: TTabloSchema;
  i:Integer;
begin
  Row := TRow.Create;
  Schema := GetTableSchema(DBName, TableName);
  if Schema = nil then Exit;

  for i := 0 to High(Columns) do
    Row.Add(Columns[i], ParseDegerTipli(Schema.AlanTipi(Columns[i]), Values[i]));

  GetDataTable(DBName, TableName).Add(Row);
end;



function TVeritabani.MatchesCondition(const Row: TRow; const Cond: TCondition): Boolean;
var
  val: Variant;
  sOp, sVal: string;
  arr: specialize TArray<string>;
  item:String;
begin
  val := Row[Cond.Column];
  sOp := UpperCase(Trim(Cond.Op));
  sVal := Cond.Value;

  case sOp of
    '='  : Result := val = sVal;
    '<>' : Result := val <> sVal;
    '>'  : Result := val > sVal;
    '<'  : Result := val < sVal;
    '>=' : Result := val >= sVal;
    '<=' : Result := val <= sVal;
    'IS NULL'     : Result := VarIsNull(val) or VarIsEmpty(val);
    'IS NOT NULL' : Result := not VarIsNull(val) and not VarIsEmpty(val);
    'LIKE' : Result := Pos(LowerCase(StringReplace(sVal, '%', '', [rfReplaceAll])),
                           LowerCase(VarToStr(val))) > 0;
    'IN' :
      begin
        arr := sVal.Split([',']);
        Result := False;
        for item in arr do
          if Trim(item) = VarToStr(val) then
            Exit(True);
        Result := False;
      end;
    'BETWEEN' :
      begin
        arr := sVal.Split([',']);
        if Length(arr) = 2 then
          Result := (val >= arr[0]) and (val <= arr[1])
        else
          Result := False;
      end;
  else
    Result := False;
  end;
end;

function TVeritabani.SelectFrom(const DBName, TableName: string; const Columns: specialize TArray<string>; const Conditions: specialize TArray<TCondition>;const OrderBy: string;const GroupBy: string;const Having: specialize TArray<TCondition>; const Limit, Offset: Integer): TRowList;
var
  allRows, filtered, paged: TRowList;
  grouped: specialize TDictionary<string, TRowList>;
  row, proj: TRow;
  key: string;
  i: Integer;
  ok:Boolean;
  cond:TCondition;
  group:TRowList;
  col:String;
begin
  allRows := GetDataTable(DBName, TableName);
  filtered := TRowList.Create;

  for row in allRows do
  begin
    ok := True;
    for cond in Conditions do
      if not MatchesCondition(row, cond) then
      begin
        ok := False;
        Break;
      end;
    if ok then
      filtered.Add(row);
  end;

  if GroupBy <> '' then
  begin
    grouped := specialize TDictionary<string, TRowList>.Create;
    for row in filtered do
    begin
      key := VarToStr(row[GroupBy]);
      if not grouped.ContainsKey(key) then
        grouped.Add(key, TRowList.Create);
      grouped[key].Add(row);
    end;
    filtered.Free;
    filtered := TRowList.Create;

    for key in grouped.Keys do
    begin
      group := grouped[key];
      ok := True;
      for cond in Having do
        if not MatchesCondition(group[0], cond) then
        begin
          ok := False;
          Break;
        end;
      if ok then
        for row in group do
          filtered.Add(row);
      group.Free;
    end;
    grouped.Free;
  end;

  if OrderBy <> '' then
    SortRowsByColumn(filtered, OrderBy);

  paged := TRowList.Create;
  for i := Offset to filtered.Count - 1 do
  begin
    if (Limit <> -1) and (paged.Count >= Limit) then Break;
    paged.Add(filtered[i]);
  end;
  filtered.Free;

  Result := TRowList.Create;
  for row in paged do
  begin
    proj := TRow.Create;
    for col in Columns do
      proj.Add(col, row[col]);
    Result.Add(proj);
  end;
  paged.Free;
end;

procedure TVeritabani.UpdateRows(const DBName, TableName: string; Filter: TRowFilter; Updater: TRowUpdater);
var
  rows: TRowList;
  row:TRow;
begin
  rows := GetDataTable(DBName, TableName);
  for row in rows do
    if Filter(row) then
      Updater(row);
end;

procedure TVeritabani.DeleteRows(const DBName, TableName: string; Filter: TRowFilter);
var
  rows: TRowList;
  i: Integer;
begin
  rows := GetDataTable(DBName, TableName);
  i := rows.Count - 1;
  while i >= 0 do
  begin
    if Filter(rows[i]) then
    begin
      rows[i].Free;
      rows.Delete(i);
    end;
    Dec(i);
  end;
end;
{
procedure TVeritabani.SaveToFile(const FileName: string);
var
  jObj: TJSONObject;
  strm: TFileStream;
begin
  jObj := BuildFullJSON;
  strm := TFileStream.Create(FileName, fmCreate);
  try
    strm.Write(Pointer(jObj.AsJSON)^, Length(jObj.AsJSON));
  finally
    strm.Free;
    jObj.Free;
  end;
end;

procedure TVeritabani.LoadFromFile(const FileName: string);
var
  jStr: string;
  jObj, tblObj: TJSONObject;
  strm: TFileStream;
  parser: TJSONParser;
  dbName:String;
  i:Integer;
begin
  // Bellek temizliği (varsa)
  for dbName in FSchemaDict.Keys do
    CreateDatabase(dbName);

  strm := TFileStream.Create(FileName, fmOpenRead or fmShareDenyWrite);
  SetLength(jStr, strm.Size);
  strm.Read(Pointer(jStr)^, strm.Size);
  strm.Free;

  parser := TJSONParser.Create(jStr);
  jObj := parser.Parse as TJSONObject;
  parser.Free;

  for i := 0 to jObj.Count - 1 do
  begin
    tblObj := jObj.Objects[jObj.Names[i]];
    LoadTableFromJSON(tblObj);
  end;
  jObj.Free;
end;

function TVeritabani.BuildFullJSON: TJSONObject;
var
  jDB: TJSONObject;
  jTable: TJSONObject;
  schema: TTabloSchema;
  row: TRow;
  col: string;
  dbName:String;
  tblName:String;
  jRows:TJSONArray;
  jRow:TJSONObject;
begin
  Result := TJSONObject.Create;

  for dbName in FSchemaDict.Keys do
  begin
    jDB := TJSONObject.Create;
    Result.Add(dbName, jDB);

    for tblName in GetTableNames(dbName) do
    begin
      jTable := TJSONObject.Create;
      jTable.Add('TableName', tblName);

      schema := GetTableSchema(dbName, tblName);
      jTable.Add('Fields', schema.ToJSON);

      jRows := TJSONArray.Create;
      for row in GetDataTable(dbName, tblName) do
      begin
        jRow := TJSONObject.Create;
        for col in row.GetFieldNames do
          jRow.Add(col, TJSONString.Create(VarToStr(row[col])));
        jRows.Add(jRow);
      end;
      jTable.Add('Rows', jRows);

      jDB.Add(tblName, jTable);
    end;
  end;
end;


function TVeritabani.BuildODBPackage: TJSONObject;
var
  root, ayar: TJSONObject;
  db, table: string;
  dbList: TJSONArray;
  tableKeys: specialize TArray<string>;
  i: Integer;
  schema: TTabloSchema;
  rows: TRowList;
  tabloDict: specialize TDictionary<string, TRowList>;
begin
  root := TJSONObject.Create;
  ayar := TJSONObject.Create;
  dbList := TJSONArray.Create;

  for db in FDataDict.Keys.ToArray do
  begin
    dbList.Add(db);
    ayar.Integers['identity_' + db] := FIdentity[db];


    if FSchemaDict.ContainsKey(db) then
    begin
      tableKeys := FSchemaDict[db].Keys.ToArray;
      for i := 0 to High(tableKeys) do
      begin
        table := tableKeys[i];
        schema := FSchemaDict[db][table];
        root.Arrays['schema_' + db + '_' + table] := schema.ToJSON;
      end;
    end;

     if FDataDict.ContainsKey(db) then
    begin
      tabloDict := FDataDict[db];
      tableKeys := tabloDict.Keys.ToArray;
      for i := 0 to High(tableKeys) do
      begin
        table := tableKeys[i];
        rows := tabloDict[table];
        root.Arrays['data_' + db + '_' + table] := rows.ToJSON;
      end;
    end;
  end;

  ayar.Arrays['db_names'] := dbList;
  root.Objects['ayar'] := ayar;
  Result := root;
end;


procedure TVeritabani.ReplaceTableRows(const dbName, tableName: string; newRows: TRowList);
var
  tabloDict: specialize TDictionary<string, TRowList>;
  oldRows: TRowList;
begin
  if not FDataDict.TryGetValue(dbName, tabloDict) then
    Exit;

  if not tabloDict.TryGetValue(tableName, oldRows) then
    Exit;

  if Assigned(oldRows) then
    oldRows.Free;

  // 🔄 YENİ veri setini tabloya yerleştir
  tabloDict.AddOrSetValue(tableName, newRows);
end;

procedure TVeritabani.LoadODBPackage(json: TJSONObject);
var
  ayar: TJSONObject;
  dbArray: TJSONArray;
  tableKeys: TStrings;
  dbName, tableKey, tableName: string;
  schemaJSON: TJSONArray;
  dataJSON: TJSONArray;
  i, j: Integer;
  tablo: TTabloSchema;
  rowList: TRowList;
  rowObj: TJSONObject;
  row: TRow;
  val:TJSONNumber;
  keyList:TStringList;
  idx:Integer;
begin
  if Assigned(FDataDict) then
    ClearAll;

  if not Assigned(json) then Exit;
  if not json.Find('ayar', ayar) then Exit;
  if not Assigned(ayar) then Exit;

  dbArray := ayar.Arrays['db_names'];
  if not Assigned(dbArray) then Exit;

  for i := 0 to dbArray.Count - 1 do
  begin
    dbName := dbArray.Strings[i];
    CreateEmptyDatabase(dbName);


    if ayar.Find('identity_' + dbName, val) then
    FIdentity[dbName] := val.AsInteger;


   try
      keyList := TStringList.Create;

      for idx := 0 to json.Count - 1 do
        keyList.Add(json.Names[idx]);

      for idx := 0 to keyList.Count - 1 do
      begin

        tableKey := keyList[idx];

        if tableKey.StartsWith('schema_' + dbName + '_') then
        begin
          tableName := tableKey.Substring(Length('schema_' + dbName + '_'));
          schemaJSON := json.Arrays[tableKey];
          tablo := TTabloSchema.Create(tableName);
          tablo.FromJSON(schemaJSON);
          AddOrReplaceTable(dbName, tableName, tablo, TRowList.Create);
        end;


        if tableKey.StartsWith('data_' + dbName + '_') then
        begin
          tableName := tableKey.Substring(Length('data_' + dbName + '_'));
          dataJSON := json.Arrays[tableKey];
          rowList := TRowList.Create;

          for j := 0 to dataJSON.Count - 1 do
          begin
            rowObj := dataJSON.Objects[j];
            row := TRow.FromJSON(rowObj);
            rowList.Add(row);
          end;
          ReplaceTableRows(dbName, tableName, rowList);
        end;
      end;

    finally
    FreeAndNil(keyList);
    end;

  end;
end;


procedure TVeritabani.LoadTableFromJSON(const tblObj: TJSONObject);
var
  dbName, tblName: string;
  schema: TTabloSchema;
  fields: TJSONArray;
  rows: TJSONArray;
  rowObj: TJSONObject;
  colName: string;
  row: TRow;
  i:Integer;
begin
  tblName := tblObj.Get('TableName', '');
  dbName := 'Default'; // çoklu DB için ileride güncellenebilir

  fields := tblObj.Arrays['Fields'];
  rows := tblObj.Arrays['Rows'];

  schema := TTabloSchema.Create;
  schema.FromJSON(fields);
  CreateTable(dbName, tblName, schema);

  for i := 0 to rows.Count - 1 do
  begin
    rowObj := rows.Objects[i];
    row := TRow.Create;
    for colName in schema.AlanAdlari do
    begin
      if rowObj.IndexOfName(colName) <> -1 then
        row.Add(colName, rowObj.Get(colName));
    end;
    GetDataTable(dbName, tblName).Add(row);
  end;
end;

}
function TVeritabani.GetDatabaseNames: TStringList;
var
  keys: specialize TArray<string>;
  db:String;
begin
  Result := TStringList.Create;
  keys := FSchemaDict.Keys.ToArray;
  for db in keys do
    Result.Add(db);
end;

function TVeritabani.GetTableNames(const DBName: string): TStringList;
var
  schemaTbl: TTabloDict;
  tbl:String;
begin
  Result := TStringList.Create;
  if FSchemaDict.TryGetValue(DBName, schemaTbl) then
    for tbl in schemaTbl.Keys do
      Result.Add(tbl);
end;


procedure WriteFolderToStream(const klasorYolu: string; hedef: TStream);
var
  dosyalar: TStringList;
  i: Integer;
  fs: TFileStream;
  buffer: array[0..4095] of byte;
  okunan: Integer;
  dosyaYolu: string;
begin
  dosyalar := FindAllFiles(klasorYolu, '*.*', False);
  for i := 0 to dosyalar.Count - 1 do
  begin
    dosyaYolu := dosyalar[i];

    // Dosya adını yaz (önce uzunluğu, sonra ad)
    hedef.WriteDWord(Length(ExtractFileName(dosyaYolu)));
    hedef.WriteBuffer(ExtractFileName(dosyaYolu)[1], Length(ExtractFileName(dosyaYolu)));

    // Dosya boyutu ve içeriğini yaz
    fs := TFileStream.Create(dosyaYolu, fmOpenRead);
    hedef.WriteQWord(fs.Size);

    repeat
      okunan := fs.Read(buffer, SizeOf(buffer));
      if okunan > 0 then
        hedef.WriteBuffer(buffer, okunan);
    until okunan = 0;

    fs.Free;
  end;
  dosyalar.Free;
end;

procedure CompressToODB(const KaynakKlasoru: string);
var
  compressor: TCompressionStream;
  fsOut: TFileStream;
begin
  fsOut := TFileStream.Create(ChangeFileExt(KaynakKlasoru, '.odb'), fmCreate);
  compressor := TCompressionStream.Create(clmax,fsOut);

  // Tüm dosyaları tek bir arşive yaz (klasör içinden)
  WriteFolderToStream(KaynakKlasoru, compressor);

  compressor.Free;
  fsOut.Free;
end;


procedure TVeritabani.SaveAsODB(const PackageYolu: string);
var
  jsonAna: TJSONObject;
  dbList, tblList: TStringList;
  dbName, tblName: string;
  tblObj: TJSONObject;
begin
  jsonAna := TJSONObject.Create;
  jsonAna.Strings['version'] := '1.0';

  dbList := GetDatabaseNames;
  for dbName in dbList do
  begin
    tblList := GetTableNames(dbName);
    for tblName in tblList do
    begin
      // JSON içeriğini dosyaya yaz
      SaveSchemaToFile(PackageYolu + '/' + tblName + '_schema.json', GetTableSchema(dbName, tblName));
      SaveDataToFile(PackageYolu + '/' + tblName + '_data.json', GetDataTable(dbName, tblName));

      // ayar.json için içerik ekle
      tblObj := TJSONObject.Create;
      tblObj.Strings['schema'] := tblName + '_schema.json';
      tblObj.Strings['data'] := tblName + '_data.json';
      tblObj.Integers['lastId'] := SonId(dbName);
      tblObj.Strings['uid'] := 'tbl_' + LowerCase(tblName); // veya uuid

      jsonAna.Objects['databases.' + dbName + '.tables.' + tblName] := tblObj;
    end;
  end;

  // ayar dosyasını kaydet
  jsonAna.SaveToFile(PackageYolu + '/ayar.json');
  jsonAna.Free;

  // ZStream ile sıkıştır
  CompressToODB(PackageYolu); // son olarak Urunler.odb dosyasına dönüşüm
end;



procedure TVeritabani.LoadODBPackage(const PackageYolu: string);
var
  ayar: TJSONObject;
  dbNames: TStringList;
  dbName, tblName: string;
  tblObj: TJSONObject;
begin
  ayar := TJSONObject.Create;
  ayar.LoadFromFile(PackageYolu + '/ayar.json');

  dbNames := ayar.Keys['databases'];
  for dbName in dbNames do
  begin
    CreateEmptyDatabase(dbName);
    for tblName in ayar.Objects['databases.' + dbName + '.tables'].Keys do
    begin
      tblObj := ayar.Objects['databases.' + dbName + '.tables.' + tblName];

      LoadSchemaFromFile(
        PackageYolu + '/' + tblObj.Strings['schema'],
        dbName,
        tblName
      );

      LoadDataFromFile(
        PackageYolu + '/' + tblObj.Strings['data'],
        dbName,
        tblName
      );

      FIdentity[dbName + '.' + tblName] := tblObj.Integers['lastId'];
    end;
  end;

  ayar.Free;
end;

end.

