unit fQueryBuilder;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, StdCtrls, ExtCtrls, Grids,
  oTypes, oVeritabani;

type
  TFormQueryBuilder = class(TForm)
    PanelTop: TPanel;
    PanelMain: TPanel;
    ComboDatabase: TComboBox;
    ComboTable: TComboBox;
    ButtonPreview: TButton;
    GridPreview: TStringGrid;
    MemoQuery: TMemo;
    procedure ButtonPreviewClick(Sender: TObject);
    procedure ComboDatabaseChange(Sender: TObject);
    procedure ComboTableChange(Sender: TObject);
  private
    FVeri: TVeritabani;
    FAktifDB: string;
    procedure LoadDatabases;
    procedure LoadTables(const DBName: string);
  public
    procedure Initialize(Veritabani: TVeritabani; const DBName: string);
  end;

var
  FormQueryBuilder: TFormQueryBuilder;

implementation

uses Variants;
  {$R *.lfm}

procedure TFormQueryBuilder.Initialize(Veritabani: TVeritabani; const DBName: string);
begin
  FVeri := Veritabani;
  FAktifDB := DBName;
  LoadDatabases;
end;

procedure TFormQueryBuilder.LoadDatabases;
begin
  ComboDatabase.Items := FVeri.GetDatabaseNames;
end;

procedure TFormQueryBuilder.LoadTables(const DBName: string);
begin
  ComboTable.Items := FVeri.GetTableNames(DBName);
end;

procedure TFormQueryBuilder.ComboDatabaseChange(Sender: TObject);
begin
  LoadTables(ComboDatabase.Text);
end;

procedure TFormQueryBuilder.ComboTableChange(Sender: TObject);
begin
  MemoQuery.Lines.Text := 'SELECT * FROM ' + ComboTable.Text;
end;

procedure TFormQueryBuilder.ButtonPreviewClick(Sender: TObject);
var
  rows: TRowList;
  i: integer;
begin
  rows := FVeri.SelectFrom(ComboDatabase.Text, ComboTable.Text, [],
    [], '', '', nil, -1, 0);
  GridPreview.RowCount := rows.Count + 1;
  GridPreview.ColCount := 3; // örnek
  for i := 0 to rows.Count - 1 do
    GridPreview.Cells[0, i + 1] := VarToStr(rows[i]['ID']); // örnek
end;

end.
