program vdbmemtest;

{ BELLEK TAVANI TESTI - 32-bit sinirini olcmek icin
  ---------------------------------------------------------------------------
  Soru: "64-bit ne katar?" - en somut yanit BELLEKTIR. Motor tum kayitlari
  ACDIKTA TDictionary<QWord, TDbLoc> icinde tutuyor. 32-bit bir surec
  en fazla ~2 GB adres alabilir. Bu program dolulugu olcup gercek
  indeksin ne kadar RAM yedigini ve ne zaman yetersiz kaldigini gosterir.
}

{$mode delphi}{$H+}

uses
  SysUtils, Windows, Classes, VDbCore, VDbTable, VDbSql, FileUtil;

var
  StartMem, CurMem, PeakMem: NativeUInt;
  MaxPeek: NativeUInt;
  kv: TVDb;
  dir: string;
  v: TBytes;
  i: Integer;
  t0, t1: Int64;
  recSize: Integer;
  reported: Integer;

type
  TMemStatusEx = record
    dwLength: DWORD;
    dwMemoryLoad: DWORD;
    ullTotalPhys: QWord;
    ullAvailPhys: QWord;
    ullTotalPageFile: QWord;
    ullAvailPageFile: QWord;
    ullTotalVirtual: QWord;
    ullAvailVirtual: QWord;
    ullAvailExtendedVirtual: QWord;
  end;

  { PSAPI'den; Lazarus'un Windows unit'i bu tiyi sunmaz. }
  TProcMemCounters = record
    cb: DWORD;
    PageFaultCount: DWORD;
    PeakWorkingSetSize: NativeUInt;
    WorkingSetSize: NativeUInt;
    QuotaPeakPagedPoolUsage: NativeUInt;
    QuotaPagedPoolUsage: NativeUInt;
    QuotaPeakNonPagedPoolUsage: NativeUInt;
    QuotaNonPagedPoolUsage: NativeUInt;
    PagefileUsage: NativeUInt;
    PeakPagefileUsage: NativeUInt;
  end;

function GetProcessMemoryInfo(Process: THandle; out Counters: TProcMemCounters;
  cb: DWORD): BOOL; stdcall;
  external 'psapi.dll' name 'GetProcessMemoryInfo';

function GlobalMemoryStatusEx_(var MS: TMemStatusEx): BOOL; stdcall;
  external 'kernel32.dll' name 'GlobalMemoryStatusEx';

function MemUsed: NativeUInt;
var
  ms: TMemStatusEx;
begin
  ms.dwLength := SizeOf(ms);
  GlobalMemoryStatusEx_(ms);
  MemUsed := ms.ullAvailPhys;
end;

function ProcMem: QWord;
// Bu SUREC'in kullandigi ozel (commit) bellek. 32-bit sinirini
// ANLAMAK icin bu olculur: sistemde bos RAM olsa bile surec
// 2 GB ades alanina dayanir.
var
  c: TProcMemCounters;
begin
  c.cb := SizeOf(c);
  GetProcessMemoryInfo(GetCurrentProcess, c, SizeOf(c));
  ProcMem := c.PagefileUsage;   // ozel (commit) bellek
end;

procedure Report(const Label_: string; Count: Integer);
var
  idxMB, dbMB: Double;
begin
  idxMB := (Count * (SizeOf(QWord) + 16 + 40)) / (1024 * 1024);  // kaba tahmin
  dbMB := FileUtil.FileSize(kv.FilePath) / (1024 * 1024);
  WriteLn(Format('  %-12s %9d kayit  db=%6.1f MB  SUREC ozel bellek=%5.0f MB  bosRAM=%5.0f MB',
    [Label_, Count, dbMB, ProcMem / (1024 * 1024), MemUsed / (1024 * 1024)]));
end;

begin
  if (ParamCount < 1) then
  begin
    WriteLn('Kullanim: vdbmemtest <klasor> [kayit-sayisi]');
    Halt(2);
  end;
  dir := ParamStr(1);
  ForceDirectories(dir);
  MaxPeek := 2000000;
  if (ParamCount >= 2) then MaxPeek := StrToInt(ParamStr(2));

  WriteLn('=== 32-bit surec bellek siniri ===');
  WriteLn('Baslangic bos RAM: ', (MemUsed / (1024 * 1024)):0:0, ' MB');
  WriteLn;
  WriteLn('Motor indeks bellekte tutar; asagida gercek sinir goruluyor.');
  WriteLn;

  kv := TVDb.Create;
  kv.SyncWrite := False;
  kv.Open(dir + '\mem.odb');
  try
    recSize := 64;                // gercek bir deger; 0 olursa v[0] cokum
  SetLength(v, recSize);
    for i := 1 to 200 do
    begin
      v[0] := Byte(i);
      kv.Put(i, v);
    end;

    reported := 0;
    t0 := GetTickCount64;
    i := 200;
    try
      while i <= MaxPeek do
      begin
        kv.Put(i, v);
        Inc(i);
        if (i mod 200000 = 0) and (i - reported >= 400000) then
        begin
          Report('yazilirken', i);
          reported := i;
        end;
      end;
    except
      on E: Exception do
      begin
        WriteLn;
        WriteLn('  DURDU: ', E.ClassName, ': ', E.Message);
        Report('hata aninda', i);
      end;
    end;
    t1 := GetTickCount64;

    WriteLn;
    WriteLn('Toplam yazilan : ', i - 1, ' kayit');
    WriteLn('Gecen sure    : ', (t1 - t0) / 1000.0:0:1, ' sn');
    WriteLn('Dosya boyutu  : ', (FileUtil.FileSize(kv.FilePath) / (1024 * 1024)):0:1, ' MB');
    WriteLn('Kalan bos RAM : ', (MemUsed / (1024 * 1024)):0:0, ' MB');
    WriteLn('Bos alan RAM  : ', (FileUtil.FileSize(kv.FilePath) / (1024 * 1024)):0:1, ' MB db + indeks ayrica');
    WriteLn;
    WriteLn('SONUC: bu degerler makineye ozgudur. 32-bit surec ~2 GB');
    WriteLn('       adres alabilir; indeks de oylece sinirli kalir.');
  finally
    kv.Free;
  end;
end.