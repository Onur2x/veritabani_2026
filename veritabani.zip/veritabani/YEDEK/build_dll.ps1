# build_dll.ps1 - vdbapi.dll derler (32-bit / i386-win32)
#
# Neden ayri bir betik? Lazarus'un .lpi XML'inde kutuphane turunun
# isareti (LibraryType) bu kurulumda okunmuyor ve projeyi .exe olarak
# bagliyor. Motor da her zaman FPC 3.2.2 / i386-win32 ile derlendigi
# icin, FPC'yi dogrudan cagirmak hem daha hizli hem de Lazarus'un
# ekledigi ondalik bayraklardan etkilenmez.
#
# ONEMLI: -Mdelphi BILINCLI olarak VERILMEZ. VDbCrc32.pas icindeki bir
# yorumda `{$mode delphi}` dizisi geciyor; delphi modunda FPC yorumu
# `}` ile kapayip satirin kalanini kod sayiyor ve derleme kiriliyor.
# FPC'nin ontanilan modunda ic ice yorumlar serbest oldugu icin
# dosya dogru derleniyor (Lazarus da ayni modu kullanir).
#
# Kullanim:  powershell -ExecutionPolicy Bypass -File build_dll.ps1

$ErrorActionPreference = 'Stop'

$dir    = Split-Path -Parent $MyInvocation.MyCommand.Path
$fpc    = 'C:\lazarus\fpc\3.2.4\bin\i386-win32\ppc386.exe'
$lazut  = 'C:\lazarus\components\lazutils\lib\i386-win32'
$outDir = Join-Path $dir 'lib\vdbapi'

if (-not (Test-Path $fpc))    { throw "FPC bulunamadi: $fpc" }
if (-not (Test-Path $lazut))  { throw "LazUtils birimleri bulunamadi: $lazut" }

New-Item -ItemType Directory -Path $outDir -Force | Out-Null

Write-Host 'vdbapi.dll derleniyor (i386-win32)...' -ForegroundColor Cyan

# NOT: degisken adi $args OLMAMALI; PowerShell'da $args yerlesik bir
# otomatik degiskendir ve digerlerini ezdi.
$fpcArgs = @(
  '-O2',                        # optimize
  '-Sh',                        # ansistring yok say (kaynak kod ASCII-Turkce)
  "-Fu$dir",                    # motor birimleri
  "-Fu$lazut",                  # FileUtil (LazUtils)
  # 2026-10-05: VDbCore -> VDbCrypt -> DCPcrypt. Bu yollar eklenmezse
  # "Can't find unit dcpcrypt2 used by VDbCrypt" ile derleme duser.
  "-Fu$dir\dcpcrypt",
  "-Fu$dir\dcpcrypt\Ciphers",
  "-Fu$dir\dcpcrypt\Hashes",
  "-FU$outDir",                 # .o/.ppu cikti
  "-FE$dir",                    # .dll cikti
  "$dir\vdbapi.lpr"             # kaynak (TEK kaynak dosyasi son arg olmali)
)

& $fpc @fpcArgs
if ($LASTEXITCODE -ne 0) { throw "derleme basarisiz (kod $LASTEXITCODE)" }

$dll = Join-Path $dir 'vdbapi.dll'
if (-not (Test-Path $dll)) { throw "vdbapi.dll uretilmedi" }

Write-Host ''
Write-Host 'TAMAM: vdbapi.dll' -ForegroundColor Green
Get-Item $dll | Select-Object Name, Length, LastWriteTime | Format-Table -AutoSize
