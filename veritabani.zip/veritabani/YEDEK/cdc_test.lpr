program cdc_test;

{ CDC + TIME TRAVEL ENTTEGRASYON TESTI
  ---------------------------------------------------------------------------
  2026-10-05: ONCEKILIK hali "yazdir ve gec" idi (assertion yoktu, ustelik
  test KORUNAN ortak veritabanina [db\veritabani.odb] yaziyordu). Simdi:
    * gecici klasor (hicbir paylasilan dosyaya dokunulmaz),
    * gercek assertion sayaci + hata durumunda exit code 1,
    * CDC: INSERT/UPDATE/DELETE olaylari, tablo/PK/onceki-deger dogrulu,
    * TimeTravel: WAL gecmisinden onceki deger + AS OF ayristirma +
      "AS OF motor katmaninda degil" hata yolu. }

{$mode delphi}{$H+}

uses
  SysUtils, Classes, SyncObjs, VDbCore, VDbTable, VDbSql, VDbCdc,
  VDbTimeTravel, VDbErr;

var
  nPass, nFail: Integer;
  grpName: string;
  EvLock: TCriticalSection;
  EvList: array of TCDCEvent;

procedure Grp(const N: string);
begin
  grpName := N;
  WriteLn;
  WriteLn('== ', N);
end;

procedure Tst(const Nm: string; Cond: Boolean; const E: string = '');
begin
  if Cond then
  begin
    Inc(nPass);
    WriteLn('   OK   ', Nm, '   [', E, ']');
  end
  else
  begin
    Inc(nFail);
    WriteLn('   HATA ', Nm, '   [', E, ']  <- ', grpName);
  end;
end;

procedure OnChange(const Ev: TCDCEvent);
begin
  EvLock.Enter;
  try
    SetLength(EvList, Length(EvList) + 1);
    EvList[High(EvList)] := Ev;
  finally
    EvLock.Leave;
  end;
end;

function EvCount: Integer;
begin
  EvLock.Enter;
  try
    Result := Length(EvList);
  finally
    EvLock.Leave;
  end;
end;

function EvAt(i: Integer): TCDCEvent;
begin
  EvLock.Enter;
  try
    Result := EvList[i];
  finally
    EvLock.Leave;
  end;
end;

function EvOfType(t: TCDCEventType): Integer;
var
  i, c: Integer;
begin
  c := 0;
  EvLock.Enter;
  try
    for i := 0 to High(EvList) do
      if EvList[i].EventType = t then Inc(c);
  finally
    EvLock.Leave;
  end;
  Result := c;
end;

{ vals[] icinde guvenli goruntuleme (bos dizide ariza yok) }
function VAt(const A: TStrArray; i: Integer): string;
begin
  if (i >= 0) and (i <= High(A)) then Result := A[i] else Result := '<bos>';
end;

var
  Dir: string;
  Kv: TVDb;
  Tb: TVTableDb;
  Sq: TVSql;
  Cdc: TVDbCdc;
  Tt: TVTimeTravel;
  Spec: TSnapshotSpec;
  vals: TStrArray;
  b: TBytes;
  i, waited: Integer;
  reps: Integer;
  b0: Boolean;
  ok1: Boolean;
  v1: string;

begin
  nPass := 0; nFail := 0;
  EvLock := TCriticalSection.Create;
  Dir := GetTempDir(False) + 'vdbcdc_' + FormatDateTime('yyyymmdd_hhnnss', Now);
  ForceDirectories(Dir);

  WriteLn('CDC + TIME TRAVEL TESTI');
  WriteLn('Klasor (gecici): ', Dir);
  try
    { ------------------------------------------------ setup }
    Kv := TVDb.Create;
    Tb := TVTableDb.Create(Kv);
    Sq := TVSql.Create(Tb);
    Kv.Open(Dir);
    Tb.Open(Dir);
    Sq.Exec('CREATE TABLE cdc_t (id INTEGER PRIMARY KEY, ad TEXT, deger INTEGER)');

    { ------------------------------------------------ CDC }
    Grp('CDC: WAL uzerinden olay yakalama');
    Cdc := TVDbCdc.Create(Tb);
    Cdc.OnChange := @OnChange;
    Cdc.FlushIntervalMs := 100;
    Cdc.Start;
    Tst('Start WAL acik birakti', Kv.WALEnabled);

    Sq.Exec('INSERT INTO cdc_t (id, ad, deger) VALUES (1, ''test1'', 100)');
    Sq.Exec('INSERT INTO cdc_t (id, ad, deger) VALUES (2, ''test2'', 200)');
    Sq.Exec('INSERT INTO cdc_t (id, ad, deger) VALUES (3, ''test3'', 300)');
    Sq.Exec('UPDATE cdc_t SET deger = 150 WHERE id = 1');
    Sq.Exec('DELETE FROM cdc_t WHERE id = 2');

    { thread'in yakalamasini bekle (en fazla 5 sn) }
    waited := 0;
    while (Cdc.EventCount < 5) and (waited < 5000) do
    begin
      Sleep(50);
      Inc(waited, 50);
    end;
    Cdc.Stop;   // kalanlari da isler + flush yapar

    Tst('5 olay yakalandi', Cdc.EventCount = 5,
      IntToStr(Cdc.EventCount) + ' olay, ' + IntToStr(waited) + ' ms');
    Tst('tumu callback e ulasti', EvCount = 5, IntToStr(EvCount));
    Tst('3 INSERT', EvOfType(cdcInsert) = 3, IntToStr(EvOfType(cdcInsert)));
    Tst('1 UPDATE', EvOfType(cdcUpdate) = 1, IntToStr(EvOfType(cdcUpdate)));
    Tst('1 DELETE', EvOfType(cdcDelete) = 1, IntToStr(EvOfType(cdcDelete)));
    { WAL'de satir disi kayitlar da vardir: her INSERT semayi da yazar
      (VSCH1...). Bunlar olay DEGIL, atlanmalidir. }
    Tst('3 sema kaydi atlandi (satir disi)', Cdc.SkippedCount = 3,
      IntToStr(Cdc.SkippedCount));
    Tst('Stop sonrasi kuyruk bos', Cdc.PendingCount = 0);

    if EvCount >= 5 then
    begin
      Tst('INSERT olayi tablo adi dogru', EvAt(0).TableName = 'cdc_t',
        EvAt(0).TableName);
      Tst('INSERT olayi PK dogru', EvAt(0).PK = '1', EvAt(0).PK);
      Tst('INSERT degerleri dogru',
        (Length(EvAt(0).NewValues) = 3) and (EvAt(0).NewValues[1] = 'test1') and
        (VAt(EvAt(0).NewValues, 2) = '100'), VAt(EvAt(0).NewValues, 2));
      Tst('UPDATE onceki deger (OldValues) dogru',
        (Length(EvAt(3).OldValues) = 3) and (VAt(EvAt(3).OldValues, 2) = '100'),
        VAt(EvAt(3).OldValues, 2));
      Tst('UPDATE yeni deger dogru', VAt(EvAt(3).NewValues, 2) = '150',
        VAt(EvAt(3).NewValues, 2));
      Tst('UPDATE PK dogru', EvAt(3).PK = '1', EvAt(3).PK);
      Tst('DELETE olayi PK besleyebildi', EvAt(4).PK = '2', EvAt(4).PK);
      Tst('DELETE onceki deger beslendi', VAt(EvAt(4).OldValues, 2) = '200',
        VAt(EvAt(4).OldValues, 2));
      Tst('olay sira numaralari artan', EvAt(4).Seq = 5, IntToStr(EvAt(4).Seq));
      Tst('olay zaman damgasi dolu', EvAt(0).Timestamp > 0);
    end;

    { ------------------------------------------- Time Travel }
    Grp('Time Travel: WAL gecmisinden onceki deger');

    { WAL YERLESIMI (bu testte - sema kayitlari da WAL'a dusuyeer):
        #0 sema  #1 INSERT id=1  #2 sema  #3 INSERT id=2
        #4 sema  #5 INSERT id=3  #6 UPDATE id=1  #7 DELETE id=2 }
    Tt := TVTimeTravel.Create(Tb);
    FillChar(Spec, SizeOf(Spec), 0);
    Spec.Mode := smNone;
    Tt.BeginSnapshot(Spec);
    Tst('BeginSnapshot aktif yapar', Tt.Active);

    Tst('gecmis 8 kayit (3 sema + 3 INSERT + UPDATE + DELETE)',
      Tt.HistoryCount = 8, IntToStr(Tt.HistoryCount));

    b := Tt.GetValueAt('cdc_t', '1', 1);
    Tst('ilk INSERT anindaki deger bulundu', Length(b) > 0,
      IntToStr(Length(b)) + ' bayt');
    { Not: Tst argumanlarinin degerlendirme sirasi garanti oldugundan
      once calistirip sonraki Tst'e sonucu veriyoruz (ekrandaki deger
      aksi halde onceki sorgunun kalmis olabiliyor). }
    ok1 := Tt.GetRowAt('cdc_t', '1', 1, vals);
    v1 := VAt(vals, 2);
    Tst('o anki hali cozulebildi', ok1 and (v1 = '100'), v1);

    { UPDATE oncesi (id=1 hala 100) }
    ok1 := Tt.GetRowAt('cdc_t', '1', 3, vals);
    v1 := VAt(vals, 2);
    Tst('UPDATE oncesindeki hali 100', ok1 and (v1 = '100'), v1);

    b := Tt.GetValueAt('cdc_t', '1', 6);
    Tst('UPDATE sonrasi deger bulundu', Length(b) > 0, IntToStr(Length(b)));
    ok1 := Tt.GetRowAt('cdc_t', '1', 6, vals);
    v1 := VAt(vals, 2);
    Tst('UPDATE sonrasi hali cozulebildi', ok1 and (v1 = '150'), v1);

    b := Tt.GetValueAt('cdc_t', '2', 3);
    Tst('id=2 silinmeden onceki deger', Length(b) > 0, IntToStr(Length(b)));
    ok1 := Tt.GetRowAt('cdc_t', '2', 3, vals);
    v1 := VAt(vals, 2);
    Tst('id=2 silinmeden onceki hali cozulebildi', ok1 and (v1 = '200'), v1);

    b := Tt.GetValueAt('cdc_t', '2', 7);
    Tst('silme sonrasi deger YOK (bos)', Length(b) = 0,
      IntToStr(Length(b)) + ' bayt');

    b := Tt.GetValueAt('cok_uzak_tablo', 'yok', 99);
    Tst('gecmisi olmayan sorgu bos doner', Length(b) = 0);

    Grp('Time Travel: AS OF ayristirma + sinirlar');
    { Not: Cond ve E argumanlarinin degerlendirme sirasi garanti DEGIL;
      once ayristirip sonraki Tst'e veriyoruz (aksi halde eski Spec
      degeri ekrana yazilir). }
    b0 := ParseSnapshotSpec(
      'SELECT * FROM t AS OF TIMESTAMP ''2026-01-15 10:30:00''', Spec);
    Tst('AS OF TIMESTAMP ayristirildi', b0 and (Spec.Mode = smTimestamp),
      DateTimeToStr(Spec.Timestamp));
    b0 := ParseSnapshotSpec('SELECT * FROM t AS OF VERSION 42', Spec);
    Tst('AS OF VERSION ayristirildi',
      b0 and (Spec.Mode = smVersion) and (Spec.Version = 42),
      IntToStr(Int64(Spec.Version)));
    b0 := ParseSnapshotSpec('SELECT * FROM t AS OF SEQUENCE 7', Spec);
    Tst('AS OF SEQUENCE ayristirildi',
      b0 and (Spec.Mode = smSequence) and (Spec.Sequence = 7),
      IntToStr(Int64(Spec.Sequence)));
    b0 := ParseSnapshotSpec('SELECT * FROM t', Spec);
    Tst('AS OF olmayan SQL taninmaz', not b0);

    reps := 0;
    try
      Tt.ExecSnapshot('SELECT * FROM cdc_t');
    except
      on E: EVDbException do
      begin
        Inc(reps);
        Tst('aktif snapshot = acik hata (ecUnsupported)',
          E.ErrorCode = ecUnsupported, E.Message);
      end;
    end;
    if reps = 0 then
      Tst('aktif snapshot = acik hata (ecUnsupported)', False, 'hata vermedi');

    Tt.EndSnapshot;
    Tst('EndSnapshot pasif yapar', not Tt.Active);
    reps := Length(Tt.ExecSnapshot('SELECT * FROM cdc_t').Rows);
    Tst('aktif olmayan SQL calisir', reps = 2, IntToStr(reps) + ' satir');

    { checkpoint gecmisi siler -> TimeTravel siniri belgeli }
    Grp('Time Travel: WAL siniri (checkpoint gecmisi siler)');
    Kv.CheckpointWAL;
    Tt.Free;
    Tt := TVTimeTravel.Create(Tb);
    Tst('checkpoint sonrasi gecmis 0', Tt.HistoryCount = 0,
      IntToStr(Tt.HistoryCount));
    Tst('gecmis 0 iken deger bulunamaz',
      Length(Tt.GetValueAt('cdc_t', '1', 0)) = 0);

    Tt.Free;
    Cdc.Free;
    Sq.Free;
    Tb.Free;
    Kv.Free;
  except
    on E: Exception do
    begin
      Inc(nFail);
      WriteLn('BEKLENMEYEN HATA: ', E.ClassName, ': ', E.Message);
    end;
  end;

  EvLock.Free;
  WriteLn;
  WriteLn('========================================');
  WriteLn('SONUC: gecen=', nPass, '  kalan=', nFail);
  if nFail = 0 then
    WriteLn('CDC + TIME TRAVEL TESTLERI GECTI')
  else
    WriteLn('HATA VAR');
  if nFail > 0 then Halt(1);
end.
