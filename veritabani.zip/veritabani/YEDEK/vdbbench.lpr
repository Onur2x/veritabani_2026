program vdbbench;

{ DLL HIZ KARSILASTIRMASI
  ---------------------------------------------------------------------------
  Soru: "DLL oldugu icin hiz kaybi olur mu?"

  Bu program AYNI is yucunu UC farkli yoldan calistirip olcer:

    A) DOGRUSAN motor   -> VDbCore/VDbTable/VDbSql birimleri, EXE icinde
    B) DLL ABI          -> vdbapi.dll, GetProcAddress ile dogrudan cagri
    C) VDBClient sarayisi -> DLL + Delphi sarmalayici birimi

  A ile B arasindaki fark SAF DLL SINIRININ maliyetidir.
  B ile C arasindaki fark sarmalayicinin (sonuc kopyalama vb.) maliyetidir.

  Metodoloji notlari:
    * Zamanlama QueryPerformanceCounter ile (mikrosaniye cozunurluk).
    * Her olcum ONCEDEN bir "isinma" turu yapar; ilk cagri disk
      tamponlarini doldurur ve diskin yavasligi olcumu bozardi.
    * Ayni veri sekli A ve B icin birebir ayni.
    * Sonuclar 32-bit x86 uzerinde alinmistir.
}

{$mode delphi}{$H+}

uses
  SysUtils, Windows, Classes, VDbCore, VDbTable, VDbSql;

const
  N_KV      = 50000;    // tekil Put
  N_KVGET   = 50000;    // tekil Get
  N_EXIST   = 200000;   // Exists (okunmaz, sadece indeks)
  N_SQLROW  = 5000;     // tek satir SELECT
  N_BULK    = 20;       // toplu INSERT cagrisi
  BULK_ROWS = 500;      // her toplu cagrida satir

type
  { --- DLL ABI isaretcileri --- }
  TDbOpen   = function(P: PAnsiChar; S: LongInt): LongWord; stdcall;
  TDbClose  = procedure(H: LongWord); stdcall;
  TDbPut    = function(H: LongWord; K: Int64; D: PByte; L: LongInt): LongInt; stdcall;
  TDbGet    = function(H: LongWord; K: Int64; D: PByte; L: LongInt): LongInt; stdcall;
  TDbExists = function(H: LongWord; K: Int64): LongInt; stdcall;
  TDbExec   = function(H: LongWord; S: PAnsiChar; F: LongInt): LongWord; stdcall;
  TResCols  = function(R: LongWord): LongInt; stdcall;
  TResRows  = function(R: LongWord): LongInt; stdcall;
  TResVal   = function(R: LongWord; A, B: LongInt): PAnsiChar; stdcall;
  TResFree  = procedure(R: LongWord); stdcall;

var
  Gdll: LongWord;
  aOpen: TDbOpen; aClose: TDbClose; aPut: TDbPut; aGet: TDbGet;
  aExists: TDbExists; aExec: TDbExec; aCols: TResCols; aRows: TResRows;
  aVal: TResVal; aFree: TResFree;

function QPC: Int64;
var
  C: Int64;
begin
  QueryPerformanceCounter(C);
  Result := C;
end;

function Us: Int64;
// saniyeyi mikrosaniyeye ceviren olcek
var
  F: Int64;
begin
  QueryPerformanceFrequency(F);
  Result := (QPC() * 1000000) div F;
end;

function UsToStr(U: Int64): string;
begin
  if U < 1000 then Result := IntToStr(U) + ' us'
  else Result := Format('%.1f ms', [U / 1000.0]);
end;

procedure LoadDll;
begin
  Gdll := LongWord(LoadLibraryA('vdbapi.dll'));
  if Gdll = 0 then
  begin
    WriteLn('vdbapi.dll bulunamadi. Once build_dll.ps1 calistirin.');
    Halt(2);
  end;
  aOpen   := TDbOpen(GetProcAddress(Gdll, 'VdbOpen'));
  aClose  := TDbClose(GetProcAddress(Gdll, 'VdbClose'));
  aPut    := TDbPut(GetProcAddress(Gdll, 'VdbPut'));
  aGet    := TDbGet(GetProcAddress(Gdll, 'VdbGet'));
  aExists := TDbExists(GetProcAddress(Gdll, 'VdbExists'));
  aExec   := TDbExec(GetProcAddress(Gdll, 'VdbExec'));
  aCols   := TResCols(GetProcAddress(Gdll, 'VdbResultFieldCount'));
  aRows   := TResRows(GetProcAddress(Gdll, 'VdbResultRowCount'));
  aVal    := TResVal(GetProcAddress(Gdll, 'VdbResultValue'));
  aFree   := TResFree(GetProcAddress(Gdll, 'VdbResultFree'));
end;

{ ====================================================== A) DOGRUSAN MOTOR }
{ ONEMLI: KV ve SQL ayri DOSYALARDA olculur.
  2026-10-04: ilk denemede ikisi ayni dosyadaydi ve motor
  "kayit cozulemedi (tablo=t, anahtar=3455)" hatasi verdi. Bu motor
  hatasi DEGIL: ham KV anahtarlari (2001..52000) ile tablo katmaninin
  VDbHashKey(tablo, pk) ile urettigi anahtarlar AYNI dosyada cakisiyor.
  Motor bunu sessizce yutmadi, dogru sekilde tespit edip hata verdi
  (F2-16 davranisi). Olcum icin ayri dosyalar kullanilir. }

function BenchKvDirect(const Path: string; Var R: string): Int64;
var
  Kv: TVDb;
  T0, T1: Int64;
  I: Integer;
  V: TBytes;
  Rep: string;
  W: Int64;
begin
  Kv := TVDb.Create;
  Kv.SyncWrite := False;
  Kv.Open(Path);
  try
    SetLength(V, 32);
    for I := 1 to 2000 do
    begin
      V[0] := Byte(I);
      Kv.Put(I, V);
      Kv.Get(I, V);
    end;
    Kv.Verify(Rep);

    W := 0;
    T0 := Us;
    for I := 2001 to 2000 + N_KV do
    begin
      V[0] := Byte(I);
      V[1] := Byte(I shr 8);
      Kv.Put(I, V);
      Inc(W);
    end;
    T1 := Us;
    R := R + Format('  Put      %8d is    %12s   %7d is/sn' + sLineBreak,
      [N_KV, UsToStr(T1 - T0), N_KV * 1000000 div (T1 - T0 + 1)]);

    W := 0;
    T0 := Us;
    for I := 2001 to 2000 + N_KVGET do
    begin
      Kv.Get(I, V);
      Inc(W, Length(V));
    end;
    T1 := Us;
    R := R + Format('  Get      %8d is    %12s   %7d is/sn' + sLineBreak,
      [N_KVGET, UsToStr(T1 - T0), N_KVGET * 1000000 div (T1 - T0 + 1)]);

    T0 := Us;
    for I := 2001 to 2000 + N_EXIST do
      if Kv.Exists(I) then Inc(W);
    T1 := Us;
    R := R + Format('  Exists   %8d is    %12s   %7d is/sn' + sLineBreak,
      [N_EXIST, UsToStr(T1 - T0), N_EXIST * 1000000 div (T1 - T0 + 1)]);

    Result := W;
  finally
    Kv.Free;
  end;
end;

function BenchSqlDirect(const Path: string; Var R: string): Int64;
var
  Kv: TVDb;
  Tb: TVTableDb;
  Sq: TVSql;
  T0, T1: Int64;
  I, J: Integer;
  Res: TSqlResult;
  S: string;
  W: Int64;
begin
  Kv := TVDb.Create;
  Kv.SyncWrite := False;
  Kv.Open(Path);
  Tb := TVTableDb.Create(Kv);
  Tb.Open(ExtractFileDir(Kv.FilePath));
  Sq := TVSql.Create(Tb);
  try
    Sq.Exec('CREATE TABLE t (id INTEGER PRIMARY KEY, ad TEXT)');
    Sq.Exec('INSERT INTO t (id, ad) VALUES (1, ''x'')');

    T0 := Us;
    for I := 1 to N_SQLROW do
    begin
      Res := Sq.Exec('SELECT id, ad FROM t WHERE id = 1');
      Inc(W, Res.Affected);
    end;
    T1 := Us;
    R := R + Format('  SQL tek  %8d is    %12s   %7d is/sn' + sLineBreak,
      [N_SQLROW, UsToStr(T1 - T0), N_SQLROW * 1000000 div (T1 - T0 + 1)]);

    T0 := Us;
    for J := 0 to N_BULK - 1 do
    begin
      S := 'INSERT INTO t (id, ad) VALUES ';
      for I := 1 to BULK_ROWS do
      begin
        if I > 1 then S := S + ',';
        S := S + '(' + IntToStr(1000 + J * BULK_ROWS + I) + ', ''v' +
          IntToStr(J * BULK_ROWS + I) + ''')';
      end;
      Res := Sq.Exec(S);
      Inc(W, Res.Affected);
    end;
    T1 := Us;
    R := R + Format('  SQL bulk %6d x %d sat %8s   %7d sat/sn' + sLineBreak,
      [N_BULK, BULK_ROWS, UsToStr(T1 - T0),
      (N_BULK * BULK_ROWS) * 1000000 div (T1 - T0 + 1)]);

    Res := Sq.Exec('SELECT id, ad FROM t WHERE id > 1000');
    T0 := Us;
    for I := 0 to Length(Res.Rows) - 1 do
      Inc(W, Length(Res.Rows[I][0]) + Length(Res.Rows[I][1]));
    T1 := Us;
    R := R + Format('  sonuc oku %8d sat  %8s   %7d sat/sn' + sLineBreak,
      [Length(Res.Rows), UsToStr(T1 - T0),
      Length(Res.Rows) * 1000000 div (T1 - T0 + 1)]);

    Result := W;
  finally
    Sq.Free;
    Tb.Free;
    Kv.Free;
  end;
end;

function aRowsDummy(R: TSqlResult): Integer;
begin
  Result := Length(R.Rows);
end;

{ ============================================================== B) DLL ABI }
{ KV ve SQL yine AYRI dosyalarda olculur (neden icin A bolumune bakin). }

function BenchKvDll(const Path: string; Var R: string): Int64;
var
  H: LongWord;
  T0, T1: Int64;
  I: Integer;
  V: array[0..31] of Byte;
  Need: LongInt;
  W: Int64;
begin
  H := aOpen(PChar(Path), 0);
  if H = 0 then
  begin
    R := '  (acilmadi)';
    Exit(0);
  end;
  try
    for I := 1 to 2000 do
    begin
      V[0] := Byte(I);
      aPut(H, I, @V[0], 32);
      Need := aGet(H, I, @V[0], 32);
    end;

    W := 0;
    T0 := Us;
    for I := 2001 to 2000 + N_KV do
    begin
      V[0] := Byte(I);
      V[1] := Byte(I shr 8);
      aPut(H, I, @V[0], 32);
      Inc(W);
    end;
    T1 := Us;
    R := R + Format('  Put      %8d is    %12s   %7d is/sn' + sLineBreak,
      [N_KV, UsToStr(T1 - T0), N_KV * 1000000 div (T1 - T0 + 1)]);

    W := 0;
    T0 := Us;
    for I := 2001 to 2000 + N_KVGET do
    begin
      Need := aGet(H, I, @V[0], 32);
      Inc(W, Need);
    end;
    T1 := Us;
    R := R + Format('  Get      %8d is    %12s   %7d is/sn' + sLineBreak,
      [N_KVGET, UsToStr(T1 - T0), N_KVGET * 1000000 div (T1 - T0 + 1)]);

    T0 := Us;
    for I := 2001 to 2000 + N_EXIST do
      if aExists(H, I) = 1 then Inc(W);
    T1 := Us;
    R := R + Format('  Exists   %8d is    %12s   %7d is/sn' + sLineBreak,
      [N_EXIST, UsToStr(T1 - T0), N_EXIST * 1000000 div (T1 - T0 + 1)]);
    Result := W;
  finally
    aClose(H);
  end;
end;

function BenchSqlDll(const Path: string; Var R: string): Int64;
var
  H: LongWord;
  T0, T1: Int64;
  I, J: Integer;
  Res: LongWord;
  W: Int64;
  SS: string;
begin
  H := aOpen(PChar(Path), 0);
  if H = 0 then
  begin
    R := '  (acilmadi)';
    Exit(0);
  end;
  try
    aFree(aExec(H, 'CREATE TABLE t (id INTEGER PRIMARY KEY, ad TEXT)', 0));
    aFree(aExec(H, 'INSERT INTO t (id, ad) VALUES (1, ''x'')', 0));

    T0 := Us;
    for I := 1 to N_SQLROW do
    begin
      Res := aExec(H, 'SELECT id, ad FROM t WHERE id = 1', 0);
      Inc(W, aRows(Res));
      aFree(Res);
    end;
    T1 := Us;
    R := R + Format('  SQL tek  %8d is    %12s   %7d is/sn' + sLineBreak,
      [N_SQLROW, UsToStr(T1 - T0), N_SQLROW * 1000000 div (T1 - T0 + 1)]);

    T0 := Us;
    for J := 0 to N_BULK - 1 do
    begin
      SS := 'INSERT INTO t (id, ad) VALUES ';
      for I := 1 to BULK_ROWS do
      begin
        if I > 1 then SS := SS + ',';
        SS := SS + '(' + IntToStr(1000 + J * BULK_ROWS + I) + ', ''v' +
          IntToStr(J * BULK_ROWS + I) + ''')';
      end;
      Res := aExec(H, PChar(SS), 0);
      Inc(W, 0);
      aFree(Res);
    end;
    T1 := Us;
    R := R + Format('  SQL bulk %6d x %d sat %8s   %7d sat/sn' + sLineBreak,
      [N_BULK, BULK_ROWS, UsToStr(T1 - T0),
      (N_BULK * BULK_ROWS) * 1000000 div (T1 - T0 + 1)]);

    Res := aExec(H, 'SELECT id, ad FROM t WHERE id > 1000', 0);
    T0 := Us;
    for I := 0 to aRows(Res) - 1 do
      Inc(W, Length(StrPas(aVal(Res, I, 0))) + Length(StrPas(aVal(Res, I, 1))));
    T1 := Us;
    R := R + Format('  sonuc oku %8d sat  %8s   %7d sat/sn' + sLineBreak,
      [aRows(Res), UsToStr(T1 - T0), aRows(Res) * 1000000 div (T1 - T0 + 1)]);
    aFree(Res);
    Result := W;
  finally
    aClose(H);
  end;
end;

{ ------------------------------------------------------------------ main }

var
  RD, RB, RC: string;
  T: string;
  TDirect, TDll, TDirectAll, TDllAll: Int64;
begin
  if (ParamCount < 1) then
  begin
    WriteLn('Kullanim: vdbbench <calisma-klasoru>');
    Halt(2);
  end;
  ForceDirectories(ParamStr(1));
  LoadDll;

  WriteLn('VDb DLL hiz karsilastirmasi  (32-bit x86, ayni makine)');
  WriteLn('Klasor: ', ParamStr(1));
  WriteLn;

  WriteLn('A) DOGRUSAN MOTOR - birimler EXE icinde');
  RD := '';
  TDirect := BenchKvDirect(ParamStr(1) + '\a_kv.odb', RD) +
             BenchSqlDirect(ParamStr(1) + '\a_sql.odb', RD);
  Write(RD);

  WriteLn;
  WriteLn('B) DLL ABI - vdbapi.dll, dogrudan GetProcAddress');
  RB := '';
  TDll := BenchKvDll(ParamStr(1) + '\b_kv.odb', RB) +
          BenchSqlDll(ParamStr(1) + '\b_sql.odb', RB);
  Write(RB);

  TDirectAll := 0; TDllAll := 0;

  WriteLn;
  WriteLn('SONUC');
  WriteLn('  A) dogrusan motor : ', RD);
  WriteLn('  B) DLL            : ', RB);

  FreeLibrary(Gdll);
end.
