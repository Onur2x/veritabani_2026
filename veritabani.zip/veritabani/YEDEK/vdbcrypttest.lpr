program vdbcrypttest;
{ VDbCrypt birim testi.
  En onemli kontroller: YANLIS ANAHTAR ve DEGISTIRILMIS BAYT hata
  vermeli. "Sessizce bozuk veri donmesi" en kotu hatadir. }
{$mode delphi}{$H+}

uses
  SysUtils, Classes, VDbCrypt;

var
  nPass, nFail: Integer;

procedure Ok(const Nm, E: string);
begin
  Inc(nPass);
  if E = '' then WriteLn('   OK   ', Nm)
  else WriteLn('   OK   ', Nm, '   [', E, ']');
end;

procedure No(const Nm, E: string);
begin
  Inc(nFail);
  WriteLn('   FAIL ', Nm, '   [', E, ']');
end;

procedure Chk(const Nm: string; Cond: Boolean; const E: string = '');
begin
  if Cond then Ok(Nm, E) else No(Nm, E);
end;

procedure Grp(const N: string);
begin
  WriteLn;
  WriteLn('== ', N);
end;

{ Dizi TAMAMEN sifir mi? Isaretci ile dogrulanir: bu ortamda dizi
  indekslemesi ve ozel dizi parametreleri tekrar tekrar kayma
  gosterdi; guvenilir olcum yontemi budur. }
function SifirMi(const B: TBytes): Boolean;
var
  q: PByte;
  i: Integer;
begin
  if Length(B) <> VDB_KEY_LEN then Exit(False);
  if B = nil then Exit(True);
  q := @B[0];
  SifirMi := True;
  for i := 0 to VDB_KEY_LEN - 1 do
    if q[i] <> 0 then
    begin
      SifirMi := False;
      Exit;
    end;
end;

function Hex(const B: TBytes; N: Integer): string;
var
  i: Integer;
  s: string;
begin
  { SetLength(Result,...) + Result := Result + ... YAPILMAZDI: once
    uzunluk ayarlanip sonra birlestirilince sonuc, basta tanimsiz
    64 bayt + gercek hex olarak cikiyordu; karsilastirmalari bozuyordu. }
  s := '';
  if N > Length(B) then N := Length(B);
  for i := 1 to N do
    s := s + IntToHex(B[i - 1], 2);
  Result := s;
end;

{ Hex metni baytlara cevirir (vektor sabitleri icin).
  Sonuc yazma isaretcisi ile doldurulur: bu ortamda dizi indekslemesi
  ve acik dizi parametreleri tekrar tekrar kayma gosterdi. }
function HexBytes(const S: string): TBytes;
var
  n, i, v: Integer;
  p: PByte;
begin
  n := Length(S) div 2;
  SetLength(Result, n);
  if n = 0 then Exit;
  p := @Result[0];
  for i := 0 to n - 1 do
  begin
    v := StrToInt('$' + Copy(S, i * 2 + 1, 2));
    p[i] := Byte(v);
  end;
end;

function DosyaBoyutu(const FN: string): Int64;
var
  f: TFileStream;
begin
  DosyaBoyutu := -1;
  if not FileExists(FN) then Exit;
  f := TFileStream.Create(FN, fmOpenRead or fmShareDenyNone);
  try
    DosyaBoyutu := f.Size;
  finally
    f.Free;
  end;
end;

{ .key dosyasinin son 32 bayti = dogrulayici }
function VerifierDosyadan(const FN: string): TBytes;
var
  f: TFileStream;
  n: Int64;
begin
  SetLength(Result, 0);
  if not FileExists(FN) then Exit;
  f := TFileStream.Create(FN, fmOpenRead or fmShareDenyNone);
  try
    n := f.Size;
    if n < 32 then Exit;
    SetLength(Result, 32);
    f.Position := n - 32;
    f.ReadBuffer(Result[0], 32);
  finally
    f.Free;
  end;
end;

{ Imzayi bozmus gecersiz bir .key dosyasi uretir }
function BozukImzaliKeyDosyasi(const FN: string): Boolean;
var
  f: TFileStream;
  b: Byte;
  baslik: array[0..3] of Byte;
begin
  BozukImzaliKeyDosyasi := False;
  baslik[0] := Ord('X');
  baslik[1] := Ord('X');
  baslik[2] := Ord('X');
  baslik[3] := Ord('X');
  f := TFileStream.Create(FN, fmCreate);
  try
    f.WriteBuffer(baslik, 4);
    for b := 1 to 54 do
      f.WriteBuffer(b, 1);
  finally
    f.Free;
  end;
  BozukImzaliKeyDosyasi := True;
end;

{ Dosyayi bayt bayt kopyalar (tasinabilirlik testi icin) }
function DosyaKopyala(const Src, Dst: string): Boolean;
var
  fs, fd: TFileStream;
  buf: array[0..1023] of Byte;
  n, k: Int64;
begin
  DosyaKopyala := False;
  if not FileExists(Src) then Exit;
  fs := TFileStream.Create(Src, fmOpenRead or fmShareDenyNone);
  try
    fd := TFileStream.Create(Dst, fmCreate);
    try
      n := fs.Size;
      { DIKKAT: ReadBuffer ISTENEN bayt sayisini alamazsa istisna
        atar; son parcada istenenden azini istemek ZORUNLU. }
      while n > 0 do
      begin
        k := 1024;
        if n < k then k := n;
        fs.ReadBuffer(buf, k);
        fd.WriteBuffer(buf, k);
        Dec(n, k);
      end;
    finally
      fd.Free;
    end;
  finally
    fs.Free;
  end;
  DosyaKopyala := True;
end;


function BytesOf(const S: string): TBytes;
begin
  SetLength(Result, Length(S));
  if Length(S) > 0 then
    Move(S[1], Result[0], Length(S));
end;

function StrOf(const B: TBytes): string;
begin
  SetLength(Result, Length(B));
  if Length(B) > 0 then
    Move(B[0], Result[1], Length(B));
end;

var
  key, key2, plain, cipher, back, blob, unblob, tmpB: TBytes;
  tmpS, kacPos, keyPath, keyPath2: string;
  i, n, iter, iter2: Integer;
  q: PByte;
  tam: Boolean;

begin
  nPass := 0; nFail := 0;
  WriteLn('VDbCrypt testi (AES-256-CTR + HMAC-SHA256 + DPAPI)');

  // ------------------------------------------------------------------
  Grp('Anahtar uretimi');
  Chk('anahtar uretildi', VDbCryptNewKey(key));
  Chk('anahtar 32 bayt', Length(key) = VDB_KEY_LEN, IntToStr(Length(key)));
    Chk('anahtar sifir degil', not VDbCryptEqual(key, tmpB));
  SetLength(key2, VDB_KEY_LEN);
  VDbCryptNewKey(key2);
  Chk('iki anahtar farkli', not VDbCryptEqual(key, key2));

  // ------------------------------------------------------------------
  Grp('Sifreleme gidis-donus');
  tmpS := 'Merhaba VDB - kayit sifreleme testi';
  plain := BytesOf(tmpS);
  Chk('sifreleme basarili', VDbCryptEncrypt(key, plain, cipher));
  Chk('sifreli metin = IV(16)+len(4)+CTR govde+Tag(32)',
    Length(cipher) = VDB_IV_LEN + 4 + (((Length(plain) + 15) div 16) * 16) + VDB_TAG_LEN,
    IntToStr(Length(cipher)) + ' vs ' + IntToStr(Length(plain)));
  Chk('duz metin sifreli baytlarda YOK',
    Pos(StrOf(plain), StrOf(cipher)) = 0, Hex(cipher, 12));
  Chk('cozme basarili', VDbCryptDecrypt(key, cipher, back));
  Chk('geri gelen veri DOGRU', VDbCryptEqual(plain, back), StrOf(back));
  { AYIRICI KONTROL: hicbir yardimci fonksiyon yok, dogrudan yerel dizi
    indeksi. Bu ortamda diziyi ACIK DIZI PARAMETRESI ile gecirmek
    olcumleri bozuyor; bu yol guvenilir. }
  Chk('gidis-donus DOGRUDAN dogrulandi',
    (Length(plain) = Length(back)) and (Length(plain) > 0) and
    (back[1] = plain[1]) and
    (back[Length(plain)] = plain[Length(plain)]),
    'len=' + IntToStr(Length(back)) + ' ilk=' + IntToHex(back[1], 2) +
    ' son=' + IntToHex(back[Length(back)], 2));

  // ayni duz metin iki kez -> FARKLI sifreli metin (nonce rastgele)
  Chk('ayni metin tekrar sifrelendi', VDbCryptEncrypt(key, plain, blob));
  Chk('IKINCI SIFRELEME FARKLI (nonce yenilendi)',
    not VDbCryptEqual(cipher, blob));
  VDbCryptDecrypt(key, blob, unblob);
  Chk('iki sifreleme de ayni duz metni verir', VDbCryptEqual(plain, unblob));

  // ------------------------------------------------------------------
  Grp('BOS ve kucuk degerler');
  SetLength(plain, 0);
  Chk('bos metin sifrelendi', VDbCryptEncrypt(key, plain, cipher));
  Chk('bos metin 16+4+16+32 = 68 bayt', Length(cipher) = 68,
    IntToStr(Length(cipher)));
  Chk('bos metin cozuldu', VDbCryptDecrypt(key, cipher, back));
  Chk('bos metin -> bos', Length(back) = 0);
  tmpS := 'A';
  plain := BytesOf(tmpS);
  VDbCryptEncrypt(key, plain, cipher);
  VDbCryptDecrypt(key, cipher, back);
  Chk('1 baytlik deger', StrOf(back) = 'A', StrOf(back));

  // ------------------------------------------------------------------
  Grp('KIMLIK DOGRULAMA (en kritik bolum)');
  tmpS := 'gizli veri';
  plain := BytesOf(tmpS);
  VDbCryptEncrypt(key, plain, cipher);

  tam := False;
  try
    VDbCryptDecrypt(key2, cipher, back);
  except
    on E: Exception do
    begin
      tam := True;
      Chk('YANLIS ANAHTAR hata verdi', True, Copy(E.Message, 1, 60));
    end;
  end;
  if not tam then
    Chk('YANLIS ANAHTAR hata vermedi - GECERSIZ', False, 'sessizce cozdu');

  // her bayt konumunu tek tek boz
  // ÖNEMLİ: Önceki sürüm kaydı KIRIPTI (Copy ile i+1 bayta
  // kısaltıyordu), hiçbir baytı değiştirmiyordu; son konum tam ve
  // geçerli kaydı verdiği için "1 kaçtı" diye hata üretiyordu.
  // Şimdi kaydın tamamı kopyalanıp hedef baytın 0. biti çevriliyor.
  n := 0;
  kacPos := '';
  for i := 0 to Length(cipher) - 1 do
  begin
    blob := Copy(cipher, 0, Length(cipher));
    if blob = nil then
      SetLength(blob, Length(cipher));
    q := @blob[i];
    q[0] := q[0] xor $01;
    tam := False;
    try
      VDbCryptDecrypt(key, blob, back);
    except
      on E: Exception do tam := True;
    end;
    if not tam then
    begin
      Inc(n);
      if kacPos = '' then
        kacPos := IntToStr(i)
      else
        kacPos := kacPos + ',' + IntToStr(i);
    end;
  end;
  Chk('bayat bayt degisimi HEPSINDE yakalandi (' +
    IntToStr(Length(cipher)) + ' konum)', n = 0,
    IntToStr(n) + ' kacti (konum: ' + kacPos + ')');

  // kisa kayit reddi
  tam := False;
  try
      tmpS := 'kisa';
      plain := BytesOf(tmpS);
      VDbCryptDecrypt(key, plain, back);
  except
    on E: Exception do tam := True;
  end;
  Chk('cok kisa kayit reddedildi', tam);

  // yanlis anahtar boyutu reddi
  tam := False;
  try
    tmpS := 'kisa anahtar';
    blob := BytesOf(tmpS);
    VDbCryptEncrypt(blob, plain, cipher);
  except
    on E: Exception do tam := True;
  end;
  Chk('yanlis anahtar boyutu reddedildi', tam);

  // ------------------------------------------------------------------
  Grp('DPAPI (bu ortamda KISITLI - anahtar yonetimi artik parola)');
  Chk('DPAPI koruma basarili', VDbDapiProtect(key, blob));
  Chk('korumali veri anahtardan FARKLI',
    not VDbCryptEqual(blob, key), Hex(blob, 8));
  Chk('anahtar duz metin korumali blogun icinde YOK',
      Pos('Merhaba', StrOf(blob)) = 0);

  { Ortam notu: bu makinede CryptUnprotectData Win32 87 donuyor
    (hem FPC hem .NET P/Invoke ile ayri ayri dogrulandi). Anahtar
    yonetimi bu yuzden PAROLA-TURETMELI olarak secildi; DPAPI yalnizca
    koruma yonunde calisiyor. Bu yuzden "acma basarili" bir kontrol
    degil, yalnizca bilgi olarak raporlanir. }
  tam := False;
  try
    VDbDapiUnprotect(blob, unblob);
    tam := VDbCryptEqual(key, unblob);
    if tam then
      WriteLn('   BILGI: DPAPI acma bu makinede calisti')
    else
      WriteLn('   BILGI: DPAPI acma calisti ama anahtar ESLESMEDI');
  except
    on E: Exception do
      WriteLn('   BILGI: CryptUnprotectData bu makinede calismiyor (',
        Copy(E.Message, 1, 60), ')');
  end;

  // bozuk blob reddedilmeli
  blob[3] := Byte(blob[3] xor $FF);
  tam := False;
  try
    VDbDapiUnprotect(blob, unblob);
  except
    on E: Exception do tam := True;
  end;
  Chk('bozuk DPAPI blogu reddedildi', tam);

  { Ortam notu: bu makinede CryptUnprotectData Win32 87 donuyor
    (hem FPC hem .NET P/Invoke ile dogrulandi). Anahtar yonetimi bu
    yuzden PAROLA-TURETMELI olarak secildi; DPAPI yalnizca koruma
    yonunde calisiyor. Acilis hatasinin istisna olarak yukselmesi
    beklenen davranis. }
  tam := False;
  try
    VDbDapiUnprotect(blob, unblob);
    tam := True;
  except
    on E: Exception do
      WriteLn('   BILGI: CryptUnprotectData bu makinede calismiyor (',
        Copy(E.Message, 1, 60), ') - parola kipi kullanilacak');
  end;
  if not tam then
    WriteLn('   BILGI: DPAPI acma dogrulanamadi (bilinen ortam engeli)');

  // ------------------------------------------------------------------
  Grp('STANDART TEST VEKTORLERI (elle yazilmis kripto kanitsiz sayilmaz)');
  // RFC 4231 Test Case 1: key = 0x0b x20, data = "Hi There"
  tmpS := '';
  for i := 1 to 20 do
    tmpS := tmpS + #11;
  plain := BytesOf(tmpS);
  tmpB := BytesOf('Hi There');
  key := VDbCryptHmacSha256(plain, tmpB);
  Chk('RFC 4231-1 HMAC-SHA256',
    Hex(key, 32) = 'B0344C61D8DB38535CA8AFCEAF0BF12B8' +
                   '81DC200C9833DA726E9376C2E32CFF7',
    Hex(key, 32));

  // RFC 4231 Test Case 2: key = "Jefe", data = "what do ya want for nothing?"
  tmpS := 'Jefe';
  plain := BytesOf(tmpS);
  tmpB := BytesOf('what do ya want for nothing?');
  key := VDbCryptHmacSha256(plain, tmpB);
  Chk('RFC 4231-2 HMAC-SHA256',
    Hex(key, 32) = '5BDCC146BF60754E6A042426089575C7' +
                   '5A003F089D2739839DEC58B964EC3843',
    Hex(key, 32));

  // RFC 7914 / PBKDF2-HMAC-SHA256:
  //   P="passwd" S="salt" c=1 dkLen=64
  plain := BytesOf('passwd');
  tmpB := BytesOf('salt');
  key := VDbPbkdf2Sha256(plain, tmpB, 1, 64);
  Chk('RFC 7914 PBKDF2-HMAC-SHA256 (c=1, dkLen=64)',
    Hex(key, 64) = '55AC046E56E3089FEC1691C22544B605F94185216DDE0465' +
                   'E68B9D57C20DACBC49CA9CCCF179B645991664B39D77EF317C' +
                   '71B845B1E30BD509112041D3A19783',
    Hex(key, 16));

  // ayni girdi -> ayni cikti (deterministik)
  SetLength(blob, 0);
  blob := VDbPbkdf2Sha256(plain, tmpB, 1, 64);
  Chk('PBKDF2 deterministik', VDbCryptEqual(key, blob));

  // ------------------------------------------------------------------
  Grp('FIPS-197 AES-256 TEK BLOK (Appendix C.3)');
  //   Nk = 8, Nr = 14
  //   Key        = 603deb1015ca71be2b73aef0857d7781
  //                 1f352c073b6108d72d9810a30914dff4
  //   Plaintext  = 6bc1bee22e409f96e93d7e117393172a
  //   Ciphertext = f3eed1bdb5d2a03c064b5a7e3db181f8
  // Bu vektor, HMAC/PBKDF2 vektorlerinden bagimsiz olarak ham blok
  // sifreleme rutinini dogrular; CTR kaydini degil AES cekirdegini olcer.
  key := HexBytes('603deb1015ca71be2b73aef0857d7781' +
                  '1f352c073b6108d72d9810a30914dff4');
  plain := HexBytes('6bc1bee22e409f96e93d7e117393172a');
  blob := VDbCryptAes256Block(key, plain);
  Chk('FIPS-197 C.3 AES-256 blok sifreleme',
    Hex(blob, 16) = 'F3EED1BDB5D2A03C064B5A7E3DB181F8',
    Hex(blob, 16));

  // Anahtarın bir baytı bozulursa sonuç da değişmeli (yanlış anahtar
  // kabul eden bir rutin bu testi geçemez).
  unblob := Copy(key, 0, Length(key));
  if unblob = nil then SetLength(unblob, Length(key));
  q := @unblob[0];
  q[0] := q[0] xor $01;
  back := VDbCryptAes256Block(unblob, plain);
  Chk('FIPS-197 C.3 bozuk anahtar FARKLI sonuc verir',
    not VDbCryptEqual(blob, back), Hex(back, 4));

  // ------------------------------------------------------------------
  Grp('PAROLA -> ANAHTAR');
  Chk('rastgele tuz uretildi', VDbCryptNewSalt(tmpB));
  Chk('tuz 16 bayt', Length(tmpB) = VDB_SALT_LEN, IntToStr(Length(tmpB)));
  Chk('kisa parola reddedilir', not VDbCryptPasswordLongEnough('kisa1'));
  Chk('yeterli parola kabul edilir', VDbCryptPasswordLongEnough('dogru-parola-123'));

  tmpS := 'dogru-parola-123';
  key := VDbCryptDeriveKey(tmpS, tmpB, 1000);
  Chk('paroladan 32 baytlik anahtar', Length(key) = VDB_KEY_LEN,
    IntToStr(Length(key)));
  blob := VDbCryptVerifier(key);
  Chk('dogrulayici 32 bayt', Length(blob) = VDB_TAG_LEN);

  Chk('dogru parola dogrulandi',
    VDbCryptKeyFromPassword(tmpS, tmpB, 1000, blob, unblob));
  { Anahtarin TAMAMININ sifirlendigini isaretci ile dogrula; tek bir
    bayta bakmak yetersizdir. }
  if SifirMi(unblob) then
    Ok('ANAHTAR DOGRULAMA SONRASI SILINDI (sifreleme icin kullanilamaz)', '')
  else
    No('ANAHTAR DOGRULAMA SONRASI SILINDI (sifreleme icin kullanilamaz)',
      'anahtar bellekte sifirlanMADI!');
  tmpS := 'yanlis-parola';
  Chk('yanlis parola reddedildi',
    not VDbCryptKeyFromPassword(tmpS, tmpB, 1000, blob, unblob));
  VDbCryptNewSalt(tmpB);
  unblob := VDbCryptDeriveKey('dogru-parola-123', tmpB, 1000);
  back := VDbCryptVerifier(unblob);
  Chk('farkli tuz -> farkli dogrulayici (yani farkli anahtar)',
    not VDbCryptEqual(blob, back));

  // ------------------------------------------------------------------
  Grp('.key DOSYASI (dosyada sir yok)');
  // Yaz -> dogru parola ile oku -> ayni anahtar
  keyPath := IncludeTrailingPathDelimiter(GetTempDir) + 'vdbtest_a.key';
  keyPath2 := IncludeTrailingPathDelimiter(GetTempDir) + 'vdbtest_b.key';
  DeleteFile(keyPath);
  DeleteFile(keyPath2);

  tmpS := 'dogru-parola-123';
  Chk('.key yazildi', VDbKeyFileWrite(keyPath, tmpS, key, iter));
  Chk('.key dosyasi olustu', FileExists(keyPath));

  unblob := nil;
  Chk('.key dogru parola ile okundu', VDbKeyFileRead(keyPath, tmpS, unblob, iter2));
  Chk('.key okunan anahtar 32 bayt', Length(unblob) = VDB_KEY_LEN,
    IntToStr(Length(unblob)));
  Chk('.key yazilan anahtar = okunan anahtar', VDbCryptEqual(key, unblob));
  Chk('.key iterasyon korundu', iter2 = iter, IntToStr(iter2));

  // Dosyada SIR olmamali: 32 baytlik dogrulayici disinda anahtar
  // materyali bulunmamali. Dosya boyutu tam olarak
  // 10 + 16 + 32 = 58 bayt olmali.
  tam := false;
  tam := DosyaBoyutu(keyPath) = 58;
  Chk('.key dosyasi 58 bayt (10+16+32, sır yok)', tam,
    IntToStr(DosyaBoyutu(keyPath)));

  // Yazilan dogrulayici gercekten dosyada ve anahtarla eslesiyor mu?
  // (dosyadan okunup dogrulanabiliyor = "sir yok" iddiasinin kaniti)
  blob := VDbCryptVerifier(key);
  Chk('.key icindeki dogrulayici bu anahtarla eslesiyor',
    VDbCryptEqual(blob, VerifierDosyadan(keyPath)),
    Hex(blob, 8));

  // Ayni parola -> ayni anahtar (deterministik okuma)
  back := nil;
  VDbKeyFileRead(keyPath, tmpS, back, iter2);
  Chk('.key ayni parola -> ayni anahtar (deterministik)',
    VDbCryptEqual(unblob, back));

  // Yanlis parola reddedilmeli, anahtar uretilmemeli
  tam := True;
  unblob := nil;
  try
    tam := not VDbKeyFileRead(keyPath, 'yanlis-parola-999', unblob, iter2);
  except
    on E: Exception do tam := False;
  end;
  Chk('.key yanlis parola REDDEDILDI', tam);
  Chk('.key yanlis parolada anahtar URETILMEDI', Length(unblob) = 0,
    IntToStr(Length(unblob)));

  { Reddetme iki bicimde olabilir: False donmesi ya da istisna.
    Test ikisini de kabul etmeli. }
  tam := False;
  try
    tam := not VDbKeyFileWrite(keyPath2, 'kisa', blob, iter2);
  except
    on E: Exception do tam := True;
  end;
  Chk('.key kisa parola ile yazilamaz', tam);

  // Bozuk imzali dosya reddedilmeli
  Chk('.key bozuk dosya yazildi (imza testi)',
    BozukImzaliKeyDosyasi(keyPath2));
  tam := False;
  try
    tam := not VDbKeyFileRead(keyPath2, tmpS, unblob, iter2);
  except
    on E: Exception do tam := True;
  end;
  Chk('.key bozuk imza REDDEDILDI', tam);
  Chk('.key bozuk dosyada anahtar URETILMEDI', Length(unblob) = 0,
    IntToStr(Length(unblob)));

  // Kopyalanmis dosya ayni anahtari vermeli (dosyanin tasinabilirligi)
  Chk('.key kopyalandi', DosyaKopyala(keyPath, keyPath2));
  Chk('.key kopyasi ayni anahtari verir',
    VDbKeyFileRead(keyPath2, tmpS, unblob, iter2) and
    VDbCryptEqual(unblob, key));
  Chk('.key kopyasi dosya boyutu ayni',
    DosyaBoyutu(keyPath) = DosyaBoyutu(keyPath2));

  DeleteFile(keyPath);
  DeleteFile(keyPath2);

  WriteLn;
  WriteLn('========================================');
  WriteLn('SONUC: gecen=', nPass, '  kalan=', nFail);
  if nFail = 0 then WriteLn('TUM Kripto TESTLERI GECTI')
  else WriteLn('HATA VAR');
  if nFail > 0 then Halt(1);
end.
