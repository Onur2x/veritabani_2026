﻿program t;
{$mode delphi}{$H+}
uses SysUtils, Classes, VDbCore, VDbTable, VDbSql, VDbAst, VDbParser, VDbExecutor;
var Kv: TVDb; Tb: TVTableDb; Sq: TVSql; R: TSqlResult; d: string;
begin
  d := GetTempDir(False) + 'vdbstragg';
  ForceDirectories(d);
  Kv := TVDb.Create; Tb := TVTableDb.Create(Kv); Sq := TVSql.Create(Tb);
  try
    Kv.Open(d); Tb.Open(d);
    Sq.Exec('CREATE TABLE ag(id INTEGER PRIMARY KEY, v INTEGER)');
    Sq.Exec('INSERT INTO ag VALUES(1,10),(2,20),(3,10),(4,30),(5,20),(6,NULL)');
    WriteLn('--- GROUP BY olmadan ---');
    try
      R := Sq.Exec('SELECT STRING_AGG(v, '','') FROM ag');
      WriteLn('sonuc: [', R.Rows[0][0], ']');
    except on E: Exception do WriteLn('HATA: ', E.Message); end;
    WriteLn('--- GROUP BY ile ---');
    try
      R := Sq.Exec('SELECT STRING_AGG(v, '','') FROM ag GROUP BY id');
      WriteLn('satir: ', Length(R.Rows));
    except on E: Exception do WriteLn('HATA: ', E.Message); end;
  finally
    Sq.Free; Tb.Free; Kv.Free;
  end;
end.
