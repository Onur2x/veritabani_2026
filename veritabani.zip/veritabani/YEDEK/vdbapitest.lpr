program vdbapitest;

{ VDb API DLL TESTI
  ---------------------------------------------------------------------------
  Bu test DLL'i BAGLAMAZ (unit olarak eklemez); `LoadLibrary` ile
  DINAMIK olarak yukler ve `GetProcAddress` ile fonksiyonlari adres
  alir. Boylece test, gercekten harici bir programin yaptigi seyi yapar:

    * DLL'de GERCEKTEN export edilmis fonksiyonlari kullanir,
    * isim imzalarini (stdcall) dogru cagirir,
    * hata donen yollari test eder,
    * bozuk handle kullanmanin CRASH olmadigini gorur.

  Boylece "DLL derlendi" degil, "DLL bir baska programdan DAHIL
  calisiyor" kanitlanir.

  Kullanim:  vdbapitest.exe [veritabani-klasoru]
  klasor verilmezse gecici klasor kullanilir.
}

{$mode delphi}{$H+}

uses
  SysUtils, Windows, Classes;

const
  DLL_NAME = 'vdbapi.dll';

  { hata kodlari (vdbapi.h ile ayni) }
  VDB_OK            =  0;
  VDB_E_BAD_HANDLE = -2;
  VDB_E_OPEN       = -3;
  VDB_E_SQL        = -4;
  VDB_E_BUFFER     = -6;
  VDB_E_ENGINE     = -8;
  VDB_E_NOT_FOUND  = -9;
  VDB_E_DUPLICATE  = -10;
  VDB_E_CONSTRAINT = -11;

type
  { --- dinamik yuklenen API --- }
  TVdbOpen          = function(APath: PAnsiChar; ASyncWrite: LongInt): LongWord; stdcall;
  TVdbClose         = procedure(AHandle: LongWord); stdcall;
  TVdbCloseAll      = procedure; stdcall;
  TVdbCount         = function(AHandle: LongWord): LongInt; stdcall;
  TVdbPut           = function(AHandle: LongWord; AKey: Int64; AData: PByte;
                        ALen: LongInt): LongInt; stdcall;
  TVdbGet           = function(AHandle: LongWord; AKey: Int64; AData: PByte;
                        ALen: LongInt): LongInt; stdcall;
  TVdbExists        = function(AHandle: LongWord; AKey: Int64): LongInt; stdcall;
  TVdbDelete        = function(AHandle: LongWord; AKey: Int64): LongInt; stdcall;
  TVdbFlush         = procedure(AHandle: LongWord); stdcall;
  TVdbExec          = function(AHandle: LongWord; ASql: PAnsiChar;
                        AFlags: LongInt): LongWord; stdcall;
  TVdbFieldCount    = function(AHandle: LongWord): LongInt; stdcall;
  TVdbRowCount      = function(AHandle: LongWord): LongInt; stdcall;
  TVdbFieldName     = function(AHandle: LongWord; ACol: LongInt): PAnsiChar; stdcall;
  TVdbValue         = function(AHandle: LongWord; ARow, ACol: LongInt): PAnsiChar; stdcall;
  TVdbAffected      = function(AHandle: LongWord): LongInt; stdcall;
  TVdbStmts         = function(AHandle: LongWord): LongInt; stdcall;
  TVdbResultMsg     = function(AHandle: LongWord): PAnsiChar; stdcall;
  TVdbResultFree    = procedure(AHandle: LongWord); stdcall;
  TVdbVerify        = function(AHandle: LongWord; AReport: PAnsiChar;
                        AMax: LongInt): LongInt; stdcall;
  TVdbWalHas        = function(AHandle: LongWord): LongInt; stdcall;
  TVdbWalRecordCount= function(AHandle: LongWord): LongInt; stdcall;
  TVdbWalWrite      = function(AHandle: LongWord; AKey: Int64; AData: PByte;
                        ALen: LongInt): LongInt; stdcall;
  TVdbWalWriteDel   = function(AHandle: LongWord; AKey: Int64): LongInt; stdcall;
  TVdbWalReplay     = function(AHandle: LongWord): LongInt; stdcall;
  TVdbWalCheckpoint = function(AHandle: LongWord): LongInt; stdcall;
  TVdbWalSetAuto   = function(AHandle: LongWord; AEnable: LongInt): LongInt; stdcall;
  TVdbWalIsAuto    = function(AHandle: LongWord): LongInt; stdcall;
  TVdbWalAutoCount = function(AHandle: LongWord): LongInt; stdcall;
  TVdbFileSize      = function(AHandle: LongWord): Int64; stdcall;
  TVdbDeadBytes     = function(AHandle: LongWord): Int64; stdcall;
  TVdbAutoCompact   = function(AHandle: LongWord; AOld, ANew: PInt64): LongInt; stdcall;
  TVdbApiVersion    = function: LongWord; stdcall;
  TVdbVersion       = function: PAnsiChar; stdcall;
  TVdbLastError     = function: PAnsiChar; stdcall;
  TVdbErrCodeGet    = function: LongInt; stdcall;
  { --- CDC / Time Travel (2026-10-06, poll) --- }
  TVdbCdcStart      = function(AHandle: LongWord): LongInt; stdcall;
  TVdbCdcStop       = function(AHandle: LongWord): LongInt; stdcall;
  TVdbCdcPollSize   = function(AHandle: LongWord): LongInt; stdcall;
  TVdbCdcPoll       = function(AHandle: LongWord; ABuf: PAnsiChar;
                        ALen: LongInt): LongInt; stdcall;
  TVdbCdcStats      = function(AHandle: LongWord; AEvents, ASkipped,
                        APending, ADropped: PInteger): LongInt; stdcall;
  TVdbValueAt       = function(AHandle: LongWord; ATable, APk: PAnsiChar;
                        ASeq: LongInt; ABuf: PAnsiChar;
                        ALen: LongInt): LongInt; stdcall;
  TVdbHistoryCount  = function(AHandle: LongWord): LongInt; stdcall;

var
  H: THandle;
  nPass, nFail, nGrp: Integer;
  nExport: Integer;
  grpName: string;
  tmpDir: string;

  { API isaretcileri }
  aOpen: TVdbOpen;
  aClose: TVdbClose;
  aCloseAll: TVdbCloseAll;
  aCount: TVdbCount;
  aPut: TVdbPut;
  aGet: TVdbGet;
  aExists: TVdbExists;
  aDelete: TVdbDelete;
  aFlush: TVdbFlush;
  aExec: TVdbExec;
  aFieldCount: TVdbFieldCount;
  aRowCount: TVdbRowCount;
  aFieldName: TVdbFieldName;
  aValue: TVdbValue;
  aAffected: TVdbAffected;
  aStmts: TVdbStmts;
  aResultMsg: TVdbResultMsg;
  aResultFree: TVdbResultFree;
  aVerify: TVdbVerify;
  aWalHas: TVdbWalHas;
  aWalRecordCount: TVdbWalRecordCount;
  aWalWrite: TVdbWalWrite;
  aWalWriteDel: TVdbWalWriteDel;
  aWalReplay: TVdbWalReplay;
  aWalCheckpoint: TVdbWalCheckpoint;
  aWalSetAuto: TVdbWalSetAuto;
  aWalIsAuto: TVdbWalIsAuto;
  aWalAutoCount: TVdbWalAutoCount;
  aFileSize: TVdbFileSize;
  aDeadBytes: TVdbDeadBytes;
  aAutoCompact: TVdbAutoCompact;
  aApiVersion: TVdbApiVersion;
  aVersion: TVdbVersion;
  aLastError: TVdbLastError;
  aErrCode: TVdbErrCodeGet;
  aCdcStart: TVdbCdcStart;
  aCdcStop: TVdbCdcStop;
  aCdcPollSize: TVdbCdcPollSize;
  aCdcPoll: TVdbCdcPoll;
  aCdcStats: TVdbCdcStats;
  aValueAt: TVdbValueAt;
  aHistoryCount: TVdbHistoryCount;

{ ------------------------------------------------------------- yardimcilar }

procedure Grp(const N: string);
begin
  Inc(nGrp);
  grpName := N;
  WriteLn;
  WriteLn('== ', nGrp, '. ', N);
end;

procedure Ok(const Nm, E: string);
begin
  Inc(nPass);
  if E = '' then WriteLn('   OK   ', Nm)
  else WriteLn('   OK   ', Nm, '   [', E, ']');
end;

procedure No(const Nm, E: string);
begin
  Inc(nFail);
  WriteLn('   FAIL ', Nm, '   [', E, ']  (grup: ', grpName, ')');
end;

procedure Tst(const Nm: string; Cond: Boolean; const E: string = '');
begin
  if Cond then Ok(Nm, E) else No(Nm, E);
end;

function ErrS: string;
begin
  Result := 'kod=' + IntToStr(aErrCode()) + ' "' + String(aLastError()) + '"';
end;

{ Bayt dizisini onaltilik metne cevirir. Iki tamponu karsilastirirken
  "esit degil" demek yetmez; FARKIN NEREDE oldugunu gormek gerekir. }
function HexOf(const A: array of Byte; ACount: Integer): string;
var
  I: Integer;
begin
  Result := '';
  for I := 0 to ACount - 1 do
  begin
    if I > 0 then Result := Result + ' ';
    Result := Result + IntToHex(A[I], 2);
  end;
end;

function BytesEq(const A: array of Byte; ACount: Integer;
  const B: AnsiString): Boolean;
{ NOT: `CompareMem(p1, p2, len) = 0` yazimi FPC'de derlenMIYOR
  ("Incompatible types: got Boolean expected LongInt") - Boolean ile
  tamsayi karsilastirmasi FPC'de yasak. Bu yuzden bayt bayt elle
  karsilastiriliyor. }
var
  I: Integer;
begin
  Result := (ACount = Length(B));
  if not Result then Exit;
  for I := 1 to ACount do
    if A[I - 1] <> Byte(B[I]) then
    begin
      Result := False;
      Break;
    end;
end;

function Cmp2(const A: array of Byte; ACount: Integer;
  const B: AnsiString): string;
// A dizisi ile B metni karsilastirir; fark varsa IKI tarafi da onaltilik
// olarak yazar, boylece gercekten neyin bozuldugu gorulur.
var
  I: Integer;
begin
  if BytesEq(A, ACount, B) then
    Result := 'ayni'
  else
  begin
    Result := 'FARK okunan=[' + HexOf(A, ACount) + '] beklenen=[';
    for I := 1 to Length(B) do
    begin
      if I > 1 then Result := Result + ' ';
      Result := Result + IntToHex(Byte(B[I]), 2);
    end;
    Result := Result + ']';
  end;
end;


{ Bir export adresini cozer. Bulunamazsa testi kesin hata ile bitirir:
  eksik export sessizce gecmemeli. }
function Req(const Name: string): Pointer;
begin
  Result := GetProcAddress(H, PChar(Name));
  if Result = nil then
  begin
    WriteLn;
    WriteLn('HATA: DLL icinde export bulunamadi: ', Name);
    WriteLn('Bu, ABI taniminin bozuk oldugu anlamina gelir.');
    Halt(2);
  end;
  // cozulen export sayisini say: elle yazilan sabit sayinin
  // gercekten tutmasi mumkun degil, Req'in saydigi DEGER her zaman
  // ABI'nin gercekten cozulen genisligidir.
  Inc(nExport);
end;

{ --------------------------------------------------------------- testler }

procedure TestSurum;
begin
  Grp('DLL yuke + surum');
  Tst('surum 1.1', aApiVersion() = $00010100,
    '0x' + IntToHex(aApiVersion(), 8));
  Tst('VdbVersion metni dolu', aVersion() <> nil, String(aVersion()));
end;

procedure TestAcilis(const Dir: string);
var
  db: LongWord;
  p: string;
begin
  Grp('Acilis / hata yollari');
  // yol bos
  db := aOpen(nil, 0);
  Tst('yol NULL -> handle 0', db = 0);
  Tst('yol NULL -> hata kodu', aErrCode() = VDB_E_OPEN, ErrS);
  { NOT: motor, verilmayan .odb yolunu OLUSTURUR (yeni veritabani demektir);
    yani "dosya yok" hatasi bu yolla UYARILAMAZ. Gercekten acilamayan
    bir yol deniyoruz: olmayan surucu. }
  p := 'Q:\olmayan_surucu\db.odb';
  db := aOpen(PChar(p), 0);
  Tst('olmayan yol -> handle 0', db = 0);
  Tst('olmayan yol -> acik hata', aErrCode() = VDB_E_OPEN, ErrS);
  { Tersine: motor YENI veritabani yaratabilmeli. }
  db := aOpen(PChar(Dir + '\yeni.odb'), 1);
  Tst('yeni veritabani yaratilabiliyor', db <> 0, ErrS);
  if db <> 0 then aClose(db);
  // ayni dosyayi IKINCI kez acmak kilitlenmis olmali (dosya kilidi)
  aOpen(PChar(Dir + '\kilit.odb'), 1);
  db := aOpen(PChar(Dir + '\kilit.odb'), 1);
  Tst('ikinci acik reddedildi (dosya kilidi)', db = 0);
  Tst('kilit hatasi VDB_E_OPEN', aErrCode() = VDB_E_OPEN, ErrS);
  aCloseAll;
  // yeniden acilabilmeli
  db := aOpen(PChar(Dir + '\kilit.odb'), 1);
  Tst('CloseAll sonra tekrar acilabiliyor', db <> 0, 'handle=' + IntToStr(db));
  aClose(db);
  // bozuk handle crash OLMAZ
  Tst('bozuk handle 0xDEAD -> hata', aCount($DEADBEEF) = 0);
  Tst('bozuk handle hata kodu', aErrCode() = VDB_E_BAD_HANDLE, ErrS);
  Tst('bozuk handle SQL de hata', aExec($12345678, 'SELECT 1', 0) = 0);
  Tst('bozuk handle SQL hata kodu', aErrCode() = VDB_E_BAD_HANDLE, ErrS);
end;

procedure TestKV(const Dir: string);
var
  db: LongWord;
  buf: array[0..63] of Byte;
  n, need: LongInt;
  s: AnsiString;
begin
  Grp('Temel KV (bayt duzeyinde)');
  db := aOpen(PChar(Dir + '\kv.odb'), 1);
  Tst('kv veritabani acildi', db <> 0, 'handle=' + IntToStr(db));
  if db = 0 then Exit;

  // metin yaz
  s := 'merhaba dunya';
  Tst('Put metin', aPut(db, 1, PByte(@s[1]), Length(s)) = VDB_OK);
  Tst('Count 1', aCount(db) = 1, IntToStr(aCount(db)));
  Tst('Exists', aExists(db, 1) = 1);
  Tst('Exists yalnizca yok', aExists(db, 99) = 0);

  // oku
  FillChar(buf, SizeOf(buf), 0);
  n := aGet(db, 1, @buf[0], SizeOf(buf));
  Tst('Get metin uzunlugu', n = Length(s), IntToStr(n));
  Tst('Get metn icerigi',
    BytesEq(buf, Length(s), s), Cmp2(buf, Length(s), s));

  { IKI ASAMALI KULLANIM: once AData=nil ile BOYUT sorulur.
    2026-10-04: bu yol HICBIR test edilmemisti ve istemci birimi
    (VDBClient.GetStr) tam olarak bunu kullaniyordu; burada hata
    kodu (-13) donuyordu. }
  need := aGet(db, 1, nil, 0);
  Tst('Get boyut sorgusu gerekli boyutu doner', need = -Length(s),
    'donen=' + IntToStr(need) + ' (beklenen ' + IntToStr(-Length(s)) + ')');
  if (need < 0) and (need > -60) then
  begin
    need := -need;
    FillChar(buf, SizeOf(buf), 0);
    n := aGet(db, 1, @buf[0], need);
    Tst('Get iki asamali -> tam kopya', n = Length(s), IntToStr(n));
    Tst('Get iki asamali icerik dogru',
      BytesEq(buf, Length(s), s), Cmp2(buf, Length(s), s));
  end;
  if (need > 0) and (need < 60) then
  begin
    FillChar(buf, SizeOf(buf), 0);
    n := aGet(db, 1, @buf[0], need);
    Tst('Get boyut kadar tampon -> tam kopya', n = Length(s),
      IntToStr(n));
    Tst('Get iki asamali icerik dogru',
      BytesEq(buf, Length(s), s), Cmp2(buf, Length(s), s));
  end;
  // boyut sorgusu anahtar yoksa da -1 vermeli
  need := aGet(db, 4242, nil, 0);
  Tst('Get boyut sorgusu olmayan anahtar -> -1', need = -1, IntToStr(need));



  // tampon kucuk: gerekli boyut NEGATIF donmeli
  n := aGet(db, 1, @buf[0], 3);
  Tst('Get kucuk tampon -> gerekli boyut', n = -Length(s), IntToStr(n));

  // olmayan anahtar
  n := aGet(db, 777, @buf[0], SizeOf(buf));
  Tst('Get olmayan anahtar -> -1', n = -1, IntToStr(n));

  // ikinci kez yaz (ustune)
  s := 'yeni deger';
  aPut(db, 1, PByte(@s[1]), Length(s));
  n := aGet(db, 1, @buf[0], SizeOf(buf));
  Tst('ustune yazma', (n = Length(s)) and
    BytesEq(buf, n, s), Cmp2(buf, n, s));

  Tst('ustune yazma Count degismedi', aCount(db) = 1, IntToStr(aCount(db)));

  // BOS deger (null isaretci + 0 uzunluk)
  Tst('Put bos deger', aPut(db, 2, nil, 0) = VDB_OK);
  n := aGet(db, 2, @buf[0], SizeOf(buf));
  Tst('Get bos deger -> 0', n = 0, IntToStr(n));
  Tst('bos deger anahtari var', aExists(db, 2) = 1);

  // ikili veri (0 ve #255 iceren BLOB) - metin olmayan veri
  buf[0] := 0; buf[1] := 255; buf[2] := 0; buf[3] := 128;
  Tst('Put ikili veri', aPut(db, 3, @buf[0], 4) = VDB_OK);
  FillChar(buf, SizeOf(buf), 0);
  n := aGet(db, 3, @buf[0], SizeOf(buf));
  Tst('Get ikili veri uzunluk', n = 4, IntToStr(n));
  Tst('Get ikili veri baytlar ayni',
    (buf[0] = 0) and (buf[1] = 255) and (buf[2] = 0) and (buf[3] = 128),
    IntToStr(buf[0]) + ',' + IntToStr(buf[1]) + ',' +
    IntToStr(buf[2]) + ',' + IntToStr(buf[3]));

  // sil
  Tst('Delete var olan', aDelete(db, 3) = VDB_OK);
  Tst('Delete sonrasi Count', aCount(db) = 2, IntToStr(aCount(db)));
  Tst('Delete olmayan -> VDB_E_NOT_FOUND', aDelete(db, 3) = VDB_E_NOT_FOUND,
    IntToStr(aDelete(db, 3)));

  // Flush + dosya olustu mu
  aFlush(db);
  Tst('dosya olustu', FileExists(Dir + '\kv.odb'));
  Tst('dosya boyutu > 0', aFileSize(db) > 0, IntToStr(aFileSize(db)) + ' bayt');
  aClose(db);
end;

procedure TestUtf8(const Dir: string);
var
  db: LongWord;
  s: AnsiString;
  buf: array[0..127] of Byte;
  n: LongInt;
begin
  Grp('UTF-8 metin (Turkce karakter)');
  db := aOpen(PChar(Dir + '\utf.odb'), 1);
  if db = 0 then
  begin
    No('utf veritabani acildi', ErrS);
    Exit;
  end;
  { UTF-8 baytlari ELLE kurulur: kaynak dosya ASCII, ayrica
    UTF8Encode() TEK BASINA duran bir 0xC7 baytini '?' ile degistirir
    (gecersiz UTF-8 dizisi). Dogrudan bayt yaziyoruz:
      c-cedil  = C3 A7 , s-cedil = C5 9F , g-breve = C4 9F }
  s := 'cagla' + #$C3#$A7 + #$C5#$9F + #$C4#$9F;
  Tst('Put UTF-8', aPut(db, 5, PByte(@s[1]), Length(s)) = VDB_OK);
  n := aGet(db, 5, @buf[0], SizeOf(buf));
  Tst('Get UTF-8 uzunluk', n = Length(s), IntToStr(n) + ' vs ' + IntToStr(Length(s)));
  Tst('Get UTF-8 baytlar ayni', BytesEq(buf, n, s),
    Cmp2(buf, n, s));
  aClose(db);
end;

procedure TestSql(const Dir: string);
var
  db, r: LongWord;
  i, nf, nr: LongInt;
  res: TStringList;
begin
  Grp('SQL: DDL / DML / SELECT');
  db := aOpen(PChar(Dir + '\sql.odb'), 1);
  if db = 0 then
  begin
    No('sql veritabani acildi', ErrS);
    Exit;
  end;

  // CREATE
  r := aExec(db, 'CREATE TABLE kisi (id INTEGER PRIMARY KEY, ad TEXT NOT NULL, yas INTEGER)', 0);
  Tst('CREATE TABLE', (r <> 0) and (aErrCode() = VDB_OK), ErrS);
  if r > 0 then aResultFree(r);

  // INSERT
  r := aExec(db, 'INSERT INTO kisi (id, ad, yas) VALUES (1, ''Ali'', 30)', 0);
  Tst('INSERT 1 satir', (r <> 0) and (aAffected(r) = 1), 'affected=' + IntToStr(aAffected(r)));
  if r > 0 then aResultFree(r);

  // coklu INSERT
  r := aExec(db, 'INSERT INTO kisi (id, ad, yas) VALUES (2, ''Veli'', 25), (3, ''Zeynep'', 41)', 0);
  Tst('coklu INSERT 2 satir', (r <> 0) and (aAffected(r) = 2), 'affected=' + IntToStr(aAffected(r)));
  if r > 0 then aResultFree(r);

  // NOT NULL ihlali -> hata kodu
  r := aExec(db, 'INSERT INTO kisi (id, ad, yas) VALUES (4, NULL, 10)', 0);
  Tst('NOT NULL ihlali yakalandi', r = 0);
  Tst('NOT NULL hata kodu CONSTRAINT', aErrCode() = VDB_E_CONSTRAINT, ErrS);

  // PK cakismasi
  r := aExec(db, 'INSERT INTO kisi (id, ad, yas) VALUES (1, ''Tekrar'', 1)', 0);
  Tst('PK cakismasi yakalandi', r = 0);
  Tst('PK hata kodu DUPLICATE', aErrCode() = VDB_E_DUPLICATE, ErrS);

  // SELECT
  r := aExec(db, 'SELECT id, ad, yas FROM kisi ORDER BY id', 0);
  Tst('SELECT basarili', r <> 0, ErrS);
  if r > 0 then
  begin
    nf := aFieldCount(r);
    nr := aRowCount(r);
    Tst('SELECT 3 kolon', nf = 3, IntToStr(nf));
    Tst('SELECT 3 satir', nr = 3, IntToStr(nr));
    Tst('kolon 0 adi "id"', String(aFieldName(r, 0)) = 'id', String(aFieldName(r, 0)));
    Tst('kolon 1 adi "ad"', String(aFieldName(r, 1)) = 'ad', String(aFieldName(r, 1)));
    Tst('satir 1 / kolon 1 = Veli',
      String(aValue(r, 1, 1)) = 'Veli', String(aValue(r, 1, 1)));
    Tst('satir 2 / kolon 1 = Zeynep',
      String(aValue(r, 2, 1)) = 'Zeynep', String(aValue(r, 2, 1)));
    Tst('satir 0 / kolon 2 = 30',
      String(aValue(r, 0, 2)) = '30', String(aValue(r, 0, 2)));
    aResultFree(r);
  end;

  // sonuc seti sinir kontrolu -> crash degil hata
  r := aExec(db, 'SELECT id FROM kisi', 0);
  if r > 0 then
  begin
    Tst('kolon indeksi disinda -> nil',
      aFieldName(r, 99) = nil, 'hata=' + ErrS);
    Tst('satir indeksi disinda -> nil',
      aValue(r, 99, 0) = nil);
    Tst('negatif indeks -> nil', aValue(r, -1, 0) = nil);
    aResultFree(r);
  end;
  Tst('gecersiz sonuc handle serbest birakma crash olmadi', True, '');
  aResultFree(0);   // 0 gecersiz; crash olmamali

  // UPDATE / DELETE
  r := aExec(db, 'UPDATE kisi SET yas = 31 WHERE id = 1', 0);
  Tst('UPDATE 1 satir', (r <> 0) and (aAffected(r) = 1), 'affected=' + IntToStr(aAffected(r)));
  if r > 0 then aResultFree(r);
  r := aExec(db, 'DELETE FROM kisi WHERE id = 3', 0);
  Tst('DELETE 1 satir', (r <> 0) and (aAffected(r) = 1), 'affected=' + IntToStr(aAffected(r)));
  if r > 0 then aResultFree(r);

  // cok cumleli betik + otomatik transaction
  r := aExec(db, 'BEGIN; INSERT INTO kisi (id, ad, yas) VALUES (10, ''Betik'', 1); COMMIT;', 1);
  Tst('cok cumleli betik', (r <> 0) and (aStmts(r) >= 3), 'stmts=' + IntToStr(aStmts(r)));
  if r > 0 then aResultFree(r);
  r := aExec(db, 'SELECT COUNT(*) FROM kisi', 0);
  if r > 0 then
  begin
    Tst('betik sonrasi kayit eklendi',
      String(aValue(r, 0, 0)) = '3', 'count=' + String(aValue(r, 0, 0)));
    aResultFree(r);
  end;

  // hatali cumlede hicbiri uygulanmamali (atomiklik)
  r := aExec(db, 'INSERT INTO kisi (id, ad) VALUES (20, ''H1''); INSERT INTO kisi (id, ad) VALUES (20, ''H2'');', 1);
  Tst('atomik hata: betik durdu', r = 0, ErrS);
  r := aExec(db, 'SELECT COUNT(*) FROM kisi', 0);
  if r > 0 then
  begin
    Tst('atomik hata: hicbiri yazilmadi',
      String(aValue(r, 0, 0)) = '3', 'count=' + String(aValue(r, 0, 0)));
    aResultFree(r);
  end;

  // sema sorgulari
  r := aExec(db, 'DESCRIBE kisi', 0);
  Tst('DESCRIBE calisti', r <> 0, ErrS);
  if r > 0 then
  begin
    Tst('DESCRIBE 8 kolon dondurdu', aFieldCount(r) = 8, IntToStr(aFieldCount(r)));
    Tst('DESCRIBE 3 satir', aRowCount(r) = 3, IntToStr(aRowCount(r)));
    aResultFree(r);
  end;
  r := aExec(db, 'SHOW INDEXES FROM kisi', 0);
  Tst('SHOW INDEXES calisti', r <> 0, ErrS);
  if r > 0 then aResultFree(r);
  r := aExec(db, 'SHOW CREATE TABLE kisi', 0);
  Tst('SHOW CREATE TABLE calisti', r <> 0, ErrS);
  if r > 0 then
  begin
    Tst('CREATE TABLE metni "CREATE TABLE" ile basliyor',
      Pos('CREATE TABLE', String(aValue(r, 0, 0))) = 1,
      Copy(String(aValue(r, 0, 0)), 1, 50));
    aResultFree(r);
  end;

  // sonuc mesaji bos olmamali (yoksa yok sayilir ama crash etmemeli)
  r := aExec(db, 'SELECT 1', 0);
  if r > 0 then
  begin
    Ok('sonuc mesaji okunabiliyor', 'len=' + IntToStr(Length(String(aResultMsg(r)))));
    aResultFree(r);
  end;

  // NULL deger okuma
  { NULL denemesi: `ad` NOT NULL oldugu icin `yas` (NULL'a izin verir)
    kullanilir. Onceki deneme `ad` kolonuna NULL yaziyordu ve motor
    HATALI olarak reddediyordu; test de yanlis yere NULL okumayi
    bekliyordu. }
  r := aExec(db, 'INSERT INTO kisi (id, ad, yas) VALUES (30, ''BosDeger'', NULL)', 0);
  Tst('NULL satiri eklendi', r <> 0, ErrS);
  if r > 0 then aResultFree(r);
  r := aExec(db, 'SELECT yas FROM kisi WHERE id = 30', 0);
  if r > 0 then
  begin
    Tst('NULL deger hata vermeden okundu', aValue(r, 0, 0) <> nil,
      'deger="' + String(aValue(r, 0, 0)) + '"');
    aResultFree(r);
  end;

  aClose(db);
end;

procedure TestBakim(const Dir: string);
var
  db: LongWord;
  rep: array[0..255] of Char;
  o, n: Int64;
  res: TStringList;
begin
  Grp('Bakim: Verify / AutoCompact');
  db := aOpen(PChar(Dir + '\sql.odb'), 0);
  if db = 0 then
  begin
    No('bakim icin acildi', ErrS);
    Exit;
  end;
  FillChar(rep, SizeOf(rep), 0);
  Tst('Verify saglam dondu 1', aVerify(db, @rep[0], SizeOf(rep)) = 1, StrPas(@rep[0]));
  Tst('Verify raporu dolu', Length(StrPas(@rep[0])) > 0);

  // olu bayt
  Tst('DeadBytes >= 0', aDeadBytes(db) >= 0, IntToStr(aDeadBytes(db)));

  // AutoCompact
  o := 0; n := 0;
  aAutoCompact(db, @o, @n);
  Tst('AutoCompact cift deger dondu', (n > 0) and (o > 0),
    IntToStr(o) + ' -> ' + IntToStr(n));
  aClose(db);
end;

procedure TestWalAuto(const Dir: string);
{ OTOMATIK WAL: VdbWalSetAuto(hDb,1) sonrasi her Put/DeleteOnce once
  .wal'a sonra ana dosyaya yazilir. }
var
  db: LongWord;
  n: LongInt;
  buf: array[0..63] of Byte;
  s: AnsiString;
begin
  Grp('OTOMATIK WAL: VdbWalSetAuto / IsAuto / AutoCount');
  db := aOpen(PChar(Dir + '\walauto.odb'), 1);
  if db = 0 then
  begin
    No('walauto veritabani acildi', ErrS);
    Exit;
  end;

  // varsayilan KAPALI
  Tst('varsayilan otomatik WAL kapali', aWalIsAuto(db) = 0);
  s := 'x';
  aPut(db, 1, PByte(@s[1]), Length(s));
  Tst('kapali iken .wal YAZILMADI', aWalHas(db) = 0);
  Tst('kapali iken otomatik sayac 0', aWalAutoCount(db) = 0,
    IntToStr(aWalAutoCount(db)));

  // ac
  Tst('VdbWalSetAuto(1) basarili', aWalSetAuto(db, 1) = VDB_OK, ErrS);
  Tst('VdbWalIsAuto = 1', aWalIsAuto(db) = 1);

  // Put otomatik gunluge girer
  s := 'on';
  aPut(db, 10, PByte(@s[1]), Length(s));
  Tst('Put sonrasi .wal var', aWalHas(db) = 1);
  Tst('otomatik sayac 1', aWalAutoCount(db) = 1, IntToStr(aWalAutoCount(db)));
  n := aGet(db, 10, @buf[0], SizeOf(buf));
  Tst('Put ana dosyaya da yazildi', n = 2, 'Get=' + IntToStr(n));

  // Delete de gunluge girer
  aDelete(db, 10);
  Tst('Delete sonrasi sayac 2', aWalAutoCount(db) = 2,
    IntToStr(aWalAutoCount(db)));

  // kapat -> sayac sifirlanir, yeni yazma gunluge GIRMEZ
  Tst('VdbWalSetAuto(0) basarili', aWalSetAuto(db, 0) = VDB_OK, ErrS);
  Tst('VdbWalIsAuto = 0', aWalIsAuto(db) = 0);
  Tst('kapatinca sayac sifirlandi', aWalAutoCount(db) = 0,
    IntToStr(aWalAutoCount(db)));

  // bozuk handle. ABI sozlesmesi: donus VDB_E_GENERAL (-1), SPESIFIK
  // kod VdbErrCode() ile alinir. ASIL koruma: donus degeri 0 OLMAMALI -
  { yoksa "kapali" / "WAL yok" ile hata birbirine karisir ve cagiran
    taraf hatayi fark edemez. }
  Tst('bozuk handle SetAuto hata doner', aWalSetAuto(1, 1) < 0,
    IntToStr(aWalSetAuto(1, 1)));
  Tst('bozuk handle SetAuto -> BAD_HANDLE', aErrCode() = VDB_E_BAD_HANDLE, ErrS);
  Tst('bozuk handle IsAuto hata doner', aWalIsAuto(1) < 0,
    IntToStr(aWalIsAuto(1)));
  Tst('bozuk handle IsAuto -> BAD_HANDLE', aErrCode() = VDB_E_BAD_HANDLE, ErrS);
  Tst('bozuk handle AutoCount hata doner', aWalAutoCount(1) < 0,
    IntToStr(aWalAutoCount(1)));
  Tst('bozuk handle AutoCount -> BAD_HANDLE', aErrCode() = VDB_E_BAD_HANDLE, ErrS);
  Tst('bozuk handle WalHas hata doner', aWalHas(1) < 0, IntToStr(aWalHas(1)));
  Tst('bozuk handle WalHas -> BAD_HANDLE', aErrCode() = VDB_E_BAD_HANDLE, ErrS);
  Tst('bozuk handle WalRecordCount hata doner', aWalRecordCount(1) < 0,
    IntToStr(aWalRecordCount(1)));
  Tst('bozuk handle WalRecordCount -> BAD_HANDLE',
    aErrCode() = VDB_E_BAD_HANDLE, ErrS);

  aClose(db);
end;

procedure TestWal(const Dir: string);
var
  db, r: LongWord;
  buf: array[0..63] of Byte;
  n: LongInt;
  s: AnsiString;
begin
  Grp('WAL: yaz / say / replay / checkpoint');
  db := aOpen(PChar(Dir + '\wal.odb'), 1);
  if db = 0 then
  begin
    No('wal veritabani acildi', ErrS);
    Exit;
  end;
  Tst('baslangicta WAL yok', aWalHas(db) = 0);
  Tst('WAL kayit sayisi 0', aWalRecordCount(db) = 0, IntToStr(aWalRecordCount(db)));

  // WAL'a yaz: ana dosyaya YAZILMAZ
  s := 'wal-1';
  Tst('WalWrite PUT', aWalWrite(db, 1, PByte(@s[1]), Length(s)) = VDB_OK, ErrS);
  s := 'wal-2';
  Tst('WalWrite PUT 2', aWalWrite(db, 2, PByte(@s[1]), Length(s)) = VDB_OK);
  Tst('WAL dosyasi var', aWalHas(db) = 1);
  Tst('WAL 2 kayit bekliyor', aWalRecordCount(db) = 2, IntToStr(aWalRecordCount(db)));

  // replay ONCESI ana dosyada olmamali
  n := aGet(db, 1, @buf[0], SizeOf(buf));
  Tst('replay oncesi ana dosyada yok', n = -1, 'Get=' + IntToStr(n));

  // replay
  Tst('WalReplay basarili', aWalReplay(db) = VDB_OK, ErrS);
  n := aGet(db, 1, @buf[0], SizeOf(buf));
  Tst('replay sonrasi kayit 1 var', n = Length('wal-1'), IntToStr(n));
  Tst('replay sonrasi deger dogru',
    StrPas(@buf[0]) = 'wal-1', StrPas(@buf[0]));
  Tst('replay sonrasi WAL silindi', aWalHas(db) = 0);
  Tst('replay sonrasi kayit sayisi 0', aWalRecordCount(db) = 0);

  // ikinci dalga: silme kaydi + checkpoint
  aWalWriteDel(db, 1);                      // 1'i sil (gunluge)
  Tst('silme gunluge yazildi', aWalHas(db) = 1);
  Tst('WalCheckpoint basarili', aWalCheckpoint(db) = VDB_OK, ErrS);
  n := aGet(db, 1, @buf[0], SizeOf(buf));
  Tst('checkpoint sonrasi kayit 1 silinmis', n = -1, 'Get=' + IntToStr(n));
  Tst('checkpoint sonrasi WAL yok', aWalHas(db) = 0);

  // WAL bos dosyada replay hata vermemeli
  Tst('WAL yokken replay VDB_OK', aWalReplay(db) = VDB_OK, ErrS);

  aClose(db);

  // KALICILIK: dosyaya yazilip kapandi, yeniden acildi
  db := aOpen(PChar(Dir + '\wal.odb'), 0);
  if db > 0 then
  begin
    FillChar(buf, SizeOf(buf), 0);
    n := aGet(db, 2, @buf[0], SizeOf(buf));
    Tst('reopen sonrasi replay kaydi kalici',
      (n = Length('wal-2')) and (StrPas(@buf[0]) = 'wal-2'),
      'len=' + IntToStr(n) + ' deger=' + StrPas(@buf[0]));
    aClose(db);
  end
  else
    No('wal yeniden acilamadi', ErrS);
end;

procedure TestCdcTt(const Dir: string);
{ CDC (poll modu) + TIME TRAVEL:
    VdbCdcStart/Stop/PollSize/Poll/Stats + VdbValueAt/VdbHistoryCount.
  CDC parcacagi olaylari ~50ms'de bir tampona dusurur; test once
  PollSize ile URETIMI bekler, sonra Stop ile senkron tamamlatip
  hepsini Poll ile ceker. Olay paketi #30 (RS) ile ayrilmistir. }
var
  db, r: LongWord;
  i, n, need, cnt: Integer;
  got: Integer;
  buf: array[0..1023] of Byte;
  pkt: AnsiString;
  ev, skip, pend, drop: Integer;
  seqIns, seqUpd, seqDel: LongInt;
  insOld, insNew, updOld, updNew, delOld, insPk: AnsiString;
  js: AnsiString;

  { Paketi alanlarina ayirir (0 tabanli): kind/seq/table/pk/old/new }
  function PktField(const S: AnsiString; I: Integer): AnsiString;
  var
    st, p, idx: Integer;
  begin
    Result := '';
    st := 1;
    for idx := 0 to I do
    begin
      if st > Length(S) then Exit;
      p := st;
      while (p <= Length(S)) and (S[p] <> #30) do Inc(p);
      if idx = I then
      begin
        Result := Copy(S, st, p - st);
        Exit;
      end;
      st := p + 1;
    end;
  end;

begin
  Grp('CDC (poll) + TIME TRAVEL: CdcStart/Poll/Stats + ValueAt');

  db := aOpen(PChar(Dir + '\cdctt.odb'), 1);
  if db = 0 then
  begin
    No('cdctt veritabani acildi', ErrS);
    Exit;
  end;

  // ---- 1) baslamadan once CDC cagrilari acikca hata doner ----
  Tst('baslamadan PollSize hata', aCdcPollSize(db) < 0,
    IntToStr(aCdcPollSize(db)));
  Tst('baslamadan PollSize -> VDB_E_ENGINE', aErrCode() = VDB_E_ENGINE, ErrS);
  Tst('baslamadan Poll hata',
    aCdcPoll(db, @buf[0], SizeOf(buf)) < 0);
  Tst('baslamadan Poll -> VDB_E_ENGINE', aErrCode() = VDB_E_ENGINE, ErrS);
  Tst('baslamadan Stats hata',
    aCdcStats(db, @ev, @skip, @pend, @drop) < 0);
  Tst('baslamadan Stop hata', aCdcStop(db) < 0);
  Tst('bozuk handle CdcStart hata', aCdcStart(1) < 0,
    IntToStr(aCdcStart(1)));
  Tst('bozuk handle CdcStart -> BAD_HANDLE',
    aErrCode() = VDB_E_BAD_HANDLE, ErrS);

  // ---- 2) baslat + yaz (Start otomatik WAL'i acar) ----
  Tst('VdbCdcStart', aCdcStart(db) = VDB_OK, ErrS);
  Tst('Start otomatik WAL acti', aWalIsAuto(db) = 1);

  r := aExec(db, 'CREATE TABLE t(id INTEGER PRIMARY KEY, ad TEXT)', 0);
  Tst('CREATE TABLE', (r <> 0) and (aErrCode() = VDB_OK), ErrS);
  if r > 0 then aResultFree(r);

  r := aExec(db, 'INSERT INTO t(id, ad) VALUES (1, ''bir'')', 0);
  Tst('INSERT', (r <> 0) and (aAffected(r) = 1),
    'affected=' + IntToStr(aAffected(r)));
  if r > 0 then aResultFree(r);
  seqIns := aWalRecordCount(db) - 1;

  r := aExec(db, 'UPDATE t SET ad = ''bir-yeni'' WHERE id = 1', 0);
  Tst('UPDATE', (r <> 0) and (aAffected(r) = 1),
    'affected=' + IntToStr(aAffected(r)));
  if r > 0 then aResultFree(r);
  seqUpd := aWalRecordCount(db) - 1;

  r := aExec(db, 'DELETE FROM t WHERE id = 1', 0);
  Tst('DELETE', (r <> 0) and (aAffected(r) = 1),
    'affected=' + IntToStr(aAffected(r)));
  if r > 0 then aResultFree(r);
  seqDel := aWalRecordCount(db) - 1;

  Tst('WAL gecmisinde kayitlar birikti', aWalRecordCount(db) >= 4,
    IntToStr(aWalRecordCount(db)));
  Tst('HistoryCount > 0', aHistoryCount(db) > 0,
    IntToStr(aHistoryCount(db)));

  // ---- 3) olay uretimini bekle (parcacik ~50ms'de bir tarar) ----
  got := 0;
  for i := 1 to 60 do
  begin
    if aCdcPollSize(db) > 0 then
    begin
      got := 1;
      Break;
    end;
    Sleep(50);
  end;
  Tst('CDC olayi uretildi (PollSize > 0)', got = 1, '60x50ms bekledi');

  // ---- 4) kucuk tampon: VDB_E_BUFFER ve olay TUKETILMEZ ----
  n := aCdcPoll(db, @buf[0], 4);
  Tst('kucuk tampon -> VDB_E_BUFFER', n = VDB_E_BUFFER, 'n=' + IntToStr(n));
  Tst('kucuk tampon -> hata kodu VDB_E_BUFFER',
    aErrCode() = VDB_E_BUFFER, ErrS);
  Tst('olay henuz tuketilmedi (PollSize hala > 0)', aCdcPollSize(db) > 0);

  // ---- 5) Stop: kalan WAL'i isler, tampon korunur ----
  Tst('VdbCdcStop', aCdcStop(db) = VDB_OK, ErrS);

  // ---- 6) hepsini cek ve dogrula ----
  cnt := 0;
  insPk := ''; insOld := ''; insNew := '';
  updOld := ''; updNew := ''; delOld := '';
  while True do
  begin
    need := aCdcPollSize(db);
    if need <= 0 then Break;
    if need > SizeOf(buf) then
    begin
      No('olay paketi tampona sigmadi', 'boyut=' + IntToStr(need));
      Break;
    end;
    n := aCdcPoll(db, @buf[0], need);
    if n <= 0 then
    begin
      No('VdbCdcPoll', 'n=' + IntToStr(n) + ' ' + ErrS);
      Break;
    end;
    SetString(pkt, PAnsiChar(@buf[0]), n);
    Inc(cnt);
    if PktField(pkt, 2) = 't' then
    begin
      if PktField(pkt, 0) = '0' then
      begin
        insPk := PktField(pkt, 3);
        insOld := PktField(pkt, 4);
        insNew := PktField(pkt, 5);
      end
      else if PktField(pkt, 0) = '1' then
      begin
        updOld := PktField(pkt, 4);
        updNew := PktField(pkt, 5);
      end
      else if PktField(pkt, 0) = '2' then
        delOld := PktField(pkt, 4);
    end;
  end;

  Tst('3 olay cekildi (sema kaydi olay DEGIL)', cnt = 3, 'cnt=' + IntToStr(cnt));
  Tst('insert pk', insPk = '1', string(insPk));
  Tst('insert old json', insOld = '[]', string(insOld));
  Tst('insert new json', insNew = '["1","bir"]', string(insNew));
  Tst('update old json', updOld = '["1","bir"]', string(updOld));
  Tst('update new json', updNew = '["1","bir-yeni"]', string(updNew));
  Tst('delete old json', delOld = '["1","bir-yeni"]', string(delOld));
  Tst('drain sonrasi PollSize 0', aCdcPollSize(db) = 0,
    IntToStr(aCdcPollSize(db)));
  Tst('drain sonrasi Poll 0',
    aCdcPoll(db, @buf[0], SizeOf(buf)) = 0);

  // ---- 7) tanilama sayaclari ----
  n := aCdcStats(db, @ev, @skip, @pend, @drop);
  Tst('VdbCdcStats', n = VDB_OK, 'n=' + IntToStr(n));
  Tst('olay sayisi 3', ev = 3, 'ev=' + IntToStr(ev));
  Tst('atlanan kayit >= 1 (sema)', skip >= 1, 'skip=' + IntToStr(skip));
  Tst('bekleyen 0 (drain edildi)', pend = 0, 'pend=' + IntToStr(pend));
  Tst('dusen 0 (tampon tasmedi)', drop = 0, 'drop=' + IntToStr(drop));

  // ---- 8) Time Travel: VdbValueAt (VdbGet sozlesmesi) ----
  // Boyut sorgusu (ALen=0) NEGATIF doner: -gerekli boyut; "yok" = -1.
  need := aValueAt(db, 't', '1', seqIns, nil, 0);
  Tst('ValueAt INSERT aninda boyut sorgusu', need = -11,
    'need=' + IntToStr(need));
  if need < -1 then
  begin
    SetLength(js, -need);
    n := aValueAt(db, 't', '1', seqIns, PAnsiChar(@js[1]), -need);
    Tst('ValueAt INSERT json', (n = -need) and (js = '["1","bir"]'),
      string(js));
  end;

  need := aValueAt(db, 't', '1', seqUpd, nil, 0);
  Tst('ValueAt UPDATE aninda boyut sorgusu', need = -16,
    'need=' + IntToStr(need));
  if need < -1 then
  begin
    SetLength(js, -need);
    n := aValueAt(db, 't', '1', seqUpd, PAnsiChar(@js[1]), -need);
    Tst('ValueAt UPDATE json', (n = -need) and (js = '["1","bir-yeni"]'),
      string(js));
  end;

  Tst('ValueAt DELETE aninda satir yok (-1)',
    aValueAt(db, 't', '1', seqDel, nil, 0) = -1,
    IntToStr(aValueAt(db, 't', '1', seqDel, nil, 0)));
  Tst('ValueAt INSERT oncesi satir yok (-1)',
    aValueAt(db, 't', '1', seqIns - 1, nil, 0) = -1,
    IntToStr(aValueAt(db, 't', '1', seqIns - 1, nil, 0)));
  Tst('ValueAt olmayan pk satir yok (-1)',
    aValueAt(db, 't', '99', seqDel, nil, 0) = -1);
  Tst('bozuk handle ValueAt hata', aValueAt(1, 't', '1', 0, nil, 0) < 0);
  Tst('bozuk handle ValueAt -> BAD_HANDLE',
    aErrCode() = VDB_E_BAD_HANDLE, ErrS);
  Tst('bozuk handle HistoryCount hata', aHistoryCount(1) < 0,
    IntToStr(aHistoryCount(1)));

  // ---- 9) CDC calisirken kapat: CloseAll parcacigi durdurur ----
  Tst('CDC yeniden baslatildi', aCdcStart(db) = VDB_OK, ErrS);
  aClose(db);   // Stop beklemeden kapat -> thread'li kapanis crash olmamali
  Tst('calisirken kapatma crash olmadi', True);
end;

{ ------------------------------------------------------------------ main }

var
  arg: string;
  dllPath: string;
begin
  nPass := 0; nFail := 0; nGrp := 0;

  if (ParamCount >= 1) and (Trim(ParamStr(1)) <> '') then
  begin
    tmpDir := ParamStr(1);
    ForceDirectories(tmpDir);
  end
  else
  begin
    tmpDir := GetTempDir(False) + 'vdbapitest_' +
      FormatDateTime('yyyymmdd_hhnnss', Now);
    ForceDirectories(tmpDir);
  end;

  WriteLn('VDb API DLL testi');
  WriteLn('Klasor : ', tmpDir);

  { DLL yerinde mi? Yaninda degilse proje klasorunu dene. }
  dllPath := DLL_NAME;
  if not FileExists(dllPath) then
    dllPath := ExtractFilePath(ParamStr(0)) + DLL_NAME;
  if not FileExists(dllPath) then
  begin
    WriteLn;
    WriteLn('HATA: ', DLL_NAME, ' bulunamadi. Once build_dll.ps1 calistirin.');
    Halt(2);
  end;
  WriteLn('DLL   : ', dllPath);
  WriteLn;

  H := LoadLibrary(PChar(dllPath));
  if H = 0 then
  begin
    WriteLn('HATA: LoadLibrary basarisiz. Kod=', GetLastError);
    Halt(2);
  end;

  WriteLn('Yuklenen export''lar cozuluyor...');
  aApiVersion := TVdbApiVersion(Req('VdbApiVersion'));
  aVersion := TVdbVersion(Req('VdbVersion'));
  aLastError := TVdbLastError(Req('VdbLastError'));
  aErrCode := TVdbErrCodeGet(Req('VdbLastErrorCodeGet'));
  aOpen := TVdbOpen(Req('VdbOpen'));
  aClose := TVdbClose(Req('VdbClose'));
  aCloseAll := TVdbCloseAll(Req('VdbCloseAll'));
  aCount := TVdbCount(Req('VdbCount'));
  aPut := TVdbPut(Req('VdbPut'));
  aGet := TVdbGet(Req('VdbGet'));
  aExists := TVdbExists(Req('VdbExists'));
  aDelete := TVdbDelete(Req('VdbDelete'));
  aFlush := TVdbFlush(Req('VdbFlush'));
  aExec := TVdbExec(Req('VdbExec'));
  aFieldCount := TVdbFieldCount(Req('VdbResultFieldCount'));
  aRowCount := TVdbRowCount(Req('VdbResultRowCount'));
  aFieldName := TVdbFieldName(Req('VdbResultFieldName'));
  aValue := TVdbValue(Req('VdbResultValue'));
  aAffected := TVdbAffected(Req('VdbResultAffected'));
  aStmts := TVdbStmts(Req('VdbResultStmts'));
  aResultMsg := TVdbResultMsg(Req('VdbResultMessage'));
  aResultFree := TVdbResultFree(Req('VdbResultFree'));
  aVerify := TVdbVerify(Req('VdbVerify'));
  aWalHas := TVdbWalHas(Req('VdbWalHas'));
  aWalRecordCount := TVdbWalRecordCount(Req('VdbWalRecordCount'));
  aWalWrite := TVdbWalWrite(Req('VdbWalWrite'));
  aWalWriteDel := TVdbWalWriteDel(Req('VdbWalWriteDelete'));
  aWalReplay := TVdbWalReplay(Req('VdbWalReplay'));
  aWalCheckpoint := TVdbWalCheckpoint(Req('VdbWalCheckpoint'));
  aWalSetAuto    := TVdbWalSetAuto(Req('VdbWalSetAuto'));
  aWalIsAuto     := TVdbWalIsAuto(Req('VdbWalIsAuto'));
  aWalAutoCount  := TVdbWalAutoCount(Req('VdbWalAutoCount'));
  aFileSize := TVdbFileSize(Req('VdbFileSize'));
  aDeadBytes := TVdbDeadBytes(Req('VdbDeadBytes'));
  aAutoCompact := TVdbAutoCompact(Req('VdbAutoCompact'));
  aCdcStart := TVdbCdcStart(Req('VdbCdcStart'));
  aCdcStop := TVdbCdcStop(Req('VdbCdcStop'));
  aCdcPollSize := TVdbCdcPollSize(Req('VdbCdcPollSize'));
  aCdcPoll := TVdbCdcPoll(Req('VdbCdcPoll'));
  aCdcStats := TVdbCdcStats(Req('VdbCdcStats'));
  aValueAt := TVdbValueAt(Req('VdbValueAt'));
  aHistoryCount := TVdbHistoryCount(Req('VdbHistoryCount'));
  WriteLn('  ', nExport, ' export cozuldu (hepsi bulundu).');
  WriteLn;

  try
    TestSurum;
    TestAcilis(tmpDir);
    TestKV(tmpDir);
    TestUtf8(tmpDir);
    TestSql(tmpDir);
    TestBakim(tmpDir);
    TestWal(tmpDir);
    TestWalAuto(tmpDir);
    TestCdcTt(tmpDir);
  finally
    aCloseAll;
    FreeLibrary(H);
  end;

  WriteLn;
  WriteLn('========================================');
  WriteLn('SONUC: gecen=', nPass, '  kalan=', nFail);
  if nFail = 0 then
    WriteLn('TUM DLL API TESTLERI GECTI')
  else
    WriteLn('HATA VAR');
  if nFail > 0 then Halt(1);
end.
