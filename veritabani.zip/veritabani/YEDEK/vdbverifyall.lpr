program vdbverifyall;

{ TUM VERITABANI DOSYALARINI DOGRULAR
  ---------------------------------------------------------------------------
  "Veritabani dosyalari tamam mi?" sorusunu CEVABINI olcerek verir.
  Her .odb icin:
    1) dosya acilabiliyor mu
    2) Verify (CRC + seq surekliligi) sonucu
    3) tablo sayisi, kayit sayisi
    4) .bak / .wal durumu
  Hicbir dosyaya YAZMAZ (salt okunur).
}

{$mode delphi}{$H+}

uses
  SysUtils, Classes, FileUtil, VDbCore, VDbTable, VDbSql;

var
  nOk, nBad: Integer;

procedure Kontrol(const Dir: string);
var
  SR: TSearchRec;
  Dosya: string;
  Kv: TVDb;
  Tb: TVTableDb;
  Rep, Durum: string;
  Tablolar: TStrArray;
  WalVar: Boolean;
  Buldu: Integer;
  procedure BirDosya(const Ad: string);
  var
    Kv2: TVDb;
    Tb2: TVTableDb;
    Rep2, Durum2, D2: string;
    Tab2: TStrArray;
    Wal2: Boolean;
  begin
    D2 := IncludeTrailingPathDelimiter(Dir) + Ad;
    Write('  ', Ad, ' ... ');
    Wal2 := FileExists(ChangeFileExt(D2, '.wal'));
    Kv2 := nil; Tb2 := nil;
    try
      try
        Kv2 := TVDb.Create;
        Kv2.SyncWrite := False;
        Kv2.Open(D2);
        Tb2 := TVTableDb.Create(Kv2);
        Tb2.Open(ExtractFileDir(D2));
        if Kv2.Verify(Rep2) then
        begin
          Tab2 := Tb2.TableNames;
          Durum2 := Format('SAGLAM  kayit=%d  tablo=%d',
            [Kv2.Count, Length(Tab2)]);
          if Wal2 then Durum2 := Durum2 + '  [WAL BEKLIYOR]';
          Inc(nOk);
        end
        else
        begin
          Durum2 := 'BOZUK: ' + Rep2;
          Inc(nBad);
        end;
      except
        on E: Exception do
        begin
          Durum2 := 'ACILAMADI: ' + E.Message;
          Inc(nBad);
        end;
      end;
    finally
      Tb2.Free;
      Kv2.Free;
    end;
    WriteLn(Durum2);
    if FileExists(D2 + '.bak') then
      WriteLn('        yedek: .bak ', (FileUtil.FileSize(D2 + '.bak') div 1024), ' KB');
    if FileExists(D2 + '.onceki') then
      WriteLn('        yedek: .onceki ', (FileUtil.FileSize(D2 + '.onceki') div 1024), ' KB');
  end;
begin
  { DIKKAT: bu programda `Windows` birimi KULLANILMAZ. Windows uniti
    SysUtils.FindFirst'i yeniden tanimliyor ve TSearchRec tipi
    TRawbyteSearchRec'a donuserek "Wrong type" hatasi veriyor.
    SysUtils tek basina dogru calisiyor (ayri bir testle dogrulandi). }
  Buldu := FindFirst(IncludeTrailingPathDelimiter(Dir) + '*.odb', faAnyFile, SR);
  if Buldu <> 0 then
  begin
    WriteLn('  (bu klasorde .odb yok)');
    Exit;
  end;
  repeat
    if (SR.Attr and faDirectory) = 0 then
      BirDosya(SR.Name);
  until FindNext(SR) <> 0;
  FindClose(SR);
end;

var
  I: Integer;
  Dizi: array[0..2] of string;
begin
  nOk := 0; nBad := 0;
  WriteLn('=== VDb dosya dogrulama (SALT OKUNUR) ===');
  WriteLn;
  { ONCEki DENEME: '.' ve 'db' gibi GORELI yollar calistigimiz klasore
    gore cozuluyor ve dosya bulunamadi. Simdi exe'nin yanindaki KLASOR
    mutlak yola cevrilir; boylece nereden calistirilirsa calistirilsin
    ayni sonucu verir. }
  Dizi[0] := ExtractFilePath(ParamStr(0));
  Dizi[1] := IncludeTrailingPathDelimiter(Dizi[0]) + 'db';
  for I := 0 to 1 do
  begin
    if not DirectoryExists(Dizi[I]) then
    begin
      WriteLn('Klasor yok, atlandi: ', Dizi[I]);
      Continue;
    end;
    WriteLn('Klasor: ', Dizi[I]);
    Kontrol(Dizi[I]);
    WriteLn;
  end;
  WriteLn('========================================');
  WriteLn('SONUC: saglam=', nOk, '  sorunlu=', nBad);
end.