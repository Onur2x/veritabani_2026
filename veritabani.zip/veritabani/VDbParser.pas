unit VDbParser;

{ VDb SQL Ayrıştırıcısı (Parser) — Faz 3 (3.1 - 3.4)
  SQL metnini tarayarak tip-güvenli AST dugumlerine (TSqlStmtNode) donusturur.
  Ozyinelemeli inis (Recursive-Descent) teknigi kullanilir.

  Desteklenen SQL:
    DDL : CREATE TABLE [IF NOT EXISTS], ALTER TABLE, DROP TABLE [IF EXISTS]
          CREATE INDEX, DROP INDEX [IF EXISTS]
          CREATE/DROP/OPEN/CLOSE DATABASE, BACKUP TO, VACUUM, REINDEX, VERIFY
          SHOW/LIST TABLES, LIST DATABASES, EXPORT/IMPORT JSON
    DML : INSERT INTO ... VALUES / SELECT
          UPDATE ... SET ... WHERE
          DELETE FROM ... WHERE
    TX  : BEGIN, COMMIT, ROLLBACK
    SEL : SELECT [DISTINCT] cols FROM tbl [alias]
          [INNER|LEFT JOIN tbl2 alias ON cond]
          [WHERE expr]
          [GROUP BY cols] [HAVING expr]
          [ORDER BY cols [ASC|DESC]]
          [LIMIT n] [OFFSET n]
          UNION [ALL] / EXCEPT / INTERSECT
  
  Cikti: tek bir TSqlStmtNode; cagiran .Free ile temizler.
  Hata durumunda pozisyon bilgili Exception firlatilir.
}

{$mode delphi}

interface

uses
  Classes, SysUtils, Generics.Collections, VDbTable, VDbAst, VDbErr;

type
  TVDbParser = class
  private
    FSql   : string;
    FPos   : Integer;
    FLen   : Integer;
    FParams: TStrArray;
    FParamIdx: Integer;
    // F1-22: ifade/parantez derinlik sayaci (yigin tasmasini onler)
    FDepth  : Integer;
    // F1-12: UNION/EXCEPT/INTERSECT sag SELECT'i icin kuyruk (ORDER BY /
    // LIMIT / OFFSET) bastirilir; kuyruk dis birlestirmenin SONRASINA
    // ait oldugundan dis cumleye yazilir.
    FSuppressTail: Boolean;

    { ---- Tokenizer ---- }
    procedure SkipWS;
    function  Peek: Char;
    function  AtEnd: Boolean;
    function  NextToken(out T: string; out IsStringLit: Boolean): Boolean; overload;
    function  NextToken(out T: string): Boolean; overload;
    function  PeekToken: string;
    function  PeekToken2: string;   // ikinci token'a bakar (pos degistirmez)
    procedure Expect(const W: string);
    procedure ExpectToken(out T: string; out IsStringLit: Boolean); overload;
    procedure ExpectToken(out T: string); overload;
    function  TryEat(const W: string): Boolean;
    function  CurPos: string;       // hata mesaji icin "pos=N"

    { ---- Tür / Alan yardımcıları ---- }
    function  ParseTypeName: Byte;   // VCT_* donuyor
    procedure ParseColDef(var C: TColDef; Stmt: TSqlCreateTableStmt = nil);
    function  ReadFkAction: string;

    { ---- İfade Ayrıştırıcı ---- }
    // Operatör öncelik hiyerarşisi (en düşükten en yükseğe):
    //   OR -> AND -> NOT -> karşılaştırma -> ek/çıkar -> çarp/böl -> tekli -> atom
    function ParseExpr: TSqlExprNode;
    function ParseOrExpr: TSqlExprNode;
    function ParseAndExpr: TSqlExprNode;
    function ParseNotExpr: TSqlExprNode;
    function ParseCmpExpr: TSqlExprNode;
    function ParseAddExpr: TSqlExprNode;
    function ParseMulExpr: TSqlExprNode;
    function ParseUnaryExpr: TSqlExprNode;
    function ParsePrimary: TSqlExprNode;
    function ParseInList(Expr: TSqlExprNode; IsNot: Boolean): TSqlInNode;
    function ParseFuncCall(const FuncName: string): TSqlExprNode;
    // P5-WIN: OVER yan cumlecigi (sahiplenme yalniz basarida gecer).
    function ParseOver(const FuncName: string; Arg: TSqlExprNode;
      IsStar: Boolean; Off: Int64; Def: TSqlExprNode): TSqlWindowNode;
    function ParseLagLead(const FuncName: string): TSqlExprNode;
    function ParseCase: TSqlCaseNode;

    { ---- SELECT alt-parser ---- }
    procedure ParseSelectColumns(Stmt: TSqlSelectStmt);
    procedure ParseFromClause(Stmt: TSqlSelectStmt);
    // AS OF kuyrugu: "OF SEQUENCE n" | "OF VERSION x" | "OF TIMESTAMP '...'
    // ("AS" yoneticisi cagiran tarafca yutulmus olmalidir.)
    procedure ParseAsOfTail(Stmt: TSqlSelectStmt);
    procedure ParseJoinClause(var JC: TJoinClause; AllowNoOn: Boolean;
      out ExitCols: TStrArray);
    procedure ParseGroupBy(Stmt: TSqlSelectStmt);
    procedure ParseOrderBy(Stmt: TSqlSelectStmt);
    // F1-12: ORDER BY / LIMIT / OFFSET kuyrugu (set-op disina tasinabilir)
    procedure ParseSelectTail(Stmt: TSqlSelectStmt);
    // ORDER BY ogesinden sonra opsiyonel COLLATE (yalniz TR desteklenir).
    procedure ParseCollate(var Item: TOrderItem);

    { ---- Statement ayrıştırıcıları ---- }
    function ParseSelect: TSqlSelectStmt;
    // P5-CTE: WITH x AS (...), ... SELECT ... (yalniz SELECT; RECURSIVE
    // ve kolon alias'lari desteklenmez).
    function ParseWith: TSqlStmtNode;
    function ParseInsert: TSqlInsertStmt;
    function ParseUpdate: TSqlUpdateStmt;
    function ParseDelete: TSqlDeleteStmt;
    function ParseCreateTable: TSqlCreateTableStmt;
    function ParseAlterTable: TSqlAlterTableStmt;
    function ParseDropTable: TSqlDropTableStmt;
    function ParseCreateIndex: TSqlCreateIndexStmt;
    function ParseDropIndex: TSqlDropIndexStmt;
    function ParseAdmin(const Kw1, Kw2: string): TSqlAdminStmt;
    function ParseJson(const Kw: string): TSqlJsonStmt;

  public
    { Parse: SQL metnini ayrıştırır, AST dugumu dondurur.
      Params: '?' yer tutucularini sirasıyla dolduran deger listesi. }
    function Parse(const ASql: string;
                   const AParams: array of string): TSqlStmtNode;
  end;

implementation

{ ============================================================
  Küçük yardımcılar
  ============================================================ }

function IsAlpha(C: Char): Boolean; inline;
begin Result := C in ['A'..'Z','a'..'z','_']; end;

function IsAlNum(C: Char): Boolean; inline;
begin Result := C in ['A'..'Z','a'..'z','0'..'9','_']; end;

function IsDigit(C: Char): Boolean; inline;
begin Result := C in ['0'..'9']; end;

{ ============================================================
  TVDbParser — Tokenizer
  ============================================================ }

procedure TVDbParser.SkipWS;
begin
  while FPos <= FLen do
  begin
    case FSql[FPos] of
      ' ', #9, #10, #13: Inc(FPos);
      '-': // -- satir yorumu
        if (FPos < FLen) and (FSql[FPos+1] = '-') then
        begin
          Inc(FPos, 2);
          while (FPos <= FLen) and (FSql[FPos] <> #10) do Inc(FPos);
        end
        else Break;
      '/': // /* ... */ blok yorumu
        if (FPos < FLen) and (FSql[FPos+1] = '*') then
        begin
          Inc(FPos, 2);
          while FPos < FLen do
          begin
            if (FSql[FPos] = '*') and (FSql[FPos+1] = '/') then
            begin Inc(FPos, 2); Break; end;
            Inc(FPos);
          end;
        end
        else Break;
    else
      Break;
    end;
  end;
end;

function TVDbParser.Peek: Char;
begin
  if FPos <= FLen then Result := FSql[FPos] else Result := #0;
end;

function TVDbParser.AtEnd: Boolean;
begin
  SkipWS;
  Result := FPos > FLen;
end;

function TVDbParser.NextToken(out T: string; out IsStringLit: Boolean): Boolean;
var
  Start, i: Integer;
  c: Char;
  rangeOk: Boolean;
begin
  SkipWS;
  T := '';
  IsStringLit := False;
  Result := False;
  if FPos > FLen then Exit;

  // F-22: '?' iki anlamli: parametre yer tutucusu VEYA JSONB "anahtar var mi"
  // operatoru. Ayrim kurali: parametre BAGLANDIGINDA yer tutucu, aksi
  // halde operator. Boylece parametreli API (Exec(sql, params)) degismez,
  // `col ? 'anahtar'` yazilabilir.
  if FSql[FPos] = '?' then
  begin
    if FParamIdx <= High(FParams) then
    begin
      Inc(FPos);
      T := FParams[FParamIdx];
      Inc(FParamIdx);
      IsStringLit := True;
      Result := True;
      Exit;
    end;
    // JSONB operatoru: '?', '?|' veya '?&'
    Inc(FPos);
    T := '?';
    if FPos <= FLen then
    begin
      if FSql[FPos] = '|' then
      begin
        T := '?|';
        Inc(FPos);
      end
      else if FSql[FPos] = '&' then
      begin
        T := '?&';
        Inc(FPos);
      end;
    end;
    Result := True;
    Exit;
  end;

  // F-22: '@>' — sol/sag JSONB icerme operatoru
  if FSql[FPos] = '@' then
  begin
    if (FPos < FLen) and (FSql[FPos + 1] = '>') then
    begin
      T := '@>';
      Inc(FPos, 2);
      Result := True;
      Exit;
    end;
    raise EVDbException.CreateFmt(ecSyntaxError,
      '"@" isaretinden sonra ">" bekleniyor (konum=%d)', [FPos]);
  end;

  // F-25: ARALIK LITERAL'I. "[1,5]", "(1,5]", "[1,)", "[1..5]" gibi diziler
// normal ifade AYRISTIRILAMAZ: lexer sayiyi '1' sonra ',' sonra '5' olarak
// verir ve ParseExpr hata verir. Bu yuzden parantezle baslayip eslesen
// kapanisla biten ve ICINDE yalnizca rakam/nokta/virgul/yildiz/eksi ve
// TEK tirnakli metin bulunan diziler TEK token olarak alinir.
//
// Guvenlik onlemleri:
//  - '(SELECT a FROM t)' alt sorgusu ic kelimeler icerdigi icin (harf)
//    bu kurala girmez.
//  - '(42, 3.5, 'merhaba', 1, ...)' INSERT VALUES satiri da tirnak icerir
//    ama KAPANIS parantez ')' ile degil ']' ile gelir; bu yuzden yalniz
//    ICINDE harf/kelime OLMAYAN diziler kabul edilir. Tirnakli metin
//    iceren diziler bu kurala GIRMEZ:INSERT satiri korunur.
  if (FSql[FPos] = '[') or (FSql[FPos] = '(') then
  begin
    Start := FPos;
    i := FPos + 1;
    rangeOk := False;
    while i <= FLen do
    begin
      c := FSql[i];
      // Tirnakli metin bu kurala girmez -> hemen vazgec.
      if c = '''' then Break;
      if c = ']' then
      begin
        rangeOk := True;
        Break;
      end;
      // Kapanis parantez ')' SADECE baslangicta '(' ile eslesirse ve
      // icerik disaridan yapisal DEGILSE (virgul sayisi sinirli).
      if c = ')' then Break;
      if not (c in ['0'..'9', '.', ',', '*', '-', ' ', #9]) then Break;
      Inc(i);
    end;
    if rangeOk then
    begin
      T := Copy(FSql, Start, i - Start + 1);
      FPos := i + 1;
      IsStringLit := True;
      Result := True;
      Exit;
    end;
  end;

  // '(...)' ile baslayan acik sol uc: "(1,5]" gibi. Kapanis ']' gelirse
  // aralik literal'idir; ')' gelirse normal parantez ifadesidir.
  if FSql[FPos] = '(' then
  begin
    Start := FPos;
    i := FPos + 1;
    rangeOk := False;
    while i <= FLen do
    begin
      c := FSql[i];
      if c = '''' then Break;
      if c = ']' then begin rangeOk := True; Break; end;
      if c = ')' then Break;
      if not (c in ['0'..'9', '.', ',', '*', '-', ' ', #9]) then Break;
      Inc(i);
    end;
    if rangeOk then
    begin
      T := Copy(FSql, Start, i - Start + 1);
      FPos := i + 1;
      IsStringLit := True;
      Result := True;
      Exit;
    end;
  end;

  // Tekli tırnaklı string
  if FSql[FPos] = '''' then
  begin
    IsStringLit := True;
    Inc(FPos); Start := FPos; T := '';
    while FPos <= FLen do
    begin
      if FSql[FPos] = '''' then
      begin
        if (FPos < FLen) and (FSql[FPos+1] = '''') then
        begin
          T := T + Copy(FSql, Start, FPos - Start) + '''';
          Inc(FPos, 2); Start := FPos; Continue;
        end;
        T := T + Copy(FSql, Start, FPos - Start);
        Inc(FPos); Result := True; Exit;
      end;
      Inc(FPos);
    end;
    raise EVDbException.Create(ecSyntaxError, 'Kapanmamis string sabiti');
  end;

  // Çift tırnaklı tanımlayıcı (quoted identifier)
  if FSql[FPos] = '"' then
  begin
    Inc(FPos); Start := FPos; T := '';
    while FPos <= FLen do
    begin
      if FSql[FPos] = '"' then
      begin
        T := T + Copy(FSql, Start, FPos - Start);
        Inc(FPos); Result := True; Exit;
      end;
      Inc(FPos);
    end;
    raise EVDbException.Create(ecSyntaxError, 'Kapanmamis tanimla (")');
  end;

  // Backtick tanımlayıcı `col`
  if FSql[FPos] = '`' then
  begin
    Inc(FPos); Start := FPos; T := '';
    while FPos <= FLen do
    begin
      if FSql[FPos] = '`' then
      begin
        T := T + Copy(FSql, Start, FPos - Start);
        Inc(FPos); Result := True; Exit;
      end;
      Inc(FPos);
    end;
    raise EVDbException.Create(ecSyntaxError, 'Kapanmamis tanimla (`)');
  end;

  // Sayı: tam veya ondalıklı
  if IsDigit(FSql[FPos]) then
  begin
    Start := FPos;
    while (FPos <= FLen) and IsDigit(FSql[FPos]) do Inc(FPos);
    if (FPos <= FLen) and (FSql[FPos] = '.') and
       (FPos < FLen) and IsDigit(FSql[FPos+1]) then
    begin
      Inc(FPos);
      while (FPos <= FLen) and IsDigit(FSql[FPos]) do Inc(FPos);
    end;
    T := Copy(FSql, Start, FPos - Start);
    Result := True; Exit;
  end;

  // Tanımlayıcı veya anahtar kelime
  if IsAlpha(FSql[FPos]) then
  begin
    Start := FPos;
    while (FPos <= FLen) and IsAlNum(FSql[FPos]) do Inc(FPos);
    T := Copy(FSql, Start, FPos - Start);
    Result := True; Exit;
  end;

  // Operatörler
  case FSql[FPos] of
    '<', '>',  '!':
      begin
        T := FSql[FPos]; Inc(FPos);
        if (FPos <= FLen) and (FSql[FPos] = '=') then begin T := T + '='; Inc(FPos); end
        else if (T = '<') and (FPos <= FLen) and (FSql[FPos] = '>') then begin T := '<>'; Inc(FPos); end
        // F-22: '<@' — JSONB "sol, sag'in icinde mi" operatoru
        else if (T = '<') and (FPos <= FLen) and (FSql[FPos] = '@') then begin T := '<@'; Inc(FPos); end
        // F-25: '<<' / '>>' — aralik "tamamen once" / "tamamen sonra"
        else if (FPos <= FLen) and (FSql[FPos] = T) and (T <> '<>') and
                (T <> '>=') then begin T := T + T; Inc(FPos); end;
        Result := True;
      end;
    // F-25: '&' baslayan aralik operatorleri: '&&', '&<', '&>'
    '&':
      begin
        T := '&'; Inc(FPos);
        if FPos <= FLen then
          case FSql[FPos] of
            '&': begin T := '&&'; Inc(FPos); end;
            '<', '>': begin T := T + FSql[FPos]; Inc(FPos); end;
          end;
        Result := True;
      end;
    // F-25: '-|-' aralik bitisiklik operatoru
    '-':
      begin
        T := '-'; Inc(FPos);
        if (FPos + 1 <= FLen) and (FSql[FPos] = '|') and (FSql[FPos+1] = '-') then
        begin
          T := '-|-'; Inc(FPos, 2);
        end;
        Result := True;
      end;
    '|':
      begin
        T := '|'; Inc(FPos);
        if (FPos <= FLen) and (FSql[FPos] = '|') then begin T := '||'; Inc(FPos); end;
        Result := True;
      end;
    '(', ')', ',', '*', '=', '+', '/', '%', '.', ';':
      begin T := FSql[FPos]; Inc(FPos); Result := True; end;
  else
    T := FSql[FPos]; Inc(FPos); Result := True;
  end;
end;

function TVDbParser.NextToken(out T: string): Boolean;
var dummy: Boolean;
begin
  Result := NextToken(T, dummy);
end;

function TVDbParser.PeekToken: string;
var SavePos, SaveIdx: Integer; T: string;
begin
  SavePos := FPos; SaveIdx := FParamIdx;
  if not NextToken(T) then T := '';
  FPos := SavePos; FParamIdx := SaveIdx;
  Result := UpperCase(T);
end;

function TVDbParser.PeekToken2: string;
var SavePos, SaveIdx: Integer; T: string;
begin
  SavePos := FPos; SaveIdx := FParamIdx;
  if not NextToken(T) then begin FPos := SavePos; FParamIdx := SaveIdx; Result := ''; Exit; end;
  if not NextToken(T) then T := '';
  FPos := SavePos; FParamIdx := SaveIdx;
  Result := UpperCase(T);
end;

procedure TVDbParser.Expect(const W: string);
var T: string;
begin
  if not NextToken(T) then
    raise EVDbException.CreateFmt(ecSyntaxError, '"%s" bekleniyor ama dosya sonu (%s)', [W, CurPos]);
  if not SameText(T, W) then
    raise EVDbException.CreateFmt(ecSyntaxError, '"%s" bekleniyor, "%s" bulundu (%s)', [W, T, CurPos]);
end;

procedure TVDbParser.ExpectToken(out T: string; out IsStringLit: Boolean);
begin
  if not NextToken(T, IsStringLit) then
    raise EVDbException.Create(ecSyntaxError, 'Beklenmedik dosya sonu ' + CurPos);
end;

procedure TVDbParser.ExpectToken(out T: string);
var dummy: Boolean;
begin
  ExpectToken(T, dummy);
end;

function TVDbParser.TryEat(const W: string): Boolean;
var SavePos, SaveIdx: Integer; T: string;
begin
  SavePos := FPos; SaveIdx := FParamIdx;
  if not NextToken(T) then begin Result := False; Exit; end;
  if SameText(T, W) then
  begin
    Result := True;
  end
  else
  begin
    FPos := SavePos; FParamIdx := SaveIdx;
    Result := False;
  end;
end;

function TVDbParser.CurPos: string;
begin
  Result := 'konum=' + IntToStr(FPos);
end;

{ ============================================================
  Tür / Alan yardımcıları
  ============================================================ }

function TVDbParser.ParseTypeName: Byte;
var T, U: string;
begin
  ExpectToken(T); U := UpperCase(T);
  // Boyutlu tipler: VARCHAR(n), CHAR(n), DECIMAL(p,s) vs. — boyutu yut
  if U = 'VARCHAR'  then begin if TryEat('(') then begin ExpectToken(T); if not TryEat(')') then Expect(')'); end; Exit(VCT_STR); end;
  if U = 'CHAR'     then begin if TryEat('(') then begin ExpectToken(T); if not TryEat(')') then Expect(')'); end; Exit(VCT_STR); end;
  if U = 'TEXT'     then Exit(VCT_STR);
  if U = 'STRING'   then Exit(VCT_STR);
  if (U = 'INT') or (U = 'INTEGER') or (U = 'BIGINT') or (U = 'SMALLINT') or (U = 'TINYINT') then Exit(VCT_INT);
  if U = 'SERIAL'   then Exit(VCT_INT);
  if (U = 'FLOAT') or (U = 'DOUBLE') or (U = 'REAL') or (U = 'DECIMAL') or (U = 'NUMERIC') then
  begin
    if TryEat('(') then begin ExpectToken(T); TryEat(','); if TryEat(',') then ExpectToken(T); Expect(')'); end;
    Exit(VCT_FLOAT);
  end;
  if (U = 'BOOL') or (U = 'BOOLEAN') then Exit(VCT_BOOL);
  if U = 'DATE'     then Exit(VCT_DATE);
  if (U = 'DATETIME') or (U = 'TIMESTAMP') then Exit(VCT_DATETIME);
  if U = 'TIME'     then Exit(VCT_TIME);
  if (U = 'BLOB') or (U = 'BINARY') or (U = 'BYTEA') then Exit(VCT_BLOB);
  raise EVDbException.CreateFmt(ecSyntaxError, 'Bilinmeyen kolon tipi: "%s" (%s)', [T, CurPos]);
end;

function TVDbParser.ReadFkAction: string;
var T: string;
begin
  ExpectToken(T); T := UpperCase(T);
  if T = 'RESTRICT'    then Exit(VDB_FK_RESTRICT);
  if T = 'CASCADE'     then Exit(VDB_FK_CASCADE);
  if T = 'SET'         then begin Expect('NULL'); Exit(VDB_FK_SETNULL); end;
  if (T = 'NO') or (T = 'NOTHING') then begin if T = 'NO' then Expect('ACTION'); Exit(VDB_FK_RESTRICT); end;
  if T = 'DEFAULT'     then Exit(VDB_FK_SETDEFAULT);
  raise EVDbException.CreateFmt(ecSyntaxError, 'Gecersiz FK aksiyonu: "%s" (%s)', [T, CurPos]);
end;

procedure TVDbParser.ParseColDef(var C: TColDef; Stmt: TSqlCreateTableStmt = nil);
var T, U: string; SavePos, SaveIdx: Integer;
    fk: TFkDef;
begin
  C.Ctype := VCT_STR;
  C.NotNull := False;
  C.HasDef := False;
  C.Def := '';
  C.Unique := False;
  // Tip adını oku
  C.Ctype := ParseTypeName;

  // Nitelikleri tüket (PRIMARY KEY, NOT NULL, DEFAULT, AUTOINCREMENT, UNIQUE, REFERENCES, CHECK)
  while True do
  begin
    SavePos := FPos; SaveIdx := FParamIdx;
    if not NextToken(T) then Break;
    U := UpperCase(T);
    if U = 'PRIMARY' then
    begin
      Expect('KEY'); // ParseCreateTable PkIndex'i ayri yonetiyor
    end
    else if U = 'NOT' then
    begin
      Expect('NULL'); C.NotNull := True;
    end
    else if U = 'NULL' then
    begin
      // NULL explicitly -> nullable
    end
    else if U = 'DEFAULT' then
    begin
      ExpectToken(T);
      C.HasDef := True;
      C.Def := T;
    end
    else if (U = 'AUTOINCREMENT') or (U = 'AUTO_INCREMENT') then
    begin
      // AutoInc: tablo seviyesinde; buradan yonetilmiyor
    end
    else if U = 'UNIQUE' then
    begin
      C.Unique := True;
    end
    else if U = 'REFERENCES' then
    begin
      fk.Col := -1;
      if Stmt <> nil then fk.Col := Length(Stmt.Cols);
      ExpectToken(T); fk.RefTable := VDbNorm(T);
      fk.RefCol := '';
      if PeekToken = '(' then
      begin
        Expect('('); ExpectToken(T); fk.RefCol := VDbNorm(T); Expect(')');
      end;
      fk.OnDelete := VDB_FK_RESTRICT;
      fk.OnUpdate := VDB_FK_RESTRICT;
      while PeekToken = 'ON' do
      begin
        ExpectToken(T); // ON
        ExpectToken(T); // DELETE|UPDATE
        if UpperCase(T) = 'DELETE' then fk.OnDelete := ReadFkAction
        else if UpperCase(T) = 'UPDATE' then fk.OnUpdate := ReadFkAction;
      end;
      if Stmt <> nil then
      begin
        SetLength(Stmt.Fks, Length(Stmt.Fks) + 1);
        Stmt.Fks[High(Stmt.Fks)] := fk;
      end;
    end
    else if (U = 'CHECK') then
    begin
      Expect('(');
      if Stmt <> nil then
        Stmt.CheckExprs.Add(ParseExpr)
      else
        ParseExpr.Free;
      Expect(')');
    end
    else
    begin
      // Tanınmayan token → geri sar, döngüden çık
      FPos := SavePos; FParamIdx := SaveIdx;
      Break;
    end;
  end;
end;

{ ============================================================
  İfade Ayrıştırıcı
  ============================================================ }

function TVDbParser.ParseExpr: TSqlExprNode;
begin
  Result := ParseOrExpr;
end;

function TVDbParser.ParseOrExpr: TSqlExprNode;
var Right: TSqlExprNode; dummy: string;
begin
  Result := ParseAndExpr;
  while PeekToken = 'OR' do
  begin
    NextToken(dummy);
    Right := ParseAndExpr;
    Result := TSqlBinaryOpNode.Create(sboOr, Result, Right);
  end;
end;

function TVDbParser.ParseAndExpr: TSqlExprNode;
var Right: TSqlExprNode; T: string;
begin
  Result := ParseNotExpr;
  while PeekToken = 'AND' do
  begin
    NextToken(T);
    Right := ParseNotExpr;
    Result := TSqlBinaryOpNode.Create(sboAnd, Result, Right);
  end;
end;

function TVDbParser.ParseNotExpr: TSqlExprNode;
var T: string;
begin
  if PeekToken = 'NOT' then
  begin
    Inc(FDepth);
    try
      if FDepth > 256 then
        raise EVDbException.Create(ecSyntaxError, 'ifade derinligi cok fazla (max 256)');
      NextToken(T);
      Result := TSqlUnaryOpNode.Create(suoNot, ParseCmpExpr);
    finally
      Dec(FDepth);
    end;
  end
  else
    Result := ParseCmpExpr;
end;

function TVDbParser.ParseCmpExpr: TSqlExprNode;
var
  T, U: string;
  Op: TSqlBinaryOp;
  Right: TSqlExprNode;
  Low, High: TSqlExprNode;
  IsNot: Boolean;
  SavePos, SaveIdx: Integer;
  likeNode: TSqlExprNode;
  quantKind: TQuantKind;   // F-06: ANY/SOME/ALL
  quantSel: TSqlSelectStmt;
  jsonKeys: TList<TSqlExprNode>;   // F-22: ?| / ?& anahtar listesi
  quantLeft: TSqlExprNode;
begin
  // P5-2: EXISTS (SELECT ...) — NOT EXISTS, NOT islemiyle ParseNotExpr'ten gelir.
  if PeekToken = 'EXISTS' then
  begin
    NextToken(T);
    Expect('(');
    if PeekToken <> 'SELECT' then
      raise EVDbException.CreateFmt(ecSyntaxError,
        'EXISTS sonrasi SELECT bekleniyor (%s)', [CurPos]);
    NextToken(T); // SELECT
    Result := TSqlSubqueryNode.CreateExists(ParseSelect);
    Expect(')');
    Exit;
  end;

  Result := ParseAddExpr;

  while True do
  begin
    SavePos := FPos; SaveIdx := FParamIdx;
    if not NextToken(T) then Break;
    U := UpperCase(T);

    if U = '='  then Op := sboEq
    else if (U = '<>') or (U = '!=') then Op := sboNeq
    else if U = '<'  then Op := sboLt
    else if U = '<=' then Op := sboLte
    else if U = '>'  then Op := sboGt
    else if U = '>=' then Op := sboGte
    else if U = 'LIKE' then Op := sboLike
    else if U = 'ILIKE' then Op := sboILike  // F-05: buyuk/kucuk duyarsiz LIKE
    // ---- F-22: JSONB operatorleri ----
    else if U = '@>' then Op := sboJsonContains   // sol, sag'i iceriyor mu
    else if U = '<@' then Op := sboJsonContained  // sol, sag'in icinde mi
    else if U = '?'  then Op := sboJsonHasKey     // anahtar var mi
    // ---- F-22: '?|' ve '?&' anahtar LISTESI alir -> ozel dugum ----
    else if U = '?|' then
    begin
      jsonKeys := TList<TSqlExprNode>.Create;
      Expect('(');
      while True do
      begin
        jsonKeys.Add(ParseExpr);
        if PeekToken <> ',' then Break;
        NextToken(T);   // ','
      end;
      Expect(')');
      Result := TSqlJsonKeyNode.Create(Result, jsonKeys, False);
      jsonKeys := nil;   // sahiplik dugumde
      Continue;
    end
    else if U = '?&' then
    begin
      jsonKeys := TList<TSqlExprNode>.Create;
      Expect('(');
      while True do
      begin
        jsonKeys.Add(ParseExpr);
        if PeekToken <> ',' then Break;
        NextToken(T);   // ','
      end;
      Expect(')');
      Result := TSqlJsonKeyNode.Create(Result, jsonKeys, True);
      jsonKeys := nil;
      Continue;
    end
    // ---- F-25: RANGE operatorleri ----
    else if U = '@>' then Op := sboRangeContains   // aralik digerini iceriyor
    else if U = '<@' then Op := sboRangeContained  // aralik digerinin icinde
    else if U = '&&' then Op := sboRangeOverlap    // kesisim var mi
    else if U = '<<' then Op := sboRangeBefore     // tamamen once
    else if U = '>>' then Op := sboRangeAfter      // tamamen sonra
    else if U = '&<' then Op := sboRangeOvLeft     // kesisir, sol
    else if U = '&>' then Op := sboRangeOvRight    // kesisir, sag
    else if U = '-|-' then Op := sboRangeAdjacent  // bitisiklik (kesisimsiz)
    else if U = 'IS' then
    begin
      IsNot := TryEat('NOT');
      Expect('NULL');
      if IsNot then
        Result := TSqlUnaryOpNode.Create(suoIsNotNull, Result)
      else
        Result := TSqlUnaryOpNode.Create(suoIsNull, Result);
      Continue;
    end
    else if U = 'NOT' then
    begin
      U := PeekToken;
      if U = 'LIKE' then
      begin
        NextToken(T);
        Right := ParseAddExpr;
        // NOT LIKE = Like + NOT
        likeNode := TSqlBinaryOpNode.Create(sboLike, Result, Right);
        Result := TSqlUnaryOpNode.Create(suoNot, likeNode);
        Continue;
      end
      else if U = 'IN' then
      begin
        NextToken(T);
        Expect('(');
        Result := ParseInList(Result, True);
        Continue;
      end
      else if U = 'ILIKE' then   // F-05: NOT ILIKE = ILIKE + NOT
      begin
        NextToken(T);
        Right := ParseAddExpr;
        likeNode := TSqlBinaryOpNode.Create(sboILike, Result, Right);
        Result := TSqlUnaryOpNode.Create(suoNot, likeNode);
        Continue;
      end
      else if U = 'BETWEEN' then
      begin
        NextToken(T);
        Low := ParseAddExpr;
        Expect('AND');
        High := ParseAddExpr;
        Result := TSqlBetweenNode.Create(Result, Low, High, True);
        Continue;
      end
      else
      begin
        FPos := SavePos; FParamIdx := SaveIdx;
        Break;
      end;
    end
    else if U = 'IN' then
    begin
      Expect('(');
      Result := ParseInList(Result, False);
      Continue;
    end
    else if U = 'BETWEEN' then
    begin
      Low := ParseAddExpr;
      Expect('AND');
      High := ParseAddExpr;
      Result := TSqlBetweenNode.Create(Result, Low, High, False);
      Continue;
    end
    else
    begin
      FPos := SavePos; FParamIdx := SaveIdx;
      Break;
    end;

    // F-06: karsilastirma operatorunden SONRA ANY/SOME/ALL gelebilir
    // (`n = ANY (SELECT ...)`). Bu kontrol `Right` parse EDILMEDEN
    // yapilir; aksi halde ANY bir fonksiyon cagrisi sanilip yutulur.
    if (PeekToken = 'ANY') or (PeekToken = 'SOME') or (PeekToken = 'ALL') then
    begin
      U := PeekToken;
      if (Op <> sboEq) and (Op <> sboNeq) and (Op <> sboLt) and
         (Op <> sboLte) and (Op <> sboGt) and (Op <> sboGte) then
        raise EVDbException.CreateFmt(ecSyntaxError,
          'ANY/SOME/ALL yalnizca =, <>, <, <=, >, >= ile kullanilabilir (%s)', [CurPos]);
      NextToken(T); // ANY / SOME / ALL
      Expect('(');
      if PeekToken <> 'SELECT' then
        raise EVDbException.CreateFmt(ecSyntaxError,
          'ANY/SOME/ALL sonrasi SELECT bekleniyor (%s)', [CurPos]);
      NextToken(T); // SELECT
      if U = 'ALL' then quantKind := qkAll else quantKind := qkAny;
      // DIKKAT: ParseSelect ONCE ayri degiskene alinir. Dogrudan
      // TSqlQuantNode.Create(..., ParseSelect) yazilirsa FPC arguman
      // degerlendirme sirasi Result'a atama yapabilir, SOL IFADE kaybolur.
      quantSel := ParseSelect;
      quantLeft := Result;
      Result := TSqlQuantNode.Create(quantKind, quantLeft, Op, quantSel);
      quantSel := nil;
      Expect(')');
      Continue;
    end;
    Right := ParseAddExpr;
    Result := TSqlBinaryOpNode.Create(Op, Result, Right);
  end;
end;

function TVDbParser.ParseAddExpr: TSqlExprNode;
var T: string; Op: TSqlBinaryOp; Right: TSqlExprNode;
    SavePos, SaveIdx: Integer;
begin
  Result := ParseMulExpr;
  while True do
  begin
    SavePos := FPos; SaveIdx := FParamIdx;
    if not NextToken(T) then Break;
    if T = '+'  then Op := sboAdd
    else if T = '-' then Op := sboSub
    else if (T = '|') and (PeekToken = '|') then
    begin
      // || string concat -> sboAdd (string kontekstinde)
      NextToken(T);
      Op := sboAdd;
    end
    else begin FPos := SavePos; FParamIdx := SaveIdx; Break; end;
    Right := ParseMulExpr;
    Result := TSqlBinaryOpNode.Create(Op, Result, Right);
  end;
end;

function TVDbParser.ParseMulExpr: TSqlExprNode;
var T: string; Op: TSqlBinaryOp; Right: TSqlExprNode;
    SavePos, SaveIdx: Integer;
begin
  Result := ParseUnaryExpr;
  while True do
  begin
    SavePos := FPos; SaveIdx := FParamIdx;
    if not NextToken(T) then Break;
    if T = '*'  then Op := sboMul
    else if T = '/' then Op := sboDiv
    else if T = '%' then Op := sboMod
    else begin FPos := SavePos; FParamIdx := SaveIdx; Break; end;
    Right := ParseUnaryExpr;
    Result := TSqlBinaryOpNode.Create(Op, Result, Right);
  end;
end;

function TVDbParser.ParseUnaryExpr: TSqlExprNode;
var T: string;
begin
  if PeekToken = '-' then
  begin
    NextToken(T);
    Result := TSqlUnaryOpNode.Create(suoNeg, ParsePrimary);
  end
  else
    Result := ParsePrimary;
end;

function TVDbParser.ParseInList(Expr: TSqlExprNode; IsNot: Boolean): TSqlInNode;
var T: string; Item: TSqlExprNode;
begin
  Result := TSqlInNode.Create(Expr, IsNot);
  if PeekToken = ')' then begin NextToken(T); Exit; end; // bos IN listesi
  // P5-2: IN (SELECT ...) — ic sorgu tek kolon dondurmelidir.
  // (ParseSelect SELECT anahtarini tuketmez; burada yutulur.)
  if PeekToken = 'SELECT' then
  begin
    NextToken(T); // SELECT
    Result.SubSelect := ParseSelect;
    Expect(')');
    Exit;
  end;
  while True do
  begin
    Item := ParseExpr;
    Result.List.Add(Item);
    if PeekToken = ')' then begin NextToken(T); Break; end;
    Expect(',');
  end;
end;

function TVDbParser.ParseFuncCall(const FuncName: string): TSqlExprNode;
var T: string; Arg, Arg2: TSqlExprNode; IsStar, IsDistinct: Boolean; Args: TList<TSqlExprNode>; i: Integer;
// F-25: RANGE() ham arguman metni ('~' ile birlestirilir) + tek literal listesi
  raw: string; litList: TList<TSqlExprNode>;
    aggN: TSqlAggNode; aggKind: TAggKind; aggPct: Double;
    filterNode: TSqlExprNode;   // F-16
begin
  // P5-WIN: LAG/LEAD ayri yoldan cozumlener (OVER sart).
  if (FuncName = 'LAG') or (FuncName = 'LEAD') then
    Exit(ParseLagLead(FuncName));

  // F-02: NULLIF(a,b) — iki arguman; COALESCE(a,b,c,...) — degisken arguman
  if FuncName = 'NULLIF' then
  begin
    Arg := ParseExpr;
    Expect(','); Arg2 := ParseExpr; Expect(')');
    Exit(TSqlNullIfNode.Create(Arg, Arg2));
  end;
  if FuncName = 'COALESCE' then
  begin
    Args := TList<TSqlExprNode>.Create;
    try
      repeat
        Args.Add(ParseExpr);
        if PeekToken <> ',' then Break;
        NextToken(T);
      until False;
      Expect(')');
      Result := TSqlCoalesceNode.Create(Args);
      Exit;
    except
      Args.Free; raise;
    end;
  end;

  // F-24: SPATIAL — DISTANCE / HAVERSINE / IN_CIRCLE / IN_BOX / IN_POLYGON / AREA_POLYGON
  // ROUND da burada: ROUND(x[, digits]) degisken argumanlidir; tek-argumanli
  // yolda fn.Args nil kalir ve EvalExpr'de fn.Args.Count -> AV verir.
  if (FuncName = 'DISTANCE') or (FuncName = 'HAVERSINE') or
     (FuncName = 'IN_CIRCLE') or (FuncName = 'IN_BOX') or
     (FuncName = 'IN_POLYGON') or (FuncName = 'AREA_POLYGON') or
     (FuncName = 'ROUND') then
  begin
    Args := TList<TSqlExprNode>.Create;
    try
      if PeekToken = ')' then
      begin
        NextToken(T);
      end
      else
      begin
        repeat
          Args.Add(ParseExpr);
          if PeekToken <> ',' then Break;
          NextToken(T);   // ','
        until False;
        Expect(')');
      end;
      Result := TSqlFuncCallNode.Create(FuncName, nil, False, False);
      TSqlFuncCallNode(Result).Args := Args;
      Args := nil;   // sahiplik dugumde
    except
      Args.Free; raise;
    end;
    Exit;
  end;

  // F-25: RANGE(alt, ust [, '[]'|'[)'|'(]'|'()'])
  // NOT: RANGE argumanlari duz ParseExpr ile AYRISTIRILAMAZ. Metin icinde
  // yazilan "1..5" ifadesi lexer'da '1', '.', '.', '5' olarak gelir ve
  // ParseExpr hata verir. Bu yuzden tum argumanlar ham metin olarak
  // toplanip tek bir literal dugumde birlestirilir; ayristirmayi motor
  // (VDbMakeRange) yapar.
  if FuncName = 'RANGE' then
  begin
    raw := '';
    litList := TList<TSqlExprNode>.Create;
    try
      // DIKKAT: ParseFuncCall'a girerken '(' HENUZ YUTULMAMISTIR; ParsePrimary
      // yalnizca fonksiyon adini okur, bu yuzden burada '(' beklenmez.
      if PeekToken <> ')' then
      begin
        repeat
          if not NextToken(T) then
            raise EVDbException.Create(ecSyntaxError, 'RANGE() kapatilmadi');
          if T = '''' then T := '';
          if raw = '' then raw := T else raw := raw + '~' + T;
          if PeekToken <> ',' then Break;
          NextToken(T);   // ','
        until False;
      end;
      Expect(')');
      litList.Add(TSqlLiteralNode.CreateStr(raw));
      Result := TSqlFuncCallNode.Create(FuncName, nil, False, False);
      TSqlFuncCallNode(Result).Args := litList;
      litList := nil;
    except
      litList.Free; raise;
    end;
    Exit;
  end;

  // F-25: CONTAINS(aralik, nokta) — normal ifade argumanlari
  if FuncName = 'CONTAINS' then
  begin
    Args := TList<TSqlExprNode>.Create;
    try
      if PeekToken = ')' then NextToken(T)
      else
      begin
        repeat
          Args.Add(ParseExpr);
          if PeekToken <> ',' then Break;
          NextToken(T);
        until False;
        Expect(')');
      end;
      Result := TSqlFuncCallNode.Create(FuncName, nil, False, False);
      TSqlFuncCallNode(Result).Args := Args;
      Args := nil;
    except
      Args.Free; raise;
    end;
    Exit;
  end;

  // F-23: XML — degisken argumanli fonksiyonlar.
//   XMLELEMENT('ad', icerik [, icerik...])
//   XMLCONCAT(a, b, ...)
//   XMLEXTract(xml, yol) | XMLEXISTS(xml, yol) | XMLCOUNT(xml, yol)
//   XMLATTR(xml, yol, 'ad') | XMLESCAPE(s) | XMLPARSE(s)
  if Copy(FuncName, 1, 3) = 'XML' then
  begin
    if (FuncName <> 'XMLELEMENT') and (FuncName <> 'XMLCONCAT') and
       (FuncName <> 'XMLEXTRACT') and (FuncName <> 'XMLEXISTS') and
       (FuncName <> 'XMLCOUNT') and (FuncName <> 'XMLATTR') and
       (FuncName <> 'XMLESCAPE') and (FuncName <> 'XMLPARSE') then
      raise EVDbException.CreateFmt(ecSyntaxError,
        'bilinmeyen XML fonksiyonu: %s', [FuncName]);
    Args := TList<TSqlExprNode>.Create;
    try
      if PeekToken = ')' then
      begin
        NextToken(T);
      end
      else
      begin
        repeat
          Args.Add(ParseExpr);
          if PeekToken <> ',' then Break;
          NextToken(T);   // ','
        until False;
        Expect(')');
      end;
      Result := TSqlFuncCallNode.Create(FuncName, nil, False, False);
      TSqlFuncCallNode(Result).Args := Args;
      Args := nil;   // sahiplik dugumde
    except
      Args.Free; raise;
    end;
    Exit;
  end;

  // F-14: STRING_AGG(deger, ayirac [, DISTINCT])
  if FuncName = 'STRING_AGG' then
  begin
    aggN := TSqlAggNode.Create(akStringAgg);
    try
      if PeekToken = 'DISTINCT' then
      begin
        NextToken(T);
        aggN.IsDistinct := True;
      end;
      aggN.Arg := ParseExpr;
      if PeekToken = ',' then
      begin
        NextToken(T);
        aggN.Sep := ParseExpr;
      end;
      Expect(')');
      Result := aggN;
      aggN := nil;
      Exit;
    except
      aggN.Free;
      raise;
    end;
  end;
  // F-15: PERCENTILE_CONT/DISC(0.5) WITHIN GROUP (ORDER BY kolon)
  // DIKKAT: ParseFuncCall'a girerken '(' HENUZ YUTULMAMISTIR (ParsePrimary
  // yalnizca ismi okur, '(' kontrolu ParseFuncCall'da yapilir).
  if (FuncName = 'PERCENTILE_CONT') or (FuncName = 'PERCENTILE_DISC') or
     (FuncName = 'PERCENTILE') then
  begin
    if FuncName = 'PERCENTILE_DISC' then aggKind := akPercentileDisc
    else aggKind := akPercentileCont;
    aggN := TSqlAggNode.Create(aggKind);
    try
      // '(' ParsePrimary'da ZATEN yutuldu (bkz. ParsePrimary:1132)
      ExpectToken(T);
      if not VDbParseFloat(T, aggPct) or (aggPct < 0) or (aggPct > 1) then
        raise EVDbException.CreateFmt(ecSyntaxError,
          'PERCENTILE: 0..1 arasi oran bekleniyor, "%s" bulundu (%s)', [T, CurPos]);
      aggN.Pct := aggPct;
      Expect(')');
      // WITHIN GROUP (ORDER BY kolon [ASC|DESC])
      if PeekToken <> 'WITHIN' then
        raise EVDbException.CreateFmt(ecSyntaxError,
          'PERCENTILE: WITHIN GROUP bekleniyor (%s)', [CurPos]);
      NextToken(T); // WITHIN
      Expect('GROUP');
      Expect('(');
      Expect('ORDER');
      Expect('BY');
      aggN.Arg := ParseExpr;
      if PeekToken = 'DESC' then NextToken(T)
      else if PeekToken = 'ASC' then NextToken(T);
      Expect(')');
      Result := aggN;
      aggN := nil;
      Exit;
    except
      aggN.Free;
      raise;
    end;
  end;

  IsStar := False; IsDistinct := False; Arg := nil; filterNode := nil;
  if PeekToken = '*' then
  begin
    NextToken(T); IsStar := True;
  end
  else if PeekToken = 'DISTINCT' then
  begin
    NextToken(T); IsDistinct := True;
    Arg := ParseExpr;
  end
  else if PeekToken <> ')' then
    Arg := ParseExpr;
  Expect(')');
  // F-16: FILTER (WHERE ...) — aggregate'e satir filtresi.
  // Yalniz aggregate fonksiyonlarinda gecerli.
  if PeekToken = 'FILTER' then
  begin
    if not ((FuncName = 'COUNT') or (FuncName = 'SUM') or (FuncName = 'AVG') or
            (FuncName = 'MIN') or (FuncName = 'MAX')) then
      raise EVDbException.CreateFmt(ecSyntaxError,
        'FILTER yalnizca aggregate fonksiyonlarında kullanılabilir: %s', [FuncName]);
    NextToken(T);   // FILTER
    Expect('(');
    Expect('WHERE');
    filterNode := ParseExpr;
    Expect(')');
  end;
  // P5-WIN: pencere cagrisi mi?
  if PeekToken = 'OVER' then
  begin
    if IsDistinct then
      raise EVDbException.Create(ecSyntaxError,
        FuncName + '(DISTINCT ...) OVER ile kullanilamaz');
    // F-16: FILTER + OVER birlikte desteklenmez (pencere cercevesi ile
    // satir filtresi birlestirilemez).
    if filterNode <> nil then
    begin
      filterNode.Free; filterNode := nil;
      raise EVDbException.Create(ecSyntaxError,
        FuncName + '(...) FILTER (...) OVER ile kullanilamaz');
    end;
    try
      Result := ParseOver(FuncName, Arg, IsStar, 1, nil);
      Arg := nil; // sahiplik dugumde
      filterNode.Free; filterNode := nil;   // F-16: OVER ile birlikte desteklenmez
    except
      Arg.Free;
      raise;
    end;
    Exit;
  end;
  Result := TSqlFuncCallNode.Create(FuncName, Arg, IsStar, IsDistinct);
  // F-16: filtre dugumu sahipligi devralir (Arg'dan bagimsiz).
  TSqlFuncCallNode(Result).Filter := filterNode;
  filterNode := nil;
end;

function TVDbParser.ParseLagLead(const FuncName: string): TSqlExprNode;
var
  T: string;
  Arg, Def: TSqlExprNode;
  Off: Int64;
begin
  Arg := nil; Def := nil; Off := 1;
  try
    if PeekToken = ')' then
      raise EVDbException.Create(ecSyntaxError,
        FuncName + ' en az bir arguman ister');
    Arg := ParseExpr;
    if PeekToken = ',' then
    begin
      NextToken(T);
      ExpectToken(T);
      if not VDbParseInt(T, Off) or (Off < 0) or (Off > 1000000000) then
        raise EVDbException.Create(ecSyntaxError,
          FuncName + ' offseti dogal sayi olmali');
      if PeekToken = ',' then
      begin
        NextToken(T);
        Def := ParseExpr;
      end;
    end;
    Expect(')');
    if PeekToken <> 'OVER' then
      raise EVDbException.Create(ecSyntaxError,
        FuncName + ' yalnizca OVER ile kullanilabilir');
    Result := ParseOver(FuncName, Arg, False, Off, Def);
    Arg := nil; Def := nil; // sahiplik dugumde
  except
    Arg.Free;
    Def.Free;
    raise;
  end;
end;

function TVDbParser.ParseOver(const FuncName: string; Arg: TSqlExprNode;
  IsStar: Boolean; Off: Int64; Def: TSqlExprNode): TSqlWindowNode;
var
  T, U: string;
  E: TSqlExprNode;
  Item: TOrderItem;
begin
  // Giriste 'OVER' henuz yutulmadi. Arg/Def sahiplenmesi YALNIZ basarida
  // gecer (cagiran hata yolunda kendi kopyasini temizler).
  Result := TSqlWindowNode.Create(FuncName);
  try
    if (FuncName = 'ROW_NUMBER') or (FuncName = 'RANK') or
       (FuncName = 'DENSE_RANK') then
    begin
      if (Arg <> nil) or IsStar then
        raise EVDbException.Create(ecSyntaxError,
          FuncName + ' arguman almaz');
    end
    else if (FuncName = 'LAG') or (FuncName = 'LEAD') then
    begin
      if Arg = nil then
        raise EVDbException.Create(ecSyntaxError,
          FuncName + ' en az bir arguman ister');
    end
    else if not ((FuncName = 'COUNT') or (FuncName = 'SUM') or
            (FuncName = 'AVG') or (FuncName = 'MIN') or (FuncName = 'MAX')) then
      raise EVDbException.Create(ecSyntaxError,
        FuncName + ' OVER ile kullanilamaz');
    NextToken(T); // OVER
    Expect('(');
    if PeekToken = 'PARTITION' then
    begin
      NextToken(T);
      Expect('BY');
      repeat
        E := ParseExpr;
        Result.Partitions.Add(E);
        if PeekToken <> ',' then Break;
        NextToken(T);
      until False;
    end;
    if PeekToken = 'ORDER' then
    begin
      NextToken(T);
      Expect('BY');
      repeat
        Item.Expr := ParseExpr;
        Item.Desc := False;
        Item.Collate := '';
        Item.NullsPos := -1;   // F-10
        U := PeekToken;
        if U = 'COLLATE' then begin ParseCollate(Item); U := PeekToken; end;
        if U = 'DESC' then begin NextToken(T); Item.Desc := True; U := PeekToken; end
        else if U = 'ASC' then begin NextToken(T); U := PeekToken; end;
        if U = 'COLLATE' then begin ParseCollate(Item); U := PeekToken; end;
        if U = 'NULLS' then
        begin
          NextToken(T); U := PeekToken;
          if U = 'FIRST' then begin NextToken(T); Item.NullsPos := 0; end
          else if U = 'LAST' then begin NextToken(T); Item.NullsPos := 1; end
          else
            raise EVDbException.CreateFmt(ecSyntaxError,
              'NULLS sonrasi FIRST veya LAST bekleniyor, "%s" bulundu (%s)', [U, CurPos]);
        end;
        Result.OrderBys.Add(Item);
        if PeekToken <> ',' then Break;
        NextToken(T);
      until False;
    end;
    // 4.6: Pencere cercevesi (ROWS / RANGE) — basit parser acik
    if PeekToken = 'ROWS' then
    begin
      NextToken(T); Result.FrameType := 'ROWS';
    end
    else if PeekToken = 'RANGE' then
    begin NextToken(T); Result.FrameType := 'RANGE'; end;
    Expect(')');
    Result.Arg := Arg;
    Result.IsStar := IsStar;
    Result.Offset := Integer(Off);
    Result.Default := Def;
  except
    Result.Free;
    raise;
  end;
end;

function TVDbParser.ParseCase: TSqlCaseNode;
var
  T: string;
  W: TSqlCaseWhen;
begin
  // Giriste 'CASE' yutuldu. Sade CASE (CASE x WHEN ...) ya da
  // aranan CASE (CASE WHEN ...). WHEN/THEN/ELSE/END sinir tasi olarak
  // ifade ayristirici tarafindan dogal durur (operator degiller).
  Result := TSqlCaseNode.Create(nil);
  try
    if PeekToken <> 'WHEN' then
      Result.Operand := ParseExpr;
    repeat
      Expect('WHEN');
      W.Cond := ParseExpr;
      W.Value := nil;
      Expect('THEN');
      W.Value := ParseExpr;
      Result.Whens.Add(W);
    until PeekToken <> 'WHEN';
    if PeekToken = 'ELSE' then
    begin
      NextToken(T);
      Result.ElseExpr := ParseExpr;
    end;
    Expect('END');
  except
    Result.Free;
    raise;
  end;
end;

function TVDbParser.ParsePrimary: TSqlExprNode;
var T, U, T2, TableQ: string; SavePos, SaveIdx: Integer;
    iv: Int64; fv: Double; IsLit: Boolean;
begin
  SavePos := FPos; SaveIdx := FParamIdx;
  ExpectToken(T, IsLit);
  U := UpperCase(T);

  // String sabiti (tek tırnaklı metin veya ? parametresi)
  if IsLit then
    Exit(TSqlLiteralNode.CreateStr(T));

  // NULL
  if U = 'NULL' then Exit(TSqlLiteralNode.CreateNull);

  // Booelan sabitleri
  if U = 'TRUE'  then Exit(TSqlLiteralNode.CreateBool(True));
  if U = 'FALSE' then Exit(TSqlLiteralNode.CreateBool(False));

  // Sayı sabiti
  if IsDigit(T[1]) then
  begin
    if Pos('.', T) > 0 then
    begin
      if VDbParseFloat(T, fv) then Exit(TSqlLiteralNode.CreateFloat(fv));
    end
    else
    begin
      if VDbParseInt(T, iv) then Exit(TSqlLiteralNode.CreateInt(iv));
    end;
    Exit(TSqlLiteralNode.CreateStr(T)); // fallback
  end;

  // Negatif sayı önüne geldiyse (-1 gibi)
  if T = '-' then
  begin
    ExpectToken(T2);
    if IsDigit(T2[1]) then
    begin
      if Pos('.', T2) > 0 then
      begin
        if VDbParseFloat(T2, fv) then Exit(TSqlLiteralNode.CreateFloat(-fv));
      end
      else if VDbParseInt(T2, iv) then
        Exit(TSqlLiteralNode.CreateInt(-iv));
    end;
    FPos := SavePos; FParamIdx := SaveIdx;
    Exit(ParseUnaryExpr);
  end;

  // String sabiti (tırnaklı — NextToken zaten tırnaksız döndürür)
  // Tırnaklı stringler NextToken tarafından zaten işlenip T'ye atanır;
  // ayrıca burada normal identifier olmayan her şeyi string sayalım:
  // Eğer T tırnak içinden geliyorsa IsAlpha kontrolü fail eder.
  // Ama NextToken '' değilse ve ilk char sayı/alpha değilse string gibi davran.
  if (Length(T) >= 1) and (not IsAlpha(T[1])) and (not IsDigit(T[1]))
     and (T <> '(') and (T <> ')') and (T <> ',') then
  begin
    // Operatör vs. → geri sar
    FPos := SavePos; FParamIdx := SaveIdx;
    raise EVDbException.CreateFmt(ecSyntaxError, 'Beklenmedik token: "%s" (%s)', [T, CurPos]);
  end;

  // CASE ifadesi mi? (WHEN'den once gelmeli; yoksa 'case' kolon sayilir)
  if U = 'CASE' then Exit(ParseCase);

  // Fonksiyon çağrısı mı?
  if IsAlpha(T[1]) and (PeekToken = '(') then
  begin
    NextToken(T2); // '('
    Exit(ParseFuncCall(UpperCase(T)));
  end;

  // Kolon referansı: ident veya tablo.kolon
  if IsAlpha(T[1]) then
  begin
    TableQ := '';
    if PeekToken = '.' then
    begin
      NextToken(T2); // '.'
      TableQ := T;
      ExpectToken(T);
    end;
    Exit(TSqlColumnRefNode.Create(T, TableQ));
  end;

  // Alt sorgu veya gruplanmış ifade: (...)
  if T = '(' then
  begin
    Inc(FDepth);
    try
      if FDepth > 256 then
        raise EVDbException.Create(ecSyntaxError, 'ifade derinligi cok fazla (max 256)');
      // P5-2: skaler alt sorgu ((SELECT ...) tek deger dondurur).
      if PeekToken = 'SELECT' then
      begin
        NextToken(T2); // SELECT
        Result := TSqlSubqueryNode.CreateScalar(ParseSelect);
        Expect(')');
        Exit;
      end;
      Result := ParseExpr;
      Expect(')');
      Exit;
    finally
      Dec(FDepth);
    end;
  end;

  // Daha önce NextToken tarafından string olarak okunan değer
  // (Tırnaklı stringler için — ilk karakter IsAlpha değil, sayı değil de string geldi)
  Exit(TSqlLiteralNode.CreateStr(T));
end;

{ ============================================================
  SELECT alt-parser'ları
  ============================================================ }

procedure TVDbParser.ParseSelectColumns(Stmt: TSqlSelectStmt);
var T, U: string; Item: TSelectColumnItem; SavePos, SaveIdx: Integer;
begin
  // SELECT * ?
  if PeekToken = '*' then
  begin
    NextToken(T); Exit; // Columns listesi boş = SELECT *
  end;

  while True do
  begin
    Item.Expr := ParseExpr;
    Item.Alias := '';
    // AS alias
    if PeekToken = 'AS' then
    begin
      NextToken(T); ExpectToken(Item.Alias);
    end
    else
    begin
      // örtük alias: FROM/WHERE/GROUP/ORDER/LIMIT/HAVING/UNION/EXCEPT/INTERSECT
      // /QUALIFY/FETCH/OFFSET/JOIN/','/';'/')' değilse
      SavePos := FPos; SaveIdx := FParamIdx;
      if NextToken(T) then
      begin
        U := UpperCase(T);
        if not (U = 'FROM') and not (U = 'WHERE') and not (U = 'GROUP') and
           not (U = 'ORDER') and not (U = 'LIMIT') and not (U = 'HAVING') and
           not (U = 'UNION') and not (U = 'EXCEPT') and not (U = 'INTERSECT') and
           not (U = 'QUALIFY') and            // F-09
           not (U = 'FETCH') and              // F-08
           not (U = 'OFFSET') and not (U = 'JOIN') and
           not (U = ',') and not (U = ';') and not (U = ')') then
          Item.Alias := T   // örtük alias
        else
          begin FPos := SavePos; FParamIdx := SaveIdx; end;
      end;
    end;
    Stmt.Columns.Add(Item);

    if PeekToken = ',' then begin NextToken(T); Continue; end;
    Break;
  end;
end;

procedure TVDbParser.ParseFromClause(Stmt: TSqlSelectStmt);
var T, U: string; SavePos, SaveIdx: Integer;
begin
  ExpectToken(T); Stmt.FromTable := VDbNorm(T);

  // 2026-10-06 AS OF: "FROM t AS OF ..." (alias ONCESI)
  if (PeekToken = 'AS') and (PeekToken2 = 'OF') then
  begin
    ExpectToken(T);                 // 'AS' yut
    ParseAsOfTail(Stmt);
    Exit;
  end;

  // Alias kontrolü
  SavePos := FPos; SaveIdx := FParamIdx;
  if NextToken(T) then
  begin
    U := UpperCase(T);
    if (U = 'AS') then ExpectToken(Stmt.FromAlias)
    else if not (U = 'WHERE') and not (U = 'INNER') and not (U = 'LEFT') and
            not (U = 'RIGHT') and not (U = 'FULL') and not (U = 'OUTER') and
            not (U = 'JOIN')  and not (U = 'GROUP') and not (U = 'ORDER') and
            not (U = 'LIMIT') and not (U = 'HAVING') and not (U = 'UNION') and
            not (U = 'EXCEPT') and not (U = 'INTERSECT') and
            not (U = 'CROSS') and
            // F-27/F-29: NATURAL / LATERAL JOIN — alias degil, JOIN anahtari
            not (U = 'NATURAL') and not (U = 'LATERAL') and
            not (U = 'QUALIFY') and   // F-09
            not (U = 'FETCH') and     // F-08
            not (U = 'OFFSET') and
            not (U = ';') and not (U = ')') then
      Stmt.FromAlias := T
    else
      begin FPos := SavePos; FParamIdx := SaveIdx; end;
  end;

  // AS OF: "FROM t x AS OF ..." / "FROM t AS x AS OF ..." (alias SONRASI)
  if (Stmt.AsOf = saoNone) and (PeekToken = 'AS') and (PeekToken2 = 'OF') then
  begin
    ExpectToken(T);                 // 'AS' yut
    ParseAsOfTail(Stmt);
  end;
end;

procedure TVDbParser.ParseAsOfTail(Stmt: TSqlSelectStmt);
// AS OF kuyrugu. 'AS' zaten yutulmus durumda gelir.
//   SEQUENCE n     -> cozumleme executor'da (WAL kayit indeksi)
//   VERSION x      -> birakilir, executor ecUnsupported verir
//   TIMESTAMP '...'-> birakilir, executor ecUnsupported verir
var
  T, U: string;
  q: QWord;
begin
  Expect('OF');
  ExpectToken(T); U := UpperCase(T);
  if U = 'SEQUENCE' then
  begin
    ExpectToken(T);
    if not TryStrToQWord(T, q) then
      raise EVDbException.CreateFmt(ecSyntaxError,
        'AS OF SEQUENCE: gecerli bir sayi bekleniyor, "%s" bulundu (%s)',
        [T, CurPos]);
    Stmt.AsOf := saoSequence;
    Stmt.AsOfValue := q;
  end
  else if (U = 'VERSION') or (U = 'TIMESTAMP') then
  begin
    if U = 'VERSION' then Stmt.AsOf := saoVersion
    else Stmt.AsOf := saoTimestamp;
    ExpectToken(T);
    Stmt.AsOfText := T;
    if Stmt.AsOfText = '' then
      raise EVDbException.CreateFmt(ecSyntaxError,
        'AS OF %s: deger bos olamaz (%s)', [U, CurPos]);
  end
  else
    raise EVDbException.CreateFmt(ecSyntaxError,
      'AS OF sonrasi SEQUENCE, VERSION veya TIMESTAMP bekleniyor, "%s" bulundu (%s)',
      [T, CurPos]);
end;

procedure TVDbParser.ParseJoinClause(var JC: TJoinClause; AllowNoOn: Boolean;
  out ExitCols: TStrArray);
var T, U: string; SavePos, SaveIdx: Integer; usingList: TStringList; i: Integer;
begin
  JC.OnCondition := nil;
  ExitCols := nil;
  // DIKKAT: JC.Natural ve JC.UsingCols burada SIFIRLANMAZ.
  //  - Natural: JOIN dongusu bu bayragi ONCE set eder; sifirlanirsa
  //    "ON'suz JOIN hata vermeli" regresyonu olusur.
  //  - UsingCols: dinamik diziyi bir RECORD'u var ile gecirip
  //    SetLength uygulamak FPC'de ayni kopyayi bozabiliyor; ayrica
  //    NATURAL/USING ayni klamada kullanilamaz, sonra biri sifirlarsa
  //    digerinin durumu bozulur. Bunun yerine USING ayrimi asagida
  //    yalnizca kendi yolunda yapilir.
  if PeekToken = 'JOIN' then NextToken(T);
  // Tablo adi
  ExpectToken(T); JC.Table := VDbNorm(T);
  JC.Alias := '';
  // Alias
  if PeekToken = 'AS' then begin NextToken(T); ExpectToken(JC.Alias); end
  else
  begin
    SavePos := FPos; SaveIdx := FParamIdx;
    if NextToken(T) then
    begin
      // JOIN anahtarlari alias degildir (zincirde sonraki JOIN gelir).
      // ORDER/GROUP/HAVING/LIMIT/UNION/QUALIFY/FETCH de alias DEGILDIR:
      // aksi halde "FROM a JOIN b ORDER BY x" yaziminda 'ORDER' alias
      // olur ve 'BY' artik token olarak kalir ("anlasilamayan ek: BY").
      U := UpperCase(T);
      if (U = 'ON') or (U = 'JOIN') or (U = 'INNER') or (U = 'LEFT') or
         (U = 'RIGHT') or (U = 'FULL') or (U = 'OUTER') or (U = 'CROSS') or
         (U = 'USING') or (U = 'NATURAL') or (U = 'WHERE') or
         (U = 'GROUP') or (U = 'ORDER') or (U = 'HAVING') or
         (U = 'LIMIT') or (U = 'OFFSET') or (U = 'UNION') or
         (U = 'EXCEPT') or (U = 'INTERSECT') or (U = 'QUALIFY') or
         (U = 'FETCH') or (U = ';') or (U = ')') then
      begin FPos := SavePos; FParamIdx := SaveIdx; end
      else JC.Alias := T;
    end;
  end;
  // F-27/F-28: NATURAL ve USING. Ikisi de ON'in yerine gecer.
  if PeekToken = 'USING' then
  begin
    NextToken(T);
    Expect('(');
    usingList := TStringList.Create;
    try
      repeat
        ExpectToken(T);
        usingList.Add(VDbNorm(T));
        if PeekToken <> ',' then Break;
        NextToken(T);
      until False;
      Expect(')');
    ExitCols := nil;
      SetLength(ExitCols, usingList.Count);
      for i := 0 to usingList.Count - 1 do
        ExitCols[i] := usingList[i];
    finally
      usingList.Free;
    end;
    // USING listesi TJoinClause'a DEGIL, ayri bir kayda yazilir
    // (bkz. TJoinUsingRec yorumu).
    Exit;
  end;
  // ON kosulu. 4.1 CROSS JOIN: CROSS'ta opsiyoneldir - ON yoksa kosul
  // her zaman dogru sayilir (EvalBool(nil)=True) = cartesius carpani;
  // ON yazildiysa INNER gibi filtre uygulanir. Diger turlerde
  // (INNER/LEFT/RIGHT/FULL) ON hala zorunludur: ON'suz JOIN hata verir.
  if PeekToken = 'ON' then
  begin
    NextToken(T);
    JC.OnCondition := ParseExpr;
  end
  else if not AllowNoOn then
    Expect('ON');   // -> '"ON" bekleniyor, ...' ecSyntaxError
end;

procedure TVDbParser.ParseGroupBy(Stmt: TSqlSelectStmt);
var T, T2: string;
begin
  // GROUP zaten yutuldu
  Expect('BY');
  while True do
  begin
    // 4.2 (06.10.2026): nitelemeli yazim da okunur ('m.sehir'):
    // tokenizer noktayi AYRI token verir (ifadedeki kolon referansi
    // parseri birlestirir); burada da ayni birlestirme yapilir.
    // Eskiden yalniz ilk token ('m') aliniyordu: kalan '.sehir' sondan
    // "anlasilamayan ek" hatasi ya da (eski birebir cozumlemede)
    // sessizce tek gruba dusme sonucunu veriyordu.
    ExpectToken(T);
    while PeekToken = '.' do
    begin
      NextToken(T2);                    // '.' yut
      ExpectToken(T2);                  // kolon adi (yoksa hata)
      T := T + '.' + T2;
    end;
    Stmt.GroupByCols.Add(VDbNorm(T));
    if PeekToken = ',' then begin NextToken(T); Continue; end;
    Break;
  end;
  // HAVING
  if PeekToken = 'HAVING' then
  begin
    NextToken(T);
    Stmt.HavingClause := ParseExpr;
  end;
end;

procedure TVDbParser.ParseOrderBy(Stmt: TSqlSelectStmt);
var T, U: string; Item: TOrderItem;
begin
  // ORDER zaten yutuldu
  Expect('BY');
  while True do
  begin
    Item.Expr := ParseExpr;
    Item.Desc := False;
    Item.Collate := '';
    Item.NullsPos := -1;   // F-10: -1 = motor varsayilani
    // Sira serbest: [COLLATE x] [ASC|DESC] [COLLATE x] [NULLS FIRST|LAST]
    U := PeekToken;
    if U = 'COLLATE' then begin ParseCollate(Item); U := PeekToken; end;
    if U = 'DESC' then begin NextToken(T); Item.Desc := True; U := PeekToken; end
    else if U = 'ASC' then begin NextToken(T); U := PeekToken; end;
    if U = 'COLLATE' then begin ParseCollate(Item); U := PeekToken; end;
    // F-10: NULLS FIRST / NULLS LAST
    if U = 'NULLS' then
    begin
      NextToken(T);
      U := PeekToken;
      if U = 'FIRST' then begin NextToken(T); Item.NullsPos := 0; end
      else if U = 'LAST' then begin NextToken(T); Item.NullsPos := 1; end
      else
        raise EVDbException.CreateFmt(ecSyntaxError,
          'NULLS sonrasi FIRST veya LAST bekleniyor, "%s" bulundu (%s)', [U, CurPos]);
      U := PeekToken;
    end;
    Stmt.OrderBy.Add(Item);
    if PeekToken = ',' then begin NextToken(T); Continue; end;
    Break;
  end;
end;

procedure TVDbParser.ParseCollate(var Item: TOrderItem);
var
  T: string;
begin
  Item.Collate := '';
  if PeekToken <> 'COLLATE' then Exit;
  NextToken(T); // COLLATE
  ExpectToken(T);
  Item.Collate := UpperCase(T);
  if Item.Collate <> 'TR' then
    raise EVDbException.CreateFmt(ecSyntaxError,
      'bilinmeyen COLLATE: "%s" (desteklenen: TR)', [T]);
end;

{ ============================================================
  SELECT kuyrugu: ORDER BY / LIMIT / OFFSET
  F1-12: Bu blok ayri bir procedure oldu; set-op sonrasi kuyruk
  DIS cumleye yazilabilsin diye. F1-18: bozuk/negatif deger sessizce
  yutulmaz.
  ============================================================ }
procedure TVDbParser.ParseSelectTail(Stmt: TSqlSelectStmt);
var
  T: string;
  limIv, offIv: Int64;
begin
  // ORDER BY
  if PeekToken = 'ORDER' then begin NextToken(T); ParseOrderBy(Stmt); end;

  // LIMIT / OFFSET
  if PeekToken = 'LIMIT' then
  begin
    NextToken(T); ExpectToken(T);
    if not VDbParseInt(T, limIv) or (limIv < 0) then
      raise EVDbException.CreateFmt(ecSyntaxError, 'LIMIT: dogal sayi bekleniyor, "%s" bulundu (%s)', [T, CurPos]);
    if limIv > 2000000 then
      raise EVDbException.CreateFmt(ecLimit, 'LIMIT cok buyuk (max 2000000): %d', [limIv]);
    Stmt.LimitVal := Integer(limIv);
    if PeekToken = 'OFFSET' then
    begin
      NextToken(T); ExpectToken(T);
      if not VDbParseInt(T, limIv) or (limIv < 0) then
        raise EVDbException.CreateFmt(ecSyntaxError, 'OFFSET: dogal sayi bekleniyor, "%s" bulundu (%s)', [T, CurPos]);
      Stmt.OffsetVal := Integer(limIv);
    end;
  end;
  if PeekToken = 'OFFSET' then
  begin
    NextToken(T); ExpectToken(T);
    if not VDbParseInt(T, offIv) or (offIv < 0) then
      raise EVDbException.CreateFmt(ecSyntaxError, 'OFFSET: dogal sayi bekleniyor, "%s" bulundu (%s)', [T, CurPos]);
    Stmt.OffsetVal := Integer(offIv);
    // F-08: OFFSET n ROW / OFFSET n ROWS (SQL:2008 yazimi)
    if PeekToken = 'ROW' then NextToken(T)
    else if PeekToken = 'ROWS' then NextToken(T);
    // F1-10: "OFFSET n LIMIT m" yazimi da gecerli (LIMIT n OFFSET m ile
    // ayni). Once yalniz LIMIT ... OFFSET ... kabul ediliyordu.
    if PeekToken = 'LIMIT' then
    begin
      NextToken(T); ExpectToken(T);
      if not VDbParseInt(T, limIv) or (limIv < 0) then
        raise EVDbException.CreateFmt(ecSyntaxError, 'LIMIT: dogal sayi bekleniyor, "%s" bulundu (%s)', [T, CurPos]);
      if limIv > 2000000 then
        raise EVDbException.CreateFmt(ecLimit, 'LIMIT cok buyuk (max 2000000): %d', [limIv]);
      Stmt.LimitVal := Integer(limIv);
    end;
  end;

  // F-08 (SQL:2008): FETCH { FIRST | NEXT } [ n ] { ROW | ROWS } { ONLY }
  // LIMIT'in standart yazimi; ayni LimitVal degerini yazar.
  if PeekToken = 'FETCH' then
  begin
    NextToken(T);
    if (PeekToken <> 'FIRST') and (PeekToken <> 'NEXT') then
      raise EVDbException.CreateFmt(ecSyntaxError,
        'FETCH sonrasi FIRST veya NEXT bekleniyor, "%s" bulundu (%s)', [PeekToken, CurPos]);
    NextToken(T);
    limIv := 1;   // FETCH NEXT ROWS ONLY (n yoksa 1)
    // n yoksa: dogrudan ROW/ROWS gelir. n varsa: once sayi.
    if (PeekToken <> 'ROW') and (PeekToken <> 'ROWS') then
    begin
      ExpectToken(T);
      if not VDbParseInt(T, limIv) or (limIv < 0) then
        raise EVDbException.CreateFmt(ecSyntaxError,
          'FETCH: dogal sayi bekleniyor, "%s" bulundu (%s)', [T, CurPos]);
    end;
    // ROW | ROWS (sayi yazilmadiysa burada beklenir)
    if PeekToken = 'ROW' then NextToken(T)
    else if PeekToken = 'ROWS' then NextToken(T)
    else
      raise EVDbException.CreateFmt(ecSyntaxError,
        'FETCH sonrasi ROW/ROWS bekleniyor, "%s" bulundu (%s)', [PeekToken, CurPos]);
    // WITH TIES (desteklenmiyor — bag ile kirpilma gerekir)
    if PeekToken = 'WITH' then
    begin
      NextToken(T); Expect('TIES');
      raise EVDbException.Create(ecUnsupported,
        'FETCH WITH TIES desteklenmiyor (LUSTE kullanin)');
    end;
    if PeekToken <> 'ONLY' then
      raise EVDbException.CreateFmt(ecSyntaxError,
        'FETCH sonrasi ONLY bekleniyor, "%s" bulundu (%s)', [PeekToken, CurPos]);
    NextToken(T);
    if limIv > 2000000 then
      raise EVDbException.CreateFmt(ecLimit, 'FETCH cok buyuk (max 2000000): %d', [limIv]);
    Stmt.LimitVal := Integer(limIv);
    // FETCH ... OFFSET n [ROW|ROWS]
    if PeekToken = 'OFFSET' then
    begin
      NextToken(T); ExpectToken(T);
      if not VDbParseInt(T, offIv) or (offIv < 0) then
        raise EVDbException.CreateFmt(ecSyntaxError,
          'OFFSET: dogal sayi bekleniyor, "%s" bulundu (%s)', [T, CurPos]);
      Stmt.OffsetVal := Integer(offIv);
      if PeekToken = 'ROW' then NextToken(T)
      else if PeekToken = 'ROWS' then NextToken(T);
    end;
  end;
end;

{ ============================================================
  SELECT cümlesi
  ============================================================ }

function TVDbParser.ParseSelect: TSqlSelectStmt;
var T, U: string;
    limIv, offIv: Int64;
    Jc: TJoinClause;
    IsCross: Boolean;
    IsNat: Boolean;   // F-27: NATURAL bayragi ParseJoinClause'a ONCE set edilir
    UsingCols: TStrArray;   // F-28: bir JOIN'in USING listesi
begin
  Result := TSqlSelectStmt.Create;
  try
    // DISTINCT
    if PeekToken = 'DISTINCT' then begin NextToken(T); Result.IsDistinct := True; end;

    // Kolon listesi
    ParseSelectColumns(Result);

    // FROM
    if PeekToken <> 'FROM' then
    begin
      // FROM'suz SELECT: sabit ifadeler (SELECT 1, 'abc')
      Result.LimitVal := -1; Result.OffsetVal := 0;
      Exit;
    end;
    NextToken(T); // FROM yut

    ParseFromClause(Result);

    // JOIN zinciri (P5-1: 2+ tablo, sinir yok; P5-RF: RIGHT/FULL + OUTER;
    // 4.1: CROSS JOIN - ON'suz cartesius, ON yazildiysa INNER gibi).
    // Ilk JOIN Join alanina, sonrakiler MoreJoins listesine
    // (soldan derine uygulanir).
    U := PeekToken;
    while (U = 'INNER') or (U = 'LEFT') or (U = 'RIGHT') or
          (U = 'FULL') or (U = 'JOIN') or (U = 'CROSS') or
          (U = 'NATURAL') or (U = 'LATERAL') do
    begin
      IsCross := False;
      // DIKKAT: Jc yerel record değişkenidir ve FPC onu DONGULER ARASI
      // sifirlamaz. Onceki JOIN'de set edilen Natural/JoinType/OnCondition
      // sonraki JOIN'e SIZAR ve tum zinciri bozar. Her turda baslangic
      // durumu elle yazilir.
      Jc.JoinType := jtInner;
      Jc.Natural := False;
      Jc.LateralIdx := -1;
      Jc.OnCondition := nil;
      Jc.Table := '';
      Jc.Alias := '';
      if U = 'CROSS' then begin NextToken(T); Jc.JoinType := jtInner; IsCross := True; end
      // F-29: [INNER|LEFT|RIGHT|FULL] [OUTER] LATERAL (subquery|t) [ON ...]
      // Sol taraf herhangi bir turlen JOIN turunde LATERAL olabilir; bu
      // yuzden ONCESI turlenir, sonra tip belirlenir.
      else if (U = 'LATERAL') or
              ((U = 'JOIN') and (PeekToken2 = 'LATERAL')) or
              ((U = 'INNER') and (PeekToken2 = 'LATERAL')) then
      begin
        // DONGU BASINDA U := PeekToken yapildigi icin hicbir anahtar kelime
        // HENUZ tuketilmemistir. Bu blokta ONCE JOIN/INNER (varsa), SONRA
        // LATERAL tuketilir.
        if U <> 'LATERAL' then NextToken(T);   // JOIN/INNER yutulur
        // LATERAL tokenini tükét; sonrasinda (SELECT|table|ON) gelecek
        NextToken(T);   // LATERAL
        // LATERAL sonrasinda bir daha INNER/LEFT/RIGHT/FULL checki yapmayiz;
        // LATERAL'da JoinType INNER olarak ayarlanir (standard).
        Jc.JoinType := jtInner;
        Jc.LateralIdx := -1;
        // LATERAL sonrasinda geleni kontrol et:
        // 1) ONCE parantez mi? (SELECT ...) olabilir
        // 2) SELECT mi? (SELECT ... ) olabilir
        // 3) Table ismi mi? (table_adi ...) olabilir
        if PeekToken = '(' then
        begin
          NextToken(T);   // (
          if PeekToken = 'SELECT' then
          begin
            // Alt sorgu: TSqlSelectStmt.LateralSubs listesine konur; JOIN
            // kaydi yalnizca INDIS taşır (bkz. TJoinClause yorumu).
            Jc.LateralIdx := Result.LateralSubs.Count;
            Result.LateralSubs.Add(ParseSelect);
          end
          else
          begin
            // Unexpected token after '('
            Jc.LateralIdx := -99;
          end;
        end
        if PeekToken = '(' then
        begin
          NextToken(T);
          if PeekToken = 'SELECT' then
          begin
            Jc.LateralIdx := Result.LateralSubs.Count;
            Result.LateralSubs.Add(ParseSelect);
          end;
        end
        else if PeekToken = 'SELECT' then
        begin
          Jc.LateralIdx := Result.LateralSubs.Count;
          Result.LateralSubs.Add(ParseSelect);
        end
        else
        begin
          ExpectToken(T); Jc.Table := VDbNorm(T);;
        else
        begin
          // LATERAL tablo (sadece tablo ismi, ON ile)
          // TABLE ismi beklentisi - basit tabela donusum icin
          ExpectToken(T); Jc.Table := VDbNorm(T);;
        else
        begin
          // LATERAL tablo (sadece tablo ismi, ON ile)
          // TABLE ismi beklentisi - basit tabela donusum icin
          ExpectToken(T); Jc.Table := VDbNorm(T);
          Jc.Alias := '';
          if PeekToken = 'AS' then begin NextToken(T); ExpectToken(Jc.Alias); end;
          Jc.LateralIdx := -2;   // -2 = LATERAL tablo
        end;
        if PeekToken = 'ON' then
        begin
          NextToken(T);
          Jc.OnCondition := ParseExpr;
        end;
        if not Result.HasJoin then
        begin
          Result.HasJoin := True;
          Result.Join := Jc;
        end
        else
          Result.MoreJoins.Add(Jc);
        U := PeekToken;
        Continue;
      end
      // F-27: NATURAL [LEFT|RIGHT|FULL] JOIN — ON yazilmaz.
      else if U = 'NATURAL' then
      begin
        NextToken(T);
        Jc.JoinType := jtInner;
        Jc.Natural := True;
        // NATURAL INNER JOIN her zaman; sol taraf varsayilandir.
        if PeekToken = 'LEFT' then begin NextToken(T); Jc.JoinType := jtLeft; end
        else if PeekToken = 'RIGHT' then begin NextToken(T); Jc.JoinType := jtRight; end
        else if PeekToken = 'FULL' then begin NextToken(T); Jc.JoinType := jtFull; end;
      end
      else if U = 'INNER' then begin NextToken(T); Jc.JoinType := jtInner; end
      else if U = 'LEFT' then begin NextToken(T); Jc.JoinType := jtLeft; end
      else if U = 'RIGHT' then begin NextToken(T); Jc.JoinType := jtRight; end
      else if U = 'FULL' then begin NextToken(T); Jc.JoinType := jtFull; end
      else begin NextToken(T); Jc.JoinType := jtInner; end;
      // OUTER opsiyonel: LEFT/RIGHT/FULL [OUTER] JOIN. CROSS'ta gecersizdir.
      if IsCross and (PeekToken = 'OUTER') then
        raise EVDbException.Create(ecSyntaxError,
          'CROSS JOIN ile OUTER kullanilamaz (CROSS, INNER ile aynidir)');
      if (not IsCross) and (PeekToken = 'OUTER') then NextToken(T);
      // NATURAL ... JOIN: ON bekleme, esitlik executor'da cozulur.
      IsNat := Jc.Natural;
      ParseJoinClause(Jc, IsCross or IsNat, UsingCols);
      // F-28: USING listesi ayri kayda yazilir (MoreJoins ile ayni sira).
      if UsingCols <> nil then
        Result.JoinUsing.Add(TJoinUsingRec.Create(UsingCols));
      if not Result.HasJoin then
      begin
        Result.HasJoin := True;
        Result.Join := Jc;
      end
      else
        Result.MoreJoins.Add(Jc);
      U := PeekToken;
    end;

    // WHERE
    if PeekToken = 'WHERE' then begin NextToken(T); Result.WhereClause := ParseExpr; end;

    // GROUP BY
    if PeekToken = 'GROUP' then begin NextToken(T); ParseGroupBy(Result); end;

    // F-09: QUALIFY — pencere sonrasi filtre (GROUP BY'dan SONRA, ORDER BY'dan
    // ONCE). ParseGroupBy icinde DEGIL: QUALIFY'siz GROUP BY da olabilir.
    if PeekToken = 'QUALIFY' then
    begin
      NextToken(T);
      Result.QualifyClause := ParseExpr;
    end;

    // ORDER BY / LIMIT / OFFSET
    if not FSuppressTail then
      ParseSelectTail(Result);

    // SET OP: UNION [ALL] / EXCEPT / INTERSECT
    U := PeekToken;
    if (U = 'UNION') or (U = 'EXCEPT') or (U = 'INTERSECT') then
    begin
      NextToken(T);
      if U = 'UNION' then
      begin
        if PeekToken = 'ALL' then begin NextToken(T); Result.SetOp := sokUnionAll; end
        else Result.SetOp := sokUnion;
      end
      else if U = 'EXCEPT' then Result.SetOp := sokExcept
      else Result.SetOp := sokIntersect;

      // Sag taraf SELECT: kuyrugu bastirilir, cunku ORDER BY / LIMIT /
      // OFFSET birlestirme SONRASINA uygulanmali (F1-12).
      FSuppressTail := True;
      try
        Expect('SELECT');
        Result.RightSelect := ParseSelect;
      finally
        FSuppressTail := False;
      end;

      // Dis kuyruk (birlestirme sonrasi)
      ParseSelectTail(Result);
    end;

  except
    Result.Free;
    raise;
  end;
end;

{ ============================================================
  INSERT
  ============================================================ }

function TVDbParser.ParseInsert: TSqlInsertStmt;
var T: string; i: Integer; Row: TInsertValuesRow; Expr: TSqlExprNode;
begin
  Result := TSqlInsertStmt.Create;
  try
    Expect('INTO');
    ExpectToken(T); Result.Table := VDbNorm(T);

    // Kolon listesi opsiyonel: INSERT INTO t VALUES(...) veya INSERT INTO t () ...
    if PeekToken = '(' then
    begin
      NextToken(T);
      if PeekToken = ')' then
      begin
        NextToken(T); // boş kolon listesi
      end
      else
      begin
        i := 0;
        while True do
        begin
          ExpectToken(T);
          SetLength(Result.Columns, i + 1);
          Result.Columns[i] := VDbNorm(T);
          Inc(i);
          if PeekToken = ')' then begin NextToken(T); Break; end;
          Expect(',');
        end;
      end;
    end;

    // VALUES veya DEFAULT VALUES
    T := UpperCase(PeekToken);
    if T = 'DEFAULT' then
    begin
      while True do
      begin
        NextToken(T);
        Expect('VALUES');
        Row := TList<TSqlExprNode>.Create;
        Result.ValuesRows.Add(Row);
        if PeekToken = ',' then
        begin
          NextToken(T);
          if UpperCase(PeekToken) = 'DEFAULT' then Continue
          else raise EVDbException.CreateFmt(ecSyntaxError, 'DEFAULT VALUES bekleniyor, "%s" bulundu (%s)', [PeekToken, CurPos]);
        end;
        Break;
      end;
    end
    else if T = 'VALUES' then
    begin
      NextToken(T);
      // Çoklu satır: VALUES (a,b), (c,d)
      while True do
      begin
        Expect('(');
        Row := TList<TSqlExprNode>.Create;
        if PeekToken = ')' then
        begin
          NextToken(T); // boş VALUES ()
        end
        else
        begin
          while True do
          begin
            Expr := ParseExpr;
            Row.Add(Expr);
            if PeekToken = ')' then begin NextToken(T); Break; end;
            Expect(',');
          end;
        end;
        Result.ValuesRows.Add(Row);
        if PeekToken = ',' then begin NextToken(T); Continue; end;
        Break;
      end;
    end
    else if T = 'SELECT' then
    begin
      NextToken(T);
      Result.SelectSrc := ParseSelect;
    end
    else
      raise EVDbException.CreateFmt(ecSyntaxError, 'VALUES veya SELECT bekleniyor, "%s" bulundu (%s)',
        [PeekToken, CurPos]);

    // R-03: ON CONFLICT clause
    T := UpperCase(PeekToken);
    if T = 'ON' then
    begin
      NextToken(T);
      Expect('CONFLICT');
      // ON CONFLICT [ (column, ...) ]
      if PeekToken = '(' then
      begin
        NextToken(T);
        i := 0;
        while True do
        begin
          ExpectToken(T);
          SetLength(Result.OnConflictTarget, i + 1);
          Result.OnConflictTarget[i] := VDbNorm(T);
          Inc(i);
          if PeekToken = ')' then begin NextToken(T); Break; end;
          Expect(',');
        end;
      end;
      // DO NOTHING veya DO UPDATE SET ...
      T := UpperCase(PeekToken);
      if T = 'DO' then
      begin
        NextToken(T);
        T := UpperCase(PeekToken);
        if T = 'NOTHING' then
        begin
          NextToken(T);
          Result.OnConflictAction := ocaDoNothing;
        end
        else if T = 'UPDATE' then
        begin
          NextToken(T);
          Expect('SET');
          Result.OnConflictAction := ocaDoUpdate;
          // SET col1 = expr1, col2 = expr2, ...
          while True do
          begin
            ExpectToken(T);
            Asgn.ColName := VDbNorm(T);
            Expect('=');
            Asgn.Expr := ParseExpr;
            Result.OnConflictSetExprs.Add(Asgn);
            if PeekToken = ',' then begin NextToken(T); Continue; end;
            Break;
          end;
        end
        else
          raise EVDbException.CreateFmt(ecSyntaxError, 'ON CONFLICT DO sonrasi NOTHING veya UPDATE bekleniyor, "%s" bulundu (%s)',
            [PeekToken, CurPos]);
      end
      else
        raise EVDbException.CreateFmt(ecSyntaxError, 'ON CONFLICT sonrasi DO bekleniyor, "%s" bulundu (%s)',
          [PeekToken, CurPos]);
    end;

    // R-04: RETURNING clause
    T := UpperCase(PeekToken);
    if T = 'RETURNING' then
    begin
      NextToken(T);
      if PeekToken = '*' then
      begin
        NextToken(T);
        // RETURNING * - tum kolonlar
        SetLength(Result.ReturningCols, 0);
        // ReturningExprs bos kaldi = * anlamina gelir
      end
      else
      begin
        // RETURNING col1, col2, ... veya col1 AS alias, ...
        while True do
        begin
          ExpectToken(T);
          Result.ReturningExprs.Add(ParseExpr);
          // Alias kontrolu: AS alias veya sadece alias
          if UpperCase(PeekToken) = 'AS' then
          begin
            NextToken(T); ExpectToken(T);
            // Alias ReturningExprs'in son elemanina eklenebilir (simdilik atlaniyor)
          end;
          SetLength(Result.ReturningCols, Length(Result.ReturningCols) + 1);
          Result.ReturningCols[High(Result.ReturningCols)] := VDbNorm(T);
          if PeekToken = ',' then begin NextToken(T); Continue; end;
          Break;
        end;
      end;
    end;

  except
    Result.Free;
    raise;
  end;
end;

{ ============================================================
  UPDATE
  ============================================================ }

function TVDbParser.ParseUpdate: TSqlUpdateStmt;
var T: string; Asgn: TUpdateAssignment;
begin
  Result := TSqlUpdateStmt.Create;
  try
    ExpectToken(T); Result.Table := VDbNorm(T);
    Expect('SET');
    while True do
    begin
      ExpectToken(Asgn.ColName); Asgn.ColName := VDbNorm(Asgn.ColName);
      Expect('=');
      Asgn.Expr := ParseExpr;
      Result.Assignments.Add(Asgn);
      if PeekToken = ',' then begin NextToken(T); Continue; end;
      Break;
    end;
    if PeekToken = 'WHERE' then begin NextToken(T); Result.WhereClause := ParseExpr; end;
    // R-04: RETURNING clause
    if UpperCase(PeekToken) = 'RETURNING' then
    begin
      NextToken(T);
      if PeekToken = '*' then
      begin
        NextToken(T);
        SetLength(Result.ReturningCols, 0);
      end
      else
      begin
        while True do
        begin
          ExpectToken(T);
          Result.ReturningExprs.Add(ParseExpr);
          if UpperCase(PeekToken) = 'AS' then
          begin
            NextToken(T); ExpectToken(T);
          end;
          SetLength(Result.ReturningCols, Length(Result.ReturningCols) + 1);
          Result.ReturningCols[High(Result.ReturningCols)] := VDbNorm(T);
          if PeekToken = ',' then begin NextToken(T); Continue; end;
          Break;
        end;
      end;
    end;
  except
    Result.Free;
    raise;
  end;
end;

{ ============================================================
  DELETE
  ============================================================ }

function TVDbParser.ParseDelete: TSqlDeleteStmt;
var T: string;
begin
  Result := TSqlDeleteStmt.Create;
  try
    Expect('FROM');
    ExpectToken(T); Result.Table := VDbNorm(T);
    if PeekToken = 'WHERE' then begin NextToken(T); Result.WhereClause := ParseExpr; end;
    // R-04: RETURNING clause
    if UpperCase(PeekToken) = 'RETURNING' then
    begin
      NextToken(T);
      if PeekToken = '*' then
      begin
        NextToken(T);
        SetLength(Result.ReturningCols, 0);
      end
      else
      begin
        while True do
        begin
          ExpectToken(T);
          Result.ReturningExprs.Add(ParseExpr);
          if UpperCase(PeekToken) = 'AS' then
          begin
            NextToken(T); ExpectToken(T);
          end;
          SetLength(Result.ReturningCols, Length(Result.ReturningCols) + 1);
          Result.ReturningCols[High(Result.ReturningCols)] := VDbNorm(T);
          if PeekToken = ',' then begin NextToken(T); Continue; end;
          Break;
        end;
      end;
    end;
  except
    Result.Free;
    raise;
  end;
end;

{ ============================================================
  CREATE TABLE
  ============================================================ }

function TVDbParser.ParseCreateTable: TSqlCreateTableStmt;
var T, U: string; C: TColDef; i: Integer;
    Fk: TFkDef; fkColName, fkRef, fkRefCol: string;
    chkText: string; depth: Integer;
    pname: string; k: Integer; isPK: Boolean;
begin
  Result := TSqlCreateTableStmt.Create;
  try
    if PeekToken = 'IF' then
    begin
      NextToken(T); Expect('NOT'); Expect('EXISTS');
      Result.IfNotExists := True;
    end;
    ExpectToken(T); Result.Table := VDbNorm(T);
    Expect('(');
    i := 0;

    while True do
    begin
      // PRIMARY KEY constraint (tablo seviyesi)
      U := PeekToken;
      if U = 'PRIMARY' then
      begin
        NextToken(T); Expect('KEY');
        Expect('(');
        ExpectToken(T); // pk kolon adı
        Result.PkIndex := i - 1; // arama: bir üstte tanımlanan kolon
        // Adı bul
        pname := VDbNorm(T);
        for k := 0 to High(Result.Cols) do
          if SameText(Result.Cols[k].Name, pname) then
          begin Result.PkIndex := k; Break; end;
        Expect(')');
        if PeekToken = ',' then begin NextToken(T); Continue; end;
        if PeekToken = ')' then begin NextToken(T); Break; end;
        Break;
      end;
      if U = 'UNIQUE' then
      begin
        NextToken(T); Expect('('); ExpectToken(T); Expect(')');
        if PeekToken = ',' then begin NextToken(T); Continue; end;
        if PeekToken = ')' then begin NextToken(T); Break; end;
        Break;
      end;
      if U = 'CHECK' then
      begin
        NextToken(T); // CHECK yut
        Expect('(');
        Result.CheckExprs.Add(ParseExpr);
        Expect(')');
        if PeekToken = ',' then begin NextToken(T); Continue; end;
        if PeekToken = ')' then begin NextToken(T); Break; end;
        Break;
      end;
      if U = 'FOREIGN' then
      begin
        NextToken(T); Expect('KEY');
        Expect('('); ExpectToken(fkColName); Expect(')');
        Expect('REFERENCES');
        ExpectToken(fkRef); fkRef := VDbNorm(fkRef);
        fkRefCol := '';
        if PeekToken = '(' then begin NextToken(T); ExpectToken(fkRefCol); Expect(')'); end;
        // TFkDef alanları
        Fk.Col := -1;
        // Col index'i bul
        for k := 0 to High(Result.Cols) do
          if SameText(Result.Cols[k].Name, VDbNorm(fkColName)) then
          begin Fk.Col := k; Break; end;
        fk.RefTable := fkRef;
        fk.RefCol := fkRefCol;
        fk.OnDelete := VDB_FK_RESTRICT;
        fk.OnUpdate := VDB_FK_RESTRICT;
        while PeekToken = 'ON' do
        begin
          NextToken(T); ExpectToken(T); U := UpperCase(T);
          if U = 'DELETE' then fk.OnDelete := ReadFkAction
          else if U = 'UPDATE' then fk.OnUpdate := ReadFkAction;
        end;
        SetLength(Result.Fks, Length(Result.Fks) + 1);
        Result.Fks[High(Result.Fks)] := fk;
        if PeekToken = ',' then begin NextToken(T); Continue; end;
        if PeekToken = ')' then begin NextToken(T); Break; end;
        Break;
      end;

      // Kolon tanımı
      ExpectToken(C.Name); C.Name := VDbNorm(C.Name);
      // PK belirleme: PRIMARY anahtar kelimesi ParseColDef'te tüketilir,
      // ama PkIndex'i burada ayarlamamız gerekiyor.
      isPK := (UpperCase(PeekToken) = 'PRIMARY') or
              (UpperCase(PeekToken2) = 'PRIMARY');
      ParseColDef(C, Result);
      if isPK then Result.PkIndex := i;
      SetLength(Result.Cols, i + 1);
      Result.Cols[i] := C;
      Inc(i);

      if PeekToken = ')' then begin NextToken(T); Break; end;
      if PeekToken = ',' then begin NextToken(T); Continue; end;
      Break;
    end;
    if PeekToken = ')' then NextToken(T);

  except
    Result.Free;
    raise;
  end;
end;

{ ============================================================
  ALTER TABLE
  ============================================================ }

function TVDbParser.ParseAlterTable: TSqlAlterTableStmt;
var T, U: string;
begin
  Result := TSqlAlterTableStmt.Create;
  try
    ExpectToken(T); Result.Table := VDbNorm(T);
    ExpectToken(T); U := UpperCase(T);

    if U = 'ADD' then
    begin
      // ADD [COLUMN] colname type ...
      if PeekToken = 'COLUMN' then NextToken(T);
      ExpectToken(Result.ColDef.Name); Result.ColDef.Name := VDbNorm(Result.ColDef.Name);
      Result.Action := ataAddColumn;
      ParseColDef(Result.ColDef);
      Result.DefaultVal := Result.ColDef.Def;
      // AFTER / FIRST
      if PeekToken = 'AFTER' then begin NextToken(T); ExpectToken(Result.PositionCol); end
      else if PeekToken = 'FIRST' then begin NextToken(T); Result.IsFirst := True; end;
    end
    else if U = 'DROP' then
    begin
      if PeekToken = 'COLUMN' then NextToken(T);
      ExpectToken(Result.ColName);
      Result.ColName := VDbNorm(Result.ColName);
      Result.Action := ataDropColumn;
    end
    else if U = 'RENAME' then
    begin
      U := PeekToken;
      if U = 'TO' then
      begin
        NextToken(T); ExpectToken(Result.NewName);
        Result.Action := ataRenameTable;
      end
      else
      begin
        if U = 'COLUMN' then NextToken(T);
        ExpectToken(Result.ColName); Result.ColName := VDbNorm(Result.ColName);
        Expect('TO'); ExpectToken(Result.NewName);
        Result.Action := ataRenameColumn;
      end;
    end
    else if U = 'MODIFY' then
    begin
      // MODIFY COLUMN col type
      if PeekToken = 'COLUMN' then NextToken(T);
      ExpectToken(Result.ColName); Result.ColName := VDbNorm(Result.ColName);
      ExpectToken(T); Result.NewTypeName := T;
      Result.Action := ataAlterColType;
    end
    else if U = 'ALTER' then
    begin
      // ALTER [COLUMN] col SET DEFAULT x | DROP DEFAULT | SET NOT NULL | DROP NOT NULL
      if PeekToken = 'COLUMN' then NextToken(T);
      ExpectToken(Result.ColName); Result.ColName := VDbNorm(Result.ColName);
      ExpectToken(T); U := UpperCase(T);
      if U = 'SET' then
      begin
        ExpectToken(T); U := UpperCase(T);
        if U = 'DEFAULT' then begin ExpectToken(Result.DefaultVal); Result.Action := ataSetDefault; end
        else if U = 'NOT' then begin Expect('NULL'); Result.Action := ataSetNotNull; end
        else raise EVDbException.CreateFmt(ecNotNullViolation, 'SET sonrasi DEFAULT veya NOT NULL bekleniyor, "%s" bulundu', [T]);
      end
      else if U = 'DROP' then
      begin
        ExpectToken(T); U := UpperCase(T);
        if U = 'DEFAULT' then Result.Action := ataDropDefault
        else if U = 'NOT' then begin Expect('NULL'); Result.Action := ataDropNotNull; end
        else raise EVDbException.CreateFmt(ecNotNullViolation, 'DROP sonrasi DEFAULT veya NOT NULL bekleniyor, "%s" bulundu', [T]);
      end
      else if U = 'TYPE' then
      begin
        ExpectToken(Result.NewTypeName); Result.Action := ataAlterColType;
      end
      else raise EVDbException.CreateFmt(ecSyntaxError, 'ALTER COLUMN sonrasi bilinmeyen eylem: "%s"', [T]);
    end
    else if U = 'CONSTRAINT' then
    begin
      // 4.6: ADD CONSTRAINT / DROP CONSTRAINT (basit parser acik, yurutucu sinirlidir)
      ExpectToken(T); // CHECK / FOREIGN KEY / PRIMARY KEY
      T := UpperCase(T);
      if (T = 'CHECK') or (T = 'FOREIGN') or (T = 'PRIMARY') then
      begin
        ExpectToken(Result.ColName); // sinirli: kolon adi / anahtar adi
        if T = 'FOREIGN' then Expect('KEY');
        if PeekToken = 'ON' then begin NextToken(T); ExpectToken(Result.Table); end;
        if PeekToken = 'REFERENCES' then begin NextToken(T); ExpectToken(Result.Table); end;
        Result.Action := ataAddConstraint;
      end
      else
        raise EVDbException.CreateFmt(ecSyntaxError, 'ALTER TABLE CONSTRAINT icin bilinmeyen tur: "%s"', [T]);
    end
    else
      raise EVDbException.CreateFmt(ecSyntaxError, 'ALTER TABLE icin bilinmeyen eylem: "%s" (%s)', [T, CurPos]);

  except
    Result.Free;
    raise;
  end;
end;

{ ============================================================
  DROP TABLE
  ============================================================ }

function TVDbParser.ParseDropTable: TSqlDropTableStmt;
var T: string;
begin
  Result := TSqlDropTableStmt.Create;
  try
    if PeekToken = 'IF' then
    begin
      NextToken(T); Expect('EXISTS'); Result.IfExists := True;
    end;
    ExpectToken(T); Result.Table := VDbNorm(T);
  except
    Result.Free; raise;
  end;
end;

{ ============================================================
  CREATE INDEX / DROP INDEX
  ============================================================ }

{ F-17: Ifade dugumunu geri metne cevirir (partial index kosulu semaya
  yazilir; dosya yeniden acildiginda korunur). Kapsamli alt kume: literal,
  kolon, ikili/unary islem, parantez, IN listesi, NULL denetimi. Bilinmeyen
  dugum turunde bos metin doner (bu durumda Predicate bos kalir ve indeks
  normal indeks gibi davranir). }
function ExprToText(E: TSqlExprNode): string;

  function BinName(O: TSqlBinaryOp): string;
  begin
    case O of
      sboAdd: Result := '+';  sboSub: Result := '-';
      sboMul: Result := '*';  sboDiv: Result := '/';
      sboMod: Result := '%';
      sboEq:  Result := '=';  sboNeq: Result := '<>';
      sboLt:  Result := '<';  sboLte: Result := '<=';
      sboGt:  Result := '>';  sboGte: Result := '>=';
      sboLike: Result := 'LIKE'; sboILike: Result := 'ILIKE';
      sboAnd: Result := 'AND';  sboOr:  Result := 'OR';
    else
      Result := '?';
    end;
  end;

  function Q(const S: string): string;
  begin
    // Her zaman tirnakla; icteki ' karakterleri ikiye katlanir
    Result := '''' + StringReplace(S, '''', '''''', [rfReplaceAll]) + '''';
  end;

  function Sub(E2: TSqlExprNode; const Op: string; const Rt: string): string;
  var
    s2: string;
  begin
    s2 := ExprToText(E2);
    if s2 = '' then Exit('');
    Result := '(' + s2 + ' ' + Op + ' ' + Rt + ')';
  end;

var
  b, u: TSqlBinaryOpNode;
  un: TSqlUnaryOpNode;
  inN: TSqlInNode;
  bt: TSqlBetweenNode;
  k: Integer;
  s: string;
begin
  Result := '';
  if E = nil then Exit;
  if E is TSqlLiteralNode then
  begin
    case TSqlLiteralNode(E).LitType of
      sltNull:   Exit('NULL');
      sltString: Exit(Q(TSqlLiteralNode(E).StrVal));
      sltBool:   if TSqlLiteralNode(E).BoolVal then Exit('1') else Exit('0');
    else
      Exit(TSqlLiteralNode(E).AsString);   // int / float
    end;
  end;
  if E is TSqlColumnRefNode then Exit(TSqlColumnRefNode(E).QualifiedName);
  if E is TSqlBinaryOpNode then
  begin
    b := TSqlBinaryOpNode(E);
    Exit(Sub(b.Left, BinName(b.Op), ExprToText(b.Right)));
  end;
  if E is TSqlUnaryOpNode then
  begin
    un := TSqlUnaryOpNode(E);
    case un.Op of
      suoNot:      Result := '(NOT ' + ExprToText(un.Operand) + ')';
      suoNeg:      Result := '(-' + ExprToText(un.Operand) + ')';
      suoIsNull:   Result := '(' + ExprToText(un.Operand) + ' IS NULL)';
      suoIsNotNull:Result := '(' + ExprToText(un.Operand) + ' IS NOT NULL)';
    else
      Result := '';
    end;
    Exit;
  end;
  if E is TSqlInNode then
  begin
    inN := TSqlInNode(E);
    if inN.IsNot then Result := ' NOT IN (' else Result := ' IN (';
    Result := '(' + ExprToText(inN.Expr) + Result;
    for k := 0 to inN.List.Count - 1 do
    begin
      if k > 0 then Result := Result + ',';
      Result := Result + ExprToText(inN.List[k]);
    end;
    Result := Result + '))';
    Exit;
  end;
  if E is TSqlBetweenNode then
  begin
    bt := TSqlBetweenNode(E);
    if bt.IsNot then Result := ' NOT BETWEEN ' else Result := ' BETWEEN ';
    Result := '(' + ExprToText(bt.Expr) + Result +
              ExprToText(bt.LowBound) + ' AND ' + ExprToText(bt.HighBound) + ')';
    Exit;
  end;
  if E is TSqlFuncCallNode then
  begin
    Result := UpperCase(TSqlFuncCallNode(E).FuncName) + '(';
    if TSqlFuncCallNode(E).IsStar then Result := Result + '*'
    else Result := Result + ExprToText(TSqlFuncCallNode(E).Arg);
    Result := Result + ')';
    Exit;
  end;
  s := '';
end;

function TVDbParser.ParseCreateIndex: TSqlCreateIndexStmt;
var T: string;
    idxFirst: Boolean;   // F-18
begin
  Result := TSqlCreateIndexStmt.Create;
  try
    if PeekToken = 'UNIQUE' then NextToken(T); // UNIQUE INDEX
    Expect('INDEX');
    ExpectToken(T); Result.IndexName := VDbNorm(T);
    Expect('ON');
    ExpectToken(T); Result.Table := VDbNorm(T);
    Expect('(');
    // F-18: ifade indeksi (bkz. Parse ana kolundaki CREATE INDEX yolu)
    idxFirst := True;
    while True do
    begin
      if PeekToken = ')' then Break;
      if (PeekToken2 = ',') or (PeekToken2 = ')') then
      begin
        ExpectToken(T);
        SetLength(Result.Cols, Length(Result.Cols) + 1);
        Result.Cols[High(Result.Cols)] := VDbNorm(T);
      end
      else
      begin
        if not idxFirst then
          raise EVDbException.Create(ecUnsupported,
            'ifade indeksi tek ifade kabul eder');
        Result.ExprNode := ParseExpr;
        Result.ExprText := ExprToText(Result.ExprNode);
        if Result.ExprText = '' then
          raise EVDbException.Create(ecUnsupported, 'indeks ifadesi desteklenmiyor');
      end;
      idxFirst := False;
      if PeekToken <> ',' then Break;
      NextToken(T);
    end;
    if (Length(Result.Cols) = 0) and (Result.ExprNode = nil) then
      raise EVDbException.Create(ecSyntaxError, 'indeks kolonu yok');
    if Length(Result.Cols) > 0 then
      Result.Col := Result.Cols[0]
    else
      Result.Col := '';
    Expect(')');
    // F-19: COVERING INDEX
    if PeekToken = 'INCLUDE' then
    begin
      NextToken(T);
      Expect('(');
      while True do
      begin
        ExpectToken(T);
        SetLength(Result.Incl, Length(Result.Incl) + 1);
        Result.Incl[High(Result.Incl)] := VDbNorm(T);
        if PeekToken <> ',' then Break;
        NextToken(T);
      end;
      Expect(')');
    end;
    // F-17: PARTIAL INDEX
    if PeekToken = 'WHERE' then
    begin
      NextToken(T);
      Result.PredExpr := ParseExpr;
      Result.Predicate := ExprToText(Result.PredExpr);
    end;
  except
    Result.Free; raise;
  end;
end;

function TVDbParser.ParseDropIndex: TSqlDropIndexStmt;
var T: string;
begin
  Result := TSqlDropIndexStmt.Create;
  try
    if PeekToken = 'IF' then begin NextToken(T); Expect('EXISTS'); Result.IfExists := True; end;
    ExpectToken(T); Result.IndexName := VDbNorm(T);
  except
    Result.Free; raise;
  end;
end;

{ ------------------------------------------------------------
  F-34: MATERIALIZED VIEW
  ------------------------------------------------------------ }
function TVDbParser.ParseCreateMaterializedView: TSqlCreateMaterializedViewStmt;
var T: string;
begin
  Result := TSqlCreateMaterializedViewStmt.Create;
  try
    if PeekToken = 'IF' then begin NextToken(T); Expect('NOT'); Expect('EXISTS'); Result.IfNotExists := True; end;
    ExpectToken(T); Result.ViewName := VDbNorm(T);
    Expect('AS');
    Result.SelectStmt := ParseSelect;
  except
    Result.Free; raise;
  end;
end;

function TVDbParser.ParseDropMaterializedView: TSqlDropMaterializedViewStmt;
var T: string;
begin
  Result := TSqlDropMaterializedViewStmt.Create;
  try
    if PeekToken = 'IF' then begin NextToken(T); Expect('EXISTS'); Result.IfExists := True; end;
    ExpectToken(T); Result.ViewName := VDbNorm(T);
  except
    Result.Free; raise;
  end;
end;

function TVDbParser.ParseRefreshMaterializedView: TSqlRefreshMaterializedViewStmt;
var T: string;
begin
  Result := TSqlRefreshMaterializedViewStmt.Create;
  try
    Expect('MATERIALIZED'); Expect('VIEW');
    ExpectToken(T); Result.ViewName := VDbNorm(T);
    if PeekToken = 'CONCURRENTLY' then begin NextToken(T); Result.Concurrently := True; end;
  except
    Result.Free; raise;
  end;
end;

{ ------------------------------------------------------------
  F-36: TRIGGER
  ------------------------------------------------------------ }
function TVDbParser.ParseCreateTrigger: TSqlCreateTriggerStmt;
var T, U: string; evt: TTriggerEvent; timing: TTriggerTiming; forEach: TTriggerForEach;
begin
  Result := TSqlCreateTriggerStmt.Create;
  try
    if PeekToken = 'IF' then begin NextToken(T); Expect('NOT'); Expect('EXISTS'); Result.IfNotExists := True; end;
    ExpectToken(T); Result.TriggerName := VDbNorm(T);
    // Timing: BEFORE / AFTER / INSTEAD OF
    T := UpperCase(PeekToken);
    if T = 'BEFORE' then begin NextToken(T); Result.Timing := ttBefore; end
    else if T = 'AFTER' then begin NextToken(T); Result.Timing := ttAfter; end
    else if T = 'INSTEAD' then begin NextToken(T); Expect('OF'); Result.Timing := ttInsteadOf; end
    else raise EVDbException.CreateFmt(ecSyntaxError, 'BEFORE/AFTER/INSTEAD OF bekleniyor: %s', [T]);
    // Event: INSERT / UPDATE / DELETE (can be multiple with OR)
    while True do
    begin
      T := UpperCase(PeekToken);
      if T = 'INSERT' then begin NextToken(T); SetLength(Result.Events, Length(Result.Events) + 1); Result.Events[High(Result.Events)] := teInsert; end
      else if T = 'UPDATE' then begin NextToken(T); SetLength(Result.Events, Length(Result.Events) + 1); Result.Events[High(Result.Events)] := teUpdate; end
      else if T = 'DELETE' then begin NextToken(T); SetLength(Result.Events, Length(Result.Events) + 1); Result.Events[High(Result.Events)] := teDelete; end
      else break;
      if UpperCase(PeekToken) = 'OR' then NextToken(T) else Break;
    end;
    if Length(Result.Events) = 0 then
      raise EVDbException.Create(ecSyntaxError, 'Trigger event (INSERT/UPDATE/DELETE) gerekli');
    Expect('ON');
    ExpectToken(T); Result.TableName := VDbNorm(T);
    // FOR EACH ROW / STATEMENT
    if UpperCase(PeekToken) = 'FOR' then
    begin
      NextToken(T); Expect('EACH');
      if UpperCase(PeekToken) = 'ROW' then begin NextToken(T); Result.ForEach := tfRow; end
      else if UpperCase(PeekToken) = 'STATEMENT' then begin NextToken(T); Result.ForEach := tfStatement; end
      else raise EVDbException.CreateFmt(ecSyntaxError, 'FOR EACH ROW/STATEMENT bekleniyor');
    end;
    // WHEN condition
    if UpperCase(PeekToken) = 'WHEN' then
    begin
      NextToken(T);
      Result.WhenCondition := ParseExpr;
    end;
    // EXECUTE FUNCTION / PROCEDURE
    if UpperCase(PeekToken) = 'EXECUTE' then
    begin
      NextToken(T);
      if UpperCase(PeekToken) = 'FUNCTION' then NextToken(T)
      else if UpperCase(PeekToken) = 'PROCEDURE' then NextToken(T);
      ExpectToken(T); Result.FunctionName := VDbNorm(T);
    end;
  except
    Result.Free; raise;
  end;
end;

function TVDbParser.ParseDropTrigger: TSqlDropTriggerStmt;
var T: string;
begin
  Result := TSqlDropTriggerStmt.Create;
  try
    if PeekToken = 'IF' then begin NextToken(T); Expect('EXISTS'); Result.IfExists := True; end;
    ExpectToken(T); Result.TriggerName := VDbNorm(T);
    Expect('ON');
    ExpectToken(T); Result.TableName := VDbNorm(T);
  except
    Result.Free; raise;
  end;
end;

{ ------------------------------------------------------------
  F-35: STORED PROCEDURE / FUNCTION
  ------------------------------------------------------------ }
function TVDbParser.ParseCreateFunction: TSqlCreateFunctionStmt;
var T: string; p: TSqlFunctionParameter; pname: string;
begin
  Result := TSqlCreateFunctionStmt.Create;
  try
    if PeekToken = 'IF' then begin NextToken(T); Expect('NOT'); Expect('EXISTS'); Result.IfNotExists := True; end;
    ExpectToken(T); Result.Name := VDbNorm(T);
    Expect('(');
    if PeekToken <> ')' then
    begin
      while True do
      begin
        p.Name := '';
        p.TypeName := '';
        p.Mode := 'IN';
        p.DefaultExpr := nil;
        ExpectToken(T); p.Name := VDbNorm(T);
        ExpectToken(T); p.TypeName := T;
        if PeekToken = 'IN' then begin NextToken(T); p.Mode := 'IN'; end
        else if PeekToken = 'OUT' then begin NextToken(T); p.Mode := 'OUT'; end
        else if PeekToken = 'INOUT' then begin NextToken(T); p.Mode := 'INOUT'; end;
        if PeekToken = 'DEFAULT' then begin NextToken(T); p.DefaultExpr := ParseExpr; end;
        SetLength(Result.Parameters, Length(Result.Parameters) + 1);
        Result.Parameters[High(Result.Parameters)] := p;
        if PeekToken = ',' then begin NextToken(T); Continue; end;
        Break;
      end;
    end;
    Expect(')');
    Expect('RETURNS'); ExpectToken(T); Result.ReturnType := VDbNorm(T);
    Expect('LANGUAGE'); ExpectToken(T); Result.Language := UpperCase(T);
    if PeekToken = 'AS' then NextToken(T);
    Result.Body := ParseStmt; // Function body (SELECT, BEGIN...END, etc.)
  except
    Result.Free; raise;
  end;
end;

function TVDbParser.ParseCreateProcedure: TSqlCreateProcedureStmt;
var T: string; p: TSqlFunctionParameter;
begin
  Result := TSqlCreateProcedureStmt.Create;
  try
    if PeekToken = 'IF' then begin NextToken(T); Expect('NOT'); Expect('EXISTS'); Result.IfNotExists := True; end;
    ExpectToken(T); Result.Name := VDbNorm(T);
    Expect('(');
    if PeekToken <> ')' then
    begin
      while True do
      begin
        p.Name := '';
        p.TypeName := '';
        p.Mode := 'IN';
        p.DefaultExpr := nil;
        ExpectToken(T); p.Name := VDbNorm(T);
        ExpectToken(T); p.TypeName := T;
        if PeekToken = 'IN' then begin NextToken(T); p.Mode := 'IN'; end
        else if PeekToken = 'OUT' then begin NextToken(T); p.Mode := 'OUT'; end
        else if PeekToken = 'INOUT' then begin NextToken(T); p.Mode := 'INOUT'; end;
        if PeekToken = 'DEFAULT' then begin NextToken(T); p.DefaultExpr := ParseExpr; end;
        SetLength(Result.Parameters, Length(Result.Parameters) + 1);
        Result.Parameters[High(Result.Parameters)] := p;
        if PeekToken = ',' then begin NextToken(T); Continue; end;
        Break;
      end;
    end;
    Expect(')');
    Expect('LANGUAGE'); ExpectToken(T); Result.Language := UpperCase(T);
    if PeekToken = 'AS' then NextToken(T);
    Result.Body := ParseStmt; // Procedure body (BEGIN...END block)
  except
    Result.Free; raise;
  end;
end;

function TVDbParser.ParseCall: TSqlCallStmt;
var T: string;
begin
  Result := TSqlCallStmt.Create;
  try
    ExpectToken(T); Result.ProcName := VDbNorm(T);
    if PeekToken = '(' then
    begin
      NextToken(T);
      if PeekToken <> ')' then
      begin
        while True do
        begin
          Result.Arguments.Add(ParseExpr);
          if PeekToken = ',' then begin NextToken(T); Continue; end;
          Break;
        end;
      end;
      Expect(')');
    end;
  except
    Result.Free; raise;
  end;
end;

function TVDbParser.ParseDropFunction: TSqlDropFunctionStmt;
var T: string;
begin
  Result := TSqlDropFunctionStmt.Create;
  try
    if PeekToken = 'IF' then begin NextToken(T); Expect('EXISTS'); Result.IfExists := True; end;
    ExpectToken(T); Result.Name := VDbNorm(T);
  except
    Result.Free; raise;
  end;
end;

function TVDbParser.ParseDropProcedure: TSqlDropProcedureStmt;
var T: string;
begin
  Result := TSqlDropProcedureStmt.Create;
  try
    if PeekToken = 'IF' then begin NextToken(T); Expect('EXISTS'); Result.IfExists := True; end;
    ExpectToken(T); Result.Name := VDbNorm(T);
  except
    Result.Free; raise;
  end;
end;

{ ============================================================
  ADMIN cumleleri (CREATE/DROP/OPEN/CLOSE DATABASE, BACKUP, VERIFY,
  VACUUM, REINDEX, SHOW/LIST)
  ============================================================ }

function TVDbParser.ParseAdmin(const Kw1, Kw2: string): TSqlAdminStmt;
var T, U: string; st: TSqlAdminStmt;
begin
  // Kw1 = ilk keyword (CREATE/DROP/OPEN/CLOSE/BACKUP/VERIFY/VACUUM/REINDEX/SHOW/LIST)
  // Kw2 = ikinci keyword (DATABASE, TABLES vs.) — bazı durumlarda boş
  Result := nil;

  if (Kw1 = 'VERIFY') then
    Exit(TSqlAdminStmt.Create(admVerify));

  if (Kw1 = 'VACUUM') then
    Exit(TSqlAdminStmt.Create(admVacuum));

  if (Kw1 = 'REINDEX') then
    Exit(TSqlAdminStmt.Create(admReindex));

  if (Kw1 = 'SHOW') or (Kw1 = 'LIST') then
  begin
    U := PeekToken;
    if U = 'TABLES' then begin NextToken(T); Exit(TSqlAdminStmt.Create(admShowTables)); end;
    if U = 'DATABASES' then begin NextToken(T); Exit(TSqlAdminStmt.Create(admListDbs)); end;
    // 2026-10-04: SHOW INDEXES [FROM] t  /  SHOW CREATE TABLE t
    if U = 'INDEXES' then
    begin
      NextToken(T);
      st := TSqlAdminStmt.Create(admShowIndexes);
      if PeekToken = 'FROM' then NextToken(T);
      ExpectToken(T); st.TableName := VDbNorm(T);
      Exit(st);
    end;
    if U = 'CREATE' then
    begin
      NextToken(T); Expect('TABLE');
      st := TSqlAdminStmt.Create(admShowCreateTable);
      ExpectToken(T); st.TableName := VDbNorm(T);
      Exit(st);
    end;
    raise EVDbException.CreateFmt(ecSyntaxError,
      '"%s" sonrasi TABLES, DATABASES, INDEXES veya CREATE TABLE bekleniyor', [Kw1]);
  end;

  // 2026-10-04: DESCRIBE t  /  DESC t   (MySQL/PostgreSQL uyumu)
  if (Kw1 = 'DESCRIBE') or (Kw1 = 'DESC') then
  begin
    ExpectToken(T);
    Result := TSqlAdminStmt.Create(admDescribe);
    Result.TableName := VDbNorm(T);
    Exit;
  end;

  if Kw1 = 'BACKUP' then
  begin
    st := TSqlAdminStmt.Create(admBackupDb);
    Expect('TO'); ExpectToken(T); st.BackupPath := T;
    Exit(st);
  end;

  // 4.6: PRAGMA (bilgi komutlari — basit parser acik)
  if Kw1 = 'PRAGMA' then
  begin
    st := TSqlAdminStmt.Create(admPragma);
    ExpectToken(T); st.PragmaName := VDbNorm(T);
    Exit(st);
  end;

  if Kw1 = 'CREATE' then
  begin
    // Kw2 = DATABASE
    st := TSqlAdminStmt.Create(admCreateDb);
    if PeekToken = 'IF' then begin NextToken(T); Expect('NOT'); Expect('EXISTS'); st.IfNotExists := True; end;
    ExpectToken(T); st.DbName := T;
    Exit(st);
  end;

  if Kw1 = 'DROP' then
  begin
    st := TSqlAdminStmt.Create(admDropDb);
    if PeekToken = 'IF' then begin NextToken(T); Expect('EXISTS'); st.IfExists := True; end;
    ExpectToken(T); st.DbName := T;
    Exit(st);
  end;

  if (Kw1 = 'OPEN') or (Kw1 = 'USE') then
  begin
    if PeekToken = 'DATABASE' then NextToken(T);
    st := TSqlAdminStmt.Create(admOpenDb);
    ExpectToken(T); st.DbName := T;
    Exit(st);
  end;

  if Kw1 = 'CLOSE' then
  begin
    if PeekToken = 'DATABASE' then NextToken(T);
    Exit(TSqlAdminStmt.Create(admCloseDb));
  end;

  // R-02: SAVEPOINT / Nested Transaction
  if Kw1 = 'SAVEPOINT' then
  begin
    ExpectToken(T);
    Exit(TSqlAdminStmt.Create(admSavepoint, T));
  end;

  if (Kw1 = 'RELEASE') and (UpperCase(Kw2) = 'SAVEPOINT') then
  begin
    ExpectToken(T);
    Exit(TSqlAdminStmt.Create(admReleaseSavepoint, T));
  end;

  if (Kw1 = 'ROLLBACK') and (UpperCase(Kw2) = 'TO') then
  begin
    ExpectToken(T);
    if UpperCase(T) <> 'SAVEPOINT' then
      raise EVDbException.CreateFmt(ecSyntaxError, 'ROLLBACK TO sonrasi SAVEPOINT bekleniyor: %s', [T]);
    ExpectToken(T);
    Exit(TSqlAdminStmt.Create(admRollbackToSavepoint, T));
  end;

  raise EVDbException.CreateFmt(ecSyntaxError, 'Bilinmeyen admin komutu: "%s %s"', [Kw1, Kw2]);
end;

{ ============================================================
  JSON (EXPORT / IMPORT)
  ============================================================ }

function TVDbParser.ParseJson(const Kw: string): TSqlJsonStmt;
var T: string;
begin
  // Kw = EXPORT veya IMPORT
  if UpperCase(Kw) = 'EXPORT' then
  begin
    Result := TSqlJsonStmt.Create(jsoExport);
    if PeekToken = 'TABLE' then
    begin
      NextToken(T); ExpectToken(T); Result.Table := VDbNorm(T);
    end;
    Expect('JSON');
    if PeekToken = 'TABLE' then
    begin
      NextToken(T); ExpectToken(T); Result.Table := VDbNorm(T);
    end;
    if TryEat('TO') then ;
    ExpectToken(Result.FilePath);
  end
  else // IMPORT
  begin
    Result := TSqlJsonStmt.Create(jsoImport);
    Expect('JSON');
    if TryEat('FROM') then ;
    ExpectToken(Result.FilePath);
  end;
end;

{ ============================================================
  Ana ayrıştırıcı: Parse
  ============================================================ }

function TVDbParser.ParseWith: TSqlStmtNode;
var
  T: string;
  W: TWithQuery;
  Main: TSqlStmtNode;
  Holder: TSqlSelectStmt;  // 4.5: holder for WITH + SELECT/INSERT/UPDATE/DELETE
  i: Integer;
  MainToken: string;
begin
  // Giriste 'WITH' yutuldu. CTE listesi once holder dugumde birikir,
  // sonra ana sorgu dugumune tasinir (SELECT/INSERT/UPDATE/DELETE).
  Holder := TSqlSelectStmt.Create; // CTE holder
  Result := Holder;
  try
    if PeekToken = 'RECURSIVE' then
    begin
      NextToken(T);
      W.IsRecursive := True;
    end
    else
      W.IsRecursive := False;
    repeat
      ExpectToken(T);
      W.Name := VDbNorm(T);
      W.Select := nil;
      if W.Name = '' then
        raise EVDbException.Create(ecSyntaxError,
          'WITH sonrasi CTE adi bekleniyor (' + CurPos + ')');
      // 4.5: kolon alias'lari (x(a,b)) — listeyi ColAliases'de tut.
      if PeekToken = '(' then
      begin
        NextToken(T); // (
        W.ColAliases := TStrArray([]);
        repeat
          ExpectToken(T);
          SetLength(W.ColAliases, Length(W.ColAliases) + 1);
          W.ColAliases[High(W.ColAliases)] := VDbNorm(T);
          if PeekToken <> ',' then Break;
          NextToken(T); // ,
        until False;
        Expect(')');
      end;
      Expect('AS');
      Expect('(');
      // 4.5: WITH + DML (SELECT, INSERT, UPDATE, DELETE).
      if (PeekToken <> 'SELECT') and (PeekToken <> 'INSERT') and
         (PeekToken <> 'UPDATE') and (PeekToken <> 'DELETE') then
        raise EVDbException.CreateFmt(ecSyntaxError,
          'AS sonrasi SELECT/INSERT/UPDATE/DELETE bekleniyor (%s)', [CurPos]);
      NextToken(T); // SELECT
      W.Select := ParseSelect;
      Expect(')');
      Holder.WithQueries.Add(W);
      W.Select := nil; // sahiplik listede
      if PeekToken <> ',' then Break;
      NextToken(T); // ','
    until False;
    // 4.5: Ana sorgu: WITH + SELECT / INSERT / UPDATE / DELETE.
    if (PeekToken <> 'SELECT') and (PeekToken <> 'INSERT') and
       (PeekToken <> 'UPDATE') and (PeekToken <> 'DELETE') then
      raise EVDbException.Create(ecUnsupported,
        'WITH yalnizca SELECT/INSERT/UPDATE/DELETE ile kullanilabilir');
    NextToken(T); // SELECT / INSERT / UPDATE / DELETE (DML 4.5 acik)
    MainToken := T;
    if MainToken = 'SELECT' then
      Main := ParseSelect
    else if MainToken = 'INSERT' then
      Main := ParseInsert
    else if MainToken = 'UPDATE' then
      Main := ParseUpdate
    else if MainToken = 'DELETE' then
      Main := ParseDelete
    else
      raise EVDbException.Create(ecSyntaxError,
        'WITH: beklenmeyen ana sorgu tipi: ' + MainToken);
    if MainToken = 'SELECT' then
      for i := 0 to Holder.WithQueries.Count - 1 do
        (Main as TSqlSelectStmt).WithQueries.Add(Holder.WithQueries[i])
    else if MainToken = 'INSERT' then
      for i := 0 to Holder.WithQueries.Count - 1 do
        (Main as TSqlInsertStmt).WithQueries.Add(Holder.WithQueries[i])
    else if MainToken = 'UPDATE' then
      for i := 0 to Holder.WithQueries.Count - 1 do
        (Main as TSqlUpdateStmt).WithQueries.Add(Holder.WithQueries[i])
    else if MainToken = 'DELETE' then
      for i := 0 to Holder.WithQueries.Count - 1 do
        (Main as TSqlDeleteStmt).WithQueries.Add(Holder.WithQueries[i]);
    // Kayitlar kopyalandi (sahiplik ana dugumde); holder bosaltilir,
    // yoksa ayni Select iki kez serbest kalir.
    Holder.WithQueries.Clear;
    Holder.Free;
    Result := Main;
  except
    if W.Select <> nil then W.Select.Free;
    Holder.Free;
    raise;
  end;
end;

function TVDbParser.Parse(const ASql: string;
                           const AParams: array of string): TSqlStmtNode;
var
  T, U, U2: string;
  i: Integer;
  idxStmt: TSqlCreateIndexStmt;
  idxFirst: Boolean;   // F-18
  expStmt: TSqlExplainStmt;   // F-20
begin
  FSql := ASql;
  FLen := Length(ASql);
  FPos := 1;
  FParamIdx := 0;
  FDepth := 0;   // F1-22: derinlik sayaci sifirlanir
  FSuppressTail := False; // F1-12
  SetLength(FParams, Length(AParams));
  for i := 0 to High(AParams) do FParams[i] := AParams[i];

  if AtEnd then Exit(nil);

  ExpectToken(T); U := UpperCase(T);

  Result := nil;

  // ---- Transaction ----
  if U = 'BEGIN'    then Result := TSqlTxStmt.Create(txBegin)
  else if U = 'COMMIT'   then Result := TSqlTxStmt.Create(txCommit)
  else if U = 'ROLLBACK' then Result := TSqlTxStmt.Create(txRollback)

  // ---- DML ----
  else if U = 'SELECT' then Result := ParseSelect
  else if U = 'WITH' then Result := ParseWith
  else if U = 'INSERT' then Result := ParseInsert
  else if U = 'UPDATE' then Result := ParseUpdate
  else if U = 'DELETE' then Result := ParseDelete
  else if U = 'CALL' then Result := ParseCall
  else if U = 'REFRESH' then Result := ParseRefreshMaterializedView
  // ---- F-20: EXPLAIN [ANALYZE] <cumle> ----
  else if U = 'EXPLAIN' then
  begin
    expStmt := TSqlExplainStmt.Create;
    try
      // ANALYZE opsiyonel (yalniz analiz sonrasi)
      if PeekToken = 'ANALYZE' then
      begin
        NextToken(T);
        expStmt.Analyze := True;
      end;
      // ic cumle: SELECT / WITH / INSERT / UPDATE / DELETE
      ExpectToken(T); U := UpperCase(T);
      if U = 'SELECT' then expStmt.Inner := ParseSelect
      else if U = 'WITH' then expStmt.Inner := ParseWith
      else if U = 'INSERT' then expStmt.Inner := ParseInsert
      else if U = 'UPDATE' then expStmt.Inner := ParseUpdate
      else if U = 'DELETE' then expStmt.Inner := ParseDelete
      else
      begin
        // DIKKAT: burada expStmt.Free YAPILMAZ; asagidaki except
        // bloğu zaten serbest birakir (cift free -> access violation).
        raise EVDbException.CreateFmt(ecSyntaxError,
          'EXPLAIN sonrasi SELECT/INSERT/UPDATE/DELETE bekleniyor, "%s" bulundu (%s)', [T, CurPos]);
      end;
      Result := expStmt;
      expStmt := nil;
    except
      expStmt.Free;
      raise;
    end;
  end

  // ---- DDL ----
  else if U = 'CREATE' then
  begin
    ExpectToken(T); U2 := UpperCase(T);
    if U2 = 'TABLE'    then Result := ParseCreateTable
    else if (U2 = 'INDEX') or (U2 = 'UNIQUE') then
    begin
      // F2-23: UNIQUE bayragi motora tasinir (yoksa kisit hic zorlanmaz)
      if U2 = 'UNIQUE' then Expect('INDEX');
      idxStmt := TSqlCreateIndexStmt.Create;
      idxStmt.Uniq := U2 = 'UNIQUE';
      ExpectToken(T); idxStmt.IndexName := VDbNorm(T);
      Expect('ON');
      ExpectToken(T); idxStmt.Table := VDbNorm(T);
      Expect('(');
      // F-18: EXPRESSION INDEX — "CREATE INDEX ix ON t(LOWER(ad))".
      // Kolon listesi girdileri IFADE olarak ayristirilir. Sade bir kolon
      // referansi eski yola (cok kolonlu indeks) gider; diger her sey
      // ifade indeksidir ve yalniz TEK girdi kabul edilir.
      idxFirst := True;
      while True do
      begin
        if PeekToken = ')' then Break;   // "CREATE INDEX ix ON t()" -> bos
        // tek kolon mu? (niteliksiz, fonksiyon/operator icermeyen)
        if (PeekToken2 = ',') or (PeekToken2 = ')') then
        begin
          ExpectToken(T);
          SetLength(idxStmt.Cols, Length(idxStmt.Cols) + 1);
          idxStmt.Cols[High(idxStmt.Cols)] := VDbNorm(T);
        end
        else
        begin
          if not idxFirst then
            raise EVDbException.Create(ecUnsupported,
              'ifade indeksi tek ifade kabul eder (virgulle birden fazla ifade desteklenmez)');
          idxStmt.ExprNode := ParseExpr;
          idxStmt.ExprText := ExprToText(idxStmt.ExprNode);
          if idxStmt.ExprText = '' then
            raise EVDbException.Create(ecUnsupported,
              'indeks ifadesi desteklenmiyor');
        end;
        idxFirst := False;
        if PeekToken <> ',' then Break;
        NextToken(T);   // ','
      end;
      if (Length(idxStmt.Cols) = 0) and (idxStmt.ExprNode = nil) then
        raise EVDbException.Create(ecSyntaxError, 'indeks kolonu yok');
      // ifade indeksinde "ilk kolon" kavrami yoktur; adresleme sentetik
      // kullanacagindan Col = -1 birakilir.
      if Length(idxStmt.Cols) > 0 then
        idxStmt.Col := idxStmt.Cols[0]
      else
        idxStmt.Col := '';
      Expect(')');
      // F-19: COVERING INDEX — "CREATE INDEX ix ON t(a) INCLUDE (b, c)".
      // INCLUDE kolonlari ANAHTAR DEGILDIR: yalnizca indeks icinde tasinir.
      if PeekToken = 'INCLUDE' then
      begin
        NextToken(T);   // INCLUDE
        Expect('(');
        while True do
        begin
          ExpectToken(T);
          SetLength(idxStmt.Incl, Length(idxStmt.Incl) + 1);
          idxStmt.Incl[High(idxStmt.Incl)] := VDbNorm(T);
          if PeekToken <> ',' then Break;
          NextToken(T);
        end;
        Expect(')');
      end;
      // F-17: PARTIAL INDEX — "CREATE INDEX ix ON t(c) WHERE <kosul>".
      // Kosul AST olarak saklanir (yazma yolunda satir bazinda uygulanir).
      if PeekToken = 'WHERE' then
      begin
        NextToken(T);   // WHERE
        idxStmt.PredExpr := ParseExpr;
        idxStmt.Predicate := ExprToText(idxStmt.PredExpr);
      end;
      Result := idxStmt;
    end
    else if U2 = 'VIEW' then
    begin
      Result := ParseCreateView;
    end
    else if U2 = 'MATERIALIZED' then
    begin
      Expect('VIEW');
      Result := ParseCreateMaterializedView;
    end
    else if U2 = 'FUNCTION' then
    begin
      Result := ParseCreateFunction;
    end
    else if U2 = 'PROCEDURE' then
    begin
      Result := ParseCreateProcedure;
    end
    else if U2 = 'TRIGGER' then
    begin
      Result := ParseCreateTrigger;
    end
    else if U2 = 'DATABASE'  then Result := ParseAdmin('CREATE', 'DATABASE')
    else raise EVDbException.CreateFmt(ecSyntaxError, 'CREATE sonrasi bilinmeyen: "%s" (%s)', [T, CurPos]);
  end
  else if U = 'DROP' then
  begin
    ExpectToken(T); U2 := UpperCase(T);
    if U2 = 'TABLE'    then Result := ParseDropTable
    else if U2 = 'INDEX'    then Result := ParseDropIndex
    else if U2 = 'VIEW'    then Result := ParseDropView
    else if U2 = 'MATERIALIZED' then
    begin
      Expect('VIEW');
      Result := ParseDropMaterializedView;
    end
    else if U2 = 'TRIGGER' then
    begin
      ExpectToken(T); Result.TriggerName := VDbNorm(T);
      Expect('ON');
      ExpectToken(T); Result.TableName := VDbNorm(T);
    end
    else if U2 = 'FUNCTION' then Result := ParseDropFunction
    else if U2 = 'PROCEDURE' then Result := ParseDropProcedure
    else if U2 = 'DATABASE' then Result := ParseAdmin('DROP', 'DATABASE')
    else raise EVDbException.CreateFmt(ecSyntaxError, 'DROP sonrasi bilinmeyen: "%s" (%s)', [T, CurPos]);
  end
  else if U = 'ALTER' then
  begin
    ExpectToken(T);
    if T = 'TABLE' then Result := ParseAlterTable
    else if T = 'DATABASE' then
    begin
      // 2026-10-05 Adim 15: ALTER DATABASE KEY 'parola'
      Expect('KEY'); ExpectToken(T);
      if (Length(T) >= 2) and ((T[1] = '''') or (T[1] = '"')) then
        T := Copy(T, 2, Length(T) - 2);
      if T = '' then
        raise EVDbException.Create(ecSyntaxError, 'ALTER DATABASE KEY: parola bos olamaz');
      Result := TSqlAdminStmt.Create(admAlterDbKey);
      (Result as TSqlAdminStmt).NewKeyPassword := T;
    end
    else raise EVDbException.CreateFmt(ecSyntaxError,
      'ALTER sonrasi bilinmeyen: "%s"', [T]);
  end

  // ---- Admin ----
  else if U = 'VERIFY'  then Result := ParseAdmin('VERIFY', '')
  else if U = 'VACUUM'  then Result := ParseAdmin('VACUUM', '')
  else if U = 'REINDEX' then Result := ParseAdmin('REINDEX', '')
    else if (U = 'SHOW') or (U = 'LIST') then Result := ParseAdmin(U, '')
    // 2026-10-04: DESCRIBE / DESC takma adlari (sema sorgulari)
    else if (U = 'DESCRIBE') or (U = 'DESC') then Result := ParseAdmin(U, '')
  else if U = 'BACKUP'  then Result := ParseAdmin('BACKUP', '')
  else if (U = 'OPEN') or (U = 'USE') then Result := ParseAdmin(U, '')
  else if U = 'CLOSE'   then Result := ParseAdmin('CLOSE', '')

  // ---- JSON ----
  else if (U = 'EXPORT') or (U = 'IMPORT') then Result := ParseJson(U)
  else raise EVDbException.CreateFmt(ecSyntaxError, 'Bilinmeyen SQL komutu: "%s" (%s)', [T, CurPos]);

  // Artık token kontrolü (sorgu bittiğinde sonda açıklanamayan token kalmamalı)
  if (Result <> nil) and not AtEnd then
  begin
    NextToken(T);
    if (T <> ';') and (T <> '') then
    begin
      Result.Free;
      Result := nil;
      raise EVDbException.CreateFmt(ecSyntaxError, 'anlasilamayan ek: %s', [T]);
    end;
  end;
end;

end.
