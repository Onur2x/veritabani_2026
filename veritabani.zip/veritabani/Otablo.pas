unit OTablo;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, Variants,
  Generics.Collections,
  fpjson, jsonparser,
  zstream,

  OTabloSchema, oTabloKayit, oTypes;

type
  TVTablo = class
  private
    FAd            : string;
    FSchema        : TTabloSchema;
    FKayitlar      : specialize TObjectList<TTabloKayit>;
    FTempKayitlar  : specialize TObjectList<TTabloKayit>;
    FInTransaction : Boolean;
    FSonID         : Integer;

    /// JSON → nesne
    function  BuildTableJSON: TJSONObject;
    /// JSON şema dizisini TTabloSchema’ya yükler
    procedure LoadSchemaFromJSONArray(const schemaArr: TJSONArray);

    procedure SetSchema(S: TTabloSchema);
    procedure TamamlaEksikAlanlar(
      const K: TTabloKayit;
      const Schema: TTabloSchema;
      const SonID: Integer
    );
  public
    constructor Create(const AAd: string);
    destructor Destroy; override;

    /// CRUD
    procedure KayitEkle(K: TTabloKayit);
    function  VarmiAyniPrimaryKey(const K: TTabloKayit): Boolean;
    procedure Temizle;
    procedure BeginTransaction;
    procedure CommitTransaction;
    procedure RollbackTransaction;

    function  Kayit(Index: Integer): TTabloKayit;
    function  KayitSayisi: Integer;

    /// JSON-array ↔ kayıt dönüşümü
    function  ToJSONArray: TJSONArray;
    procedure FromJSONArray(A: TJSONArray);

    /// Sadece şemayı JSON string olarak al / yükle
    function  TabloyuJsonSemaOlarakAl: string;
    procedure TabloyuJsonSemaIleKurFromString(const JSONStr: string);

    /// Sıkıştırılmış JSON stream’e yaz / stream’den oku
    procedure SaveToStream(S: TStream);
    procedure LoadFromStream(S: TStream);

    property Ad: string read FAd write FAd;
    property Schema: TTabloSchema read FSchema write SetSchema;
    property SonID: Integer read FSonID write FSonID;
    property Kayitlar: specialize TObjectList<TTabloKayit> read FKayitlar;
  end;

implementation

uses
  Math;

{------------------------------------------------------------------------------}
constructor TVTablo.Create(const AAd: string);
begin
  inherited Create;
  FAd            := AAd;
  FKayitlar      := specialize TObjectList<TTabloKayit>.Create(True);
  FTempKayitlar  := specialize TObjectList<TTabloKayit>.Create(True);
  FSchema        := nil;
  FInTransaction := False;
  FSonID         := 0;
end;

destructor TVTablo.Destroy;
begin
  FKayitlar.Free;
  FTempKayitlar.Free;
  FSchema.Free;
  inherited;
end;

procedure TVTablo.SetSchema(S: TTabloSchema);
begin
  FSchema.Free;
  FSchema := S;
end;

procedure TVTablo.Temizle;
begin
  FKayitlar.Clear;
end;

function TVTablo.Kayit(Index: Integer): TTabloKayit;
begin
  if (Index < 0) or (Index >= FKayitlar.Count) then
    raise Exception.CreateFmt('Kayıt index dışı: %d', [Index]);
  Result := FKayitlar[Index];
end;

function TVTablo.KayitSayisi: Integer;
begin
  Result := FKayitlar.Count;
end;

procedure TVTablo.BeginTransaction;
begin
  if FInTransaction then Exit;
  FTempKayitlar.Clear;
  FInTransaction := True;
end;

procedure TVTablo.CommitTransaction;
begin
  if not FInTransaction then Exit;
  FKayitlar.AddRange(FTempKayitlar);
  FTempKayitlar.Clear;
  FInTransaction := False;
end;

procedure TVTablo.RollbackTransaction;
begin
  if not FInTransaction then Exit;
  FTempKayitlar.Clear;
  FInTransaction := False;
end;

function TVTablo.VarmiAyniPrimaryKey(const K: TTabloKayit): Boolean;
var
  Mevcut: TTabloKayit;
  i: Integer;
  alan: TAlanTanimi;
begin
  Result := False;
  for i := 0 to FSchema.AlanSayisi - 1 do
  begin
    alan := FSchema.Alanlar[i];
    if not alan.PrimaryKey then Continue;
    for Mevcut in FKayitlar do
      if VarCompareValue(Mevcut.DegerAl(alan.Name),
                         K.DegerAl(alan.Name)) = vrEqual then
        Exit(True);
  end;
end;

procedure TVTablo.TamamlaEksikAlanlar(
  const K: TTabloKayit;
  const Schema: TTabloSchema;
  const SonID: Integer
);
var
  i, yeniID: Integer;
  alan: TAlanTanimi;
   v: Variant;

begin
  for i := 0 to Schema.AlanSayisi - 1 do
  begin
    alan := Schema.Alanlar[i];
    if K.Varmi(alan.Name) then Continue;

    if alan.AutoIncrement and (alan.Tip = ftInteger) then
    begin
      yeniID := SonID + 1;
      while VarmiAyniPrimaryKey(K) do
        Inc(yeniID);
      K.DegerAta(alan.Name, yeniID);
    end
    else if alan.NotNull and (VarToStr(alan.DefaultDeger) <> '') then
      K.DegerAta(alan.Name, alan.DefaultDeger)
    else if alan.NotNull then
    begin
      case Alan.Tip of
        ftText:    v := '';
        ftFloat:   v := 0.0;
        ftInteger: v := 0;
      else
        v := Null;
      end;
      K.DegerAta(alan.Name,v);
    end else if VarToStr(alan.DefaultDeger) <> '' then
      K.DegerAta(alan.Name, alan.DefaultDeger)
    else
      K.DegerAta(alan.Name, Null);
  end;
end;

procedure TVTablo.KayitEkle(K: TTabloKayit);
begin
  if not Assigned(FSchema) then
    raise Exception.Create('Şema tanımlanmamış!');
  TamamlaEksikAlanlar(K, FSchema, FSonID);
  if FInTransaction then
    FTempKayitlar.Add(K)
  else
    FKayitlar.Add(K);
end;

{------------------------------------------------------------------------------}
function TVTablo.ToJSONArray: TJSONArray;
var
  i: Integer;
begin
  Result := TJSONArray.Create;
  for i := 0 to FKayitlar.Count - 1 do
    Result.Add(FKayitlar[i].ToJSON);
end;

procedure TVTablo.FromJSONArray(A: TJSONArray);
var
  i: Integer;
  K: TTabloKayit;
begin
  Temizle;
  for i := 0 to A.Count - 1 do
  begin
    K := TTabloKayit.Create;
    K.FromJSON(A.Objects[i]);
    FKayitlar.Add(K);
  end;
end;

function TVTablo.TabloyuJsonSemaOlarakAl: string;
var
  js: TJSONObject;
    ja: TJSONArray;

begin
  if not Assigned(FSchema) then
    raise Exception.Create('Şema tanımsız!');
     ja := FSchema.ToJSON as TJSONArray;
  try
    Result := ja.FormatJSON;
  finally
    ja.Free;
  end;

 { js := FSchema.ToJSON as TJSONObject;
  try
    Result := js.FormatJSON;
  finally
    js.Free;
  end;  }
end;

procedure TVTablo.TabloyuJsonSemaIleKurFromString(const JSONStr: string);
var
  jd: TJSONData;
begin
  jd := GetJSON(JSONStr);
  try
    FSchema := TTabloSchema.Create;
    FSchema.FromJSON(jd as TJSONArray);
  finally
    jd.Free;
  end;
end;

{------------------------------------------------------------------------------}
function TVTablo.BuildTableJSON: TJSONObject;
var
  schemaArr, dataArr: TJSONArray;
  colDef: TAlanTanimi;
  row: TTabloKayit;
  i: Integer;
  colObj: TJSONObject;
begin
  Result := TJSONObject.Create;
  Result.Add('TableName', FAd);

  // Şema
  schemaArr := TJSONArray.Create;
  for i := 0 to FSchema.AlanSayisi - 1 do
  begin
    colDef := FSchema.Alanlar[i];
    colObj := TJSONObject.Create;
    colObj.Add('Name',   colDef.Name);
    colObj.Add('Tip',    IntToStr(Ord(colDef.Tip)));
    colObj.Add('Length', IntToStr(colDef.Length));
    colObj.Add('PK',     colDef.PrimaryKey);
    colObj.Add('AI',     colDef.AutoIncrement);
    colObj.Add('NN',     colDef.NotNull);
    colObj.Add('DF',     VarToStr(colDef.DefaultDeger));
    schemaArr.Add(colObj);
  end;
  Result.Add('Schema', schemaArr);

  // Veri
  dataArr := TJSONArray.Create;
  for row in FKayitlar do
    dataArr.Add(row.ToJSON);
  Result.Add('Data', dataArr);
end;

procedure TVTablo.SaveToStream(S: TStream);
var
  jsonObj : TJSONObject;
  txt      : string;
  buf      : TBytes;
  ms       : TMemoryStream;
  cs       : TCompressionStream;
begin
  jsonObj := BuildTableJSON;
  try
    txt := jsonObj.FormatJSON;
    buf := TEncoding.UTF8.GetBytes(txt);

    ms := TMemoryStream.Create;
    try
      ms.WriteBuffer(buf[0], Length(buf));
      ms.Position := 0;
      cs := TCompressionStream.Create(clMax, S);
      try
        cs.CopyFrom(ms, 0);
      finally
        cs.Free;
      end;
    finally
      ms.Free;
    end;

  finally
    jsonObj.Free;
  end;
end;

procedure TVTablo.LoadFromStream(S: TStream);
var
  ds       : TDecompressionStream;
  ms       : TMemoryStream;
  jsonText : string;
  jd       : TJSONData;
  tblObj   : TJSONObject;
  schemaArr, dataArr: TJSONArray;
begin
  // 1) Decompress
  ds := TDecompressionStream.Create(S);
  ms := TMemoryStream.Create;
  try
    ms.CopyFrom(ds, 0);
    SetString(jsonText, PAnsiChar(ms.Memory), ms.Size);
  finally
    ds.Free;
    ms.Free;
  end;

  // 2) Parse & yükle
  jd := GetJSON(jsonText);
  try
    tblObj    := jd as TJSONObject;
    schemaArr := tblObj.GetPath('Schema') as TJSONArray;
    dataArr   := tblObj.GetPath('Data')   as TJSONArray;

    LoadSchemaFromJSONArray(schemaArr);
    FromJSONArray(dataArr);
  finally
    jd.Free;
  end;
end;

procedure TVTablo.LoadSchemaFromJSONArray(const schemaArr: TJSONArray);
var
  i: Integer;
  def: TAlanTanimi;
  obj: TJSONObject;
begin
  FSchema.Free;
  FSchema := TTabloSchema.Create;

  for i := 0 to schemaArr.Count - 1 do
  begin
    obj := schemaArr.Items[i] as TJSONObject;
    def := Default(TAlanTanimi);
    def.Name          := obj.Get('Name','');
    def.Tip           := TAlanTuru(StrToInt(obj.Get('Tip','0')));
    def.Length        := StrToInt(obj.Get('Length','0'));
    def.PrimaryKey    := obj.Get('PK', False);
    def.AutoIncrement := obj.Get('AI', False);
    def.NotNull       := obj.Get('NN', False);
    def.DefaultDeger  := ParseDegerTipli(def.Tip, obj.Get('DF',''));
    FSchema.AlanEkleDetayli(def);
  end;
end;

end.
