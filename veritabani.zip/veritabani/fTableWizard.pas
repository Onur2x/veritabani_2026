unit fTableWizard;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, StdCtrls, Grids, Buttons,
  oVeritabani, oTabloSchema, oTypes;

type
  TFormTableWizard = class(TForm)
    Button1:TButton;
    Button2:TButton;
    Button3:TButton;
    Button4:TButton;
    Button5:TButton;
    CheckAutoInc:TCheckBox;
    CheckPK:TCheckBox;
    CheckNotNull:TCheckBox;
    ComboTipi:TComboBox;
    EditAlanAdi:TEdit;
    EditVarsayilan:TEdit;
    EditTabloAdi: TEdit;
    Label1:TLabel;
    Label2:TLabel;
    Label3:TLabel;
    LabelTabloAdi: TLabel;
    GridAlanlar: TStringGrid;
    BtnAlanEkle: TButton;
    BtnOlustur: TButton;
    Memo1:TMemo;
    procedure BtnAlanEkleClick(Sender:TObject);
    procedure BtnOlusturClick(Sender:TObject);
    procedure Button1Click(Sender:TObject);
    procedure Button2Click(Sender:TObject);
    procedure Button3Click(Sender:TObject);
    procedure Button4Click(Sender:TObject);
    procedure Button5Click(Sender:TObject);
    procedure FormCreate(Sender: TObject);
  private
    FVeri: TVeritabani;
    FDBName: string;
    function GriddenSchemaOlustur:TTabloSchema;
  public
    procedure Initialize(Veritabani: TVeritabani; const AktifDB: string);
  end;

var
  FormTableWizard: TFormTableWizard;
  SilinenSatir: array of string; // Geçici yedek
  SilinenIndex: integer;         // Silinen satır konumu

implementation
uses Math,Dialogs;
{$R *.lfm}
function TFormTableWizard.GriddenSchemaOlustur: TTabloSchema;
var
  ad, tip, varsayilan: string;
  pk, autoInc, notNull: boolean;
  alan: TAlanTanimi;
  i: integer;
begin
  Result := TTabloSchema.Create(EditTabloAdi.Text);

  for i := 1 to GridAlanlar.RowCount - 1 do
  begin
    ad        := Trim(GridAlanlar.Cells[0, i]);
    tip       := Trim(GridAlanlar.Cells[1, i]);
    pk        := LowerCase(GridAlanlar.Cells[2, i]) = 'true';
    autoInc   := LowerCase(GridAlanlar.Cells[3, i]) = 'true';
    varsayilan:= GridAlanlar.Cells[4, i];
    notNull   := LowerCase(GridAlanlar.Cells[5, i]) = 'true';

    if ad = '' then Continue;

    alan := AlanOlustur(ad, tip, pk, autoInc);
    alan.DefaultDeger := varsayilan;
    alan.NotNull := notNull;

    Result.AlanEkleDetayli(alan);
  end;
end;
procedure TFormTableWizard.Initialize(Veritabani: TVeritabani; const AktifDB: string);
begin
  FVeri := Veritabani;
  FDBName := AktifDB;
end;

procedure TFormTableWizard.FormCreate(Sender: TObject);
var
  i:Integer;
begin
  GridAlanlar.RowCount := 2;
  GridAlanlar.ColCount := 6;
  GridAlanlar.Cells[0, 0] := 'Alan Adı';
  GridAlanlar.Cells[1, 0] := 'Tip';
  GridAlanlar.Cells[2, 0] := 'PK';
  GridAlanlar.Cells[3, 0] := 'AutoInc';
  GridAlanlar.Cells[4,0] := 'Varsayılan';
  GridAlanlar.Cells[5,0] := 'NotNull';

   // 🎯 ComboBox tipi tanımlama (örnek için sadece)
 // GridAlanlar.Columns[1].PickList.AddStrings([ 'Integer', 'Text', 'Float', 'Boolean', 'Date', 'Time', 'Timestamp']);


for i := 0 to Ord(High(TAlanTuru)) do
begin
  ComboTipi.Items.Add(AlanTuruToStr(TAlanTuru(i)));
 // GridAlanlar.Columns[1].PickList.AddStrings([ComboTipi.Items[i]]);
end;

//GridAlanlar.Columns[1].ButtonStyle := cbsPickList;
end;


procedure TFormTableWizard.Button1Click(Sender:TObject);
var
  schema: TTabloSchema;
begin
  memo1.Clear;
  schema := GriddenSchemaOlustur;
  memo1.lines.add(schema.ToJSON.AsJSON); // veya Memo içine yaz

end;

procedure TFormTableWizard.Button2Click(Sender:TObject);
var
  i, c: integer;
begin
  c := GridAlanlar.ColCount;
  SilinenIndex := GridAlanlar.Row;

  if SilinenIndex <= 0 then Exit; // Başlığı silme

  SetLength(SilinenSatir, c);
  for i := 0 to c - 1 do
    SilinenSatir[i] := GridAlanlar.Cells[i, SilinenIndex];

  GridAlanlar.DeleteRow(SilinenIndex);
  Button5.Enabled:=true;
end;

procedure TFormTableWizard.Button3Click(Sender:TObject);
var
  r, c: Integer;
  tmp: string;
begin
  r := GridAlanlar.Row;
  if r >= GridAlanlar.RowCount - 1 then Exit;

  for c := 0 to GridAlanlar.ColCount - 1 do
  begin
    tmp := GridAlanlar.Cells[c, r];
    GridAlanlar.Cells[c, r] := GridAlanlar.Cells[c, r + 1];
    GridAlanlar.Cells[c, r + 1] := tmp;
  end;
  GridAlanlar.Row := r + 1;
end;

procedure TFormTableWizard.Button4Click(Sender:TObject);
var
  r, c: Integer;
  tmp: string;
begin
  r := GridAlanlar.Row;
  if r <= 1 then Exit; // Başlık veya ilk satır

  for c := 0 to GridAlanlar.ColCount - 1 do
  begin
    tmp := GridAlanlar.Cells[c, r];
    GridAlanlar.Cells[c, r] := GridAlanlar.Cells[c, r - 1];
    GridAlanlar.Cells[c, r - 1] := tmp;
  end;
  GridAlanlar.Row := r - 1;
end;

 procedure InsertRowManual(Grid: TStringGrid; Index: Integer; const Values: array of string);
var
  r, c: Integer;
begin
  if (Index < 1) or (Index > Grid.RowCount) then Exit;

  // Satır sayısını arttır
  Grid.RowCount := Grid.RowCount + 1;

  // Alta doğru kaydır
  for r := Grid.RowCount - 1 downto Index + 1 do
    for c := 0 to Grid.ColCount - 1 do
      Grid.Cells[c, r] := Grid.Cells[c, r - 1];

  // Yeni satırı doldur
  for c := 0 to Min(High(Values), Grid.ColCount - 1) do
    Grid.Cells[c, Index] := Values[c];
end;

procedure TFormTableWizard.Button5Click(Sender:TObject);
var
  i: integer;
begin
  if Length(SilinenSatir) = GridAlanlar.ColCount then
  begin
  InsertRowManual(GridAlanlar, SilinenIndex, SilinenSatir);
  Button5.Enabled := False;
  SetLength(SilinenSatir, 0);
  end else
  ShowMessage('Geri alınacak bir alan bulunamadı.');

end;

procedure TFormTableWizard.BtnAlanEkleClick(Sender: TObject);
var
  row: Integer;
begin
  row := GridAlanlar.RowCount;
  //GridAlanlar.RowCount := GridAlanlar.RowCount + 1;
  GridAlanlar.RowCount := row + 1;

  GridAlanlar.Cells[0, row] := EditAlanAdi.Text;
  GridAlanlar.Cells[1, row] := ComboTipi.Text;
  GridAlanlar.Cells[2, row] := BoolToStr(CheckPK.Checked, True);
  GridAlanlar.Cells[3, row] := BoolToStr(CheckAutoInc.Checked, True);
  GridAlanlar.Cells[4, row] := EditVarsayilan.Text;
  GridAlanlar.Cells[5, row] := BoolToStr(CheckNotNull.Checked, True);

  // 🎯 Alan tanımı yapıldıktan sonra girdi kutularını temizleyebilirsin:
  EditAlanAdi.Text := '';
  ComboTipi.ItemIndex := -1;
  CheckPK.Checked := False;
  CheckAutoInc.Checked := False;
  EditVarsayilan.Text := '';
  CheckNotNull.Checked := False;


end;

procedure TFormTableWizard.BtnOlusturClick(Sender: TObject);
var
  schema: TTabloSchema;
  i: integer;
  ad, tip, varsayilan: string;
  pk, autoInc, notNull: boolean;
  alan: TAlanTanimi;
  bosVeri: TRowList;
begin
  bosVeri := TRowList.Create;
  schema := TTabloSchema.Create(EditTabloAdi.Text);

  for i := 1 to GridAlanlar.RowCount - 1 do
  begin
    ad        := Trim(GridAlanlar.Cells[0, i]);
    tip       := Trim(GridAlanlar.Cells[1, i]);
    pk        := LowerCase(GridAlanlar.Cells[2, i]) = 'true';
    autoInc   := LowerCase(GridAlanlar.Cells[3, i]) = 'true';
    varsayilan:= GridAlanlar.Cells[4, i];
    notNull   := LowerCase(GridAlanlar.Cells[5, i]) = 'true';

    if ad <> '' then
    begin
      alan := AlanOlustur(ad, tip, pk, autoInc);
      alan.DefaultDeger := varsayilan;
      alan.NotNull := notNull;
      schema.AlanEkleDetayli(alan);
    end;
  end;

  FVeri.AddOrReplaceTable(FDBName, schema.Ad, schema, bosVeri);
  FVeri.SaveToFile(FVeri.DosyaAdi);
  ShowMessage('Tablo oluşturuldu: ' + schema.Ad);
  Close;
end;
{
procedure TFormTableWizard.BtnOlusturClick(Sender: TObject);
var
  schema: TTabloSchema;
  i: integer;
  ad, tip: string;
  pk, autoInc: boolean;
  bosVeri: TRowList;
begin
  bosVeri := TRowList.Create;

  schema := TTabloSchema.Create(EditTabloAdi.Text);
  for i := 1 to GridAlanlar.RowCount - 1 do
  begin
    ad := Trim(GridAlanlar.Cells[0, i]);
    tip := Trim(GridAlanlar.Cells[1, i]);
    //  pk := GridAlanlar.Cells[2, i] = 'True';
    //   autoInc := GridAlanlar.Cells[3, i] = 'True';

    if ad <> '' then
      schema.AlanEkle(ad, tip);
  end;

  FVeri.AddOrReplaceTable(FDBName, schema.Ad, schema, bosVeri);
  Close;
end;

}end.
