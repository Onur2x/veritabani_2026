unit Unit1;

{$mode objfpc}{$H+}

interface

uses
  Classes, Grids,StdCtrls,SysUtils, Forms, Controls, Graphics, Dialogs,Generics.Collections;

type
  TForm1 = class(TForm)
    Button1:TButton;
    Button2:TButton;
    Button3:TButton;
    Button4:TButton;
    Button5:TButton;
    Button6:TButton;
    Button7:TButton;
    Button8:TButton;
    Button9:TButton;
    Edit1:TEdit;
    Memo1:TMemo;
    OpenDialog1:TOpenDialog;
    StringGrid1:TStringGrid;
    procedure Button1Click(Sender:TObject);
    procedure Button2Click(Sender:TObject);
    procedure Button3Click(Sender:TObject);
    procedure Button4Click(Sender:TObject);
    procedure Button5Click(Sender:TObject);
    procedure Button6Click(Sender:TObject);
    procedure Button7Click(Sender:TObject);
    procedure Button8Click(Sender:TObject);
    procedure Button9Click(Sender:TObject);
  private

  public

  end;

var
  Form1: TForm1;

implementation
uses paket,dbtablo,dbtype,Variants,fpjson;
{$R *.lfm}

procedure TestAlanNormalization;
var
  json: TJSONObject;
  alan: TAlanTanimi;
begin
  json := TJSONObject.Create;
  json.Add('name', 'ad');
  json.Add('type', 'Text');
  json.Add('primaryKey', True);
  json.Add('default', '');
  alan := alantanimijsondan(json);

  WriteLn('Alan: ', alan.Name);
  WriteLn('Tip: ', alanturutostr(alan.Tip));
  WriteLn('Length: ', alan.Length);
  WriteLn('NotNull: ', alan.NotNull);
  WriteLn('Default: ', VarToStr(alan.DefaultDeger));
end;

procedure TabloyuStringGridAktar(const tablo: TDBTablo; grid: TStringGrid);
var
  i, j: Integer;
  kayit: TKayit;
  key: string;
begin
  // Grid başlıklarını ayarla
  grid.ColCount := tablo.AlanSayisi;
  grid.RowCount := tablo.SatirSayisi + 1;

  // Başlıklar
  for j := 0 to tablo.AlanSayisi - 1 do
    grid.Cells[j, 0] := tablo.AlanGetir(j).Name;

  // Veriler
  for i := 0 to tablo.SatirSayisi - 1 do
  begin
    kayit := tablo.KayitGetir(i);

    for j := 0 to tablo.AlanSayisi - 1 do
    begin
      key := tablo.AlanGetir(j).Name;
      grid.Cells[j, i + 1] := VarToStr(kayit.Items[key]);
    end;
  end;
end;

procedure TForm1.Button1Click(Sender: TObject);
var
  Paket: TVeritabaniPaket;
  musteriTablo, faturaTablo: TDBTablo;
  a: TAlanTanimi;
  veri: TKayit;
  i: Integer;
begin
  Paket := TVeritabaniPaket.Create;

  paket.TabloEkle('Müşteriler');
  paket.TabloEkle('Faturalar');

  // Tablo nesnesi oluştur
//  musteriTablo := TDBTablo.Create('musteriler01', 'Müşteriler');
//  faturaTablo  := TDBTablo.Create('faturalar02', 'Faturalar');  // ← fatura ID ve eklenecek sözlük uyuşmalı!

  // Müşteri tablosu şeması
  a.Name := 'id';
  a.Tip := oeAutoIncrement;
  a.Length := 20;
  paket.TabloGetir(1).AlanEkle(a);


  a.Name := 'ad';
  a.Tip := oeText;
  a.NotNull := True;
  a.Length := 25;
  a.DefaultDeger := 'ISIMSIZ';
  paket.TabloGetir(1).AlanEkle(a);


  // Fatura tablosu şeması
  a.Name := 'id';
  a.Tip := oeAutoIncrement;
  a.Length := 20;
 paket.TabloGetir(2).AlanEkle(a);

  a.Name := 'tutar';
  a.Tip := oeDouble;
  a.NotNull := True;
  a.DefaultDeger := '0.0';
  a.Length := 20;
 paket.TabloGetir(2).AlanEkle(a);

  // Kayıtlar
  for i := 1 to 10 do
  begin
    veri := TKayit.Create;
    veri.Add('ad', 'Ali' + IntToStr(i)); // id otomatik verilecek
    if paket.TabloGetir(1).KayitEkle(veri) then
      WriteLn('✔️ Kayit eklendi: ', veri.Items['ad'])
    else
      WriteLn('❌ Kayit eklenemedi: ', veri.Items['ad']);
  end;

  for i := 1 to 10 do
  begin
    veri := TKayit.Create;
    veri.Add('tutar', 100.50 + i * 10); // id otomatik verilecek
    paket.TabloGetir(2).KayitEkle(veri);
 //   faturaTablo.KayitEkle(veri);
  end;

  // Tabloları pakete ekle
 // Paket.Tablolar.Add('musteriler01', musteriTablo);
//  Paket.Tablolar.Add('faturalar02', faturaTablo);

  // Paketi kaydet
  Paket.SavePackageToFile('demo.odb');

  // Log
//  WriteLn('→ Musteriler kayit: ', musteriTablo.SatirSayisi);
//  WriteLn('→ Faturalar kayit: ', faturaTablo.SatirSayisi);
  memo1.Append('Veri paketi demo.odb olarak kaydedildi.');

  Paket.Free;
end;


procedure YazTabloVerisiMemoya(const tablo: TDBTablo; memo: TMemo);
var
  i: Integer;
  kayit: TKayit;
  satirStr: string;
  key: string;
begin
  memo.Append('Tablo: ' + tablo.TableName);
  memo.Append('Toplam Kayıt: ' + IntToStr(tablo.SatirSayisi));
  memo.Append('-----------------------------');

  for i := 0 to tablo.SatirSayisi - 1 do
  begin
    satirStr := '';
    kayit := tablo.KayitGetir(i);

    for key in kayit.Keys do
      satirStr := satirStr + key + '=' + VarToStr(kayit.Items[key]) + ' | ';

    memo.Append(satirStr);
  end;
end;



procedure TForm1.Button2Click(Sender: TObject);
var
  Paket: TVeritabaniPaket;
  tableID: Integer;
begin
  Paket := TVeritabaniPaket.Create;
  try
    Paket.LoadPackageFromFile('demo.odb');
    memo1.Append('Demo.odb başarıyla yüklendi.');
    memo1.Append('============================');

    // Tabloları listele ve içeriklerini yazdır
    for tableID in Paket.Tablolar.Keys do
    begin
      YazTabloVerisiMemoya(Paket.Tablolar[tableID], memo1);
      memo1.Append('============================');
    end;
  except
    on E: Exception do
      memo1.Append('Hata: ' + E.Message);
  end;
  Paket.Free;
end;


procedure TForm1.Button3Click(Sender:TObject);
var
  Paket: TVeritabaniPaket;
begin
  Paket := TVeritabaniPaket.Create;
  Paket.LoadOnlyTable('demo.odb', 1);
  Paket.Free;
  memo1.Append('Faturalar tablosu yüklendi.');
end;

procedure TForm1.Button4Click(Sender:TObject);
 var
  satirlar: specialize TArray<string>;
  s: string;
  Paket: TVeritabaniPaket;
  musteriTablo: TDBTablo;
begin
Paket := TVeritabaniPaket.Create;
  Paket.LoadPackageFromFile('demo.odb');
  musteriTablo := Paket.Tablolar[1]; // GUI’ye bağladın


  satirlar := musteriTablo.KayitAraListe('ad', 'Ali'); // örnek arama
  memo1.Lines.Clear;
  for s in satirlar do
    memo1.Lines.Add(s); // GUI üzerinden listeleme

 { Paket := TVeritabaniPaket.Create;
  Paket.LoadOnlyTable('demo.odb', 'musteriler01');
  memo1.Lines.Clear;
  for s in satirlar do
    memo1.Lines.Add(s); // GUI üzerinden listeleme
 }
  {satirlar := paket.musteriTablo.KayitAraListe('ad', 'Ali5');
  for s in satirlar do
    memo1.Append(s);  }
end;

procedure TForm1.Button5Click(Sender:TObject);
 var
  satirlar: specialize TArray<string>;
  s: string;
  Paket: TVeritabaniPaket;
  musteriTablo: TDBTablo;
begin
Paket := TVeritabaniPaket.Create;
  Paket.LoadPackageFromFile('demo.odb');
  musteriTablo := Paket.Tablolar[1]; // GUI’ye bağladın

  TabloyuStringGridAktar(musteriTablo, StringGrid1);

end;

procedure TForm1.Button6Click(Sender:TObject);
begin
TestAlanNormalization
end;


function CreateDummyKayit(j: Integer): TKayit;
var k: Integer;
begin
  Result := TKayit.Create;
  for k := 2 to 10 do
    Result.Add('A' + IntToStr(k), 'v' + IntToStr(j));
end;



procedure TestVeriYazOkuBenchmark;
var
  i, j, k: Integer;
  tablo: TDBTablo;
  alan: TAlanTanimi;
  veritabani: TVeritabaniPaket;
  startWrite, startRead, elapsedWrite, elapsedRead: Int64;
  dummy: TJSONObject;
  Veri:TKayit;
begin
  veritabani := TVeritabaniPaket.Create;

  // 🚀 Tablo ve alan oluşturma
  for i := 1 to 15 do
  begin
    tablo := veritabani.TabloEkle('Tablo_' + IntToStr(i));
    for j := 1 to 10 do
    begin
  //    alan := TAlanTanimi.Create;


      if j=1 then
      begin
       alan.Name := 'ID';
       alan.Tip := oeAutoIncrement; // Dilersen karıştır: oeInteger, oeDouble...
      end else
      begin
       alan.Name := 'Alan_' + IntToStr(j);
       alan.Tip := oeText; // Dilersen karıştır: oeInteger, oeDouble...
       alan.Length := 50;
      end;
      tablo.AlanEkle(alan);// Schema.Add(alan);
    end;
  end;

  // 🕒 Yazma süresi başlat
  startWrite := GetTickCount64;

  // 🔁 Sahte kayıt ekleme
  for i := 1 to 15 do
  begin
    tablo := veritabani.Tablolar[i];
    for j := 1 to 500 do
    begin
     // dummy := TJSONObject.Create;
      veri:=TKayit.create;
   //   veri:=CreateDummyKayit(j);

      for k := 2 to 10 do
      veri.Add('Alan_' + IntToStr(k), 'v' + IntToStr(j));
    //  for k := 1 to 10 do
    //   if (j>15) and (i=1) then
     //    writeln(veri.Items['Alan_1']);
    //  veri.add('Alan_' + IntToStr(k), 'veri_' + IntToStr(j));
   //     dummy.Add('Alan_' + IntToStr(k), 'veri_' + IntToStr(j));
      tablo.KayitEkle(veri);//dummy);
      //dummy.Free;
    end;
  end;



  elapsedWrite := GetTickCount64 - startWrite;
  WriteLn('📝 Yazma süresi: ', elapsedWrite, ' ms');

  // 🕒 Okuma süresi başlat
  startRead := GetTickCount64;

  for i := 1 to 15 do
  begin
    tablo := veritabani.Tablolar[i];

    // Satırları sırayla oku
    for j := 0 to tablo.SatirSayisi - 1 do
    begin
      veri := tablo.KayitGetir(j);  // veya tablo.Kayitlar[j]
      // İstersen burada içeriği test et: kayit.GetValue('Alan_1');
    //  form1.memo1.Append
    //  writeln(veri.Items['Alan_1']);
    //  if j=10 then break;
       form1.memo1.Append(veri.Items['Alan_1']);//   GetValue('Alan_1'));

    end;
  end;


//  for i := 1 to 15 do
//    dummy := veritabani.Tablolar[i].VerilerToJSON; // 💾 Tüm kayıtları oku

  elapsedRead := GetTickCount64 - startRead;
  WriteLn('📖 Okuma süresi: ', elapsedRead, ' ms');
  veritabani.SavePackageToFile('AAAA.dbo');
  veritabani.Free;
end;
procedure TForm1.Button7Click(Sender:TObject);
begin
TestVeriYazOkuBenchmark;
end;

procedure TForm1.Button8Click(Sender:TObject);
 var
  satirlar: specialize TArray<string>;
  s: string;
  Paket: TVeritabaniPaket;
  musteriTablo: TDBTablo;
begin
if OpenDialog1.Execute then
begin
  Paket := TVeritabaniPaket.Create;

  Paket.LoadPackageFromFile(OpenDialog1.FileName);
  musteriTablo := Paket.Tablolar[1]; // GUI’ye bağladın

  TabloyuStringGridAktar(musteriTablo, StringGrid1);
paket.Free;
end;
end;


procedure TestVeriYazOkuListeBenchmark2;
var
  i, j, k: Integer;
  tablo: TDBTablo;
  alan: TAlanTanimi;
  veritabani: TVeritabaniPaket;
  startWrite, startRead, elapsedWrite, elapsedRead: Int64;
  veriListesi: specialize TList<TKayit>;
  kayit: TKayit;
  dummyStr: Variant;
begin
  veritabani := TVeritabaniPaket.Create;

  // 🏗️ 15 tablo, 10 alan
  for i := 1 to 15 do
  begin
    tablo := veritabani.TabloEkle('Tablo_' + IntToStr(i));
    for j := 1 to 10 do
    begin
      if j=1 then
      begin
       alan.Name := 'ID';
       alan.Tip := oeAutoIncrement; // Dilersen karıştır: oeInteger, oeDouble...
      end else
      begin
       alan.Name := 'Alan_' + IntToStr(j);
       alan.Tip := oeText; // Dilersen karıştır: oeInteger, oeDouble...
       alan.Length := 50;
      end;
      tablo.AlanEkle(alan);// Schema.Add(alan);
    end;
  end;

  // 📝 Kayıt listesini oluştur
  veriListesi := specialize TList<TKayit>.Create;
  for j := 1 to 10000 do
  begin
    kayit := TKayit.Create;
    for k := 1 to 10 do
      kayit.Add('Alan_' + IntToStr(k), 'veri_' + IntToStr(j));
    veriListesi.Add(kayit);
  end;

  // 🕒 Yazma süresi başlat
  startWrite := GetTickCount64;


 // for j := 0 to veriListesi.Count - 1 do
  // tablo.KayitEkle(veriListesi[j]);


  // 📦 Listeyi tabloya topluca ekle
 { for i := 1 to 15 do
  begin
    tablo := veritabani.Tablolar[i];
    tablo.KayitEkleListesi(veriListesi);
   // for j := 0 to veriListesi.Count - 1 do
  //    tablo.KayitEkle(veriListesi[j]);
  end;  }

   for i := 1 to 15 do
//    veritabani.Tablolar[i].KayitEkleListesi(veriListesi);  // ✅ Senin yöntemin
    veritabani.Tablolar[i].BatchInsert(veriListesi,false);

  elapsedWrite := GetTickCount64 - startWrite;
  WriteLn('📝 Listeyle yazma süresi: ', elapsedWrite, ' ms');

  // 🕒 Okuma süresi başlat
  startRead := GetTickCount64;

  for i := 1 to 15 do
  begin
    tablo := veritabani.Tablolar[i];
    for j := 0 to tablo.SatirSayisi - 1 do
    begin
      kayit := tablo.KayitGetir(j);
    //  dummyStr := kayit['Alan_1']; // 👈 gerçek erişim yap
    end;
  end;

  elapsedRead := GetTickCount64 - startRead;
  WriteLn('📖 Listeyle okuma süresi: ', elapsedRead, ' ms');


  veritabani.SavePackageToFile('AAAA2.dbo');

  // 🧹 Bellek temizliği
  for j := 0 to veriListesi.Count - 1 do
    veriListesi[j].Free;

 // veritabani.Free;
end;


procedure TForm1.Button9Click(Sender:TObject);

begin
TestVeriYazOkuListeBenchmark2
end;


end.

