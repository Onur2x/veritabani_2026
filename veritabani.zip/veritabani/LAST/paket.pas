unit paket;

interface

uses
  Classes, SysUtils, fpjson, zstream, Generics.Collections, DateUtils,
  dbtype, dbtablo, Dialogs;

type
  TVeritabaniPaket = class
  private
    FVeritabaniAdi: string;
    FTablolar: specialize TDictionary<integer, TDBTablo>;
    FSonTabloID: integer;

    function BuildPackageJSON: string;
    function BuildTableJSON(const tableID:integer):TJSONObject;
    function GetTableDataJSON(const tableID:integer):string;
    procedure WriteTableDataBlocks(dest: TStream);
    procedure CreateTableFromMeta(tblMeta: TJSONObject);
    procedure AddRowsFromJSON(const tableID: integer; dataStr: string);
    procedure SortTablesByDependencies(const tableArr: TJSONArray;
      out sortedList: specialize TList<TJSONObject>);
  public
    constructor Create;
    destructor Destroy; override;
    function TabloEkle(const Name: string): TDBTablo;
    procedure TabloSil(const TabloID: integer);
    procedure TabloGuncelleAdi(const TabloID: integer; const YeniAd: string);
    function TabloGetir(const TabloID: integer): TDBTablo;
    procedure SavePackageToFile(const fileName: string);
    procedure LoadPackageFromFile(const fileName: string);
    procedure LoadOnlyTable(const fileName: string; tableID: integer);
    property Tablolar: specialize TDictionary<integer, TDBTablo> read FTablolar;
  end;

implementation


{ Sıkıştırma }

procedure CompressStreamWithZStream(src, dest: TStream);
var
  compressor: TCompressionStream;
begin
  compressor := TCompressionStream.Create(clmax, dest);
  src.Position := 0;
  compressor.CopyFrom(src, src.Size);
  compressor.Free;
end;

procedure DecompressStreamWithZStream(src, dest: TStream);
var
  decompressor: TDecompressionStream;
begin
  decompressor := TDecompressionStream.Create(src);
  dest.CopyFrom(decompressor, 0);
  decompressor.Free;
end;

{ Yapıcı ve Yıkıcı }
function TVeritabaniPaket.TabloEkle(const Name: string): TDBTablo;
begin
  Inc(FSonTabloID);
  Result := TDBTablo.Create(FSonTabloID, Name);
  FTablolar.Add(FSonTabloID, Result);
//  WriteLn('🆕 Tablo eklendi → ID: ', FSonTabloID, ' | Ad: ', Name);
end;

procedure TVeritabaniPaket.TabloSil(const TabloID: integer);
begin
  if FTablolar.ContainsKey(TabloID) then
  begin
    FTablolar[TabloID].Free;
    FTablolar.Remove(TabloID);
//    WriteLn('🗑️ Tablo silindi → ID: ', TabloID);
  end
//  else
//    WriteLn('⚠️ Silme başarısız → TabloID bulunamadı: ', TabloID);
end;

procedure TVeritabaniPaket.TabloGuncelleAdi(const TabloID: integer;
  const YeniAd: string);
begin
  if FTablolar.ContainsKey(TabloID) then
  begin
    FTablolar[TabloID].TableName := YeniAd;
//    WriteLn('✏️ Tablo adı güncellendi → Yeni ad: ', YeniAd);
  end
//  else
//    WriteLn('⚠️ Güncelleme başarısız → TabloID bulunamadı: ', TabloID);
end;

function TVeritabaniPaket.TabloGetir(const TabloID: integer): TDBTablo;
begin
  if FTablolar.ContainsKey(TabloID) then
    Result := FTablolar[TabloID]
  else
    Result := nil;
end;

constructor TVeritabaniPaket.Create;
begin
  FSonTabloID := 0;
  FTablolar := specialize TDictionary<integer, TDBTablo>.Create;
end;

destructor TVeritabaniPaket.Destroy;
var
  tablo: TDBTablo;
begin
  for tablo in FTablolar.Values do
    tablo.Free;
  FTablolar.Free;
  inherited Destroy;
end;

{
procedure TVeritabaniPaket.YukleVeritabanindan(const json: TJSONObject);
var
  tabloArray: TJSONArray;
  i: Integer;
  tabloObj: TJSONObject;
  tablo: TDBTablo;
begin
  FSonTabloID := 0;
  FTablolar.Clear;
  tabloArray := json.Get('tables', TJSONArray.Create);

  for i := 0 to tabloArray.Count - 1 do
  begin
    tabloObj := TJSONObject(tabloArray.Items[i]);
    tablo := TDBTablo.FromJSON(tabloObj); // ← Burada tablo nesnesi oluşuyor

    if tablo.TableID > FSonTabloID then
      FSonTabloID := tablo.TableID; // ✅ İşte bu satır burada olmalı

    FTablolar.Add(tablo.TableID, tablo);
  end;
end;

procedure TVeritabaniPaket.LoadFromJSON(const json: TJSONObject);
var
  i, tempID: Integer;
  tabloObj: TJSONObject;
  tabloArray: TJSONArray;
  tablo: TDBTablo;
begin
  FSonTabloID := 0; // Başlangıçta sıfırla
  FTablolar.Clear;
  tabloArray := json.Get('tables', TJSONArray.Create);

  for i := 0 to tabloArray.Count - 1 do
  begin
    tabloObj := TJSONObject(tabloArray.Items[i]);
    tablo := TDBTablo.FromJSON(tabloObj);
    tempID := tablo.TableID;

    if tempID > FSonTabloID then
      FSonTabloID := tempID; // ✅ En büyük ID'yi güncelle

    FTablolar.Add(tempID, tablo);
  end;
end;
}
{ Paket Kaydetme }

procedure TVeritabaniPaket.SavePackageToFile(const fileName: string);
var
  rawStream, compressedStream: TMemoryStream;
  metaStr: string;

begin
  rawStream := TMemoryStream.Create;
  compressedStream := TMemoryStream.Create;
  try
    rawStream.WriteBuffer('ODBX', 4);  // imza
    rawStream.WriteByte(1);            // versiyon

    metaStr := BuildPackageJSON;
    rawStream.WriteDWord(Length(metaStr));
    rawStream.WriteBuffer(metaStr[1], Length(metaStr));

    WriteTableDataBlocks(rawStream);




    CompressStreamWithZStream(rawStream, compressedStream);
    compressedStream.SaveToFile(fileName);

    with TStringList.Create do
    try
      Text := metaStr;
      SaveToFile(ChangeFileExt(fileName, '.json'));
    finally
      Free;
    end;
  finally
    rawStream.Free;
    compressedStream.Free;
  end;
end;

procedure TVeritabaniPaket.LoadPackageFromFile(const fileName: string);
var
  compressedStream, rawStream: TMemoryStream;
  sig: array[0..3] of char;
  version: byte;
  metaLen: cardinal;
  metaStr: string;
  metaObj: TJSONObject;
  tableArr: TJSONArray;
  sortedTables: specialize TList<TJSONObject>;
  i: integer;
  tbl: TJSONObject;
  tid: integer;//string;
  tidLen: byte;
  dataLen: cardinal;
  dataStr: string;
//  crcStored, crcComputed: cardinal;
  tableIDInt: longint;
begin
  FSonTabloID := 0;  // ✅ Sayaç sıfırla
  compressedStream := TMemoryStream.Create;
  rawStream := TMemoryStream.Create;
  try
    compressedStream.LoadFromFile(fileName);
    DecompressStreamWithZStream(compressedStream, rawStream);
    rawStream.Position := 0;

    rawStream.ReadBuffer(sig, 4);
    if string(sig) <> 'ODBX' then
      raise Exception.Create('Geçersiz paket: İmza uyuşmuyor');
    version := rawStream.ReadByte;
    if version <> 1 then raise Exception.Create('Versiyon uyumsuz: ' +
        IntToStr(version));

    rawStream.ReadBuffer(metaLen, 4);
    SetLength(metaStr, metaLen);
    rawStream.ReadBuffer(metaStr[1], metaLen);
    metaObj := GetJSON(metaStr) as TJSONObject;
    tableArr := metaObj.Arrays['tables'];

    sortedTables := specialize TList<TJSONObject>.Create;
    try
      SortTablesByDependencies(tableArr, sortedTables);
      for i := 0 to sortedTables.Count - 1 do
        CreateTableFromMeta(sortedTables[i]);
    finally
      sortedTables.Free;
    end;


    // ✅ En büyük tablo ID'sini bul ve sayaç olarak ayarla
    for i := 0 to tableArr.Count - 1 do
    begin
      tbl := TJSONObject(tableArr.Items[i]);
      tableIDInt := StrToIntDef(tbl.Get('tableid', '0'), 0);
      // 👈 String ID’yi sayıya çevir
      if tableIDInt > FSonTabloID then
        FSonTabloID := tableIDInt;
      //  end;


      //  for i := 0 to tableArr.Count - 1 do
      //   begin
      //     tbl := TJSONObject(tableArr.Items[i]);
     { rawStream.ReadBuffer(tidLen, 1);
      SetLength(tid, tidLen);
      rawStream.ReadBuffer(tid[1], tidLen);
      }
      rawStream.ReadBuffer(tid, SizeOf(cardinal));

      rawStream.ReadBuffer(dataLen, 4);
      SetLength(dataStr, dataLen);
      rawStream.ReadBuffer(dataStr[1], dataLen);

      AddRowsFromJSON(tid, dataStr);
    end;

  {  rawStream.ReadBuffer(crcStored, 4);
    crcComputed := CalcCRC32(rawStream.Memory^, rawStream.Size - 4);
    if crcStored <> crcComputed then
      raise Exception.Create('CRC doğrulaması başarısız: Veri bozulmuş olabilir!'); }
  finally
    compressedStream.Free;
    rawStream.Free;
  end;
end;

procedure TVeritabaniPaket.SortTablesByDependencies(const tableArr: TJSONArray;
  out sortedList: specialize TList<TJSONObject>);
var
  visited: specialize TList<integer>; // ✅ TStringList yerine Integer listesi kullan
  depArr: TJSONArray;

  procedure Visit(const tableID: integer);
  var
    tbl: TJSONObject;
    depTableID: integer;
    i, j: integer;
    js: TJSONData;
  begin
    if visited.IndexOf(tableID) <> -1 then Exit;
    visited.Add(tableID);

    // Tabloyu bul
    for i := 0 to tableArr.Count - 1 do
    begin
      js := tableArr.Items[i];
      if Assigned(js) and (js is TJSONObject) then
      begin
        tbl := TJSONObject(js);
        if tableID = GetJSONIntSafe(tbl, 'tableid', 0) then
        begin
          // 🔐 dependencies güvenli alınır
          if tbl.Find('dependencies') is TJSONArray then
            depArr := TJSONArray(tbl.Find('dependencies'))
          else
            depArr := TJSONArray.Create; // boş dahi olsa oluşturulmalı

          // Bağımlılıkları gez
          for j := 0 to depArr.Count - 1 do
          begin
            depTableID := StrToIntDef(depArr.Strings[j], 0);
            // ✅ string'ten Integer'a çevir
            if depTableID > 0 then
              Visit(depTableID);
          end;

          // Sıralı listeye ekle
          sortedList.Add(tbl);
          Break;
        end;
      end;
    end;
  end;

var
  i: integer;
  tblObj: TJSONObject;
  tableID: integer;
begin
  visited := specialize TList<integer>.Create;
  try
    for i := 0 to tableArr.Count - 1 do
    begin
      if Assigned(tableArr.Items[i]) and (tableArr.Items[i] is TJSONObject) then
      begin
        tblObj := TJSONObject(tableArr.Items[i]);
        tableID := GetJSONIntSafe(tblObj, 'tableid', 0);
        if tableID > 0 then
          Visit(tableID);
      end;
    end;
  finally
    visited.Free;
  end;
end;


{
procedure TVeritabaniPaket.SortTablesByDependencies(
  const tableArr: TJSONArray;
  out sortedList: specialize TList<TJSONObject>);
var
  visited: TStringList;

  procedure Visit(const tableID: integer);
  var
    tbl: TJSONObject;
    depArr: TJSONArray;
    depID: string;
    i, j: Integer;
    js: TJSONData;
  begin
    if visited.IndexOf(tableID) <> -1 then Exit;
    visited.Add(tableID);

    // Tabloyu bul
    for i := 0 to tableArr.Count - 1 do
    begin
      js := tableArr.Items[i];
      if Assigned(js) and (js is TJSONObject) then
      begin
        tbl := TJSONObject(js);
     //   if SameText(tbl.Get('tableid', ''), tableID) then
        if tableID=GetJSONIntSafe(tbl,'tableid', 0) then
        begin
          // 🔐 dependencies güvenli alınır
          if tbl.Find('dependencies') is TJSONArray then
            depArr := TJSONArray(tbl.Find('dependencies'))
          else
            depArr := TJSONArray.Create;

          // Bağımlılıkları gez
          for j := 0 to depArr.Count - 1 do
          begin
            depID := depArr.Strings[j];
            Visit(depID);
          end;

          // Sıralı listeye ekle
          sortedList.Add(tbl);
          Break;
        end;
      end;
    end;
  end;

var
  i: Integer;
  tblObj: TJSONObject;
  tableID: integer;//string;
begin
  visited := TStringList.Create;
  try
    for i := 0 to tableArr.Count - 1 do
    begin
      if Assigned(tableArr.Items[i]) and (tableArr.Items[i] is TJSONObject) then
      begin
        tblObj := TJSONObject(tableArr.Items[i]);
        tableID := GetJSONIntSafe(tblObj,'tableid', 0);////tblObj.Get('tableid', '');
        if tableID > 0 then
          Visit(tableID);
      end;
    end;
  finally
    visited.Free;
  end;
end; }

procedure TVeritabaniPaket.LoadOnlyTable(const fileName: string; tableID: integer);
var
  compressedStream, rawStream: TMemoryStream;
  sig: array[0..3] of char;
  version: byte;
  metaLen: cardinal;
  metaStr, dataStr: string;
  metaObj, tblMeta: TJSONObject;
  tableArr: TJSONArray;
  i, idLen, foundID: integer;
  dataLen: cardinal;
begin
  compressedStream := TMemoryStream.Create;
  rawStream := TMemoryStream.Create;
  try
    compressedStream.LoadFromFile(fileName);
    DecompressStreamWithZStream(compressedStream, rawStream);
    rawStream.Position := 0;

    rawStream.ReadBuffer(sig, 4);
    if string(sig) <> 'ODBX' then
      raise Exception.Create('Geçersiz dosya: imza uyuşmuyor');
    version := rawStream.ReadByte;
    if version <> 1 then raise Exception.Create('Versiyon uyuşmazlığı: ' +
        IntToStr(version));

    rawStream.ReadBuffer(metaLen, 4);
    SetLength(metaStr, metaLen);
    rawStream.ReadBuffer(metaStr[1], metaLen);
    metaObj := GetJSON(metaStr) as TJSONObject;
    tableArr := metaObj.Arrays['tables'];

    for i := 0 to tableArr.Count - 1 do
    begin
      if Assigned(tableArr.Items[i]) and (tableArr.Items[i] is TJSONObject) then
      begin
        tblMeta := TJSONObject(tableArr.Items[i]);
        if tblMeta.Get('tableid', 0) = tableID then
        begin
          CreateTableFromMeta(tblMeta);
          Break;
        end;
      end;
    end;

    for i := 0 to tableArr.Count - 1 do
    begin
     { rawStream.ReadBuffer(idLen, 1);
      SetLength(foundID, idLen);
      rawStream.ReadBuffer(foundID[1], idLen);
     }
      rawStream.ReadBuffer(foundID, SizeOf(cardinal));

      rawStream.ReadBuffer(dataLen, 4);
      SetLength(dataStr, dataLen);
      rawStream.ReadBuffer(dataStr[1], dataLen);

      //  if SameText(foundID, tableID) then
      if foundID = tableID then
      begin
        AddRowsFromJSON(tableID, dataStr);
        Break;
      end;
    end;
  finally
    compressedStream.Free;
    rawStream.Free;
  end;

//  WriteLn('💾 Final tablo satir sayisi: ', FTablolar[tableid].SatirSayisi);
  // .Items[tableID].SatirSayisi);

end;

procedure TVeritabaniPaket.CreateTableFromMeta(tblMeta: TJSONObject);
var
  tablo: TDBTablo;
  alanlar: specialize TList<TAlanTanimi>;
  i: integer;
  tableID: integer;
  tableName: string;
begin
  tableID := GetJSONIntSafe(tblMeta, 'tableid', 0);// tblMeta.Get('tableid', 0);
  tableName := tblMeta.Get('name', '');

  tablo := TDBTablo.Create(tableID, tableName);
  alanlar := JSONArrayToAlanList(tblMeta.Arrays['schema']);
  for i := 0 to alanlar.Count - 1 do
    tablo.AlanEkle(alanlar[i]);

  if not FTablolar.ContainsKey(tableID) then
  begin
    FTablolar.Add(tableID, tablo);
//    WriteLn('✅ Tablo eklendi: ', tableID);
  end
//  else
//    WriteLn('⚠️ Tablo zaten var! Atlandi: ', tableID);


{  if not FTablolar.ContainsKey(tableID) then
    FTablolar.Add(tableID, tablo)
  else
    raise Exception.Create('Duplicate tableID: ' + tableID);   }
end;

procedure TVeritabaniPaket.AddRowsFromJSON(const tableID: integer; dataStr: string);
var
  arr: TJSONArray;
  i, j: integer;
  veri: TKayit;
  obj: TJSONObject;
  keyi: string;
begin
  arr := GetJSON(dataStr) as TJSONArray;
//  WriteLn('➤ Kayit ekleniyor → ', tableID);
//  WriteLn('  Toplam JSON satiri: ', arr.Count);


  for i := 0 to arr.Count - 1 do
  begin
    obj := arr.Objects[i];
    veri := TKayit.Create;
    for j := 0 to obj.Count - 1 do
    begin
      keyi := obj.Names[j];
      veri.Add(keyi, obj.Get(keyi, ''));
//      WriteLn('    Alan: ', keyi, ' = ', obj.Get(keyi, ''));

    end;
    FTablolar[tableID].KayitEkle(veri);
  end;
end;

function TVeritabaniPaket.BuildPackageJSON: string;
var
  metaObj, tblObj: TJSONObject;
  tableArr: TJSONArray;
  tableID: integer;
  table: TDBTablo;
begin
  metaObj := TJSONObject.Create;
  tableArr := TJSONArray.Create;

  for tableID in FTablolar.Keys do
  begin
    table := FTablolar.Items[tableID];
    tblObj := BuildTableJSON(tableID); // 👈 Yeni versiyon aşağıda
    tableArr.Add(tblObj);
  end;

  metaObj.Add('databasename', 'demo');
  metaObj.Add('createdate', FormatDateTime('dd.mm.yyyy', Date));
  metaObj.Add('tablecount', FTablolar.Count);
  //  metaObj.Add('crc', '');
  metaObj.Add('tables', tableArr);

  Result := metaObj.AsJSON;
  metaObj.Free;
end;

function TVeritabaniPaket.BuildTableJSON(const tableID: integer): TJSONObject;
var
  obj: TJSONObject;
  tablo: TDBTablo;
begin
  tablo := FTablolar.Items[tableID];
  obj := TJSONObject.Create;
  obj.Add('tableid', tableID); // 👈 Artık string değil!
  obj.Add('name', tablo.TableName);
  obj.Add('version', '1.0');
  obj.Add('created', FormatDateTime('dd.mm.yyyy hh:nn:ss', Now));
  obj.Add('modified', FormatDateTime('dd.mm.yyyy hh:nn:ss', Now));
  obj.Add('lastid', tablo.SonID);
  obj.Add('recordcount', tablo.SatirSayisi);
  obj.Add('dependencies', TJSONArray.Create);
  obj.Add('schema', tablo.SchemaToJSON);
  Result := obj;
end;

function TVeritabaniPaket.GetTableDataJSON(const tableID: integer): string;
begin
  Result := FTablolar.Items[tableID].VerilerToJSON.AsJSON;
end;

procedure TVeritabaniPaket.WriteTableDataBlocks(dest: TStream);
var
  tableID: integer;
  table: TDBTablo;
  dataStr: string;
  dataLen: cardinal;
begin
  for tableID in FTablolar.Keys do
  begin
    table := FTablolar.Items[tableID];
    dataStr := table.VerilerToJSON.AsJSON;
    dataLen := Length(dataStr);

    // tableID → doğrudan yaz
    dest.WriteBuffer(tableID, SizeOf(cardinal));

    // veri boyutu
    dest.WriteBuffer(dataLen, 4);

    // JSON veri içeriği
    dest.WriteBuffer(dataStr[1], dataLen);
  end;
end;
end.
{

function TVeritabaniPaket.BuildPackageJSON: string;
var
  metaObj, tblObj: TJSONObject;
  tableArr: TJSONArray;
  tableID: string;
  table: TDBTablo;
begin
  metaObj := TJSONObject.Create;
  tableArr := TJSONArray.Create;

  for tableID in FTablolar.Keys do
  begin
    table := FTablolar.Items[tableID];
    tblObj := BuildTableJSON(tableID);
    tableArr.Add(tblObj);
  end;

  metaObj.Add('databasename', 'demo');
  metaObj.Add('createdate', FormatDateTime('dd.mm.yyyy', Date));
  metaObj.Add('tablecount', FTablolar.Count);
  metaObj.Add('crc', ''); // opsiyonel dışa aktarma için
  metaObj.Add('tables', tableArr);

  Result := metaObj.AsJSON;
  metaObj.Free;
end;

function TVeritabaniPaket.BuildTableJSON(const tableID: string): TJSONObject;
var
  obj: TJSONObject;
  tablo: TDBTablo;
begin
  tablo := FTablolar.Items[tableID];
  obj := TJSONObject.Create;
  obj.Add('tableid', tableID);
  obj.Add('name', tablo.TableName);
  obj.Add('version', '1.0');
  obj.Add('created', FormatDateTime('dd.mm.yyyy hh:nn:ss', Now));
  obj.Add('modified', FormatDateTime('dd.mm.yyyy hh:nn:ss', Now));
  obj.Add('lastid', tablo.SonID);
  obj.Add('recordcount', tablo.SatirSayisi);
  obj.Add('dependencies', TJSONArray.Create);
  obj.Add('schema', tablo.SchemaToJSON);
  Result := obj;
end;

function TVeritabaniPaket.GetTableDataJSON(const tableID: string): string;
begin
  Result := FTablolar.Items[tableID].VerilerToJSON.AsJSON;
end;
 procedure TVeritabaniPaket.WriteTableDataBlocks(dest: TStream);
var
  tableID: string;
  table: TDBTablo;
  dataStr: string;
  tidLen: Byte;
  dataLen: Cardinal;
begin
  for tableID in FTablolar.Keys do
  begin
    table := FTablolar.Items[tableID];
    dataStr := table.VerilerToJSON.AsJSON;

    tidLen := Length(tableID);
    dataLen := Length(dataStr);

    // tableID
    dest.WriteBuffer(tidLen, 1);
    dest.WriteBuffer(tableID[1], tidLen);

    // veri boyutu
    dest.WriteBuffer(dataLen, 4);

    // JSON veri içeriği
    dest.WriteBuffer(dataStr[1], dataLen);
  end;
end;
end.


 unit paket;

interface

uses
  Classes, SysUtils, fpjson, zstream, Generics.Collections, DateUtils,
  dbtype, dbtablo,Dialogs;

type
  TVeritabaniPaket = class
  private
    FVeritabaniAdi: string;
    FTablolar: specialize TDictionary<string, TDBTablo>;
    function BuildPackageJSON: string;
    function BuildTableJSON(const tableID: string): TJSONObject;
    function GetTableDataJSON(const tableID: string): string;
    procedure WriteTableDataBlocks(dest: TStream);
    procedure CreateTableFromMeta(tblMeta: TJSONObject);
    procedure AddRowsFromJSON(const tableID, dataStr: string);
    procedure SortTablesByDependencies(const tableArr:TJSONArray;out sortedList:
      specialize TList<TJSONObject>);
  public
    constructor Create;
    destructor Destroy; override;

    procedure SavePackageToFile(const fileName: string);
    procedure LoadPackageFromFile(const fileName: string);
    procedure LoadOnlyTable(const fileName, tableID: string);
    property Tablolar: specialize TDictionary<string, TDBTablo> read FTablolar;
  end;

implementation


{ CRC hesaplama }


function CalcCRC32(const Buffer; Len: Cardinal): Cardinal;
const
  Polynomial = $EDB88320;
var
  i, j: Integer;
  CRC: Cardinal;
  Table: array[0..255] of Cardinal;
  P: PByte;
begin
  for i := 0 to 255 do
  begin
    CRC := i;
    for j := 0 to 7 do
      if (CRC and 1) <> 0 then
        CRC := (CRC shr 1) xor Polynomial
      else
        CRC := CRC shr 1;
    Table[i] := CRC;
  end;

  CRC := $FFFFFFFF;
  P := @Buffer;
  for i := 0 to Len - 1 do
    CRC := (CRC shr 8) xor Table[(CRC xor P^) and $FF];
  Result := CRC xor $FFFFFFFF;
end;

{ Sıkıştırma }

procedure CompressStreamWithZStream(src, dest: TStream);
var
  compressor: TCompressionStream;
begin
  compressor := TCompressionStream.Create(clmax,dest);
  src.Position := 0;
  compressor.CopyFrom(src, src.Size);
  compressor.Free;
end;

procedure DecompressStreamWithZStream(src, dest: TStream);
var
  decompressor: TDecompressionStream;
begin
  decompressor := TDecompressionStream.Create(src);
  dest.CopyFrom(decompressor, 0);
  decompressor.Free;
end;

{ Sınıf }
 constructor TVeritabaniPaket.Create;
begin
  FTablolar := specialize TDictionary<string, TDBTablo>.Create;
end;

destructor TVeritabaniPaket.Destroy;
var
  tablo: TDBTablo;
begin
  for tablo in FTablolar.Values do
    tablo.Free;
  FTablolar.Free;
  inherited Destroy;
end;

procedure TVeritabaniPaket.SavePackageToFile(const fileName: string);
var
  rawStream, compressedStream: TMemoryStream;
  metaStr: string;
begin
  rawStream := TMemoryStream.Create;
  compressedStream := TMemoryStream.Create;
  try
    // Header
    rawStream.WriteBuffer('ODBX', 4);       // imza
    rawStream.WriteByte(1);                 // versiyon

    // Metadata JSON
    metaStr := BuildPackageJSON;
    rawStream.WriteDWord(Length(metaStr));  // metadata boyutu
    rawStream.WriteBuffer(metaStr[1], Length(metaStr)); // metadata içeriği

    // Veri blokları
    WriteTableDataBlocks(rawStream);       // her tabloyu JSON olarak stream'e göm

    // (Opsiyonel CRC hesaplama ve gömme işlemi buraya eklenebilir)

    // ZStream ile sıkıştır
    CompressStreamWithZStream(rawStream, compressedStream);

    // Dosyaya yaz
    compressedStream.SaveToFile(fileName);

     // 💾 Ek dışa aktarma: meta JSON'u ayrı dosyaya yaz
    with TStringList.Create do
    try
      Text := metaStr;
      SaveToFile(ChangeFileExt(fileName, '.json')); // demo.json olarak kaydeder
    finally
      Free;
    end;



  finally
    rawStream.Free;
    compressedStream.Free;
  end;
end;

procedure TVeritabaniPaket.SortTablesByDependencies(const tableArr: TJSONArray; out sortedList: specialize TList<TJSONObject>);
var
  visited: TStringList;

  procedure Visit(const tableID: string);
  var
    tbl: TJSONObject;
    depArr: TJSONArray;
    depID: string;
    i, j: Integer;
    js: TJSONData;
  begin
    if visited.IndexOf(tableID) <> -1 then Exit;
    visited.Add(tableID);

    // Tabloyu bul
    for i := 0 to tableArr.Count - 1 do
    begin
      js := tableArr.Items[i];
      if Assigned(js) and (js is TJSONObject) then
      begin
        tbl := TJSONObject(js);
        if SameText(tbl.Get('tableid', ''), tableID) then
        begin
          // 🔐 dependencies güvenli alınır
          if tbl.Find('dependencies') is TJSONArray then
            depArr := TJSONArray(tbl.Find('dependencies'))
          else
            depArr := TJSONArray.Create;

          // Bağımlılıkları gez
          for j := 0 to depArr.Count - 1 do
          begin
            depID := depArr.Strings[j];
            Visit(depID);
          end;

          // Sıralı listeye ekle
          sortedList.Add(tbl);
          Break;
        end;
      end;
    end;
  end;

var
  i: Integer;
  tblObj: TJSONObject;
  tableID: string;
begin
  visited := TStringList.Create;
  try
    for i := 0 to tableArr.Count - 1 do
    begin
      if Assigned(tableArr.Items[i]) and (tableArr.Items[i] is TJSONObject) then
      begin
        tblObj := TJSONObject(tableArr.Items[i]);
        tableID := tblObj.Get('tableid', '');
        if tableID <> '' then
          Visit(tableID);
      end;
    end;
  finally
    visited.Free;
  end;
end;

procedure TVeritabaniPaket.LoadPackageFromFile(const fileName: string);
var
  compressedStream, rawStream: TMemoryStream;
  sig: array[0..3] of Char;
  version: Byte;
  metaLen: Cardinal;
  metaStr: string;
  metaObj: TJSONObject;
  tableArr: TJSONArray;
  i: Integer;
  tbl: TJSONObject;
  tid: string;
  tidLen: Byte;
  dataLen: Cardinal;
  dataStr: string;

  sortedTables: specialize TList<TJSONObject>;


  js: TJSONData;

begin
  compressedStream := TMemoryStream.Create;
  rawStream := TMemoryStream.Create;
  try
    compressedStream.LoadFromFile(fileName);
    DecompressStreamWithZStream(compressedStream, rawStream);
    rawStream.Position := 0;

    // Paket başlığı ve versiyon
    rawStream.ReadBuffer(sig, 4);
    if string(sig) <> 'ODBX' then raise Exception.Create('Geçersiz paket: İmza uyuşmuyor');
    version := rawStream.ReadByte;
    if version <> 1 then raise Exception.Create('Versiyon uyumsuz: ' + IntToStr(version));

    // Metadata
    rawStream.ReadBuffer(metaLen, 4);
    SetLength(metaStr, metaLen);
    rawStream.ReadBuffer(metaStr[1], metaLen);
    metaObj := GetJSON(metaStr) as TJSONObject;

    // Tabloları sırala ve kur
    tableArr := metaObj.Arrays['tables'];

   // SortTablesByDependencies(tableArr);

  sortedTables := specialize TList<TJSONObject>.Create;
  try
    SortTablesByDependencies(tableArr, sortedTables);
    for i := 0 to sortedTables.Count - 1 do
      CreateTableFromMeta(sortedTables[i]); // Artık sıralı kurulmuş olur
  finally
    sortedTables.Free;
  end;






   // for i := 0 to tableArr.Count - 1 do
  //showmessage('Tablo ID: ' + TJSONObject(tableArr.Items[i]).Get('tableid', 'YOK'));

  //  showmessage(inttostr(tableArr.Count));
    WriteLn('--- Stream blogu basliyor ---');

    for i := 0 to tableArr.Count - 1 do
    begin
   { if Assigned(tableArr.Items[i]) and (tableArr.Items[i].JSONType = jtObject) then
      begin
        tbl := tableArr.Objects[i]; // güvenli cast
        CreateTableFromMeta(tbl);
      end
      else
        raise Exception.Create('Tablo metası bozuk: index ' + IntToStr(i));
     }
       tbl := TJSONObject(tableArr.Items[i]);
      CreateTableFromMeta(tbl); // 🔐 FTablolar'a eklenmeli

      // Veri bloğunu oku
      rawStream.ReadBuffer(tidLen, 1);
      WriteLn('  [' + IntToStr(i) + '] tidLen = ', tidLen);

      SetLength(tid, tidLen);
      rawStream.ReadBuffer(tid[1], tidLen);
      WriteLn('  [' + IntToStr(i) + '] tableID = ', tid);

      rawStream.ReadBuffer(dataLen, 4);
      WriteLn('  [' + IntToStr(i) + '] dataLen = ', dataLen);

      SetLength(dataStr, dataLen);
      rawStream.ReadBuffer(dataStr[1], dataLen);
      WriteLn('  [' + IntToStr(i) + '] Veri okundu, uzunluğu = ', Length(dataStr));

      try
        WriteLn('  [' + IntToStr(i) + '] JSON satır sayısı: ', (GetJSON(dataStr) as TJSONArray).Count);
      except
        on E: Exception do
          WriteLn('  [' + IntToStr(i) + '] JSON parse hatası: ', E.Message);
      end;

      AddRowsFromJSON(tid, dataStr);
    end;
  finally
    compressedStream.Free;
    rawStream.Free;
  end;
end;

procedure TVeritabaniPaket.LoadOnlyTable(const fileName, tableID: string);
var
  compressedStream, rawStream: TMemoryStream;
  sig: array[0..3] of Char;
  version: Byte;
  metaLen: Cardinal;
  metaStr, foundID, dataStr: string;
  metaObj, tblMeta: TJSONObject;
  tableArr: TJSONArray;
  i, idLen: Integer;
  dataLen: Cardinal;
begin
  compressedStream := TMemoryStream.Create;
  rawStream := TMemoryStream.Create;
  try
    compressedStream.LoadFromFile(fileName);
    DecompressStreamWithZStream(compressedStream, rawStream);
    rawStream.Position := 0;

    // Paket başlığı
    rawStream.ReadBuffer(sig, 4);
    if string(sig) <> 'ODBX' then raise Exception.Create('Geçersiz dosya: imza uyuşmuyor');
    version := rawStream.ReadByte;
    if version <> 1 then raise Exception.Create('Versiyon uyuşmazlığı: ' + IntToStr(version));

    // Metadata okuma
    rawStream.ReadBuffer(metaLen, 4);
    SetLength(metaStr, metaLen);
    rawStream.ReadBuffer(metaStr[1], metaLen);
    metaObj := GetJSON(metaStr) as TJSONObject;

    tableArr := metaObj.Arrays['tables'];

    // Aranan tabloyu bul ve nesnesini oluştur
    for i := 0 to tableArr.Count - 1 do
    begin
      if Assigned(tableArr.Items[i]) and (tableArr.Items[i].JSONType = jtObject) then
      begin
        tblMeta := TJSONObject(tableArr.Items[i]);
        if tblMeta.Get('tableid', '') = tableID then
        begin
          CreateTableFromMeta(tblMeta);
          Break;
        end;
      end;
    end;

    // Stream üzerinden veri bloğunu sırayla kontrol et
    for i := 0 to tableArr.Count - 1 do
    begin
      rawStream.ReadBuffer(idLen, 1);
      SetLength(foundID, idLen);
      rawStream.ReadBuffer(foundID[1], idLen);

      rawStream.ReadBuffer(dataLen, 4);
      SetLength(dataStr, dataLen);
      rawStream.ReadBuffer(dataStr[1], dataLen);

      if SameText(foundID, tableID) then
      begin
        AddRowsFromJSON(tableID, dataStr);
        Break;
      end;
    end;
  finally
    compressedStream.Free;
    rawStream.Free;
  end;
end;

procedure TVeritabaniPaket.CreateTableFromMeta(tblMeta: TJSONObject);
var
  tablo: TDBTablo;
  alanlar: specialize TList<TAlanTanimi>;
  i: Integer;
  tableID, tableName: string;
begin
  tableID := tblMeta.Get('tableid', '');
  tableName := tblMeta.Get('name', '');

  // Tablo nesnesi oluştur
  tablo := TDBTablo.Create(tableID, tableName);

  // Schema dizisini oku ve alanları tabloya ekle
  alanlar := JSONArrayToAlanList(tblMeta.Arrays['schema']);
  for i := 0 to alanlar.Count - 1 do
    tablo.AlanEkle(alanlar[i]);

  // Tabloyu paket sözlüğüne ekle
  FTablolar.Add(tableID, tablo);
  writeln('TABLOID=  ',tableID, '   ADI = ',tableName);
end;

procedure TVeritabaniPaket.AddRowsFromJSON(const tableID, dataStr: string);
var
  arr: TJSONArray;
  i, j: Integer;
  veri: TKayit;
  obj: TJSONObject;
  keyi: string;
begin
  arr := GetJSON(dataStr) as TJSONArray;
  for i := 0 to arr.Count - 1 do
  begin
    obj := arr.Objects[i];
    veri := TKayit.Create;

    for j := 0 to obj.Count - 1 do
    begin
      keyi := obj.Names[j];
      veri.Add(keyi, obj.Get(keyi, ''));
    end;

    FTablolar.Items[tableID].KayitEkle(veri);
  end;
end;

function TVeritabaniPaket.BuildPackageJSON: string;
var
  metaObj, tblObj: TJSONObject;
  tableArr: TJSONArray;
  tableID: string;
  table: TDBTablo;
begin
  metaObj := TJSONObject.Create;
  tableArr := TJSONArray.Create;

  for tableID in FTablolar.Keys do
  begin
    table := FTablolar.Items[tableID];
    tblObj := BuildTableJSON(tableID);
    tableArr.Add(tblObj);
  end;

  metaObj.Add('databasename', 'demo');
  metaObj.Add('createdate', FormatDateTime('dd.mm.yyyy', Date));
  metaObj.Add('tablecount', FTablolar.Count);
  metaObj.Add('crc', ''); // şimdilik boş
  metaObj.Add('tables', tableArr);

  Result := metaObj.AsJSON;
  metaObj.Free;
end;

function TVeritabaniPaket.BuildTableJSON(const tableID: string): TJSONObject;
var
  obj: TJSONObject;
  tablo: TDBTablo;
begin
  tablo := FTablolar.Items[tableID];

  obj := TJSONObject.Create;
  obj.Add('tableid', tableID);
  obj.Add('name', tablo.TableName);
  obj.Add('version', '1.0');
  obj.Add('created', FormatDateTime('dd.mm.yyyy hh:nn:ss', Now));
  obj.Add('modified', FormatDateTime('dd.mm.yyyy hh:nn:ss', Now));
  obj.Add('lastid', tablo.SonID);
  obj.Add('recordcount', tablo.SatirSayisi);
  obj.Add('dependencies', TJSONArray.Create);
  obj.Add('schema', tablo.SchemaToJSON);

  Result := obj;
end;
function TVeritabaniPaket.GetTableDataJSON(const tableID: string): string;
begin
  Result := FTablolar.Items[tableID].VerilerToJSON.AsJSON;
end;

procedure TVeritabaniPaket.WriteTableDataBlocks(dest: TStream);
var
  tableID: string;
  table: TDBTablo;
  dataStr: string;
  tidLen: Byte;
  dataLen: Cardinal;
begin
  for tableID in FTablolar.Keys do
  begin
    table := FTablolar.Items[tableID];
    dataStr := table.VerilerToJSON.AsJSON;

    tidLen := Length(tableID);
    dataLen := Length(dataStr);

    // tableID
    dest.WriteBuffer(tidLen, 1);
    dest.WriteBuffer(tableID[1], tidLen);

    // veri boyutu ve içerik
    dest.WriteBuffer(dataLen, 4);
    dest.WriteBuffer(dataStr[1], dataLen);
  end;
end;

end.}

{
function TVeritabaniPaket.BuildTableJSON(const tableID: string): TJSONObject;
var
  obj: TJSONObject;
  schemaArray, depsArray: TJSONArray;
  alanlar: TAlanTuru;
  i: Integer;
begin
  obj := TJSONObject.Create;
  obj.Strings['tableid'] := tableID;
  obj.Strings['uid'] := GetTabloUID(tableID);
  obj.Strings['name'] := GetTabloIsmi(tableID);
  obj.Strings['version'] := '1.0';
  obj.Strings['created'] := GetOlusturmaZamani(tableID);
  obj.Strings['modified'] := GetGuncellemeZamani(tableID);
  obj.Integers['lastid'] := GetSonID(tableID);
  obj.Integers['recordcount'] := GetKayitSayisi(tableID);

  // dependencies
  depsArray := TJSONArray.Create;
  for i := 0 to GetDependencyCount(tableID) - 1 do
    depsArray.Add(GetDependency(tableID, i));
  obj.Arrays['dependencies'] := depsArray;

  // schema
  alanlar := GetAlanlar(tableID);
  schemaArray := TJSONArray.Create;
  for i := 0 to alanlar.Count - 1 do
    schemaArray.Add(FieldToJSONObject(alanlar[i]));
  obj.Arrays['schema'] := schemaArray;

  Result := obj;
end;

procedure TVeritabaniPaket.CreateTableFromMeta(tblMeta: TJSONObject);
var
  schemaArr: TJSONArray;
  tableID, tabloAdi: string;
  alan: TJSONObject;
  i: Integer;
begin
  tableID := tblMeta.Strings['tableid'];
  tabloAdi := tblMeta.Strings['name'];
  CreateEmptyTable(tableID, tabloAdi);

  schemaArr := tblMeta.Arrays['schema'];
  for i := 0 to schemaArr.Count - 1 do
  begin
    alan := schemaArr.Objects[i];
    AddFieldToTable(tableID, alan); // bu fonksiyon JSON'dan field yaratır
  end;

  SetTabloUID(tableID, tblMeta.Strings['uid']);
  SetSonID(tableID, tblMeta.Integers['lastid']);
end;


procedure TVeritabaniPaket.AddRowsFromJSON(const tableID, dataStr: string);
var
  dataArr: TJSONArray;
  i: Integer;
begin
  dataArr := GetJSON(dataStr) as TJSONArray;
  for i := 0 to dataArr.Count - 1 do
    AddRowToTable(tableID, dataArr.Objects[i]); // JSON objeyi tabloya ekler
  dataArr.Free;
end;
}
// Diğer JSON üretme, tablo oluşturma, veri ekleme işlevleri burada...



