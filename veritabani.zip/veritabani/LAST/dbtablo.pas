unit dbtablo;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, dbtype, fpjson, jsonparser, Generics.Collections,Generics.Defaults;

type
  TKayit = specialize TDictionary<string, Variant>;      // her satır bir sözlük: alan adı → değer

  TKayitList = specialize TObjectList<TKayit>;           // tablo içindeki tüm kayıtlar

 TKayitL =class (TKayit)
 private
 public
 function GetValue(const Key: string): Variant;
 end;

  TDBTablo = class
  private
    FTableID: string;
    FTableName: string;
    FSchema : specialize TList<TAlanTanimi>;         // alan tanımı listesi
    FVeriler: TKayitList;                // kayıtlar
    FSonID: Integer;                     // otomatik artan ID


    function GetAlanByName(const alanAd: string): TAlanTanimi;

    function UygunDegerMi(const alan: TAlanTanimi; const deger: Variant): Boolean;
  public
    constructor Create(const AID:integer;AName: string);
    destructor Destroy; override;

    procedure AlanEkle(const Alan: TAlanTanimi);
    procedure KayitEkleListesi(const Liste: specialize TList<TKayit>);
    procedure BatchInsert(const Liste:specialize TList<TKayit>;Validate:Boolean);
    function KopyalaVeriler: specialize TList<TKayit>;
    function KayitEkle(const veri: TKayit): Boolean;
    procedure KayitSil(const satirNo: Integer);
    function KayitGetir(const satirNo: Integer): TKayit;
    procedure KayitGuncelle(const satirNo: Integer; const veri: TKayit);
    function KayitAraListe(const alanAdi, arananDeger: string): specialize TArray<string>;
    function KayitAraListeKosullu(const Kosullar:specialize TDictionary<string,
      Variant>;const SiralamaAlan:string='';const Artan:Boolean=True):
      specialize TArray<string>;
    function SatirSayisi: Integer;
    function AlanSayisi: Integer;
    function AlanGetir(index: Integer): TAlanTanimi;

    procedure Temizle;

    function SchemaToJSON: TJSONArray;
    function VerilerToJSON: TJSONArray;

    property TableID: string read FTableID;
    property TableName: string read FTableName write FTableName;
    property SonID: Integer read FSonID;
  end;
  type
  TKayitComparer = class(specialize TComparer<TKayit>)//TInterfacedObject, specialize IComparer<TKayit>)
  private
    FSiralamaAlan: string;
    FArtan: Boolean;
  public
    constructor Create(const Alan: string; const ArtanSira: Boolean);
    function Compare(const Left, Right: TKayit): Integer;
  end;




implementation
 uses Variants;




function TKayitL.GetValue(const Key: string): Variant;
begin
  if Self.ContainsKey(Key) then
    Result := Self[Key]
  else
    Result := Null; // Veya Default değer
end;


constructor TKayitComparer.Create(const Alan: string; const ArtanSira: Boolean);
begin
  FSiralamaAlan := Alan;
  FArtan := ArtanSira;
end;

function TKayitComparer.Compare(const Left, Right: TKayit): Integer;
var
  va, vb: string;
begin
  va := VarToStr(Left.Items[FSiralamaAlan]);
  vb := VarToStr(Right.Items[FSiralamaAlan]);

  if FArtan then
    Result := CompareStr(va, vb)
  else
    Result := CompareStr(vb, va);
end;

constructor TDBTablo.Create(const AID:integer; AName: string);
begin
  FTableID := inttostr(AID);
  FTableName := AName;
  FSchema := specialize TList<TAlanTanimi>.Create;
  FVeriler := TKayitList.Create;
  FSonID := 0;
end;

destructor TDBTablo.Destroy;
begin
  FSchema.Free;
  FVeriler.Free;
  inherited Destroy;
end;

procedure TDBTablo.AlanEkle(const Alan: TAlanTanimi);
var
  temiz: TAlanTanimi;
begin
  temiz := Alan;
  normalizealan(temiz);
  FSchema.Add(temiz);
end;

function TDBTablo.KayitGetir(const satirNo: Integer): TKayit;
begin
  if (satirNo >= 0) and (satirNo < FVeriler.Count) then
    Result := FVeriler[satirNo]
  else
    Result := nil;
end;
function TDBTablo.AlanGetir(index:Integer):TAlanTanimi;
begin
  Result := FSchema[index];

end;

function TDBTablo.SatirSayisi: Integer;
begin
  Result := FVeriler.Count;
end;

function TDBTablo.AlanSayisi: Integer;
begin
  Result := FSchema.Count;
end;

function TDBTablo.GetAlanByName(const alanAd: string): TAlanTanimi;
var
  i: Integer;
begin
  for i := 0 to FSchema.Count - 1 do
  begin
    if SameText(FSchema[i].Name, alanAd) then
      Exit(FSchema[i]);
  end;
  raise Exception.Create('Alan bulunamadı: ' + alanAd);
end;

function TDBTablo.UygunDegerMi(const alan: TAlanTanimi; const deger: Variant): Boolean;
var
  tmpFloat: Double;
  tmpInt: Integer;
begin
  Result := True;

  try
    case alan.Tip of
      oeInteger:
        begin
          Result := TryStrToInt(VarToStr(deger), tmpInt);
         // if not Result then    WriteLn('⛔ Sayı değil (Integer): ', VarToStr(deger));
        end;

      oeFloat, oeDouble, oeCurrency:
        begin
          Result := TryStrToFloat(VarToStr(deger), tmpFloat);
         // if not Result then WriteLn('⛔ Sayıya çevrilemedi (Float): ', VarToStr(deger));
        end;

      oeBoolean:
        begin
          Result := SameText(VarToStr(deger), 'true') or SameText(VarToStr(deger), 'false') or (VarType(deger) = varBoolean);
       //   if not Result then  WriteLn('⛔ Gerçek Boolean değil: ', VarToStr(deger));
        end;

      oeChar, oeText:
        begin
          if not VarIsStr(deger) then
          begin
        //    WriteLn('⛔ Tip metin değil: ', VarType(deger));
            Result := False;
            Exit;
          end;

          if Length(VarToStr(deger)) > alan.Length then
          begin
         //   WriteLn('⛔ Metin uzunluğu aşıldı: ', alan.Name, ' → Girilen=', Length(VarToStr(deger)), ' | Sınır=', alan.Length);
            Result := False;
          end;
        end;

      oeDate, oeTime, oeTimestamp:
        begin
          Result := TryStrToFloat(VarToStr(deger), tmpFloat); // TDateTime da aslında Float
         // if not Result then WriteLn('⛔ Tarih/Saat geçersiz: ', VarToStr(deger));
        end;

      else
        begin
       //   WriteLn('⚠️ Tip kontrolü yapılmadı (Serbest tip): ', VarType(deger));
          Result := True;
        end;
    end;
  except
    on E: Exception do
    begin
    //  WriteLn('💥 Tip analizi istisnası: ', E.Message);
      Result := False;
    end;
  end;
end;



function TDBTablo.KopyalaVeriler: specialize TList<TKayit>;
var
  i: Integer;
  yeni: TKayit;
  liste:specialize  TList<TKayit>;
begin
  liste :=specialize  TList<TKayit>.Create;
  for i := 0 to FVeriler.Count - 1 do
  begin
    yeni := TKayit.Create;

    // Derin kopyalama: her alanı teker teker ekle
    for var key in FVeriler[i].Keys do
      yeni.Add(key, FVeriler[i][key]);

    liste.Add(yeni);
  end;
  Result := liste;
end;

procedure TDBTablo.BatchInsert(const Liste: specialize TList<TKayit>; Validate: Boolean);
var
  i: Integer;
begin
  for i := 0 to Liste.Count - 1 do
  begin
    if Validate then
      KayitEkle(Liste[i])
    else
      FVeriler.Add(Liste[i]); // doğrudan ekle
  end;
end;

procedure TDBTablo.KayitEkleListesi(const Liste: specialize TList<TKayit>);
var
  i: Integer;
begin
  for i := 0 to Liste.Count - 1 do
    KayitEkle(Liste[i]);
end;


 function TDBTablo.KayitEkle(const veri: TKayit): Boolean;
var
  i: Integer;
  alan: TAlanTanimi;
  k,key: string;
  yeniSatir: TKayit;
  deger: Variant;
begin
  Result := False;
  try
    for i := 0 to FSchema.Count - 1 do
    begin
      alan := FSchema[i];
      key := alan.Name;

      if veri.ContainsKey(key) and not isAutoIncrement(alan) then
      begin
        deger := veri.Items[key];

        if not UygunDegerMi(alan, deger) then
          Exit(False);
      end
      else if not isAutoIncrement(alan) then
      begin
        if alan.NotNull and (VarIsNull(alan.DefaultDeger) or (alan.DefaultDeger = '')) then
          Exit(False);
      end;
    end;

    Inc(FSonID);
    yeniSatir := TKayit.Create;
    for i := 0 to FSchema.Count - 1 do
    begin
      alan := FSchema[i];
      key := alan.Name;

      if isAutoIncrement(alan) then
        yeniSatir.AddOrSetValue(key, FSonID)
      else if veri.ContainsKey(key) then
        yeniSatir.AddOrSetValue(key, veri.Items[key])
      else
        yeniSatir.AddOrSetValue(key, alan.DefaultDeger);
    end;

    FVeriler.Add(yeniSatir);
    Result := True;
  except
    on E: Exception do
    begin
    //  WriteLn('💥 KayitEkle hatası: ', E.Message);
      Result := False;
    end;
  end;
end;



procedure TDBTablo.KayitSil(const satirNo: Integer);
begin
  if (satirNo >= 0) and (satirNo < FVeriler.Count) then
  begin
//    WriteLn('🗑️ Satir siliniyor: ', satirNo);
    FVeriler.Delete(satirNo);
  end
  else
    WriteLn('⚠️ Silme basarisiz: Gecersiz satirNo → ', satirNo);
end;

procedure TDBTablo.KayitGuncelle(const satirNo: Integer; const veri: TKayit);
var
  alan: TAlanTanimi;
  deger: Variant;
  i: Integer;
begin
  if (satirNo < 0) or (satirNo >= FVeriler.Count) then Exit;

  for i := 0 to FSchema.Count - 1 do
  begin
    alan := FSchema[i];

    if not isAutoIncrement(alan) and veri.ContainsKey(alan.Name) then
    begin
      deger := veri.Items[alan.Name];
      if UygunDegerMi(alan, deger) then
        FVeriler[satirNo].AddOrSetValue(alan.Name, deger);
    end;
  end;
end;


procedure TDBTablo.Temizle;
begin
  FVeriler.Clear;
  FSonID := 0;
end;

function TDBTablo.VerilerToJSON: TJSONArray;
var
  i: Integer;
  satir: TKayit;
  obj: TJSONObject;
  key: string;
begin
  Result := TJSONArray.Create;
  for i := 0 to FVeriler.Count - 1 do
  begin
    satir := FVeriler[i];
    obj := TJSONObject.Create;

    for key in satir.Keys do
      obj.Add(key, VarToStr(satir.Items[key]));

    Result.Add(obj);
  end;
end;

function TDBTablo.SchemaToJSON: TJSONArray;
var
  i: Integer;
begin
  Result := TJSONArray.Create;
  for i := 0 to FSchema.Count - 1 do
    Result.Add(AlanTanimindanJSON(FSchema[i]));
end;



function TDBTablo.KayitAraListe(const alanAdi, arananDeger: string): specialize TArray<string>;
var
  i, say: Integer;
  kayit: TKayit;
  satirStr: string;
  key:String;
begin
  say := 0;
  SetLength(Result, 0);

  for i := 0 to SatirSayisi - 1 do
  begin
    kayit := KayitGetir(i);
    if kayit.ContainsKey(alanAdi) and (VarToStr(kayit.Items[alanAdi]) = arananDeger) then
    begin
      satirStr := '';
      for key in kayit.Keys do
        satirStr := satirStr + key + '=' + VarToStr(kayit.Items[key]) + ' | ';

      Inc(say);
      SetLength(Result, say);
      Result[say - 1] := satirStr;
    end;
  end;
end;





function TDBTablo.KayitAraListeKosullu(const Kosullar: specialize TDictionary<string, Variant>; const SiralamaAlan: string = ''; const Artan: Boolean = True): specialize TArray<string>;
var
  GeciciListe: specialize TList<TKayit>;
  i, j: Integer;
  kayit: TKayit;
  satirStr, key: string;
  uyumlu:Boolean;
begin
  GeciciListe := specialize TList<TKayit>.Create;

  try
    for i := 0 to SatirSayisi - 1 do
    begin
      kayit := KayitGetir(i);
      if Assigned(kayit) then
      begin
        uyumlu := True;
        for key in Kosullar.Keys do
        begin
          if not kayit.ContainsKey(key) or (VarToStr(kayit.Items[key]) <> VarToStr(Kosullar.Items[key])) then
          begin
            uyumlu := False;
            Break;
          end;
        end;

        if uyumlu then
          GeciciListe.Add(kayit);
      end;
    end;

    // Sıralama
    if (SiralamaAlan <> '') then
    GeciciListe.Sort(TKayitComparer.Create(SiralamaAlan, Artan));

    // Diziye aktar
    SetLength(Result, GeciciListe.Count);
    for j := 0 to GeciciListe.Count - 1 do
    begin
      satirStr := '';
      for key in GeciciListe[j].Keys do
        satirStr := satirStr + key + '=' + VarToStr(GeciciListe[j].Items[key]) + ' | ';

      Result[j] := satirStr;
    end;
  finally
    GeciciListe.Free;
  end;
end;

end.

