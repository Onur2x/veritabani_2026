unit dbtype;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils,Variants,Generics.Collections, fpjson, jsonparser;
 type
   TAlanTuru = (oeAutoIncrement, oeChar, oeText, oeInteger,
    oeFloat, oeDouble, oeCurrency, oeBoolean,
    oeDate, oeTime, oeTimestamp, oeUUID,
    oeList, oeJSON, oeBlob, oeFile, oeImage,
    oePhone, oeNull, oeUnknown);

  TAlanTanimi = record
    Name: string;
    Tip: TAlanTuru;
    NotNull: boolean;
    PrimaryKey: boolean;
 //   AutoIncrement: boolean;
    Unique: boolean;
    DefaultDeger: variant;
    ForeignKey: string;   // "yazarlar.id"
    Check: string;
    Comment: string;
    Length: integer;  // TEXT, CHAR için
    Index: boolean;
    TakmaAd: string;   // alias
  end;


//  TAlanList = specialize TObjectList<TAlanTanimi>;


function alantanimindanjson(a:TAlanTanimi): TJSONObject;
function alantanimijsondan(obj: TJSONObject): TAlanTanimi;
function strtoalanturu(const s: string): TAlanTuru;
function alanturutostr(Tur: TAlanTuru): string;
function alanboyutu(const Alan: TAlanTanimi): Integer;
function isautoincrement(const Alan: TAlanTanimi): Boolean;
procedure normalizealan(var Alan: TAlanTanimi);
function jsonarraytoalanlist(arr: TJSONArray): specialize TList<TAlanTanimi>;
function alanListtojsonarray( lst: specialize TList<TAlanTanimi>): TJSONArray;
function GetJSONIntSafe(const obj: TJSONObject; const key: string; default: Integer): Integer;
function strtovariant(const S: string): Variant;
implementation

function isautoincrement(const Alan: TAlanTanimi): Boolean;
begin
  Result := (Alan.Tip = oeAutoIncrement);
end;


function strtovariant(const S: string): Variant;
var
  V: Double;
begin
  // Sayıysa → sayıya çevir
  if TryStrToFloat(S, V) then
    Result := V
  else if SameText(S, 'true') then
    Result := True
  else if SameText(S, 'false') then
    Result := False
  else if S = '' then
    Result := Null
  else
    Result := S; // metin
end;

function alanboyutu(const Alan: TAlanTanimi): Integer;
begin
  // Eğer uzunluk (Length) tanımlıysa doğrudan onu kullan
  if Alan.Length > 0 then
    Exit(Alan.Length);

  // Yoksa tip üzerinden varsayılan boyutu ver
  case Alan.Tip of
    oeAutoIncrement, oeInteger: Result := SizeOf(Integer);     // 4
    oeFloat, oeCurrency, oeDouble: Result := SizeOf(Double);   // 8
    oeBoolean: Result := SizeOf(Boolean);                      // 1
    oeChar: Result := 1;
    oeText: Result := 255;
    oeDate, oeTime, oeTimestamp: Result := SizeOf(TDateTime);  // 8
    oeUUID: Result := 16;
    oePhone: Result := 20;

    // Dinamik türler için boyut belirsiz
    oeList, oeJSON, oeBlob, oeFile, oeImage,
    oeNull, oeUnknown: Result := 0;

    else Result := 0;
  end;
end;
function alanturutostr(Tur: TAlanTuru): string;
begin
  case Tur of
    oeAutoIncrement: Result := 'AutoIncrement';
    oeText: Result := 'Text';
    oeChar: Result := 'Char';
    oeInteger: Result := 'Integer';
    oeFloat: Result := 'Float';
    oeDouble: Result := 'Double';
    oeCurrency: Result := 'Currency';
    oeBoolean: Result := 'Boolean';
    oeDate: Result := 'Date';
    oeTime: Result := 'Time';
    oeTimestamp: Result := 'Timestamp';
    oeUUID: Result := 'UUID';
    oeList: Result := 'List';
    oeJSON: Result := 'JSON';
    oeBlob: Result := 'Blob';
    oeFile: Result := 'File';
    oeImage: Result := 'Image';
    oePhone: Result := 'Phone';
    oeNull: Result := 'Null';
    oeUnknown: Result := 'Unknown';
  end;
end;

function strtoalanturu(const s: string): TAlanTuru;
begin
  if SameText(s, 'oeAutoIncrement') or SameText(s, 'AutoIncrement') then
    Exit(oeAutoIncrement)
  else if SameText(s, 'oeText') or SameText(s, 'Text') then
    Exit(oeText)
  else if SameText(s, 'oeChar') or SameText(s, 'Char') then
    Exit(oeChar)
  else if SameText(s, 'oeInteger') or SameText(s, 'Integer') then
    Exit(oeInteger)
  else if SameText(s, 'oeFloat') or SameText(s, 'Float') then
    Exit(oeFloat)
  else if SameText(s, 'oedouble') or SameText(s, 'Double') then
    Exit(oeDouble)
  else if SameText(s, 'oeCurrency') or SameText(s, 'Currency') then
    Exit(oeCurrency)
  else if SameText(s, 'oeBoolean') or SameText(s, 'Boolean') then
    Exit(oeBoolean)
  else if SameText(s, 'oeDate') or SameText(s, 'Date') then
    Exit(oeDate)
  else if SameText(s, 'oeTime') or SameText(s, 'Time') then
    Exit(oeTime)
  else if SameText(s, 'oeTimestamp') or SameText(s, 'Timestamp') then
    Exit(oeTimestamp)
  else if SameText(s, 'oeUUID') or SameText(s, 'UUID') then
    Exit(oeUUID)
  else if SameText(s, 'oeList') or SameText(s, 'List') then
    Exit(oeList)
  else if SameText(s, 'oeJSON') or SameText(s, 'JSON') then
    Exit(oeJSON)
  else if SameText(s, 'oeBlob') or SameText(s, 'Blob') then
    Exit(oeBlob)
  else if SameText(s, 'oeFile') or SameText(s, 'File') then
    Exit(oeFile)
  else if SameText(s, 'oeImage') or SameText(s, 'Image') then
    Exit(oeImage)
  else if SameText(s, 'oePhone') or SameText(s, 'Phone') then
    Exit(oePhone)
  else if SameText(s, 'oeNull') or SameText(s, 'Null') then
    Exit(oeNull)
  else if SameText(s, 'oeUnknown') or SameText(s, 'Unknown') then
    Exit(oeUnknown)
  else
    // raise Exception.Create('Unknown field type: ' + s);
    raise Exception.Create('Bilinmeyen alan turu: ' + s);

end;


procedure normalizealan(var Alan: TAlanTanimi);
begin
  if Alan.Tip = oeAutoIncrement then
  begin
    Alan.PrimaryKey := True;
    Alan.NotNull := True;
    Alan.DefaultDeger := '';
  end;

  if alan.Tip in [oeText, oeChar] then
  begin
    alan.PrimaryKey := False;
    alan.Unique := False;
  end;

  if Alan.Length = 0 then
    Alan.Length := AlanBoyutu(Alan);

 if Alan.NotNull and VarIsNull(Alan.DefaultDeger) then
begin
  //WriteLn('⛔ Zorunlu alan için default değer belirtilmemiş: ', Alan.Name);
  // Gerekirse otomatik değer ver:
  case Alan.Tip of
    oeText: Alan.DefaultDeger := 'none';
    oeInteger: Alan.DefaultDeger := 0;
    oeBoolean: Alan.DefaultDeger := False;
  end;
end;

end;

function GetJSONIntSafe(const obj: TJSONObject; const key: string; default: Integer): Integer;
begin
  if obj.IndexOfName(key) >= 0 then
    Result := obj.Integers[key]
  else
    Result := default;
end;

function alantanimindanjson(a:TAlanTanimi): TJSONObject;
begin
  Result := TJSONObject.Create;
 // with a do
 // begin
    Result.Add('name', a.Name);
    Result.Add('type',AlanTuruToStr(a.tip));
    Result.Add('length', a.Length);
    Result.Add('primarykey', a.PrimaryKey);
//    Result.Add('autoIncrement', AutoIncrement);
    Result.Add('notnull', a.NotNull);
    Result.Add('unique', a.Unique);
  //  Result.Add('default', VarToStr(DefaultDeger));
    Result.Add('foreignKey', a.ForeignKey);
    Result.Add('check', a.Check);
    Result.Add('comment', a.Comment);
    Result.Add('index', a.Index);
    Result.Add('takmaad', a.TakmaAd);

    case VarType(a.DefaultDeger) of
      varBoolean: Result.Add('default', Boolean(a.DefaultDeger));
      varDouble, varCurrency: Result.Add('default', FloatToStr(a.DefaultDeger));
      varInteger, varInt64: Result.Add('default', IntToStr(a.DefaultDeger));
      else Result.Add('default', VarToStr(a.DefaultDeger));
    end;


  //end;
end;


function alantanimijsondan(obj: TJSONObject): TAlanTanimi;
begin
  Result.Name          := obj.Get('name', '');
  Result.tip           := strtoalanturu(obj.Get('type', ''));
  Result.Length        := GetJSONIntSafe(obj, 'length', 0); //obj.Get('length', 0);
  Result.PrimaryKey    := obj.Get('primaryKey', False);
//  Result.AutoIncrement := obj.Get('autoIncrement', False);
  Result.NotNull       := obj.Get('notnull', False);
  Result.Unique        := obj.Get('unique', False);
  Result.DefaultDeger  := strtovariant(obj.Get('default', ''));
  Result.ForeignKey    := obj.Get('foreignKey', '');
  Result.Check         := obj.Get('check', '');
  Result.Comment       := obj.Get('comment', '');
  Result.Index         := obj.Get('index', False);
  Result.TakmaAd       := obj.Get('takmaad', '');

  NormalizeAlan(Result);
end;


function jsonarraytoalanlist(arr: TJSONArray): specialize TList<TAlanTanimi>;
var
  i: Integer;
  alan: TAlanTanimi;
  obj: TJSONObject;
begin
  Result := specialize TList<TAlanTanimi>.Create;
  for i := 0 to arr.Count - 1 do
  begin
    obj := arr.Objects[i];
    alan := alantanimijsondan(obj); // senin fonksiyonun
    Result.Add(alan);
  end;
end;

function alanListtojsonarray(lst: specialize TList<TAlanTanimi>): TJSONArray;
var
  i: Integer;
begin
  Result := TJSONArray.Create;
  for i := 0 to lst.Count - 1 do
    Result.Add(AlanTanimindanJSON(lst[i])); // senin fonksiyonun
end;
end.

