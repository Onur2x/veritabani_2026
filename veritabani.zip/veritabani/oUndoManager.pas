unit oUndoManager;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, Generics.Collections,
  oTypes, oVeritabani;

type
  TChangeType = (ctInsert, ctDelete, ctUpdate);

  TRowChange = record
    ChangeType: TChangeType;
    TableName: string;
    RowBefore: TRow;
    RowAfter: TRow;
  end;

  TUndoManager = class
  private
    FUndoStack: specialize TStack<TRowChange>;
    FRedoStack: specialize TStack<TRowChange>;
    FVeri: TVeritabani;
    FDatabaseName: string;
  public
    constructor Create(Veritabani: TVeritabani; const DBName: string);
    destructor Destroy; override;

    procedure RecordChange(Change: TRowChange);
    procedure Undo;
    procedure Redo;

    procedure Clear;
    function CanUndo: boolean;
    function CanRedo: boolean;
  end;

implementation

{ TUndoManager }

constructor TUndoManager.Create(Veritabani: TVeritabani; const DBName: string);
begin
  inherited Create;
  FVeri := Veritabani;
  FDatabaseName := DBName;
  FUndoStack := specialize TStack<TRowChange>.Create;
  FRedoStack := specialize TStack<TRowChange>.Create;
end;

destructor TUndoManager.Destroy;
begin
  FUndoStack.Free;
  FRedoStack.Free;
  inherited;
end;

procedure TUndoManager.RecordChange(Change: TRowChange);
begin
  FUndoStack.Push(Change);
  FRedoStack.Clear;
end;

function TUndoManager.CanUndo: boolean;
begin
  Result := FUndoStack.Count > 0;
end;

function TUndoManager.CanRedo: boolean;
begin
  Result := FRedoStack.Count > 0;
end;

procedure TUndoManager.Clear;
begin
  FUndoStack.Clear;
  FRedoStack.Clear;
end;

procedure TUndoManager.Undo;
var
  change: TRowChange;
  rows: TRowList;
begin
  if not CanUndo then Exit;

  change := FUndoStack.Pop;
  FRedoStack.Push(change);

  rows := FVeri.GetDataTable(FDatabaseName, change.TableName);
  case change.ChangeType of
    ctInsert:
      FVeri.DeleteRows(FDatabaseName, change.TableName, function(r: TRow): boolean
      begin
        Result := r = change.RowAfter;
      end);

    ctDelete:
      rows.Add(change.RowBefore.Clone);

    ctUpdate:
      for var r in rows do
        if r = change.RowAfter then
        begin
          r.Assign(change.RowBefore);
          Break;
        end;
  end;
end;

procedure TUndoManager.Redo;
var
  change: TRowChange;
  rows: TRowList;
begin
  if not CanRedo then Exit;

  change := FRedoStack.Pop;
  FUndoStack.Push(change);

  rows := FVeri.GetDataTable(FDatabaseName, change.TableName);
  case change.ChangeType of
    ctInsert:
      rows.Add(change.RowAfter.Clone);

    ctDelete:
      FVeri.DeleteRows(FDatabaseName, change.TableName, function(r: TRow): boolean
      begin
        Result := r = change.RowBefore;
      end);

    ctUpdate:
      for var r in rows do
        if r = change.RowBefore then
        begin
          r.Assign(change.RowAfter);
          Break;
        end;
  end;
end;

end.
