unit VDbTimeTravel;

{ VDb Time Travel / Snapshot Isolation - Motor Katmani
  Append-only WAL yapisi sayesinde onceki versiyonlara erisim saglar.
  SQL: SELECT * FROM tablo AS OF TIMESTAMP '2026-01-15 10:30:00';
       SELECT * FROM tablo AS OF VERSION 42; }

{$mode delphi}

interface

uses
  Classes, SysUtils, VDbCore, VDbTable, VDbSql;

type
  TSnapshotMode = (smNone, smTimestamp, smVersion, smSequence);

  TSnapshotSpec = record
    Mode: TSnapshotMode;
    Timestamp: TDateTime;  // smTimestamp icin
    Version: QWord;        // smVersion icin
    Sequence: QWord;       // smSequence icin
  end;

  TVTimeTravel = class
  private
    FTb: TVTableDb;
    FSnapshot: TSnapshotSpec;
    FActive: Boolean;
    FPrevSnapshot: TSnapshotSpec;
  public
    constructor Create(const ATb: TVTableDb);
    destructor Destroy; override;
    
    // Snapshot modlarini baslat
    procedure BeginSnapshot(const ASpec: TSnapshotSpec);
    procedure EndSnapshot;
    
    // Snapshot modunda sorgu calistirma
    function ExecSnapshot(const Sql: string): TSqlResult;
    
    // Belirli bir anahtarin onceki degerini al
    function GetValueAt(const Table: string; const PK: string; const Seq: QWord): TBytes;
    
    property Active: Boolean read FActive;
    property Snapshot: TSnapshotSpec read FSnapshot;
  end;

  // SQL parser genisletmesi icin yardimci
  function ParseSnapshotSpec(const Sql: string; out Spec: TSnapshotSpec): Boolean;

implementation

uses
  VDbParser, VDbExecutor, DateUtils;

constructor TVTimeTravel.Create(const ATb: TVTableDb);
begin
  inherited Create;
  FTb := ATb;
  FActive := False;
  FillChar(FSnapshot, SizeOf(TSnapshotSpec), 0);
end;

destructor TVTimeTravel.Destroy;
begin
  EndSnapshot;
  inherited Destroy;
end;

procedure TVTimeTravel.BeginSnapshot(const ASpec: TSnapshotSpec);
begin
  if FActive then EndSnapshot;
  FSnapshot := ASpec;
  FActive := True;
end;

procedure TVTimeTravel.EndSnapshot;
begin
  FActive := False;
  FillChar(FSnapshot, SizeOf(TSnapshotSpec), 0);
end;

function TVTimeTravel.ExecSnapshot(const Sql: string): TSqlResult;
var
  sq: TVSql;
begin
  sq := TVSql.Create(FTb);
  try
    Result := sq.Exec(Sql);
  finally
    sq.Free;
  end;
end;

function TVTimeTravel.GetValueAt(const Table: string; const PK: string; const Seq: QWord): TBytes;
var
  key: QWord;
  entries: TWalEntryArray;
  i: Integer;
begin
  SetLength(Result, 0);
  key := VDbHashKey(Table, PK);
  
  // WAL'i tara ve Seq'e kadar olan son degeri bul
  if FTb.Kv.ScanWal(Seq, 0, FTb.Kv.FWalEntries) > 0 then
  begin
    for i := High(FTb.Kv.FWalEntries) downto 0 do
    begin
      if (FTb.Kv.FWalEntries[i].Seq <= Seq) and (FTb.Kv.FWalEntries[i].Key = VDbHashKey(FTb.GetTable(Table).Name, PK)) then
      begin
        Result := FTb.Kv.FWalEntries[i].Value;
        Exit;
      end;
    end;
  end;
end;

function ParseSnapshotSpec(const Sql: string; out Spec: TSnapshotSpec): Boolean;
var
  upperSql: string;
  p, p2: Integer;
  timestampStr, versionStr, sequenceStr: string;
begin
  Result := False;
  FillChar(Spec, SizeOf(TSnapshotSpec), 0);
  upperSql := UpperCase(Sql);
  
  // AS OF TIMESTAMP '...'
  p := Pos('AS OF TIMESTAMP', upperSql);
  if p > 0 then
  begin
    p2 := p + Length('AS OF TIMESTAMP');
    timestampStr := Trim(Copy(Sql, p + Length('AS OF TIMESTAMP') + 1, 50));
    timestampStr := Trim(timestampStr);
    if (timestampStr <> '') and (timestampStr[1] = '''') then
    begin
      p2 := PosEx('''', timestampStr, 2);
      if p2 > 0 then
        timestampStr := Copy(timestampStr, 2, p2 - 2);
    end;
    if TryStrToDateTime(timestampStr, Spec.Timestamp) then
    begin
      Spec.Mode := smTimestamp;
      Result := True;
      Exit;
    end;
  end;
  
  // AS OF VERSION N
  p := Pos('AS OF VERSION', upperSql);
  if p > 0 then
  begin
    versionStr := Trim(Copy(Sql, p + Length('AS OF VERSION') + 1, 20));
    if TryStrToQWord(Trim(versionStr), Spec.Version) then
    begin
      Spec.Mode := smVersion;
      Result := True;
      Exit;
    end;
  end;
  
  // AS OF SEQUENCE N
  p := Pos('AS OF SEQUENCE', upperSql);
  if p > 0 then
  begin
    sequenceStr := Trim(Copy(Sql, p + Length('AS OF SEQUENCE') + 1, 20));
    if TryStrToQWord(Trim(sequenceStr), Spec.Sequence) then
    begin
      Spec.Mode := smSequence;
      Result := True;
      Exit;
    end;
  end;
end;

end.