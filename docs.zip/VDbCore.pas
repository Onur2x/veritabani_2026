unit VDbCore;

{$mode delphi}

interface

uses
  Classes, SysUtils, SyncObjs, Generics.Collections, FileUtil;

type
  TQWordArray = array of QWord;
  TValArray = array of TBytes;
  TWalEntry = record
    Seq: QWord;
    Key: QWord;
    Flags: Byte;
    ValLen: LongWord;
    Value: TBytes;
    Timestamp: TDateTime;
  end;
  TWalEntryArray = array of TWalEntry;
  TDbLoc = record Offset: Int64; Size: LongWord; Seq: QWord; end;
  TPendOp = record Key: QWord; Value: TBytes; IsDel: Boolean; end;

  TVDbRecHead = packed record
    Magic: LongWord; Crc: LongWord; Seq: QWord; Key: QWord; ValLen: LongWord; Flags: Byte;
  end;

  TVDbFileHead = packed record
    Magic: LongWord; Ver: LongWord; Flags: LongWord; Crc: LongWord;
  end;

  TVDb = class
  private
    FPath: string;
    FLock: TCriticalSection;
    FDirty: Boolean;
    FDirSyncFailed: Boolean;
    FInBatch: Boolean;
    FWalSeq: QWord;
    FWalStream: TFileStream;
    FWalDirty: Boolean;
    procedure CheckOpen;
    function GetWalPath: string;
    function GetDirSyncFailed: Boolean;
    function GetWalRecordCount: Integer;
  public
    constructor Create;
    destructor Destroy; override;
    procedure Open(const Dir: string);
    procedure Close;
    procedure Put(Key: QWord; const Value: TBytes);
    function Get(Key: QWord; out Value: TBytes): Boolean;
    function Exists(Key: QWord): Boolean;
    function Delete(Key: QWord): Boolean;
    procedure BeginBatch;
    procedure CommitBatch;
    procedure Flush;
    function Count: Integer;
    property FilePath: string read FPath;
    property Dirty: Boolean read FDirty;
    property WalPath: string read GetWalPath;
    property DirSyncFailed: Boolean read GetDirSyncFailed;
    property WalRecordCount: Integer read GetWalRecordCount;
    property InBatch: Boolean read FInBatch;
    procedure AbortBatch;
    procedure ScanAll(out AKeys: TQWordArray; out ARaw: TValArray);
    function ScanWal(const AMaxSeq: QWord; const AMaxTimestamp: TDateTime; out AEntries: TWalEntryArray): Integer;
    procedure ReplayWalToSeq(const AMaxSeq: QWord);
    function HasWAL: Boolean;
  end;

function VDbStrToBytes(const S: RawByteString): TBytes;
function VDbBytesToStr(const B: TBytes): RawByteString;

implementation

uses VDbCrc32, VDbSync, Math;

{ TVDb }

constructor TVDb.Create;
begin
  inherited Create;
  FLock := TCriticalSection.Create;
  FDirty := False;
  FDirSyncFailed := False;
  FInBatch := False;
  FWalSeq := 0;
  FWalStream := nil;
  FWalDirty := False;
end;

destructor TVDb.Destroy;
begin
  Flush;
  if FWalStream <> nil then
  begin
    FWalStream.Free;
    FWalStream := nil;
  end;
  FLock.Free;
  inherited Destroy;
end;

procedure TVDb.CheckOpen;
begin
  if FPath = '' then
    raise Exception.Create('VDb: database not opened');
end;

procedure TVDb.Open(const Dir: string);
begin
  Close;
  FPath := IncludeTrailingPathDelimiter(Dir) + 'veritabani.odb';
  FDirty := False;
  FDirSyncFailed := False;
end;

procedure TVDb.Close;
begin
  Flush;
  FPath := '';
  FDirty := False;
  FDirSyncFailed := False;
end;

procedure TVDb.Put(Key: QWord; const Value: TBytes);
begin
  CheckOpen;
  FDirty := True;
  // In a real implementation, this would write to the database
  // For now, we just mark as dirty
end;

function TVDb.Get(Key: QWord; out Value: TBytes): Boolean;
begin
  CheckOpen;
  // In a real implementation, this would read from the database
  Result := False;
  Value := nil;
end;

function TVDb.Exists(Key: QWord): Boolean;
begin
  CheckOpen;
  Result := False;
end;

function TVDb.Delete(Key: QWord): Boolean;
begin
  CheckOpen;
  FDirty := True;
  Result := True;
end;

procedure TVDb.BeginBatch;
begin
  FInBatch := True;
end;

procedure TVDb.CommitBatch;
begin
  FInBatch := False;
  Flush;
end;

procedure TVDb.Flush;
begin
  if not FDirty then Exit;
  // In a real implementation, this would flush WAL to disk
  FDirty := False;
  FDirSyncFailed := False;
end;

function TVDb.Count: Integer;
begin
  Result := 0;
  // In a real implementation, this would count records
end;

function TVDb.GetWalPath: string;
begin
  Result := ChangeFileExt(FPath, '.wal');
end;

function TVDb.GetDirSyncFailed: Boolean;
begin
  Result := FDirSyncFailed;
end;

function TVDb.GetWalRecordCount: Integer;
begin
  Result := 0;
  // In a real implementation, this would count WAL records
end;

procedure TVDb.AbortBatch;
begin
  FInBatch := False;
  // Discard any pending changes
end;

procedure TVDb.ScanAll(out AKeys: TQWordArray; out ARaw: TValArray);
begin
  SetLength(AKeys, 0);
  SetLength(ARaw, 0);
  // In a real implementation, this would scan all records
end;

function TVDb.ScanWal(const AMaxSeq: QWord; const AMaxTimestamp: TDateTime; out AEntries: TWalEntryArray): Integer;
begin
  SetLength(AEntries, 0);
  Result := 0;
  // In a real implementation, this would scan WAL entries
end;

procedure TVDb.ReplayWalToSeq(const AMaxSeq: QWord);
begin
  // In a real implementation, this would replay WAL to sequence
end;

function TVDb.HasWAL: Boolean;
begin
  Result := FileExists(GetWalPath);
end;

{ Helper functions }

function VDbStrToBytes(const S: RawByteString): TBytes;
begin
  SetLength(Result, Length(S));
  if Length(S) > 0 then
    Move(S[1], Result[0], Length(S));
end;

function VDbBytesToStr(const B: TBytes): RawByteString;
begin
  SetLength(Result, Length(B));
  if Length(B) > 0 then
    Move(B[0], Result[1], Length(B));
end;

end.