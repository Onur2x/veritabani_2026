# VDB Motor v2 — Dokumantasyon (Komple — Guncel)

Saf Free Pascal (FPC) ile yazilmis, harici DLL gerektirmeyen (`.odb` tek dosya) iliskisel veritabani motoru. `D:\veritabani\` (`Motor`, `Yonetim`, `API`, `Dokumantasyon`) klasorleri icin `Komple` dokumantasyon.

---

## `Incelenen` (`Komple`) Dosya Listesi (`D:\veritabani`)

### `Motor` (`.pas` — `Incelendi` / `Modifiye` `Durum`)
```
VDbAst.pas         15881  AST (Tam)
VDbCore.pas        60065  Core + WAL (WriteAheadWAL, ReplayWAL, CheckpointWAL, HasWAL) + Faz D Flags (4=ENC, 8=COMP)
VDbCrc32.pas        2677  CRC32
VDbDataSet.pas     31823  TDataSet
VDbDataSetReg.pas    458  Kayit
VDbErr.pas         5241  Hata
VDbExecutor.pas    76860  SQL yurutucu
VDbJson.pas        15240  JSON
VDbParser.pas      64131  Parser
VDbPool.pas         6167  Havuz
VDbSql.pas        108211  SQL (KOPYA dosyasi: 154859 byte - projede kullanilmiyor, silinmedi)
VDbSync.pas         4219  fsync
VDbTable.pas      129254  Tablo (PutRow: WAL entegre VDB_FLAG_PUT)
VDbTest.pas          909  Faz D Test (Crash + Replay - Satis.odb uzerinde)
VDbText.pas         5973  Turkce
VDbWal.pas          2200  WAL motor (.wal yazma/replay/checkpoint) - YENI
```

### `Veritabani` (`.odb` — `Incelendi` `Komple`, `Modifiye` `YOK`)
```
D:\veritabani\db\veritabani.odb  381068 byte (370 KB)  VDB v2 (Magic LE: 0x42444F56 = VODB, Ver: 2, Flags: 0, CRC: 0xC8335F8C) - SAGLAM, CANLI VERI
D:\veritabani\db\satis.odb        135 byte             VDB v2 (Magic LE: 0x42444F56 = VODB, Ver: 2, Flags: 0) - BOS / TEST (SCH1 etiketi + 0 deger)
```

### `Yonetim` (`GUI` — `Incelendi`, `WAL` `Bagimsiz`)
```
D:\veritabani\yonetim\hadmain.pas  (3127 satir)  Modern UI (Banner, Kart, Tema, Toolbar, Popup Menu)
D:\veritabani\yonetim\haddlg.pas   (346 satir)   Dialog (Tablo/Sutun)
D:\veritabani\yonetim\hadtools.pas (350 satir)   Utility (CSV/JSON)
```

### `API` / `DLL` (`Incelendi`, `Harici` Katman)
```
D:\veritabani\vdbapi.dll          1084416 byte  DLL (C ABI, stdcall, UTF-8 NUL, 32-bit x86)
D:\veritabani\vdbapi.h              6144 byte   C Header (VDB_API extern __declspec)
D:\veritabani\vdbapi_core.pas       32739 byte  API Core (Pascal sarayici, Cagri kurali bagimsiz)
D:\veritabani\vdbapi.lpi            2560 byte  DLL projesi
D:\veritabani\vdbapitest.exe       232448 byte  Dinamik test (LoadLibrary + GetProcAddress, 53 kontrol - TAMAM)
D:\veritabani\VDBClient.pas        19391 byte  Delphi istemci (vdbapi.dll baglantisi)
D:\veritabani\vdbclientdemo.exe    205312 byte  Ornek (VDBClient kullanimi)
D:\veritabani\vdbclienttest.exe     230912 byte  Test
```

### `Test` (`Incelendi` / `Derleme` `Durum`)
```
D:\veritabani\sqltest.lpi          1805 byte  79 grup, 830 kontrol - TAMAM (830/830)
D:\veritabani\vdbgui.lpi           2112 byte  Basit yonetim GUI - DERLENIR + LINKLENIR
D:\veritabani\vdbgui.exe           25865443 byte  Uretim (Derlenmis)
D:\veritabani\vdbspeed.lpr         8428 byte  HIZ olcumu (DLL cagri maliyeti)
```

### `Alt Klasorler` (`Incelendi`)
```
D:\veritabani\ESKI/    (db/, yonetim/, guimain.*, README.md eski, SQL.md, sqltest.*, ...) - Eski surumler / Yedek
D:\veritabani\mtakip/  (backup/, data/, webserver/, web_prototype/) - Takip / Prototip
```

---

## `Veritabani` (`Binary` `Inceleme` — `Komple`)

### `veritabani.odb` (`381068 byte = 370 KB`)
```
Magic (offset 0):    0x42444F56  (VODB LE)     -> SAGLAM
Versiyon (offset 4): 2           (VDB_FILE_VER) -> v2
Flags (offset 8):    0           (Varsayilan)  -> ENCRYPTED(4) DEGIL, COMPRESSED(8) DEGIL
Crc (offset 12):     0xC8335F8C  (Header CRC32)
Kayit Baslangici (16): 0x56444231 (VDB_MAGIC) -> Append-Only basladi
```
`Durum`: `Canli veri`, `Saglam`, `Bozuk kayit yok` (`CRC` `Tutuyor`), `Truncate` `Gerekli` `Degil`.

### `satis.odb` (`135 byte`)
```
Magic (offset 0):    0x42444F56  (VODB LE)
Versiyon (offset 4): 2
Flags (offset 8):    0
Durum: Bos / Test (SCH1 etiket + 0 deger)
```

---

## `WAL` (`Sifir Veri Kaybi` — `Faz A/B/C` `Tamam`)

- `VDbWal.pas` (`2200 byte`): `.wal` (`WAL_MAGIC`) + `WriteAheadWAL`, `ReplayWAL`, `CheckpointWAL`, `HasWAL`
- `VDbCore.pas` (`60065 byte`): `TVDb` (`WAL` `Hook` `Entegrasyonu`)
- `VDbTable.pas` (`PutRow`): `FKv.WriteAheadWAL(key, b, VDB_FLAG_PUT)` -> `FKv.Put(key, b)` -> `WAL` `Yazma` `Once`
- `Faz D`: `Encryption` (`Flags=4`), `Compression` (`Flags=8`), `Streaming` (`Cursor` `Temel`), `AutoBackup` (`Timer` `Temel`), `Memory-Mapped` (`Temel`)

---

## `Faz D`: `Motor` `Yenilikleri` (`Durum`)

| `Ozellik` | `Durum` (`Tam`/`Temel`/`Iskelet`) | `Acilama` |
|---|---|---|
| `WAL` | `Tam` (`Faz A/B/C`) | `Sifir Veri Kaybi` (`Durability`) |
| `Encryption` (`AES`) | `Iskelet` (`Flags=4` tanimli) | `Value` (`TBytes`) `Sifreleme` (`Tam AES` `Eklenmedi`) |
| `Compression` (`ZLIB`) | `Iskelet` (`Flags=8` tanimli) | `Value` (`Sikistirma` — `Tam ZLIB` `Eklenmedi`) |
| `Streaming` (`Pagination`) | `Temel` (`StreamCursor` var) | `O(1)` `Read-only Cursor` (`Tam` `Position` `Seek` `Eklenmedi`) |
| `AutoBackup` | `Temel` (`AutoBackup` var) | `Timer` (`5 dk`) `Tam` `Otomasyon` (`Eklenmedi`) |
| `Memory-Mapped` (`MMF`) | `Temel` (`IsEncrypted`/`IsCompressed` `MMF` `Referans`) | `TFileStream` `MMF` (`Zero-Copy`) (`Tam` `Entegrasyon` `Eklenmedi`) |
| `Query Planner` | `Mevcut` (`VDbSql.pas` `Mevcut`) | `Plan` (`Cost-Based`) `Tam` (`VDbAst.pas` `Entegrasyonu` `Eklenmedi`) |

---

## `Test` (`Derleme` `Durum`)

| `Proje` | `Durum` |
|---|---|
| `had.lpi` (`Yonetim`) | `Derlenir` (`Temiz`) |
| `vdbgui.lpi` (`Basit GUI`) | `Derlenir` (`Temiz`) |
| `sqltest.lpi` (`Test`) | `Derlenir` (`Temiz`) |
| `vdbapi.lpi` (`DLL`) | `Derlenir` (`Temiz`) |

---
`Dokumantasyon`: `Komple`. `Eksik`: `Yok`. `WAL`: `Tamam`. `Faz D`: `Iskelet` (`Tam` `Kod` `Sen` `Yazacaksin`).
