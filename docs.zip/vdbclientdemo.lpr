program vdbclientdemo;

{ VDbClient ORNEGI - kendi Delphi programinda nasil kullanacaksin
  ---------------------------------------------------------------------------
  Bu ORNEK, `VDBClient.pas` birimini kullanir. Yani motorun kodunu
  degil, tamamen DLL uzerinden gider. Senin Delphi projen icin de
  ayni sey: `uses VDbClient;` yazip ayni cagrilari kullan.

  Derleme (bu ornek icin FPC kullanildi; Delphi'de proje olusturup
  VDBClient.pas'i eklemen yeterli):
      lazbuild vdbclientdemo.lpi
  Calistirma:
      vdbclientdemo.exe [veritabani-klasoru]

  ONEMLI: `vdbapi.dll` bu .exe ile AYNI klasorde olmali.
}

{$mode delphi}{$H+}

uses
  SysUtils, VDbClient;

var
  Db: TVDb;
  R: TVDbResult;
  Dir: string;
  I: Integer;
  Ad, Yil: string;
  Toplam: Int64;
  Rep: AnsiString;
  Eski, Yeni: Int64;
begin
  if (ParamCount >= 1) and (Trim(ParamStr(1)) <> '') then
    Dir := ParamStr(1)
  else
    Dir := GetCurrentDir;

  WriteLn('=== VDbClient ornegi ===');
  WriteLn('Veritabani klasoru: ', Dir);
  WriteLn;

  // 1) AC ---------------------------------------------------------------
  Db := TVDb.Open(Dir + '\demo.odb', True);
  try
    WriteLn('[1] Acildi. Kayit sayisi = ', Db.Count);

    // 2) SQL: olustur (varsa hata verir, yakalayip devam ederiz)
    try
      R := Db.SQL('DROP TABLE IF EXISTS sehir');
      R.Free;
    except
      on E: Exception do
        WriteLn('    (tablo zaten yoktu)');
    end;

    R := Db.SQL('CREATE TABLE sehir (id INTEGER PRIMARY KEY, ad TEXT NOT NULL, ' +
      'nufus INTEGER)');
    WriteLn('[2] Tablo olusturuldu. Etkilenen satir = ', R.Affected);
    R.Free;

    // 3) Coklu ekleme
    R := Db.SQL('INSERT INTO sehir (id, ad, nufus) VALUES ' +
      '(1, ''Istanbul'', 16000000),' +
      '(2, ''Ankara'', 5700000),' +
      '(3, ''Izmir'', 4400000),' +
      '(4, ''Bursa'', 3100000),' +
      '(5, ''Antalya'', 1300000)');
    WriteLn('[3] ', R.Affected, ' sehir eklendi');
    R.Free;

    // 4) Sorgu + sonuclari gez
    R := Db.SQL('SELECT id, ad, nufus FROM sehir ORDER BY nufus DESC');
    WriteLn('[4] Sorgu sonucu: ', R.RowCount, ' satir x ', R.FieldCount, ' kolon');
    WriteLn('    Kolonlar: ', R.FieldName(0), ', ', R.FieldName(1), ', ',
      R.FieldName(2));
    Toplam := 0;
    for I := 0 to R.RowCount - 1 do
    begin
      Ad := R.Value(I, 1);
      Yil := R.Value(I, 2);
      Toplam := Toplam + StrToInt64Def(Yil, 0);
      WriteLn('    ', R.Value(I, 0), '.  ', Ad, '  ->  ', Yil);
    end;
    WriteLn('    TOPLAM nufus: ', Toplam);
    R.Free;

    // 5) Kume (aggregate) sorgusu
    R := Db.SQL('SELECT COUNT(*) FROM sehir');
    WriteLn('[5] Sehir sayisi: ', R.Value(0, 0));
    R.Free;

    // 6) KISIT HATASI YAKALAMA
    // DIKKAT: `nufus` NULL'a izin verir, `ad` ise NOT NULL. Onceki
    // deneme `nufus`'u atlayip `ad` yerine deger yaziyordu ve gecerli
    // bir insert olcegi icin hata YOKTU. Dogru deneme `ad` alanina
    // NULL yazmaktir.
    try
      R := Db.SQL('INSERT INTO sehir (id, ad) VALUES (99, NULL)');
      R.Free;
      WriteLn('[6] HATA: NOT NULL ihlali yakalanmadi!');
    except
      on E: EVDbApiError do
        WriteLn('[6] Kisit hatasi yakalandi -> kod=', E.Code, '  ', E.Message);
      on E: Exception do
        WriteLn('[6] Beklenmeyen hata: ', E.Message);
    end;
    // Ayni sekilde PK cakismasi da yakalanmali
    try
      R := Db.SQL('INSERT INTO sehir (id, ad) VALUES (1, ''Tekrar'')');
      R.Free;
      WriteLn('[6b] HATA: PK cakismasi yakalanmadi!');
    except
      on E: EVDbApiError do
        WriteLn('[6b] PK cakismasi yakalandi -> kod=', E.Code);
    end;

    // 7) Ham KV: bilgi nesnesi gibi kullanmak icin
    Db.Put(1000, 'surum bilgisi');
    { Turkce karakterli UTF-8 metni bayt olarak elle yaziyoruz:
      c-cedil=C3 A7, g-breve=C4 9F, u-umlaut=C3 BC, o-umlaut=C3 B6 }
    Db.Put(1001, 'cag' + #$C3#$A7 + ' ' + #$C4#$9F + #$C3#$BC + #$C3#$B6 + 'ce');
    WriteLn('    [7a] Count simdi = ', Db.Count);
    WriteLn('    [7b] Put 1000 sonrasi Exists = ', Db.Exists(1000));
    if Db.GetStr(1000, Ad) then
      WriteLn('[7] KV okuma: 1000 = ', Ad);
    if Db.GetStr(1001, Ad) then
      WriteLn('    KV okuma: 1001 UTF-8 bayt sayisi = ', Length(Ad),
        '  ilk 3 bayt = ',
        IntToHex(Byte(Ad[1]), 2), ' ', IntToHex(Byte(Ad[2]), 2), ' ',
        IntToHex(Byte(Ad[3]), 2),
        '   (konsol kodlamasi Turkce karakteri gosteremeyebilir)');

    WriteLn('    1002 var mi? ', Db.Exists(1002));
    Db.DeleteKey(1000);

    // 8) Butunluk
    if Db.Verify(Rep) then
      WriteLn('[8] Verify: SAGLAM - ', Rep)
    else
      WriteLn('[8] Verify: SORUN - ', Rep);

    // 9) Bakim
    if Db.AutoCompact(Eski, Yeni) then
      WriteLn('[9] Sikistirildi: ', Eski, ' -> ', Yeni, ' bayt')
    else
      WriteLn('[9] Sikistirma gerekmedi: ', Eski, ' bayt');

    // 10) WAL durumu
    if Db.HasWAL then
      WriteLn('[10] WAL bekliyor: ', Db.WalRecordCount, ' kayit')
    else
      WriteLn('[10] WAL bekleyen kayit yok');

    WriteLn;
    WriteLn('Dosya boyutu : ', Db.Size, ' bayt');
    WriteLn('Olu bayt    : ', Db.DeadBytes);
    WriteLn('Canli kayit  : ', Db.Count);
  finally
    Db.Free;
  end;

  WriteLn;
  WriteLn('=== TAMAM ===');
end.
