/* ===========================================================================
   vdbapi.h - VDb Engine C API
   ---------------------------------------------------------------------------
   Bu baslik her dilde kullanilabilir (Delphi, C#, Python ctypes, C, Rust...).
   DLL 32-bit (x86) olarak derlenmistir.

   KURALLAR
     * Metinler UTF-8 ve NUL ile sonlanir.
     * Veriler ham bayt; metin de BLOB da ayni yolla gecer.
     * Hicbir istisna DLL sinirini gecmez. Her cagri VDB_OK (0) donerse
       basarilidir; degilse VdbLastError() ile ayrintiyi alin.
     * Metin donduren fonksiyonlar (VdbLastError, VdbResultValue, ...)
       DLL icindeki bir tampona isaret doner. Tampon BIR SONRAKI ayni
       DLL cagrisina kadar gecerlidir; iki isareti ayni anda tutmayin.
     * Bir tur serbest birakma yoktur.
   =========================================================================== */

#ifndef VDBAPI_H
#define VDBAPI_H

#include <stdint.h>

#if defined(_WIN32)
#  define VDB_CALL __stdcall
#  if defined(VDB_BUILD_DLL)
#    define VDB_API extern __declspec(dllexport)
#  else
#    define VDB_API extern __declspec(dllimport)
#  endif
#else
#  define VDB_CALL
#  define VDB_API extern
#endif

#ifdef __cplusplus
extern "C" {
#endif

/* ------------------------------------------------------------ surum */
#define VDB_API_VERSION 0x00010000   /* 1.0 */

VDB_API uint32_t      VDB_CALL VdbApiVersion(void);
VDB_API const char*   VDB_CALL VdbVersion(void);

/* ------------------------------------------------------------- hata */
#define VDB_OK            0
#define VDB_E_GENERAL    -1
#define VDB_E_BAD_HANDLE -2
#define VDB_E_OPEN       -3   /* dosya kilitli / acilamadi */
#define VDB_E_SQL        -4
#define VDB_E_READONLY   -5
#define VDB_E_BUFFER     -6   /* tampon kucuk */
#define VDB_E_RANGE      -7
#define VDB_E_ENGINE     -8
#define VDB_E_NOT_FOUND  -9
#define VDB_E_DUPLICATE -10
#define VDB_E_CONSTRAINT -11

VDB_API const char*   VDB_CALL VdbLastError(void);
VDB_API int32_t       VDB_CALL VdbLastErrorCodeGet(void);
VDB_API void          VDB_CALL VdbSetLastErrorCode(int32_t err);

/* ------------------------------------------------------- ac / kapa */
/* APath: .odb dosyasinin tam yolu (ya da klasor).
   ASyncWrite: 1 = her yazmada fsync (dayanikli, yavas).
                0 = ara bellekli (hizli; VdbFlush ile yazilir).
   Basarili: sifirdan farkli handle. Basarisiz: 0. */
VDB_API uint32_t      VDB_CALL VdbOpen(const char* APath, int32_t ASyncWrite);
VDB_API void          VDB_CALL VdbClose(uint32_t hDb);
VDB_API void          VDB_CALL VdbCloseAll(void);

/* --------------------------------------------------------- temel KV */
/* VdbGet: >=0 kopyalanan bayt; <0 gerekli boyut = -sonuc; -1 anahtar yok */
VDB_API int32_t       VDB_CALL VdbCount(uint32_t hDb);
VDB_API int32_t       VDB_CALL VdbPut(uint32_t hDb, int64_t key,
                                     const void* data, int32_t len);
/* Iki asamali kullanim (ONCESI boyut sorulur, SONRA okunur):
     need = VdbGet(h, key, NULL, 0);
     if (need == -1)              -> anahtar YOK
     else if (need <= VDB_E_GENERAL) -> HATA (need bir VDB_E_* kodu)
     else {
        buf[need];                // need = gerekli bayt sayisi
        if (need > 0) VdbGet(h, key, buf, need);   // -> kopyalanan bayt
     }
   NOT: hata kodlari (-1..-11) ile "gerekli boyut" ayni degere
   dusebilecegi icin yalniz -1 "yok" demektir; daha kucuk degerler
   HATA kodudUR ve mutlaka ayirt edilmelidir. */
VDB_API int32_t       VDB_CALL VdbGet(uint32_t hDb, int64_t key,
                                     void* buf, int32_t buflen);
VDB_API int32_t       VDB_CALL VdbExists(uint32_t hDb, int64_t key);
VDB_API int32_t       VDB_CALL VdbDelete(uint32_t hDb, int64_t key);
/* AOut NULL ise yalnizca anahtar sayisini doner. */
VDB_API int32_t       VDB_CALL VdbKeys(uint32_t hDb, int64_t* AOut, int32_t amax);
VDB_API void          VDB_CALL VdbFlush(uint32_t hDb);

/* -------------------------------------------------------------- SQL */
#define VDB_SQL_AUTOTXN 0x0001

/* Basarili: sifirdan farkli sonuc handle. Hata: 0 (VdbLastError'a bakin). */
VDB_API uint32_t      VDB_CALL VdbExec(uint32_t hDb, const char* sql,
                                      int32_t flags);

/* ------------------------------------------------------- sonuc seti */
VDB_API int32_t       VDB_CALL VdbResultFieldCount(uint32_t hRes);
VDB_API int32_t       VDB_CALL VdbResultRowCount(uint32_t hRes);
VDB_API const char*   VDB_CALL VdbResultFieldName(uint32_t hRes, int32_t col);
VDB_API const char*   VDB_CALL VdbResultValue(uint32_t hRes, int32_t row,
                                              int32_t col);
VDB_API int32_t       VDB_CALL VdbResultAffected(uint32_t hRes);
VDB_API int32_t       VDB_CALL VdbResultStmts(uint32_t hRes);
VDB_API const char*   VDB_CALL VdbResultMessage(uint32_t hRes);
VDB_API const char*   VDB_CALL VdbResultLastTable(uint32_t hRes);
VDB_API void          VDB_CALL VdbResultFree(uint32_t hRes);

/* -------------------------------------------------------- bakim/WAL */
/* WAL opt-in'dir: VdbWalWrite ana dosyaya YAZMAZ; kayit ancak
   VdbWalReplay / VdbWalCheckpoint ile kalicilik kazanir. */
VDB_API int32_t       VDB_CALL VdbVerify(uint32_t hDb, char* report,
                                         int32_t reportMax);
VDB_API int32_t       VDB_CALL VdbWalHas(uint32_t hDb);
VDB_API int32_t       VDB_CALL VdbWalRecordCount(uint32_t hDb);
VDB_API int32_t       VDB_CALL VdbWalWrite(uint32_t hDb, int64_t key,
                                           const void* data, int32_t len);
VDB_API int32_t       VDB_CALL VdbWalWriteDelete(uint32_t hDb, int64_t key);
VDB_API int32_t       VDB_CALL VdbWalReplay(uint32_t hDb);
VDB_API int32_t       VDB_CALL VdbWalCheckpoint(uint32_t hDb);
VDB_API int64_t       VDB_CALL VdbFileSize(uint32_t hDb);
VDB_API int64_t       VDB_CALL VdbDeadBytes(uint32_t hDb);
/* 1 = sikistirildi, 0 = gerek yok. AOld/ANew NULL olabilir. */
VDB_API int32_t       VDB_CALL VdbAutoCompact(uint32_t hDb,
                                              int64_t* AOld, int64_t* ANew);

#ifdef __cplusplus
}
#endif
#endif /* VDBAPI_H */
