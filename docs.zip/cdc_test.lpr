program cdc_test;

{ CDC Test - WAL + CDC entegrasyonunu dogrular }

{$mode delphi}{$H+}

uses
  SysUtils, Classes, VDbCore, VDbTable, VDbSql, VDbCdc;

var
  Kv: TVDb;
  Tb: TVTableDb;
  Sq: TVSql;
  Cdc: TVDbCdc;
  Dir: string;

procedure OnChange(const Event: TCDCEvent);
begin
  WriteLn('CDC EVENT: ', Event.EventType, ' | Table: ', Event.TableName, 
    ' | PK: ', Event.PK, ' | Seq: ', Event.Seq);
end;

begin
  Dir := 'D:\veritabani\db';
  
  WriteLn('=== CDC TEST BASLADI ===');
  
  Kv := TVDb.Create;
  Tb := TVTableDb.Create(Kv);
  Sq := TVSql.Create(Tb);
  try
    // DB ac
    Kv.Open(Dir);
    Tb.Open(Dir);
    
    // Test tablo olustur
    Sq.Exec('DROP TABLE IF EXISTS cdc_test');
    Sq.Exec('CREATE TABLE cdc_test (id INTEGER PRIMARY KEY, ad TEXT, deger INTEGER)');
    
    // CDC baslat
    Cdc := TVDbCdc.Create(Tb);
    Cdc.OnChange := @OnChange;
    Cdc.Start;
    
    // Veri ekle (CDC tetiklenmeli)
    WriteLn('--- INSERT test ---');
    Sq.Exec('INSERT INTO cdc_test (id, ad, deger) VALUES (1, ''test1'', 100)');
    Sq.Exec('INSERT INTO cdc_test (id, ad, deger) VALUES (2, ''test2'', 200)');
    Sq.Exec('INSERT INTO cdc_test (id, ad, deger) VALUES (3, ''test3'', 300)');
    Sleep(500);
    
    // Guncelle
    WriteLn('--- UPDATE test ---');
    Sq.Exec('UPDATE cdc_test SET deger = 150 WHERE id = 1');
    Sleep(500);
    
    // Sil
    WriteLn('--- DELETE test ---');
    Sq.Exec('DELETE FROM cdc_test WHERE id = 2');
    Sleep(500);
    
    // CDC durdur
    Cdc.Stop;
    Cdc.Free;
    
    WriteLn('=== CDC TEST TAMAMLANDI ===');
    
  finally
    Sq.Free;
    Tb.Free;
    Kv.Free;
  end;
end.