# VDB SQL referansi

Bu dosya `VDbSql.pas` icindeki **gercekten ayristirilan** komutlari listeler.
Listede olmayan bir sey calismaz (asagida "Desteklenmeyenler" bolumu).

**Betik calistirma:** `TVSql.Exec` metni `;` ile ayrilmis **coklu cumle** olarak
kabul edir ve hepsini sirayla calistirir (bolum 5b).

**Otomatik transaction (varsayilan acik):** `;` ile ayrilmis cumlelerin hepsi
batch uyumluysa **TEK `BeginBatch`/`CommitBatch`** icinde calistirilir:
- tek fsync -> belirgin hizli (300 komut: 1 ms, kapali hali 94 ms)
- hata olursa **hicbir cumle uygulanmaz** (ya hep ya hic)

Devreye girmeyen durumlar (bu cumleler varsa eski davranis korunur):
`BEGIN`/`COMMIT`/`ROLLBACK`/`END`, `CREATE`/`DROP`/`DELETE DATABASE`,
`OPEN`/`USE`/`CLOSE`, `BACKUP`, `VERIFY`, `VACUUM`, `REINDEX`, `EXPORT`,
`IMPORT`. Kapatmak icin: `TVSql.AutoTransaction := False`.

## Komut listesi (ozet)

| Komut | Durum |
|---|---|
| `BEGIN` / `COMMIT` / `ROLLBACK` | var |
| `CREATE TABLE` | var (PRIMARY KEY, NOT NULL, UNIQUE, DEFAULT, CHECK, REFERENCES, AUTOINCREMENT, ON DELETE/UPDATE aksiyonlari) |
| `CREATE INDEX` | var |
| `CREATE DATABASE` | var (`IF NOT EXISTS`) |
| `OPEN DATABASE` / `USE` | var (etkin veritabanini degistirir, sonrasi otomatik `Verify`) |
| `CLOSE DATABASE` | var (kapatir, dosya kilidini birakir) |
| `DROP TABLE` / `DROP INDEX` / `DROP DATABASE` / `DELETE DATABASE` | var (`IF EXISTS` sadece DATABASE'te) |
| `BACKUP TO 'dosya.odb'` / `VERIFY` | var |
| `ALTER TABLE` | var (ADD/DROP/RENAME/ALTER COLUMN) |
| `INSERT` | var (4 bicim + **çoklu `VALUES`** + `INSERT ... SELECT`) |
| `SELECT` | var (`*`, kolon listesi, AS, `DISTINCT`, JOIN, WHERE, GROUP BY, HAVING, ORDER BY, LIMIT, OFFSET, aggregate, `UNION`/`EXCEPT`/`INTERSECT`) |
| `UPDATE` / `DELETE` | var (`SET` icinde `+ - * / %` aritmetigi) |
| `LIST DATABASES` / `SHOW DATABASES` / `SHOW TABLES` | var |
| `DESCRIBE t` / `DESC t` | var (kolon semasi) |
| `SHOW INDEXES [FROM] t` | var |
| `SHOW CREATE TABLE t` | var |
| `VACUUM` / `REINDEX` | var |
| `EXPORT JSON` / `IMPORT JSON` | var |

---

## 0. Sema sorgulari

```sql
DESCRIBE ebe;                  -- veya: DESC ebe;
SHOW INDEXES FROM ebe;         -- FROMsuz bicim de calisir: SHOW INDEXES ebe
SHOW CREATE TABLE ebe;
```

`DESCRIBE` sutunlari dondurur: `name, type, pk, notnull, unique, default`.
`SHOW INDEXES` her indeks icin `name, columns, unique, type` dondurur.
`SHOW CREATE TABLE` tek satirlik `CREATE TABLE` metni verir.

Yonetim programinda bu uc sorgu **Sema** sekmesinden tek tikla
calistirilir; sorgu SQL sekmesine de yazilir, duzenlenip tekrar
calistirilabilir.

**Bilinen sinir:** `SHOW CREATE TABLE` `AUTOINCREMENT` niteligi
uretmez (otoincrement semada saklanmaz, yalniz calisma aninda sayac
tutulur) ve metin `DEFAULT` degerini tirnaksiz yazar
(`DEFAULT x`). Bunlar sema **okuma** komutlari oldugu icin yazma
tutarliligini etkilemez, ama bir `CREATE TABLE` metnini oldugu gibi
geri calistirmak kullaniciya gore degere baglidir.

---

## 0b. WAL (yazma oncesi gunluk) — API, SQL degil

WAL bir **SQL komutu degil**, dogrudan API'dir (`had` uzerinden de
kullanilir):

| Metot | Islev |
|---|---|
| `WalPath` | `.odb` dosyasinin `.wal` yolu |
| `WriteAheadWAL(Key, Value, Flags)` | gunluge bir kayit yazar (`Flags`: `VDB_FLAG_PUT` / `VDB_FLAG_DEL`) |
| `ReplayWAL` | gecerli kayitlari ana dosyaya **tek batch'te** uygular, sonra `.wal` siler |
| `CheckpointWAL` | once replay, sonra sil |
| `HasWAL` | bekleyen kayit var mi |
| `WalRecordCount` | bekleyen **gecerli** kayit sayisi (yalnizca okur) |

### Kayit formati (21 bayt baslik)

```
LongWord Magic = $57414C52 ('WALR')
QWord    Key
Byte     Flags        // 0 = PUT, 1 = DEL
LongWord ValLen
LongWord Crc          // CRC32(Seq=0 || Key || ValLen || Flags || Value)
```

`CRC` **magic'i kapsamaz**.

### Davranis

- `ReplayWAL`: kayitlar sirayla okunur; **magic / bayrak / uzunluk / CRC**
  tutmuyorsa kuyruk **orada kesilir**, o ana kadar olanlar uygulanir.
  Yirtik kuyruk veya CRC bozuk kayit **hicbir zaman** uygulanmaz.
- Gecerli kayitlar **tek `BATCHEND` ile** yazilir: ya hep uygulanir ya
  hicbiri. Boylece yari uygulanmis replay, sonraki `Open`'da `Recover`
  tarafindan geri sarilir.
- `.wal` dosyasi `ReplayWAL` sonunda **silinir** (bozuk kuyruk da
  silinir: bozuk kayit zaten hic uygulanamaz, tutmanin kurtarma degeri
  yoktur).
- `WriteAheadWAL` mevcut dosyaya **ekler**; deger dosyaya `fsync` edilir.

### DIKKAT

`Put`/`Delete` **otomatik olarak WAL yazmaz.** WAL **opt-in**'tir:
`WriteAheadWAL` cagrildiktan sonra kayit `.wal`'a yazilir ve ana dosyaya
**yazilmaz**; veri ancak `ReplayWAL`/`CheckpointWAL` ile kalicilik kazanir.

---

## 1. Transaction

```sql
BEGIN;
COMMIT;
ROLLBACK;
```

`ROLLBACK` **DDL dahil**: batch basinda alinan sema yedegi geri yuklenir
(`CREATE TABLE`, `DROP TABLE`, `ALTER TABLE`, `CREATE INDEX` geri alinir).

## 2. CREATE TABLE

```sql
CREATE TABLE kisi (
  id     INTEGER PRIMARY KEY AUTOINCREMENT,  -- PK otomatik NOT NULL + UNIQUE
  ad     TEXT    NOT NULL,
  yas    INTEGER DEFAULT 0,
  email  TEXT    UNIQUE,                     -- UNIQUE kisit
  aktif  BOOLEAN DEFAULT 1,
  not1   FLOAT,
  dogum  DATE,
  kayit  DATETIME,
  saat   TIME,
  resim  BLOB,
  CHECK (yas >= 0)                          -- tablo-seviyesi CHECK
);
```

### AUTOINCREMENT

```sql
CREATE TABLE Musteriler (
  ID    INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
  Kod   TEXT NOT NULL DEFAULT 'M000',
  Ad    TEXT NOT NULL DEFAULT 'İsimsiz'
);
INSERT INTO Musteriler(Ad) VALUES('Ali');   -- ID = 1 otomatik
```

Motor `INTEGER PRIMARY KEY` degeri verilmediginde **her zaman** otomatik artirir.
`AUTOINCREMENT` anahtar sozcugu bu davranisi **acikca belirtir** ve semada
kaydedilir; ayrica sunlar kabul edilir:

| Yazim | Anlami |
|---|---|
| `AUTOINCREMENT` / `AUTO_INCREMENT` | INTEGER PRIMARY KEY (MySQL yazimi) |
| `SERIAL` | tip olarak INTEGER + otomatik artma (PostgreSQL yazimi) |
| `IDENTITY[(seed,inc)]` | tip olarak INTEGER + otomatik artma (MSSQL yazimi) |

`IDENTITY`/`SERIAL` parantezli argumanlari kabul edilir ama **yok sayilir**
(seed/inc her zaman 1'dir). `AUTOINCREMENT` yalniz `INTEGER` kolonunda ve
`ALTER TABLE ... ADD` ile de kullanilabilir; baska bir tipte hata verir.

### Kolon ici kisitler

```sql
CREATE TABLE t (
  a INTEGER NOT NULL,
  b TEXT UNIQUE,
  c INTEGER DEFAULT 5,
  d INTEGER REFERENCES ebeveyn(id),     -- FK (hedef sutun verilmezse PK olur)
  e INTEGER CHECK (e > 0)               -- kolon ici CHECK
);
```

Tipler: `INTEGER|INT|BIGINT|SMALLINT`, `FLOAT|DOUBLE|REAL|DECIMAL|NUMERIC`,
`BOOLEAN|BOOL`, `DATE`, `DATETIME|TIMESTAMP`, `TIME`, `BLOB|BINARY`.
Diger her sey `TEXT` sayilir.

Sinirda taninip yok sayilan yazimlar: `DEFERRABLE`,
`NOT DEFERRABLE`, `INITIALLY DEFERRED`, `GENERATED ALWAYS AS (...)`.
(`COLLATE` yalniz `ORDER BY ... COLLATE TR` biciminde anlamlidir;
bkz. siralama notlari.)
Bilinmeyen bir anahtar sozcugu **sessizce yutulmaz**, hatayi soyleyerek verir
(`"FOO" taninmiyor (bu konumda , veya ) bekleniyor)`).

### BLOB (ikili veri: fotograf, belge)

```sql
CREATE TABLE foto(id INTEGER PRIMARY KEY, ham BLOB);
INSERT INTO foto(id, ham) VALUES(?, ?);   -- parametre ile (bayt aynen tasinir)
SELECT ham FROM foto WHERE id = 1;
SELECT LENGTH(ham) FROM foto;             -- bayt sayisi
```

Kurallar:
- `BLOB` ham bayttir: `Trim`, `NULL` literali cevimi, `UTF-8` normalize
  uygulanmaz. Gecersiz `UTF-8` (`C0`...), basi/sonu bosluk bayti
  (`<= $20`), icindeki `#0` ve `NULL` metni aynen korunur.
- `INSERT` icin `?` parametresi kullanin; SQL metnine gomulu ikili
  sabit desteklenmez.
- `EXPORT/IMPORT JSON` turu kayipsizdir (`#0` iceren hucre hex-nesne
  olarak yazilir). `LENGTH` metinde karakter, `BLOB`'da bayt sayar.
- Sinir: `TDataSet` (`TVDbQuery`) `BLOB`'u metin alani gibi gosterir;
  `#0` iceren degerler gridde kirpilir (motor verisi saglamdir).

### FOREIGN KEY aksiyonlari

```sql
CREATE TABLE coc (
  id  INTEGER PRIMARY KEY,
  pid INTEGER REFERENCES eb(id) ON DELETE CASCADE ON UPDATE SET NULL
);
```

| Yazim | Karsilik |
|---|---|
| (yok) / `RESTRICT` / `NO ACTION` | kullaniliyorsa hata (varsayilan) |
| `CASCADE` | ebeveyn silinince cocuk da silinir; ebeveyn `UNIQUE`/PK kolonu degisince cocuk FK kolonu yeni degere gelir |
| `SET NULL` | ebeveyn silinince cocuk FK kolonu NULL olur |
| `SET DEFAULT` | ebeveyn silinince cocuk FK kolonuna kolonun `DEFAULT` degeri yazilir (`DEFAULT` yoksa NULL) |

Hepsi tablo-seviyesinde de yazilabilir:

```sql
CREATE TABLE coc (
  id  INTEGER PRIMARY KEY,
  pid INTEGER,
  FOREIGN KEY (pid) REFERENCES eb(id) ON DELETE CASCADE
);
```

Aksiyonlar semada saklanir (dosyada 5 alanli olarak yazilir; **eski 3 alanli
sema dosyalari geriye uyumlu** okunur ve `RESTRICT` sayilir).

> **Iki asamali denetim.** Bir silme/guncellemede **tum** cocuk FK'lar once
> denetlenir; herhangi biri `RESTRICT` ise hicbir yazma yapilmadan hata
> verilir. Kaskadlar ancak denetim basarili olduktan sonra uygulanir.
> Aksi halde tablolarin siralamasina bagli olarak kismi kaskad yan etkileri
> birikirdi.

### FK tetikleyicisi hangi degisiklikte devreye girer

`UPDATE` sirasinda bir cocuk FK'nin `RefCol` degeri degisiyorsa
(UNIQUE olmasa bile) `ON UPDATE` aksiyonu uygulanir.

## 3. CREATE / DROP INDEX

```sql
CREATE INDEX ix_ad ON kisi(ad);
DROP INDEX ix_ad;
```

Indeks **bellek ici**, veriden turetilir; crash-safe (yeniden kurulur).
`WHERE <indexli kolon> = ...` hizli yoldan gider. `REINDEX` ile elle kurulur.

## 4. Veritabani olusturma / acma / silme / yedekleme

```sql
CREATE DATABASE satis;                  -- satis.odb (TEK dosya, klasor YOK)
CREATE DATABASE IF NOT EXISTS satis;
OPEN DATABASE satis;                    -- etkin veritabanini degistir
USE satis;                              -- OPEN DATABASE kisayolu
CLOSE DATABASE;                         -- kapat (dosya kilidi birakilir)
DROP DATABASE satis;                    -- sil  (etkin olan silinemez)
DELETE DATABASE satis;                  -- DROP ile ayni
LIST DATABASES;                         -- aktif olan '*' isaretli
SHOW DATABASES;                         -- ayni
BACKUP TO 'yedek.odb';                  -- tutarli yedek al
VERIFY;                                 -- salt-okunur butunluk denetimi
```

Yeni veritabani **etkin veritabaninin bulundugu klasore** olusur ve dosya adi
veritabani adiyla aynidir:

```
D:\veritabani\db\veritabani.odb   <- etkin
D:\veritabani\db\satis.odb        <- CREATE DATABASE satis;   (ayni klasor)
```

Veritabani adi **dosya adidir** (`veritabani.odb` -> `veritabani`), klasor adi
degil. Klasor icine gomulmez. `OPEN DATABASE satis.odb` da yazabilirsin
(uzanti otomatik atilir).

**`OPEN DATABASE` / `CLOSE` davranisi**
- Motor nesnesi **ayni kalir**; yalnizca dosya degisir. Programdaki
  `TVDb` / `TVTableDb` / `TVSql` referanslari gecerli olmaya devam eder.
- Acilis sonrasi **otomatik `Verify`** calisir; sonuc `Msg` alaninda yazar.
- **Var olmayan** veritabani icin bos dosya **OLUSTURULMAZ**; hata verir.
- `CLOSE DATABASE` sonrasi diger tum komutlar net hata verir:
  `veritabani kapali - OPEN DATABASE <ad> ile ac (LIST DATABASES)`.
- Bu komutlar otomatik transaction disindadir (karisirlik olmasin diye).

Once `\<ad>\veritabani.odb` (klasor) olarak olusturulmus veritabanlari da
okunur ve listelenir; `CREATE`/`DROP` var olan yerlesimi kullanir.
Guvenlik: ad `..`, yol ayirici (`\ / : * ? " < > |`) ve 64 karakterden uzun
ise reddedilir; **etkin** veritabani `DROP`/`DELETE` ile silinemez.

## 5. INSERT — coklu kayit

```sql
INSERT INTO t(a,b) VALUES (1,'x');     -- sutun listesi
INSERT INTO t VALUES (1,'x','y');       -- sutun listesi YOK -> sirayla
INSERT INTO t() VALUES ();              -- yalnizca DEFAULT'lar
INSERT INTO t DEFAULT VALUES;           -- kisayol
```

### COKMULU SATIR (virgulle ayrilmis deger gruplari)

```sql
INSERT INTO personel (ad, unvan, sehir, departman, maas) VALUES
('Mehmet', 'Yönetici', 'İstanbul', 'Yazılım', 9200),
('Samet',  'Uzman',   'Ankara',   'Finans',  4800),
('Kenan',  'Yönetici', 'İstanbul', 'Yazılım', 9700),
('Veli',   'Uzman',   'İzmir',    'Satış',   5200);
```

- Tüm gruplar **tek bir atomik batch** içinde yazılır: 4. satır `CHECK`
  ihlali verirse **hiçbiri** yazılmaz (yarım yazım = veri tutarsızlığı).
- `Affected` yazılan satır sayısıdır (4).
- Tüm grupların değer sayısı eşit olmak zorundadır; değilse hata verilir.
- `INSERT INTO t DEFAULT VALUES, DEFAULT VALUES` ve
  `INSERT INTO t() VALUES (), ()` da çoklu satır ekler.
- Artık token varsa hata verilir — `VALUES (1,'a') BLA` sessizce yutulmaz.

### INSERT INTO ... SELECT

```sql
INSERT INTO hedef(id, ad) SELECT id, ad FROM kaynak;
INSERT INTO hedef(ad, id) SELECT ad, id FROM kaynak WHERE id > 10;
```

Eşleme **pozisyoneldir**: hedef sutun listesi varsa sorgu çıktısının sırasıyla,
yoksa hedef tablonun tüm sütunlarıyla sırayla eşleşir. Sonuç da tek atomik
batch içinde yazılır.

### Deger / sutun sayisi kurali

```sql
CREATE TABLE t(a TEXT, b INTEGER);
INSERT INTO t(a,b) VALUES('x',1);   -- dogru
INSERT INTO t(a,b) VALUES('x');     -- HATA: sutun 2, deger 1
INSERT INTO t VALUES('x',1);        -- dogru (liste yok -> sirayla)
INSERT INTO t VALUES('x');          -- HATA: sutun 2, deger 1
```

Ayni sutun iki kez verilirse de hata verilir.

## 5b. BIRDEN FAZLA CUMLE (";" ile)

`Exec` betiği **`;` ile ayrılmış tüm cümleleri sırayla çalıştırır**:

```sql
CREATE TABLE t(id INTEGER PRIMARY KEY, v TEXT);
INSERT INTO t(v) VALUES ('a'),('b'),('c');
UPDATE t SET v = 'z' WHERE id = 2;
DELETE FROM t WHERE id = 3;
```

- `;` **tırnak dışında** böler: `VALUES ('a;b')` tek değerdir, `''` kaçışlı
  tırnak doğru sayılır.
- `Affected` tüm cümlelerin **toplamıdır**.
- `TSqlResult.Fields` / `.Rows`, **satır döndüren son** cümlenin sonucudur.
  INSERT/UPDATE/DELETE satır döndürmez → `Fields` boş kalır.
- `TSqlResult.LastTable` son cümlenin dokunduğu tabloyu tutar; arayüz
  (GUI) sonucu boşsa bu tabloyu yeniden çizer.
- `TSqlResult.Stmts` çalıştırılan cümle sayısıdır.
- Hatalı bir cümlede betik **durur**; *o ana kadar* uygulanan cümleler
  commit edilmiş olarak kalır (otomatik transaction yalnızca **tüm
  cümleler batch-uyumluysa** devreye girer; `StmtBatchSafe` dışı bir cümle
  varsa — örneğin `BEGIN`/`COMMIT`, `CREATE`/`DROP`/`DELETE DATABASE`,
  `VACUUM`, `VERIFY`, `EXPORT`/`IMPORT` — o cümleden itibaren otomatik
  batch kapatılır ve **cümleler tek tek (küme-atomik) commit edilir**).
  Tüm betiği tek transaction içinde geri almak için başına `BEGIN;`
  sonuna `COMMIT;`/`ROLLBACK;` ekleyin.
- `CREATE`/`DROP`/`DELETE DATABASE` gibi "dosya seviyesi" komutlar
  batch içinde geri alınamaz; `ROLLBACK` onların etkisini geri almaz.

## 6. SELECT

```sql
SELECT * FROM t;
SELECT a, b FROM t;
SELECT a AS x, b y FROM t;              -- AS'li ve AS'siz alias
SELECT COUNT(*) FROM t;
SELECT 1;                               -- FROM'suz: tek satir
SELECT 'abc' AS x, NULL, 2.5;
```

`FROM` yoksa tek satır döner. Alan adı değerin kendisidir (`AS` ile
değiştirilebilir). `FROM`'suz `SELECT`'te kolon kullanılamaz — tablo gerekiyorsa
`FROM` yazılmalıdır.

Tablo alias'ı da nitelemeli ad üretir:

```sql
SELECT x.ad FROM t x;                   -- SELECT, WHERE, ORDER BY, GROUP BY
SELECT x.ad FROM t x WHERE x.yas > 20 ORDER BY x.id;
```

### DISTINCT

```sql
SELECT DISTINCT dept FROM personel;
SELECT DISTINCT dept, unvan FROM personel;
SELECT DISTINCT * FROM personel;
SELECT DISTINCT dept FROM personel ORDER BY dept;
```

Tekillestirme **projeksiyon sonrasi, `OFFSET`/`LIMIT` oncesi** yapilir.
Boylece `SELECT DISTINCT d ... ORDER BY d LIMIT 2` 5 satirdan degil, 3 tekil
satirdan ilk 2'sini doner. `DISTINCT` sorgusu her zaman tam taramaya duser
(indexli hizli yol kullanilmaz), cunku tekillestirme `LIMIT`'tan once
uygulanmalidir.

### JOIN

```sql
SELECT t.a, e.ad
FROM t INNER JOIN ebeveyn e ON t.pid = e.id;

SELECT t.a, e.ad
FROM t LEFT JOIN ebeveyn e ON t.pid = e.id;   -- eslesmeyenlerde e.* NULL

SELECT t.a FROM cocuk c JOIN ebeveyn ON c.pid = ebeveyn.id;  -- nitelemeli
```

`INNER`, `LEFT`, `RIGHT` ve `FULL` var (`OUTER` yazimi opsiyonel:
`LEFT OUTER JOIN` = `LEFT JOIN`). `CROSS` **yok**.
**Zincir `JOIN` serbest** (soldan derine uygulanir, `A JOIN B JOIN C ...`);
turler karisabilir (`A LEFT JOIN B RIGHT JOIN C`).

```sql
SELECT p.ad, e.ad
FROM per p RIGHT JOIN eb e ON p.eid = e.id;   -- eslesmeyen eb satiri NULL-solla korunur

SELECT p.ad, e.ad
FROM per p FULL JOIN eb e ON p.eid = e.id;    -- iki taraf da korunur
```

Notlar:
- `RIGHT`/`FULL` klasik ic ice donguyle calisir (sol kume materyaldir,
  indeksli hizli yol uygulanamaz); cikti sirasi (sol kolonlar, sag
  kolonlar) degismez.
- Sonuc siniri: adim basi 2M satir (`ecLimit`).
- `JOIN` ile `GROUP BY`/`aggregate` birlikte kullanilamaz.

### Alt sorgular (iliskisiz)

```sql
SELECT ad FROM musteri WHERE bid IN (SELECT id FROM bolge);
SELECT ad FROM musteri WHERE bid NOT IN (SELECT id FROM bolge);
SELECT ad FROM musteri WHERE bid = (SELECT id FROM bolge WHERE ad = 'Ege');
SELECT ad FROM musteri WHERE EXISTS (SELECT id FROM bolge WHERE id = 1);
SELECT ad, (SELECT ad FROM bolge WHERE id = 1) AS b FROM musteri WHERE id = 1;
```

Kurallar:
- `IN` alt sorgusu **tek kolon** dondurmeli; skaler alt sorgu **tek satir
  x tek kolon** (satir yoksa `NULL`, cok satirsa hata).
- Ic sorgu **cumle basi bir kez** calisir (onbellekli); dis satir basina
  tekrar calismaz.
- **Iliskili** alt sorgu (ic sorgunun dis tabloya basvurmasi) desteklenmez:
  acik hata verir (`iliskili alt sorgu desteklenmiyor`).
- `NULL` kurali liste davranisiyla aynidir: `NULL` deger eslesmez,
  `NOT IN` belirsizligi satiri eler.

### WITH-CTE (gecici adlandirilmis sonuc)

```sql
WITH tr AS (SELECT id, ad FROM musteri WHERE bid = 1)
SELECT ad FROM tr ORDER BY id;

WITH e AS (SELECT id FROM musteri WHERE bid = 1),
     x AS (SELECT id FROM e WHERE id > 1)
SELECT * FROM x;

WITH m AS (SELECT id, bid FROM musteri WHERE bid IS NOT NULL)
SELECT b.ad FROM bolge b JOIN m ON m.bid = b.id;
```

Kurallar:
- Liste sirayla materyallestirilir; sonraki CTE oncekileri gorebilir.
- `FROM` ve `JOIN` taraflarinda kullanilabilir; `WHERE`/`GROUP BY`/
  `ORDER BY`/`LIMIT` aynen calisir. Tek-tablo ic sorgularda kolon
  tipleri korunur (sayisal kiyas/siralama dogru calisir).
- Desteklenmez: `WITH RECURSIVE`, kolon alias'lari (`x(a,b)`),
  `WITH` + `INSERT/UPDATE/DELETE` (acik hata verirler).

### Kosullu ifade (CASE)

```sql
SELECT ad, CASE WHEN yas >= 18 THEN 'resit' ELSE 'cocuk' END AS durum
FROM personel;

SELECT CASE sehir WHEN 'Ankara' THEN 1 WHEN 'Izmir' THEN 2 ELSE 0 END AS kod
FROM personel;

SELECT ad FROM personel
WHERE CASE WHEN maas > 5000 THEN 1 ELSE 0 END = 1;
```

Kurallar:
- Aranan (`WHEN kosul`) ve sade (`CASE x WHEN deger`) bicimler var;
  `WHEN...THEN` zincirlenebilir, `ELSE` opsiyoneldir (yoksa `NULL`).
- `SELECT`, `WHERE`, `ORDER BY` icinde calisir; ic ice `CASE` serbesttir.
- Sade bicimde `NULL` eslesmez; tip-bilgili kiyas yapilir
  (sayisal kolonda `20` ile `'20'` eslesir).

### Pencere fonksiyonlari (OVER)

```sql
SELECT ad, ROW_NUMBER() OVER (PARTITION BY bolge ORDER BY tutar) AS rn
FROM satis;

SELECT ad, RANK() OVER (PARTITION BY bolge ORDER BY tutar) AS r,
       DENSE_RANK() OVER (PARTITION BY bolge ORDER BY tutar) AS dr
FROM satis;

SELECT ad, SUM(tutar) OVER (PARTITION BY bolge) AS toplam,
       COUNT(*) OVER (PARTITION BY bolge) AS adet
FROM satis;

SELECT ad, LAG(ad) OVER (ORDER BY id) AS onceki,
       LEAD(ad, 2, 'yok') OVER (ORDER BY id) AS sonraki
FROM satis;
```

Kurallar:
- Desteklenenler: `ROW_NUMBER`, `RANK`, `DENSE_RANK`, `COUNT`, `SUM`,
  `AVG`, `MIN`, `MAX`, `LAG`, `LEAD`. Cerceve (`ROWS`/`RANGE`) yok:
  agregalar partition genelini hesaplar.
- `OVER` ici `PARTITION BY`/`ORDER BY` opsiyoneldir; bos `OVER ()`
  tum kumeyi tek partition sayar.
- `LAG`/`LEAD` varsayilan offseti 1'dir; ucuncu arguman partition
  disi icin varsayilan degerdir (yoksa `NULL`).
- Yalniz `SELECT` listesinde ust-duzey oge olarak kullanilabilir
  (`WHERE`/`HAVING`/`ORDER BY`/`JOIN ON` ve ic ice kullanim hata verir).
- `GROUP BY`/aggregate ile birlestirilemez; `ORDER BY` takma adla
  degil taban kolonla yazilir (motorun genel kurali).

### WHERE

Operatorler:

| Tur | Operatorler |
|---|---|
| karsilastirma | `=` `!=` `<>` `<` `>` `<=` `>=` |
| metin | `LIKE` / `NOT LIKE` (`%`, `?`, `_`) |
| kume | `IN (...)` / `NOT IN (...)`, `BETWEEN a AND b` / `NOT BETWEEN` |
| null | `IS NULL` / `IS NOT NULL` |
| mantik | `AND` `OR` `NOT` parantez |

```sql
WHERE a = 1
WHERE a <> 1
WHERE a >= 10 AND b = 'x'
WHERE a = 1 OR (b = 'x' AND c > 5)
WHERE ad LIKE 'A%'
WHERE ad IS NULL
WHERE ad IS NOT NULL
WHERE yas BETWEEN 18 AND 65
WHERE yas NOT BETWEEN 18 AND 65
WHERE sehir IN ('Izmir','Istanbul','Ankara')
WHERE sehir NOT IN ('Izmir','Istanbul')
WHERE NOT ad LIKE 'A%'
```

- `AND` / `OR` / parantez serbest karisim.
- `IS NULL` / `IS NOT NULL` **disinda hicbir operator NULL ile eslesmez**
  (`= NULL`, `<> NULL`, `> NULL`, `LIKE`, `IN`, `BETWEEN` dahil — hepsi
  0 satir doner). Tirnaksiz `NULL` literal deger WHERE'de de NULL sayilir.
- **NULL tarafi bilesik deger:** `x NOT IN (1,2,NULL)` satiri **dondurmez**
  (UNKNOWN), `x IN (1,2,NULL)` yalniz `x=1`/`x=2` ise dondurur.
- `IN (...)` icinde `?` parametresi kullanilabilir: `WHERE id IN (?,?,?)`.
- `IN (SELECT ...)` alt sorgu olarak calisir (bkz. alt sorgular bolumu).
- **Artik token reddedilir**: yazim hatasi ya da desteklenmeyen bir cumle
  sessizce yutulmaz, hata verir. (Sessizce yutulmak filtrelenmemis veri
  gosterirdi.)
- **`NOT (...)` tek kosul olmak zorunda.** Kosul temsili "OR'lu AND'ler"
  (DNF) oldugu icin `NOT (a=1 OR b=2)` ifade edilemez; bu yuzden De Morgan
  onerisi veren bir hata verilir: `a<>1 AND b<>2`.
  `NOT (a=1 AND b=2)` calisir.

### Tip-bilgili karsilastirma

Sadece **sayisal** kolonlarda deger sayisalla lastirilir:

```sql
-- y TEXT:  '007' ile '7' ESLESMEZ
-- n INTEGER: 7 ile '7' ESLESIR
```

Tirnaksiz sayi literal de metindir: `WHERE s = 7` TEXT kolonda `'7'` ile
karsilastirir (yani `'007'` ile eslesmez). `BETWEEN` de ayni kurali kullanir:
metin kolonda **byte (UTF-8) sirasi** esas alinir, `'007' < '7'`.

### Sayi bicimi her zaman nokta (locale bagimsiz)

```sql
INSERT INTO t(f) VALUES(2.5);     -- dogru
INSERT INTO t(f) VALUES(2,5);     -- HATA: virgul ayiractir, 2 deger olur
SELECT f FROM t;                  -- '2.5'  (tr-TR sistemde bile)
```

### Siralama / dilimleme

```sql
ORDER BY a                 -- varsayilan ASC
ORDER BY a DESC
ORDER BY a ASC, b DESC     -- coklu
LIMIT 10
LIMIT 10 OFFSET 20
OFFSET 20
```

`ORDER BY` **sorgunun en sonunda** yazilir. `OFFSET`/`LIMIT` sirali cikti
uzerinde uygulanir.

Siralama kurallari:

- **NULL (bos deger) her zaman en basta** siralanir; `DESC` ile en sonda.
- INTEGER kolonlar **tam sayi** olarak karsilastirilir (2^53'ten buyuk
  degerler de dogru siralanir).
- `ORDER BY <indeksli kolon>` indeksten okur; `LIMIT` kucukse yalnizca
  gereken kadar satir okunur (100.000 satirlik tabloda `LIMIT 10` ~0 ms).
- Indeks **tembel** kurulur: bir kolona ilk `ORDER BY`/`WHERE` yapilana kadar
  dosya acilisi beklemez. Indekslenmis bir tabloyu acmak, hicbir indeksi
  kullanmayan kadar hizlidir.

### GROUP BY + HAVING

```sql
SELECT dept, COUNT(*), SUM(maas), AVG(maas), MIN(maas), MAX(maas)
FROM personel
GROUP BY dept;
```

Aggregate fonksiyonlari: `COUNT`, `SUM`, `AVG`, `MIN`, `MAX`.

`HAVING` yalniz `GROUP BY` veya aggregate tasiyan `SELECT` ile kullanilabilir
ve **cikti alanlarina gore** cozumlenir:

```sql
SELECT dept, COUNT(*) AS adet FROM personel
GROUP BY dept HAVING adet > 2;

SELECT dept, SUM(maas) AS top FROM personel
GROUP BY dept HAVING top >= 400;

SELECT dept, COUNT(*) AS adet FROM personel
GROUP BY dept HAVING dept = 'satis';
```

Kurallar:
- `HAVING` **gruplama kolonu** ya da `SELECT` listesinde **alias verilmis bir
  aggregate** uzerinden yazilir.
- `HAVING COUNT(*) > 1` calismaz; `SELECT ... COUNT(*) AS adet ... HAVING adet > 1`
  yazin.
- `HAVING`'siz yazim `HAVING yalnizca GROUP BY veya aggregate ile kullanilabilir`
  hatasi verir (sessizce yutulmaz).

### Kume islemleri: UNION / UNION ALL / EXCEPT / INTERSECT

```sql
SELECT v FROM a UNION     SELECT v FROM b;   -- tekillestirir
SELECT v FROM a UNION ALL SELECT v FROM b;   -- tekrarlari korur
SELECT v FROM a EXCEPT    SELECT v FROM b;
SELECT v FROM a INTERSECT SELECT v FROM b;
SELECT v FROM a UNION SELECT v FROM b ORDER BY v LIMIT 2;
```

- Sutun sayilari esit olmak zorundadir, degilse hata verir.
- `ORDER BY` / `LIMIT` / `OFFSET` **birlesmis sonuca** uygulanir, sag
  tabloya degil. (Sag tabloya uygulansaydi sonuc fazla satir donerdi.)
- Anahtar sozcuk tirnak disinda, tam kelime olarak aranir: `'union'` gibi bir
  metin icindeki kelime operator sayilmaz.
- Zincirleme kullanilabilir (`a UNION b UNION c`).

### Skaler fonksiyonlar ve Turkce siralama

```sql
SELECT UPPER(ad), LOWER(sehir) FROM kisi;
SELECT LENGTH(ad) FROM kisi;            -- karakter sayisi (metin)
SELECT LENGTH(ham) FROM foto;           -- bayt sayisi (BLOB)
SELECT ad FROM kisi ORDER BY ad COLLATE TR;
SELECT ad FROM kisi ORDER BY ad COLLATE TR DESC;
SELECT ad FROM kisi WHERE UPPER(ad) = UPPER('cocuk');  -- harf duyarsiz arama
```

- `UPPER`/`LOWER` Turkce duyarlidir (`i->İ`, `I->ı`; sistem yerel
  ayarindan bagimsiz). `LENGTH` metinde karakter, `BLOB`'da bayt sayar.
- `COLLATE TR` Turk alfabesi sirasi uygular
  (`...c,ç,d...g,ğ,h,ı,i...o,ö,p...s,ş,t...u,ü,v...`); harf-disi
  karakterler kod noktasina gore harflerden once gelir. Bilinmeyen ad
  hata verir (yalniz `TR` desteklenir).
- `COLLATE TR` indeksi kullanmaz (indeks bayt duzenindedir); dogru ama
  yavas yola duser. `=` karsilastirmasi bayt-ayni kalir (degismedi).

## 7. UPDATE

```sql
UPDATE t SET a = 1;
UPDATE t SET a = 1, b = 'x' WHERE id = 5;
UPDATE t SET a = NULL WHERE id = 5;      -- NULL yazmak icin bos deger
```

`WHERE` yoksa **tum satirlar** guncellenir. UNIQUE / PK / CHECK / FK ihlali
hata verir; **degisen referans kolonunda** cocuk tabloya `ON UPDATE` aksiyonu
uygulanir (`CASCADE` cocuk FK kolonunu yeni degere ceker).

### SET icinde aritmetik (satir basina hesaplanir)

```sql
UPDATE t SET sayac = sayac + 1;             -- en sik kullanim
UPDATE t SET sayac = sayac - 1 WHERE id = 5;
UPDATE t SET puan  = puan * 2;
UPDATE t SET yarim = yarim / 2;              -- INTEGER kolonda tam bolme
UPDATE t SET kalan = kalan % 3;
UPDATE t SET toplam = fiyat * adet;          -- kolon + kolon
UPDATE t SET n = 5 WHERE id = 3;             -- duz deger (eski davranis)
```

Kurallar:

- Islemler: `+  -  *  /  %`. Sadece **sayisal** kolonlarda (INTEGER, FLOAT,
  BOOLEAN). Metin kolonda aritmetik **hata verir** (sessizce sayiya
  cevrilmez — veri bozulmaz).
- `/` INTEGER kolonda **tam bolmedir** (`7 / 2` -> `3`); FLOAT kolonda
  kayan nokta. Sifira bolme ve sifira modulo hata verir.
- Ifadenin **sol tarafı bir kolon olmak zorundadır**: `SET b = n * 2`
  -> `b := n * 2` (SQL semantiği; hedef kolon `b` degil, ifade `n * 2`).
- NULL baslayan bir kolonda `NULL + 1` sonucu **NULL** kalır.
- `LIMIT` yoktur; `WHERE` ile daraltın. Tum satirlarda ayni islem yapılacaksa
  tek `UPDATE ... WHERE ...` yazmak 5000 ayri komuttan hizlidir.

## 8. DELETE

```sql
DELETE FROM t;
DELETE FROM t WHERE id = 5;
```

Cocuk tablo varsa `ON DELETE` aksiyonu uygulanir; `RESTRICT` ise silmeyi
engeller. Ayni anda birden fazla cocuk varsa once hepsi denetlenir.

## 9. Bakim

```sql
SHOW TABLES;          -- tablo + satir sayilari
VACUUM;               -- compact: olu surumler + tombstone'lari temizler (.bak birakir)
REINDEX;              -- bellek indekslerini veriden yeniden kurar
```

## 10. JSON degisim

```sql
EXPORT JSON 'yedek.json';                -- sema + tum veri
EXPORT TABLE kisi JSON 'kisi.json';      -- tek tablo
IMPORT JSON 'yedek.json';                -- sema dahil (pk/notnull/unique/
                                        -- default/checks/fks/aksiyonlar)
```

## 11. Parametreli calistirma (SQL metninde tek tirnak gerekmez)

```pascal
r := sq.Exec('SELECT * FROM t WHERE ad = ? AND yas > ?', ['Ali', '20']);
```

`?` sirayla `Params` dizisinden gelir. Tirnak/escape sorunu olmaz.

---

## Desteklenmeyenler (bilerek yok)

- Iliskili alt sorgu (ic sorgunun dis tabloya basvurmasi)
- `WITH RECURSIVE`, `WITH` kolon alias'lari, `WITH` + DML
- Pencere cercevesi (`ROWS`/`RANGE`)
- `CROSS` JOIN
- `JOIN` ile `GROUP BY`/`aggregate` birlikte
- `HAVING` icinde aggregate'i dogrudan yazmak (`HAVING COUNT(*) > 1`) -
  alias kullanin
- `NOT (...)` icinde `OR`'lu ifade (DNF temsili bunu ifade edemez)
- `ALTER TABLE ... ADD/DROP CONSTRAINT` (CHECK/FK kolon uzerinden dolayli guncellenir)
- `CREATE VIEW`, `CREATE TRIGGER`, `CREATE PROCEDURE`
- `PRAGMA` (bilgi `SHOW` komutlariyla veriliyor)

## Semantik notlari

- **NULL = bos deger.** `''` ile NULL ayni sey; ayri "bos string" kavrami yok.
  `WHERE` tarafinda uc-degerli mantik: `IS NULL` disinda hicbir operator
  NULL'a eslesmez. `CHECK` tarafinda ise **bilinmez ihlal sayilmaz**:
  `CHECK (p >= 0)` olan opsiyonel bir kolona NULL yazabilirsin; yalniz
  kosulun kesin `FALSE` olmasi ihlaldir.
  *(F1-14 ile uyumlandi: `=`, `<>`, `<`, `<=`, `>`, `>=` ve `LIKE`
  bir tarafi NULL ise sonuc `UNKNOWN` (`''`) doner. Boylece
  `NOT (NULL = 1)` artik `TRUE` degil `UNKNOWN` -> satir filtreye girmez.
  WHERE'de NULL satirlari zaten eleniyordu; degisim `SELECT NULL = 1`
  gibi deger gosteren ifadelerde ve `NOT` ile zincirlenmis
  kosullarda gorunur.)*
- **Atomik batch:** `COMMIT` bir `BATCHEND` isareti + tek fsync yazar.
  Recovery isareti gormeden onceki kayitlari geri sarar.
- **Batch ici gorunurluk:** `BEGIN` ile acikken yazilan satirlar ayni
  transaction icindeki `SELECT`/`UPDATE`/`DELETE` ve kisit denetimlerinde gorunur.
- **PK arama O(1):** `WHERE pk = x` dogrudan hash anahtarindan okur.
- **ALTER TABLE** satirlari yeniden kodlar; donusturulemeyen deger hata verir
  (sessiz veri kaybi yok). `ADD COLUMN` ile eklenen kolonun `DEFAULT`'u eski
  satirlara **yazilmaz** (yeni kolon NULL kalir) — standart SQL de ayni seyi yapar.
- **Sayi/tarih cikti bicimi locale'den bagimsiz**: ondalik `nokta`,
  tarih `YYYY-MM-DD`, tarih-saat `YYYY-MM-DD HH:MM:SS`, saat `HH:MM:SS`.
- **Yazilim dosya surumu:** `VDB_FILE_VER = 2`. Eski surumlu dosyalar ilk
  acilista yerinde yukseltilir; daha yeni surumlu dosyalar temiz bir hatayla
  reddedilir (veri bozulmaz).
- **`ORDER BY` bilinmeyen kolon hatasi (F1-21).** `ORDER BY yokBoyleBirKolon`
  artik sessizce yok sayilmaz; `ecColumnNotFound` verir. Once giris sirasiyla
  donuyordu, yani sonuc kararsizdi. `ORDER BY <alias>` yazimi **taban kolon**
  adini gostermelidir (`SELECT ... AS adet ... ORDER BY adet` -> `ORDER BY adet`
  calisir, `ORDER BY 1` ve ifade-ORDER BY desteklenmez ve `kidx<0` oldugu icin
  hata verir).
- **Set-op kuyrugu (F1-11/F1-12).** `UNION`/`UNION ALL`/`EXCEPT`/`INTERSECT`
  icin `ORDER BY`, `OFFSET` ve `LIMIT` **birlestirme sonrasina** uygulanir:
  `SELECT id FROM a UNION SELECT id FROM b ORDER BY id LIMIT 2 OFFSET 1`
  -> once iki taraf birlestirilir, sonra siralanir, sonra kirpilir.
  Sutun sayilari esit degilse `ecSyntaxError` verilir (eski matris
  karsilastirilirdi). aggregate/`GROUP BY` ile set-op birlestirilemez
  (`ecUnsupported`).
- **`OFFSET` yazimlari (F1-10).** `LIMIT n OFFSET m`, `OFFSET m LIMIT n` ve
  `OFFSET m` (limit'siz) desteklenir. Negatif veya sayi disi deger
  `ecSyntaxError`/`ecLimit` verir (sessizce yutulmaz).
- **Satir sirasi garantisi yok.** `ORDER BY` kullanilmayan bir `SELECT` satir
  sirasi garantisi vermez (indeks/PK okuma sirasi olabilir). Testlerde ve
  uygulamada belirli satir bekleniyorsa `ORDER BY` yazilmalidir.
- **`UPDATE` `ON DELETE CASCADE` tetiklemez (F1-4 tamamlayici).** Satir
  yerinde guncellenir (`Delete`+`Insert` DEGIL). `ON DELETE CASCADE` yalniz
  gercek `DELETE` cumlesinde calisir; `ON UPDATE CASCADE` ise bir cocuk FK'nin
  `RefCol`u degistiginde calisir. Ilgisiz kolonun guncellenmesi hicbir cocuk
  satiri etkilemez. `UPDATE` PK kolonunu **guncelleyemez** (`ecUnsupported`).
- **`UPDATE` bilinmeyen kolon hatasi (F1-16).** `UPDATE t SET yok = 1`
  `ecColumnNotFound` verir; eskiden atlanir, satir silinip aynen yazilirdi.
- **`UPDATE ... SET` aritmetigi satira gore hesaplanir** (`SET n = n + 1`).

## F2 Notlari (2026-10-04)

Bu bolum F2 duzeltmeleriyle motorun SEMANTIGININ degistigi yerleri belgeler.
Ayrica F2 sirasinda iki yeni gercek hata bulundu ve duzeltildi: **F2-22**
(PK'siz tablo) ve **F2-23** (`CREATE UNIQUE INDEX`).

### Tablo anahtari (F2-22) - KRITIK ANLAM DEGISIMI

`PRIMARY KEY` tanimlanmamis bir tabloda **ilk kolon artik anahtar degildir**.
`CREATE TABLE t(a TEXT, b TEXT)` ile:

- `a` kolonu UNIQUE degildir. Ayni `a` degeriyle **cok satir** eklenebilir
  (eskiden `duplicate PK` hatasi veriyordu).
- `a` kolonu `DROP COLUMN` / `ALTER COLUMN ... TYPE` / `SET NOT NULL`
  kisitlarindan muaftir (eskiden "PK kolonu dusurulemez" ile reddediliyordu).
- Satirlar motor tarafindan uretilen **sentetik anahtarla** (`@1`, `@2`, ...)
  ayirt edilir. Bu anahtar semada kalicidir; yeniden acilista korunur.
  `UPDATE`/`DELETE` bu anahtarla calisir.
- PRIMARY KEY tanimlanmis tabloda davranış **degismedi**.

### UNIQUE (F2-23)

`CREATE UNIQUE INDEX` artik **gercekten zorlanir** (tek ve cok kolonlu).
Daha once `UNIQUE` kelimesi parser'da yutuluyor, motora tasinmiyordu; sonuc
komut sessizce HIC BIR SEY yapmiyordu. Kisit `INSERT` ve `UPDATE` sirasinda
denetlenir ve semada saklanir (yeniden acilista da gecerlidir).
Kolon seviyesi `col TEXT UNIQUE` zaten zorlaniyordu ve degismedi.

### Diger F2 davranislari

- **Kendine referansli FK artik kurulabilir** (`dugum(id, parent REFERENCES
  dugum(id))`). `DELETE`/`UPDATE CASCADE` zincirinde dongu `FCascadeDepth`
  ile korunur (azami 32).
- **`ALTER COLUMN` PK ve FK kaynak kolonlarinin tipini degistiremez** ve yeni
  tipte mevcut satirlar `CHECK`/`NOT NULL` kurallarina gore yeniden dogrulanir.
- **`DROP COLUMN`, kolonu iceren indeksleri de kaldirir** (cok kolonlu indeks
  dahil) ve bekleyen indeks islemlerini temizler.
- **`DROP TABLE`, cocuk tablolarda o tabloya isaret eden FK*TANIMLARINI* da
  kaldirir**; aksi halde cocuk tablo kalici olarak kullanilamaz hale geliyordu.
- **`ORDER BY` artik `SELECT` alias'ina gore calisir**
  (`... AS rn ... ORDER BY rn`) ve `SELECT` listesinde olmayan bir taban
  kolona gore de siralama yapabilir. Tanimsiz kolon `ecColumnNotFound` verir.
- **`IN (SELECT ...)`** deger kumesi alt sorgu basina bir kez kurulur.
  Iliskili (correlated) alt sorgular desteklenmez.
- **`DROP`/`RENAME` sonrasi "kasitli silindi" isareti kalici semaya
  yazildiktan sonra temizlenir.**

### DDL ve butunluk

`ALTER TABLE` veri yeniden kodlamasi ile sema yazimini **tek batch'te** yapar;
hata halinde ikisi de geri alinir. `CREATE TABLE` bos ad reddedilir.
Bozuk sema satiri `ecSchemaCorrupt` ile reddedilir (sessizce atlanmaz).
Bozuk/yarim dosya `EVDbException(ecCorrupt)` ile acilamaz.

### F3-7 notu: cok kolonlu indeks ve "leading column" kurali

`CREATE INDEX ix ON t(a, b, c)` kuruldugunde `WHERE a = 10` filtresi indeksin
**ilk kolonu** uzerinden arar (gercek RDBMS'lerin leading-column kurali).
`WHERE b = 200` (ilk kolon degil) indeks kullanmaz, tam tarama yapar.

Bu kural **dogru uygulanir**: `WHERE a = 10` yalnizca `a = 10` olan satirlari
doner; `a` ek bir filtreyle birlikte verilirse ikisi de uygulanir.
Cok kolonlu indeks, ilk kolona uygulanan `=` / `<=` / `>` / `>=` /
`BETWEEN` / `IN` filtrelerinde satirlari **dikkate almaz**; sonuc her zaman
tam dogrulanir.