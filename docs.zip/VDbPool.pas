unit VDbPool;

{ Baglanti havuzu: tek motor (TVDb/TVTableDb) uzerinde N adet TVSql ornegi.
  Kullanim (REST sunucusu is parcasi basina):

    Sq := Pool.Acquire;           // bosalana kadar bekler (zaman asimli)
    try
      R := Sq.Exec('SELECT ...', [...]);
      ...
    finally
      Pool.Release(Sq);
    end;

  Ya da tek satirlik: R := Pool.Exec('SELECT ...');

  NEDEN TEK MOTOR: .odb dosyasi exclusive kilitlidir (VDbSync); ayni
  dosyaya ikinci baglanti acilamaz. Havuz, motoru paylasan TVSql
  orneklerini yonetir (her ornek bir thread'e aittir; guvenlik P3
  kilitleriyle saglanir). Havuz paralellik CARPMaz, kaynak kullanimini
  SINIRLAR (asiri yukte kuyruk + zaman asimi).

  Kurallar:
  - Acquire bos havuzda TimeoutMs kadar bekler, sonra ecPoolTimeout.
  - Kapanmis havuzdan Acquire ecPoolClosed verir.
  - Havuza ait olmayan ornek Release edilirse ecInvalidArgument.
  - Free oncesi tum baglantilar Release edilmelidir (edilmeyenler
    serbest birakilir; kayip sayisi kapanista yoksayilir).
}

{$mode delphi}

interface

uses
  Classes, SysUtils, SyncObjs, Generics.Collections, VDbTable, VDbSql,
  VDbAst, VDbErr;

type
  TVDbPool = class
  private
    FTb: TVTableDb;
    FSize: Integer;
    FLock: TCriticalSection;
    FAvail: TEvent;               // bosta baglanti sinyali
    FIdle: TList<TVSql>;          // bosta ornekler
    FAll: TList<TVSql>;           // havuzun urettigi tum ornekler (sahiplik)
    FOut: Integer;                // disaridaki ornek sayisi
    FClosed: Boolean;
    FTimeoutMs: Integer;
  public
    constructor Create(ATableDb: TVTableDb; ASize: Integer = 8;
      ATimeoutMs: Integer = 5000);
    destructor Destroy; override;
    // Kullanimlik ornek al (yoksa TimeoutMs bekler).
    function Acquire: TVSql;
    // Geri ver (baska thread uyandirilir).
    procedure Release(Sql: TVSql);
    // Kapat: yeni Acquire reddedilir, bekleyenler hata ile uyanir.
    // Geri gelen baglantilar serbest kalir.
    procedure Close;
    // Tek seferlik: al + calistir + geri ver.
    function Exec(const Sql: string): TSqlResult; overload;
    function Exec(const Sql: string; const Params: array of string): TSqlResult; overload;
    property Size: Integer read FSize;
    property TimeoutMs: Integer read FTimeoutMs write FTimeoutMs;
    // Su an disaridaki ornek sayisi (gozlem).
    function ActiveCount: Integer;
  end;

implementation

constructor TVDbPool.Create(ATableDb: TVTableDb; ASize: Integer;
  ATimeoutMs: Integer);
var
  i: Integer;
begin
  inherited Create;
  if ATableDb = nil then
    raise EVDbException.Create(ecInvalidArgument,
      'TVDbPool: tablo katmani verilmedi');
  if ASize < 1 then ASize := 1;
  FTb := ATableDb;
  FSize := ASize;
  FTimeoutMs := ATimeoutMs;
  FLock := TCriticalSection.Create;
  // Manuel-reset degil: tek bekleyeni uyandirir (otomatik sifirlanir).
  FAvail := TEvent.Create(nil, False, False, '');
  FIdle := TList<TVSql>.Create;
  FAll := TList<TVSql>.Create;
  for i := 1 to FSize do
  begin
    FIdle.Add(TVSql.Create(FTb));
    FAll.Add(FIdle[FIdle.Count - 1]);
  end;
  FOut := 0;
  FClosed := False;
end;

destructor TVDbPool.Destroy;
var
  i: Integer;
begin
  FLock.Enter;
  try
    FClosed := True;
    for i := 0 to FIdle.Count - 1 do
      FIdle[i].Free;
    FIdle.Free;
    FAll.Free;
    // Disaridaki ornekler uygulamaya aittir (dokumante); burada
    // serbest birakilmaz (cift-free riski).
  finally
    FLock.Leave;
  end;
  FAvail.Free;
  FLock.Free;
  inherited;
end;

function TVDbPool.Acquire: TVSql;
var
  W: TWaitResult;
begin
  FLock.Enter;
  try
    if FClosed then
      raise EVDbException.Create(ecPoolClosed,
        'TVDbPool: havuz kapali');
    if FIdle.Count > 0 then
    begin
      Result := FIdle[FIdle.Count - 1];
      FIdle.Delete(FIdle.Count - 1);
      Inc(FOut);
      if FIdle.Count = 0 then
        FAvail.ResetEvent;
      Exit;
    end;
  finally
    FLock.Leave;
  end;
  // Bos: sinyal ya da zaman asimi.
  W := FAvail.WaitFor(FTimeoutMs);
  FLock.Enter;
  try
    if FClosed then
      raise EVDbException.Create(ecPoolClosed,
        'TVDbPool: havuz kapali');
    if (W = wrSignaled) and (FIdle.Count > 0) then
    begin
      Result := FIdle[FIdle.Count - 1];
      FIdle.Delete(FIdle.Count - 1);
      Inc(FOut);
      if FIdle.Count = 0 then
        FAvail.ResetEvent;
      Exit;
    end;
    raise EVDbException.CreateFmt(ecPoolTimeout,
      'TVDbPool: %d ms icinde bosta baglanti yok (boyut=%d)',
      [FTimeoutMs, FSize]);
  finally
    FLock.Leave;
  end;
end;

procedure TVDbPool.Release(Sql: TVSql);
var
  i: Integer;
  Found: Boolean;
begin
  if Sql = nil then Exit;
  FLock.Enter;
  try
    // Havuzun uretmedigi ornek geri verilemez (programlama hatasi).
    Found := False;
    for i := 0 to FAll.Count - 1 do
      if FAll[i] = Sql then
      begin Found := True; Break; end;
    if not Found then
      raise EVDbException.Create(ecInvalidArgument,
        'TVDbPool: havuza ait olmayan baglanti');
    for i := 0 to FIdle.Count - 1 do
      if FIdle[i] = Sql then
      begin Found := False; Break; end;
    if not Found then
      raise EVDbException.Create(ecInvalidArgument,
        'TVDbPool: baglanti zaten havuzda (cift Release?)');
    Dec(FOut);
    if FClosed then
    begin
      // Kapanista geri gelenler dogrudan serbest kalir (listeden de duser).
      FAll.Remove(Sql);
      Sql.Free;
    end
    else
    begin
      FIdle.Add(Sql);
      FAvail.SetEvent;
    end;
  finally
    FLock.Leave;
  end;
end;

procedure TVDbPool.Close;
begin
  FLock.Enter;
  try
    FClosed := True;
    // Bekleyen Acquire'lar hata ile uyanir.
    FAvail.SetEvent;
  finally
    FLock.Leave;
  end;
end;

function TVDbPool.Exec(const Sql: string): TSqlResult;
var
  Q: TVSql;
begin
  Q := Acquire;
  try
    Result := Q.Exec(Sql);
  finally
    Release(Q);
  end;
end;

function TVDbPool.Exec(const Sql: string;
  const Params: array of string): TSqlResult;
var
  Q: TVSql;
begin
  Q := Acquire;
  try
    Result := Q.Exec(Sql, Params);
  finally
    Release(Q);
  end;
end;

function TVDbPool.ActiveCount: Integer;
begin
  FLock.Enter;
  try
    Result := FOut;
  finally
    FLock.Leave;
  end;
end;

end.
