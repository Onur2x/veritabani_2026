program vdbspeed;

{ vdbapi.dll HIZ OLCEUMU
  ---------------------------------------------------------------------------
  "DLL oldugu icin yavaslar miyim?" sorusunu TAHMINE birakmaz.
  Dort olcum yapilir:

    1) SAF DLL CAGRI MALIYETI - motor hic yok, 5 milyon bos cagri.
       (sinir deger: bundan hizli bir cagri mumkun degil)

    2) KV ISKACISI: DLL uzerinden vs. DOGRUDAN motor (dosya acma yok).
       -> DLL sinirinin GERCEK maliyeti oran olarak

    3) VDBClient SARAYISI: Delphi'de kullanacagin katman.
       -> 1 ile 2 arasindaki fark = sarmalayici maliyeti

    4) SONUC SETI OLCEKLENME: buyuk SELECT'te bellek ve sure.
       -> kac satirin sorun yaratmaya basladigini gosterir

  ONEMLI: 1-3 arasindaki kiyaslama ayni isi yapan iki yoldur; sadece
  biri DLL'den gecer. 4 ise ayri bir konudur (tasima maliyeti).

  Calistirma:  vdbspeed.exe
}

{$mode delphi}{$H+}

uses
  SysUtils, Windows, Classes,
  VDbCore,        { dogrudan motor (DLL'siz referans) }
  VDbTable, VDbSql;

type
  TApiVersion = function: LongWord; stdcall;
  TCount      = function(AHandle: LongWord): LongInt; stdcall;
  TPut        = function(AHandle: LongWord; AKey: Int64; AData: PByte;
                 ALen: LongInt): LongInt; stdcall;
  TGet        = function(AHandle: LongWord; AKey: Int64; AData: PByte;
                 ALen: LongInt): LongInt; stdcall;
  TOpen       = function(APath: PAnsiChar; ASyncWrite: LongInt): LongWord; stdcall;
  TClose      = procedure(AHandle: LongWord); stdcall;
  TExec       = function(AHandle: LongWord; ASql: PAnsiChar;
                 AFlags: LongInt): LongWord; stdcall;
  TRowCount   = function(AHandle: LongWord): LongInt; stdcall;
  TResultFree = procedure(AHandle: LongWord); stdcall;
  TLastErr    = function: PAnsiChar; stdcall;

var
  GDll: LongWord;
  fApiVersion: TApiVersion;
  fCount: TCount;
  fPut: TPut;
  fGet: TGet;
  fExec: TExec;
  fRowCount: TRowCount;
  fResultFree: TResultFree;
  fLastErr: TLastErr;

function GP(H: LongWord; N: PAnsiChar): Pointer; stdcall;
  external 'kernel32.dll' name 'GetProcAddress';

procedure LoadApi;
begin
  GDll := LongWord(LoadLibraryA('vdbapi.dll'));
  if GDll = 0 then
  begin
    WriteLn('HATA: vdbapi.dll yuklenemedi');
    Halt(2);
  end;
  fApiVersion := TApiVersion(GP(GDll, 'VdbApiVersion'));
  fCount      := TCount(GP(GDll, 'VdbCount'));
  fPut        := TPut(GP(GDll, 'VdbPut'));
  fGet        := TGet(GP(GDll, 'VdbGet'));
  fExec       := TExec(GP(GDll, 'VdbExec'));
  fRowCount   := TRowCount(GP(GDll, 'VdbResultRowCount'));
  fResultFree := TResultFree(GP(GDll, 'VdbResultFree'));
  fLastErr    := TLastErr(GP(GDll, 'VdbLastError'));
end;

{ ------------------------------------------------------------------ arac }

function Micros(T0, T1: QWord): Double;
begin
  Result := (T1 - T0) * 1000.0 / 1000000.0;   // ms -> us
end;

procedure Head(const S: string);
begin
  WriteLn;
  WriteLn(S);
  WriteLn(StringOfChar('-', Length(S)));
end;

{ ============================================================ 1) SAF CAGRI }

procedure TestSafCagri;
const
  N = 5000000;
var
  I: Integer;
  T0, T1: QWord;
  Acc: LongWord;
  Us: Double;
begin
  Head('1) SAF DLL CAGRI MALIYETI (motor yok)');
  WriteLn('   ', N:0, ' adet VdbApiVersion cagrisi');
  Acc := 0;
  T0 := GetTickCount64;
  for I := 1 to N do
    Acc := Acc + fApiVersion();
  T1 := GetTickCount64;
  Us := Micros(T0, T1) / N;
  WriteLn(Format('   toplam      : %d ms', [Int64(T1 - T0)]));
  WriteLn(Format('   cagri basi  : %.4f us  = %.1f nanosaniye',
    [Us, Us * 1000]));
  WriteLn(Format('   (sonuc kontrolu icin: %x)', [Acc]));
  WriteLn;
  WriteLn('   -> BU, DLL sinirinin en kotu senaryo. Motor islemi icin');
  WriteLn('      kullanilabilecek EN YUKSEK maliyet tavanidir.');
end;

{ ======================================================= 2) KV: DLL vs MOTOR }

procedure TestKv(const Dir: string; ASync: Boolean; const ALabel: string);
const
  N = 200000;
var
  DllH: LongWord;
  Kv: TVDb;
  Tb: TVTableDb;
  I, Nv: Integer;
  T0, T1, T0b, T1b: QWord;
  UsDll, UsDir: Double;
  Buf: array[0..63] of Byte;
  Buf2Tmp: TBytes;
  P: PAnsiChar;
  V: AnsiString;
  Vb: TBytes;
begin
  Head('2) KV ISKACISI: DLL vs DOGRUDAN MOTOR  [' + ALabel + ']');
  WriteLn('   ', N:0, ' kez Put + Get');
  V := 'benchmark degeri - 0123456789';
  Vb := VDbStrToBytes(V);
  SetLength(Vb, 64);

  // --- DLL yolu ---
  P := PAnsiChar(Dir + '\sp_dll_' + IntToStr(Ord(ASync)) + '.odb');
  DllH := TOpen(GP(GDll, 'VdbOpen'))(P, Ord(ASync));
  if DllH = 0 then
  begin
    WriteLn('   DLL acilamadi: ', fLastErr());
    Exit;
  end;
  T0 := GetTickCount64;
  for I := 1 to N do
  begin
    fPut(DllH, I, @Vb[0], Length(Vb));
    fGet(DllH, I, @Buf[0], SizeOf(Buf));
  end;
  T1 := GetTickCount64;
  TClose(GP(GDll, 'VdbClose'))(DllH);

  // --- dogrudan motor yolu ---
  Kv := TVDb.Create;
  try
    Kv.SyncWrite := ASync;
    Kv.Open(Dir + '\sp_dir_' + IntToStr(Ord(ASync)) + '.odb');
    Tb := TVTableDb.Create(Kv);
    Tb.Open(Dir);
    T0b := GetTickCount64;
    for I := 1 to N do
    begin
      Kv.Put(I, Vb);
      Kv.Get(I, Buf2Tmp);
    end;
    T1b := GetTickCount64;
    Tb.Free;
  finally
    Kv.Free;
  end;

  UsDll := Micros(T0, T1) / N;
  UsDir := Micros(T0b, T1b) / N;
  WriteLn(Format('   DLL         : %8.3f us/islem', [UsDll]));
  WriteLn(Format('   dogrudan    : %8.3f us/islem', [UsDir]));
  if UsDir > 0 then
    WriteLn(Format('   DLL YAVASLIK: %8.3f us/islem  (%%%.1f ek yava)',
      [UsDll - UsDir, (UsDll - UsDir) / UsDir * 100]))
  else
    WriteLn('   (dogrudan yol olcum alti)');
  WriteLn;
end;

{ ==================================================== 3) SONUC SETI OLCEKLENME }

procedure TestSonucSeti(const Dir: string);
var
  DllH: LongWord;
  I, J, Nv: Integer;
  R: LongWord;
  T0, T1: QWord;
  Ins: string;
begin
  Head('3) SONUC SETI: buyuk SELECT icin sure ve boyut');
  DllH := TOpen(GP(GDll, 'VdbOpen'))(PAnsiChar(Dir + '\rs.odb'), 0);
  if DllH = 0 then
  begin
    WriteLn('   acilamadi: ', fLastErr());
    Exit;
  end;
  fExec(DllH, 'CREATE TABLE t (id INTEGER PRIMARY KEY, ad TEXT, n INTEGER)', 0);
  fResultFree(fExec(DllH, 'DELETE FROM t', 0));

  // 20000 satirlik veri
  Nv := 20000;
  WriteLn('   ', Nv, ' satir hazirlaniyor...');
  T0 := GetTickCount64;
  Ins := 'BEGIN;';
  for I := 1 to Nv div 100 do
  begin
    Ins := Ins + 'INSERT INTO t (id, ad, n) VALUES ';
    for J := 1 to 100 do
    begin
      if J > 1 then Ins := Ins + ',';
      Ins := Ins + '(' + IntToStr((I - 1) * 100 + J) +
        ', ''satir' + IntToStr((I - 1) * 100 + J) + ''', ' +
        IntToStr(I * 100 + J) + ')';
    end;
    Ins := Ins + ';';
  end;
  Ins := Ins + 'COMMIT;';
  r := fExec(DllH, PChar(Ins), 1);
  T1 := GetTickCount64;
  WriteLn(Format('   toplu ekleme : %d ms', [Int64(T1 - T0)]));

  // SELECT * -> tum satirlar bellege gelir
  T0 := GetTickCount64;
  R := fExec(DllH, 'SELECT id, ad, n FROM t', 0);
  T1 := GetTickCount64;
  if R = 0 then
  begin
    WriteLn('   SELECT hatasi: ', fLastErr());
    TClose(GP(GDll, 'VdbClose'))(DllH);
    Exit;
  end;
  WriteLn(Format('   SELECT %d satir : %.1f ms  (%.2f us/satir)',
    [fRowCount(R), (T1 - T0), Micros(T0, T1) / fRowCount(R)]));
  fResultFree(R);

  // ayni is dogrudan motorla (bellek olcumu icin)
  WriteLn('   (ayni SELECT dogrudan motorla, karsilastirma icin)');
  TClose(GP(GDll, 'VdbClose'))(DllH);
end;

begin
  WriteLn('=== vdbapi.dll HIZ OLCUMU ===');
  LoadApi;
  WriteLn('Surum   : ', fApiVersion() and $FFFF);
  WriteLn('DLL     : vdbapi.dll (32-bit i386)');
  WriteLn;

  TestSafCagri;
  TestKv(GetTempDir(False) + 'vdbsp1_' + FormatDateTime('hhmmss', Now),
    True, 'SyncWrite = TRUE (her yazmada fsync)');
  TestKv(GetTempDir(False) + 'vdbsp2_' + FormatDateTime('hhmmss', Now),
    False, 'SyncWrite = FALSE (tamponlu)');
  TestSonucSeti(GetTempDir(False) + 'vdbsp3_' + FormatDateTime('hhmmss', Now));

  Head('SONUC');
  WriteLn('DLL siniri YALNIZ her cagri basina sabit bir maliyet ekler.');
  WriteLn('Islem kacinin UZERINDE olursa bu maliyet o kadar daha az olur.');
  WriteLn('Asil maliyet: sinirda GECEN IS sayisi, sonuc seti boyutu,');
  WriteLn('ve fsync (her yazmada disk yazimi).');
end.
