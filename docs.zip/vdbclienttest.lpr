program vdbclienttest;

{ VDBClient PAS BIRIMI TESTI
  ---------------------------------------------------------------------------
  Bu test DLL ABI'sini dogrudan (GetProcAddress) degil, `VDBClient.pas`
  sarayisini kullanir. Boylece ikinci katmandaki hatalar da yakalanir:
  iki asamali Get, hata kodlarinin ayirt edilmesi, metin/bayt donusumleri,
  sonuc seti kopyalama, istisna turleri.

  DKG (vdbapitest.exe) ABI'yi disaridan dener; bu test onu SARAR.

  Calistirma:  vdbclienttest.exe [veritabani-klasoru]
}

{$mode delphi}{$H+}

uses
  SysUtils, Classes, VDbClient;

var
  nPass, nFail, nGrp: Integer;
  grpName: string;
  tmpDir: string;

procedure Grp(const N: string);
begin
  Inc(nGrp);
  grpName := N;
  WriteLn;
  WriteLn('== ', nGrp, '. ', N);
end;

procedure Ok(const Nm, E: string);
begin
  Inc(nPass);
  if E = '' then WriteLn('   OK   ', Nm)
  else WriteLn('   OK   ', Nm, '   [', E, ']');
end;

procedure No(const Nm, E: string);
begin
  Inc(nFail);
  WriteLn('   FAIL ', Nm, '   [', E, ']  (grup: ', grpName, ')');
end;

procedure Tst(const Nm: string; Cond: Boolean; const E: string = '');
begin
  if Cond then Ok(Nm, E) else No(Nm, E);
end;

{ ------------------------------------------------------ acilis / hata }

procedure TestAcKapat(const Dir: string);
var
  Db: TVDb;
  Err: string;
begin
  Grp('Acilis / kapatma');
  // hatali yol: istisna firlatmali, TRYOPEN ile yakalanmali
  Tst('TRYOPEN hatali yol -> False',
    not TVDb.TryOpen('Q:\yok\db.odb', True, Db, Err));
  Tst('TRYOPEN hata metni dolu', Err <> '', Copy(Err, 1, 50));
  Tst('TRYOPEN cikisinda Db nil', Db = nil);

  // dogru yol
  Db := TVDb.Open(Dir + '\c1.odb', True);
  try
    Tst('OPEN basarili', Db.Handle <> 0, 'handle=' + IntToStr(Db.Handle));
    Tst('bos veritabani Count=0', Db.Count = 0, IntToStr(Db.Count));
  finally
    Db.Free;
  end;

  // ayni dosyayi IKINCI kez acmak reddedilmeli
  Db := TVDb.Open(Dir + '\c2.odb', True);
  try
    Err := '';
    Tst('ikinci acik reddedildi',
      not TVDb.TryOpen(Dir + '\c2.odb', True, Db, Err));
    WriteLn('        (beklenen hata: ', Copy(Err, 1, 60), ')');
  finally
    Db.Free;
  end;
end;

{ ----------------------------------------------------------- KV katmani }

procedure TestKV(const Dir: string);
var
  Db: TVDb;
  S: AnsiString;
  B: TBytes;
  I: Integer;
begin
  Grp('KV katmani (VDBClient.GetStr / PutBytes)');
  Db := TVDb.Open(Dir + '\kv.odb', True);
  try
    // metin
    Db.Put(1, 'merhaba dunya');
    Tst('Put + Count', Db.Count = 1, IntToStr(Db.Count));
    Tst('GetStr degeri', Db.GetStr(1, S) and (S = 'merhaba dunya'), S);

    // BOS deger: "yok" ile "bos" ayirt edilebilmeli
    // 2026-10-04: eski surumde bos deger (0 bayt) "anahtar yok"
    // saniliyordu; bu yuzden ayri bir kontrol olarak var.
    Db.PutBytes(2, []);
    Tst('Put bos deger', Db.Exists(2));
    S := 'dolmadı';
    Tst('GetStr bos deger -> bos metin, "yok" degil',
      Db.GetStr(2, S) and (S = ''), 'S="' + S + '"');

    // olmayan anahtar
    S := 'degisti';
    Tst('GetStr olmayan -> False', not Db.GetStr(9999, S));
    Tst('GetStr olmayan degeri temizledi', S = '', 'S uzunluk=' + IntToStr(Length(S)));


    // ikili veri (0 ve #255 iceren)
    SetLength(B, 4);
    B[0] := 0; B[1] := 255; B[2] := 0; B[3] := 128;
    Db.PutBytes(3, B);
    SetLength(B, 0);
    Tst('GetBytes ikili veri', Db.GetBytes(3, B) and (Length(B) = 4));
    if Length(B) = 4 then
      Tst('GetBytes baytlar birebir',
        (B[0] = 0) and (B[1] = 255) and (B[2] = 0) and (B[3] = 128),
        IntToStr(B[0]) + ',' + IntToStr(B[1]) + ',' +
        IntToStr(B[2]) + ',' + IntToStr(B[3]));

    // UTF-8
    Db.Put(4, 'cag' + #$C3#$A7 + #$C4#$9F);
    Db.GetStr(4, S);
    Tst('UTF-8 uzunlugu', Length(S) = 7, IntToStr(Length(S)));
    Tst('UTF-8 c-cedil baytlari',
      (Byte(S[4]) = $C3) and (Byte(S[5]) = $A7),
      IntToHex(Byte(S[4]), 2) + ' ' + IntToHex(Byte(S[5]), 2));


    // buyuk deger (iki asamali Get'in gercekten iki adim yaptigini
    // dogrulamak icin)
    SetLength(B, 0);
    Db.PutBytes(5, B);              // 0 uzunluk
    Tst('PutBytes nil dizi', Db.Exists(5));

    // ustune yazma
    Db.Put(1, 'yeni');
    Db.GetStr(1, S);
    Tst('ustune yazma', S = 'yeni', S);
    Tst('ustune yazma Count degismedi', Db.Count = 5, IntToStr(Db.Count));

    // silme
    Db.DeleteKey(1);
    Tst('DeleteKey sonrasi yok', not Db.Exists(1));
    Tst('DeleteKey sonrasi Count', Db.Count = 4, IntToStr(Db.Count));

    // DeleteKey olmayan anahtarda istisna
    try
      Db.DeleteKey(1);
      No('DeleteKey olmayan -> istisna', 'istisna gelmedi');
    except
      on E: EVDbApiError do
        Ok('DeleteKey olmayan -> EVDbApiError', 'kod=' + IntToStr(E.Code));
      on E: Exception do
        No('DeleteKey olmayan -> yanlis istisna tipi', E.ClassName);
    end;
  finally
    Db.Free;
  end;
end;

{ ------------------------------------------------------------ SQL katmani }

procedure TestSQL(const Dir: string);
var
  Db: TVDb;
  R: TVDbResult;
  Toplam: Int64;
  I: Integer;
begin
  Grp('SQL katmani (sonuc seti kopyalama)');
  Db := TVDb.Open(Dir + '\sql.odb', True);
  try
    R := Db.SQL('CREATE TABLE kisi (id INTEGER PRIMARY KEY, ad TEXT NOT NULL, yas INTEGER)');
    try
      Tst('CREATE TABLE calisti', True);
    finally
      R.Free;
    end;

    R := Db.SQL('INSERT INTO kisi (id, ad, yas) VALUES (1, ''Ali'', 30), ' +
      '(2, ''Veli'', 25), (3, ''Zeynep'', 41)');
    try
      Tst('coklu INSERT 3 satir', R.Affected = 3, IntToStr(R.Affected));
    finally
      R.Free;
    end;

    R := Db.SQL('SELECT id, ad, yas FROM kisi ORDER BY id');
    try
      Tst('SELECT 3 satir', R.RowCount = 3, IntToStr(R.RowCount));
      Tst('SELECT 3 kolon', R.FieldCount = 3, IntToStr(R.FieldCount));
      Tst('kolon adi', R.FieldName(1) = 'ad', R.FieldName(1));

      { ONEMLI: Degerler DLL'den TEK SEFERDE kopyalanir. Onceki surumde
        degerler satir satir okunuyordu ve her cagri DLL'in ic
        tamponunu EZDI; sonuc "ayni" gorunur ama veri bozulurdu.
        Burada tum satirlari okuyup karsilastiriyoruz. }
      Tst('satir 0 / kolon 1', R.Value(0, 1) = 'Ali', R.Value(0, 1));
      Tst('satir 1 / kolon 1', R.Value(1, 1) = 'Veli', R.Value(1, 1));
      Tst('satir 2 / kolon 1', R.Value(2, 1) = 'Zeynep', R.Value(2, 1));
      Tst('satir 2 / kolon 2', R.Value(2, 2) = '41', R.Value(2, 2));

      Toplam := 0;
      for I := 0 to R.RowCount - 1 do
        Toplam := Toplam + StrToInt64Def(R.Value(I, 2), 0);
      Tst('sutun toplami (tam tarama)', Toplam = 96, IntToStr(Toplam));

      // indis sinir disi -> istisna
      try
        R.Value(99, 0);
        No('indis disi satir -> istisna', 'istisna gelmedi');
      except
        on E: EVDbApiError do
          Ok('indis disi satir -> EVDbApiError', 'kod=' + IntToStr(E.Code));
      end;
    finally
      R.Free;
    end;

    // kisit hatasi: EVDbApiError + dogru kod
    try
      R := Db.SQL('INSERT INTO kisi (id, ad) VALUES (4, NULL)');
      R.Free;
      No('NOT NULL ihlali -> istisna', 'istisna gelmedi');
    except
      on E: EVDbApiError do
      begin
        Tst('NOT NULL ihlali yakalandi', True, E.Message);
        Tst('NOT NULL kodu = VDB_E_CONSTRAINT', E.Code = VDB_E_CONSTRAINT,
          IntToStr(E.Code));
      end;
    end;

    // NULL deger okunabilmeli
    Db.SQL('INSERT INTO kisi (id, ad, yas) VALUES (9, ''BosYas'', NULL)').Free;
    R := Db.SQL('SELECT yas FROM kisi WHERE id = 9');
    try
      Tst('NULL deger okundu', (R.RowCount = 1) and (Length(R.Value(0, 0)) = 0),
        'deger="' + R.Value(0, 0) + '"');
    finally
      R.Free;
    end;

    // cok cumleli betik (otomatik transaction)
    R := Db.SQL('BEGIN; INSERT INTO kisi (id, ad) VALUES (30, ''A''); ' +
      'INSERT INTO kisi (id, ad) VALUES (31, ''B''); COMMIT;', VDB_SQL_AUTOTXN);
    try
      Tst('cok cumleli betik', R.Stmts >= 4, 'stmts=' + IntToStr(R.Stmts));
    finally
      R.Free;
    end;
    R := Db.SQL('SELECT COUNT(*) FROM kisi');
    try
      Tst('betik sonrasi kayit eklendi', R.Value(0, 0) = '6',

        R.Value(0, 0));
    finally
      R.Free;
    end;

    // sema sorgulari
    R := Db.SQL('DESCRIBE kisi');
    try
      Tst('DESCRIBE calisti', R.RowCount = 3, IntToStr(R.RowCount));
    finally
      R.Free;
    end;
    R := Db.SQL('SHOW CREATE TABLE kisi');
    try
      Tst('SHOW CREATE TABLE metni',
        Pos('CREATE TABLE', R.Value(0, 0)) = 1, Copy(R.Value(0, 0), 1, 45));
    finally
      R.Free;
    end;
  finally
    Db.Free;
  end;
end;

{ ------------------------------------------------------ bakim / WAL katmani }

procedure TestBakimWAL(const Dir: string);
var
  Db: TVDb;
  S: AnsiString;
  Rep: AnsiString;
  Eski, Yeni: Int64;
begin
  Grp('Bakim + WAL katmani');
  Db := TVDb.Open(Dir + '\wal.odb', True);
  try
    Tst('Verify saglam', Db.Verify(Rep), Rep);
    Tst('Verify raporu dolu', Rep <> '', Copy(Rep, 1, 50));

    Db.AutoCompact(Eski, Yeni);
    Tst('AutoCompact boyut bildiriyor', (Eski > 0) and (Yeni > 0),
      IntToStr(Eski) + ' -> ' + IntToStr(Yeni));
    Tst('Dosya boyutu', Db.Size > 0, IntToStr(Db.Size) + ' bayt');

    Tst('WAL yokken HasWAL=False', not Db.HasWAL);
    Tst('WAL yokken kayit sayisi 0', Db.WalRecordCount = 0);

    // WAL'a yaz -> ana dosyaya YAZILMAZ
    Db.WalWrite(1, 'wal-deger-1');
    Db.WalWrite(2, 'wal-deger-2');
    Tst('WAL yazildi', Db.HasWAL);
    Tst('WAL 2 kayit bekliyor', Db.WalRecordCount = 2,
      IntToStr(Db.WalRecordCount));
    Tst('replay oncesi ana dosyada YOK', not Db.Exists(1));

    Db.WalReplay;
    Tst('replay sonrasi kayit 1 var', Db.GetStr(1, S) and (S = 'wal-deger-1'), S);
    Tst('replay sonrasi WAL silindi', not Db.HasWAL);

    // silme gunluge
    Db.WalWriteDelete(1);
    Tst('silme kaydi gunluge', Db.HasWAL);
    Db.WalCheckpoint;
    Tst('checkpoint sonrasi kayit 1 silinmis', not Db.Exists(1));
    Tst('checkpoint sonrasi WAL yok', not Db.HasWAL);
  finally
    Db.Free;
  end;

  // kalicilik: yeniden ac
  Db := TVDb.Open(Dir + '\wal.odb', True);
  try
    Tst('reopen sonrasi replay kaydi kalici',
      Db.GetStr(2, S) and (S = 'wal-deger-2'), S);
  finally
    Db.Free;
  end;
end;

{ ------------------------------------------------------------------ main }

var
  arg: string;
begin
  nPass := 0; nFail := 0; nGrp := 0;

  if (ParamCount >= 1) and (Trim(ParamStr(1)) <> '') then
  begin
    tmpDir := ParamStr(1);
    ForceDirectories(tmpDir);
  end
  else
  begin
    tmpDir := GetTempDir(False) + 'vdbclienttest_' +
      FormatDateTime('yyyymmdd_hhnnss', Now);
    ForceDirectories(tmpDir);
  end;

  WriteLn('VDBClient (Delgi sarayisi) testi');
  WriteLn('Klasor: ', tmpDir);
  WriteLn;

  try
    TestAcKapat(tmpDir);
    TestKV(tmpDir);
    TestSQL(tmpDir);
    TestBakimWAL(tmpDir);
  except
    on E: Exception do
    begin
      WriteLn;
      WriteLn('BEKLENMEYEN HATA: ', E.ClassName, ': ', E.Message);
      Inc(nFail);
    end;
  end;

  WriteLn;
  WriteLn('========================================');
  WriteLn('SONUC: gecen=', nPass, '  kalan=', nFail);
  if nFail = 0 then
    WriteLn('TUM VDBCLIENT TESTLERI GECTI')
  else
    WriteLn('HATA VAR');
  if nFail > 0 then Halt(1);
end.
