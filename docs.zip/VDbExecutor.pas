unit VDbExecutor;

{ VDb SQL AST Yurutucusu (Executor)  - Faz 2 Adim 2.2
  AST cumle dugumlerini (TSqlStmtNode) TVTableDb uzerinde calistirir ve
  TSqlResult sonuc nesnesini uretir.

  Ozellikler:
  * EvalExpr: tam tip-bilgili ifade degerlendirici (literal, kolon, ikili/tekli
    op, IN, BETWEEN, COUNT/SUM/AVG/MIN/MAX fonksiyon cagrilari)
  * ExecSelect: WHERE filtreleme, ORDER BY (cok sutun, ASC/DESC),
    LIMIT/OFFSET, DISTINCT, GROUP BY + HAVING, toplama fonksiyonlari,
    INNER/LEFT JOIN, UNION/UNION ALL/EXCEPT/INTERSECT
  * ExecInsert: cok satirli VALUES + INSERT ... SELECT
  * ExecUpdate: AST WHERE ile filtreli guncelleme (Delete+ReInsert)
  * ExecDelete: AST WHERE ile filtreli silme
  * DDL (CREATE/ALTER/DROP TABLE, CREATE/DROP INDEX)
  * TX (BEGIN/COMMIT/ROLLBACK), Admin (VERIFY/VACUUM/REINDEX), JSON
}

{$mode delphi}

interface

uses
  Classes, SysUtils, Math, Generics.Collections,
  VDbCore, VDbTable, VDbAst, VDbJson, VDbErr, VDbText;

const
  // F2-18: DISTINCT / UNION tekilleştirme sonucu ve set-op birlestirme
  // satiri ust siniri. Once sinirsizdi; tekilleştirme kovasi bir tabloda
  // bellek kucak doldurabiliyordu (OOM).
  VDB_MAX_RESULT_ROWS = 2000000;
  // F2-18: satir icin tekillestirme anahtari. Her deger "len:deger"
  // biciminde yazilir; boylece degerin icindeki ayirici (#1) belirsizlik
  // yaratmaz.
  VDB_ROWKEY_SEP = #1;
  // F3-2: quicksort yigin derinligi. Iki durakli (push larger half)
  // quicksortta derinlik log2(N); 64 cerverek. Yine de asilirsa dizi
  // disina yazilmamasi icin sinir denetimi vardir.
  VDB_SORT_STACK_MAX = 64;

type
  TByteArray = array of Byte;

  // P5-CTE: materyallestirilmis gecici sonuc (ad -> satirlar + tipler).
  TCteTable = record
    Names: TStrArray;
    Types: TByteArray;
    Rows: TStrMatrix;
  end;

  TVSqlExecutor = class
  private
    FT: TVTableDb;
    // P5-2: iliskisiz alt sorgu sonuclari (cumle basi onbellek; ayni ic
    // sorgu disaridaki her satir icin bir kez calisir). Anahtar = AST dugumu.
    FSubCache: TDictionary<Pointer, TSqlResult>;
    // F2-20: IN (SELECT ...) deger kumesi (alt sorgu basina TEK KEZ kurulur).
    // Once her dis satir icin alt sonucu yeniden taraniyordu (O(N*M)).
    FInSetCache: TDictionary<Pointer, TDictionary<string, Byte>>;
    // P5-CTE: WITH adlari (cumle basi kapsam; sirayla doldurulur,
    // sonrakiler oncekileri gorur).
    FCteTables: TDictionary<string, TCteTable>;

    { ---------- Expression Evaluator ---------- }
    function EvalExpr(Expr: TSqlExprNode; const Row: TStrArray;
      const ColNames: TStrArray; const ColTypes: TByteArray): string;
    function EvalBool(Expr: TSqlExprNode; const Row: TStrArray;
      const ColNames: TStrArray; const ColTypes: TByteArray): Boolean;
    function EvalBinary(AOp: TSqlBinaryOp; const LeftVal, RightVal: string;
      Ctype: Byte): string;
    function EvalUnary(AOp: TSqlUnaryOp; const Val: string): string;
    // P5-2: ic sorguyu calistirip sonucu onbellekten/dogrudan dondurur.
    function SubResult(Sel: TSqlSelectStmt): TSqlResult;
    // P5-CTE: WITH listesini sirayla materyallestirir.
    procedure MaterializeCtes(Stmt: TSqlSelectStmt);
    // P5-CTE: ad CTE ise satirlarini dondurur (yoksa False).
    function TryCte(const TableName: string; out Names: TStrArray;
      out Types: TByteArray; out Rows: TStrMatrix): Boolean;
    // P5-CTE: ic sorgu ciktisinin kolon tipleri (Taraf/kiyas icin).
    procedure CteColTypes(Sel: TSqlSelectStmt; const Fields: TStrArray;
      out Types: TByteArray);
    // P5-2: ic sorgunun dis tablolara basvurmadigini dogrular
    // (iliskili alt sorgu desteklenmez; sessiz yanlis sonuc yerine hata).
    procedure ValidateSubquery(Sel: TSqlSelectStmt);

    { ---------- Yardimcilar ---------- }
    procedure BuildColInfo(const td: TTableDef; out ColNames: TStrArray;
      out ColTypes: TByteArray);
    { F1-17: kolon referansini konum listesinde cozer.
      JOIN'de kolonlar nitelemeli (alias.col) gelir; yalniz tam ad
      eslestirmesi typi VCT_STR'a dusurur ve '10' < '2' sonucu dogar.
      Nitelemesiz referanslar sonek eslestirmesiyle bulunur. }
    function FindColIdx(const ColumnName, TableQualifier: string;
      const ColNames: TStrArray): Integer;
    function RowMatches(WhereClause: TSqlExprNode; const Row: TStrArray;
      const ColNames: TStrArray; const ColTypes: TByteArray): Boolean;
    procedure DoSort(var Rows: TStrMatrix; const Keys: TStrArray;
      OrderBy: TList<TOrderItem>;
      const ColNames: TStrArray; const ColTypes: TByteArray);
    function HasAggregate(Stmt: TSqlSelectStmt): Boolean;
    // P5-WIN: SELECT listesinde pencere fonksiyonu var mi (ic ice dahil).
    function HasWindow(Stmt: TSqlSelectStmt): Boolean;
    // P5-WIN: pencere yerlesim kurali (yalniz ust-duzey SELECT ogesi;
    // WHERE/HAVING/ORDER BY/JOIN-ON ve ic ice kullanim yasaktir).
    procedure CheckWindowPlacement(Stmt: TSqlSelectStmt);
    { ---------- Satir adaylarini DARALTMA (tam tarama oncesi) ----------
      WHERE AST'sinden PK nokta aramasi veya indeks dilimi cikarir.
      False donerse cagri tam tarama yapar.
      DONUMLERIN TAMAMI RowMatches ile yeniden dogrulanir; dilim yalnizca
      UST KUMEDIR, bu yuzden sonuc hicbir kosulda degismez. }
    function NarrowRows(const Td: TTableDef; WhereClause: TSqlExprNode;
      const ColNames: TStrArray; const ColTypes: TByteArray;
      out Pks: TStrArray; out Rows: TStrMatrix): Boolean;
    { ORDER BY tek kolon ve bu kolon indeksliyse, satirlar INDeks sirasiyla
      okunur; OFFSET/LIMIT erken uygulanir. "ORDER BY n LIMIT 10" 100.000
      satirlik tabloda ~900 ms yerine ~0 ms surer.
      False donerse normal (tam tarama + siralama) yol kullanilir. }
    function TryIndexOrder(const Td: TTableDef; Stmt: TSqlSelectStmt;
      const ColNames: TStrArray; const ColTypes: TByteArray;
      out Rows: TStrMatrix): Boolean;
    procedure ExecGroupBy(Stmt: TSqlSelectStmt; const AllPks: TStrArray;
      const AllRows: TStrMatrix; const ColNames: TStrArray;
      const ColTypes: TByteArray; out Res: TSqlResult;
      out OutTypes: TByteArray);
    procedure ExecJoinScan(Stmt: TSqlSelectStmt; out MergedRows: TStrMatrix;
      out MergedColNames: TStrArray; out MergedColTypes: TByteArray);
    { P5-WIN: pencere kolonlarini satirlarla ayni sirada hesaplar.
      WinVals[i][s] = i'nci satirin s'nci pencere degeri;
      WinSlot[j] = j'nci cikti kolonunun penceresi (degilse -1).
      Sorgu ORDER BY'sinden SONRA, projeksiyondan ONCE cagrilir. }
    procedure ComputeWindows(Stmt: TSqlSelectStmt;
      const Rows: TStrMatrix; const ColNames: TStrArray;
      const ColTypes: TByteArray; out WinVals: TStrMatrix;
      out WinSlot: TIntArray);

    { ---------- Statement Handlers ---------- }
    procedure ExecSelect(Stmt: TSqlSelectStmt; out Res: TSqlResult);
    procedure ExecInsert(Stmt: TSqlInsertStmt; out Res: TSqlResult);
    procedure ExecUpdate(Stmt: TSqlUpdateStmt; out Res: TSqlResult);
    procedure ExecDelete(Stmt: TSqlDeleteStmt; out Res: TSqlResult);
    procedure ExecCreateTable(Stmt: TSqlCreateTableStmt; out Res: TSqlResult);
    procedure ExecAlterTable(Stmt: TSqlAlterTableStmt; out Res: TSqlResult);
    procedure ExecDropTable(Stmt: TSqlDropTableStmt; out Res: TSqlResult);
    procedure ExecCreateIndex(Stmt: TSqlCreateIndexStmt; out Res: TSqlResult);
    procedure ExecDropIndex(Stmt: TSqlDropIndexStmt; out Res: TSqlResult);
    procedure ExecTx(Stmt: TSqlTxStmt; out Res: TSqlResult);
    procedure ExecAdmin(Stmt: TSqlAdminStmt; out Res: TSqlResult);
    procedure ExecJson(Stmt: TSqlJsonStmt; out Res: TSqlResult);
  public
    constructor Create(ATableDb: TVTableDb);
    function Execute(Stmt: TSqlStmtNode): TSqlResult;
    property TableDb: TVTableDb read FT;
  end;

implementation

type
  { FPC'de TList<TList<T>> desteklenmedigi icin yardimci alt sinif }
  TIntList = class(TList<Integer>)
  end;
  TIntListList = TList<TIntList>;

{ ============================================================
  Yardimci: string dizisi esit mi?
  ============================================================ }
function RowEncodeKey(const Row: TStrArray): string;
// F2-18: Satiri tekilleştirme icin UZUNLUK-ONEKI kodlanmis anahtara
// cevirir. Her deger "len:deger" seklinde yazilir; boylece degerin
// icindeki ayirici (#1) belirsizlik yaratmaz.
var
  i: Integer;
begin
  Result := '';
  for i := 0 to High(Row) do
    Result := Result + IntToStr(Length(Row[i])) + ':' + Row[i] + VDB_ROWKEY_SEP;
end;

function SameStrArr(const A, B: TStrArray): Boolean;
var i: Integer;
begin
  if Length(A) <> Length(B) then Exit(False);
  for i := 0 to High(A) do
    if A[i] <> B[i] then Exit(False);
  Result := True;
end;

{ ============================================================
  TVSqlExecutor
  ============================================================ }

constructor TVSqlExecutor.Create(ATableDb: TVTableDb);
begin
  inherited Create;
  FT := ATableDb;
end;

{ ------------------------------------------------------------
  BuildColInfo
  //---------------------------------------------------------- }
procedure TVSqlExecutor.BuildColInfo(const td: TTableDef;
  out ColNames: TStrArray; out ColTypes: TByteArray);
var i: Integer;
begin
  SetLength(ColNames, Length(td.Cols));
  SetLength(ColTypes, Length(td.Cols));
  for i := 0 to High(td.Cols) do
  begin
    ColNames[i] := td.Cols[i].Name;
    ColTypes[i] := td.Cols[i].Ctype;
  end;
end;

function TVSqlExecutor.FindColIdx(const ColumnName, TableQualifier: string;
  const ColNames: TStrArray): Integer;
var
  i, dp: Integer;
begin
  // 1. Tam eslesme (nitelemeli veya nitelememisiz)
  for i := 0 to High(ColNames) do
    if SameText(ColNames[i], ColumnName) or
       ((TableQualifier <> '') and SameText(ColNames[i], TableQualifier + '.' + ColumnName)) then
      Exit(i);
  // 2. Nitelemesiz referans -> sonek eslestirmesi (ad -> alias.ad)
  if TableQualifier = '' then
    for i := 0 to High(ColNames) do
    begin
      dp := Pos('.', ColNames[i]);
      if (dp > 0) and
         SameText(Copy(ColNames[i], dp + 1, MaxInt), ColumnName) then
        Exit(i);
    end;
  Result := -1;
end;

{ ------------------------------------------------------------
  EvalBinary
  //---------------------------------------------------------- }
function TVSqlExecutor.EvalBinary(AOp: TSqlBinaryOp; const LeftVal, RightVal: string;
  Ctype: Byte): string;
var
  ia, ib: Int64;
  fa, fb: Double;
  bRes: Boolean;
begin
  // F1-14: SQL'de NULL ile hicbir KARSILASTIRMA operatoru eslesmez; sonuc
  // UNKNOWN ('') olur. Once 'False' donuyordu, bu yuzden NOT (NULL = 1)
  // -> True oluyor ve NULL satirlari WHERE filtresine giriyordu.
  // (sboEq..sboLike araligi = =, <>, <, <=, >, >=, LIKE)
  // Aritmetik operatorler zaten kendi NULL kontrolunu yapiyor.
  if (AOp >= sboEq) and (AOp <= sboLike) and
     ((LeftVal = '') or (RightVal = '')) then Exit('');
  case AOp of
    sboAdd, sboSub, sboMul, sboDiv, sboMod:
      begin
        if (LeftVal = '') or (RightVal = '') then Exit('');
        if (Ctype = VCT_FLOAT) or (Pos('.', LeftVal) > 0) or (Pos('.', RightVal) > 0) then
        begin
          if not VDbParseFloat(LeftVal, fa) or not VDbParseFloat(RightVal, fb) then Exit('');
          case AOp of
            sboAdd: Exit(VDbFloatToStr(fa + fb));
            sboSub: Exit(VDbFloatToStr(fa - fb));
            sboMul: Exit(VDbFloatToStr(fa * fb));
            sboDiv:
              begin
                if fb = 0.0 then raise EVDbException.Create(ecMathError, 'Sifira bolme hatasi');
                Exit(VDbFloatToStr(fa / fb));
              end;
            sboMod: raise EVDbException.Create(ecMathError, 'FLOAT tipte modulo kullanilamaz');
          end;
        end
        else
        begin
          if not VDbParseInt(LeftVal, ia) or not VDbParseInt(RightVal, ib) then Exit('');
          case AOp of
            sboAdd: Exit(IntToStr(ia + ib));
            sboSub: Exit(IntToStr(ia - ib));
            sboMul: Exit(IntToStr(ia * ib));
            sboDiv:
              begin
                if ib = 0 then raise EVDbException.Create(ecMathError, 'Sifira bolme hatasi');
                Exit(IntToStr(ia div ib));
              end;
            sboMod:
              begin
                if ib = 0 then raise EVDbException.Create(ecMathError, 'Sifira bolme hatasi');
                Exit(IntToStr(ia mod ib));
              end;
          end;
        end;
      end;
    sboAnd:
      begin
        bRes := (SameText(LeftVal, 'True') or (LeftVal = '1')) and
                (SameText(RightVal, 'True') or (RightVal = '1'));
        if bRes then Exit('True') else Exit('False');
      end;
    sboOr:
      begin
        bRes := (SameText(LeftVal, 'True') or (LeftVal = '1')) or
                (SameText(RightVal, 'True') or (RightVal = '1'));
        if bRes then Exit('True') else Exit('False');
      end;
    sboEq:   bRes := VDbCmpVal(LeftVal, RightVal, '=', Ctype);
    sboNeq:  bRes := VDbCmpVal(LeftVal, RightVal, '<>', Ctype);
    sboLt:   bRes := VDbCmpVal(LeftVal, RightVal, '<', Ctype);
    sboLte:  bRes := VDbCmpVal(LeftVal, RightVal, '<=', Ctype);
    sboGt:   bRes := VDbCmpVal(LeftVal, RightVal, '>', Ctype);
    sboGte:  bRes := VDbCmpVal(LeftVal, RightVal, '>=', Ctype);
    sboLike: bRes := VDbLikeMatch(LeftVal, RightVal);
  else
    bRes := False;
  end;
  if bRes then Result := 'True' else Result := 'False';
end;

{ ------------------------------------------------------------
  EvalUnary
  //---------------------------------------------------------- }
function TVSqlExecutor.EvalUnary(AOp: TSqlUnaryOp; const Val: string): string;
var
  iVal: Int64;
  fVal: Double;
  b: Boolean;
begin
  case AOp of
    suoNot:
      begin
        // F1-14: NOT NULL => UNKNOWN (''), not TRUE.
        if Val = '' then Exit('');
        b := SameText(Val, 'True') or (Val = '1');
        if not b then Result := 'True' else Result := 'False';
      end;
    suoNeg:
      begin
        if Val = '' then Exit('');
        if VDbParseInt(Val, iVal) then Result := IntToStr(-iVal)
        else if VDbParseFloat(Val, fVal) then Result := VDbFloatToStr(-fVal)
        else Result := Val;
      end;
    suoIsNull:    if Val = '' then Result := 'True' else Result := 'False';
    suoIsNotNull: if Val <> '' then Result := 'True' else Result := 'False';
  else
    Result := Val;
  end;
end;

{ ------------------------------------------------------------
  EvalExpr
  //---------------------------------------------------------- }
function TVSqlExecutor.EvalExpr(Expr: TSqlExprNode; const Row: TStrArray;
  const ColNames: TStrArray; const ColTypes: TByteArray): string;
var
  lit: TSqlLiteralNode;
  colRef: TSqlColumnRefNode;
  bin: TSqlBinaryOpNode;
  un: TSqlUnaryOpNode;
  inN: TSqlInNode;
  subN: TSqlSubqueryNode;
  csN: TSqlCaseNode;
  ov, wv: string;
  subR: TSqlResult;
  bt: TSqlBetweenNode;
  fn: TSqlFuncCallNode;
  lv, rv, itemVal: string;
  ct: Byte;
  idx, i, ci: Integer;
  matched: Boolean;
  fa: Double;
  ia: Int64;
  hasNull: Boolean;
  // F2-20
  inSet: TDictionary<string, Byte>;
begin
  if Expr = nil then Exit('');

  if Expr is TSqlLiteralNode then
  begin
    lit := TSqlLiteralNode(Expr);
    Exit(lit.AsString);
  end;

  if Expr is TSqlColumnRefNode then
  begin
    colRef := TSqlColumnRefNode(Expr);
    if (Row = nil) or (Length(ColNames) = 0) then
      Exit(colRef.ColumnName);
    idx := FindColIdx(colRef.ColumnName, colRef.TableQualifier, ColNames);
    if (idx >= 0) and (idx < Length(Row)) then Exit(Row[idx])
    else raise EVDbException.Create(ecColumnNotFound, 'Kolon bulunamadi: ' + colRef.QualifiedName);
  end;

  if Expr is TSqlBinaryOpNode then
  begin
    bin := TSqlBinaryOpNode(Expr);
    lv := EvalExpr(bin.Left, Row, ColNames, ColTypes);
    rv := EvalExpr(bin.Right, Row, ColNames, ColTypes);
    ct := VCT_STR;
    // F1-17: tip cozumlesmesi nitelemeli adi da gorur, aksi halde
    // JOIN sonrasi WHERE'te karsilastirma metin sirasiyla yapilir.
    if bin.Left is TSqlColumnRefNode then
    begin
      colRef := TSqlColumnRefNode(bin.Left);
      ci := FindColIdx(colRef.ColumnName, colRef.TableQualifier, ColNames);
      if (ci >= 0) and (ci < Length(ColTypes)) then ct := ColTypes[ci];
    end;
    if (ct = VCT_STR) and (bin.Right is TSqlColumnRefNode) then
    begin
      colRef := TSqlColumnRefNode(bin.Right);
      ci := FindColIdx(colRef.ColumnName, colRef.TableQualifier, ColNames);
      if (ci >= 0) and (ci < Length(ColTypes)) then ct := ColTypes[ci];
    end;
    Exit(EvalBinary(bin.Op, lv, rv, ct));
  end;

  if Expr is TSqlUnaryOpNode then
  begin
    un := TSqlUnaryOpNode(Expr);
    lv := EvalExpr(un.Operand, Row, ColNames, ColTypes);
    Exit(EvalUnary(un.Op, lv));
  end;

  if Expr is TSqlInNode then
  begin
    inN := TSqlInNode(Expr);
    lv := EvalExpr(inN.Expr, Row, ColNames, ColTypes);
    if lv = '' then Exit('False');
    matched := False;
    // F1-13: NOT IN ... NULL handling (three-valued logic)
    hasNull := False;
    if inN.SubSelect <> nil then
    begin
      // P5-2: IN (SELECT ...) - ic sorgu tek kolon dondurmelidir.
      // NULL kurali liste davranisiyla aynidir: '' degerler eslesmez.
      subR := SubResult(inN.SubSelect);
      if Length(subR.Fields) <> 1 then
        raise EVDbException.Create(ecInvalidArgument,
          'IN alt sorgusu tek kolon dondurmeli');
      // F2-20: alt sorgu degerleri TEK KEZ hash kovaya yazilir. Once
      // her DIS satir icin sonuc yeniden taraniyordu -> O(N*M).
      // Artik O(N + M).
      if not FInSetCache.TryGetValue(Pointer(inN.SubSelect), inSet) then
      begin
        inSet := TDictionary<string, Byte>.Create;
        for i := 0 to High(subR.Rows) do
          if Length(subR.Rows[i]) > 0 then
            inSet.AddOrSetValue(subR.Rows[i][0], 0);
        FInSetCache.Add(Pointer(inN.SubSelect), inSet);
      end;
      matched := inSet.ContainsKey(lv);
      hasNull := inSet.ContainsKey('');
    end
    else
      for i := 0 to inN.List.Count - 1 do
      begin
        itemVal := EvalExpr(inN.List[i], Row, ColNames, ColTypes);
        if itemVal = lv then begin matched := True; Break; end;
        if itemVal = '' then hasNull := True;
      end;
    if inN.IsNot then
    begin
      // F1-13: NOT IN ... NULL => UNKNOWN (satir gelmez)
      // Liste icinde NULL varsa sonuc UNKNOWN -> eslesmez.
      if hasNull then matched := False
      else matched := not matched;
    end;
    if matched then Exit('True') else Exit('False');
  end;

  if Expr is TSqlSubqueryNode then
  begin
    // P5-2: skaler deger veya EXISTS denetimi.
    subN := TSqlSubqueryNode(Expr);
    subR := SubResult(subN.Select);
    if subN.Kind = sqExists then
    begin
      matched := Length(subR.Rows) > 0;
      if subN.IsNot then matched := not matched;
      if matched then Exit('True') else Exit('False');
    end;
    if Length(subR.Fields) <> 1 then
      raise EVDbException.Create(ecInvalidArgument,
        'skaler alt sorgu tek kolon dondurmeli');
    if Length(subR.Rows) = 0 then Exit(''); // satir yok = NULL
    if Length(subR.Rows) > 1 then
      raise EVDbException.Create(ecInvalidArgument,
        'skaler alt sorgu birden fazla satir dondurdu');
    if Length(subR.Rows[0]) = 0 then Exit('');
    Exit(subR.Rows[0][0]);
  end;

  if Expr is TSqlBetweenNode then
  begin
    bt := TSqlBetweenNode(Expr);
    lv := EvalExpr(bt.Expr, Row, ColNames, ColTypes);
    if lv = '' then Exit('False');
    ct := VCT_STR;
    if bt.Expr is TSqlColumnRefNode then
    begin
      colRef := TSqlColumnRefNode(bt.Expr);
      for i := 0 to High(ColNames) do
        if SameText(colRef.ColumnName, ColNames[i]) and (i < Length(ColTypes)) then
        begin ct := ColTypes[i]; Break; end;
    end;
    matched := VDbCmpVal(lv, EvalExpr(bt.LowBound, Row, ColNames, ColTypes), '>=', ct) and
               VDbCmpVal(lv, EvalExpr(bt.HighBound, Row, ColNames, ColTypes), '<=', ct);
    if bt.IsNot then matched := not matched;
    if matched then Exit('True') else Exit('False');
  end;

  if Expr is TSqlFuncCallNode then
  begin
    fn := TSqlFuncCallNode(Expr);
    if fn.IsStar then Exit('1');
    lv := EvalExpr(fn.Arg, Row, ColNames, ColTypes);
    if fn.FuncName = 'UPPER' then Exit(VDbTrUpper(lv))
    else if fn.FuncName = 'LOWER' then Exit(VDbTrLower(lv))
    else if fn.FuncName = 'LENGTH' then
    begin
      // BLOB'da bayt sayisi (ikili veri UTF-8 karakteri degildir).
      if fn.Arg is TSqlColumnRefNode then
      begin
        colRef := TSqlColumnRefNode(fn.Arg);
        for i := 0 to High(ColNames) do
          if SameText(colRef.ColumnName, ColNames[i]) and
             (i < Length(ColTypes)) and (ColTypes[i] = VCT_BLOB) then
            Exit(IntToStr(Length(lv)));
      end;
      Exit(IntToStr(VDbUtf8Length(lv)));
    end
    else if fn.FuncName = 'ABS' then
    begin
      if VDbParseFloat(lv, fa) then Exit(VDbFloatToStr(Abs(fa)))
      else if VDbParseInt(lv, ia) then Exit(IntToStr(Abs(ia)))
      else Exit(lv);
    end
    else if fn.FuncName = 'COALESCE' then
    begin
      if lv <> '' then Exit(lv) else Exit('');
    end
    else Exit(lv); // COUNT/SUM/AVG/MIN/MAX: ExecGroupBy'da degerlendirilir
  end;

  if Expr is TSqlCaseNode then
  begin
    // P5-3: aranan (WHEN kosul) ve sade (CASE x WHEN deger) bicimler.
    // ELSE yoksa sonuc NULL'dur. Sade bicimde NULL eslesmez.
    csN := TSqlCaseNode(Expr);
    if csN.Operand <> nil then
    begin
      ov := EvalExpr(csN.Operand, Row, ColNames, ColTypes);
      ct := VCT_STR;
      if csN.Operand is TSqlColumnRefNode then
      begin
        colRef := TSqlColumnRefNode(csN.Operand);
        for i := 0 to High(ColNames) do
          if SameText(colRef.ColumnName, ColNames[i]) and (i < Length(ColTypes)) then
          begin ct := ColTypes[i]; Break; end;
      end;
    end;
    for i := 0 to csN.Whens.Count - 1 do
    begin
      if csN.Operand <> nil then
      begin
        wv := EvalExpr(csN.Whens[i].Cond, Row, ColNames, ColTypes);
        if (ov <> '') and (wv <> '') and VDbCmpVal(ov, wv, '=', ct) then
          Exit(EvalExpr(csN.Whens[i].Value, Row, ColNames, ColTypes));
      end
      else if EvalBool(csN.Whens[i].Cond, Row, ColNames, ColTypes) then
        Exit(EvalExpr(csN.Whens[i].Value, Row, ColNames, ColTypes));
    end;
    if csN.ElseExpr <> nil then
      Exit(EvalExpr(csN.ElseExpr, Row, ColNames, ColTypes));
    Exit('');
  end;

  if Expr is TSqlWindowNode then
    // P5-WIN: pencere yalniz projeksiyonda tuketilir; satir-basi
    // degerlendirme anlamsizdir (CheckWindowPlacement bunu onceden eler).
    raise EVDbException.Create(ecUnsupported,
      'pencere fonksiyonu yalnizca SELECT listesinde kullanilabilir');

  Result := '';
end;

{ ------------------------------------------------------------
  SubResult (P5-2)
  //---------------------------------------------------------- }
procedure TVSqlExecutor.ValidateSubquery(Sel: TSqlSelectStmt);

  procedure CheckSelect(S: TSqlSelectStmt); forward;

  function InScope(const Qual: string; const Tabs: TStrArray): Boolean;
  var
    k: Integer;
  begin
    Result := False;
    for k := 0 to High(Tabs) do
      if (Tabs[k] <> '') and SameText(Tabs[k], Qual) then
        Exit(True);
  end;

  procedure CheckExpr(E: TSqlExprNode; const Tabs: TStrArray);
  var
    k: Integer;
    C: TSqlColumnRefNode;
  begin
    if E = nil then Exit;
    if E is TSqlColumnRefNode then
    begin
      C := TSqlColumnRefNode(E);
      if (C.TableQualifier <> '') and not InScope(C.TableQualifier, Tabs) then
        raise EVDbException.Create(ecUnsupported,
          'iliskili alt sorgu desteklenmiyor (dis tablo: ' +
          C.TableQualifier + ')');
    end
    else if E is TSqlBinaryOpNode then
    begin
      CheckExpr(TSqlBinaryOpNode(E).Left, Tabs);
      CheckExpr(TSqlBinaryOpNode(E).Right, Tabs);
    end
    else if E is TSqlUnaryOpNode then
      CheckExpr(TSqlUnaryOpNode(E).Operand, Tabs)
    else if E is TSqlInNode then
    begin
      CheckExpr(TSqlInNode(E).Expr, Tabs);
      for k := 0 to TSqlInNode(E).List.Count - 1 do
        CheckExpr(TSqlInNode(E).List[k], Tabs);
      if TSqlInNode(E).SubSelect <> nil then
        CheckSelect(TSqlInNode(E).SubSelect);
    end
    else if E is TSqlBetweenNode then
    begin
      CheckExpr(TSqlBetweenNode(E).Expr, Tabs);
      CheckExpr(TSqlBetweenNode(E).LowBound, Tabs);
      CheckExpr(TSqlBetweenNode(E).HighBound, Tabs);
    end
    else if E is TSqlFuncCallNode then
      CheckExpr(TSqlFuncCallNode(E).Arg, Tabs)
    else if E is TSqlWindowNode then
    begin
      CheckExpr(TSqlWindowNode(E).Arg, Tabs);
      CheckExpr(TSqlWindowNode(E).Default, Tabs);
      for k := 0 to TSqlWindowNode(E).Partitions.Count - 1 do
        CheckExpr(TSqlWindowNode(E).Partitions[k], Tabs);
      for k := 0 to TSqlWindowNode(E).OrderBys.Count - 1 do
        CheckExpr(TSqlWindowNode(E).OrderBys[k].Expr, Tabs);
    end
    else if E is TSqlCaseNode then
    begin
      CheckExpr(TSqlCaseNode(E).Operand, Tabs);
      for k := 0 to TSqlCaseNode(E).Whens.Count - 1 do
      begin
        CheckExpr(TSqlCaseNode(E).Whens[k].Cond, Tabs);
        CheckExpr(TSqlCaseNode(E).Whens[k].Value, Tabs);
      end;
      CheckExpr(TSqlCaseNode(E).ElseExpr, Tabs);
    end
    else if E is TSqlSubqueryNode then
      CheckSelect(TSqlSubqueryNode(E).Select);
  end;

  procedure CheckSelect(S: TSqlSelectStmt);
  var
    Tabs: TStrArray;
    k: Integer;
    CteNm: string;

    procedure AddTab(const T, A: string);
    begin
      if T <> '' then
      begin
        SetLength(Tabs, Length(Tabs) + 1);
        Tabs[High(Tabs)] := T;
      end;
      if A <> '' then
      begin
        SetLength(Tabs, Length(Tabs) + 1);
        Tabs[High(Tabs)] := A;
      end;
    end;

  begin
    if S = nil then Exit;
    SetLength(Tabs, 0);
    AddTab(S.FromTable, S.FromAlias);
    if S.HasJoin then
    begin
      AddTab(S.Join.Table, S.Join.Alias);
      for k := 0 to S.MoreJoins.Count - 1 do
        AddTab(S.MoreJoins[k].Table, S.MoreJoins[k].Alias);
      CheckExpr(S.Join.OnCondition, Tabs);
      for k := 0 to S.MoreJoins.Count - 1 do
        CheckExpr(S.MoreJoins[k].OnCondition, Tabs);
    end;
    // Kapsamdaki CTE adlari da gecerli niteleyicidir (materyal sirada
    // biriktigi icin FCteTables o an gorunur olanlari icerir).
    if FCteTables <> nil then
      for CteNm in FCteTables.Keys do
      begin
        SetLength(Tabs, Length(Tabs) + 1);
        Tabs[High(Tabs)] := CteNm;
      end;
    for k := 0 to S.Columns.Count - 1 do
      CheckExpr(S.Columns[k].Expr, Tabs);
    CheckExpr(S.WhereClause, Tabs);
    CheckExpr(S.HavingClause, Tabs);
    if S.OrderBy <> nil then
      for k := 0 to S.OrderBy.Count - 1 do
        CheckExpr(S.OrderBy[k].Expr, Tabs);
    if S.RightSelect <> nil then
      CheckSelect(S.RightSelect);
  end;

begin
  CheckSelect(Sel);
end;

function TVSqlExecutor.SubResult(Sel: TSqlSelectStmt): TSqlResult;
begin
  if (FSubCache <> nil) and FSubCache.TryGetValue(Pointer(Sel), Result) then
    Exit;
  ValidateSubquery(Sel);
  ExecSelect(Sel, Result);
  // F2-20: alt sorgu sonucu sinirli. Alt sorgu milyonlarca satir dondururse
  // (BOMsuz JOIN/UNION) hem bellek hem sonraki O(N*M) taramalar yuzünden
  // cokmeye (OOM) yol acardi. Once sinirsizdi.
  if Length(Result.Rows) > VDB_MAX_RESULT_ROWS then
    raise EVDbException.CreateFmt(ecLimit,
      'alt sorgu sonucu cok buyuk (%d > %d satir)',
      [Length(Result.Rows), VDB_MAX_RESULT_ROWS]);
  if FSubCache <> nil then
  begin
    if FSubCache.ContainsKey(Pointer(Sel)) then
      FSubCache[Pointer(Sel)] := Result
    else
      FSubCache.Add(Pointer(Sel), Result);
  end;
end;

{ ------------------------------------------------------------
  CTE yardimcilari (P5-CTE)
  //---------------------------------------------------------- }
function TVSqlExecutor.TryCte(const TableName: string; out Names: TStrArray;
  out Types: TByteArray; out Rows: TStrMatrix): Boolean;
var
  T: TCteTable;
begin
  Result := False;
  if (FCteTables <> nil) and
     FCteTables.TryGetValue(VDbNorm(TableName), T) then
  begin
    Names := T.Names;
    Types := T.Types;
    Rows := T.Rows;
    Result := True;
  end;
end;

procedure TVSqlExecutor.CteColTypes(Sel: TSqlSelectStmt;
  const Fields: TStrArray; out Types: TByteArray);
// Ic sorgu ciktisinin mumkun olan en iyi tipleri: sade kolonlar kaynaktan,
// COUNT(*) tamsayi, SUM/AVG gercek sayi; gerisi metin. Amac: dis sorguda
// sayisal kiyas/siralama dogru calissin ('10' > '2' sayisal).
var
  i: Integer;
  Td: TTableDef;
  Ref: TSqlColumnRefNode;
  Fn: TSqlFuncCallNode;

  function SrcCol(const Nm: string; out Ct: Byte): Boolean;
  var
    q: Integer;
  begin
    Result := False;
    for q := 0 to High(Td.Cols) do
      if SameText(Td.Cols[q].Name, Nm) then
      begin Ct := Td.Cols[q].Ctype; Exit(True); end;
  end;

begin
  SetLength(Types, Length(Fields));
  for i := 0 to High(Types) do
    Types[i] := VCT_STR;
  if (Sel.FromTable = '') or Sel.HasJoin then Exit;
  try
    Td := FT.GetTable(Sel.FromTable);
  except
    Exit;
  end;
  if Sel.Columns.Count = 0 then
  begin
    // SELECT *: cikti = sema sirasi
    if Length(Fields) <> Length(Td.Cols) then Exit;
    for i := 0 to High(Td.Cols) do
      Types[i] := Td.Cols[i].Ctype;
    Exit;
  end;
  if Sel.Columns.Count <> Length(Fields) then Exit;
  for i := 0 to Sel.Columns.Count - 1 do
  begin
    if Sel.Columns[i].Expr is TSqlColumnRefNode then
    begin
      Ref := TSqlColumnRefNode(Sel.Columns[i].Expr);
      SrcCol(Ref.ColumnName, Types[i]);
    end
    else if Sel.Columns[i].Expr is TSqlFuncCallNode then
    begin
      Fn := TSqlFuncCallNode(Sel.Columns[i].Expr);
      if SameText(Fn.FuncName, 'COUNT') then
        Types[i] := VCT_INT
      else if SameText(Fn.FuncName, 'SUM') or SameText(Fn.FuncName, 'AVG') then
        Types[i] := VCT_FLOAT;
    end;
  end;
end;

procedure TVSqlExecutor.MaterializeCtes(Stmt: TSqlSelectStmt);var
  i: Integer;
  R: TSqlResult;
  T: TCteTable;
  Nm: string;
begin
  if (Stmt.WithQueries.Count = 0) or (FCteTables = nil) then Exit;
  for i := 0 to Stmt.WithQueries.Count - 1 do
  begin
    Nm := VDbNorm(Stmt.WithQueries[i].Name);
    // Sira onemli: sonraki CTE oncekileri gorebilir (kapsamda birikir).
    R := SubResult(Stmt.WithQueries[i].Select);
    T.Names := R.Fields;
    T.Rows := R.Rows;
    CteColTypes(Stmt.WithQueries[i].Select, R.Fields, T.Types);
    if FCteTables.ContainsKey(Nm) then
      FCteTables[Nm] := T
    else
      FCteTables.Add(Nm, T);
  end;
end;

{ ------------------------------------------------------------
  EvalBool
  //---------------------------------------------------------- }
function TVSqlExecutor.EvalBool(Expr: TSqlExprNode; const Row: TStrArray;
  const ColNames: TStrArray; const ColTypes: TByteArray): Boolean;
var s: string;
begin
  if Expr = nil then Exit(True);
  s := EvalExpr(Expr, Row, ColNames, ColTypes);
  Result := SameText(s, 'True') or (s = '1');
end;

{ ------------------------------------------------------------
  RowMatches
  //---------------------------------------------------------- }
function TVSqlExecutor.RowMatches(WhereClause: TSqlExprNode;
  const Row: TStrArray; const ColNames: TStrArray; const ColTypes: TByteArray): Boolean;
begin
  Result := EvalBool(WhereClause, Row, ColNames, ColTypes);
end;

{ ------------------------------------------------------------
  HasAggregate
  //---------------------------------------------------------- }
function HasAggregateExpr(E: TSqlExprNode): Boolean;
begin
  if E = nil then Exit(False);
  if E is TSqlFuncCallNode then
  begin
    if (TSqlFuncCallNode(E).FuncName = 'COUNT') or
       (TSqlFuncCallNode(E).FuncName = 'SUM') or
       (TSqlFuncCallNode(E).FuncName = 'AVG') or
       (TSqlFuncCallNode(E).FuncName = 'MIN') or
       (TSqlFuncCallNode(E).FuncName = 'MAX') then Exit(True);
    Exit(HasAggregateExpr(TSqlFuncCallNode(E).Arg));
  end;
  if E is TSqlBinaryOpNode then
    Exit(HasAggregateExpr(TSqlBinaryOpNode(E).Left) or HasAggregateExpr(TSqlBinaryOpNode(E).Right));
  if E is TSqlUnaryOpNode then
    Exit(HasAggregateExpr(TSqlUnaryOpNode(E).Operand));
  Result := False;
end;

function TVSqlExecutor.HasAggregate(Stmt: TSqlSelectStmt): Boolean;
var
  i: Integer;
  fn: TSqlFuncCallNode;
begin
  for i := 0 to Stmt.Columns.Count - 1 do
    if Stmt.Columns[i].Expr is TSqlFuncCallNode then
    begin
      fn := TSqlFuncCallNode(Stmt.Columns[i].Expr);
      if (fn.FuncName = 'COUNT') or (fn.FuncName = 'SUM') or
         (fn.FuncName = 'AVG')   or (fn.FuncName = 'MIN') or
         (fn.FuncName = 'MAX') then Exit(True);
    end;
  if Stmt.HavingClause <> nil then Exit(True);
  Result := False;
end;

{ ------------------------------------------------------------
  Pencere yerlesim denetimi (P5-WIN)
  //---------------------------------------------------------- }
function TVSqlExecutor.HasWindow(Stmt: TSqlSelectStmt): Boolean;

  function Walk(E: TSqlExprNode): Boolean;
  var
    k: Integer;
  begin
    Result := False;
    if E = nil then Exit;
    if E is TSqlWindowNode then Exit(True);
    if E is TSqlBinaryOpNode then
      Exit(Walk(TSqlBinaryOpNode(E).Left) or Walk(TSqlBinaryOpNode(E).Right));
    if E is TSqlUnaryOpNode then
      Exit(Walk(TSqlUnaryOpNode(E).Operand));
    if E is TSqlInNode then
    begin
      if Walk(TSqlInNode(E).Expr) then Exit(True);
      for k := 0 to TSqlInNode(E).List.Count - 1 do
        if Walk(TSqlInNode(E).List[k]) then Exit(True);
      Exit(False); // alt sorgular kendi ExecSelect'inde denetlenir
    end;
    if E is TSqlBetweenNode then
      Exit(Walk(TSqlBetweenNode(E).Expr) or
           Walk(TSqlBetweenNode(E).LowBound) or
           Walk(TSqlBetweenNode(E).HighBound));
    if E is TSqlFuncCallNode then
      Exit(Walk(TSqlFuncCallNode(E).Arg));
    if E is TSqlCaseNode then
    begin
      if Walk(TSqlCaseNode(E).Operand) then Exit(True);
      for k := 0 to TSqlCaseNode(E).Whens.Count - 1 do
        if Walk(TSqlCaseNode(E).Whens[k].Cond) or
           Walk(TSqlCaseNode(E).Whens[k].Value) then Exit(True);
      Exit(Walk(TSqlCaseNode(E).ElseExpr));
    end;
  end;

var
  i: Integer;
begin
  Result := False;
  for i := 0 to Stmt.Columns.Count - 1 do
    if Walk(Stmt.Columns[i].Expr) then Exit(True);
end;

procedure TVSqlExecutor.CheckWindowPlacement(Stmt: TSqlSelectStmt);

  procedure AssertNoWindow(E: TSqlExprNode; const Where: string);
  var
    k: Integer;
  begin
    if E = nil then Exit;
    if E is TSqlWindowNode then
      raise EVDbException.Create(ecUnsupported,
        'pencere fonksiyonu yalnizca SELECT listesinde kullanilabilir (' +
        Where + ')');
    if E is TSqlBinaryOpNode then
    begin
      AssertNoWindow(TSqlBinaryOpNode(E).Left, Where);
      AssertNoWindow(TSqlBinaryOpNode(E).Right, Where);
    end
    else if E is TSqlUnaryOpNode then
      AssertNoWindow(TSqlUnaryOpNode(E).Operand, Where)
    else if E is TSqlInNode then
    begin
      AssertNoWindow(TSqlInNode(E).Expr, Where);
      for k := 0 to TSqlInNode(E).List.Count - 1 do
        AssertNoWindow(TSqlInNode(E).List[k], Where);
    end
    else if E is TSqlBetweenNode then
    begin
      AssertNoWindow(TSqlBetweenNode(E).Expr, Where);
      AssertNoWindow(TSqlBetweenNode(E).LowBound, Where);
      AssertNoWindow(TSqlBetweenNode(E).HighBound, Where);
    end
    else if E is TSqlFuncCallNode then
      AssertNoWindow(TSqlFuncCallNode(E).Arg, Where)
    else if E is TSqlCaseNode then
    begin
      AssertNoWindow(TSqlCaseNode(E).Operand, Where);
      for k := 0 to TSqlCaseNode(E).Whens.Count - 1 do
      begin
        AssertNoWindow(TSqlCaseNode(E).Whens[k].Cond, Where);
        AssertNoWindow(TSqlCaseNode(E).Whens[k].Value, Where);
      end;
      AssertNoWindow(TSqlCaseNode(E).ElseExpr, Where);
    end
    else if E is TSqlWindowNode then
      raise EVDbException.Create(ecUnsupported,
        'pencere fonksiyonu yalnizca SELECT listesinde kullanilabilir (' +
        Where + ')');
    // Alt sorgular (SubSelect/Select) kendi cumlelerinde denetlenir.
  end;

var
  i, k: Integer;
begin
  // SELECT listesi: ust-duzey pencere serbest, ic ice yasak.
  for i := 0 to Stmt.Columns.Count - 1 do
    if not (Stmt.Columns[i].Expr is TSqlWindowNode) then
      AssertNoWindow(Stmt.Columns[i].Expr, 'SELECT');
  AssertNoWindow(Stmt.WhereClause, 'WHERE');
  AssertNoWindow(Stmt.HavingClause, 'HAVING');
  if Stmt.OrderBy <> nil then
    for k := 0 to Stmt.OrderBy.Count - 1 do
      AssertNoWindow(Stmt.OrderBy[k].Expr, 'ORDER BY');
  if Stmt.HasJoin then
  begin
    AssertNoWindow(Stmt.Join.OnCondition, 'JOIN ON');
    for k := 0 to Stmt.MoreJoins.Count - 1 do
      AssertNoWindow(Stmt.MoreJoins[k].OnCondition, 'JOIN ON');
  end;
end;

{ ============================================================
   NarrowRows - WHERE'den satir adayi daraltma

   SORUN: ExecSelect/ExecUpdate/ExecDelete kosiulsuz olarak
   FT.ScanRows cagirip TUM tabloyu bellege cekiyordu. 100.000 satirlik
   tabloda "WHERE id = 5" bile ~900 ms suruyordu (PK hash ile O(1)
   olmaliydi).

   COZUM: WHERE AST'sinden su iki kaliptan biri cikarilir:
     1) PK kolonunda '='  -> ReadRow ile TEK satir (O(1))
     2) indeksli kolonda '=', '>', '>=', '<', '<=', BETWEEN, IN
        -> indeks dilimi, yalniz o aralik okunur
   Bulunamazsa False doner ve cagri tam tarama yapar.

   GUVENLILIK: dilim yalnizca bir UST KUMEDIR; donen satirlarin tamami
   RowMatches ile yeniden dogrulanir. Bu yuzden "hangi satirlar eslesir"
   sorusunun cevabi degismez - sadece okunacak satir sayisi azalir.
   ============================================================ }

function TVSqlExecutor.NarrowRows(const Td: TTableDef; WhereClause: TSqlExprNode;
  const ColNames: TStrArray; const ColTypes: TByteArray;
  out Pks: TStrArray; out Rows: TStrMatrix): Boolean;
var
  conj: TList<TSqlExprNode>;
  i, ci, lo, hi, l2, h2, n: Integer;
  e: TIdxEntries;
  ct: Byte;
  pkVal: string;
  bestCol: Integer;
  bestLo, bestHi: Integer;
  foundRange: Boolean;
  op: TSqlBinaryOp;
  cr: TSqlColumnRefNode;
  opName: string;
  oneRow: TStrArray;
  nParts: Integer;

  procedure Push(C: TSqlExprNode);
  begin
    if (C is TSqlBinaryOpNode) and (TSqlBinaryOpNode(C).Op = sboAnd) then
    begin
      Push(TSqlBinaryOpNode(C).Left);
      Push(TSqlBinaryOpNode(C).Right);
    end
    else
      conj.Add(C);
  end;

  // Sutun + tek sabit iceren karsilastirmayi "op" adina cevirir.
  function AsSimple(const C: TSqlExprNode; out ColI: Integer;
    out Val: string; out Op: TSqlBinaryOp): Boolean;
  var
    nn: TSqlBinaryOpNode;
    a, b: TSqlColumnRefNode;
    q: Integer;
  begin
    Result := False;
    Op := sboEq; ColI := -1; Val := '';
    if not (C is TSqlBinaryOpNode) then Exit;
    nn := TSqlBinaryOpNode(C);
    if (nn.Op = sboAnd) or (nn.Op = sboOr) or (nn.Op = sboAdd) or
       (nn.Op = sboSub) or (nn.Op = sboMul) or (nn.Op = sboDiv) or
       (nn.Op = sboMod) or (nn.Op = sboLike) then Exit;
    a := nil; b := nil;
    if nn.Left  is TSqlColumnRefNode then a := TSqlColumnRefNode(nn.Left);
    if nn.Right is TSqlColumnRefNode then b := TSqlColumnRefNode(nn.Right);
    if (a <> nil) and (nn.Right is TSqlLiteralNode) then
    begin
      ColI := -1;
      for q := 0 to High(Td.Cols) do
        if VDbNorm(Td.Cols[q].Name) = VDbNorm(a.ColumnName) then
        begin ColI := q; Break; end;
      if ColI < 0 then Exit;
      Val := TSqlLiteralNode(nn.Right).AsString;
      Op := nn.Op;
      Exit(True);
    end;
    if (b <> nil) and (nn.Left is TSqlLiteralNode) then
    begin
      // "5 = a" -> "a = 5" (yansitilmis operator)
      ColI := -1;
      for q := 0 to High(Td.Cols) do
        if VDbNorm(Td.Cols[q].Name) = VDbNorm(b.ColumnName) then
        begin ColI := q; Break; end;
      if ColI < 0 then Exit;
      Val := TSqlLiteralNode(nn.Left).AsString;
      case nn.Op of
        sboEq:  Op := sboEq;
        sboNeq: Op := sboNeq;
        sboLt:  Op := sboGt;
        sboLte: Op := sboGte;
        sboGt:  Op := sboLt;
        sboGte: Op := sboLte;
        else    Exit;
      end;
      Exit(True);
    end;
  end;

begin
  SetLength(Pks, 0);
  SetLength(Rows, 0);
  Result := False;
  if WhereClause = nil then Exit;

  conj := TList<TSqlExprNode>.Create;
  try
    Push(WhereClause);
    if conj.Count = 0 then Exit;

    // --- 1) PK nokta aramasi (en degerli yol) ---
    for i := 0 to conj.Count - 1 do
      if AsSimple(conj[i], ci, pkVal, op) and (Td.PkIndex >= 0) and
         (ci = Td.PkIndex) and
         (op = sboEq) then
      begin
        if FT.ReadRow(Td.Name, pkVal, oneRow) and
           RowMatches(WhereClause, oneRow, ColNames, ColTypes) then
        begin
          SetLength(Pks, 1);
          SetLength(Rows, 1);
          Pks[0] := pkVal;
          Rows[0] := oneRow;
        end;
        // eslesme yoksa da bos sonuc DONDURULUR: tam tarama gerekmez
        Exit(True);
      end;

    // --- 1b) PK uzerinde IN (...) : her deger icin tek O(1) arama ---
    // (PK'nin bellek indeksi yoktur; kucuk listelerde tek tek okumak
    //  tam taramadan kat kat hizlidir.)
    // NOT: alt sorgulu IN burada ele alinmaz (liste bossa bos donerdi).
    if Td.PkIndex >= 0 then
      for i := 0 to conj.Count - 1 do
        if (conj[i] is TSqlInNode) and (not TSqlInNode(conj[i]).IsNot) and
           (TSqlInNode(conj[i]).SubSelect = nil) and
           (TSqlInNode(conj[i]).Expr is TSqlColumnRefNode) and
           (TSqlInNode(conj[i]).List.Count <= 512) then
        begin
          ci := -1;
          for n := 0 to High(Td.Cols) do
            if VDbNorm(Td.Cols[n].Name) =
               VDbNorm(TSqlColumnRefNode(TSqlInNode(conj[i]).Expr).ColumnName) then
            begin ci := n; Break; end;
          if ci <> Td.PkIndex then Continue;
          SetLength(Pks, 0);
          SetLength(Rows, 0);
          for n := 0 to TSqlInNode(conj[i]).List.Count - 1 do
          begin
            if not (TSqlInNode(conj[i]).List[n] is TSqlLiteralNode) then Continue;
            pkVal := TSqlLiteralNode(TSqlInNode(conj[i]).List[n]).AsString;
            if FT.ReadRow(Td.Name, pkVal, oneRow) then
            begin
              SetLength(Pks, Length(Pks) + 1);
              SetLength(Rows, Length(Rows) + 1);
              Pks[High(Pks)] := pkVal;
              Rows[High(Rows)] := oneRow;
            end;
          end;
          Exit(True);   // filtre RowMatches ile asagida uygulanir
        end;

    // --- 2) indeks dilimi ---
    bestCol := -1; bestLo := 0; bestHi := 0; foundRange := False;
    for i := 0 to conj.Count - 1 do
    begin
      lo := 0; hi := 0;
      // 2a) basit karsilastirma
      if AsSimple(conj[i], ci, pkVal, op) then
      begin
        opName := '';
        case op of
          sboEq:  opName := '=';
          sboGt:  opName := '>';
          sboGte: opName := '>=';
          sboLt:  opName := '<';
          sboLte: opName := '<=';
        end;
        if opName <> '' then
        begin
          if not FT.TryGetMemIndex(Td.TableId, ci, e) then Continue;
          if not VDbIdxRangeL(e, Td.Cols[ci].Ctype, opName, pkVal, FT.IdxNParts(Td.TableId, ci), lo, hi) then
            Continue;
        end
        else Continue;
      end
      // 2b) BETWEEN a AND b
      else if (conj[i] is TSqlBetweenNode) and
              (not TSqlBetweenNode(conj[i]).IsNot) and
              (TSqlBetweenNode(conj[i]).Expr is TSqlColumnRefNode) and
              (TSqlBetweenNode(conj[i]).LowBound  is TSqlLiteralNode) and
              (TSqlBetweenNode(conj[i]).HighBound is TSqlLiteralNode) then
      begin
        cr := TSqlColumnRefNode(TSqlBetweenNode(conj[i]).Expr);
        ci := -1;
        for n := 0 to High(Td.Cols) do
          if VDbNorm(Td.Cols[n].Name) = VDbNorm(cr.ColumnName) then
          begin ci := n; Break; end;
        if ci < 0 then Continue;
        if not FT.TryGetMemIndex(Td.TableId, ci, e) then Continue;
        ct := Td.Cols[ci].Ctype;
        nParts := FT.IdxNParts(Td.TableId, ci);
        if not VDbIdxRangeL(e, ct, '>=',
             TSqlLiteralNode(TSqlBetweenNode(conj[i]).LowBound).AsString, nParts, l2, h2) then
          Continue;
        lo := l2; hi := Length(e);
        if VDbIdxRangeL(e, ct, '<=',
             TSqlLiteralNode(TSqlBetweenNode(conj[i]).HighBound).AsString, nParts, l2, h2) then
          if h2 < hi then hi := h2;
      end
      // 2c) IN (a, b, c, ...)
      else if (conj[i] is TSqlInNode) and (not TSqlInNode(conj[i]).IsNot) and
              (TSqlInNode(conj[i]).Expr is TSqlColumnRefNode) then
      begin
        cr := TSqlColumnRefNode(TSqlInNode(conj[i]).Expr);
        ci := -1;
        for n := 0 to High(Td.Cols) do
          if VDbNorm(Td.Cols[n].Name) = VDbNorm(cr.ColumnName) then
          begin ci := n; Break; end;
        if (ci < 0) or (TSqlInNode(conj[i]).List.Count = 0) then Continue;
        if not FT.TryGetMemIndex(Td.TableId, ci, e) then Continue;
        ct := Td.Cols[ci].Ctype;
        nParts := FT.IdxNParts(Td.TableId, ci);
        lo := MaxInt; hi := 0;
        for n := 0 to TSqlInNode(conj[i]).List.Count - 1 do
        begin
          if not (TSqlInNode(conj[i]).List[n] is TSqlLiteralNode) then Continue;
          pkVal := TSqlLiteralNode(TSqlInNode(conj[i]).List[n]).AsString;
          // alt sinir: EN KUCUK degerin '>=' baslangici
          if VDbIdxRangeL(e, ct, '>=', pkVal, nParts, l2, h2) then
            if l2 < lo then lo := l2;
          // ust sinir: EN BUYUK degerin '<=' bitisi
          if VDbIdxRangeL(e, ct, '<=', pkVal, nParts, l2, h2) then
            if h2 > hi then hi := h2;
        end;
        if (lo = MaxInt) or (hi = 0) then Continue;
      end
      else Continue;

      // ONEMLI: birden fazla indeks kosulu ancak AYNI KOLONDA ise
      // kesisilir. Farkli kolonlarda kesisim anlamsizdir (iki farkli
      // indeks dizisinin konumlari birbirine denk gelmez) ve hatta
      // dizi sonuna tasmaya yol acardi. Farkli kolonlu kosul yok sayilir;
      // sonuctaki satirlar yine RowMatches ile dogrulanir.
      if foundRange and (ci <> bestCol) then Continue;

      if not foundRange then
      begin
        foundRange := True; bestCol := ci; bestLo := lo; bestHi := hi;
      end
      else
      begin
        if lo > bestLo then bestLo := lo;
        if hi < bestHi then bestHi := hi;
      end;
    end;

    if not foundRange then Exit;   // -> tam tarama
    if bestHi <= bestLo then       // kesim bos
    begin
      Exit(True);                  // 0 satir, tam tarama gerekmez
    end;
    // e dizisini KULLANILACAK kolona bagla (yukaridaki kosullar e'yi
    // degistirmis olabilir)
    if not FT.TryGetMemIndex(Td.TableId, bestCol, e) then Exit;

    SetLength(Pks, bestHi - bestLo);
    SetLength(Rows, bestHi - bestLo);
    n := 0;
    for i := bestLo to bestHi - 1 do
      if FT.ReadRow(Td.Name, e[i].Pk, Rows[n]) then
      begin
        Pks[n] := e[i].Pk;
        Inc(n);
      end;
    SetLength(Pks, n);
    SetLength(Rows, n);
    Result := True;
  finally
    conj.Free;
  end;
end;

function TVSqlExecutor.TryIndexOrder(const Td: TTableDef; Stmt: TSqlSelectStmt;
  const ColNames: TStrArray; const ColTypes: TByteArray;
  out Rows: TStrMatrix): Boolean;
// ORDER BY <indeksli kolon(lar)> -> satirlari indeks sirasiyla oku.
// COK KOLONLU: ORDER BY a, b ile indeksin (a, b) on ek'i eslesiyorsa
// hicbir siralama yapilmaz; satirlar indeks sirasiyla okunur.
var
  e: TIdxEntries;
  ci, lo, hi, l2, h2, i, j, n, off, lim, need: Integer;
  desc: Boolean;
  descAny: Boolean;
  rv: TStrArray;
  cr: TSqlColumnRefNode;
  conj: TList<TSqlExprNode>;
  node: TSqlBinaryOpNode;
  opName: string;
  pkVal: string;
  oCols: TIntArray;      // ORDER BY kolonlari (tablo indeksleri)
  icols: TIntArray;      // indeksin kolonlari
  nIdxCols: Integer;     // indeksin kac kolonu
  leadingMatch: Integer; // ORDER BY'nin indeks on ekiyle eslesen kolon sayisi

  procedure Push(C: TSqlExprNode);
  begin
    if (C is TSqlBinaryOpNode) and (TSqlBinaryOpNode(C).Op = sboAnd) then
    begin
      Push(TSqlBinaryOpNode(C).Left);
      Push(TSqlBinaryOpNode(C).Right);
    end
    else
      conj.Add(C);
  end;

begin
  SetLength(Rows, 0);
  Result := False;
  // Yalniz: JOIN yok, aggregate yok, GROUP BY yok, DISTINCT yok,
  // pencere yok, ORDER BY kolonlari ve hepsi kolon referansi olmali.
  if Stmt.HasJoin or Stmt.IsDistinct then Exit;
  if HasAggregate(Stmt) or (Stmt.GroupByCols.Count > 0) then Exit;
  if HasWindow(Stmt) then Exit; // pencere tum kumeyi gorur (LIMIT oncesi)
  // P5-TR: indeks sirasi bayt duzenidir; COLLATE TR DoSort'a birakilir.
  if (Stmt.OrderBy <> nil) then
    for i := 0 to Stmt.OrderBy.Count - 1 do
      if Stmt.OrderBy[i].Collate = 'TR' then Exit;
  if (Stmt.OrderBy = nil) or (Stmt.OrderBy.Count = 0) then Exit;
  for i := 0 to Stmt.OrderBy.Count - 1 do
    if not (Stmt.OrderBy[i].Expr is TSqlColumnRefNode) then Exit;
  { LIMIT/OFFSET YOKSA indeksten tek tek ReadRow yapmak TAM TARAMA + siralamadan
    YAVAS kalir (her satir rastgele seek). Bu durumda eski yol tercih edilir;
    WHERE ile daraltma zaten NarrowRows'ta devreye giriyor. }
  if (Stmt.LimitVal < 0) and (Stmt.OffsetVal <= 0) then Exit;

  // ORDER BY kolonlarini coz
  SetLength(oCols, Stmt.OrderBy.Count);
  for i := 0 to Stmt.OrderBy.Count - 1 do
  begin
    cr := TSqlColumnRefNode(Stmt.OrderBy[i].Expr);
    oCols[i] := -1;
    for j := 0 to High(Td.Cols) do
      if VDbNorm(Td.Cols[j].Name) = VDbNorm(cr.ColumnName) then
      begin oCols[i] := j; Break; end;
    if oCols[i] < 0 then Exit;
  end;

  // Bilesik (farkli yonler) siralama indeksten saglanamaz.
  descAny := False;
  for i := 1 to Stmt.OrderBy.Count - 1 do
    if Stmt.OrderBy[i].Desc <> Stmt.OrderBy[0].Desc then descAny := True;
  if descAny then Exit;

  ci := oCols[0];
  if not FT.TryGetMemIndex(Td.TableId, ci, e) then Exit;
  nIdxCols := FT.IdxNParts(Td.TableId, ci);
  if Stmt.OrderBy.Count > nIdxCols then Exit;

  // ORDER BY kolonlari indeksin on ekiyle SIRAYLA eslesmeli
  icols := FT.IdxColsOfTable(Td.TableId, ci);
  if Length(icols) = 0 then Exit;
  leadingMatch := 0;
  for i := 0 to Stmt.OrderBy.Count - 1 do
    if icols[i] = oCols[i] then Inc(leadingMatch) else Break;
  if leadingMatch < Stmt.OrderBy.Count then Exit;

  desc := Stmt.OrderBy[0].Desc;

  // WHERE ile dilim daralt (yalnizca ILK ORDER BY kolonu uzerinden; boylece
  // dilim icinde indeks sirasi ORDER BY sirasiyla ayni kalir)
  lo := 0; hi := Length(e);
  conj := TList<TSqlExprNode>.Create;
  try
    if Stmt.WhereClause <> nil then Push(Stmt.WhereClause);
    for i := 0 to conj.Count - 1 do
    begin
      opName := '';
      if (conj[i] is TSqlBinaryOpNode) then
      begin
        node := TSqlBinaryOpNode(conj[i]);
        if node.Right is TSqlLiteralNode then
          case node.Op of
            sboEq:  opName := '=';
            sboGt:  opName := '>';
            sboGte: opName := '>=';
            sboLt:  opName := '<';
            sboLte: opName := '<=';
          end;
      end;
      if opName = '' then Continue;   // bu kosulu indeksleyemeyiz -> daraltma
      if not (TSqlBinaryOpNode(conj[i]).Left is TSqlColumnRefNode) then Continue;
      if VDbNorm(TSqlColumnRefNode(TSqlBinaryOpNode(conj[i]).Left).ColumnName) <>
         VDbNorm(Td.Cols[ci].Name) then Continue;
      pkVal := TSqlLiteralNode(node.Right).AsString;
      if not VDbIdxRangeL(e, Td.Cols[ci].Ctype, opName, pkVal,
      FT.IdxNParts(Td.TableId, ci), l2, h2) then Continue;
      if l2 > lo then lo := l2;
      if h2 < hi then hi := h2;
    end;
  finally
    conj.Free;
  end;

  off := Stmt.OffsetVal;
  lim := Stmt.LimitVal;
  need := lim;
  if need < 0 then need := -1;
  SetLength(Rows, 0);
  n := 0;
  if desc then
  begin
    i := hi - 1;
    while i >= lo do
    begin
      if FT.ReadRow(Td.Name, e[i].Pk, rv) and
         RowMatches(Stmt.WhereClause, rv, ColNames, ColTypes) then
      begin
        if off > 0 then Dec(off)
        else
        begin
          SetLength(Rows, Length(Rows) + 1);
          Rows[High(Rows)] := rv;
          if (need >= 0) and (Length(Rows) >= need) then Break;
        end;
      end;
      Dec(i);
    end;
  end
  else
  begin
    i := lo;
    while i < hi do
    begin
      if FT.ReadRow(Td.Name, e[i].Pk, rv) and
         RowMatches(Stmt.WhereClause, rv, ColNames, ColTypes) then
      begin
        if off > 0 then Dec(off)
        else
        begin
          SetLength(Rows, Length(Rows) + 1);
          Rows[High(Rows)] := rv;
          if (need >= 0) and (Length(Rows) >= need) then Break;
        end;
      end;
      Inc(i);
    end;
  end;
  Result := True;
end;

type
  TSortColInfo = record
    ColIdx: Integer;
    CType: Byte;
    Desc: Boolean;
    UseTr: Boolean;  // P5-TR: COLLATE TR (yalniz metin kolonlarda)
  end;

{ ------------------------------------------------------------
  DoSort - Bellek-ici ORDER BY (Iterative QuickSort, O(N log N))
  //---------------------------------------------------------- }
procedure TVSqlExecutor.DoSort(var Rows: TStrMatrix; const Keys: TStrArray;
  OrderBy: TList<TOrderItem>;
  const ColNames: TStrArray; const ColTypes: TByteArray);
var
  i, j, k, kidx, m, c, validCount: Integer;
  sortCols: array of TSortColInfo;
  idx: array of Integer;
  newRows: TStrMatrix;
  // F3-3/F3-2: quicksort yigini. Derinlik log2(N) oldugu icin 64 cerverek
  // fazladir; yine de tasma OLSA bile dizi disina yazmamak icin asagidaki
  // VDB_SORT_STACK_MAX sinirinda hata verilir (ulasilamaz, savunma).
  StackL, StackH: array[0..VDB_SORT_STACK_MAX - 1] of Integer;
  SP, L, H, pIdx, tIdx: Integer;
  intKeys: array of Int64;
  vInt, pivInt, tInt: Int64;
  desc: Boolean;

  function CompareRowIdx(ra, rb: Integer): Integer;
  var
    sk, sc: Integer;
    sct: Byte;
    sav, sbv: string;
    tc: Integer;
  begin
    Result := 0;
    for sk := 0 to High(sortCols) do
    begin
      sc := sortCols[sk].ColIdx;
      sct := sortCols[sk].CType;
      if (sc >= 0) and (sc <= High(Rows[ra])) then sav := Rows[ra][sc] else sav := '';
      if (sc >= 0) and (sc <= High(Rows[rb])) then sbv := Rows[rb][sc] else sbv := '';
      if sortCols[sk].UseTr then
      begin
        // P5-TR: NULL davranisi bayt sirasayla ayni (esit sayilir).
        if (sav = '') or (sbv = '') then
          Result := 0
        else
        begin
          tc := VDbCompareTr(sav, sbv);
          if tc < 0 then Result := -1
          else if tc > 0 then Result := 1
          else Result := 0;
        end;
      end
      else if VDbCmpVal(sav, sbv, '<', sct) then Result := -1
      else if VDbCmpVal(sav, sbv, '>', sct) then Result := 1
      else Result := 0;
      if Result <> 0 then
      begin
        if sortCols[sk].Desc then Result := -Result;
        Exit;
      end;
    end;
  end;

begin
  if (OrderBy = nil) or (OrderBy.Count = 0) or (Length(Rows) < 2) then Exit;

  // 1. Siralama kolonlarini onceden coz (her karsilastirmada Name arama!)
  SetLength(sortCols, OrderBy.Count);
  validCount := 0;
  for k := 0 to OrderBy.Count - 1 do
  begin
    kidx := -1;
    for m := 0 to High(ColNames) do
    begin
      if SameText(ColNames[m], Keys[k]) then
      begin kidx := m; Break; end;
      if (Pos('.', ColNames[m]) > 0) and
         SameText(Copy(ColNames[m], Pos('.', ColNames[m]) + 1, MaxInt), Keys[k]) then
      begin kidx := m; Break; end;
      if (Pos('.', Keys[k]) > 0) and
         SameText(Copy(Keys[k], Pos('.', Keys[k]) + 1, MaxInt), ColNames[m]) then
      begin kidx := m; Break; end;
    end;
    if kidx >= 0 then
    begin
      sortCols[validCount].ColIdx := kidx;
      if kidx < Length(ColTypes) then
        sortCols[validCount].CType := ColTypes[kidx]
      else
        sortCols[validCount].CType := VCT_STR;
      sortCols[validCount].Desc := OrderBy[k].Desc;
      // P5-TR: yalniz metin kolonlarda gecerli (sayisal siralama korunur).
      sortCols[validCount].UseTr :=
        (OrderBy[k].Collate = 'TR') and
        (sortCols[validCount].CType = VCT_STR);
      Inc(validCount);
    end
    // F1-21: bilinmeyen kolon sessizce yok sayilmaz, hata verir.
    else if Keys[k] <> '' then
      raise EVDbException.Create(ecColumnNotFound,
        'ORDER BY bilinmeyen kolon: ' + Keys[k]);
  end;
  SetLength(sortCols, validCount);
  if validCount = 0 then Exit;

  // 2. Indeks dizisi olustur
  SetLength(idx, Length(Rows));
  for i := 0 to High(Rows) do idx[i] := i;

  // 3. Tekil sayisal kolon icin ultra-hizli tamsayi QuickSort
  if (validCount = 1) and ((sortCols[0].CType = VCT_INT) or (sortCols[0].CType = VCT_BOOL)) then
  begin
    c := sortCols[0].ColIdx;
    desc := sortCols[0].Desc;
    SetLength(intKeys, Length(Rows));
    for i := 0 to High(Rows) do
    begin
      if (c <= High(Rows[i])) and VDbParseInt(Rows[i][c], vInt) then
        intKeys[i] := vInt
      else
        intKeys[i] := Low(Int64);
    end;

    SP := 0;
    StackL[0] := 0; StackH[0] := High(idx); Inc(SP);
    while SP > 0 do
    begin
      Dec(SP);
      L := StackL[SP]; H := StackH[SP];
      while L < H do
      begin
        pivInt := intKeys[(L + H) div 2];
        i := L; j := H;
        repeat
          if desc then
          begin
            while intKeys[i] > pivInt do Inc(i);
            while intKeys[j] < pivInt do Dec(j);
          end
          else
          begin
            while intKeys[i] < pivInt do Inc(i);
            while intKeys[j] > pivInt do Dec(j);
          end;
          if i <= j then
          begin
            tIdx := idx[i]; idx[i] := idx[j]; idx[j] := tIdx;
            tInt := intKeys[i]; intKeys[i] := intKeys[j]; intKeys[j] := tInt;
            Inc(i); Dec(j);
          end;
        until i > j;
        if (j - L) < (H - i) then
        begin
          if i < H then
          begin
            if SP > High(StackL) then
              raise EVDbException.Create(ecLimit, 'siralama yigini asildi');
            StackL[SP] := i; StackH[SP] := H; Inc(SP);
          end;
          H := j;
        end
        else
        begin
          if L < j then
          begin
            if SP > High(StackL) then
              raise EVDbException.Create(ecLimit, 'siralama yigini asildi');
            StackL[SP] := L; StackH[SP] := j; Inc(SP);
          end;
          L := i;
        end;
      end;
    end;
  end
  else
  begin
    // 4. Genel tip-bilgili Quicksort
    SP := 0;
    StackL[0] := 0; StackH[0] := High(idx); Inc(SP);
    while SP > 0 do
    begin
      Dec(SP);
      L := StackL[SP]; H := StackH[SP];
      while L < H do
      begin
        pIdx := idx[(L + H) div 2];
        i := L; j := H;
        repeat
          while CompareRowIdx(idx[i], pIdx) < 0 do Inc(i);
          while CompareRowIdx(idx[j], pIdx) > 0 do Dec(j);
          if i <= j then
          begin
            tIdx := idx[i]; idx[i] := idx[j]; idx[j] := tIdx;
            Inc(i); Dec(j);
          end;
        until i > j;
        if (j - L) < (H - i) then
        begin
          if i < H then
          begin
            if SP > High(StackL) then
              raise EVDbException.Create(ecLimit, 'siralama yigini asildi');
            StackL[SP] := i; StackH[SP] := H; Inc(SP);
          end;
          H := j;
        end
        else
        begin
          if L < j then
          begin
            if SP > High(StackL) then
              raise EVDbException.Create(ecLimit, 'siralama yigini asildi');
            StackL[SP] := L; StackH[SP] := j; Inc(SP);
          end;
          L := i;
        end;
      end;
    end;
  end;

  // 5. Siralanmis indekslere gore satirlari tek seferde O(N) kopyala
  SetLength(newRows, Length(Rows));
  for i := 0 to High(Rows) do
    newRows[i] := Rows[idx[i]];
  Rows := newRows;
end;

{ ------------------------------------------------------------
  ExecJoinScan
  //---------------------------------------------------------- }
// P5-CTE: materyal kumeden sahte tablo tanimi (Taraf cozumu icin).
// TableId=0, PkIndex=-1: indeks/PK yollari bu tanimla denenmez.
procedure PseudoDef(const TableName: string; const Names: TStrArray;
  const Types: TByteArray; out Td: TTableDef);
var
  k: Integer;
begin
  Td.TableId := 0;
  Td.Name := TableName;
  SetLength(Td.Cols, Length(Names));
  for k := 0 to High(Names) do
  begin
    Td.Cols[k].Name := Names[k];
    Td.Cols[k].Ctype := VCT_STR;
    if k < Length(Types) then
      Td.Cols[k].Ctype := Types[k];
    Td.Cols[k].NotNull := False;
    Td.Cols[k].Unique := False;
    Td.Cols[k].HasDef := False;
    Td.Cols[k].Def := '';
  end;
  Td.PkIndex := -1;
  Td.AutoInc := 0;
  SetLength(Td.Idx, 0);
  SetLength(Td.Fks, 0);
  SetLength(Td.Checks, 0);
end;

procedure TVSqlExecutor.ExecJoinScan(Stmt: TSqlSelectStmt;
  out MergedRows: TStrMatrix;
  out MergedColNames: TStrArray; out MergedColTypes: TByteArray);
{ P5-1: N-tablo JOIN (soldan derin). Ilk tablo taranir, her JOIN adimi
  birikmis sol kumeyle sag tabloyu birlestirir. 2-tablo davranisi
  (nitelikli/niteliksiz kolon cozumu, indeksli hizli yol, LEFT
  NULL-genisletme) her adimda aynen korunur. }
type
  TJoinTab = record
    Def: TTableDef;
    AliasEff: string;    // Alias <> '' ? Alias : Table
    ColStart: Integer;   // birlesik satirdaki ofset
    ColCount: Integer;
  end;
  TJoinTabs = array of TJoinTab;
var
  LRows: TStrMatrix;
  LNames: TStrArray;
  LTypes: TByteArray;
  LTabs: TJoinTabs;
  td0: TTableDef;
  cn0: TStrArray;
  ct0: TByteArray;
  pks0: TStrArray;
  i, t: Integer;

  // Tek birlestirme adimi: birikmis sol (LR/LN/LT/Tabs) + sag tablo (JC).
  procedure MergeStep(var LR: TStrMatrix; var LN: TStrArray;
    var LT: TByteArray; var Tabs: TJoinTabs; const JC: TJoinClause);
  var
    rDef: TTableDef;
    rAlias: string;
    rRows: TStrMatrix;
    rPks: TStrArray;
    rCn: TStrArray;
    rCt: TByteArray;
    n1, n2: Integer;
    i, j, k, q: Integer;
    merged: TStrArray;
    onOk, matchFound: Boolean;
    rIsCte: Boolean;
    lMatched: array of Boolean;
    JoinIdxCol1, JoinIdxCol2: Integer;   // sol/sag JOIN kolonlari
    JoinUsePk: Boolean;
    JoinEntries: TIdxEntries;
    lo2, hi2: Integer;
    rv2: TStrArray;
    jv: string;
    eqn: TSqlBinaryOpNode;
    mr: TStrMatrix;        // kademeli buyume (O(n^2) SetLength onlemi)
    mrN, mrCap: Integer;
    nt: TJoinTab;

    // Bir kolon referansinin hangi tarafta oldugunu bulur.
    // Doner: 1 = sol birlesim, 2 = sag tablo, 0 = belirsiz/yok.
    // Nitelikli ad birden cok tabloyla eslesirse 0 doner; hicbiriyle
    // eslesmezse sade ada dusulur (2-tablo motoruyla ayni kural).
    function Taraf(const C: TSqlColumnRefNode; out Pos: Integer): Integer;
    var
      hitTab, hitCount, w, lc: Integer;
      nm: string;
    begin
      Pos := -1;
      Result := 0;
      hitTab := -1; hitCount := 0;
      if C.TableQualifier <> '' then
      begin
        for w := 0 to High(Tabs) do
          if SameText(C.TableQualifier, Tabs[w].AliasEff) then
          begin Inc(hitCount); hitTab := w; end;
        if SameText(C.TableQualifier, rAlias) then
        begin Inc(hitCount); hitTab := -2; end;
        if hitCount > 1 then Exit; // belirsiz
        if hitCount = 1 then
        begin
          nm := VDbNorm(C.ColumnName);
          if hitTab = -2 then
          begin
            Result := 2;
            for w := 0 to High(rDef.Cols) do
              if VDbNorm(rDef.Cols[w].Name) = nm then
              begin Pos := n1 + w; Break; end;
          end
          else
          begin
            Result := 1;
            for w := 0 to High(Tabs[hitTab].Def.Cols) do
              if VDbNorm(Tabs[hitTab].Def.Cols[w].Name) = nm then
              begin Pos := Tabs[hitTab].ColStart + w; Break; end;
          end;
          Exit;
        end;
        // hitCount = 0: asagidaki sade-ad aramasina dus (eski davranis)
      end;
      nm := VDbNorm(C.ColumnName);
      for w := 0 to High(Tabs) do
        for lc := 0 to High(Tabs[w].Def.Cols) do
          if VDbNorm(Tabs[w].Def.Cols[lc].Name) = nm then
          begin Inc(hitCount); hitTab := w; Pos := Tabs[w].ColStart + lc; end;
      for w := 0 to High(rDef.Cols) do
        if VDbNorm(rDef.Cols[w].Name) = nm then
        begin Inc(hitCount); hitTab := -2; Pos := n1 + w; end;
      if hitCount = 1 then
      begin
        if hitTab = -2 then Result := 2 else Result := 1;
      end
      else Pos := -1;
    end;

    procedure MrPush(const Row: TStrArray);
    begin
      if mrN >= 2000000 then
        raise EVDbException.Create(ecLimit, 'JOIN sonucu cok buyuk (2M sinir)');
      if mrN >= mrCap then
      begin
        if mrCap = 0 then mrCap := 64
        else mrCap := mrCap * 2;
        SetLength(mr, mrCap);
      end;
      mr[mrN] := Row;
      Inc(mrN);
    end;

  begin
    // P5-CTE: sag taraf CTE ise materyal kume kullanilir; indeks/PK
    // hizli yolu atlanir (klasik ic ice dongu her zaman dogrudur).
    rIsCte := TryCte(JC.Table, rCn, rCt, rRows);
    if rIsCte then
      PseudoDef(JC.Table, rCn, rCt, rDef)
    else
    begin
      rDef := FT.GetTable(JC.Table);
      BuildColInfo(rDef, rCn, rCt);
      FT.ScanRows(JC.Table, rPks, rRows);
    end;
    if JC.Alias <> '' then rAlias := JC.Alias else rAlias := JC.Table;
    n1 := Length(LN); n2 := Length(rCn);

    JoinIdxCol1 := -1; JoinIdxCol2 := -1; JoinUsePk := False;
    if (JC.OnCondition is TSqlBinaryOpNode) and
       (TSqlBinaryOpNode(JC.OnCondition).Op = sboEq) and
       (TSqlBinaryOpNode(JC.OnCondition).Left  is TSqlColumnRefNode) and
       (TSqlBinaryOpNode(JC.OnCondition).Right is TSqlColumnRefNode) then
    begin
      eqn := TSqlBinaryOpNode(JC.OnCondition);
      j := Taraf(TSqlColumnRefNode(eqn.Left), i);
      k := Taraf(TSqlColumnRefNode(eqn.Right), q);
      if (j = 1) and (k = 2) and (i >= 0) and (q >= 0) then
      begin
        JoinIdxCol1 := i; JoinIdxCol2 := q;
      end
      else if (j = 2) and (k = 1) and (i >= 0) and (q >= 0) then
      begin
        JoinIdxCol1 := q; JoinIdxCol2 := i;
      end;
    end;
    if JoinIdxCol2 >= 0 then
    begin
      if rIsCte then
        JoinIdxCol2 := -1   // CTE'de indeks/PK yok -> klasik yol
      else if (JC.JoinType = jtRight) or (JC.JoinType = jtFull) then
        JoinIdxCol2 := -1   // P5-RF: sag surucu klasik dongu kullanir
      else if rDef.PkIndex = JoinIdxCol2 - n1 then
        JoinUsePk := True
      else if not FT.TryGetMemIndex(rDef.TableId, JoinIdxCol2 - n1, JoinEntries) then
        JoinIdxCol2 := -1;   // indeks yok -> klasik yol
    end;

    // Sag isimler (nitelikli, alias oncelikli)
    SetLength(LN, n1 + n2);
    SetLength(LT, n1 + n2);
    for i := 0 to n2 - 1 do
    begin
      LN[n1 + i] := rAlias + '.' + rCn[i];
      LT[n1 + i] := rCt[i];
    end;

    { ----------------------------------------------------------------
      HIZLI YOL: ON <sol kolon> = <sag kolon>
      Sag tarafin JOIN kolonunda indeks (veya PK) varsa sol satir basina
      yalniz O(log n + eslesme) kadar bakilir.
      //-------------------------------------------------------------- }

    mrN := 0; mrCap := 0; SetLength(mr, 0);

    if JoinIdxCol2 >= 0 then
    begin
      for i := 0 to High(LR) do
      begin
        jv := VDbNormValue(rDef.Cols[JoinIdxCol2 - n1].Ctype, LR[i][JoinIdxCol1]);
        matchFound := False;
        if JoinUsePk then
        begin
          if FT.ReadRow(JC.Table, jv, rv2) and
             (rv2[JoinIdxCol2 - n1] = LR[i][JoinIdxCol1]) then
          begin
            SetLength(merged, n1 + n2);
            for k := 0 to n1 - 1 do merged[k] := LR[i][k];
            for k := 0 to n2 - 1 do merged[n1 + k] := rv2[k];
            MrPush(merged);
            matchFound := True;
          end;
        end
        else if VDbIdxRangeL(JoinEntries, rDef.Cols[JoinIdxCol2 - n1].Ctype, '=', jv,
                 FT.IdxNParts(rDef.TableId, JoinIdxCol2 - n1),
                 lo2, hi2) then
          for k := lo2 to hi2 - 1 do
            if FT.ReadRow(JC.Table, JoinEntries[k].Pk, rv2) then
            begin
              SetLength(merged, n1 + n2);
              for q := 0 to n1 - 1 do merged[q] := LR[i][q];
              for q := 0 to n2 - 1 do merged[n1 + q] := rv2[q];
              onOk := EvalBool(JC.OnCondition, merged, LN, LT);
              if onOk then
              begin
                MrPush(merged);
                matchFound := True;
              end;
            end;
        if (not matchFound) and (JC.JoinType = jtLeft) then
        begin
          SetLength(merged, n1 + n2);
          for k := 0 to n1 - 1 do merged[k] := LR[i][k];
          for k := 0 to n2 - 1 do merged[n1 + k] := '';
          MrPush(merged);
        end;
      end;
      SetLength(mr, mrN);
      LR := mr;
    end
    else
    begin
      // klasik ic ice dongu (sag tarafta indeks/PK yok veya CTE)
      if not rIsCte then
        FT.ScanRows(JC.Table, rPks, rRows);
      mrN := 0;
      if (JC.JoinType = jtRight) or (JC.JoinType = jtFull) then
      begin
        // P5-RF: sag surucu. Eslesmeyen sag satirlar NULL-solla korunur;
        // FULL'da ayrica eslesmeyen sol satirlar da korunur. Cikti sirasi
        // (sol kolonlar, sag kolonlar) degismez. Hizli yol yok (sol kume
        // materyaldir, indeksi yoktur) — O(n*m) klasik dongu.
        if JC.JoinType = jtFull then
        begin
          SetLength(lMatched, Length(LR));
          for i := 0 to High(lMatched) do
            lMatched[i] := False;
        end;
        for j := 0 to High(rRows) do
        begin
          matchFound := False;
          for i := 0 to High(LR) do
          begin
            SetLength(merged, n1 + n2);
            for k := 0 to n1 - 1 do merged[k] := LR[i][k];
            for k := 0 to n2 - 1 do merged[n1 + k] := rRows[j][k];
            onOk := EvalBool(JC.OnCondition, merged, LN, LT);
            if onOk then
            begin
              MrPush(merged);
              matchFound := True;
              if JC.JoinType = jtFull then
                lMatched[i] := True;
            end;
          end;
          if not matchFound then
          begin
            SetLength(merged, n1 + n2);
            for k := 0 to n1 - 1 do merged[k] := '';
            for k := 0 to n2 - 1 do merged[n1 + k] := rRows[j][k];
            MrPush(merged);
          end;
        end;
        if JC.JoinType = jtFull then
          for i := 0 to High(LR) do
            if not lMatched[i] then
            begin
              SetLength(merged, n1 + n2);
              for k := 0 to n1 - 1 do merged[k] := LR[i][k];
              for k := 0 to n2 - 1 do merged[n1 + k] := '';
              MrPush(merged);
            end;
      end
      else
      for i := 0 to High(LR) do
      begin
        matchFound := False;
        for j := 0 to High(rRows) do
        begin
          SetLength(merged, n1 + n2);
          for k := 0 to n1 - 1 do merged[k] := LR[i][k];
          for k := 0 to n2 - 1 do merged[n1 + k] := rRows[j][k];
          onOk := EvalBool(JC.OnCondition, merged, LN, LT);
          if onOk then
          begin
            MrPush(merged);
            matchFound := True;
          end;
        end;
        if (not matchFound) and (JC.JoinType = jtLeft) then
        begin
          SetLength(merged, n1 + n2);
          for k := 0 to n1 - 1 do merged[k] := LR[i][k];
          for k := 0 to n2 - 1 do merged[n1 + k] := '';
          MrPush(merged);
        end;
      end;
      SetLength(mr, mrN);
      LR := mr;
    end;

    // Sag tablo koken bilgisi (sonraki adimlarin Taraf cozumu icin)
    nt.Def := rDef; nt.AliasEff := rAlias; nt.ColStart := n1; nt.ColCount := n2;
    SetLength(Tabs, Length(Tabs) + 1);
    Tabs[High(Tabs)] := nt;
  end;

begin
  // Adim 0: sol taraf (FROM tablo veya CTE) yuklenir, isimler nitelenir
  if TryCte(Stmt.FromTable, cn0, ct0, LRows) then
    PseudoDef(Stmt.FromTable, cn0, ct0, td0)
  else
  begin
    td0 := FT.GetTable(Stmt.FromTable);
    BuildColInfo(td0, cn0, ct0);
    FT.ScanRows(Stmt.FromTable, pks0, LRows);
  end;
  SetLength(LNames, Length(cn0));
  SetLength(LTypes, Length(cn0));
  for i := 0 to High(cn0) do
  begin
    if Stmt.FromAlias <> '' then
      LNames[i] := Stmt.FromAlias + '.' + cn0[i]
    else
      LNames[i] := Stmt.FromTable + '.' + cn0[i];
    LTypes[i] := ct0[i];
  end;
  SetLength(LTabs, 1);
  LTabs[0].Def := td0;
  if Stmt.FromAlias <> '' then
    LTabs[0].AliasEff := Stmt.FromAlias
  else
    LTabs[0].AliasEff := Stmt.FromTable;
  LTabs[0].ColStart := 0;
  LTabs[0].ColCount := Length(cn0);
  // Adim 1..n: her JOIN soldan derine uygulanir
  MergeStep(LRows, LNames, LTypes, LTabs, Stmt.Join);
  for t := 0 to Stmt.MoreJoins.Count - 1 do
    MergeStep(LRows, LNames, LTypes, LTabs, Stmt.MoreJoins[t]);
  MergedRows := LRows;
  MergedColNames := LNames;
  MergedColTypes := LTypes;
end;

{ ------------------------------------------------------------
  ComputeWindows (P5-WIN)
  //---------------------------------------------------------- }
procedure TVSqlExecutor.ComputeWindows(Stmt: TSqlSelectStmt;
  const Rows: TStrMatrix; const ColNames: TStrArray;
  const ColTypes: TByteArray; out WinVals: TStrMatrix;
  out WinSlot: TIntArray);
var
  WList: TList<TSqlWindowNode>;
  j, r, s, q, k: Integer;
  WN: TSqlWindowNode;
  PDict: TDictionary<string, TList<Integer>>;
  PKeys: TList<string>;
  idxList: TList<Integer>;
  key: AnsiString;
  ord: array of Integer;
  tmpM: TStrMatrix;
  keyNames: TStrArray;
  keyTypes: TByteArray;
  ci2: Integer;
  tmpRow: TStrArray;
  orderKeys: TStrArray;
  v, wv, dv: string;
  ct: Byte;
  cnt: Int64;
  sum: Double;
  navg: Integer;
  mn, mx: string;
  fv: Double;
  rk,uv: Integer;
  colRef: TSqlColumnRefNode;

  function PartKey(RowIdx: Integer): AnsiString;
  var
    t, L: Integer;
    e: string;
  begin
    // Carpismasiz birlesim: uzunluk-onekli parcalar.
    Result := '';
    for t := 0 to WN.Partitions.Count - 1 do
    begin
      e := EvalExpr(WN.Partitions[t], Rows[RowIdx], ColNames, ColTypes);
      L := Length(e);
      Result := Result + AnsiString(Chr(L and $FF) + Chr((L shr 8) and $FF) +
        Chr((L shr 16) and $FF) + Chr((L shr 24) and $FF)) + AnsiString(e);
    end;
  end;

  function KeyCtype(E: TSqlExprNode): Byte;
  var
    t: Integer;
  begin
    Result := VCT_STR;
    if E is TSqlColumnRefNode then
      for t := 0 to High(ColNames) do
        if SameText(TSqlColumnRefNode(E).ColumnName, ColNames[t]) and
           (t < Length(ColTypes)) then
        begin Result := ColTypes[t]; Break; end;
  end;

  // Baglarin esitligi (RANK bag paylasimi icin, tip-bilgili).
  function KeysEqual(Ra, Rb: Integer): Boolean;
  var
    t: Integer;
    va, vb: string;
  begin
    Result := True;
    for t := 0 to WN.OrderBys.Count - 1 do
    begin
      va := EvalExpr(WN.OrderBys[t].Expr, Rows[Ra], ColNames, ColTypes);
      vb := EvalExpr(WN.OrderBys[t].Expr, Rows[Rb], ColNames, ColTypes);
      if (va = '') or (vb = '') then
      begin
        if va <> vb then Exit(False);
        Continue; // iki NULL = bag
      end;
      if not VDbCmpVal(va, vb, '=', KeyCtype(WN.OrderBys[t].Expr)) then
        Exit(False);
    end;
  end;

  function AggCtype: Byte;
  begin
    Result := VCT_STR;
    if (WN.Arg <> nil) and (WN.Arg is TSqlColumnRefNode) then
      Result := KeyCtype(WN.Arg);
  end;

begin
  SetLength(WinSlot, Stmt.Columns.Count);
  WList := TList<TSqlWindowNode>.Create;
  try
    for j := 0 to Stmt.Columns.Count - 1 do
      if Stmt.Columns[j].Expr is TSqlWindowNode then
      begin
        WinSlot[j] := WList.Count;
        WList.Add(TSqlWindowNode(Stmt.Columns[j].Expr));
      end
      else
        WinSlot[j] := -1;
    SetLength(WinVals, Length(Rows));
    for r := 0 to High(WinVals) do
      SetLength(WinVals[r], WList.Count);
    for s := 0 to WList.Count - 1 do
    begin
      WN := WList[s];
      // 1. Partition'lara ayir (giris sirasi korunur).
      PDict := TDictionary<string, TList<Integer>>.Create;
      PKeys := TList<string>.Create;
      try
        for r := 0 to High(Rows) do
        begin
          key := PartKey(r);
          if not PDict.TryGetValue(key, idxList) then
          begin
            idxList := TList<Integer>.Create;
            PDict.Add(key, idxList);
            PKeys.Add(key);
          end;
          idxList.Add(r);
        end;
        // 2. Her partition'da sirala + degerleri yaz.
        for q := 0 to PKeys.Count - 1 do
        begin
          idxList := PDict[PKeys[q]];
          SetLength(ord, idxList.Count);
          for k := 0 to idxList.Count - 1 do
            ord[k] := idxList[k];
          if WN.OrderBys.Count > 0 then
          begin
            // F2-19: ONCEDEN gecici matris (tmpM) satirin TUM
            // kolonlarini kopyaliyordu (Cols+1 dizi/satir) -> pencere
            // isleminde bellek 2-3 katina cikiyordu. Artik yalnizca
            // SIRALAMA ANAHTARI kolonlari + satir indeksi kopyalanir.
            // (Tablo 100 kolonluysa fark 100 katindir.)
            SetLength(keyNames, WN.OrderBys.Count + 1);
            SetLength(keyTypes, WN.OrderBys.Count + 1);
            SetLength(orderKeys, WN.OrderBys.Count);
            for k := 0 to WN.OrderBys.Count - 1 do
            begin
              if WN.OrderBys[k].Expr is TSqlColumnRefNode then
              begin
                // deger zaten satirdaki kolonun kendisi
                orderKeys[k] := TSqlColumnRefNode(WN.OrderBys[k].Expr).QualifiedName;
                keyNames[k] := orderKeys[k];
                keyTypes[k] := VCT_STR;
                ci2 := FindColIdx(TSqlColumnRefNode(WN.OrderBys[k].Expr).ColumnName,
                  TSqlColumnRefNode(WN.OrderBys[k].Expr).TableQualifier, ColNames);
                if (ci2 >= 0) and (ci2 < Length(ColTypes)) then keyTypes[k] := ColTypes[ci2];
              end
              else
              begin
                // ifade siralama: degeri hesapla, sentetik ad ver
                orderKeys[k] := '#w' + IntToStr(k);
                keyNames[k] := orderKeys[k];
                keyTypes[k] := VCT_STR;
              end;
            end;
            // son sutun: orijinal satir indeksi (siralama SONUCUNU okumak icin)
            keyNames[WN.OrderBys.Count] := '#wrow';
            keyTypes[WN.OrderBys.Count] := VCT_INT;
            SetLength(tmpM, idxList.Count);
            for k := 0 to idxList.Count - 1 do
            begin
              SetLength(tmpM[k], WN.OrderBys.Count + 1);
              for j := 0 to WN.OrderBys.Count - 1 do
                if WN.OrderBys[j].Expr is TSqlColumnRefNode then
                begin
                  ci2 := FindColIdx(TSqlColumnRefNode(WN.OrderBys[j].Expr).ColumnName,
                    TSqlColumnRefNode(WN.OrderBys[j].Expr).TableQualifier, ColNames);
                  if (ci2 >= 0) and (ci2 < Length(Rows[idxList[k]])) then
                    tmpM[k][j] := Rows[idxList[k]][ci2]
                  else tmpM[k][j] := '';
                end
                else
                  tmpM[k][j] := EvalExpr(WN.OrderBys[j].Expr,
                    Rows[idxList[k]], ColNames, ColTypes);
              tmpM[k][WN.OrderBys.Count] := IntToStr(idxList[k]);
            end;
            DoSort(tmpM, orderKeys, WN.OrderBys, keyNames, keyTypes);
            for k := 0 to High(tmpM) do
              ord[k] := StrToIntDef(tmpM[k][WN.OrderBys.Count], -1);
            SetLength(tmpM, 0);   // F2-19: kopyayi hemen birak
          end;
          // 3. Fonksiyona gore yaz.
          if (WN.FuncName = 'ROW_NUMBER') then
          begin
            for k := 0 to High(ord) do
              WinVals[ord[k]][s] := IntToStr(k + 1);
          end
          else if (WN.FuncName = 'RANK') or (WN.FuncName = 'DENSE_RANK') then
          begin
            rk := 1; uv := 1;
            for k := 0 to High(ord) do
            begin
              if (k > 0) and not KeysEqual(ord[k], ord[k - 1]) then
              begin
                if WN.FuncName = 'RANK' then rk := k + 1
                else Inc(uv);
              end;
              if WN.FuncName = 'RANK' then
                WinVals[ord[k]][s] := IntToStr(rk)
              else
                WinVals[ord[k]][s] := IntToStr(uv);
            end;
          end
          else if (WN.FuncName = 'LAG') or (WN.FuncName = 'LEAD') then
          begin
            for k := 0 to High(ord) do
            begin
              if WN.FuncName = 'LAG' then uv := k - WN.Offset
              else uv := k + WN.Offset;
              if (uv >= 0) and (uv <= High(ord)) then
                WinVals[ord[k]][s] := EvalExpr(WN.Arg, Rows[ord[uv]], ColNames, ColTypes)
              else if WN.Default <> nil then
                WinVals[ord[k]][s] := EvalExpr(WN.Default, Rows[ord[k]], ColNames, ColTypes)
              else
                WinVals[ord[k]][s] := '';
            end;
          end
          else
          begin
            // COUNT/SUM/AVG/MIN/MAX: partition geneli (cercevesiz).
            cnt := 0; sum := 0; navg := 0; mn := ''; mx := '';
            ct := AggCtype;
            for k := 0 to High(ord) do
            begin
              if WN.IsStar then
              begin Inc(cnt); Continue; end;
              v := EvalExpr(WN.Arg, Rows[ord[k]], ColNames, ColTypes);
              if v = '' then Continue;
              Inc(cnt);
              if VDbParseFloat(v, fv) then
              begin sum := sum + fv; Inc(navg); end;
              if (mn = '') or VDbCmpVal(v, mn, '<', ct) then mn := v;
              if (mx = '') or VDbCmpVal(v, mx, '>', ct) then mx := v;
            end;
            if WN.FuncName = 'COUNT' then wv := IntToStr(cnt)
            else if WN.FuncName = 'SUM' then wv := VDbFloatToStr(sum)
            else if WN.FuncName = 'AVG' then
            begin
              if navg > 0 then wv := VDbFloatToStr(sum / navg) else wv := '';
            end
            else if WN.FuncName = 'MIN' then wv := mn
            else if WN.FuncName = 'MAX' then wv := mx
            else wv := '';
            for k := 0 to High(ord) do
              WinVals[ord[k]][s] := wv;
          end;
        end;
      finally
        for q := 0 to PKeys.Count - 1 do
          PDict[PKeys[q]].Free;
        PDict.Free;
        PKeys.Free;
      end;
    end;
  finally
    WList.Free;
  end;
end;

{ ------------------------------------------------------------
  ExecGroupBy
  //---------------------------------------------------------- }
procedure TVSqlExecutor.ExecGroupBy(Stmt: TSqlSelectStmt;
  const AllPks: TStrArray; const AllRows: TStrMatrix;
  const ColNames: TStrArray; const ColTypes: TByteArray;
  out Res: TSqlResult; out OutTypes: TByteArray);
var
  GroupKeys: TList<TStrArray>;
  GroupRowSets: TIntListList;
  i, j, k, gi: Integer;
  key: TStrArray;
  rowIdx: TIntList;
  outCols: TStrArray;
  outRows: TStrMatrix;
  fn: TSqlFuncCallNode;
  colVal: string;
  sumF, fv: Double;
  cntI: Int64;
  minV, maxV: string;
  aggCt: Byte;
  ci, avgCnt: Integer;
  tmpRow: TStrArray;
  havingOk: Boolean;
begin
  GroupKeys := TList<TStrArray>.Create;
  GroupRowSets := TIntListList.Create;
  try
    // 1. Grupla
    for i := 0 to High(AllRows) do
    begin
      if not RowMatches(Stmt.WhereClause, AllRows[i], ColNames, ColTypes) then Continue;
      SetLength(key, Stmt.GroupByCols.Count);
      for j := 0 to Stmt.GroupByCols.Count - 1 do
      begin
        ci := -1;
        for k := 0 to High(ColNames) do
          if SameText(ColNames[k], Stmt.GroupByCols[j]) then begin ci := k; Break; end;
        if (ci >= 0) and (ci < Length(AllRows[i])) then key[j] := AllRows[i][ci]
        else key[j] := '';
      end;
      gi := -1;
      for j := 0 to GroupKeys.Count - 1 do
        if SameStrArr(GroupKeys[j], key) then begin gi := j; Break; end;
      if gi < 0 then
      begin
        GroupKeys.Add(key);
        GroupRowSets.Add(TIntList.Create);
        gi := GroupKeys.Count - 1;
      end;
      GroupRowSets[gi].Add(i);
    end;
    // Bos tablo + GROUP BY'siz aggregate: tek bos grup olustur (COUNT(*)=0)
    if (GroupKeys.Count = 0) and (Stmt.GroupByCols.Count = 0) then
    begin
      SetLength(key, 0);
      GroupKeys.Add(key);
      GroupRowSets.Add(TIntList.Create);
    end;

    // 2. Cikti kolonlari + tipleri
    SetLength(outCols, Stmt.Columns.Count);
    SetLength(OutTypes, Stmt.Columns.Count);
    for j := 0 to Stmt.Columns.Count - 1 do
    begin
      // Kolon adi
      if Stmt.Columns[j].Alias <> '' then outCols[j] := Stmt.Columns[j].Alias
      else if Stmt.Columns[j].Expr is TSqlFuncCallNode then
        outCols[j] := TSqlFuncCallNode(Stmt.Columns[j].Expr).FuncName
      else if Stmt.Columns[j].Expr is TSqlColumnRefNode then
        outCols[j] := TSqlColumnRefNode(Stmt.Columns[j].Expr).ColumnName
      else outCols[j] := 'col' + IntToStr(j + 1);

      // P5-WIN: cikti tipi belirleme
      OutTypes[j] := VCT_STR;
      if Stmt.Columns[j].Expr is TSqlColumnRefNode then
      begin
        for ci := 0 to High(ColNames) do
          if SameText(ColNames[ci], TSqlColumnRefNode(Stmt.Columns[j].Expr).ColumnName) then
          begin
            if ci < Length(ColTypes) then OutTypes[j] := ColTypes[ci];
            Break;
          end;
      end
      else if Stmt.Columns[j].Expr is TSqlFuncCallNode then
      begin
        fn := TSqlFuncCallNode(Stmt.Columns[j].Expr);
        if (fn.FuncName = 'COUNT') then
          OutTypes[j] := VCT_INT
        else if (fn.FuncName = 'SUM') or (fn.FuncName = 'AVG') then
          OutTypes[j] := VCT_FLOAT
        else if ((fn.FuncName = 'MIN') or (fn.FuncName = 'MAX')) and (fn.Arg is TSqlColumnRefNode) then
        begin
          for ci := 0 to High(ColNames) do
            if SameText(ColNames[ci], TSqlColumnRefNode(fn.Arg).ColumnName) then
            begin
              if ci < Length(ColTypes) then OutTypes[j] := ColTypes[ci];
              Break;
            end;
        end;
      end;
    end;

    if Stmt.HavingClause <> nil then
    begin
      if HasAggregateExpr(Stmt.HavingClause) then
        raise EVDbException.Create(ecSyntaxError, 'HAVING icinde aggregate dogrudan kullanilamaz; SELECT listesinde alias verip alias ile filtreleyin');
    end;

    // 3. Her grup icin hesapla
    SetLength(outRows, 0);
    for gi := 0 to GroupKeys.Count - 1 do
    begin
      rowIdx := GroupRowSets[gi];
      SetLength(tmpRow, Stmt.Columns.Count);
      for j := 0 to Stmt.Columns.Count - 1 do
      begin
        if Stmt.Columns[j].Expr is TSqlFuncCallNode then
        begin
          fn := TSqlFuncCallNode(Stmt.Columns[j].Expr);
          cntI := 0; sumF := 0; avgCnt := 0; minV := ''; maxV := '';
          // MIN/MAX karsilastirmasi kolon tipiyle yapilir. VCT_STR ile
          // kiyaslanirsa '10' < '2' olur (string sira) — yanlis sonuc.
          aggCt := VCT_STR;
          if fn.Arg is TSqlColumnRefNode then
            for ci := 0 to High(ColNames) do
              if SameText(ColNames[ci],
                   TSqlColumnRefNode(fn.Arg).ColumnName) then
              begin
                if ci < Length(ColTypes) then
                  aggCt := ColTypes[ci];
                Break;
              end;
          for k := 0 to rowIdx.Count - 1 do
          begin
            if fn.IsStar then
              Inc(cntI)
            else
            begin
              colVal := EvalExpr(fn.Arg, AllRows[rowIdx[k]], ColNames, ColTypes);
              if colVal = '' then Continue;
              Inc(cntI);
              if VDbParseFloat(colVal, fv) then
              begin
                sumF := sumF + fv;
                Inc(avgCnt);
              end;
              if (minV = '') or VDbCmpVal(colVal, minV, '<', aggCt) then minV := colVal;
              if (maxV = '') or VDbCmpVal(colVal, maxV, '>', aggCt) then maxV := colVal;
            end;
          end;
          if fn.FuncName = 'COUNT' then tmpRow[j] := IntToStr(cntI)
          else if fn.FuncName = 'SUM' then
            if cntI > 0 then tmpRow[j] := VDbFloatToStr(sumF) else tmpRow[j] := ''
          else if fn.FuncName = 'AVG' then
          begin
            if avgCnt > 0 then tmpRow[j] := VDbFloatToStr(sumF / avgCnt)
            else tmpRow[j] := '';
          end
          else if fn.FuncName = 'MIN' then tmpRow[j] := minV
          else if fn.FuncName = 'MAX' then tmpRow[j] := maxV
          else tmpRow[j] := '';
        end
        else
        begin
          if rowIdx.Count > 0 then
            tmpRow[j] := EvalExpr(Stmt.Columns[j].Expr, AllRows[rowIdx[0]], ColNames, ColTypes)
          else
            tmpRow[j] := '';
        end;
      end;
        if Stmt.HavingClause <> nil then
          havingOk := EvalBool(Stmt.HavingClause, tmpRow, outCols, OutTypes)
      else
        havingOk := True;
      if havingOk then
      begin
        SetLength(outRows, Length(outRows) + 1);
        outRows[High(outRows)] := tmpRow;
      end;
    end;

  Res.Fields := outCols;
    Res.Rows := outRows;
    Res.Affected := Length(outRows);
    Res.Msg := 'OK';
  finally
    for i := 0 to GroupRowSets.Count - 1 do GroupRowSets[i].Free;
    GroupRowSets.Free;
    GroupKeys.Free;
  end;
end;

{ ------------------------------------------------------------
  ExecSelect
  //---------------------------------------------------------- }
procedure TVSqlExecutor.ExecSelect(Stmt: TSqlSelectStmt; out Res: TSqlResult);
var
  td: TTableDef;
  pks: TStrArray;
  allRows, filteredRows, outRows, merged: TStrMatrix;
  colNames: TStrArray;
  colTypes: TByteArray;
  outTypes: TByteArray;
  i, j, n: Integer;
  outCols: TStrArray;
  orderKeys: TStrArray;
  rightRes: TSqlResult;
  seenKeys: TList<TStrArray>;
  // F2-18: O(1) tekilleştirme kovalari
  seenSet, rightSet: TDictionary<string, Integer>;
  distinctOut: TStrMatrix;
  rowKey: string;
  isDup, found, SkipOffsetLimit, HasSetOp, deferOrder: Boolean;
  baseIdx, tmpSlot, origCols: Integer;
  // P5-WIN: pencere onbellek (projeksiyonda tuketilir).
  WinVals: TStrMatrix;
  WinSlot: TIntArray;
begin
  SkipOffsetLimit := False;
  // F1-12: set-op'ta kuyruk (ORDER BY / OFFSET / LIMIT) birlestirme
  // SONRASINA uygulanir; ONCESI uygulanirsa sol taraf kirpilir.
  HasSetOp := (Stmt.SetOp <> sokNone) and (Stmt.RightSelect <> nil);
  // FROM'suz SELECT: SELECT 1, 'abc' AS x, NULL
  if (Stmt.FromTable = '') and not Stmt.HasJoin then
  begin
    SetLength(outCols, Stmt.Columns.Count);
    SetLength(outRows, 1);
    SetLength(outRows[0], Stmt.Columns.Count);
    for i := 0 to Stmt.Columns.Count - 1 do
    begin
      if Stmt.Columns[i].Alias <> '' then
        outCols[i] := Stmt.Columns[i].Alias
      else if Stmt.Columns[i].Expr is TSqlLiteralNode then
        outCols[i] := TSqlLiteralNode(Stmt.Columns[i].Expr).AsString
      else
        outCols[i] := 'col' + IntToStr(i + 1);

      if Stmt.Columns[i].Expr is TSqlColumnRefNode then
        raise EVDbException.Create(ecSyntaxError, 'FROM''suz SELECT icinde kolon kullanilamaz: ' +
          TSqlColumnRefNode(Stmt.Columns[i].Expr).ColumnName);

      outRows[0][i] := EvalExpr(Stmt.Columns[i].Expr, nil, nil, nil);
    end;
    Res.Fields := outCols;
    Res.Rows := outRows;
    Res.Affected := 1;
    Res.Msg := 'OK';
    Exit;
  end;

  // P5-CTE: WITH listesi once materyallestirilir (sira onemli:
  // sonraki CTE oncekileri gorebilir).
  if (Stmt.WithQueries.Count > 0) then
    MaterializeCtes(Stmt);

  // Karma kontrol: FROM'lu SELECT'te ham literal + kolon ref birlikte kullanilamaz
  if (Stmt.FromTable <> '') and (Stmt.Columns.Count > 0) then
  begin
    found := False; isDup := False;
    for i := 0 to Stmt.Columns.Count - 1 do
    begin
      if Stmt.Columns[i].Expr is TSqlLiteralNode then found := True;
      if Stmt.Columns[i].Expr is TSqlColumnRefNode then isDup := True;
    end;
    if found and isDup then
      for i := 0 to Stmt.Columns.Count - 1 do
        if Stmt.Columns[i].Expr is TSqlColumnRefNode then
          raise EVDbException.CreateFmt(ecSyntaxError, 'FROM''suz SELECT icinde kolon kullanilamaz: %s',
            [TSqlColumnRefNode(Stmt.Columns[i].Expr).ColumnName]);
  end;

  if (Stmt.HavingClause <> nil) and (not HasAggregate(Stmt)) and (Stmt.GroupByCols.Count = 0) then
    raise EVDbException.Create(ecSyntaxError, 'HAVING yalnizca GROUP BY veya aggregate ile kullanilabilir');

  // P5-WIN: pencere yerlesim + GROUP BY/aggregate catismasi.
  if HasWindow(Stmt) then
  begin
    if (Stmt.GroupByCols.Count > 0) or HasAggregate(Stmt) then
      raise EVDbException.Create(ecUnsupported,
        'GROUP BY/aggregate ile pencere fonksiyonu desteklenmiyor');
    CheckWindowPlacement(Stmt);
  end;

  if Stmt.HasJoin then
  begin
    // P5-1: JOIN ile GROUP BY/aggregate birlestirilemez (eski motor da
    // reddediyordu; sessizce yanlis sonuc uretmek yerine acik hata).
    if (Stmt.GroupByCols.Count > 0) or HasAggregate(Stmt) then
      raise EVDbException.Create(ecUnsupported,
        'JOIN ile GROUP BY/aggregate desteklenmiyor');
    ExecJoinScan(Stmt, allRows, colNames, colTypes);
    SetLength(filteredRows, 0);
    for i := 0 to High(allRows) do
      if RowMatches(Stmt.WhereClause, allRows[i], colNames, colTypes) then
      begin
        SetLength(filteredRows, Length(filteredRows) + 1);
        filteredRows[High(filteredRows)] := allRows[i];
      end;
  end
  else
  begin
    // P5-CTE: FROM bir CTE adiysa materyal kumesi kullanilir (PK/indeks
    // optimizasyonlari atlanir; filtreleme RowMatches ile aynen calisir).
    if TryCte(Stmt.FromTable, colNames, colTypes, allRows) then
    begin
      SetLength(pks, 0);
      SkipOffsetLimit := False;
    end
    else
    begin
      td := FT.GetTable(Stmt.FromTable);
      BuildColInfo(td, colNames, colTypes);

      // YOL 1 (en hizli): ORDER BY tek kolon ve o kolon indeksliyse satirlar
      // INDEKS sirasiyla okunur; OFFSET/LIMIT satir okunurken uygulanir.
      // F1-12: Eger SetOp varsa (UNION/EXCEPT/INTERSECT), ORDER BY/LIMIT/OFFSET
      // birlesimden SONRA uygulanmali, indeks yolunu atla.
      // DIKKAT: SkipOffsetLimit yalnizca "indeks yolu eleme/siralamayi
      // kendi yapti" demektir; set-op'ta deger False kalir, cunku sol
      // taraf WHERE filtresi hala uygulanmali. Eski kodda True yapildigi
      // icin filteredRows hic doldurulmuyor ve birlestirme bos oluyordu.
      if Stmt.SetOp <> sokNone then
        SkipOffsetLimit := False
      else
        SkipOffsetLimit := TryIndexOrder(td, Stmt, colNames, colTypes, filteredRows);
      if not SkipOffsetLimit then
      begin
        { YOL 2: Satir adaylarini DARALT - PK nokta aramasi veya indeks dilimi.
          (Once her zaman FT.ScanRows cagriliyordu: 100.000 satirlik tabloda
           "WHERE id = 5" bile ~900 ms suruyordu.)
          Aggregate/GROUP BY de dogrudan sunu kullanir: ExecGroupBy satirlari
          KENDISI RowMatches ile filtreler, yani onceden daraltmak sonucu
          degistirmez. }
        if not NarrowRows(td, Stmt.WhereClause, colNames, colTypes, pks, allRows) then
          FT.ScanRows(Stmt.FromTable, pks, allRows);
      end;
    end;

    if HasAggregate(Stmt) or (Stmt.GroupByCols.Count > 0) then
    begin
      // F1-12: aggregate/GROUP BY yolu taban tablodan dogrudan satirlari
      // dondurup Exit yapar; set-op birlestirmesi hic calismazdi ve
      // sonuc sessizce yanlis cikardi. Desteklenmiyorsa hata ver.
      if HasSetOp then
        raise EVDbException.Create(ecUnsupported,
          'UNION/EXCEPT/INTERSECT ile aggregate/GROUP BY birlestirilemiyor');
      ExecGroupBy(Stmt, pks, allRows, colNames, colTypes, Res, outTypes);
        // F1-20: ORDER BY cikti tip haritasi ile yapilir, aksi halde
        // COUNT '10' < '2' diye metin sirasiyla siralanir.
        if (Stmt.OrderBy <> nil) and (Stmt.OrderBy.Count > 0) then
        begin
          SetLength(orderKeys, Stmt.OrderBy.Count);
          for i := 0 to Stmt.OrderBy.Count - 1 do
            if Stmt.OrderBy[i].Expr is TSqlColumnRefNode then
              orderKeys[i] := TSqlColumnRefNode(Stmt.OrderBy[i].Expr).QualifiedName
            else orderKeys[i] := '';
          DoSort(Res.Rows, orderKeys, Stmt.OrderBy, Res.Fields, outTypes);
        end;
        if Stmt.OffsetVal > 0 then
        begin
          if Stmt.OffsetVal < Length(Res.Rows) then
          begin
            n := Length(Res.Rows) - Stmt.OffsetVal;
            for i := 0 to n - 1 do Res.Rows[i] := Res.Rows[i + Stmt.OffsetVal];
            SetLength(Res.Rows, n);
          end
          else SetLength(Res.Rows, 0);
        end;
        if (Stmt.LimitVal >= 0) and (Length(Res.Rows) > Stmt.LimitVal) then
          SetLength(Res.Rows, Stmt.LimitVal);
        Res.Affected := Length(Res.Rows);
        Exit;
      end;

    // Indeks yolu (SkipOffsetLimit) filteredRows'u doldurduysa eleme;
    // CTE/normal yolda allRows buradan suzulur.
    if not SkipOffsetLimit then
    begin
      SetLength(filteredRows, 0);
      for i := 0 to High(allRows) do
        if RowMatches(Stmt.WhereClause, allRows[i], colNames, colTypes) then
        begin
          SetLength(filteredRows, Length(filteredRows) + 1);
          filteredRows[High(filteredRows)] := allRows[i];
        end;
    end;
  end;

  // ORDER BY (Projection oncesi - tum kolonlar mevcutken dogru sirala)
  // F1-12: set-op varsa birlestirme sonrasina birakilir.
  //
  // F2-19 ALIAS DESTEGI: `SELECT id, ROW_NUMBER() OVER (...) AS rn
  // FROM w ORDER BY g, rn` gecerlidir. Projeksiyon ONCESI 'rn' taban
  // kolonlarinda yoktur ve DoSort F1-21 geregi hata verir. Bu yuzden
  // once taban kolonlarinda cozulur; cozulemeyen anahtar varsa siralama
  // projeksiyon SONRASINA ertelenir (bkz. asagida deferOrder blogu) ve
  // orada CIKTI kolonlari uzerinden, alias dahil, cozulur.
  deferOrder := False;
  if (not SkipOffsetLimit) and (not HasSetOp) and (Stmt.OrderBy <> nil) and
     (Stmt.OrderBy.Count > 0) then
  begin
    SetLength(orderKeys, Stmt.OrderBy.Count);
    for i := 0 to Stmt.OrderBy.Count - 1 do
      if Stmt.OrderBy[i].Expr is TSqlColumnRefNode then
        orderKeys[i] := TSqlColumnRefNode(Stmt.OrderBy[i].Expr).QualifiedName
      else orderKeys[i] := '';
    // Taban kolonlarinda cozulebilir mi?
    for i := 0 to Stmt.OrderBy.Count - 1 do
    begin
      if orderKeys[i] = '' then Continue;
      found := False;
      for j := 0 to High(colNames) do
      begin
        if SameText(colNames[j], orderKeys[i]) then
        begin found := True; Break; end;
        if (Pos('.', colNames[j]) > 0) and
           SameText(Copy(colNames[j], Pos('.', colNames[j]) + 1, MaxInt),
                    orderKeys[i]) then
        begin found := True; Break; end;
        if (Pos('.', orderKeys[i]) > 0) and
           SameText(Copy(orderKeys[i], Pos('.', orderKeys[i]) + 1, MaxInt),
                    colNames[j]) then
        begin found := True; Break; end;
      end;
      if not found then deferOrder := True;
    end;
    // Ertelenen siralamada cozulecek anahtarlar SELECT alias'i olabilir.
    // Gercekten tanimsiz kolon F1-21 hatasi vermeye devam eder.
    if deferOrder then
      for i := 0 to Stmt.OrderBy.Count - 1 do
      begin
        if orderKeys[i] = '' then Continue;
        found := False;
        for j := 0 to High(colNames) do
        begin
          if SameText(colNames[j], orderKeys[i]) then
          begin found := True; Break; end;
          if (Pos('.', colNames[j]) > 0) and
             SameText(Copy(colNames[j], Pos('.', colNames[j]) + 1, MaxInt),
                      orderKeys[i]) then
          begin found := True; Break; end;
          if (Pos('.', orderKeys[i]) > 0) and
             SameText(Copy(orderKeys[i], Pos('.', orderKeys[i]) + 1, MaxInt),
                      colNames[j]) then
          begin found := True; Break; end;
        end;
        if found then Continue;
        for j := 0 to Stmt.Columns.Count - 1 do
          if (Stmt.Columns[j].Alias <> '') and
             SameText(Stmt.Columns[j].Alias, orderKeys[i]) then
          begin found := True; Break; end;
        if not found then
          raise EVDbException.Create(ecColumnNotFound,
            'ORDER BY bilinmeyen kolon: ' + orderKeys[i]);
      end;
    if not deferOrder then
      DoSort(filteredRows, orderKeys, Stmt.OrderBy, colNames, colTypes);
  end;
  // Projection
  if Stmt.Columns.Count = 0 then
  begin
    SetLength(outCols, Length(colNames));
    for i := 0 to High(colNames) do outCols[i] := colNames[i];
    outRows := filteredRows;
  end
  else
  begin
    SetLength(outCols, Stmt.Columns.Count);
    for i := 0 to Stmt.Columns.Count - 1 do
    begin
      if Stmt.Columns[i].Alias <> '' then outCols[i] := Stmt.Columns[i].Alias
      else if Stmt.Columns[i].Expr is TSqlColumnRefNode then
        outCols[i] := TSqlColumnRefNode(Stmt.Columns[i].Expr).ColumnName
      else if Stmt.Columns[i].Expr is TSqlWindowNode then
        outCols[i] := TSqlWindowNode(Stmt.Columns[i].Expr).FuncName
      else outCols[i] := 'col' + IntToStr(i + 1);
    end;
    SetLength(outRows, Length(filteredRows));
    // P5-WIN: pencere degerleri sorgu ORDER BY'sinden SONRA hesaplanir
    // (kendi ORDER BY'si bagimsizdir), asagida tuketilir.
    if HasWindow(Stmt) then
      ComputeWindows(Stmt, filteredRows, colNames, colTypes, WinVals, WinSlot);
    for i := 0 to High(filteredRows) do
    begin
      SetLength(outRows[i], Stmt.Columns.Count);
      for j := 0 to Stmt.Columns.Count - 1 do
        if (j < Length(WinSlot)) and (WinSlot[j] >= 0) and
           (i < Length(WinVals)) and (WinSlot[j] < Length(WinVals[i])) then
          outRows[i][j] := WinVals[i][WinSlot[j]]
        else
          outRows[i][j] := EvalExpr(Stmt.Columns[j].Expr, filteredRows[i], colNames, colTypes);
    end;
  end;

  // ORDER BY: alias (veya projeksiyonda olmayan) kolona gore ertelenmis
  // siralama. SQL standardi ORDER BY icin SELECT listesinde OLMAYAN
  // taban kolonlara da izin verir; bu yuzden gerekli kolonlar outRows'a
  // gecici olarak EKLENIR, siralama yapilir, sonra kirpilir.
  // `SELECT id, ROW_NUMBER() OVER (PARTITION BY g ORDER BY v) AS rn
  // FROM w ORDER BY g, rn` icin once g, sonra rn uygulanir.
  if deferOrder then
  begin
    SetLength(orderKeys, Stmt.OrderBy.Count);
    for i := 0 to Stmt.OrderBy.Count - 1 do
    begin
      if Stmt.OrderBy[i].Expr is TSqlColumnRefNode then
        orderKeys[i] := TSqlColumnRefNode(Stmt.OrderBy[i].Expr).QualifiedName
      else orderKeys[i] := '';
    end;
    // eksik anahtarlari gecici kolon olarak ekle
    origCols := Length(outCols);
    for i := 0 to Stmt.OrderBy.Count - 1 do
    begin
      if orderKeys[i] = '' then Continue;
      found := False;
      for j := 0 to High(outCols) do
      begin
        if SameText(outCols[j], orderKeys[i]) then
        begin found := True; Break; end;
        if (Pos('.', outCols[j]) > 0) and
           SameText(Copy(outCols[j], Pos('.', outCols[j]) + 1, MaxInt),
                    orderKeys[i]) then
        begin found := True; Break; end;
        if (Pos('.', orderKeys[i]) > 0) and
           SameText(Copy(orderKeys[i], Pos('.', orderKeys[i]) + 1, MaxInt),
                    outCols[j]) then
        begin found := True; Break; end;
      end;
      if found then Continue;
      // SELECT listesinde olmayan TABAN kolonu: siralama icin gecici
      // eklenir (outRows[i] ile filteredRows[i] ayni siradir).
      baseIdx := -1;
      for j := 0 to High(colNames) do
      begin
        if SameText(colNames[j], orderKeys[i]) then
        begin baseIdx := j; Break; end;
        if (Pos('.', colNames[j]) > 0) and
           SameText(Copy(colNames[j], Pos('.', colNames[j]) + 1, MaxInt),
                    orderKeys[i]) then
        begin baseIdx := j; Break; end;
        if (Pos('.', orderKeys[i]) > 0) and
           SameText(Copy(orderKeys[i], Pos('.', orderKeys[i]) + 1, MaxInt),
                    colNames[j]) then
        begin baseIdx := j; Break; end;
      end;
      if baseIdx < 0 then
        raise EVDbException.Create(ecColumnNotFound,
          'ORDER BY bilinmeyen kolon: ' + orderKeys[i]);
      tmpSlot := Length(outCols);
      SetLength(outCols, tmpSlot + 1);
      SetLength(outTypes, tmpSlot + 1);
      outCols[tmpSlot] := orderKeys[i];
      if baseIdx < Length(colTypes) then outTypes[tmpSlot] := colTypes[baseIdx]
      else       outTypes[tmpSlot] := VCT_STR;
      for j := 0 to High(outRows) do
      begin
        SetLength(outRows[j], tmpSlot + 1);
        if (j <= High(filteredRows)) and (baseIdx <= High(filteredRows[j])) then
          outRows[j][tmpSlot] := filteredRows[j][baseIdx]
        else outRows[j][tmpSlot] := '';
      end;
    end;
    DoSort(outRows, orderKeys, Stmt.OrderBy, outCols, outTypes);
    // gecici kolonlari kirp
    if origCols < Length(outCols) then
    begin
      SetLength(outCols, origCols);
      SetLength(outTypes, origCols);
      for i := 0 to High(outRows) do SetLength(outRows[i], origCols);
    end;
  end;

  // DISTINCT
  // F2-18: ONCEDEN TList + ic ice SameStrArr taramasi -> O(N^2). 100.000
  // tekil satirda ~5 milyar karsilastirma (saniyelerce). Artik O(1)
  // hash kova ile N. Ayrica sonuc satiri SINIRLANIR: tekilleştirme
  // biriken sayi sinirsiz oldugu icin bellek kucak doluyordu.
  if Stmt.IsDistinct then
  begin
    seenSet := TDictionary<string, Integer>.Create;
    try
      SetLength(distinctOut, 0);
      for i := 0 to High(outRows) do
      begin
        rowKey := RowEncodeKey(outRows[i]);
        if seenSet.ContainsKey(rowKey) then Continue;
        seenSet.Add(rowKey, 0);
        if Length(distinctOut) >= VDB_MAX_RESULT_ROWS then
          raise EVDbException.CreateFmt(ecLimit,
            'DISTINCT sonucu cok buyuk (>%d satir)', [VDB_MAX_RESULT_ROWS]);
        SetLength(distinctOut, Length(distinctOut) + 1);
        distinctOut[High(distinctOut)] := outRows[i];
      end;
      outRows := distinctOut;
    finally
      seenSet.Free;
    end;
  end;

  // OFFSET  (TryIndexOrder yolu OFFSET/LIMIT'i SATIR OKURKEN uyguladi)
  // F1-12: set-op'ta birlestirme sonrasina birakilir.
  if (not SkipOffsetLimit) and (not HasSetOp) and (Stmt.OffsetVal > 0) then
  begin
    if Stmt.OffsetVal < Length(outRows) then
    begin
      n := Length(outRows) - Stmt.OffsetVal;
      for i := 0 to n - 1 do outRows[i] := outRows[i + Stmt.OffsetVal];
      SetLength(outRows, n);
    end
    else SetLength(outRows, 0);
  end;

  // F1-20: projeksiyon cikti tipleri (UNION sonrasi ORDER BY icin gerekir)
  SetLength(outTypes, Length(outCols));
  for j := 0 to High(outCols) do outTypes[j] := VCT_STR;
  for j := 0 to Stmt.Columns.Count - 1 do
  begin
    if not (Stmt.Columns[j].Expr is TSqlColumnRefNode) then Continue;
    for i := 0 to High(colNames) do
      if SameText(colNames[i], TSqlColumnRefNode(Stmt.Columns[j].Expr).ColumnName) then
      begin
        if i < Length(colTypes) then outTypes[j] := colTypes[i];
        Break;
      end;
  end;

  // LIMIT  (TryIndexOrder yolu LIMIT'i SATIR OKURKEN uyguladi)
  // F1-12: set-op'ta birlestirme sonrasina birakilir.
  if (not SkipOffsetLimit) and (not HasSetOp) and (Stmt.LimitVal >= 0) and
     (Length(outRows) > Stmt.LimitVal) then
    SetLength(outRows, Stmt.LimitVal);

  // SET OP
  if HasSetOp then
  begin
    ExecSelect(Stmt.RightSelect, rightRes);
    // F1-11: UNION/EXCEPT/INTERSECT sutun sayisi esit olmali
    if Length(outCols) <> Length(rightRes.Fields) then
      raise EVDbException.Create(ecSyntaxError,
        'UNION/EXCEPT/INTERSECT: sutun sayilari esit olmali (sol=' +
        IntToStr(Length(outCols)) + ', sag=' + IntToStr(Length(rightRes.Fields)) + ')');
    case Stmt.SetOp of
      sokUnion, sokUnionAll:
        begin
          SetLength(merged, Length(outRows) + Length(rightRes.Rows));
          if Length(merged) > VDB_MAX_RESULT_ROWS then
            raise EVDbException.CreateFmt(ecLimit,
              'UNION/UNION ALL sonucu cok buyuk (%d > %d satir)',
              [Length(merged), VDB_MAX_RESULT_ROWS]);
          for i := 0 to High(outRows) do merged[i] := outRows[i];
          for i := 0 to High(rightRes.Rows) do merged[Length(outRows) + i] := rightRes.Rows[i];
          if Stmt.SetOp = sokUnion then
          begin
            // F2-18: O(N^2) icice tarama -> O(1) hash kova
            seenSet := TDictionary<string, Integer>.Create;
            try
              n := 0;
              for i := 0 to High(merged) do
              begin
                rowKey := RowEncodeKey(merged[i]);
                if seenSet.ContainsKey(rowKey) then Continue;
                seenSet.Add(rowKey, 0);
                merged[n] := merged[i];
                Inc(n);
              end;
              SetLength(merged, n);
            finally seenSet.Free; end;
          end;
          outRows := merged;
        end;
      sokExcept:
        begin
          // F2-18: sag taraf hash kovaya -> O(1) sorgu
          rightSet := TDictionary<string, Integer>.Create;
          try
            for j := 0 to High(rightRes.Rows) do
              rightSet.AddOrSetValue(RowEncodeKey(rightRes.Rows[j]), 0);
            n := 0; SetLength(merged, Length(outRows));
            for i := 0 to High(outRows) do
              if not rightSet.ContainsKey(RowEncodeKey(outRows[i])) then
              begin merged[n] := outRows[i]; Inc(n); end;
          finally rightSet.Free; end;
          SetLength(merged, n); outRows := merged;
        end;
      sokIntersect:
        begin
          // F2-18: ayni sekilde hash
          rightSet := TDictionary<string, Integer>.Create;
          try
            for j := 0 to High(rightRes.Rows) do
              rightSet.AddOrSetValue(RowEncodeKey(rightRes.Rows[j]), 0);
            n := 0; SetLength(merged, Length(outRows));
            for i := 0 to High(outRows) do
              if rightSet.ContainsKey(RowEncodeKey(outRows[i])) then
              begin merged[n] := outRows[i]; Inc(n); end;
          finally rightSet.Free; end;
          SetLength(merged, n); outRows := merged;
        end;
    end;

    // F1-12: ORDER BY / OFFSET / LIMIT birlestirme SONRASINA uygulanir.
    // Once uygulansaydi sol taraf kirpilir, birlestirilen sonuc fazladan
    // satir donerdi.
    if (Stmt.OrderBy <> nil) and (Stmt.OrderBy.Count > 0) then
    begin
      SetLength(orderKeys, Stmt.OrderBy.Count);
      for i := 0 to Stmt.OrderBy.Count - 1 do
        if Stmt.OrderBy[i].Expr is TSqlColumnRefNode then
          orderKeys[i] := TSqlColumnRefNode(Stmt.OrderBy[i].Expr).QualifiedName
        else orderKeys[i] := '';
      DoSort(outRows, orderKeys, Stmt.OrderBy, outCols, outTypes);
    end;
    if Stmt.OffsetVal > 0 then
    begin
      if Stmt.OffsetVal < Length(outRows) then
      begin
        n := Length(outRows) - Stmt.OffsetVal;
        for i := 0 to n - 1 do outRows[i] := outRows[i + Stmt.OffsetVal];
        SetLength(outRows, n);
      end
      else SetLength(outRows, 0);
    end;
    if (Stmt.LimitVal >= 0) and (Length(outRows) > Stmt.LimitVal) then
      SetLength(outRows, Stmt.LimitVal);
  end;

  Res.Fields := outCols;
  Res.Rows := outRows;
  Res.Affected := Length(outRows);
  Res.Msg := 'OK';
end;

{ ------------------------------------------------------------
  ExecInsert
  //---------------------------------------------------------- }
procedure TVSqlExecutor.ExecInsert(Stmt: TSqlInsertStmt; out Res: TSqlResult);
var
  i, j, rCount: Integer;
  strVals: array of string;
  cnames: array of string;
  subRes: TSqlResult;
  td: TTableDef;
begin
  rCount := 0;
  td := FT.GetTable(Stmt.Table);
  if Length(Stmt.Columns) = 0 then
  begin
    SetLength(cnames, Length(td.Cols));
    for i := 0 to High(td.Cols) do cnames[i] := td.Cols[i].Name;
  end
  else
  begin
    SetLength(cnames, Length(Stmt.Columns));
    for i := 0 to High(Stmt.Columns) do cnames[i] := Stmt.Columns[i];
  end;

  if Stmt.SelectSrc <> nil then
  begin
    ExecSelect(Stmt.SelectSrc, subRes);
    for i := 0 to High(subRes.Rows) do
    begin
      FT.Insert(Stmt.Table, cnames, subRes.Rows[i]);
      Inc(rCount);
    end;
  end
  else if Stmt.ValuesRows <> nil then
  begin
    if (Stmt.ValuesRows.Count > 1) and not FT.Kv.InBatch then
    begin
      FT.Kv.BeginBatch;
      try
        for i := 0 to Stmt.ValuesRows.Count - 1 do
        begin
          if Stmt.ValuesRows[i].Count = 0 then
            FT.Insert(Stmt.Table, [], [])
          else
          begin
            SetLength(strVals, Stmt.ValuesRows[i].Count);
            for j := 0 to Stmt.ValuesRows[i].Count - 1 do
              strVals[j] := EvalExpr(Stmt.ValuesRows[i][j], nil, nil, nil);
            FT.Insert(Stmt.Table, cnames, strVals);
          end;
          Inc(rCount);
        end;
        FT.Kv.CommitBatch;
      except
        FT.AbortBatch;
        raise;
      end;
    end
    else
    begin
      for i := 0 to Stmt.ValuesRows.Count - 1 do
      begin
        if Stmt.ValuesRows[i].Count = 0 then
          FT.Insert(Stmt.Table, [], [])
        else
        begin
          SetLength(strVals, Stmt.ValuesRows[i].Count);
          for j := 0 to Stmt.ValuesRows[i].Count - 1 do
            strVals[j] := EvalExpr(Stmt.ValuesRows[i][j], nil, nil, nil);
          FT.Insert(Stmt.Table, cnames, strVals);
        end;
        Inc(rCount);
      end;
    end;
  end;

  Res.Affected := rCount;
  Res.LastTable := Stmt.Table;
  Res.Msg := 'OK';
end;

{ ------------------------------------------------------------
  ExecUpdate - AST WHERE filtreli, expression-based SET
  //---------------------------------------------------------- }
procedure TVSqlExecutor.ExecUpdate(Stmt: TSqlUpdateStmt; out Res: TSqlResult);
var
  td: TTableDef;
  pks: TStrArray;
  allRows: TStrMatrix;
  colNames: TStrArray;
  colTypes: TByteArray;
  i, j, ci, setIdx, rCount: Integer;
  newVals: TStrArray;
  allColNames: TStrArray;
begin
  td := FT.GetTable(Stmt.Table);
  BuildColInfo(td, colNames, colTypes);
  // F1-16: bilinmeyen SET kolonu sessizce atlanmaz. Atlanirsa satir
  // silinip aynen yazilir, rCount yanlis cikar.
  for j := 0 to Stmt.Assignments.Count - 1 do
  begin
    ci := -1;
    for setIdx := 0 to High(colNames) do
      if SameText(colNames[setIdx], Stmt.Assignments[j].ColName) then
      begin ci := setIdx; Break; end;
    if ci < 0 then
      raise EVDbException.Create(ecColumnNotFound,
        'UPDATE: bilinmeyen kolon: ' + Stmt.Assignments[j].ColName);
  end;
  { Once her zaman FT.ScanRows -> 100.000 satirlik tabloda tek bir
    "UPDATE ... WHERE id = 5" ~1 saniye suruyordu. Simdi once adaylar
    daraltilir (PK nokta / indeks dilimi); bulunamazsa tam tarama. }
  if not NarrowRows(td, Stmt.WhereClause, colNames, colTypes, pks, allRows) then
    FT.ScanRows(Stmt.Table, pks, allRows);

  SetLength(allColNames, Length(td.Cols));
  for i := 0 to High(td.Cols) do allColNames[i] := td.Cols[i].Name;

  rCount := 0;
  // F1-4 (tamamlayici): SQL UPDATE artik Delete+Insert YAPMIYOR.
  // Onceki yol "ON DELETE CASCADE"i yanlis tetikliyordu: ilgisiz bir
  // kolonu guncellerken bile cocuk satirlari SILINIYORDU. Satir mantigi
  // TVTableDb.UpdateRowInPlace'e tasindi (UpdateWhere ile ortak).
  // Ayrica PK kolonu SET edilemez (satir anahtari degismez).
  for j := 0 to Stmt.Assignments.Count - 1 do
    for setIdx := 0 to High(colNames) do
      if SameText(colNames[setIdx], Stmt.Assignments[j].ColName) then
        // F2-22: PkIndex<0 ise PK tanimlanmamis; koruma yok.
        if (td.PkIndex >= 0) and (setIdx = td.PkIndex) then
          raise EVDbException.Create(ecUnsupported,
            'UPDATE: PK kolonu guncellenemez: ' + colNames[setIdx]);

  if not FT.Kv.InBatch then
  begin
    FT.Kv.BeginBatch;
    try
      for i := 0 to High(allRows) do
      begin
        if not RowMatches(Stmt.WhereClause, allRows[i], colNames, colTypes) then Continue;
        SetLength(newVals, Length(td.Cols));
        for j := 0 to High(td.Cols) do newVals[j] := allRows[i][j];
        for j := 0 to Stmt.Assignments.Count - 1 do
        begin
          ci := -1;
          for setIdx := 0 to High(colNames) do
            if SameText(colNames[setIdx], Stmt.Assignments[j].ColName) then
            begin ci := setIdx; Break; end;
          if ci >= 0 then
            newVals[ci] := EvalExpr(Stmt.Assignments[j].Expr, allRows[i], colNames, colTypes);
        end;
        if FT.UpdateRowInPlace(Stmt.Table, pks[i], newVals) then Inc(rCount);
      end;
      FT.Kv.CommitBatch;
    except
      FT.AbortBatch;
      raise;
    end;
  end
  else
  begin
    for i := 0 to High(allRows) do
    begin
      if not RowMatches(Stmt.WhereClause, allRows[i], colNames, colTypes) then Continue;
      SetLength(newVals, Length(td.Cols));
      for j := 0 to High(td.Cols) do newVals[j] := allRows[i][j];
      for j := 0 to Stmt.Assignments.Count - 1 do
      begin
        ci := -1;
        for setIdx := 0 to High(colNames) do
          if SameText(colNames[setIdx], Stmt.Assignments[j].ColName) then
          begin ci := setIdx; Break; end;
        if ci >= 0 then
          newVals[ci] := EvalExpr(Stmt.Assignments[j].Expr, allRows[i], colNames, colTypes);
      end;
      if FT.UpdateRowInPlace(Stmt.Table, pks[i], newVals) then Inc(rCount);
    end;
  end;

  Res.Affected := rCount;
  Res.LastTable := Stmt.Table;
  Res.Msg := 'OK';
end;

{ ------------------------------------------------------------
  ExecDelete - AST WHERE filtreli
  //---------------------------------------------------------- }
procedure TVSqlExecutor.ExecDelete(Stmt: TSqlDeleteStmt; out Res: TSqlResult);
var
  td: TTableDef;
  pks: TStrArray;
  allRows: TStrMatrix;
  colNames: TStrArray;
  colTypes: TByteArray;
  i, rCount: Integer;
  toDelete: TList<string>;
begin
  td := FT.GetTable(Stmt.Table);
  BuildColInfo(td, colNames, colTypes);
  { Once her zaman tam tarama: "DELETE ... WHERE id = 5" 100.000 satirlik
    tabloda ~1 saniye suruyordu. Simdi PK nokta / indeks dilimi denenir. }
  if not NarrowRows(td, Stmt.WhereClause, colNames, colTypes, pks, allRows) then
    FT.ScanRows(Stmt.Table, pks, allRows);

  toDelete := TList<string>.Create;
  try
    for i := 0 to High(allRows) do
      if RowMatches(Stmt.WhereClause, allRows[i], colNames, colTypes) then
        toDelete.Add(pks[i]);
    rCount := toDelete.Count;
    if rCount > 0 then
    begin
      if not FT.Kv.InBatch then
      begin
        FT.Kv.BeginBatch;
        try
          for i := 0 to toDelete.Count - 1 do FT.Delete(Stmt.Table, toDelete[i]);
          FT.Kv.CommitBatch;
        except
          FT.AbortBatch;
          raise;
        end;
      end
      else
        for i := 0 to toDelete.Count - 1 do FT.Delete(Stmt.Table, toDelete[i]);
    end;
  finally
    toDelete.Free;
  end;

  Res.Affected := rCount;
  Res.LastTable := Stmt.Table;
  Res.Msg := 'OK';
end;

function FindColInArr(const Cols: array of TColDef; const ColName: string): Integer;
var i: Integer;
begin
  for i := 0 to High(Cols) do
    if SameText(Cols[i].Name, ColName) then Exit(i);
  Result := -1;
end;

function AndWhereGroups(const A, B: TWhereGroups): TWhereGroups;
var x, y, q, z: Integer;
begin
  if Length(A) = 0 then Exit(B);
  if Length(B) = 0 then Exit(A);
  SetLength(Result, Length(A) * Length(B));
  z := 0;
  for x := 0 to High(A) do
    for y := 0 to High(B) do
    begin
      SetLength(Result[z], Length(A[x]) + Length(B[y]));
      for q := 0 to High(A[x]) do Result[z][q] := A[x][q];
      for q := 0 to High(B[y]) do Result[z][Length(A[x]) + q] := B[y][q];
      Inc(z);
    end;
end;

function OrWhereGroups(const A, B: TWhereGroups): TWhereGroups;
var i, nA, nB: Integer;
begin
  nA := Length(A); nB := Length(B);
  SetLength(Result, nA + nB);
  for i := 0 to nA - 1 do Result[i] := A[i];
  for i := 0 to nB - 1 do Result[nA + i] := B[i];
end;

function ExprToWhereGroups(Expr: TSqlExprNode; const Cols: array of TColDef): TWhereGroups;
var
  bin: TSqlBinaryOpNode;
  colRef: TSqlColumnRefNode;
  lit: TSqlLiteralNode;
  ci: Integer;
  c: TWhereCond;
  colName, valStr, opStr: string;
begin
  SetLength(Result, 0);
  if Expr = nil then Exit;

  if Expr is TSqlBinaryOpNode then
  begin
    bin := TSqlBinaryOpNode(Expr);
    if bin.Op = sboAnd then
      Exit(AndWhereGroups(ExprToWhereGroups(bin.Left, Cols), ExprToWhereGroups(bin.Right, Cols)));
    if bin.Op = sboOr then
      Exit(OrWhereGroups(ExprToWhereGroups(bin.Left, Cols), ExprToWhereGroups(bin.Right, Cols)));

    colName := ''; valStr := ''; opStr := SqlBinaryOpToStr(bin.Op);
    if bin.Left is TSqlColumnRefNode then
    begin
      colName := TSqlColumnRefNode(bin.Left).ColumnName;
      if bin.Right is TSqlLiteralNode then
        valStr := TSqlLiteralNode(bin.Right).AsString
      else if bin.Right is TSqlColumnRefNode then
        valStr := TSqlColumnRefNode(bin.Right).ColumnName;
    end
    else if bin.Right is TSqlColumnRefNode then
    begin
      colName := TSqlColumnRefNode(bin.Right).ColumnName;
      if bin.Left is TSqlLiteralNode then
        valStr := TSqlLiteralNode(bin.Left).AsString;
      if opStr = '<' then opStr := '>'
      else if opStr = '>' then opStr := '<'
      else if opStr = '<=' then opStr := '>='
      else if opStr = '>=' then opStr := '<=';
    end;

    if colName <> '' then
    begin
      ci := FindColInArr(Cols, colName);
      if ci >= 0 then
      begin
        c.Col := ci;
        c.Ctype := Cols[ci].Ctype;
        c.Op := opStr;
        c.Val := valStr;
        SetLength(c.Vals, 0);
        SetLength(Result, 1);
        SetLength(Result[0], 1);
        Result[0][0] := c;
      end;
    end;
  end;
end;

procedure TVSqlExecutor.ExecCreateTable(Stmt: TSqlCreateTableStmt; out Res: TSqlResult);
var i: Integer;
begin
  if Stmt.IfNotExists and FT.TableExists(Stmt.Table) then
  begin Res.Affected := 0; Res.Msg := 'OK'; Exit; end;
  if Stmt.CheckExprs <> nil then
  begin
    for i := 0 to Stmt.CheckExprs.Count - 1 do
      Stmt.Checks := AndWhereGroups(Stmt.Checks, ExprToWhereGroups(Stmt.CheckExprs[i], Stmt.Cols));
  end;
  FT.CreateTable(Stmt.Table, Stmt.Cols, Stmt.PkIndex, Stmt.Checks, Stmt.Fks);
  Res.Affected := 1; Res.LastTable := Stmt.Table; Res.Msg := 'OK';
end;

procedure TVSqlExecutor.ExecDropTable(Stmt: TSqlDropTableStmt; out Res: TSqlResult);
begin
  if Stmt.IfExists and not FT.TableExists(Stmt.Table) then
  begin Res.Affected := 0; Res.Msg := 'OK'; Exit; end;
  FT.DropTable(Stmt.Table);
  Res.Affected := 1; Res.LastTable := Stmt.Table; Res.Msg := 'OK';
end;

procedure TVSqlExecutor.ExecCreateIndex(Stmt: TSqlCreateIndexStmt; out Res: TSqlResult);
begin
  // F2-23: UNIQUE bayragi TEK KOLONLU yolda da tasinir. Once bu dal
  // CreateIndex'i cagirip Uniq'i yutuyordu.
  if Length(Stmt.Cols) > 1 then
    FT.CreateIndexCols(Stmt.Table, Stmt.IndexName, Stmt.Cols, Stmt.Uniq)
  else
    FT.CreateIndexCols(Stmt.Table, Stmt.IndexName, [Stmt.Col], Stmt.Uniq);
  Res.Affected := 1; Res.LastTable := Stmt.Table; Res.Msg := 'OK';
end;

procedure TVSqlExecutor.ExecDropIndex(Stmt: TSqlDropIndexStmt; out Res: TSqlResult);
begin
  FT.DropIndex(Stmt.IndexName);
  Res.Affected := 1; Res.Msg := 'OK';
end;

procedure TVSqlExecutor.ExecAlterTable(Stmt: TSqlAlterTableStmt; out Res: TSqlResult);
begin
  case Stmt.Action of
    ataAddColumn:
      FT.AlterAddColumn(Stmt.Table, Stmt.ColDef, Stmt.PositionCol,
        Stmt.DefaultVal <> '', Stmt.DefaultVal);
    ataDropColumn:
      FT.AlterDropColumn(Stmt.Table, Stmt.ColName);
    ataRenameColumn:
      FT.AlterRenameColumn(Stmt.Table, Stmt.ColName, Stmt.NewName);
    ataAlterColType:
      FT.AlterColumnType(Stmt.Table, Stmt.ColName, Stmt.NewTypeName);
    ataSetDefault:
      FT.AlterSetDefault(Stmt.Table, Stmt.ColName, True, Stmt.DefaultVal);
    ataDropDefault:
      FT.AlterDropDefault(Stmt.Table, Stmt.ColName);
    ataSetNotNull:
      FT.AlterSetNotNull(Stmt.Table, Stmt.ColName, True);
    ataDropNotNull:
      FT.AlterSetNotNull(Stmt.Table, Stmt.ColName, False);
    ataRenameTable:
      FT.AlterRenameTable(Stmt.Table, Stmt.NewName);
  end;
  Res.Affected := 1; Res.LastTable := Stmt.Table; Res.Msg := 'OK';
end;

{ ------------------------------------------------------------
  TX Handler
  //---------------------------------------------------------- }
procedure TVSqlExecutor.ExecTx(Stmt: TSqlTxStmt; out Res: TSqlResult);
begin
  case Stmt.Kind of
    txBegin:    FT.BeginBatch;
    txCommit:   FT.CommitBatch;
    txRollback: FT.AbortBatch;
  end;
  Res.Affected := 0; Res.Msg := 'OK';
end;

{ ------------------------------------------------------------
  Admin Handler
  //---------------------------------------------------------- }
procedure TVSqlExecutor.ExecAdmin(Stmt: TSqlAdminStmt; out Res: TSqlResult);
var
  rep: string;
  vOld, vNew: Int64;
  tbls, tmpi: TStrArray;
  tmprow: TStrMatrix;
  i, j: Integer;
  td: TTableDef;
  cn, chk, fkCol: string;
  icols: TIntArray;
begin
  case Stmt.Kind of
    admVerify:
      begin
        if FT.Kv.Verify(rep) then
        begin Res.Affected := 1; Res.Msg := 'VERIFY: ' + rep; end
        else
        begin Res.Affected := 0; Res.Msg := 'VERIFY HATASI: ' + rep; end;
      end;
    admVacuum:
      begin
        FT.Kv.Compact(vOld, vNew);
        Res.Affected := 1;
        Res.Msg := Format('VACUUM %d -> %d bayt (%d kazanc)', [vOld, vNew, vOld - vNew]);
      end;
    admReindex:
      begin FT.RebuildIndexes; Res.Affected := 1; Res.Msg := 'OK'; end;
    admShowTables:
      begin
        tbls := FT.TableNames;
        SetLength(Res.Fields, 2);
        Res.Fields[0] := 'table'; Res.Fields[1] := 'rows';
        SetLength(Res.Rows, Length(tbls));
        for i := 0 to High(tbls) do
        begin
          SetLength(Res.Rows[i], 2);
          Res.Rows[i][0] := tbls[i];
          FT.ScanRows(tbls[i], tmpi, tmprow);
          Res.Rows[i][1] := IntToStr(Length(tmprow));
        end;
        Res.Affected := Length(tbls);
        Res.Msg := IntToStr(Length(tbls)) + ' tablo';
      end;
    admBackupDb:
      begin
        FT.Kv.BackupTo(Stmt.BackupPath);
        Res.Affected := 1; Res.Msg := 'OK';
      end;
    // ---- 2026-10-04: SEMA SORGULARI ----
    admDescribe:
      begin
        td := FT.GetTable(Stmt.TableName);
        SetLength(Res.Fields, 8);
        Res.Fields[0] := 'name';    Res.Fields[1] := 'type';
        Res.Fields[2] := 'notnull'; Res.Fields[3] := 'unique';
        Res.Fields[4] := 'default'; Res.Fields[5] := 'pk';
        Res.Fields[6] := 'autoinc'; Res.Fields[7] := 'position';
        SetLength(Res.Rows, Length(td.Cols));
        for i := 0 to High(td.Cols) do
        begin
          SetLength(Res.Rows[i], 8);
          Res.Rows[i][0] := td.Cols[i].Name;
          Res.Rows[i][1] := VDbTypeName(td.Cols[i].Ctype);
          Res.Rows[i][2] := BoolToStr(td.Cols[i].NotNull, True);
          Res.Rows[i][3] := BoolToStr(td.Cols[i].Unique, True);
          if td.Cols[i].HasDef then Res.Rows[i][4] := td.Cols[i].Def
          else Res.Rows[i][4] := '';
          Res.Rows[i][5] := BoolToStr(td.PkIndex = i, True);
          Res.Rows[i][6] := BoolToStr(td.AutoInc > 0, True);
          Res.Rows[i][7] := IntToStr(i);
        end;
        Res.Affected := Length(td.Cols);
        Res.Msg := Stmt.TableName + ': ' + IntToStr(Length(td.Cols)) + ' sutun';
      end;
    admShowIndexes:
      begin
        td := FT.GetTable(Stmt.TableName);
        SetLength(Res.Fields, 5);
        Res.Fields[0] := 'index';    Res.Fields[1] := 'unique';
        Res.Fields[2] := 'columns';  Res.Fields[3] := 'ncols';
        Res.Fields[4] := 'kind';
        SetLength(Res.Rows, Length(td.Idx));
        for i := 0 to High(td.Idx) do
        begin
          SetLength(Res.Rows[i], 5);
          Res.Rows[i][0] := td.Idx[i].Name;
          Res.Rows[i][1] := BoolToStr(td.Idx[i].Uniq, True);
          // F2-15: cok kolonlu indekslerde TUM sutunlar sirayla
          icols := FT.IdxColsOfTable(td.TableId, td.Idx[i].Col);
          cn := '';
          for j := 0 to High(icols) do
          begin
            if cn <> '' then cn := cn + ',';
            if (icols[j] >= 0) and (icols[j] < Length(td.Cols)) then
              cn := cn + td.Cols[icols[j]].Name
            else
              cn := cn + '?';
          end;
          Res.Rows[i][2] := cn;
          Res.Rows[i][3] := IntToStr(Length(icols));
          if Length(td.Idx[i].Cols) > 1 then Res.Rows[i][4] := 'cok kolunlu'
          else Res.Rows[i][4] := 'tek kolunlu';
        end;
        Res.Affected := Length(td.Idx);
        Res.Msg := Stmt.TableName + ': ' + IntToStr(Length(td.Idx)) + ' indeks';
      end;
    admShowCreateTable:
      begin
        td := FT.GetTable(Stmt.TableName);
        cn := 'CREATE TABLE ' + td.Name + ' (';
        for i := 0 to High(td.Cols) do
        begin
          if i > 0 then cn := cn + ', ';
          cn := cn + td.Cols[i].Name + ' ' + VDbTypeName(td.Cols[i].Ctype);
          if td.PkIndex = i then cn := cn + ' PRIMARY KEY';
          if td.Cols[i].NotNull then cn := cn + ' NOT NULL';
          if td.Cols[i].Unique then cn := cn + ' UNIQUE';
          if td.Cols[i].HasDef then
            cn := cn + ' DEFAULT ' + VDbNormValue(td.Cols[i].Ctype, td.Cols[i].Def);
        end;
        cn := cn + ')';
        if td.AutoInc > 0 then cn := cn + ' AUTOINCREMENT';
        SetLength(Res.Fields, 1);
        Res.Fields[0] := 'sql';
        SetLength(Res.Rows, 1);
        SetLength(Res.Rows[0], 1);
        Res.Rows[0][0] := cn;
        // CHECK / FK tanimlari ayrica satirlarda
        for i := 0 to High(td.Checks) do
        begin
          chk := '';
          for j := 0 to High(td.Checks[i]) do
          begin
            if chk <> '' then chk := chk + ' AND ';
            if td.Checks[i][j].Col >= 0 then
              chk := chk + VDbNorm(td.Cols[td.Checks[i][j].Col].Name) + ' ' +
                td.Checks[i][j].Op + ' ' +
                VDbNormValue(td.Cols[td.Checks[i][j].Col].Ctype, td.Checks[i][j].Val)
            else
              chk := chk + '?';
          end;
          if chk <> '' then
          begin
            SetLength(Res.Rows, Length(Res.Rows) + 1);
            SetLength(Res.Rows[High(Res.Rows)], 1);
            Res.Rows[High(Res.Rows)][0] := 'CHECK (' + chk + ')';
          end;
        end;
        for i := 0 to High(td.Fks) do
        begin
          if (td.Fks[i].Col >= 0) and (td.Fks[i].Col < Length(td.Cols)) then
            fkCol := td.Cols[td.Fks[i].Col].Name
          else
            fkCol := '?';
          SetLength(Res.Rows, Length(Res.Rows) + 1);
          SetLength(Res.Rows[High(Res.Rows)], 1);
          Res.Rows[High(Res.Rows)][0] := 'FOREIGN KEY (' + fkCol + ') REFERENCES ' +
            td.Fks[i].RefTable + '(' + td.Fks[i].RefCol + ')' +
            ' ON DELETE ' + VDbFkActionToStr(td.Fks[i].OnDelete) +
            ' ON UPDATE ' + VDbFkActionToStr(td.Fks[i].OnUpdate);
        end;
        Res.Affected := 1;
        Res.Msg := 'OK';
      end;
  else
    Res.Affected := 0; Res.Msg := 'OK';
  end;
end;

{ ------------------------------------------------------------
  JSON Handler
  //---------------------------------------------------------- }
procedure TVSqlExecutor.ExecJson(Stmt: TSqlJsonStmt; out Res: TSqlResult);
begin
  case Stmt.Kind of
    jsoExport:
      begin
        // VDbExportJson: Table='' ise tum veritabani, dolu ise tek tablo
        VDbExportJson(FT, Stmt.FilePath, Stmt.Table);
        Res.Affected := 1; Res.Msg := 'OK';
      end;
    jsoImport:
      begin
        VDbImportJson(FT, Stmt.FilePath);
        Res.Affected := 1; Res.Msg := 'OK';
      end;
  end;
end;


{ ------------------------------------------------------------
  Execute - Ana giris noktasi
  //---------------------------------------------------------- }
function TVSqlExecutor.Execute(Stmt: TSqlStmtNode): TSqlResult;
var
  vSet: TDictionary<string, Byte>;  // F2-20: IN kume serbest birakimi
begin
  Result.Affected := 0;
  Result.Msg := '';
  Result.LastTable := '';
  Result.Stmts := 1;
  SetLength(Result.Fields, 0);
  SetLength(Result.Rows, 0);
  if Stmt = nil then Exit;

  // P5-2: alt sorgu onbellegi + P5-CTE kapsami cumle boyu yasar.
  FSubCache := TDictionary<Pointer, TSqlResult>.Create;
  FInSetCache := TDictionary<Pointer, TDictionary<string, Byte>>.Create;
  FCteTables := TDictionary<string, TCteTable>.Create;
  try
    if Stmt is TSqlSelectStmt then ExecSelect(TSqlSelectStmt(Stmt), Result)
  else if Stmt is TSqlInsertStmt then ExecInsert(TSqlInsertStmt(Stmt), Result)
  else if Stmt is TSqlUpdateStmt then ExecUpdate(TSqlUpdateStmt(Stmt), Result)
  else if Stmt is TSqlDeleteStmt then ExecDelete(TSqlDeleteStmt(Stmt), Result)
  else if Stmt is TSqlCreateTableStmt then ExecCreateTable(TSqlCreateTableStmt(Stmt), Result)
  else if Stmt is TSqlAlterTableStmt then ExecAlterTable(TSqlAlterTableStmt(Stmt), Result)
  else if Stmt is TSqlDropTableStmt then ExecDropTable(TSqlDropTableStmt(Stmt), Result)
  else if Stmt is TSqlCreateIndexStmt then ExecCreateIndex(TSqlCreateIndexStmt(Stmt), Result)
  else if Stmt is TSqlDropIndexStmt then ExecDropIndex(TSqlDropIndexStmt(Stmt), Result)
  else if Stmt is TSqlTxStmt then ExecTx(TSqlTxStmt(Stmt), Result)
  else if Stmt is TSqlAdminStmt then ExecAdmin(TSqlAdminStmt(Stmt), Result)
  else if Stmt is TSqlJsonStmt then ExecJson(TSqlJsonStmt(Stmt), Result)
  else raise EVDbException.Create(ecUnsupported, 'Desteklenmeyen AST cumlesi: ' + Stmt.ClassName);
  finally
    FSubCache.Free;
    FSubCache := nil;
    if FInSetCache <> nil then
    begin
      for vSet in FInSetCache.Values do vSet.Free;
      FInSetCache.Free;
      FInSetCache := nil;
    end;
    FCteTables.Free;
    FCteTables := nil;
  end;
end;

end.
