function TVDb.GetWalPath: string;
begin
  Result := ChangeFileExt(FPath, '.wal');
end;

function TVDb.GetDirSyncFailed: Boolean;
begin
  Result := FDirSyncFailed;
end;

function TVDb.GetWalRecordCount: Integer;
var
  fs: TFileStream;
  wp: string;
  h: TVDbWalHead;
  valBuf: TBytes;
  walSize, pos: Int64;
begin
  FLock.Enter;
  try
    CheckOpen;
    Result := 0;
    wp := GetWalPath;
    if not FileExists(wp) then Exit;
    fs := TFileStream.Create(wp, fmOpenRead);
    try
      walSize := fs.Size;
      pos := 0;
      while pos + Int64(SizeOf(h)) <= walSize do
      begin
        fs.Position := pos;
        if fs.Read(h, SizeOf(h)) <> SizeOf(h) then Break;
        if h.Magic <> VDB_WAL_MAGIC then Break;
        if (h.Flags <> VDB_FLAG_PUT) and (h.Flags <> VDB_FLAG_DEL) then Break;
        if (h.Flags = VDB_FLAG_DEL) and (h.ValLen <> 0) then Break;
        if h.ValLen > VDB_MAX_VALUE then Break;
        if pos + Int64(SizeOf(h)) + Int64(h.ValLen) > walSize then Break;
        SetLength(valBuf, h.ValLen);
        if h.ValLen > 0 then
          if fs.Read(valBuf[0], h.ValLen) <> Integer(h.ValLen) then Break;
        if h.ValLen > 0 then
        begin
          if RecCrc(0, h.Key, h.ValLen, h.Flags, @valBuf[0]) <> h.Crc then Break;
        end
        else if RecCrc(0, h.Key, 0, h.Flags, nil) <> h.Crc then Break;
        Inc(Result);
        pos := pos + Int64(SizeOf(h)) + Int64(h.ValLen);
      end;
    finally
      fs.Free();
    end;
  finally
    FLock.Leave;
  end;
end;