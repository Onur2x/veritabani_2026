# vdbapi.dll — Kendi Programınızda Kullanım

## Ne İşe Yarar

Bu veritabanı motoru Pascal/FPC ile yazıldı. **Delphi derleyicisi FPC ile
üretilmiş `.ppu` dosyalarını bağlayamaz** — iki derleyicinin birim biçimi
uyumsuzdur. Bu yüzden tek yol bir **DLL**'dir.

`vdbapi.dll` motorun tamamını **C ABI** ile dışa açar. Aynı dosya Delphi,
C#, Python, C, Rust ve diğer dillerden çağrılabilir; her dil için yalnızca
birkaç satırlık bir bağlayıcı gerekir.

## Dosyalar

| Dosya | İşlev |
|---|---|
| `vdbapi.dll` | **Motorun kendisi.** Programınızın yanında olmalı. |
| `vdbapi.h` | C/C++ için fonksiyon bildirimleri |
| `VDBClient.pas` | **Delphi/Pascal için hazır birim.** `uses VDbClient;` yeter. |
| `build_dll.ps1` | DLL'i yeniden derler |
| `vdbapitest.exe` | ABI testi (101 kontrol) |
| `vdbclienttest.exe` | Delphi birim testi (55 kontrol) |
| `vdbclientdemo.exe` | Çalıştırılabilir kullanım örneği |

## Delphi'de Kullanım (Senin Durumun)

### 1. Dosyaları kopyala

`vdbapi.dll` ve `VDBClient.pas` dosyalarını Delphi projenin klasörüne kopyala.

### 2. Projeye ekle

`VDBClient.pas` dosyasını projeye "Existing Unit" olarak ekle ve
`uses VDbClient;` yaz.

### 3. Platform: 32-bit

**DLL 32-bit (x86) olarak derlenmiştir.** Delphi projen de 32-bit olmalı:

```
Project > Options > Delphi Compiler > Target Platforms > 32-bit Windows
```

64-bit projede `vdbapi.dll` yüklenemez.

### 4. Kullan

```pascal
uses VDbClient;

var
  Db: TVDb;
  R: TVDbResult;
begin
  Db := TVDb.Open('C:\veriler\veritabani.odb');
  try
    Db.SQL('CREATE TABLE kisi (id INTEGER PRIMARY KEY, ad TEXT NOT NULL, yas INTEGER)').Free;

    Db.SQL('INSERT INTO kisi (id, ad, yas) VALUES ' +
           '(1, ''Ali'', 30), (2, ''Veli'', 25)').Free;

    R := Db.SQL('SELECT id, ad FROM kisi ORDER BY id');
    try
      ShowMessage(IntToStr(R.RowCount) + ' satir');
      ShowMessage(R.FieldName(1) + ' = ' + R.Value(0, 1));   // ad = Ali
    finally
      R.Free;
    end;

    // Kısıt hatası istisna olarak gelir
    try
      Db.SQL('INSERT INTO kisi (id, ad) VALUES (3, NULL)').Free;
    except
      on E: EVDbApiError do
        ShowMessage('Kısıt hatası (kod ' + IntToStr(E.Code) + '): ' + E.Message);
    end;
  finally
    Db.Free;
  end;
end;
```

Çalışan tam örnek: `vdbclientdemo.exe`

```
cd veritabani
vdbclientdemo.exe
```

## Önemli Kurallar

### Metinler UTF-8

Tüm metinler **UTF-8** ve NUL ile sonlanır. Kaynak kodunuzda Türkçe
karakter kullanacaksanız dosyayı UTF-8 olarak kaydedin:

```pascal
Db.SQL('INSERT INTO kisi (id, ad) VALUES (1, ''Ahmet Çelik'')');
```

### Aynı Veritabanı Aynı Anda Tek Programda Açık Olabilir

Motor dosyayı **işlemler arası kilitler** (`LockFileEx`). İkinci bir
program aynı dosyayı açmaya çalışırsa `VDB_E_OPEN` hatası alır:

```pascal
if not TVDb.TryOpen(Yol, True, Db, Hata) then
  ShowMessage('Açılamadı: ' + Hata);   // başka program açık
```

Yani `had.exe` ile kendi programını **aynı anda çalıştıramazsın**. Yönetimi
kullanacaksan önce onu kapat.

### WAL İsteğe Bağlı

`Put`/`Delete` otomatik olarak WAL yazmaz. `WalWrite` çağrıldığında kayıt
`.wal` dosyasına yazılır ve **ana dosyaya yazılmaz**; veri ancak
`WalReplay` veya `WalCheckpoint` ile kalıcı hâle gelir.

```pascal
Db.WalWrite(1001, 'önemli bilgi');   // ana dosyaya YAZILMAZ
Db.WalReplay;                         // şimdi yazılır
```

Normal veri için `Put` kullan; WAL yalnızca "ana dosyaya yazmadan kayıt
tutmak" istediğinde gerekir (örn. toplu yükleme sırasında çökerse veri
kaybolmasın).

### Hata Yönetimi

Her çağrı `VDB_OK` (0) dönerse başarılıdır. `VDBClient` hataları
`EVDbApiError` istisnası olarak fırlatır; `E.Code` ABI hata kodudur.

| Kod | Anlamı |
|---|---|
| `-2` | Geçersiz handle |
| `-3` | Veritabanı açılamadı (başka program açık olabilir) |
| `-4` | SQL hatası |
| `-9` | Anahtar/tablo bulunamadı |
| `-10` | UNIQUE veya PK ihlali |
| `-11` | FK / CHECK / NOT NULL ihlali |

### `VdbGet` İki Aşamalıdır

Doğrudan DLL'i kullanırsan değeri okumak iki çağrı ister:

```c
int need = VdbGet(h, key, NULL, 0);   /* gerekli boyut */
if (need == -1) { /* anahtar yok */ }
else if (need < 0) { need = -need; }  /* negatif = boyut */
char buf[need];
VdbGet(h, key, buf, need);            /* asıl okuma */
```

`VDBClient.pas` bunu sizin için yapar — `GetStr` / `GetBytes` kullanın.

## Başka Diller İçin

`vdbapi.h` dosyasındaki imzaları kullan. Örnek C:

```c
#include "vdbapi.h"

uint32_t db = VdbOpen("C:\\veriler\\veritabani.odb", 1);
if (db == 0) {
    printf("Hata %d: %s\n", VdbLastErrorCodeGet(), VdbLastError());
    return 1;
}

uint32_t r = VdbExec(db, "SELECT id, ad FROM kisi", 0);
if (r) {
    int n = VdbResultRowCount(r);
    for (int i = 0; i < n; i++)
        printf("%s\n", VdbResultValue(r, i, 1));
    VdbResultFree(r);
}
VdbClose(db);
```

## Derleme

DLL'i yeniden derlemek için:

```powershell
powershell -ExecutionPolicy Bypass -File build_dll.ps1
```

> **Not:** Lazarus'un `.lpi` XML'inde kütüphane türü işareti bu kurulumda
> okunmadığı ve proje `.exe` olarak bağlandığı için DLL derlemesi FPC'yi
> doğrudan çağıran `build_dll.ps1` ile yapılır. Aynı nedenle derleme
> betiğinde `-Mdelphi` **bilinçli olarak verilmez**: `VDbCrc32.pas` içindeki
> bir yorumda `{$mode delphi}` dizisi geçiyor ve delphi modunda derleme
> kırılıyor (FPC yorumu `}` ile kapatıp satırın kalanını kod sanıyor).

## Doğrulama Durumu

| Test | Kapsam | Sonuç |
|---|---|---|
| `sqltest.exe` | Motor (830 kontrol) | ✅ 830/830 |
| `vdbapitest.exe` | DLL ABI (101 kontrol) | ✅ 101/101 |
| `vdbclienttest.exe` | Delphi birimi (55 kontrol) | ✅ 55/55 |

`vdbapitest.exe` DLL'i **`LoadLibrary` ile dinamik yükler** ve her export'u
`GetProcAddress` ile adres alarak çağırır — yani gerçekten harici bir
programın yaptığını yapar. Eksik bir export sessizce geçmez, test
hata durur.
