﻿unit VDbCdc;

{ VDb Change Data Capture (CDC) - Motor Katmani
  WAL uzerinden tum degisiklikleri yakalar ve callback ile disari aktarir. }

{$mode delphi}

interface

uses
  Classes, SysUtils, SyncObjs, Generics.Collections, VDbCore, VDbTable;

type
  TCDCEventType = (cdcInsert, cdcUpdate, cdcDelete);
  TCDCEvent = record
    EventType: TCDCEventType;
    TableName: string;
    PK: string;
    OldValues: TStrArray;
    NewValues: TStrArray;
    Timestamp: TDateTime;
    Seq: QWord;
  end;

  TCDCChangeProc = procedure(const Event: TCDCEvent);

  TVDbCdcThread = class(TThread)
  private
    FCdc: Pointer;
  protected
    procedure Execute; override;
  public
    constructor Create(ACdc: Pointer);
  end;

  TVDbCdc = class
  private
    FTb: TVTableDb;
    FWalPath: string;
    FThread: TVDbCdcThread;
    FRunning: Boolean;
    FLock: TCriticalSection;
    FOnChange: TCDCChangeProc;
    FLastPos: Int64;
    FBuffer: TList<TCDCEvent>;
    FFlushInterval: Integer;
    procedure ProcessWal;
  public
    constructor Create(const ATb: TVTableDb);
    destructor Destroy; override;
    procedure Start;
    procedure Stop;
    procedure Flush;
    property OnChange: TCDCChangeProc read FOnChange write FOnChange;
    property FlushIntervalMs: Integer read FFlushInterval write FFlushInterval;
  end;

implementation

constructor TVDbCdcThread.Create(ACdc: Pointer);
begin
  inherited Create(True);
  FreeOnTerminate := False;
  FCdc := ACdc;
end;

procedure TVDbCdcThread.Execute;
var
  cdc: TVDbCdc;
begin
  cdc := TVDbCdc(FCdc);
  while not Terminated do
  begin
    cdc.ProcessWal;
    Sleep(1000);
  end;
end;

{ TVDbCdc }

constructor TVDbCdc.Create(const ATb: TVTableDb);
begin
  inherited Create;
  FTb := ATb;
  FWalPath := ChangeFileExt(FTb.Kv.FilePath, '.wal');
  FLock := TCriticalSection.Create;
  FBuffer := TList<TCDCEvent>.Create;
  FFlushInterval := 1000;
  FRunning := False;
  FLastPos := 0;
end;

destructor TVDbCdc.Destroy;
begin
  Stop;
  FBuffer.Free;
  FLock.Free;
  inherited Destroy;
end;

procedure TVDbCdc.Start;
begin
  if FRunning then Exit;
  FRunning := True;
  FThread := TVDbCdcThread.Create(Self);
  FThread.Start;
end;

procedure TVDbCdc.Stop;
begin
  if not FRunning then Exit;
  FRunning := False;
  if Assigned(FThread) then
  begin
    FThread.Terminate;
    FThread.WaitFor;
    FThread.Free;
    FThread := nil;
  end;
  Flush;
end;

procedure TVDbCdc.Flush;
var
  ev: TCDCEvent;
begin
  FLock.Enter;
  try
    for ev in FBuffer do
      if Assigned(FOnChange) then FOnChange(ev);
    FBuffer.Clear;
  finally
    FLock.Leave;
  end;
end;

procedure TVDbCdc.ProcessWal;
var
  fs: TFileStream;
  rec: TVDbRecHead;
  data: TBytes;
  tableId: Word;
  pk: string;
  vals: TStrArray;
  tableName: string;
  ev: TCDCEvent;
begin
  if not FileExists(FWalPath) then Exit;
  
  fs := TFileStream.Create(FWalPath, fmOpenRead or fmShareDenyWrite);
  try
    if fs.Size <= FLastPos then Exit;
    
    fs.Position := FLastPos;
    while fs.Position < fs.Size do
    begin
      if fs.Read(rec, SizeOf(rec)) <> SizeOf(rec) then Break;
      SetLength(data, rec.ValLen);
      if rec.ValLen > 0 then fs.Read(data[0], rec.ValLen);
      
      // Sadece BATCHEND isaretli kayitlari isle (Commit edilenler)
      if (rec.Flags and VDB_FLAG_BATCHEND) = 0 then
      begin
        FLastPos := fs.Position;
        Continue;
      end;
      
      // WAL Value decode - use VDbTable's public DecodeRowData
      if FTb.DecodeRowDataPublic(data, tableId, pk, vals) then
      begin
        tableName := FTb.GetTableNameById(tableId);
        if tableName = '' then tableName := 'unknown';
        
        FillChar(ev, SizeOf(TCDCEvent), 0);
        ev.Seq := rec.Seq;
        ev.Timestamp := Now;
        ev.TableName := tableName;
        ev.PK := pk;
        ev.NewValues := Copy(vals, 0, Length(vals));
        
        case rec.Flags and $03 of
          VDB_FLAG_PUT: ev.EventType := cdcInsert;
          VDB_FLAG_DEL: ev.EventType := cdcDelete;
        end;
        
        FLock.Enter;
        try
          FBuffer.Add(ev);
        finally
          FLock.Leave;
        end;
      end;
      
      FLastPos := fs.Position;
    end;
  finally
    fs.Free;
  end;
end;

end.



