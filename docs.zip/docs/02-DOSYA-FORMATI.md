# 02 — `.odb` / `.wal` Dosya Formatı

> Kaynak: `VDbCore.pas` sabit/kayıt tanımları + `db\` altındaki dosyaların ad/boyut listelemesi.
> Binary içerik açılmadı; ofset tablosu kod tanımlarından alıntıdır.

## Dosya kimliği (16 byte başlık — `TVDbFileHead`)

| Ofset | Boyut | Alan | Değer |
|---|---|---|---|
| 0 | 4 | `Magic` | `$42444F56` (`'VODB'`, little-endian) |
| 4 | 4 | `Ver` | `2` (`VDB_FILE_VER`; eski `1` = `VDB_FILE_VER_OLD`) |
| 8 | 4 | `Flags` | `0` (varsayılan). Tanımlı bitler: `ENCRYPTED=4`, `COMPRESSED=8` — mevcut `.odb`'lerde `0` |
| 12 | 4 | `Crc` | İlk 12 byte'ın CRC32'si |

`VDB_HDR_SIZE = 16`. Kayıtlar hep başlıktan sonra başlar; ham kayıt akışıyla karışmaz.

## Kayıt formatı (`TVDbRecHead`, packed, little-endian)

| Alan | Boyut | Açıklama |
|---|---|---|
| `Magic` | u32 | `$56444231` |
| `Crc` | u32 | `CRC32(seq + key + vallen + flags + value)` |
| `Seq` | u64 | Sıra numarası |
| `Key` | u64 | Anahtar (`UInt64`; tablo satırı için `FNV1a64(lower(table)+#0+pk)`, şema için ayrılmış `0`) |
| `ValLen` | u32 | Değer uzunluğu (`VDB_MAX_VALUE = 16 MB` üst sınır) |
| `Flags` | u8 | `0=PUT`, `1=DEL`, `2=BATCHEND` |
| `Value` | `ValLen` byte | Ham değer baytları |

## Dayanıklılık modeli (Bitcask tarzı, WAL'siz çekirdek)

1. **Append-only:** Yazma hep sona eklenir; yerinde güncelleme yok.
2. **Kayıt başı CRC32:** Bozuk kayıt açılışta tespit edilir, yırtık kuyruk budanır (`Verify` raporlar, dosyayı değiştirmez).
3. **Batch atomikliği:** `COMMIT` tek `fsync` + `BATCHEND` işaretiyle kapanır — ya hep ya hiç; recovery commit'siz kuyruğu geri sarar.
4. **Commit-flush:** Başarılı her `Exec` sonrası kirli bayrak kontrol edilip `Flush` çağrılır (`SyncWrite=False` olsa bile SQL katmanında commit dayanıklıdır).
5. **Kilit:** Aynı `.odb` aynı anda tek işlem tarafından açılır (dosya kilidi); ikinci açış hata koduyla reddedilir.
6. **Bakım:** `Compact` ölü sürümleri temizler (`.bak` bırakır); yedek için `BACKUP` / `EXPORT JSON` kullanılır.

## `.wal` (harici, iskelet)

- `VDbWal.pas`: `WAL_FILE_MAGIC/VER`, `WalWriteAhead/WalReplay/WalCheckpoint/WalExists`.
- `VDbCore.pas` hook'ları: `WriteAheadWAL/ReplayWAL/CheckpointWAL/HasWAL/WalRecordCount/WalPath`.
- `VDbTable.PutRow`: `FKv.WriteAheadWAL(key, b, VDB_FLAG_PUT)` çağrısı mevcut.
- Durum: iskelet düzeyinde; fiilî garanti yukarıdaki çekirdek mekanizmadadır.

## Sürüm notu

- `v1 -> v2` geçişinde `BATCHEND` (`flags=2`) eklendi. `v1` dosyaları açılışta `v2`'ye yükseltilir (`DetectFormat`/`MigrateLegacy`). Eski sürümlü build `v2` bayrağını "bozuk kayıt" sanıp kırpmaz — dosyayı **açamaz** (temiz hata), veri silinmez.
