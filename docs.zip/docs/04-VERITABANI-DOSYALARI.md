# 04 — Veritabanı Dosyaları (`db\`)

> Kaynak: `D:\veritabani\db\` dizin listelemesi, 04.10.2026. Binary içerik açılmadı.

| Dosya | Boyut | Son yazma | Durum |
|---|---|---|---|
| `mtakip.odb` | 7096901 byte (~6,77 MB) | 04.10.2026 21:50 | En büyük dosya; üretim/test ayrımı dosya yöneticisinden doğrulanmalı |
| `veritabani.odb` | 381068 byte (~372 KB) | 04.10.2026 09:48 | Ana çalışma dosyası (önceki oturumlarda `VODB v2` başlığı doğrulandı) |
| `satis.odb` | 135 byte | 01.10.2026 15:31 | Neredeyse boş test dosyası |
| `satis.odb.bak` | 551 byte | 01.10.2026 15:30 | `satis.odb` yedeği |

## Notlar

- Biçim: `v2` (`VODB` magic + sürüm + bayrak + başlık CRC, ardından append-only kayıtlar). Ayrıntı: `02-DOSYA-FORMATI.md`.
- Önceki oturum ölçümleri (`veritabani.odb` başlık: `Magic=VODB`, `Ver=2`) bu belgede **yeniden doğrulanmadı**; güncel başlık kontrolü için `Verify`/`sqltest` çıktısına bakılmalı.
- `ESKI\db\` ve `mtakip\data\` altında başka `.odb` kopyaları olabilir; envanter dışı bırakıldı (bu belge yalnız `db\` kökünü kapsar).
- Yedekleme: `BACKUP` / `EXPORT JSON` kullanılır; `Compact` `.bak` bırakır.
