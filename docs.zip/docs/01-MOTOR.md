# 01 — VDB Motor Birimleri

> Kaynak: `D:\veritabani\*.pas` — salt okuma ile çıkarıldı, 04.10.2026.
> Hiçbir kaynak dosyası değiştirilmedi; satır/byte sayıları ölçüm sonucudur.

Veri akışı:

```
SQL metni -> VDbParser -> VDbAst -> VDbExecutor -> VDbTable -> VDbCore -> .odb
```

## Çekirdek katman

| Birim | Satır / Byte | Görev |
|---|---|---|
| `VDbCore.pas` | 1860 / 60065 | Append-only `UInt64 -> Bytes` KV motor. CRC, dosya-sonu yırtık truncate, batch atomikliği (`BATCHEND`), `fsync`, kilit (`TCriticalSection`). Public: `Open/Close, Put/Get/Exists/Delete, BeginBatch/CommitBatch/AbortBatch, Flush, Count/GetAllKeys/ScanAll, Compact/AutoCompact, Verify, BackupTo`, WAL hook'ları (`WriteAheadWAL/ReplayWAL/CheckpointWAL/HasWAL/WalRecordCount/WalPath`). Sabitler: `VDB_MAGIC=$56444231`, `VDB_FLAG_PUT=0, DEL=1, BATCHEND=2, ENCRYPTED=4, COMPRESSED=8`, `VDB_MAX_VALUE=16 MB`, `VDB_FILE_MAGIC=$42444F56 ('VODB')`, `VDB_FILE_VER=2`, `VDB_HDR_SIZE=16`. |
| `VDbTable.pas` | 4582 / 159817 | KV üstünde tablo/sema katmanı. `TColDef/TFkDef/TIdxDef`, `VDB_SCHEMA_KEY=0`, `VSCH1` etiketi, constraint + FK (`RESTRICT/CASCADE/SETNULL/SETDEFAULT`), CHECK, bellek-içi sekonder indeks. Public: `Open/Close, CreateTable/DropTable, AlterAddColumn/DropColumn/RenameColumn/ColumnType/SetDefault/DropDefault/SetNotNull/RenameTable, Insert/BatchInsert, ReadRow/ScanRows/CandidatePks, UpdateWhere/UpdateRowInPlace, Delete/DeleteWhere, CreateIndex/CreateIndexCols/DropIndex/RebuildIndexes, Lock/Unlock`. `PutRow` içinde `FKv.WriteAheadWAL(key, b, VDB_FLAG_PUT)` çağrısı mevcut. |
| `VDbCrc32.pas` | 105 / 2677 | Saf Pascal IEEE CRC32 (`VDbCrc32Init/Final/Update/Of/...`). Kayıt + dosya başlığı bütünlüğü. |
| `VDbSync.pas` | 155 / 4219 | `fsync` + dizin flush + dosya kilidi (`VDbFlushStream/VDbFlushDir/VDbLockStream/UnlockStream`, `VDB_LOCK_EX/NB/UN`). Çift-açma ve crash-kalıcılık koruması. |
| `VDbWal.pas` | 81 / 2200 | Harici `.wal` iskeleti (`WAL_FILE_MAGIC/VER`, `WalWriteAhead/WalReplay/WalCheckpoint/WalExists`). `.odb`'yi bozmadan yaz-önce-log taslağı. |
| `VDbTest.pas` | 44 / 909 | WAL duman testi (`RunWalCrashTest(DbPath)`). Hiçbir proje kullanmıyor (ölü kod durumunda). |

## SQL katmanı

| Birim | Satır / Byte | Görev |
|---|---|---|
| `VDbSql.pas` | 3193 / 108211 | Dış cephe `TVSql`: `Exec(Sql)`, `Exec(Sql,Params)`, `SplitStatements`, `ExecAll`, `AutoTransaction`. Betik bölme + otomatik transaction + DB dosya yönetimi. |
| `VDbAst.pas` | 925 / 22042 | Tip-güvenli AST düğüm modeli (`TSqlNode/TSqlExprNode`, literal/kolon/binary/unary/IN/subquery/BETWEEN/func/CASE, `TSqlSelect/Insert/Update/Delete`, `CreateTable/AlterTable/DropTable`, `CreateIndex/DropIndex`, TX/Admin/JSON, `TSqlResult`). Her düğüm alt-ağacı `Destroy`'da temizler. |
| `VDbParser.pas` | 2030 / 64131 | Recursive-descent ayrıştırıcı. Tek giriş: `Parse(ASql,AParams):TSqlStmtNode`. SELECT/WITH/INSERT/UPDATE/DELETE/CREATE/ALTER/DROP/ADMIN/JSON ayrıştırır. |
| `VDbExecutor.pas` | 3721 / 136519 | AST yürütücü `TVSqlExecutor.Execute(Stmt):TSqlResult`. WHERE/ORDER/GROUP/JOIN/WINDOW/UNION, DDL/TX (`DoSort/ExecGroupBy/ExecJoinScan/ComputeWindows`, `VDB_MAX_RESULT_ROWS`). |

## Yardımcı katman

| Birim | Satır / Byte | Görev |
|---|---|---|
| `VDbJson.pas` | 467 / 15240 | `VDbExportJson(Tb,Path,Table)` / `VDbImportJson(Tb,Path)`, `VDbCtypeName/ByName`. Kanonik sıralı JSON taşıma. |
| `VDbErr.pas` | 133 / 5241 | Bağımsız hata kodları (`TVDbErrorCode`: `ecNone..ecJsonError` ~30 değer) + `EVDbException(ErrorCode)` + `VDbErrorName`. |
| `VDbText.pas` | 237 / 5973 | Türkçe-duyarlı UTF-8 metin (`VDbTrUpper/TrLower/Utf8Length/CompareTr`, `I/ı/i/İ` çevrimi, TR alfabetik sıra). |
| `VDbPool.pas` | 251 / 6167 | `.odb` exclusive kilitli olduğu için tek motor üstünde N `TVSql` havuzu (`Create(ATableDb,ASize,ATimeoutMs)`, `Acquire/Release/Close`, `Exec`). Paralellik çarpmaz, kuyruk+zaman aşımı ile sınırlar. |
| `VDbDataSet.pas` | 1076 / 31823 | `TDataSet` köprüsü `TVDbQuery` (DBGrid/DataSource, tipli alanlar, tek-tablo `Insert/Edit/Post/Delete`) + `VDbDataSetReg.pas` (24 satır, kayıt birimi). `vdbcomponents.lpk/.pas` runtime paketidir. |

## Notlar

- `VDbSql - Kopya (2).pas` diye bir dosya önceki oturumlarda anılmıştı; **şu an `D:\veritabani\` kökünde böyle bir dosya YOK** (listelemede görünmüyor). Envanterde yer almıyor.
- `VDbWal.pas` + `VDbTest.pas` derlenebilir durumda ancak fiilî dayanıklılık `.odb`'nin kendi append-only + CRC + `BATCHEND` + açılış recovery mekanizmasındadır (ayrıntı `02-DOSYA-FORMATI.md`).
