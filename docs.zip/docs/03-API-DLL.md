# 03 — API / DLL Katmanı

> Kaynak: `vdbapi_core.pas` (1243 satır / 32739 byte), `vdbapi.h` (6144 byte),
> `vdbapi.lpr` (7640 byte), `VDBClient.pas` (633 satır / 19391 byte),
> `DLL_KULLANIM.md` (6026 byte), `build_dll.ps1` (2211 byte). Salt okuma.

## Neden DLL?

Motor FPC ile yazıldı; Delphi derleyicisi FPC `.ppu` dosyalarını bağlayamaz.
Tek yol C ABI sunan bir DLL'dir (`vdbapi.dll`, 1084416 byte, 32-bit x86, `stdcall`).

## Katmanlar

```
Motor (VDbCore/Table/Sql)
  -> vdbapi_core.pas (gerçek mantık, 35 export fonksiyon)
  -> vdbapi.lpr (ince sarmalayıcı: FPC `exports` kısıtı yüzünden her API için 1 satırlık wrapper + exports listesi)
  -> vdbapi.dll
  -> vdbapi.h (C/C#/Python/Rust başlığı) | VDBClient.pas (Delphi istemcisi)
```

## Tasarım kuralları (değiştirilmemeli)

1. Hiçbir istisna DLL sınırını geçmez (`try/except` + hata kodu + son-hata metni).
2. Metinler UTF-8, NUL-sonlu.
3. Handle `0` daima hata; bozuk handle crash değil hata kodudur (`VDB_E_BAD_HANDLE`).
4. Sonuç tamponu **bir sonraki çağrıya kadar** geçerli; iki işaretçi aynı anda tutulmaz.
5. Bellek sahipliği DLL'dedir; çağıran yalnız kendi buffer'ını yönetir (`ResultFree` sonuç handle'ını kapatır).
6. Aynı DB dosyası aynı anda tek işlem tarafından açılır.

## Hata kodları

| Kod | Ad | Anlam |
|---|---|---|
| `0` | `VDB_OK` | Başarı |
| `-1` | `VDB_E_GENERAL` | Sınıflandırılmamış |
| `-2` | `VDB_E_BAD_HANDLE` | Geçersiz handle |
| `-3` | `VDB_E_OPEN` | Açılamadı (kilitli vb.) |
| `-4` | `VDB_E_SQL` | SQL hatası (`VdbLastError` ayrıntı) |
| `-5` | `VDB_E_READONLY` | Yazma desteklenmiyor |
| `-6` | `VDB_E_BUFFER` | Tampon küçük (gerekli boyut negatif döner) |
| `-7` | `VDB_E_RANGE` | İndis sınır dışı |
| `-8` | `VDB_E_ENGINE` | Motor hatası |
| `-9` | `VDB_E_NOT_FOUND` | Anahtar/tablo yok |
| `-10` | `VDB_E_DUPLICATE` | UNIQUE/PK ihlali |
| `-11` | `VDB_E_CONSTRAINT` | FK/CHECK/NOT NULL ihlali |

`VDB_API_VERSION = $00010000 (1.0)`, `VDB_SQL_AUTOTXN = $0001`.

## Fonksiyon listesi (35 export)

- Sürüm/hata: `VdbApiVersion, VdbVersion, VdbLastError, VdbLastErrorCodeGet, VdbSetLastErrorCode`
- Aç/kapa: `VdbOpen(APath,ASyncWrite)->handle, VdbClose, VdbCloseAll`
- KV: `VdbCount, VdbPut, VdbGet, VdbExists, VdbDelete, VdbKeys, VdbFlush`
- SQL/sonuç: `VdbExec->result, VdbResultFieldCount/RowCount/FieldName/Value/Affected/Stmts/Message/LastTable/ResultFree`
- Bakım/WAL: `VdbVerify, VdbWalHas, VdbWalRecordCount, VdbWalWrite, VdbWalWriteDelete, VdbWalReplay, VdbWalCheckpoint, VdbFileSize, VdbDeadBytes, VdbAutoCompact`

Notlar: `VdbGet` iki aşamalı çağrılır (`need = VdbGet(h,key,NULL,0)` ile boyut öğrenilir).
WAL opt-in'dir: `WalWrite` tek başına yazmaz; `WalReplay/Checkpoint` yazar.

## Delphi istemcisi (`VDBClient.pas`)

- `DLL_NAME='vdbapi.dll'`, proje **Win32** olmalı, DLL exe yanında (veya PATH'te) olmalı.
- `TVDb.Open(...).SQL(...).Query` akışı; `EVDbApiError(Code)` istisnası.
- `TVDb`: `Put/PutBytes/GetStr/GetBytes/Exists/DeleteKey/Flush, SQL, Verify, AutoCompact, HasWAL, WalWrite/WalWriteDelete/WalReplay/WalCheckpoint, Size/DeadBytes/Count`.

## Test / demo / hız programları

| Dosya | Boyut | Amaç |
|---|---|---|
| `vdbapitest.lpr` / `.exe` (25422 / 232448) | DLL'yi `LoadLibrary+GetProcAddress` ile dinamik yükleyip 7 grupta (sürüm/açılış/KV/UTF-8/SQL/bakım/WAL) gerçek harici-program davranışını test eder |
| `vdbclientdemo.lpr` / `.exe` (5202 / 205312) | `VDBClient` ile çalışan örnek (tablo kur + INSERT + SELECT + hata yolları + Verify) |
| `vdbclienttest.lpr` / `.exe` (11185 / 230912) | `VDBClient` sarmalayıcı katman testi |
| `vdbspeed.lpr` / `.exe` (8428 / 552448) | 4 ölçüm: saf DLL çağrı maliyeti, KV DLL-vs-direkt, istemci sarmalayıcı, büyük SELECT ölçeklenmesi |
| `build_dll.ps1` | DLL'yi 32-bit `i386-win32` derleyen betik (`ppc386.exe` doğrudan; `-Mdelphi` bilinçli verilmez) |

Ayrıntı için `DLL_KULLANIM.md` (kullanıcı kılavuzu) geçerlidir.
