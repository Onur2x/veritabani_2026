unit VDbText;

{ Turkce duyarli metin islemleri (UTF-8, bagimsiz birim).
  Girdi dizileri UTF-8 kodlu AnsiString kabul edilir (motorun formati).

  - VDbTrUpper/VDbTrLower: noktali/noktasiz I dogru cevrimi
    (i->İ, I->ı) + s/g/u/o/c harfleri. Sistem yerel ayarindan bagimsizdir
    (FPC UpperCase/LowerCase Turkce'yi bilmez).
  - VDbUtf8Length: karakter sayisi (LENGTH() icin; bayt degil).
  - VDbCompareTr: Turk alfabesi sirasi
      a b c c d e f g g h i i j k l m n o o p r s s t u u v y z
    Doner: <0 (A once), 0 (esit), >0. Buyuk/kucuk harf birincil sirada
    esittir; esitlikte orijinal baytlar bag cozer (deterministik).
    Harf-disi karakterler kod noktasina gore harflerden ONCE gelir. }

{$mode delphi}

interface

function VDbTrUpper(const S: string): string;
function VDbTrLower(const S: string): string;
function VDbUtf8Length(const S: string): Integer;
function VDbCompareTr(const A, B: string): Integer;

implementation

// Bir sonraki UTF-8 kod noktasini okur (hatali baytta Latin-1 sayar).
function NextCp(const S: string; var P: Integer): Integer;
var
  b0, b1, b2, b3: Byte;
begin
  b0 := Byte(S[P]);
  if b0 < $80 then
  begin
    Result := b0;
    Inc(P);
  end
  else if (b0 and $E0 = $C0) and (P + 1 <= Length(S)) then
  begin
    b1 := Byte(S[P + 1]);
    Result := ((b0 and $1F) shl 6) or (b1 and $3F);
    Inc(P, 2);
  end
  else if (b0 and $F0 = $E0) and (P + 2 <= Length(S)) then
  begin
    b1 := Byte(S[P + 1]);
    b2 := Byte(S[P + 2]);
    Result := ((b0 and $0F) shl 12) or ((b1 and $3F) shl 6) or (b2 and $3F);
    Inc(P, 3);
  end
  else if (b0 and $F8 = $F0) and (P + 3 <= Length(S)) then
  begin
    b1 := Byte(S[P + 1]);
    b2 := Byte(S[P + 2]);
    b3 := Byte(S[P + 3]);
    Result := ((b0 and $07) shl 18) or ((b1 and $3F) shl 12) or
      ((b2 and $3F) shl 6) or (b3 and $3F);
    Inc(P, 4);
  end
  else
  begin
    Result := b0;
    Inc(P);
  end;
end;

procedure PutCp(var D: string; Cp: Integer);
begin
  if Cp < $80 then
    D := D + Chr(Cp)
  else if Cp < $800 then
    D := D + Chr($C0 or (Cp shr 6)) + Chr($80 or (Cp and $3F))
  else if Cp < $10000 then
    D := D + Chr($E0 or (Cp shr 12)) + Chr($80 or ((Cp shr 6) and $3F)) +
      Chr($80 or (Cp and $3F))
  else
    D := D + Chr($F0 or (Cp shr 18)) + Chr($80 or ((Cp shr 12) and $3F)) +
      Chr($80 or ((Cp shr 6) and $3F)) + Chr($80 or (Cp and $3F));
end;

function TrUpperCp(Cp: Integer): Integer;
begin
  case Cp of
    $69: Result := $130; // i -> İ
    $131: Result := $49; // ı -> I
    $15F: Result := $15E; // ş -> Ş
    $11F: Result := $11E; // ğ -> Ğ
    $FC: Result := $DC;  // ü -> Ü
    $F6: Result := $D6;  // ö -> Ö
    $E7: Result := $C7;  // ç -> Ç
    $61..$68, $6A..$7A: Result := Cp - $20; // ASCII (i yukarida ele alindi)
  else
    // ASCII disi buyukl banda dokunma; kucuk ASCII banda buyut.
    // (Diger alfabelerin harfleri aynen birakilir.)
    Result := Cp;
  end;
end;

function TrLowerCp(Cp: Integer): Integer;
begin
  case Cp of
    $49: Result := $131; // I -> ı
    $130: Result := $69; // İ -> i
    $15E: Result := $15F; // Ş -> ş
    $11E: Result := $11F; // Ğ -> ğ
    $DC: Result := $FC;
    $D6: Result := $F6;
    $C7: Result := $E7;
    $41..$48, $4A..$5A: Result := Cp + $20; // ASCII (I yukarida ele alindi)
  else
    Result := Cp;
  end;
end;

function VDbTrUpper(const S: string): string;
var
  p: Integer;
begin
  Result := '';
  p := 1;
  while p <= Length(S) do
    PutCp(Result, TrUpperCp(NextCp(S, p)));
end;

function VDbTrLower(const S: string): string;
var
  p: Integer;
begin
  Result := '';
  p := 1;
  while p <= Length(S) do
    PutCp(Result, TrLowerCp(NextCp(S, p)));
end;

function VDbUtf8Length(const S: string): Integer;
var
  p: Integer;
begin
  Result := 0;
  p := 1;
  while p <= Length(S) do
  begin
    NextCp(S, p);
    Inc(Result);
  end;
end;

// Kucuk harf normalize + Turk alfabesi birincil agirligi (1..29).
// Harf degilse agirlik = $200000 + kod noktasi (harflerden sonra).
function TrWeight(Cp: Integer): Integer;
var
  L: Integer;
begin
  if (Cp >= $41) and (Cp <= $5A) then
    L := Cp + $20
  else
    L := TrLowerCp(Cp);
  // ASCII kucuk harf olmayanlar (rakam, noktalama...) kod noktasidir.
  if (L < $61) or (L > $7A) then
  begin
    case L of
      $131: Exit(11); // ı
      $69: Exit(12);  // i
      $E7: Exit(4);   // ç
      $11F: Exit(9);  // ğ
      $F6: Exit(19);  // ö
      $15F: Exit(23); // ş
      $FC: Exit(26);  // ü
    else
      Exit($200000 + Cp);
    end;
  end;
  case Chr(L) of
    'a': Exit(1);
    'b': Exit(2);
    'c': Exit(3);
    'd': Exit(5);
    'e': Exit(6);
    'f': Exit(7);
    'g': Exit(8);
    'h': Exit(10);
    'i': Exit(12);
    'j': Exit(13);
    'k': Exit(14);
    'l': Exit(15);
    'm': Exit(16);
    'n': Exit(17);
    'o': Exit(18);
    'p': Exit(20);
    'r': Exit(21);
    's': Exit(22);
    't': Exit(24);
    'u': Exit(25);
    'v': Exit(27);
    'y': Exit(28);
    'z': Exit(29);
  else
    // ASCII harf disi (or. '{'): kod noktasi.
    Exit($200000 + Cp);
  end;
end;

function VDbCompareTr(const A, B: string): Integer;
var
  pa, pb, ca, cb, wa, wb: Integer;
  i, LB: Integer;
begin
  pa := 1;
  pb := 1;
  while (pa <= Length(A)) and (pb <= Length(B)) do
  begin
    ca := NextCp(A, pa);
    cb := NextCp(B, pb);
    wa := TrWeight(ca);
    wb := TrWeight(cb);
    if wa < wb then Exit(-1);
    if wa > wb then Exit(1);
  end;
  if Length(A) - pa <> Length(B) - pb then
  begin
    // Biri one ek: kisa olan once (uzunluk farki bayt degil, konum farki).
    if (Length(A) - pa) < (Length(B) - pb) then Exit(-1) else Exit(1);
  end;
  // Birinciller esit: orijinal baytlar bag cozer (deterministik).
  LB := Length(A);
  if Length(B) < LB then LB := Length(B);
  for i := 1 to LB do
  begin
    if Byte(A[i]) < Byte(B[i]) then Exit(-1);
    if Byte(A[i]) > Byte(B[i]) then Exit(1);
  end;
  if Length(A) < Length(B) then Exit(-1);
  if Length(A) > Length(B) then Exit(1);
  Result := 0;
end;

end.
