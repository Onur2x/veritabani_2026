program sqltest;
{ VDB SQL tam test paketi.
  Tum desteklenen SQL komutlarini calistirir, beklenen sonucu karsilastirir.
  Derleme:  lazbuild sqltest.lpi
  Calistirma: sqltest.exe <calisma-klasoru>
  klasor verilmezse gecici klasor kullanilir. }

{$mode delphi}{$H+}

uses
  SysUtils, Classes, VDbCore, VDbTable, VDbSql;

var
  D: string;
  kv: TVDb;
  tb: TVTableDb;
  sq: TVSql;
  R: TSqlResult;
  nPass, nFail, nGrp: Integer;
  grpName: string;

const
  Q = '''';   // tek tirnak

{ ------------------------------------------------------------ yardimcilar }

procedure Grp(const N: string);
begin
  Inc(nGrp);
  grpName := N;
  WriteLn;
  WriteLn('== ', nGrp, '. ', N);
end;

procedure Ok(const Nm, E: string);
begin
  Inc(nPass);
  if E = '' then WriteLn('   OK   ', Nm)
  else WriteLn('   OK   ', Nm, '   [', E, ']');
end;

procedure No(const Nm, E: string);
begin
  Inc(nFail);
  WriteLn('   FAIL ', Nm, '   [', E, ']');
end;

procedure Chk(const Nm, Sql: string; const ExpectRows: Integer);
var e: string;
begin
  try
    R := sq.Exec(Sql);
    if ExpectRows >= 0 then
    begin
      if Length(R.Rows) = ExpectRows then Ok(Nm, IntToStr(Length(R.Rows)) + ' satir')
      else No(Nm, 'beklenen ' + IntToStr(ExpectRows) + ' satir, gelen ' +
                 IntToStr(Length(R.Rows)));
    end
    else Ok(Nm, '');
  except
    on E: Exception do No(Nm, '(' + E.Message + ')');
  end;
end;

procedure ChkVal(const Nm, Sql: string; RowIx, ColIx: Integer;
  const Want: string);
var got: string;
begin
  try
    R := sq.Exec(Sql);
    if (RowIx >= Length(R.Rows)) or (ColIx >= Length(R.Rows[RowIx])) then
    begin
      No(Nm, 'sonuc hucre yok (satir ' + IntToStr(RowIx) + '/' +
              IntToStr(Length(R.Rows)) + ')');
      Exit;
    end;
    got := R.Rows[RowIx][ColIx];
    if got = Want then Ok(Nm, got)
    else No(Nm, 'beklenen "' + Want + '" gelen "' + got + '"');
  except
    on E: Exception do No(Nm, '(' + E.Message + ')');
  end;
end;

// Calistirilmasi beklenen, HATA vermesi gereken komut
procedure ChkErr(const Nm, Sql: string);
begin
  try
    sq.Exec(Sql);
    No(Nm, 'HATA VERMEDI (kabul edildi)');
  except
    on E: Exception do Ok(Nm, E.Message);
  end;
end;

procedure ChkInt(const Nm: string; const Got, Expect: Integer);
// TSqlResult sayisal alanlarini (Affected / Stmts) dogrudan dogrular.
begin
  if Got = Expect then Ok(Nm, IntToStr(Got))
  else No(Nm, 'beklenen ' + IntToStr(Expect) + ', gelen ' + IntToStr(Got));
end;

// Ayri bir calisma yerinde gecici acma/kapatma
procedure Fresh(const Nm: string);
var p: string;
begin
  p := D + '\' + Nm;
  ForceDirectories(p);
  if tb <> nil then begin tb.Close; kv.Close; sq.Free; tb.Free; kv.Free; end;
  kv := TVDb.Create; tb := TVTableDb.Create(kv); sq := TVSql.Create(tb);
  kv.Open(p);
  tb.Open(p);
end;

procedure UseDir(const Nm: string);
var p: string;
begin
  p := D + '\' + Nm;
  ForceDirectories(p);
  if tb <> nil then begin tb.Close; kv.Close; sq.Free; tb.Free; kv.Free; end;
  kv := TVDb.Create; tb := TVTableDb.Create(kv); sq := TVSql.Create(tb);
  kv.Open(p);
  tb.Open(p);
end;

procedure Shutdown;
begin
  if tb <> nil then
  begin
    tb.Close; kv.Close; sq.Free; tb.Free; kv.Free;
    sq := nil; tb := nil; kv := nil;
  end;
end;

{ ------------------------------------------------------------------ TESTLER }

procedure T01_Veritabani;
begin
  Grp('Veritabani komutlari (CREATE/DROP/LIST DATABASE)');
  UseDir('ana');
  Chk('CREATE DATABASE satis', 'CREATE DATABASE satis', -1);
  ChkErr('CREATE DATABASE var olan (hata)',
      'CREATE DATABASE satis');
  Chk('CREATE DATABASE IF NOT EXISTS (sessiz)',
      'CREATE DATABASE IF NOT EXISTS satis', -1);
  R := sq.Exec('LIST DATABASES');
  Ok('LIST DATABASES calisti', IntToStr(R.Affected) + ' veritabani');
  R := sq.Exec('SHOW DATABASES');
  Ok('SHOW DATABASES = LIST', IntToStr(R.Affected));
  ChkErr('DROP DATABASE etkini silemez', 'DROP DATABASE ana');
  Chk('DROP DATABASE satis', 'DROP DATABASE satis', -1);
  Chk('DROP DATABASE IF EXISTS (yok)', 'DROP DATABASE IF EXISTS satis', -1);
  ChkErr('DROP DATABASE olmayan (hata)', 'DROP DATABASE satis');
  ChkErr('veritabani adi yol ayirici (hata)',
      'CREATE DATABASE ' + Q + 'a\b' + Q);
  ChkErr('veritabani adi .. (hata)', 'CREATE DATABASE ' + Q + '..' + Q);
end;

procedure T02_Tipler;
begin
  Grp('Veri tipleri (INTEGER/FLOAT/TEXT/BOOL/DATE/DATETIME/TIME/BLOB)');
  UseDir('tip');
  sq.Exec('CREATE TABLE tip(id INTEGER PRIMARY KEY, i INTEGER, f FLOAT, ' +
          's TEXT, b BOOLEAN, d DATE, dt DATETIME, tm TIME, bl BLOB)');
  Chk('hepsine bir satir', 'INSERT INTO tip(i,f,s,b,d,dt,tm,bl) VALUES(' +
      '42, 3.5, ' + Q + 'merhaba' + Q + ', 1, ' + Q + '2024-01-15' + Q + ', ' +
      Q + '2024-01-15 10:30:00' + Q + ', ' + Q + '10:30:00' + Q + ', ' +
      Q + 'binary' + Q + ')', -1);
  ChkVal('INTEGER saklanir', 'SELECT i FROM tip', 0, 0, '42');
  ChkVal('FLOAT saklanir', 'SELECT f FROM tip', 0, 0, '3.5');
  ChkVal('TEXT saklanir', 'SELECT s FROM tip', 0, 0, 'merhaba');
  ChkVal('BOOLEAN saklanir', 'SELECT b FROM tip', 0, 0, 'True');
  ChkVal('DATE saklanir', 'SELECT d FROM tip', 0, 0, '2024-01-15');
  ChkVal('DATETIME saklanir', 'SELECT dt FROM tip', 0, 0, '2024-01-15 10:30:00');
  ChkVal('TIME saklanir', 'SELECT tm FROM tip', 0, 0, '10:30:00');
  ChkVal('BLOB saklanir', 'SELECT bl FROM tip', 0, 0, 'binary');
  ChkErr('INTEGER kolona metin (hata)',
      'INSERT INTO tip(i) VALUES(' + Q + 'abc' + Q + ')');
  ChkErr('DATE kolona bozuk tarih (hata)',
      'INSERT INTO tip(d) VALUES(' + Q + 'abc' + Q + ')');
  // Locale bagimsizlik: sistem tr-TR (ondalik ayirici = virgul) ama motor
  // daima NOKTA kullanir. Aksi halde "VALUES(0,5)" 4 deger sanilir ve
  // sessizce yanlis satir yazilir.
  sq.Exec('CREATE TABLE fl(id INTEGER PRIMARY KEY, f FLOAT)');
  sq.Exec('INSERT INTO fl(f) VALUES(2.25)');
  ChkVal('FLOAT nokta ile okunur (locale bagimsiz)', 'SELECT f FROM fl', 0, 0, '2.25');
  sq.Exec('INSERT INTO fl(f) VALUES(10)');
  ChkVal('FLOAT tam sayi', 'SELECT f FROM fl WHERE id=2', 0, 0, '10');
  ChkVal('FLOAT karsilastirma', 'SELECT COUNT(*) FROM fl WHERE f > 2', 0, 0, '2');
  ChkErr('ondalik VIRGUL deger ayirici sayilmaz (hata)',
      'INSERT INTO fl(id,f) VALUES(9,0,5)');
end;

procedure T03_CreateKisit;
begin
  Grp('CREATE TABLE kisitlari (PK/NOT NULL/UNIQUE/DEFAULT/CHECK/FK)');
  UseDir('kis');
  sq.Exec('CREATE TABLE ebeveyn(id INTEGER PRIMARY KEY, ad TEXT NOT NULL)');
  ChkErr('NOT NULL ihlali (hata)',
      'INSERT INTO ebeveyn(id,ad) VALUES(1,' + Q + Q + ')');
  Chk('gecerli satir', 'INSERT INTO ebeveyn(id,ad) VALUES(1,' + Q + 'Ali' + Q + ')', -1);
  ChkErr('PK tekrari (hata)',
      'INSERT INTO ebeveyn(id,ad) VALUES(1,' + Q + 'Veli' + Q + ')');
  sq.Exec('CREATE TABLE cocuk(id INTEGER PRIMARY KEY, pid INTEGER ' +
          'REFERENCES ebeveyn(id), yas INTEGER DEFAULT 0, ' +
          'puan FLOAT, etiket TEXT UNIQUE)');
  Chk('FK dogru deger', 'INSERT INTO cocuk(id,pid) VALUES(1,1)', -1);
  ChkErr('FK yanlis deger (hata)', 'INSERT INTO cocuk(id,pid) VALUES(2,99)');
  Chk('DEFAULT uygulandi', 'INSERT INTO cocuk(id) VALUES(2)', -1);
  ChkVal('DEFAULT degeri yazildi', 'SELECT yas FROM cocuk WHERE id=2', 0, 0, '0');
  Chk('UNIQUE ilk kullanim',
      'INSERT INTO cocuk(id,etiket) VALUES(3,' + Q + 'x' + Q + ')', -1);
  ChkErr('UNIQUE tekrari 2 (hata)',
      'INSERT INTO cocuk(id,etiket) VALUES(4,' + Q + 'x' + Q + ')');
  sq.Exec('CREATE TABLE yasli(id INTEGER PRIMARY KEY, y INTEGER, ' +
          'CHECK (y >= 0))');
  Chk('CHECK gecer', 'INSERT INTO yasli(id,y) VALUES(1,10)', -1);
  ChkErr('CHECK ihlali (hata)', 'INSERT INTO yasli(id,y) VALUES(2,-1)');
  sq.Exec('CREATE TABLE tek(id INTEGER PRIMARY KEY, v INTEGER CHECK (v > 0))');
  ChkErr('kolon ici CHECK (hata)', 'INSERT INTO tek(id,v) VALUES(1,0)');
end;

procedure T04_Insert;
begin
  Grp('INSERT bicimleri');
  UseDir('ins');
  sq.Exec('CREATE TABLE t(id INTEGER PRIMARY KEY, a TEXT, b INTEGER, ' +
          'c TEXT DEFAULT ' + Q + 'varsayilan' + Q + ')');
  Chk('sutun listeli', 'INSERT INTO t(a,b) VALUES(' + Q + 'x' + Q + ',1)', -1);
  Chk('sutun listesiz (sirayla)', 'INSERT INTO t VALUES(2,' + Q + 'y' + Q +
      ',2,' + Q + 'z' + Q + ')', -1);
  Chk('bos liste + bos VALUES (DEFAULT)',
      'INSERT INTO t() VALUES()', -1);
  Chk('DEFAULT VALUES kisayol', 'INSERT INTO t DEFAULT VALUES', -1);
  Chk('NULL deger', 'INSERT INTO t(a,b) VALUES(NULL,NULL)', -1);
  ChkErr('olmayan sutun (hata)',
      'INSERT INTO t(olmayan) VALUES(1)');
  ChkErr('deger sayisi uymaz (hata)',
      'INSERT INTO t(a,b) VALUES(' + Q + 'q' + Q + ')');
  Chk('5 satir yazildi', 'SELECT COUNT(*) FROM t', 1);
  R := sq.Exec('SELECT COUNT(*) FROM t');
  ChkVal('sayim dogru', 'SELECT COUNT(*) FROM t', 0, 0, '5');
  ChkVal('NULL okundu', 'SELECT a FROM t WHERE id=5', 0, 0, '');
end;

procedure T05_SelectTemel;
begin
  Grp('SELECT: yildiz, kolon listesi, alias, ORDER BY, LIMIT/OFFSET');
  UseDir('sel');
  sq.Exec('CREATE TABLE t(id INTEGER PRIMARY KEY, ad TEXT, yas INTEGER)');
  sq.Exec('INSERT INTO t(ad,yas) VALUES(' + Q + 'Ali' + Q + ',30)');
  sq.Exec('INSERT INTO t(ad,yas) VALUES(' + Q + 'Veli' + Q + ',20)');
  sq.Exec('INSERT INTO t(ad,yas) VALUES(' + Q + 'Zeynep' + Q + ',40)');
  sq.Exec('INSERT INTO t(ad,yas) VALUES(' + Q + 'Ayse' + Q + ',25)');
  Chk('SELECT *', 'SELECT * FROM t', 4);
  Chk('kolon listesi', 'SELECT ad,yas FROM t', 4);
  Chk('ORDER BY ASC', 'SELECT ad FROM t ORDER BY yas', 4);
  ChkVal('ORDER BY ASC ilk', 'SELECT ad FROM t ORDER BY yas', 0, 0, 'Veli');
  ChkVal('ORDER BY DESC ilk', 'SELECT ad FROM t ORDER BY yas DESC', 0, 0, 'Zeynep');
  Chk('coklu ORDER BY', 'SELECT ad FROM t ORDER BY yas ASC, ad DESC', 4);
  Chk('LIMIT 2', 'SELECT ad FROM t ORDER BY yas LIMIT 2', 2);
  ChkVal('LIMIT ilk kayit', 'SELECT ad FROM t ORDER BY yas LIMIT 2', 0, 0, 'Veli');
  Chk('LIMIT + OFFSET', 'SELECT ad FROM t ORDER BY yas LIMIT 2 OFFSET 1', 2);
  ChkVal('OFFSET kaydi', 'SELECT ad FROM t ORDER BY yas LIMIT 2 OFFSET 1', 0, 0, 'Ayse');
  Chk('OFFSET tek basina', 'SELECT ad FROM t ORDER BY yas OFFSET 3', 1);
  R := sq.Exec('SELECT ad AS isim FROM t ORDER BY id');
  Ok('AS alias', R.Fields[0] + ' = ' + R.Rows[0][0]);
  R := sq.Exec('SELECT ad isim2 FROM t ORDER BY id');
  Ok('AS`siz alias', R.Fields[0] + ' = ' + R.Rows[0][0]);
  Chk('tablo alias', 'SELECT x.ad FROM t x ORDER BY x.id', 4);
  ChkErr('olmayan tablo (hata)', 'SELECT * FROM yok');
  ChkErr('olmayan kolon (hata)', 'SELECT yok FROM t');
end;

procedure T06_Where;
begin
  Grp('WHERE operatorleri, AND/OR/parantez, LIKE, IS NULL');
  UseDir('whr');
  sq.Exec('CREATE TABLE t(id INTEGER PRIMARY KEY, ad TEXT, yas INTEGER, ' +
          'email TEXT)');
  sq.Exec('INSERT INTO t(ad,yas,email) VALUES(' + Q + 'Ali' + Q + ',30,' + Q + 'ali@x.com' + Q + ')');
  sq.Exec('INSERT INTO t(ad,yas,email) VALUES(' + Q + 'Veli' + Q + ',20,' + Q + 'veli@y.com' + Q + ')');
  sq.Exec('INSERT INTO t(ad,yas,email) VALUES(' + Q + 'Zeynep' + Q + ',40,NULL)');
  Chk('=', 'SELECT ad FROM t WHERE yas = 30', 1);
  Chk('<>', 'SELECT ad FROM t WHERE yas <> 30', 2);
  Chk('!=', 'SELECT ad FROM t WHERE yas != 30', 2);
  Chk('<', 'SELECT ad FROM t WHERE yas < 30', 1);
  Chk('>', 'SELECT ad FROM t WHERE yas > 30', 1);
  Chk('<=', 'SELECT ad FROM t WHERE yas <= 30', 2);
  Chk('>=', 'SELECT ad FROM t WHERE yas >= 30', 2);
  Chk('AND', 'SELECT ad FROM t WHERE yas > 20 AND yas < 35', 1);
  Chk('OR', 'SELECT ad FROM t WHERE yas = 20 OR yas = 40', 2);
  Chk('parentez', 'SELECT ad FROM t WHERE yas = 20 OR (yas > 30 AND yas < 35)', 1);
  Chk('LIKE %', 'SELECT ad FROM t WHERE ad LIKE ' + Q + 'A%' + Q, 1);
  Chk('LIKE % orta', 'SELECT ad FROM t WHERE email LIKE ' + Q + '%@y.com' + Q, 1);
  Chk('LIKE tam', 'SELECT ad FROM t WHERE ad LIKE ' + Q + 'Ali' + Q, 1);
  Chk('IS NULL', 'SELECT ad FROM t WHERE email IS NULL', 1);
  Chk('IS NOT NULL', 'SELECT ad FROM t WHERE email IS NOT NULL', 2);
  Chk('NULL = ile eslesmez', 'SELECT ad FROM t WHERE email = NULL', 0);
  Chk('NULL <> ile eslesmez', 'SELECT ad FROM t WHERE email <> NULL', 0);
  Chk('NULL LIKE ile eslesmez', 'SELECT ad FROM t WHERE email LIKE ' + Q + '%' + Q, 2);
  Chk('metin karsilastirma', 'SELECT ad FROM t WHERE ad = ' + Q + 'Ali' + Q, 1);
  ChkErr('olmayan operator (hata)', 'SELECT ad FROM t WHERE yas =~~ 3');
end;

procedure T07_TipKarsilastirma;
begin
  Grp('Tip-bilgili karsilastirma (TEXT 007 != 7)');
  UseDir('tipk');
  sq.Exec('CREATE TABLE t(id INTEGER PRIMARY KEY, s TEXT, n INTEGER)');
  sq.Exec('INSERT INTO t(s,n) VALUES(' + Q + '007' + Q + ',7)');
  sq.Exec('INSERT INTO t(s,n) VALUES(' + Q + '7' + Q + ',007)');
  Chk('TEXT: s = 7 (tirnaksiz literal = metin ' + Q + '7' + Q + ')',
      'SELECT s FROM t WHERE s = 7', 1);
  Chk('TEXT: ' + Q + '007' + Q + ' = ' + Q + '007' + Q,
      'SELECT s FROM t WHERE s = ' + Q + '007' + Q, 1);
  Chk('INTEGER: n = ' + Q + '007' + Q + ' (iki satirda da 7)',
      'SELECT n FROM t WHERE n = ' + Q + '007' + Q, 2);
  Chk('INTEGER: n = 7 (iki satir)', 'SELECT n FROM t WHERE n = 7', 2);
  Chk('BETWEEN (n=7 -> aralik disi)', 'SELECT s FROM t WHERE n BETWEEN 1 AND 5', 0);
  Chk('BETWEEN (n=7 -> aralik ici)', 'SELECT s FROM t WHERE n BETWEEN 5 AND 9', 2);
  Chk('IN (...) (n=7 -> eslesmez)',
      'SELECT s FROM t WHERE n IN (1,2,3)', 0);
  Chk('IN (...) (n=7 -> eslesir)',
      'SELECT s FROM t WHERE n IN (6,7,8)', 2);
  Chk('NOT IN (...)', 'SELECT s FROM t WHERE n NOT IN (1,2,3)', 2);
  Chk('TEXT BETWEEN (byte sirasi: ''007'' < ''7'')',
      'SELECT s FROM t WHERE s BETWEEN ' + Q + '7' + Q + ' AND ' + Q + '8' + Q, 1);
  Chk('TEXT BETWEEN (''007''..''9'' -> ikisi de)',
      'SELECT s FROM t WHERE s BETWEEN ' + Q + '007' + Q + ' AND ' + Q + '9' + Q, 2);
  Chk('DISTINCT (007 ve 7 farkli)', 'SELECT DISTINCT s FROM t', 2);
  Chk('DISTINCT n (7 iki kez)', 'SELECT DISTINCT n FROM t', 1);
end;

procedure T08_Join;
begin
  Grp('JOIN: INNER, LEFT, alias, nitelemeli kolon');
  UseDir('jnn');
  sq.Exec('CREATE TABLE eb(id INTEGER PRIMARY KEY, ad TEXT)');
  sq.Exec('CREATE TABLE coc(id INTEGER PRIMARY KEY, ad TEXT, pid INTEGER)');
  sq.Exec('INSERT INTO eb(id,ad) VALUES(1,' + Q + 'Ali' + Q + ')');
  sq.Exec('INSERT INTO eb(id,ad) VALUES(2,' + Q + 'Veli' + Q + ')');
  sq.Exec('INSERT INTO coc(id,ad,pid) VALUES(1,' + Q + 'c1' + Q + ',1)');
  sq.Exec('INSERT INTO coc(id,ad,pid) VALUES(2,' + Q + 'c2' + Q + ',1)');
  sq.Exec('INSERT INTO coc(id,ad,pid) VALUES(3,' + Q + 'c3' + Q + ',2)');
  sq.Exec('INSERT INTO coc(id,ad,pid) VALUES(4,' + Q + 'c4' + Q + ',NULL)');
  Chk('INNER JOIN (3 eslesme)', 'SELECT c.ad FROM coc c INNER JOIN eb ON c.pid = eb.id', 3);
  Chk('JOIN = INNER JOIN', 'SELECT c.ad FROM coc c JOIN eb ON c.pid = eb.id', 3);
  Chk('LEFT JOIN (4 satir)', 'SELECT c.ad FROM coc c LEFT JOIN eb ON c.pid = eb.id', 4);
  ChkVal('LEFT JOIN eslesmeyen NULL',
      'SELECT c.ad, eb.ad FROM coc c LEFT JOIN eb ON c.pid = eb.id ORDER BY c.id', 3, 1, '');
  Chk('aliasli JOIN + WHERE', 'SELECT c.ad FROM coc c JOIN eb e ON c.pid = e.id ' +
      'WHERE e.ad = ' + Q + 'Ali' + Q, 2);
  Chk('nitelemeli kolon', 'SELECT coc.ad FROM coc JOIN eb ON coc.pid = eb.id', 3);
  Chk('coklu JOIN kosulu yerine ON+WHERE',
      'SELECT c.ad FROM coc c JOIN eb ON c.pid = eb.id WHERE c.id > 1', 2);
  ChkErr('3 tablo JOIN desteklenmiyor (hata)',
      'SELECT c.ad FROM coc c JOIN eb ON c.pid = eb.id JOIN coc c2 ON c2.pid = eb.id');
  Chk('ORDER BY + LIMIT JOIN',
      'SELECT c.ad FROM coc c JOIN eb ON c.pid = eb.id ORDER BY c.id LIMIT 1', 1);
end;

procedure T09_GroupAggregate;
begin
  Grp('GROUP BY + aggregate (COUNT/SUM/AVG/MIN/MAX)');
  UseDir('grp');
  sq.Exec('CREATE TABLE p(id INTEGER PRIMARY KEY, dept TEXT, maas INTEGER)');
  sq.Exec('INSERT INTO p(dept,maas) VALUES(' + Q + 'yazilim' + Q + ',100)');
  sq.Exec('INSERT INTO p(dept,maas) VALUES(' + Q + 'yazilim' + Q + ',200)');
  sq.Exec('INSERT INTO p(dept,maas) VALUES(' + Q + 'yazilim' + Q + ',300)');
  sq.Exec('INSERT INTO p(dept,maas) VALUES(' + Q + 'satis' + Q + ',150)');
  sq.Exec('INSERT INTO p(dept,maas) VALUES(' + Q + 'satis' + Q + ',250)');
  ChkVal('COUNT(*)', 'SELECT COUNT(*) FROM p', 0, 0, '5');
  ChkVal('COUNT(dept)', 'SELECT COUNT(dept) FROM p', 0, 0, '5');
  ChkVal('SUM', 'SELECT SUM(maas) FROM p', 0, 0, '1000');
  ChkVal('AVG', 'SELECT AVG(maas) FROM p', 0, 0, '200');
  ChkVal('MIN', 'SELECT MIN(maas) FROM p', 0, 0, '100');
  ChkVal('MAX', 'SELECT MAX(maas) FROM p', 0, 0, '300');
  Chk('GROUP BY 2 grup', 'SELECT dept, COUNT(*) FROM p GROUP BY dept', 2);
  ChkVal('GROUP BY SUM', 'SELECT dept, SUM(maas) FROM p GROUP BY dept ' +
      'ORDER BY dept', 0, 1, '400');
  ChkVal('coklu kolon GROUP BY',
      'SELECT dept, maas, COUNT(*) FROM p GROUP BY dept, maas', 0, 2, '1');
  ChkVal('aggregate + WHERE', 'SELECT COUNT(*) FROM p WHERE maas > 150', 0, 0, '3');
  ChkErr('HAVING desteklenmiyor (hata)',
      'SELECT dept, COUNT(*) FROM p GROUP BY dept HAVING COUNT(*) > 1');
  ChkErr('artik token sessizce yutulmaz (hata)',
      'SELECT dept FROM p WHERE maas > 1 BLA BLA');
end;

procedure T10_Update;
begin
  Grp('UPDATE');
  UseDir('upd');
  sq.Exec('CREATE TABLE ebeveyn(id INTEGER PRIMARY KEY)');
  sq.Exec('INSERT INTO ebeveyn(id) VALUES(1)');
  sq.Exec('CREATE TABLE t(id INTEGER PRIMARY KEY, ad TEXT UNIQUE, ' +
          'yas INTEGER, pid INTEGER REFERENCES ebeveyn(id), ' +
          'puan INTEGER CHECK (puan >= 0))');
  sq.Exec('INSERT INTO t(ad,yas,pid) VALUES(' + Q + 'a' + Q + ',1,1)');
  sq.Exec('INSERT INTO t(ad,yas,pid) VALUES(' + Q + 'b' + Q + ',2,1)');
  Chk('WHERE ile tek', 'UPDATE t SET yas = 99 WHERE id = 1', -1);
  ChkVal('guncellendi', 'SELECT yas FROM t WHERE id=1', 0, 0, '99');
  Chk('WHERE ile cok', 'UPDATE t SET yas = 50 WHERE yas > 10', -1);
  Chk('WHERE yoksa tumu', 'UPDATE t SET yas = 7', -1);
  ChkVal('tum satirlar guncellendi', 'SELECT yas FROM t WHERE id=1', 0, 0, '7');
  Chk('coklu SET', 'UPDATE t SET ad = ' + Q + 'z' + Q + ', yas = 1 WHERE id = 1', -1);
  Chk('NULL yazma', 'UPDATE t SET yas = NULL WHERE id = 1', -1);
  ChkVal('NULL yazildi', 'SELECT yas FROM t WHERE id=1', 0, 0, '');
  ChkErr('CHECK ihlali UPDATE (hata)', 'UPDATE t SET puan = -5 WHERE id = 1');
  ChkErr('FK ihlali UPDATE (hata)', 'UPDATE t SET pid = 77 WHERE id = 1');
  Chk('gecerli FK UPDATE', 'UPDATE t SET pid = 1 WHERE id = 1', -1);
  ChkErr('UNIQUE ihlali UPDATE (hata)',
      'UPDATE t SET ad = ' + Q + 'z' + Q + ' WHERE id = 2');
end;

procedure T11_Delete;
begin
  Grp('DELETE');
  UseDir('del');
  sq.Exec('CREATE TABLE eb(id INTEGER PRIMARY KEY)');
  sq.Exec('CREATE TABLE coc(id INTEGER PRIMARY KEY, pid INTEGER ' +
          'REFERENCES eb(id))');
  sq.Exec('INSERT INTO eb(id) VALUES(1)');
  sq.Exec('INSERT INTO coc(id,pid) VALUES(1,1)');
  sq.Exec('INSERT INTO coc(id) VALUES(2)');
  sq.Exec('CREATE TABLE t(id INTEGER PRIMARY KEY, v INTEGER)');
  sq.Exec('INSERT INTO t(v) VALUES(1)');
  sq.Exec('INSERT INTO t(v) VALUES(2)');
  sq.Exec('INSERT INTO t(v) VALUES(3)');
  Chk('WHERE ile tek', 'DELETE FROM t WHERE id = 1', -1);
  ChkVal('kalan satir', 'SELECT COUNT(*) FROM t', 0, 0, '2');
  Chk('WHERE ile cok', 'DELETE FROM t WHERE v > 1', -1);
  ChkVal('kalan satir 2', 'SELECT COUNT(*) FROM t', 0, 0, '0');
  ChkErr('FK RESTRICT silemez (hata)', 'DELETE FROM eb WHERE id = 1');
  Chk('NULL FK ile silinebilir', 'DELETE FROM coc WHERE id = 2', -1);
  sq.Exec('INSERT INTO t(v) VALUES(9)');
  Chk('WHERE yoksa tumu', 'DELETE FROM t', -1);
  ChkVal('tablo bos', 'SELECT COUNT(*) FROM t', 0, 0, '0');
end;

procedure T12_Transaction;
begin
  Grp('Transaction: COMMIT / ROLLBACK, DDL dahil');
  UseDir('trn');
  sq.Exec('CREATE TABLE t(id INTEGER PRIMARY KEY, a TEXT)');
  sq.Exec('INSERT INTO t(a) VALUES(' + Q + 'ilk' + Q + ')');
  Chk('BEGIN', 'BEGIN', -1);
  Chk('batch icinde INSERT', 'INSERT INTO t(a) VALUES(' + Q + 'gizli' + Q + ')', -1);
  Chk('batch icinde SELECT gorunur',
      'SELECT a FROM t WHERE a = ' + Q + 'gizli' + Q, 1);
  ChkVal('batch icinde UPDATE gorunur',
      'SELECT a FROM t WHERE id = 1', 0, 0, 'ilk');
  Chk('ROLLBACK', 'ROLLBACK', -1);
  Chk('rollback: eklenen yok',
      'SELECT a FROM t WHERE a = ' + Q + 'gizli' + Q, 0);
  ChkVal('rollback: eski veri duruyor', 'SELECT COUNT(*) FROM t', 0, 0, '1');
  Chk('BEGIN 2', 'BEGIN', -1);
  sq.Exec('INSERT INTO t(a) VALUES(' + Q + 'kalici' + Q + ')');
  Chk('COMMIT', 'COMMIT', -1);
  ChkVal('commit: veri duruyor', 'SELECT COUNT(*) FROM t', 0, 0, '2');
  Chk('BEGIN 3 (DDL)', 'BEGIN', -1);
  Chk('batch icinde CREATE TABLE', 'CREATE TABLE gecici(id INTEGER PRIMARY KEY)', -1);
  sq.Exec('INSERT INTO gecici(id) VALUES(1)');
  Chk('ROLLBACK DDL', 'ROLLBACK', -1);
  ChkErr('rollback sonrasi tablo yok (hata)', 'SELECT * FROM gecici');
  ChkVal('rollback sonrasi veri saglam', 'SELECT COUNT(*) FROM t', 0, 0, '2');
  Chk('BEGIN 4 (ALTER)', 'BEGIN', -1);
  Chk('batch icinde ALTER', 'ALTER TABLE t ADD yeni INTEGER', -1);
  Chk('ROLLBACK ALTER', 'ROLLBACK', -1);
  ChkErr('rollback sonrasi kolon yok (hata)', 'SELECT yeni FROM t');
end;

procedure T13_AlterTable;
begin
  Grp('ALTER TABLE');
  UseDir('alt');
  sq.Exec('CREATE TABLE t(id INTEGER PRIMARY KEY, a TEXT, b INTEGER)');
  sq.Exec('INSERT INTO t(a,b) VALUES(' + Q + 'Ali' + Q + ',1)');
  sq.Exec('INSERT INTO t(a,b) VALUES(' + Q + 'Veli' + Q + ',2)');
  Chk('ADD COLUMN', 'ALTER TABLE t ADD c TEXT', -1);
  ChkVal('veri korundu', 'SELECT a FROM t ORDER BY id', 0, 0, 'Ali');
  ChkVal('yeni sutun NULL', 'SELECT c FROM t ORDER BY id', 0, 0, '');
  Chk('ADD COLUMN FIRST', 'ALTER TABLE t ADD ilk TEXT FIRST', -1);
  Chk('ADD COLUMN AFTER', 'ALTER TABLE t ADD sonra TEXT AFTER a', -1);
  ChkErr('var olan kolon (hata)', 'ALTER TABLE t ADD a TEXT');
  ChkErr('olmayan kolon (hata)', 'ALTER TABLE t ADD x TEXT AFTER yok');
  Chk('DROP COLUMN', 'ALTER TABLE t DROP c', -1);
  ChkVal('veri hala duruyor', 'SELECT a FROM t ORDER BY id', 0, 0, 'Ali');
  Chk('RENAME COLUMN', 'ALTER TABLE t RENAME COLUMN a TO isim', -1);
  ChkVal('yeni adiyle okunur', 'SELECT isim FROM t ORDER BY id', 0, 0, 'Ali');
  ChkErr('eski ad yok (hata)', 'SELECT a FROM t');
  ChkErr('PK kolonu dusurulemez (hata)', 'ALTER TABLE t DROP id');
  Chk('ALTER COLUMN TYPE', 'ALTER TABLE t ALTER COLUMN b TYPE TEXT', -1);
  Chk('TEXT kolona her sey yazilabilir', 'UPDATE t SET b = ' + Q + 'zzz' + Q, -1);
  ChkErr('TEXT -> INTEGER donusturulemez (hata)',
      'ALTER TABLE t ALTER COLUMN b TYPE INTEGER');
  Chk('bozuk degeri duzelt', 'UPDATE t SET b = ' + Q + '5' + Q, -1);
  Chk('ALTER COLUMN INTEGER a donus', 'ALTER TABLE t ALTER COLUMN b TYPE INTEGER', -1);
  Chk('ALTER COLUMN SET DEFAULT', 'ALTER TABLE t ALTER COLUMN b SET DEFAULT 9', -1);
  Chk('ALTER COLUMN DROP DEFAULT', 'ALTER TABLE t ALTER COLUMN b DROP DEFAULT', -1);
  Chk('ALTER COLUMN SET NOT NULL', 'ALTER TABLE t ALTER COLUMN b SET NOT NULL', -1);
  Chk('ALTER COLUMN DROP NOT NULL', 'ALTER TABLE t ALTER COLUMN b DROP NOT NULL', -1);
  ChkErr('PK NOT NULL kaldirilamaz (hata)',
      'ALTER TABLE t ALTER COLUMN id DROP NOT NULL');
  Chk('RENAME TO', 'ALTER TABLE t RENAME TO tablo2', -1);
  ChkVal('yeni tablo adiyle veri', 'SELECT isim FROM tablo2 ORDER BY id', 0, 0, 'Ali');
  ChkErr('eski tablo adi yok (hata)', 'SELECT * FROM t');
end;

procedure T14_Index;
begin
  Grp('Index: CREATE / kullanim / DROP');
  UseDir('idx');
  sq.Exec('CREATE TABLE t(id INTEGER PRIMARY KEY, ad TEXT UNIQUE, v INTEGER)');
  sq.Exec('INSERT INTO t(ad,v) VALUES(' + Q + 'a' + Q + ',1)');
  sq.Exec('INSERT INTO t(ad,v) VALUES(' + Q + 'b' + Q + ',2)');
  sq.Exec('CREATE INDEX ix_v ON t(v)');
  ChkVal('indexli = arama', 'SELECT ad FROM t WHERE v = 2', 0, 0, 'b');
  Chk('indexli > arama', 'SELECT ad FROM t WHERE v > 0 ORDER BY v', 2);
  Chk('indexli aralik', 'SELECT ad FROM t WHERE v >= 1 AND v <= 2', 2);
  Chk('indexli <> ', 'SELECT ad FROM t WHERE v <> 1', 1);
  Chk('PK indexli arama', 'SELECT ad FROM t WHERE id = 1', 1);
  Chk('DROP INDEX', 'DROP INDEX ix_v', -1);
  ChkVal('indexsiz de ayni sonuc', 'SELECT ad FROM t WHERE v = 2', 0, 0, 'b');
  ChkErr('olmayan index DROP (hata)', 'DROP INDEX ix_yok');
end;

procedure T15_Bakim;
begin
  Grp('Bakim: SHOW TABLES / VACUUM / REINDEX');
  UseDir('bak');
  sq.Exec('CREATE TABLE t1(id INTEGER PRIMARY KEY, a TEXT)');
  sq.Exec('CREATE TABLE t2(id INTEGER PRIMARY KEY, b INTEGER)');
  sq.Exec('INSERT INTO t1(a) VALUES(' + Q + 'x' + Q + ')');
  R := sq.Exec('SHOW TABLES');
  Ok('SHOW TABLES', IntToStr(R.Affected) + ' tablo');
  if Length(R.Rows) > 0 then
  begin
    WriteLn('        ', R.Rows[0][0], ' = ', R.Rows[0][1], ' satir, ',
            R.Rows[1][0], ' = ', R.Rows[1][1], ' satir');
  end;
  Chk('CREATE INDEX sonra REINDEX', 'CREATE INDEX ix ON t1(a)', -1);
  Chk('REINDEX', 'REINDEX', -1);
  ChkVal('REINDEX sonrasi arama', 'SELECT a FROM t1 WHERE a = ' + Q + 'x' + Q, 0, 0, 'x');
  sq.Exec('INSERT INTO t1(a) VALUES(' + Q + 'y' + Q + ')');
  sq.Exec('INSERT INTO t1(a) VALUES(' + Q + 'z' + Q + ')');
  sq.Exec('DELETE FROM t1 WHERE a = ' + Q + 'y' + Q);
  R := sq.Exec('VACUUM');
  Ok('VACUUM', R.Msg);
  ChkVal('VACUUM sonrasi veri', 'SELECT COUNT(*) FROM t1', 0, 0, '2');
end;

procedure T16_Parametreli;
var p: array of string;
begin
  Grp('Parametreli SQL (?)');
  UseDir('prm');
  sq.Exec('CREATE TABLE t(id INTEGER PRIMARY KEY, ad TEXT, yas INTEGER)');
  SetLength(p, 2); p[0] := 'Ali'; p[1] := '30';
  R := sq.Exec('INSERT INTO t(ad,yas) VALUES(?,?)', p);
  if R.Affected = 1 then Ok('INSERT 2 parametre', '') else No('INSERT 2 parametre', 'affected=' + IntToStr(R.Affected));
  SetLength(p, 2); p[0] := 'Veli'; p[1] := '20';
  R := sq.Exec('INSERT INTO t(ad,yas) VALUES(?,?)', p);
  if R.Affected = 1 then Ok('INSERT 2 parametre 2', '') else No('INSERT 2 parametre 2', '');
  R := sq.Exec('SELECT yas FROM t WHERE ad = ?', ['Ali']);
  if (Length(R.Rows) = 1) and (R.Rows[0][0] = '30') then Ok('WHERE ?', R.Rows[0][0])
  else No('WHERE ?', 'sonuc ' + IntToStr(Length(R.Rows)));
  R := sq.Exec('UPDATE t SET yas = ? WHERE ad = ?', ['31', 'Ali']);
  if R.Affected = 1 then Ok('UPDATE 2 parametre', '') else No('UPDATE 2 parametre', '');
  R := sq.Exec('DELETE FROM t WHERE ad = ?', ['Veli']);
  if R.Affected = 1 then Ok('DELETE 1 parametre', '') else No('DELETE 1 parametre', '');
  R := sq.Exec('SELECT COUNT(*) FROM t');
  if (Length(R.Rows) = 1) and (R.Rows[0][0] = '1') then Ok('kalan satir', R.Rows[0][0])
  else No('kalan satir', '');
  ChkErr('fazla parametre yok (hata)', 'SELECT * FROM t WHERE ad = ?');
end;

procedure T17_Json;
var f: string;
begin
  Grp('EXPORT / IMPORT JSON');
  UseDir('jsn');
  f := D + '\jsn\yedek.json';
  sq.Exec('CREATE TABLE eb(id INTEGER PRIMARY KEY)');
  sq.Exec('CREATE TABLE t(id INTEGER PRIMARY KEY, ad TEXT, pid INTEGER ' +
          'REFERENCES eb(id), CHECK (id > 0))');
  sq.Exec('INSERT INTO eb(id) VALUES(1)');
  sq.Exec('INSERT INTO t(ad,pid) VALUES(' + Q + 'Ali' + Q + ',1)');
  sq.Exec('INSERT INTO t(ad,pid) VALUES(' + Q + 'Veli' + Q + ',1)');
  sq.Exec('EXPORT JSON ' + Q + f + Q);
  if FileExists(f) then Ok('EXPORT JSON', 'dosya yazildi') else No('EXPORT JSON', 'dosya yok');
  ChkErr('olmayan tablo EXPORT (hata)',
      'EXPORT TABLE yok JSON ' + Q + D + '\jsn\x.json' + Q);
  // yeni bos db'ye aktar
  UseDir('jsn2');
  sq.Exec('IMPORT JSON ' + Q + f + Q);
  ChkVal('IMPORT: sema geldi', 'SELECT COUNT(*) FROM t', 0, 0, '2');
  ChkVal('IMPORT: veri geldi', 'SELECT ad FROM t ORDER BY id', 0, 0, 'Ali');
  ChkErr('IMPORT sonrasi FK korunuyor (hata)',
      'INSERT INTO t(id,ad,pid) VALUES(9,' + Q + 'x' + Q + ',99)');
  ChkErr('IMPORT sonrasi CHECK korunuyor (hata)',
      'INSERT INTO t(id,ad) VALUES(-1,' + Q + 'x' + Q + ')');
end;

procedure T18_Kalici;
begin
  Grp('Disk kaliciligi: kapat + yeniden ac');
  UseDir('kal');
  sq.Exec('CREATE TABLE t(id INTEGER PRIMARY KEY, a TEXT, n INTEGER DEFAULT 5)');
  sq.Exec('INSERT INTO t(a) VALUES(' + Q + 'kalici' + Q + ')');
  sq.Exec('CREATE INDEX ix ON t(a)');
  sq.Exec('ALTER TABLE t ADD ek TEXT');
  UseDir('kal');   // ayni klasoru yeniden ac
  ChkVal('sema korundu', 'SELECT a FROM t', 0, 0, 'kalici');
  ChkVal('veri korundu', 'SELECT COUNT(*) FROM t', 0, 0, '1');
  R := sq.Exec('SELECT a FROM t WHERE a = ' + Q + 'kalici' + Q);
  if Length(R.Rows) = 1 then Ok('index kalici', '') else No('index kalici', '');
  ChkVal('ALTER kolon kalici', 'SELECT ek FROM t', 0, 0, '');
  ChkVal('DEFAULT kalici', 'SELECT n FROM t', 0, 0, '5');
end;

procedure T19_Olcek;
var i: Integer;
begin
  Grp('Olcek: 1000 satir + index aralama');
  UseDir('big');
  sq.Exec('CREATE TABLE t(id INTEGER PRIMARY KEY, v INTEGER, s TEXT)');
  for i := 1 to 1000 do
  begin
    R := sq.Exec('INSERT INTO t(v,s) VALUES(' + IntToStr(i) + ',' +
        Q + 'satir' + IntToStr(i) + Q + ')');
  end;
  ChkVal('1000 satir yazildi', 'SELECT COUNT(*) FROM t', 0, 0, '1000');
  sq.Exec('CREATE INDEX ix_v ON t(v)');
  ChkVal('PK arama', 'SELECT s FROM t WHERE id = 500', 0, 0, 'satir500');
  ChkVal('index = arama', 'SELECT s FROM t WHERE v = 777', 0, 0, 'satir777');
  ChkVal('index > arama', 'SELECT COUNT(*) FROM t WHERE v > 990', 0, 0, '10');
  ChkVal('index aralik', 'SELECT COUNT(*) FROM t WHERE v >= 100 AND v <= 199', 0, 0, '100');
  Chk('tam tarama', 'SELECT COUNT(*) FROM t', 1);
  Chk('ORDER BY + LIMIT', 'SELECT s FROM t ORDER BY v DESC LIMIT 1', 1);
  ChkVal('ORDER BY DESC ilk', 'SELECT s FROM t ORDER BY v DESC LIMIT 1', 0, 0, 'satir1000');
  R := sq.Exec('VACUUM');
  Ok('buyuk veride VACUUM', R.Msg);
  ChkVal('VACUUM sonrasi 1000 satir', 'SELECT COUNT(*) FROM t', 0, 0, '1000');
end;

{ -------------------------------------------------- 20) coklu kayit / coklu komut }
procedure T20_CokluKayit;
begin
  Grp('Coklu kayit (VALUES (...),(...)) + coklu komut (";")');
  UseDir('coklu');
  // Kullanicinin tipik kullanimi: 5 kolonlu tablo, 8 satirlik VALUES.
  Chk('CREATE TABLE (5 kolon)',
      'CREATE TABLE personel (ad TEXT, unvan TEXT, sehir TEXT, ' +
      'departman TEXT, maas FLOAT)', -1);
  try
    r := sq.Exec('INSERT INTO personel (ad,unvan,sehir,departman,maas) VALUES' +
      ' (' + Q + 'Mehmet' + Q + ',' + Q + 'Yonetici' + Q + ',' + Q + 'Istanbul' + Q + ',yazilim,9200),' +
      ' (' + Q + 'Samet' + Q + ',' + Q + 'Uzman' + Q + ',' + Q + 'Ankara' + Q + ',finans,4800),' +
      ' (' + Q + 'Kenan' + Q + ',' + Q + 'Yonetici' + Q + ',' + Q + 'Istanbul' + Q + ',yazilim,9700),' +
      ' (' + Q + 'Veli' + Q + ',' + Q + 'Uzman' + Q + ',' + Q + 'Izmir' + Q + ',satis,5200),' +
      ' (' + Q + 'Deli' + Q + ',' + Q + 'Yonetici' + Q + ',' + Q + 'Ankara' + Q + ',finans,9100),' +
      ' (' + Q + 'Can' + Q + ',' + Q + 'Uzman' + Q + ',' + Q + 'Istanbul' + Q + ',finans,5400),' +
      ' (' + Q + 'Selim' + Q + ',' + Q + 'Uzman' + Q + ',' + Q + 'Istanbul' + Q + ',finans,5500),' +
      ' (' + Q + 'Nihat' + Q + ',' + Q + 'Yonetici' + Q + ',' + Q + 'Izmir' + Q + ',yazilim,8700)');
    ChkVal('Affected = 8 satir', 'SELECT COUNT(*) FROM personel', 0, 0, '8');
    ChkInt('Stmts = 1 (tek komut, coklu grup)', r.Stmts, 1);
  except on E: Exception do No('8 satirlik VALUES', '(' + E.Message + ')'); end;
  Chk('8 satir listelenir', 'SELECT ad FROM personel', 8);
  ChkVal('1. kayit', 'SELECT ad FROM personel WHERE maas = 9200', 0, 0, 'Mehmet');
  ChkVal('2. kayit', 'SELECT ad FROM personel WHERE maas = 4800', 0, 0, 'Samet');
  ChkVal('3. kayit', 'SELECT ad FROM personel WHERE maas = 9700', 0, 0, 'Kenan');
  ChkVal('4. kayit', 'SELECT ad FROM personel WHERE maas = 5200', 0, 0, 'Veli');
  ChkVal('5. kayit', 'SELECT ad FROM personel WHERE maas = 9100', 0, 0, 'Deli');
  ChkVal('6. kayit', 'SELECT ad FROM personel WHERE maas = 5400', 0, 0, 'Can');
  ChkVal('7. kayit', 'SELECT ad FROM personel WHERE maas = 5500', 0, 0, 'Selim');
  ChkVal('8. kayit', 'SELECT ad FROM personel WHERE maas = 8700', 0, 0, 'Nihat');
  Chk('ORDER BY maas', 'SELECT ad FROM personel ORDER BY maas', 8);
  ChkVal('ORDER BY maas ilk', 'SELECT ad FROM personel ORDER BY maas', 0, 0, 'Samet');
  Chk('LIMIT 3', 'SELECT ad FROM personel ORDER BY maas LIMIT 3', 3);
  Chk('OFFSET 5 LIMIT 3', 'SELECT ad FROM personel ORDER BY maas LIMIT 3 OFFSET 5', 3);

  Chk('yardimci tablo', 'CREATE TABLE t(id INTEGER PRIMARY KEY, a INTEGER, b TEXT)', -1);
  Chk('2 deger grubu', 'INSERT INTO t(id,a,b) VALUES (1,1,' + Q + 'x' + Q + '),(2,2,' + Q + 'y' + Q + ')', -1);
  Chk('3 deger grubu', 'INSERT INTO t(id,a,b) VALUES (3,3,' + Q + 'p' + Q + '),(4,4,' + Q + 'q' + Q + '),(5,5,' + Q + 'r' + Q + ')', -1);
  ChkVal('5 satir', 'SELECT COUNT(*) FROM t', 0, 0, '5');
  ChkErr('gruplar arasinda deger sayisi farki', 'INSERT INTO t(id,a,b) VALUES (6,6,' + Q + 'z' + Q + '),(7)');
  ChkVal('hatali grup sonrasi yazilmedi', 'SELECT COUNT(*) FROM t', 0, 0, '5');
  Chk('DEFAULT VALUES coklu', 'INSERT INTO t DEFAULT VALUES, DEFAULT VALUES', -1);
  ChkVal('7 satir', 'SELECT COUNT(*) FROM t', 0, 0, '7');
  ChkErr('artik token yutulmaz', 'INSERT INTO t(id,a,b) VALUES (9,9,' + Q + 'z' + Q + ') BLA');
  Chk('INSERT INTO t() VALUES(),()', 'INSERT INTO t() VALUES (), ()', -1);
  ChkVal('9 satir', 'SELECT COUNT(*) FROM t', 0, 0, '9');

  // Atomiklik: 3. grup ihlalli -> hicbiri yazilmaz
  Chk('atomik tablo', 'CREATE TABLE k(id INTEGER PRIMARY KEY, v INTEGER NOT NULL)', -1);
  Chk('ilk satir', 'INSERT INTO k(id,v) VALUES (1,1)', -1);
  ChkErr('3. grup NOT NULL ihlali', 'INSERT INTO k(id,v) VALUES (2,2),(3,3),(4,NULL)');
  ChkVal('yarim yazma yok', 'SELECT COUNT(*) FROM k', 0, 0, '1');
  ChkErr('PK cakismasi -> hicbiri yazilmaz', 'INSERT INTO k(id,v) VALUES (5,5),(1,9)');
  ChkVal('cakisma sonrasi degismez', 'SELECT COUNT(*) FROM k', 0, 0, '1');
  Chk('dogru 2 grup', 'INSERT INTO k(id,v) VALUES (2,2),(3,3)', -1);
  ChkVal('3 satir', 'SELECT COUNT(*) FROM k', 0, 0, '3');

  // INSERT INTO ... SELECT
  Chk('kaynak tablo', 'CREATE TABLE src(id INTEGER PRIMARY KEY, ad TEXT)', -1);
  Chk('src coklu kayit', 'INSERT INTO src(ad) VALUES (' + Q + 'a' + Q + '),(' + Q + 'b' + Q + '),(' + Q + 'c' + Q + ')', -1);
  Chk('hedef tablo', 'CREATE TABLE dst(id INTEGER PRIMARY KEY, ad TEXT)', -1);
  Chk('INSERT INTO dst SELECT', 'INSERT INTO dst(id,ad) SELECT id,ad FROM src', -1);
  ChkVal('3 satir kopyalandi', 'SELECT COUNT(*) FROM dst', 0, 0, '3');
  ChkVal('veri dogru', 'SELECT ad FROM dst WHERE id = 2', 0, 0, 'b');
  ChkErr('sutun sayisi uyusmaz', 'INSERT INTO dst(id,ad) SELECT id FROM src');

  // ";" ile coklu komut
  try
    r := sq.Exec('INSERT INTO t(id,a,b) VALUES (11,1,' + Q + 'c1' + Q + ');' +
                 'INSERT INTO t(id,a,b) VALUES (12,2,' + Q + 'c2' + Q + ');' +
                 'INSERT INTO t(id,a,b) VALUES (13,3,' + Q + 'c3' + Q + ')');
    ChkInt('3 komut islendi', r.Stmts, 3);
    ChkInt('Affected toplam 3', r.Affected, 3);
    if r.LastTable = 't' then Ok('LastTable = t', r.LastTable)
    else No('LastTable = t', 'gelen: ' + r.LastTable);
  except on E: Exception do No('3 komut', '(' + E.Message + ')'); end;
  ChkVal('12 satir', 'SELECT COUNT(*) FROM t', 0, 0, '12');
  ChkVal('son satir gorunur', 'SELECT b FROM t WHERE id = 13', 0, 0, 'c3');
  ChkVal('tirnak icindeki ; bolunmez', 'SELECT ' + Q + 'a;b' + Q + ' AS x', 0, 0, 'a;b');
  Chk('tirnakli deger ; olarak kalir',
      'INSERT INTO t(id,a,b) VALUES (14,4,' + Q + 'p;q' + Q + ')', -1);
  ChkVal('deger oldugu gibi', 'SELECT b FROM t WHERE id = 14', 0, 0, 'p;q');
  ChkErr('hatali cumle betigi durdurur',
      'INSERT INTO t(id,a,b) VALUES (15,5,' + Q + 'zz' + Q + '); SELECT YANLIS');
  ChkVal('hata OLURSA HICBIR CUMLE UYGULANMAZ (otomatik transaction)', 'SELECT COUNT(*) FROM t', 0, 0, '13');

  // FROM'suz SELECT
  ChkVal('SELECT 1', 'SELECT 1', 0, 0, '1');
  ChkVal('SELECT ''abc'' AS x', 'SELECT ' + Q + 'abc' + Q + ' AS x', 0, 0, 'abc');
  ChkVal('SELECT NULL, 2.5', 'SELECT NULL, 2.5', 0, 1, '2.5');
  ChkErr('FROM''suz SELECT''ta kolon kullanilamaz', 'SELECT 1, b FROM t');

  // Tam zincir: CREATE + INSERT + UPDATE + DELETE tek betikte
  Chk('zincir betigi',
      'BEGIN;' +
      'CREATE TABLE z(id INTEGER PRIMARY KEY, v TEXT);' +
      'INSERT INTO z(id,v) VALUES (1,' + Q + 'a' + Q + '),(2,' + Q + 'b' + Q + ');' +
      'UPDATE z SET v = ' + Q + 'c' + Q + ' WHERE id = 2;' +
      'DELETE FROM z WHERE id = 2;' +
      'COMMIT;', -1);
  ChkVal('z icinde 1 satir', 'SELECT COUNT(*) FROM z', 0, 0, '1');
  ChkVal('z degeri', 'SELECT v FROM z', 0, 0, 'a');
end;

procedure T21_KritikHataDogrulama;
var
  rep: string;
  okv: Boolean;
  kColl: QWord;
  rawB: TBytes;
begin
  Grp('Kritik Hata Duzeltmeleri (Verify Akis Tamponu & Hash Carpismasi)');
  Fresh('kritik');
  // 1. TVDb.Verify akis tamponu: veritabani dolu iken uninitialized tampon hatasi olmadan dogrulanmali
  sq.Exec('CREATE TABLE t(id INTEGER PRIMARY KEY, v TEXT)');
  sq.Exec('INSERT INTO t(id, v) VALUES(1, ' + Q + 'veri1' + Q + '),(2, ' + Q + 'veri2' + Q + ')');
  okv := kv.Verify(rep);
  if okv then Ok('TVDb.Verify akis tamponu ile dogrulandi', rep)
  else No('TVDb.Verify akis tamponu basarisiz', rep);

  // SQL uzerinden VERIFY calistirma
  R := sq.Exec('VERIFY');
  if R.Affected = 1 then Ok('SQL VERIFY komutu', R.Msg)
  else No('SQL VERIFY komutu basarisiz', R.Msg);

  // 2. Hash carpismasi guvenligi:
  sq.Exec('CREATE TABLE diger(id INTEGER PRIMARY KEY, v TEXT)');
  sq.Exec('CREATE TABLE cocuk(id INTEGER PRIMARY KEY, pid INTEGER REFERENCES diger(id))');
  kColl := VDbHashKey('diger', '999');
  if kv.Get(VDbHashKey('t', '1'), rawB) then
  begin
    kv.Put(kColl, rawB); // 'diger' tablosundaki PK 999 anahtari altinda 't' tablosunun row verisi var

    // a) FK denetimi sentetik carpismayi yakalamali (baska tablonun row'unu kabul etmemeli)
    ChkErr('FK carpismada yalanci eslesme yapmaz', 'INSERT INTO cocuk(id, pid) VALUES(1, 999)');

    // b) INSERT yapilirken var olan carpismali veri sessizce ezilmemeli, hata firlatmali
    ChkErr('INSERT hash carpismasini tespit eder', 'INSERT INTO diger(id, v) VALUES(999, ' + Q + 'yeni' + Q + ')');
  end;
end;

{ ---------------------------------------------------------------------- main }

var
  arg: string;
  tmp: string;
begin
  nPass := 0; nFail := 0; nGrp := 0;
  sq := nil; tb := nil; kv := nil;
  if (ParamCount >= 1) and (Trim(ParamStr(1)) <> '') then
  begin
    D := ParamStr(1);
    ForceDirectories(D);
  end
  else
  begin
    tmp := GetTempDir(False) + 'vdbsqltest_' + FormatDateTime('yyyymmdd_hhnnss', Now);
    ForceDirectories(tmp);
    D := tmp;
  end;
  WriteLn('VDB SQL tam testi');
  WriteLn('Klasor: ', D);
  try
    try
      T01_Veritabani;
      T02_Tipler;
      T03_CreateKisit;
      T04_Insert;
      T05_SelectTemel;
      T06_Where;
      T07_TipKarsilastirma;
      T08_Join;
      T09_GroupAggregate;
      T10_Update;
      T11_Delete;
      T12_Transaction;
      T13_AlterTable;
      T14_Index;
      T15_Bakim;
      T16_Parametreli;
      T17_Json;
      T18_Kalici;
      T19_Olcek;
      T20_CokluKayit;
      T21_KritikHataDogrulama;
    except
      on E: Exception do
      begin
        Inc(nFail);
        WriteLn;
        WriteLn('!! KESILDI (', grpName, '): ', E.ClassName, ': ', E.Message);
      end;
    end;
  finally
    Shutdown;
  end;
  WriteLn;
  WriteLn('================================================');
  WriteLn('SONUC: gecen=', nPass, '  kalan=', nFail);
  if nFail = 0 then WriteLn('TUM SQL TESTLERI GECTI')
  else WriteLn('HATA VAR');
end.
