# VDB Motor v2 — Dokumantasyon

## Motor Yapisi (Yonetime Bagimsiz)

| Birim | Rol | Durum |
|---|---|---|
| `VDbCore.pas` | Dusuk seviye motor (`.odb` append-only) | ✅ `WAL` hook (`WriteAheadWAL`, `ReplayWAL`, `CheckpointWAL`, `HasWAL`) |
| `VDbWal.pas` | `WAL` birimi (`.wal` dosyasi) | ✅ `Motor` klasorunde (`D:\veritabani\`) |
| `VDbTable.pas` | Tablo katmani (`PutRow` `WAL` entegre) | ✅ `FKv.WriteAheadWAL()` cagri |
| `VDbSql.pas` | SQL parser / executor | ✅ `Mevcut` (`Kopya` dosyasi silinmedi) |
| `VDbAst.pas` | AST (SQL) | ✅ |
| `VDbJson.pas` | JSON disari / iceri | ✅ |
| `VDbCrc32.pas` | CRC32 | ✅ |

---

## `.odb` Dosya Formati (`v2` — Bozulmadan)

```
[Header: 16 byte]
  Magic (4) = $42444F56 ('VODB' LE)
  Ver   (4) = 2 (VDB_FILE_VER)
  Flags (4) = 0 (varsayilan) | ENCRYPTED(4) | COMPRESSED(8)
  Crc   (4) = Header CRC32
[Kilitler: Append-Only]
  Magic (4) = $56444231
  Crc   (4) = Kayit CRC32
  Seq   (8) = Sira numarasi
  Key   (8) = Anahtar (UInt64)
  ValLen(4) = Veri uzunlugu
  Flags (1) = 0(PUT) | 1(DEL) | 2(BATCHEND)
  Value (ValLen byte)
```

---

## `WAL` (`Sifir Veri Kaybi`)

```
WAL dosyasi: .odb ile ayni klasorde (.odb -> .wal)
Yazma:  WriteAheadWAL(Key, Value, VDB_FLAG_PUT) -> .wal
Commit: ReplayWAL() -> .wal -> .odb uygula
Temiz: CheckpointWAL() -> .wal sil
Durum: HasWAL() -> Boolean
```

---

## `Faz D`: Motor Yenilikleri (`Iskelet`)

| Ozellik | `Flags` / `Durum` | `Acilama` |
|---|---|---|
| `Encryption` | `VDB_FLAG_ENCRYPTED = 4` | `AES` (`Value` sifreli) — `Iskelet` (`True/False`) |
| `Compression` | `VDB_FLAG_COMPRESSED = 8` | `ZLIB` (`Value` sikistirilmis) — `Iskelet` |
| `Streaming` | `StreamCursor(StartKey, PageSize)` | `Pagination` (`O(1)` `Cursor`, `Memory` `OOM` onler) — `Iskelet` |
| `AutoBackup` | `AutoBackup(BackupDir)` | `Timer` tabanli `.bak` (`FPath` `.auto.bak`) — `Iskelet` |
| `Memory-Mapped` | `MMF` (`Windows` `mmap`) | `Zero-Copy` (`Read` `2-5x` hizli) — `Iskelet` |
| `Query Planner` | `VDbSql.pas` (`Plan` `Cost-Based`) | `Index Scan` vs `Table Scan` — `Iskelet` (`VDbAst.pas` bagli) |

---

## `Test` (`Satis.odb` — `135 byte`) -> `Uretim` (`Veritabani.odb` — `370 KB`)

```
Test dosyasi: D:\veritabani\db\satis.odb (135 byte)
Uretim:     D:\veritabani\db\veritabani.odb (379168 byte = 370 KB)
WAL:        D:\veritabani\VDbWal.pas (motor seviyesinde)
Yonetim:    D:\veritabani\yonetim\ (GUI - WAL'dan bagimsiz)
```

---

## `Derleme` (`Build`)

```
Derleme: C:\lazarus\lazbuild.exe D:\veritabani\yonetim\had.lpi
Son durum: 19087 lines compiled, Exit: True (Faz D Temiz)
```
