unit VDbExecutor;

{ VDb SQL AST Yurutucusu (Executor)  - Faz 2 Adim 2.2
  AST cumle dugumlerini (TSqlStmtNode) TVTableDb uzerinde calistirir ve
  TSqlResult sonuc nesnesini uretir.

  Ozellikler:
  * EvalExpr: tam tip-bilgili ifade degerlendirici (literal, kolon, ikili/tekli
    op, IN, BETWEEN, COUNT/SUM/AVG/MIN/MAX fonksiyon cagrilari)
  * ExecSelect: WHERE filtreleme, ORDER BY (cok sutun, ASC/DESC),
    LIMIT/OFFSET, DISTINCT, GROUP BY + HAVING, toplama fonksiyonlari,
    INNER/LEFT JOIN, UNION/UNION ALL/EXCEPT/INTERSECT
  * ExecInsert: cok satirli VALUES + INSERT ... SELECT
  * ExecUpdate: AST WHERE ile filtreli guncelleme (Delete+ReInsert)
  * ExecDelete: AST WHERE ile filtreli silme
  * DDL (CREATE/ALTER/DROP TABLE, CREATE/DROP INDEX)
  * TX (BEGIN/COMMIT/ROLLBACK), Admin (VERIFY/VACUUM/REINDEX), JSON
}

{$mode delphi}

interface

uses
  Classes, SysUtils, Math, Generics.Collections,
  VDbCore, VDbTable, VDbAst, VDbJson;

type
  TByteArray = array of Byte;

  TVSqlExecutor = class
  private
    FT: TVTableDb;

    { ---------- Expression Evaluator ---------- }
    function EvalExpr(Expr: TSqlExprNode; const Row: TStrArray;
      const ColNames: TStrArray; const ColTypes: TByteArray): string;
    function EvalBool(Expr: TSqlExprNode; const Row: TStrArray;
      const ColNames: TStrArray; const ColTypes: TByteArray): Boolean;
    function EvalBinary(AOp: TSqlBinaryOp; const LeftVal, RightVal: string;
      Ctype: Byte): string;
    function EvalUnary(AOp: TSqlUnaryOp; const Val: string): string;

    { ---------- Yardimcilar ---------- }
    procedure BuildColInfo(const td: TTableDef; out ColNames: TStrArray;
      out ColTypes: TByteArray);
    function RowMatches(WhereClause: TSqlExprNode; const Row: TStrArray;
      const ColNames: TStrArray; const ColTypes: TByteArray): Boolean;
    procedure DoSort(var Rows: TStrMatrix; const Keys: TStrArray;
      OrderBy: TList<TOrderItem>;
      const ColNames: TStrArray; const ColTypes: TByteArray);
    function HasAggregate(Stmt: TSqlSelectStmt): Boolean;
    { ---------- Satir adaylarini DARALTMA (tam tarama oncesi) ----------
      WHERE AST'sinden PK nokta aramasi veya indeks dilimi cikarir.
      False donerse cagri tam tarama yapar.
      DONUMLERIN TAMAMI RowMatches ile yeniden dogrulanir; dilim yalnizca
      UST KUMEDIR, bu yuzden sonuc hicbir kosulda degismez. }
    function NarrowRows(const Td: TTableDef; WhereClause: TSqlExprNode;
      const ColNames: TStrArray; const ColTypes: TByteArray;
      out Pks: TStrArray; out Rows: TStrMatrix): Boolean;
    { ORDER BY tek kolon ve bu kolon indeksliyse, satirlar INDeks sirasiyla
      okunur; OFFSET/LIMIT erken uygulanir. "ORDER BY n LIMIT 10" 100.000
      satirlik tabloda ~900 ms yerine ~0 ms surer.
      False donerse normal (tam tarama + siralama) yol kullanilir. }
    function TryIndexOrder(const Td: TTableDef; Stmt: TSqlSelectStmt;
      const ColNames: TStrArray; const ColTypes: TByteArray;
      out Rows: TStrMatrix): Boolean;
    procedure ExecGroupBy(Stmt: TSqlSelectStmt; const AllPks: TStrArray;
      const AllRows: TStrMatrix; const ColNames: TStrArray;
      const ColTypes: TByteArray; out Res: TSqlResult);
    procedure ExecJoinScan(Stmt: TSqlSelectStmt; out MergedRows: TStrMatrix;
      out MergedColNames: TStrArray; out MergedColTypes: TByteArray);

    { ---------- Statement Handlers ---------- }
    procedure ExecSelect(Stmt: TSqlSelectStmt; out Res: TSqlResult);
    procedure ExecInsert(Stmt: TSqlInsertStmt; out Res: TSqlResult);
    procedure ExecUpdate(Stmt: TSqlUpdateStmt; out Res: TSqlResult);
    procedure ExecDelete(Stmt: TSqlDeleteStmt; out Res: TSqlResult);
    procedure ExecCreateTable(Stmt: TSqlCreateTableStmt; out Res: TSqlResult);
    procedure ExecAlterTable(Stmt: TSqlAlterTableStmt; out Res: TSqlResult);
    procedure ExecDropTable(Stmt: TSqlDropTableStmt; out Res: TSqlResult);
    procedure ExecCreateIndex(Stmt: TSqlCreateIndexStmt; out Res: TSqlResult);
    procedure ExecDropIndex(Stmt: TSqlDropIndexStmt; out Res: TSqlResult);
    procedure ExecTx(Stmt: TSqlTxStmt; out Res: TSqlResult);
    procedure ExecAdmin(Stmt: TSqlAdminStmt; out Res: TSqlResult);
    procedure ExecJson(Stmt: TSqlJsonStmt; out Res: TSqlResult);
  public
    constructor Create(ATableDb: TVTableDb);
    function Execute(Stmt: TSqlStmtNode): TSqlResult;
    property TableDb: TVTableDb read FT;
  end;

implementation

type
  { FPC'de TList<TList<T>> desteklenmedigi icin yardimci alt sinif }
  TIntList = class(TList<Integer>)
  end;
  TIntListList = TList<TIntList>;

{ ============================================================
  Yardimci: string dizisi esit mi?
  ============================================================ }
function SameStrArr(const A, B: TStrArray): Boolean;
var i: Integer;
begin
  if Length(A) <> Length(B) then Exit(False);
  for i := 0 to High(A) do
    if A[i] <> B[i] then Exit(False);
  Result := True;
end;

{ ============================================================
  TVSqlExecutor
  ============================================================ }

constructor TVSqlExecutor.Create(ATableDb: TVTableDb);
begin
  inherited Create;
  FT := ATableDb;
end;

{ ------------------------------------------------------------
  BuildColInfo
  ------------------------------------------------------------ }
procedure TVSqlExecutor.BuildColInfo(const td: TTableDef;
  out ColNames: TStrArray; out ColTypes: TByteArray);
var i: Integer;
begin
  SetLength(ColNames, Length(td.Cols));
  SetLength(ColTypes, Length(td.Cols));
  for i := 0 to High(td.Cols) do
  begin
    ColNames[i] := td.Cols[i].Name;
    ColTypes[i] := td.Cols[i].Ctype;
  end;
end;

{ ------------------------------------------------------------
  EvalBinary
  ------------------------------------------------------------ }
function TVSqlExecutor.EvalBinary(AOp: TSqlBinaryOp; const LeftVal, RightVal: string;
  Ctype: Byte): string;
var
  ia, ib: Int64;
  fa, fb: Double;
  bRes: Boolean;
begin
  case AOp of
    sboAdd, sboSub, sboMul, sboDiv, sboMod:
      begin
        if (LeftVal = '') or (RightVal = '') then Exit('');
        if (Ctype = VCT_FLOAT) or (Pos('.', LeftVal) > 0) or (Pos('.', RightVal) > 0) then
        begin
          if not VDbParseFloat(LeftVal, fa) or not VDbParseFloat(RightVal, fb) then Exit('');
          case AOp of
            sboAdd: Exit(VDbFloatToStr(fa + fb));
            sboSub: Exit(VDbFloatToStr(fa - fb));
            sboMul: Exit(VDbFloatToStr(fa * fb));
            sboDiv:
              begin
                if fb = 0.0 then raise Exception.Create('Sifira bolme hatasi');
                Exit(VDbFloatToStr(fa / fb));
              end;
            sboMod: raise Exception.Create('FLOAT tipte modulo kullanilamaz');
          end;
        end
        else
        begin
          if not VDbParseInt(LeftVal, ia) or not VDbParseInt(RightVal, ib) then Exit('');
          case AOp of
            sboAdd: Exit(IntToStr(ia + ib));
            sboSub: Exit(IntToStr(ia - ib));
            sboMul: Exit(IntToStr(ia * ib));
            sboDiv:
              begin
                if ib = 0 then raise Exception.Create('Sifira bolme hatasi');
                Exit(IntToStr(ia div ib));
              end;
            sboMod:
              begin
                if ib = 0 then raise Exception.Create('Sifira bolme hatasi');
                Exit(IntToStr(ia mod ib));
              end;
          end;
        end;
      end;
    sboAnd:
      begin
        bRes := (SameText(LeftVal, 'True') or (LeftVal = '1')) and
                (SameText(RightVal, 'True') or (RightVal = '1'));
        if bRes then Exit('True') else Exit('False');
      end;
    sboOr:
      begin
        bRes := (SameText(LeftVal, 'True') or (LeftVal = '1')) or
                (SameText(RightVal, 'True') or (RightVal = '1'));
        if bRes then Exit('True') else Exit('False');
      end;
    sboEq:   bRes := VDbCmpVal(LeftVal, RightVal, '=', Ctype);
    sboNeq:  bRes := VDbCmpVal(LeftVal, RightVal, '<>', Ctype);
    sboLt:   bRes := VDbCmpVal(LeftVal, RightVal, '<', Ctype);
    sboLte:  bRes := VDbCmpVal(LeftVal, RightVal, '<=', Ctype);
    sboGt:   bRes := VDbCmpVal(LeftVal, RightVal, '>', Ctype);
    sboGte:  bRes := VDbCmpVal(LeftVal, RightVal, '>=', Ctype);
    sboLike: begin if (LeftVal = '') or (RightVal = '') then bRes := False else bRes := VDbLikeMatch(LeftVal, RightVal); end;
  else
    bRes := False;
  end;
  if bRes then Result := 'True' else Result := 'False';
end;

{ ------------------------------------------------------------
  EvalUnary
  ------------------------------------------------------------ }
function TVSqlExecutor.EvalUnary(AOp: TSqlUnaryOp; const Val: string): string;
var
  iVal: Int64;
  fVal: Double;
  b: Boolean;
begin
  case AOp of
    suoNot:
      begin
        b := SameText(Val, 'True') or (Val = '1');
        if not b then Result := 'True' else Result := 'False';
      end;
    suoNeg:
      begin
        if Val = '' then Exit('');
        if VDbParseInt(Val, iVal) then Result := IntToStr(-iVal)
        else if VDbParseFloat(Val, fVal) then Result := VDbFloatToStr(-fVal)
        else Result := Val;
      end;
    suoIsNull:    if Val = '' then Result := 'True' else Result := 'False';
    suoIsNotNull: if Val <> '' then Result := 'True' else Result := 'False';
  else
    Result := Val;
  end;
end;

{ ------------------------------------------------------------
  EvalExpr
  ------------------------------------------------------------ }
function TVSqlExecutor.EvalExpr(Expr: TSqlExprNode; const Row: TStrArray;
  const ColNames: TStrArray; const ColTypes: TByteArray): string;
var
  lit: TSqlLiteralNode;
  colRef: TSqlColumnRefNode;
  bin: TSqlBinaryOpNode;
  un: TSqlUnaryOpNode;
  inN: TSqlInNode;
  bt: TSqlBetweenNode;
  fn: TSqlFuncCallNode;
  lv, rv, itemVal: string;
  ct: Byte;
  idx, i: Integer;
  matched: Boolean;
  fa: Double;
  ia: Int64;
begin
  if Expr = nil then Exit('');

  if Expr is TSqlLiteralNode then
  begin
    lit := TSqlLiteralNode(Expr);
    Exit(lit.AsString);
  end;

  if Expr is TSqlColumnRefNode then
  begin
    colRef := TSqlColumnRefNode(Expr);
    if (Row = nil) or (Length(ColNames) = 0) then
      Exit(colRef.ColumnName);
    idx := -1;
    for i := 0 to High(ColNames) do
    begin
      if Pos('.', ColNames[i]) > 0 then
      begin
        // Nitelemeli kolon adi (alias.col veya tablo.col)
        if (colRef.TableQualifier <> '') and
           SameText(colRef.QualifiedName, ColNames[i]) then
        begin idx := i; Break; end;
        // Nitelemesiz ref: sonek eslemesi (ad -> coc.ad)
        if (colRef.TableQualifier = '') and
           SameText(colRef.ColumnName, Copy(ColNames[i], Pos('.', ColNames[i]) + 1, MaxInt)) then
        begin idx := i; Break; end;
      end
      else if SameText(colRef.ColumnName, ColNames[i]) then
      begin idx := i; Break; end;
    end;
    if (idx >= 0) and (idx < Length(Row)) then Exit(Row[idx])
    else raise Exception.Create('Kolon bulunamadi: ' + colRef.QualifiedName);
  end;

  if Expr is TSqlBinaryOpNode then
  begin
    bin := TSqlBinaryOpNode(Expr);
    lv := EvalExpr(bin.Left, Row, ColNames, ColTypes);
    rv := EvalExpr(bin.Right, Row, ColNames, ColTypes);
    ct := VCT_STR;
    if bin.Left is TSqlColumnRefNode then
    begin
      colRef := TSqlColumnRefNode(bin.Left);
      for i := 0 to High(ColNames) do
        if SameText(colRef.ColumnName, ColNames[i]) and (i < Length(ColTypes)) then
        begin ct := ColTypes[i]; Break; end;
    end;
    Exit(EvalBinary(bin.Op, lv, rv, ct));
  end;

  if Expr is TSqlUnaryOpNode then
  begin
    un := TSqlUnaryOpNode(Expr);
    lv := EvalExpr(un.Operand, Row, ColNames, ColTypes);
    Exit(EvalUnary(un.Op, lv));
  end;

  if Expr is TSqlInNode then
  begin
    inN := TSqlInNode(Expr);
    lv := EvalExpr(inN.Expr, Row, ColNames, ColTypes);
    if lv = '' then Exit('False');
    matched := False;
    for i := 0 to inN.List.Count - 1 do
    begin
      itemVal := EvalExpr(inN.List[i], Row, ColNames, ColTypes);
      if itemVal = lv then begin matched := True; Break; end;
    end;
    if inN.IsNot then matched := not matched;
    if matched then Exit('True') else Exit('False');
  end;

  if Expr is TSqlBetweenNode then
  begin
    bt := TSqlBetweenNode(Expr);
    lv := EvalExpr(bt.Expr, Row, ColNames, ColTypes);
    if lv = '' then Exit('False');
    ct := VCT_STR;
    if bt.Expr is TSqlColumnRefNode then
    begin
      colRef := TSqlColumnRefNode(bt.Expr);
      for i := 0 to High(ColNames) do
        if SameText(colRef.ColumnName, ColNames[i]) and (i < Length(ColTypes)) then
        begin ct := ColTypes[i]; Break; end;
    end;
    matched := VDbCmpVal(lv, EvalExpr(bt.LowBound, Row, ColNames, ColTypes), '>=', ct) and
               VDbCmpVal(lv, EvalExpr(bt.HighBound, Row, ColNames, ColTypes), '<=', ct);
    if bt.IsNot then matched := not matched;
    if matched then Exit('True') else Exit('False');
  end;

  if Expr is TSqlFuncCallNode then
  begin
    fn := TSqlFuncCallNode(Expr);
    if fn.IsStar then Exit('1');
    lv := EvalExpr(fn.Arg, Row, ColNames, ColTypes);
    if fn.FuncName = 'UPPER' then Exit(UpperCase(lv))
    else if fn.FuncName = 'LOWER' then Exit(LowerCase(lv))
    else if fn.FuncName = 'LENGTH' then Exit(IntToStr(Length(lv)))
    else if fn.FuncName = 'ABS' then
    begin
      if VDbParseFloat(lv, fa) then Exit(VDbFloatToStr(Abs(fa)))
      else if VDbParseInt(lv, ia) then Exit(IntToStr(Abs(ia)))
      else Exit(lv);
    end
    else if fn.FuncName = 'COALESCE' then
    begin
      if lv <> '' then Exit(lv) else Exit('');
    end
    else Exit(lv); // COUNT/SUM/AVG/MIN/MAX: ExecGroupBy'da degerlendirilir
  end;

  Result := '';
end;

{ ------------------------------------------------------------
  EvalBool
  ------------------------------------------------------------ }
function TVSqlExecutor.EvalBool(Expr: TSqlExprNode; const Row: TStrArray;
  const ColNames: TStrArray; const ColTypes: TByteArray): Boolean;
var s: string;
begin
  if Expr = nil then Exit(True);
  s := EvalExpr(Expr, Row, ColNames, ColTypes);
  Result := SameText(s, 'True') or (s = '1');
end;

{ ------------------------------------------------------------
  RowMatches
  ------------------------------------------------------------ }
function TVSqlExecutor.RowMatches(WhereClause: TSqlExprNode;
  const Row: TStrArray; const ColNames: TStrArray; const ColTypes: TByteArray): Boolean;
begin
  Result := EvalBool(WhereClause, Row, ColNames, ColTypes);
end;

{ ------------------------------------------------------------
  HasAggregate
  ------------------------------------------------------------ }
function HasAggregateExpr(E: TSqlExprNode): Boolean;
begin
  if E = nil then Exit(False);
  if E is TSqlFuncCallNode then
  begin
    if (TSqlFuncCallNode(E).FuncName = 'COUNT') or
       (TSqlFuncCallNode(E).FuncName = 'SUM') or
       (TSqlFuncCallNode(E).FuncName = 'AVG') or
       (TSqlFuncCallNode(E).FuncName = 'MIN') or
       (TSqlFuncCallNode(E).FuncName = 'MAX') then Exit(True);
    Exit(HasAggregateExpr(TSqlFuncCallNode(E).Arg));
  end;
  if E is TSqlBinaryOpNode then
    Exit(HasAggregateExpr(TSqlBinaryOpNode(E).Left) or HasAggregateExpr(TSqlBinaryOpNode(E).Right));
  if E is TSqlUnaryOpNode then
    Exit(HasAggregateExpr(TSqlUnaryOpNode(E).Operand));
  Result := False;
end;

function TVSqlExecutor.HasAggregate(Stmt: TSqlSelectStmt): Boolean;
var
  i: Integer;
  fn: TSqlFuncCallNode;
begin
  for i := 0 to Stmt.Columns.Count - 1 do
    if Stmt.Columns[i].Expr is TSqlFuncCallNode then
    begin
      fn := TSqlFuncCallNode(Stmt.Columns[i].Expr);
      if (fn.FuncName = 'COUNT') or (fn.FuncName = 'SUM') or
         (fn.FuncName = 'AVG')   or (fn.FuncName = 'MIN') or
         (fn.FuncName = 'MAX') then Exit(True);
    end;
  if Stmt.HavingClause <> nil then Exit(True);
  Result := False;
end;

{ ============================================================
   NarrowRows - WHERE'den satir adayi daraltma

   SORUN: ExecSelect/ExecUpdate/ExecDelete kosiulsuz olarak
   FT.ScanRows cagirip TUM tabloyu bellege cekiyordu. 100.000 satirlik
   tabloda "WHERE id = 5" bile ~900 ms suruyordu (PK hash ile O(1)
   olmaliydi).

   COZUM: WHERE AST'sinden su iki kaliptan biri cikarilir:
     1) PK kolonunda '='  -> ReadRow ile TEK satir (O(1))
     2) indeksli kolonda '=', '>', '>=', '<', '<=', BETWEEN, IN
        -> indeks dilimi, yalniz o aralik okunur
   Bulunamazsa False doner ve cagri tam tarama yapar.

   GUVENLILIK: dilim yalnizca bir UST KUMEDIR; donen satirlarin tamami
   RowMatches ile yeniden dogrulanir. Bu yuzden "hangi satirlar eslesir"
   sorusunun cevabi degismez - sadece okunacak satir sayisi azalir.
   ============================================================ }

function TVSqlExecutor.NarrowRows(const Td: TTableDef; WhereClause: TSqlExprNode;
  const ColNames: TStrArray; const ColTypes: TByteArray;
  out Pks: TStrArray; out Rows: TStrMatrix): Boolean;
var
  conj: TList<TSqlExprNode>;
  i, ci, lo, hi, l2, h2, n: Integer;
  e: TIdxEntries;
  ct: Byte;
  pkVal: string;
  bestCol: Integer;
  bestLo, bestHi: Integer;
  foundRange: Boolean;
  op: TSqlBinaryOp;
  cr: TSqlColumnRefNode;
  opName: string;
  oneRow: TStrArray;
  nParts: Integer;

  procedure Push(C: TSqlExprNode);
  begin
    if (C is TSqlBinaryOpNode) and (TSqlBinaryOpNode(C).Op = sboAnd) then
    begin
      Push(TSqlBinaryOpNode(C).Left);
      Push(TSqlBinaryOpNode(C).Right);
    end
    else
      conj.Add(C);
  end;

  // Sutun + tek sabit iceren karsilastirmayi "op" adina cevirir.
  function AsSimple(const C: TSqlExprNode; out ColI: Integer;
    out Val: string; out Op: TSqlBinaryOp): Boolean;
  var
    nn: TSqlBinaryOpNode;
    a, b: TSqlColumnRefNode;
    q: Integer;
  begin
    Result := False;
    Op := sboEq; ColI := -1; Val := '';
    if not (C is TSqlBinaryOpNode) then Exit;
    nn := TSqlBinaryOpNode(C);
    if (nn.Op = sboAnd) or (nn.Op = sboOr) or (nn.Op = sboAdd) or
       (nn.Op = sboSub) or (nn.Op = sboMul) or (nn.Op = sboDiv) or
       (nn.Op = sboMod) or (nn.Op = sboLike) then Exit;
    a := nil; b := nil;
    if nn.Left  is TSqlColumnRefNode then a := TSqlColumnRefNode(nn.Left);
    if nn.Right is TSqlColumnRefNode then b := TSqlColumnRefNode(nn.Right);
    if (a <> nil) and (nn.Right is TSqlLiteralNode) then
    begin
      ColI := -1;
      for q := 0 to High(Td.Cols) do
        if VDbNorm(Td.Cols[q].Name) = VDbNorm(a.ColumnName) then
        begin ColI := q; Break; end;
      if ColI < 0 then Exit;
      Val := TSqlLiteralNode(nn.Right).AsString;
      Op := nn.Op;
      Exit(True);
    end;
    if (b <> nil) and (nn.Left is TSqlLiteralNode) then
    begin
      // "5 = a" -> "a = 5" (yansitilmis operator)
      ColI := -1;
      for q := 0 to High(Td.Cols) do
        if VDbNorm(Td.Cols[q].Name) = VDbNorm(b.ColumnName) then
        begin ColI := q; Break; end;
      if ColI < 0 then Exit;
      Val := TSqlLiteralNode(nn.Left).AsString;
      case nn.Op of
        sboEq:  Op := sboEq;
        sboNeq: Op := sboNeq;
        sboLt:  Op := sboGt;
        sboLte: Op := sboGte;
        sboGt:  Op := sboLt;
        sboGte: Op := sboLte;
        else    Exit;
      end;
      Exit(True);
    end;
  end;

begin
  SetLength(Pks, 0);
  SetLength(Rows, 0);
  Result := False;
  if WhereClause = nil then Exit;

  conj := TList<TSqlExprNode>.Create;
  try
    Push(WhereClause);
    if conj.Count = 0 then Exit;

    // --- 1) PK nokta aramasi (en degerli yol) ---
    for i := 0 to conj.Count - 1 do
      if AsSimple(conj[i], ci, pkVal, op) and (ci = Td.PkIndex) and
         (op = sboEq) then
      begin
        if FT.ReadRow(Td.Name, pkVal, oneRow) and
           RowMatches(WhereClause, oneRow, ColNames, ColTypes) then
        begin
          SetLength(Pks, 1);
          SetLength(Rows, 1);
          Pks[0] := pkVal;
          Rows[0] := oneRow;
        end;
        // eslesme yoksa da bos sonuc DONDURULUR: tam tarama gerekmez
        Exit(True);
      end;

    // --- 1b) PK uzerinde IN (...) : her deger icin tek O(1) arama ---
    // (PK'nin bellek indeksi yoktur; kucuk listelerde tek tek okumak
    //  tam taramadan kat kat hizlidir.)
    if Td.PkIndex >= 0 then
      for i := 0 to conj.Count - 1 do
        if (conj[i] is TSqlInNode) and (not TSqlInNode(conj[i]).IsNot) and
           (TSqlInNode(conj[i]).Expr is TSqlColumnRefNode) and
           (TSqlInNode(conj[i]).List.Count <= 512) then
        begin
          ci := -1;
          for n := 0 to High(Td.Cols) do
            if VDbNorm(Td.Cols[n].Name) =
               VDbNorm(TSqlColumnRefNode(TSqlInNode(conj[i]).Expr).ColumnName) then
            begin ci := n; Break; end;
          if ci <> Td.PkIndex then Continue;
          SetLength(Pks, 0);
          SetLength(Rows, 0);
          for n := 0 to TSqlInNode(conj[i]).List.Count - 1 do
          begin
            if not (TSqlInNode(conj[i]).List[n] is TSqlLiteralNode) then Continue;
            pkVal := TSqlLiteralNode(TSqlInNode(conj[i]).List[n]).AsString;
            if FT.ReadRow(Td.Name, pkVal, oneRow) then
            begin
              SetLength(Pks, Length(Pks) + 1);
              SetLength(Rows, Length(Rows) + 1);
              Pks[High(Pks)] := pkVal;
              Rows[High(Rows)] := oneRow;
            end;
          end;
          Exit(True);   // filtre RowMatches ile asagida uygulanir
        end;

    // --- 2) indeks dilimi ---
    bestCol := -1; bestLo := 0; bestHi := 0; foundRange := False;
    for i := 0 to conj.Count - 1 do
    begin
      lo := 0; hi := 0;
      // 2a) basit karsilastirma
      if AsSimple(conj[i], ci, pkVal, op) then
      begin
        opName := '';
        case op of
          sboEq:  opName := '=';
          sboGt:  opName := '>';
          sboGte: opName := '>=';
          sboLt:  opName := '<';
          sboLte: opName := '<=';
        end;
        if opName <> '' then
        begin
          if not FT.TryGetMemIndex(Td.TableId, ci, e) then Continue;
          if not VDbIdxRangeL(e, Td.Cols[ci].Ctype, opName, pkVal, FT.IdxNParts(Td.TableId, ci), lo, hi) then
            Continue;
        end
        else Continue;
      end
      // 2b) BETWEEN a AND b
      else if (conj[i] is TSqlBetweenNode) and
              (not TSqlBetweenNode(conj[i]).IsNot) and
              (TSqlBetweenNode(conj[i]).Expr is TSqlColumnRefNode) and
              (TSqlBetweenNode(conj[i]).LowBound  is TSqlLiteralNode) and
              (TSqlBetweenNode(conj[i]).HighBound is TSqlLiteralNode) then
      begin
        cr := TSqlColumnRefNode(TSqlBetweenNode(conj[i]).Expr);
        ci := -1;
        for n := 0 to High(Td.Cols) do
          if VDbNorm(Td.Cols[n].Name) = VDbNorm(cr.ColumnName) then
          begin ci := n; Break; end;
        if ci < 0 then Continue;
        if not FT.TryGetMemIndex(Td.TableId, ci, e) then Continue;
        ct := Td.Cols[ci].Ctype;
        nParts := FT.IdxNParts(Td.TableId, ci);
        if not VDbIdxRangeL(e, ct, '>=',
             TSqlLiteralNode(TSqlBetweenNode(conj[i]).LowBound).AsString, nParts, l2, h2) then
          Continue;
        lo := l2; hi := Length(e);
        if VDbIdxRangeL(e, ct, '<=',
             TSqlLiteralNode(TSqlBetweenNode(conj[i]).HighBound).AsString, nParts, l2, h2) then
          if h2 < hi then hi := h2;
      end
      // 2c) IN (a, b, c, ...)
      else if (conj[i] is TSqlInNode) and (not TSqlInNode(conj[i]).IsNot) and
              (TSqlInNode(conj[i]).Expr is TSqlColumnRefNode) then
      begin
        cr := TSqlColumnRefNode(TSqlInNode(conj[i]).Expr);
        ci := -1;
        for n := 0 to High(Td.Cols) do
          if VDbNorm(Td.Cols[n].Name) = VDbNorm(cr.ColumnName) then
          begin ci := n; Break; end;
        if (ci < 0) or (TSqlInNode(conj[i]).List.Count = 0) then Continue;
        if not FT.TryGetMemIndex(Td.TableId, ci, e) then Continue;
        ct := Td.Cols[ci].Ctype;
        nParts := FT.IdxNParts(Td.TableId, ci);
        lo := MaxInt; hi := 0;
        for n := 0 to TSqlInNode(conj[i]).List.Count - 1 do
        begin
          if not (TSqlInNode(conj[i]).List[n] is TSqlLiteralNode) then Continue;
          pkVal := TSqlLiteralNode(TSqlInNode(conj[i]).List[n]).AsString;
          // alt sinir: EN KUCUK degerin '>=' baslangici
          if VDbIdxRangeL(e, ct, '>=', pkVal, nParts, l2, h2) then
            if l2 < lo then lo := l2;
          // ust sinir: EN BUYUK degerin '<=' bitisi
          if VDbIdxRangeL(e, ct, '<=', pkVal, nParts, l2, h2) then
            if h2 > hi then hi := h2;
        end;
        if (lo = MaxInt) or (hi = 0) then Continue;
      end
      else Continue;

      // ONEMLI: birden fazla indeks kosulu ancak AYNI KOLONDA ise
      // kesisilir. Farkli kolonlarda kesisim anlamsizdir (iki farkli
      // indeks dizisinin konumlari birbirine denk gelmez) ve hatta
      // dizi sonuna tasmaya yol acardi. Farkli kolonlu kosul yok sayilir;
      // sonuctaki satirlar yine RowMatches ile dogrulanir.
      if foundRange and (ci <> bestCol) then Continue;

      if not foundRange then
      begin
        foundRange := True; bestCol := ci; bestLo := lo; bestHi := hi;
      end
      else
      begin
        if lo > bestLo then bestLo := lo;
        if hi < bestHi then bestHi := hi;
      end;
    end;

    if not foundRange then Exit;   // -> tam tarama
    if bestHi <= bestLo then       // kesim bos
    begin
      Exit(True);                  // 0 satir, tam tarama gerekmez
    end;
    // e dizisini KULLANILACAK kolona bagla (yukaridaki kosullar e'yi
    // degistirmis olabilir)
    if not FT.TryGetMemIndex(Td.TableId, bestCol, e) then Exit;

    SetLength(Pks, bestHi - bestLo);
    SetLength(Rows, bestHi - bestLo);
    n := 0;
    for i := bestLo to bestHi - 1 do
      if FT.ReadRow(Td.Name, e[i].Pk, Rows[n]) then
      begin
        Pks[n] := e[i].Pk;
        Inc(n);
      end;
    SetLength(Pks, n);
    SetLength(Rows, n);
    Result := True;
  finally
    conj.Free;
  end;
end;

function TVSqlExecutor.TryIndexOrder(const Td: TTableDef; Stmt: TSqlSelectStmt;
  const ColNames: TStrArray; const ColTypes: TByteArray;
  out Rows: TStrMatrix): Boolean;
// ORDER BY <indeksli kolon(lar)> -> satirlari indeks sirasiyla oku.
// COK KOLONLU: ORDER BY a, b ile indeksin (a, b) on ek'i eslesiyorsa
// hicbir siralama yapilmaz; satirlar indeks sirasiyla okunur.
var
  e: TIdxEntries;
  ci, lo, hi, l2, h2, i, j, n, off, lim, need: Integer;
  desc: Boolean;
  descAny: Boolean;
  rv: TStrArray;
  cr: TSqlColumnRefNode;
  conj: TList<TSqlExprNode>;
  node: TSqlBinaryOpNode;
  opName: string;
  pkVal: string;
  oCols: TIntArray;      // ORDER BY kolonlari (tablo indeksleri)
  icols: TIntArray;      // indeksin kolonlari
  nIdxCols: Integer;     // indeksin kac kolonu
  leadingMatch: Integer; // ORDER BY'nin indeks on ekiyle eslesen kolon sayisi

  procedure Push(C: TSqlExprNode);
  begin
    if (C is TSqlBinaryOpNode) and (TSqlBinaryOpNode(C).Op = sboAnd) then
    begin
      Push(TSqlBinaryOpNode(C).Left);
      Push(TSqlBinaryOpNode(C).Right);
    end
    else
      conj.Add(C);
  end;

begin
  SetLength(Rows, 0);
  Result := False;
  // Yalniz: JOIN yok, aggregate yok, GROUP BY yok, DISTINCT yok,
  // ORDER BY kolonlari ve hepsi kolon referansi olmali.
  if Stmt.HasJoin or Stmt.IsDistinct then Exit;
  if HasAggregate(Stmt) or (Stmt.GroupByCols.Count > 0) then Exit;
  if (Stmt.OrderBy = nil) or (Stmt.OrderBy.Count = 0) then Exit;
  for i := 0 to Stmt.OrderBy.Count - 1 do
    if not (Stmt.OrderBy[i].Expr is TSqlColumnRefNode) then Exit;
  { LIMIT/OFFSET YOKSA indeksten tek tek ReadRow yapmak TAM TARAMA + siralamadan
    YAVAS kalir (her satir rastgele seek). Bu durumda eski yol tercih edilir;
    WHERE ile daraltma zaten NarrowRows'ta devreye giriyor. }
  if (Stmt.LimitVal < 0) and (Stmt.OffsetVal <= 0) then Exit;

  // ORDER BY kolonlarini coz
  SetLength(oCols, Stmt.OrderBy.Count);
  for i := 0 to Stmt.OrderBy.Count - 1 do
  begin
    cr := TSqlColumnRefNode(Stmt.OrderBy[i].Expr);
    oCols[i] := -1;
    for j := 0 to High(Td.Cols) do
      if VDbNorm(Td.Cols[j].Name) = VDbNorm(cr.ColumnName) then
      begin oCols[i] := j; Break; end;
    if oCols[i] < 0 then Exit;
  end;

  // Bilesik (farkli yonler) siralama indeksten saglanamaz.
  descAny := False;
  for i := 1 to Stmt.OrderBy.Count - 1 do
    if Stmt.OrderBy[i].Desc <> Stmt.OrderBy[0].Desc then descAny := True;
  if descAny then Exit;

  ci := oCols[0];
  if not FT.TryGetMemIndex(Td.TableId, ci, e) then Exit;
  nIdxCols := FT.IdxNParts(Td.TableId, ci);
  if Stmt.OrderBy.Count > nIdxCols then Exit;

  // ORDER BY kolonlari indeksin on ekiyle SIRAYLA eslesmeli
  icols := FT.IdxColsOfTable(Td.TableId, ci);
  if Length(icols) = 0 then Exit;
  leadingMatch := 0;
  for i := 0 to Stmt.OrderBy.Count - 1 do
    if icols[i] = oCols[i] then Inc(leadingMatch) else Break;
  if leadingMatch < Stmt.OrderBy.Count then Exit;

  desc := Stmt.OrderBy[0].Desc;

  // WHERE ile dilim daralt (yalnizca ILK ORDER BY kolonu uzerinden; boylece
  // dilim icinde indeks sirasi ORDER BY sirasiyla ayni kalir)
  lo := 0; hi := Length(e);
  conj := TList<TSqlExprNode>.Create;
  try
    if Stmt.WhereClause <> nil then Push(Stmt.WhereClause);
    for i := 0 to conj.Count - 1 do
    begin
      opName := '';
      if (conj[i] is TSqlBinaryOpNode) then
      begin
        node := TSqlBinaryOpNode(conj[i]);
        if node.Right is TSqlLiteralNode then
          case node.Op of
            sboEq:  opName := '=';
            sboGt:  opName := '>';
            sboGte: opName := '>=';
            sboLt:  opName := '<';
            sboLte: opName := '<=';
          end;
      end;
      if opName = '' then Continue;   // bu kosulu indeksleyemeyiz -> daraltma
      if not (TSqlBinaryOpNode(conj[i]).Left is TSqlColumnRefNode) then Continue;
      if VDbNorm(TSqlColumnRefNode(TSqlBinaryOpNode(conj[i]).Left).ColumnName) <>
         VDbNorm(Td.Cols[ci].Name) then Continue;
      pkVal := TSqlLiteralNode(node.Right).AsString;
      if not VDbIdxRangeL(e, Td.Cols[ci].Ctype, opName, pkVal,
      FT.IdxNParts(Td.TableId, ci), l2, h2) then Continue;
      if l2 > lo then lo := l2;
      if h2 < hi then hi := h2;
    end;
  finally
    conj.Free;
  end;

  off := Stmt.OffsetVal;
  lim := Stmt.LimitVal;
  need := lim;
  if need < 0 then need := -1;
  SetLength(Rows, 0);
  n := 0;
  if desc then
  begin
    i := hi - 1;
    while i >= lo do
    begin
      if FT.ReadRow(Td.Name, e[i].Pk, rv) and
         RowMatches(Stmt.WhereClause, rv, ColNames, ColTypes) then
      begin
        if off > 0 then Dec(off)
        else
        begin
          SetLength(Rows, Length(Rows) + 1);
          Rows[High(Rows)] := rv;
          if (need >= 0) and (Length(Rows) >= need) then Break;
        end;
      end;
      Dec(i);
    end;
  end
  else
  begin
    i := lo;
    while i < hi do
    begin
      if FT.ReadRow(Td.Name, e[i].Pk, rv) and
         RowMatches(Stmt.WhereClause, rv, ColNames, ColTypes) then
      begin
        if off > 0 then Dec(off)
        else
        begin
          SetLength(Rows, Length(Rows) + 1);
          Rows[High(Rows)] := rv;
          if (need >= 0) and (Length(Rows) >= need) then Break;
        end;
      end;
      Inc(i);
    end;
  end;
  Result := True;
end;

type
  TSortColInfo = record
    ColIdx: Integer;
    CType: Byte;
    Desc: Boolean;
  end;

{ ------------------------------------------------------------
  DoSort - Bellek-ici ORDER BY (Iterative QuickSort, O(N log N))
  ------------------------------------------------------------ }
procedure TVSqlExecutor.DoSort(var Rows: TStrMatrix; const Keys: TStrArray;
  OrderBy: TList<TOrderItem>;
  const ColNames: TStrArray; const ColTypes: TByteArray);
var
  i, j, k, kidx, m, c, validCount: Integer;
  sortCols: array of TSortColInfo;
  idx: array of Integer;
  newRows: TStrMatrix;
  StackL, StackH: array[0..63] of Integer;
  SP, L, H, pIdx, tIdx: Integer;
  intKeys: array of Int64;
  vInt, pivInt, tInt: Int64;
  desc: Boolean;

  function CompareRowIdx(ra, rb: Integer): Integer;
  var
    sk, sc: Integer;
    sct: Byte;
    sav, sbv: string;
  begin
    Result := 0;
    for sk := 0 to High(sortCols) do
    begin
      sc := sortCols[sk].ColIdx;
      sct := sortCols[sk].CType;
      if (sc >= 0) and (sc <= High(Rows[ra])) then sav := Rows[ra][sc] else sav := '';
      if (sc >= 0) and (sc <= High(Rows[rb])) then sbv := Rows[rb][sc] else sbv := '';
      if VDbCmpVal(sav, sbv, '<', sct) then Result := -1
      else if VDbCmpVal(sav, sbv, '>', sct) then Result := 1
      else Result := 0;
      if Result <> 0 then
      begin
        if sortCols[sk].Desc then Result := -Result;
        Exit;
      end;
    end;
  end;

begin
  if (OrderBy = nil) or (OrderBy.Count = 0) or (Length(Rows) < 2) then Exit;

  // 1. Siralama kolonlarini onceden coz (her karsilastirmada Name arama!)
  SetLength(sortCols, OrderBy.Count);
  validCount := 0;
  for k := 0 to OrderBy.Count - 1 do
  begin
    kidx := -1;
    for m := 0 to High(ColNames) do
    begin
      if SameText(ColNames[m], Keys[k]) then
      begin kidx := m; Break; end;
      if (Pos('.', ColNames[m]) > 0) and
         SameText(Copy(ColNames[m], Pos('.', ColNames[m]) + 1, MaxInt), Keys[k]) then
      begin kidx := m; Break; end;
      if (Pos('.', Keys[k]) > 0) and
         SameText(Copy(Keys[k], Pos('.', Keys[k]) + 1, MaxInt), ColNames[m]) then
      begin kidx := m; Break; end;
    end;
    if kidx >= 0 then
    begin
      sortCols[validCount].ColIdx := kidx;
      if kidx < Length(ColTypes) then
        sortCols[validCount].CType := ColTypes[kidx]
      else
        sortCols[validCount].CType := VCT_STR;
      sortCols[validCount].Desc := OrderBy[k].Desc;
      Inc(validCount);
    end;
  end;
  SetLength(sortCols, validCount);
  if validCount = 0 then Exit;

  // 2. Indeks dizisi olustur
  SetLength(idx, Length(Rows));
  for i := 0 to High(Rows) do idx[i] := i;

  // 3. Tekil sayisal kolon icin ultra-hizli tamsayi QuickSort
  if (validCount = 1) and ((sortCols[0].CType = VCT_INT) or (sortCols[0].CType = VCT_BOOL)) then
  begin
    c := sortCols[0].ColIdx;
    desc := sortCols[0].Desc;
    SetLength(intKeys, Length(Rows));
    for i := 0 to High(Rows) do
    begin
      if (c <= High(Rows[i])) and VDbParseInt(Rows[i][c], vInt) then
        intKeys[i] := vInt
      else
        intKeys[i] := Low(Int64);
    end;

    SP := 0;
    StackL[0] := 0; StackH[0] := High(idx); Inc(SP);
    while SP > 0 do
    begin
      Dec(SP);
      L := StackL[SP]; H := StackH[SP];
      while L < H do
      begin
        pivInt := intKeys[(L + H) div 2];
        i := L; j := H;
        repeat
          if desc then
          begin
            while intKeys[i] > pivInt do Inc(i);
            while intKeys[j] < pivInt do Dec(j);
          end
          else
          begin
            while intKeys[i] < pivInt do Inc(i);
            while intKeys[j] > pivInt do Dec(j);
          end;
          if i <= j then
          begin
            tIdx := idx[i]; idx[i] := idx[j]; idx[j] := tIdx;
            tInt := intKeys[i]; intKeys[i] := intKeys[j]; intKeys[j] := tInt;
            Inc(i); Dec(j);
          end;
        until i > j;
        if (j - L) < (H - i) then
        begin
          if i < H then begin StackL[SP] := i; StackH[SP] := H; Inc(SP); end;
          H := j;
        end
        else
        begin
          if L < j then begin StackL[SP] := L; StackH[SP] := j; Inc(SP); end;
          L := i;
        end;
      end;
    end;
  end
  else
  begin
    // 4. Genel tip-bilgili Quicksort
    SP := 0;
    StackL[0] := 0; StackH[0] := High(idx); Inc(SP);
    while SP > 0 do
    begin
      Dec(SP);
      L := StackL[SP]; H := StackH[SP];
      while L < H do
      begin
        pIdx := idx[(L + H) div 2];
        i := L; j := H;
        repeat
          while CompareRowIdx(idx[i], pIdx) < 0 do Inc(i);
          while CompareRowIdx(idx[j], pIdx) > 0 do Dec(j);
          if i <= j then
          begin
            tIdx := idx[i]; idx[i] := idx[j]; idx[j] := tIdx;
            Inc(i); Dec(j);
          end;
        until i > j;
        if (j - L) < (H - i) then
        begin
          if i < H then begin StackL[SP] := i; StackH[SP] := H; Inc(SP); end;
          H := j;
        end
        else
        begin
          if L < j then begin StackL[SP] := L; StackH[SP] := j; Inc(SP); end;
          L := i;
        end;
      end;
    end;
  end;

  // 5. Siralanmis indekslere gore satirlari tek seferde O(N) kopyala
  SetLength(newRows, Length(Rows));
  for i := 0 to High(Rows) do
    newRows[i] := Rows[idx[i]];
  Rows := newRows;
end;

{ ------------------------------------------------------------
  ExecJoinScan
  ------------------------------------------------------------ }
procedure TVSqlExecutor.ExecJoinScan(Stmt: TSqlSelectStmt;
  out MergedRows: TStrMatrix;
  out MergedColNames: TStrArray; out MergedColTypes: TByteArray);
var
  td1, td2: TTableDef;
  pks1, pks2: TStrArray;
  rows1, rows2: TStrMatrix;
  cn1, cn2: TStrArray;
  ct1, ct2: TByteArray;
  i, j, k, q, n1, n2: Integer;
  merged: TStrArray;
  onOk, matchFound: Boolean;
  JoinIdxCol1, JoinIdxCol2: Integer;   // sol/sag JOIN kolonlari
  JoinUsePk: Boolean;
  JoinEntries: TIdxEntries;
  lo2, hi2: Integer;
  rv2: TStrArray;
  jv: string;
  eqn: TSqlBinaryOpNode;
  mr: TStrMatrix;        // MergeRows + kademeli buyume (O(n^2) SetLength onlemi)
  mrN, mrCap: Integer;

  // Bir kolon referansini (tablo adi + kolon adi) iki taraftan hangisine
  // ait oldugunu bulur. Doner: 1 = sol tablo, 2 = sag tablo, 0 = bilinmiyor.
  function Taraf(const C: TSqlColumnRefNode; out Pos: Integer): Integer;
  var
    m1, m2: Boolean;
    nm: string;
    w: Integer;
  begin
    Pos := -1;
    m1 := False; m2 := False;
    if (C.TableQualifier <> '') and (Stmt.FromAlias <> '') then
      m1 := SameText(C.TableQualifier, Stmt.FromAlias);
    if (C.TableQualifier <> '') and (Stmt.FromAlias = '') then
      m1 := SameText(C.TableQualifier, Stmt.FromTable);
    if (C.TableQualifier <> '') and (Stmt.Join.Alias <> '') then
      m2 := SameText(C.TableQualifier, Stmt.Join.Alias);
    if (C.TableQualifier <> '') and (Stmt.Join.Alias = '') then
      m2 := SameText(C.TableQualifier, Stmt.Join.Table);
    if m1 and not m2 then Result := 1
    else if m2 and not m1 then Result := 2
    else if not m1 and not m2 then
    begin
      // nitelendirme yok: kolon adi tek tarafta varsa orasi
      nm := VDbNorm(C.ColumnName);
      for w := 0 to High(td1.Cols) do
        if VDbNorm(td1.Cols[w].Name) = nm then
        begin m1 := True; Pos := w; end;
      for w := 0 to High(td2.Cols) do
        if VDbNorm(td2.Cols[w].Name) = nm then
        begin m2 := True; Pos := w; end;
      if m1 and not m2 then Result := 1
      else if m2 and not m1 then Result := 2
      else Result := 0;
    end
    else Result := 0;
    if Result = 1 then
    begin
      Pos := -1;
      for w := 0 to High(td1.Cols) do
        if VDbNorm(td1.Cols[w].Name) = VDbNorm(C.ColumnName) then
        begin Pos := w; Break; end;
    end
    else if Result = 2 then
    begin
      Pos := -1;
      for w := 0 to High(td2.Cols) do
        if VDbNorm(td2.Cols[w].Name) = VDbNorm(C.ColumnName) then
        begin Pos := w; Break; end;
    end;
  end;

  // Sonuc dizisini KADEMELI buyut (FPC'de SetLength(n+1) her adimda tum
  // diziyi yeniden ayirir; 35.000 satirlik bir JOIN'de O(n^2) olurdu).
  procedure MrPush(const Row: TStrArray);
  begin
    if mrN >= mrCap then
    begin
      if mrCap = 0 then mrCap := 64
      else mrCap := mrCap * 2;
      SetLength(mr, mrCap);
    end;
    mr[mrN] := Row;
    Inc(mrN);
  end;

begin
  td1 := FT.GetTable(Stmt.FromTable);
  td2 := FT.GetTable(Stmt.Join.Table);
  BuildColInfo(td1, cn1, ct1);
  BuildColInfo(td2, cn2, ct2);
  n1 := Length(cn1); n2 := Length(cn2);

  JoinIdxCol1 := -1; JoinIdxCol2 := -1; JoinUsePk := False;
  if (Stmt.Join.OnCondition is TSqlBinaryOpNode) and
     (TSqlBinaryOpNode(Stmt.Join.OnCondition).Op = sboEq) and
     (TSqlBinaryOpNode(Stmt.Join.OnCondition).Left  is TSqlColumnRefNode) and
     (TSqlBinaryOpNode(Stmt.Join.OnCondition).Right is TSqlColumnRefNode) then
  begin
    eqn := TSqlBinaryOpNode(Stmt.Join.OnCondition);
    j := Taraf(TSqlColumnRefNode(eqn.Left), i);
    k := Taraf(TSqlColumnRefNode(eqn.Right), q);
    if (j = 1) and (k = 2) and (i >= 0) and (q >= 0) then
    begin
      JoinIdxCol1 := i; JoinIdxCol2 := q;
    end
    else if (j = 2) and (k = 1) and (i >= 0) and (q >= 0) then
    begin
      JoinIdxCol1 := q; JoinIdxCol2 := i;
    end;
  end;
  if JoinIdxCol2 >= 0 then
  begin
    if td2.PkIndex = JoinIdxCol2 then
      JoinUsePk := True
    else if not FT.TryGetMemIndex(td2.TableId, JoinIdxCol2, JoinEntries) then
      JoinIdxCol2 := -1;   // indeks yok -> klasik yol
  end;

  SetLength(MergedColNames, n1 + n2);
  SetLength(MergedColTypes, n1 + n2);
  for i := 0 to n1 - 1 do
  begin
    if Stmt.FromAlias <> '' then
      MergedColNames[i] := Stmt.FromAlias + '.' + cn1[i]
    else
      MergedColNames[i] := Stmt.FromTable + '.' + cn1[i];
    MergedColTypes[i] := ct1[i];
  end;
  for i := 0 to n2 - 1 do
  begin
    if Stmt.Join.Alias <> '' then
      MergedColNames[n1 + i] := Stmt.Join.Alias + '.' + cn2[i]
    else
      MergedColNames[n1 + i] := Stmt.Join.Table + '.' + cn2[i];
    MergedColTypes[n1 + i] := ct2[i];
  end;

  { ----------------------------------------------------------------
    HIZLI YOL: ON <sol kolon> = <sag kolon>
    ONCEDEN her iki tablo da tam taraniyor ve ic ice dongu ile
    eslestiriliyordu (O(n*m)): 20.000 x 20.000 = 400.000.000 karsilastirma.
    Sag tarafin JOIN kolonunda indeks (veya PK) varsa sol satir basina
    yalniz O(log n + eslesme) kadar bakilir.
    ---------------------------------------------------------------- }

  mrN := 0; mrCap := 0; SetLength(mr, 0);

  if JoinIdxCol2 >= 0 then
  begin
    FT.ScanRows(Stmt.FromTable, pks1, rows1);
    for i := 0 to High(rows1) do
    begin
      jv := VDbNormValue(td2.Cols[JoinIdxCol2].Ctype, rows1[i][JoinIdxCol1]);
      matchFound := False;
      if JoinUsePk then
      begin
        if FT.ReadRow(Stmt.Join.Table, jv, rv2) and
           (rv2[JoinIdxCol2] = rows1[i][JoinIdxCol1]) then
        begin
          SetLength(merged, n1 + n2);
          for k := 0 to n1 - 1 do merged[k] := rows1[i][k];
          for k := 0 to n2 - 1 do merged[n1 + k] := rv2[k];
          MrPush(merged);
          matchFound := True;
        end;
      end
      else if VDbIdxRangeL(JoinEntries, td2.Cols[JoinIdxCol2].Ctype, '=', jv,
               FT.IdxNParts(td2.TableId, JoinIdxCol2),
               lo2, hi2) then
        for k := lo2 to hi2 - 1 do
          if FT.ReadRow(Stmt.Join.Table, JoinEntries[k].Pk, rv2) then
          begin
            SetLength(merged, n1 + n2);
            for q := 0 to n1 - 1 do merged[q] := rows1[i][q];
            for q := 0 to n2 - 1 do merged[n1 + q] := rv2[q];
            onOk := EvalBool(Stmt.Join.OnCondition, merged, MergedColNames,
              MergedColTypes);
            if onOk then
            begin
              MrPush(merged);
              matchFound := True;
            end;
          end;
      if (not matchFound) and (Stmt.Join.JoinType = jtLeft) then
      begin
        SetLength(merged, n1 + n2);
        for k := 0 to n1 - 1 do merged[k] := rows1[i][k];
        for k := 0 to n2 - 1 do merged[n1 + k] := '';
        MrPush(merged);
      end;
    end;
    SetLength(mr, mrN);
    MergedRows := mr;
    Exit;
  end;

  // klasik ic ice dongu (sag tarafta indeks/PK yok)
  FT.ScanRows(Stmt.FromTable, pks1, rows1);
  FT.ScanRows(Stmt.Join.Table, pks2, rows2);
  mrN := 0;
  for i := 0 to High(rows1) do
  begin
    matchFound := False;
    for j := 0 to High(rows2) do
    begin
      SetLength(merged, n1 + n2);
      for k := 0 to n1 - 1 do merged[k] := rows1[i][k];
      for k := 0 to n2 - 1 do merged[n1 + k] := rows2[j][k];
      onOk := EvalBool(Stmt.Join.OnCondition, merged, MergedColNames, MergedColTypes);
      if onOk then
      begin
        MrPush(merged);
        matchFound := True;
      end;
    end;
    if (not matchFound) and (Stmt.Join.JoinType = jtLeft) then
    begin
      SetLength(merged, n1 + n2);
      for k := 0 to n1 - 1 do merged[k] := rows1[i][k];
      for k := 0 to n2 - 1 do merged[n1 + k] := '';
      MrPush(merged);
    end;
  end;
  SetLength(mr, mrN);
  MergedRows := mr;
end;

{ ------------------------------------------------------------
  ExecGroupBy
  ------------------------------------------------------------ }
procedure TVSqlExecutor.ExecGroupBy(Stmt: TSqlSelectStmt;
  const AllPks: TStrArray; const AllRows: TStrMatrix;
  const ColNames: TStrArray; const ColTypes: TByteArray;
  out Res: TSqlResult);
var
  GroupKeys: TList<TStrArray>;
  GroupRowSets: TIntListList;
  i, j, k, gi: Integer;
  key: TStrArray;
  rowIdx: TIntList;
  outCols: TStrArray;
  outRows: TStrMatrix;
  fn: TSqlFuncCallNode;
  colVal: string;
  sumF, fv: Double;
  cntI: Int64;
  minV, maxV: string;
  ci, avgCnt: Integer;
  tmpRow: TStrArray;
  havingOk: Boolean;
begin
  GroupKeys := TList<TStrArray>.Create;
  GroupRowSets := TIntListList.Create;
  try
    // 1. Grupla
    for i := 0 to High(AllRows) do
    begin
      if not RowMatches(Stmt.WhereClause, AllRows[i], ColNames, ColTypes) then Continue;
      SetLength(key, Stmt.GroupByCols.Count);
      for j := 0 to Stmt.GroupByCols.Count - 1 do
      begin
        ci := -1;
        for k := 0 to High(ColNames) do
          if SameText(ColNames[k], Stmt.GroupByCols[j]) then begin ci := k; Break; end;
        if (ci >= 0) and (ci < Length(AllRows[i])) then key[j] := AllRows[i][ci]
        else key[j] := '';
      end;
      gi := -1;
      for j := 0 to GroupKeys.Count - 1 do
        if SameStrArr(GroupKeys[j], key) then begin gi := j; Break; end;
      if gi < 0 then
      begin
        GroupKeys.Add(key);
        GroupRowSets.Add(TIntList.Create);
        gi := GroupKeys.Count - 1;
      end;
      GroupRowSets[gi].Add(i);
    end;
    // Bos tablo + GROUP BY'siz aggregate: tek bos grup olustur (COUNT(*)=0)
    if (GroupKeys.Count = 0) and (Stmt.GroupByCols.Count = 0) then
    begin
      SetLength(key, 0);
      GroupKeys.Add(key);
      GroupRowSets.Add(TIntList.Create);
    end;

    // 2. Cikti kolonlari
    SetLength(outCols, Stmt.Columns.Count);
    for j := 0 to Stmt.Columns.Count - 1 do
    begin
      if Stmt.Columns[j].Alias <> '' then outCols[j] := Stmt.Columns[j].Alias
      else if Stmt.Columns[j].Expr is TSqlFuncCallNode then
        outCols[j] := TSqlFuncCallNode(Stmt.Columns[j].Expr).FuncName
      else if Stmt.Columns[j].Expr is TSqlColumnRefNode then
        outCols[j] := TSqlColumnRefNode(Stmt.Columns[j].Expr).ColumnName
      else outCols[j] := 'col' + IntToStr(j + 1);
    end;

    if Stmt.HavingClause <> nil then
    begin
      if HasAggregateExpr(Stmt.HavingClause) then
        raise Exception.Create('HAVING icinde aggregate dogrudan kullanilamaz; SELECT listesinde alias verip alias ile filtreleyin');
    end;

    // 3. Her grup icin hesapla
    SetLength(outRows, 0);
    for gi := 0 to GroupKeys.Count - 1 do
    begin
      rowIdx := GroupRowSets[gi];
      SetLength(tmpRow, Stmt.Columns.Count);
      for j := 0 to Stmt.Columns.Count - 1 do
      begin
        if Stmt.Columns[j].Expr is TSqlFuncCallNode then
        begin
          fn := TSqlFuncCallNode(Stmt.Columns[j].Expr);
          cntI := 0; sumF := 0; avgCnt := 0; minV := ''; maxV := '';
          for k := 0 to rowIdx.Count - 1 do
          begin
            if fn.IsStar then
              Inc(cntI)
            else
            begin
              colVal := EvalExpr(fn.Arg, AllRows[rowIdx[k]], ColNames, ColTypes);
              if colVal = '' then Continue;
              Inc(cntI);
              if VDbParseFloat(colVal, fv) then
              begin
                sumF := sumF + fv;
                Inc(avgCnt);
              end;
              if (minV = '') or VDbCmpVal(colVal, minV, '<', VCT_STR) then minV := colVal;
              if (maxV = '') or VDbCmpVal(colVal, maxV, '>', VCT_STR) then maxV := colVal;
            end;
          end;
          if fn.FuncName = 'COUNT' then tmpRow[j] := IntToStr(cntI)
          else if fn.FuncName = 'SUM' then tmpRow[j] := VDbFloatToStr(sumF)
          else if fn.FuncName = 'AVG' then
          begin
            if avgCnt > 0 then tmpRow[j] := VDbFloatToStr(sumF / avgCnt)
            else tmpRow[j] := '';
          end
          else if fn.FuncName = 'MIN' then tmpRow[j] := minV
          else if fn.FuncName = 'MAX' then tmpRow[j] := maxV
          else tmpRow[j] := '';
        end
        else
        begin
          if rowIdx.Count > 0 then
            tmpRow[j] := EvalExpr(Stmt.Columns[j].Expr, AllRows[rowIdx[0]], ColNames, ColTypes)
          else
            tmpRow[j] := '';
        end;
      end;
      if Stmt.HavingClause <> nil then
        havingOk := EvalBool(Stmt.HavingClause, tmpRow, outCols, nil)
      else
        havingOk := True;
      if havingOk then
      begin
        SetLength(outRows, Length(outRows) + 1);
        outRows[High(outRows)] := tmpRow;
      end;
    end;

    Res.Fields := outCols;
    Res.Rows := outRows;
    Res.Affected := Length(outRows);
    Res.Msg := 'OK';
  finally
    for i := 0 to GroupRowSets.Count - 1 do GroupRowSets[i].Free;
    GroupRowSets.Free;
    GroupKeys.Free;
  end;
end;

{ ------------------------------------------------------------
  ExecSelect
  ------------------------------------------------------------ }
procedure TVSqlExecutor.ExecSelect(Stmt: TSqlSelectStmt; out Res: TSqlResult);
var
  td: TTableDef;
  pks: TStrArray;
  allRows, filteredRows, outRows, merged: TStrMatrix;
  colNames: TStrArray;
  colTypes: TByteArray;
  i, j, n: Integer;
  outCols: TStrArray;
  orderKeys: TStrArray;
  rightRes: TSqlResult;
  seenKeys: TList<TStrArray>;
  isDup, found, SkipOffsetLimit: Boolean;
begin
  SkipOffsetLimit := False;
  // FROM'suz SELECT: SELECT 1, 'abc' AS x, NULL
  if (Stmt.FromTable = '') and not Stmt.HasJoin then
  begin
    SetLength(outCols, Stmt.Columns.Count);
    SetLength(outRows, 1);
    SetLength(outRows[0], Stmt.Columns.Count);
    for i := 0 to Stmt.Columns.Count - 1 do
    begin
      if Stmt.Columns[i].Alias <> '' then
        outCols[i] := Stmt.Columns[i].Alias
      else if Stmt.Columns[i].Expr is TSqlLiteralNode then
        outCols[i] := TSqlLiteralNode(Stmt.Columns[i].Expr).AsString
      else
        outCols[i] := 'col' + IntToStr(i + 1);

      if Stmt.Columns[i].Expr is TSqlColumnRefNode then
        raise Exception.Create('FROM''suz SELECT icinde kolon kullanilamaz: ' +
          TSqlColumnRefNode(Stmt.Columns[i].Expr).ColumnName);

      outRows[0][i] := EvalExpr(Stmt.Columns[i].Expr, nil, nil, nil);
    end;
    Res.Fields := outCols;
    Res.Rows := outRows;
    Res.Affected := 1;
    Res.Msg := 'OK';
    Exit;
  end;

  // Karma kontrol: FROM'lu SELECT'te ham literal + kolon ref birlikte kullanilamaz
  if (Stmt.FromTable <> '') and (Stmt.Columns.Count > 0) then
  begin
    found := False; isDup := False;
    for i := 0 to Stmt.Columns.Count - 1 do
    begin
      if Stmt.Columns[i].Expr is TSqlLiteralNode then found := True;
      if Stmt.Columns[i].Expr is TSqlColumnRefNode then isDup := True;
    end;
    if found and isDup then
      for i := 0 to Stmt.Columns.Count - 1 do
        if Stmt.Columns[i].Expr is TSqlColumnRefNode then
          raise Exception.CreateFmt('FROM''suz SELECT icinde kolon kullanilamaz: %s',
            [TSqlColumnRefNode(Stmt.Columns[i].Expr).ColumnName]);
  end;

  if (Stmt.HavingClause <> nil) and (not HasAggregate(Stmt)) and (Stmt.GroupByCols.Count = 0) then
    raise Exception.Create('HAVING yalnizca GROUP BY veya aggregate ile kullanilabilir');

  if Stmt.HasJoin then
  begin
    ExecJoinScan(Stmt, allRows, colNames, colTypes);
    SetLength(filteredRows, 0);
    for i := 0 to High(allRows) do
      if RowMatches(Stmt.WhereClause, allRows[i], colNames, colTypes) then
      begin
        SetLength(filteredRows, Length(filteredRows) + 1);
        filteredRows[High(filteredRows)] := allRows[i];
      end;
  end
  else
  begin
    td := FT.GetTable(Stmt.FromTable);
    BuildColInfo(td, colNames, colTypes);

    // YOL 1 (en hizli): ORDER BY tek kolon ve o kolon indeksliyse satirlar
    // INDEKS sirasiyla okunur; OFFSET/LIMIT satir okunurken uygulanir.
    SkipOffsetLimit := TryIndexOrder(td, Stmt, colNames, colTypes, filteredRows);

    if not SkipOffsetLimit then
    begin
      { YOL 2: Satir adaylarini DARALT - PK nokta aramasi veya indeks dilimi.
        (Once her zaman FT.ScanRows cagriliyordu: 100.000 satirlik tabloda
         "WHERE id = 5" bile ~900 ms suruyordu.)
        Aggregate/GROUP BY de dogrudan sunu kullanir: ExecGroupBy satirlari
        KENDISI RowMatches ile filtreler, yani onceden daraltmak sonucu
        degistirmez. }
      if not NarrowRows(td, Stmt.WhereClause, colNames, colTypes, pks, allRows) then
        FT.ScanRows(Stmt.FromTable, pks, allRows);

      if HasAggregate(Stmt) or (Stmt.GroupByCols.Count > 0) then
      begin
        ExecGroupBy(Stmt, pks, allRows, colNames, colTypes, Res);
        // ORDER BY + LIMIT sonrasi
        if (Stmt.OrderBy <> nil) and (Stmt.OrderBy.Count > 0) then
        begin
          SetLength(orderKeys, Stmt.OrderBy.Count);
          for i := 0 to Stmt.OrderBy.Count - 1 do
            if Stmt.OrderBy[i].Expr is TSqlColumnRefNode then
              orderKeys[i] := TSqlColumnRefNode(Stmt.OrderBy[i].Expr).QualifiedName
            else orderKeys[i] := '';
          DoSort(Res.Rows, orderKeys, Stmt.OrderBy, Res.Fields, nil);
        end;
        if Stmt.OffsetVal > 0 then
        begin
          if Stmt.OffsetVal < Length(Res.Rows) then
          begin
            n := Length(Res.Rows) - Stmt.OffsetVal;
            for i := 0 to n - 1 do Res.Rows[i] := Res.Rows[i + Stmt.OffsetVal];
            SetLength(Res.Rows, n);
          end
          else SetLength(Res.Rows, 0);
        end;
        if (Stmt.LimitVal >= 0) and (Length(Res.Rows) > Stmt.LimitVal) then
          SetLength(Res.Rows, Stmt.LimitVal);
        Res.Affected := Length(Res.Rows);
        Exit;
      end;

      SetLength(filteredRows, 0);
      for i := 0 to High(allRows) do
        if RowMatches(Stmt.WhereClause, allRows[i], colNames, colTypes) then
        begin
          SetLength(filteredRows, Length(filteredRows) + 1);
          filteredRows[High(filteredRows)] := allRows[i];
        end;
    end;
  end;

  // ORDER BY (Projection oncesi - tum kolonlar mevcutken dogru sirala)
  if (not SkipOffsetLimit) and (Stmt.OrderBy <> nil) and
     (Stmt.OrderBy.Count > 0) then
  begin
    SetLength(orderKeys, Stmt.OrderBy.Count);
    for i := 0 to Stmt.OrderBy.Count - 1 do
      if Stmt.OrderBy[i].Expr is TSqlColumnRefNode then
        orderKeys[i] := TSqlColumnRefNode(Stmt.OrderBy[i].Expr).QualifiedName
      else orderKeys[i] := '';
    DoSort(filteredRows, orderKeys, Stmt.OrderBy, colNames, colTypes);
  end;

  // Projection
  if Stmt.Columns.Count = 0 then
  begin
    SetLength(outCols, Length(colNames));
    for i := 0 to High(colNames) do outCols[i] := colNames[i];
    outRows := filteredRows;
  end
  else
  begin
    SetLength(outCols, Stmt.Columns.Count);
    for i := 0 to Stmt.Columns.Count - 1 do
    begin
      if Stmt.Columns[i].Alias <> '' then outCols[i] := Stmt.Columns[i].Alias
      else if Stmt.Columns[i].Expr is TSqlColumnRefNode then
        outCols[i] := TSqlColumnRefNode(Stmt.Columns[i].Expr).ColumnName
      else outCols[i] := 'col' + IntToStr(i + 1);
    end;
    SetLength(outRows, Length(filteredRows));
    for i := 0 to High(filteredRows) do
    begin
      SetLength(outRows[i], Stmt.Columns.Count);
      for j := 0 to Stmt.Columns.Count - 1 do
        outRows[i][j] := EvalExpr(Stmt.Columns[j].Expr, filteredRows[i], colNames, colTypes);
    end;
  end;

  // DISTINCT
  if Stmt.IsDistinct then
  begin
    seenKeys := TList<TStrArray>.Create;
    try
      n := 0;
      for i := 0 to High(outRows) do
      begin
        isDup := False;
        for j := 0 to seenKeys.Count - 1 do
          if SameStrArr(seenKeys[j], outRows[i]) then begin isDup := True; Break; end;
        if not isDup then
        begin
          seenKeys.Add(outRows[i]);
          outRows[n] := outRows[i];
          Inc(n);
        end;
      end;
      SetLength(outRows, n);
    finally
      seenKeys.Free;
    end;
  end;

  // OFFSET  (TryIndexOrder yolu OFFSET/LIMIT'i SATIR OKURKEN uyguladi)
  if (not SkipOffsetLimit) and (Stmt.OffsetVal > 0) then
  begin
    if Stmt.OffsetVal < Length(outRows) then
    begin
      n := Length(outRows) - Stmt.OffsetVal;
      for i := 0 to n - 1 do outRows[i] := outRows[i + Stmt.OffsetVal];
      SetLength(outRows, n);
    end
    else SetLength(outRows, 0);
  end;

  // LIMIT  (TryIndexOrder yolu LIMIT'i SATIR OKURKEN uyguladi)
  if (not SkipOffsetLimit) and (Stmt.LimitVal >= 0) and
     (Length(outRows) > Stmt.LimitVal) then
    SetLength(outRows, Stmt.LimitVal);

  // SET OP
  if (Stmt.SetOp <> sokNone) and (Stmt.RightSelect <> nil) then
  begin
    ExecSelect(Stmt.RightSelect, rightRes);
    case Stmt.SetOp of
      sokUnion, sokUnionAll:
        begin
          SetLength(merged, Length(outRows) + Length(rightRes.Rows));
          for i := 0 to High(outRows) do merged[i] := outRows[i];
          for i := 0 to High(rightRes.Rows) do merged[Length(outRows) + i] := rightRes.Rows[i];
          if Stmt.SetOp = sokUnion then
          begin
            seenKeys := TList<TStrArray>.Create;
            try
              n := 0;
              for i := 0 to High(merged) do
              begin
                isDup := False;
                for j := 0 to seenKeys.Count - 1 do
                  if SameStrArr(seenKeys[j], merged[i]) then begin isDup := True; Break; end;
                if not isDup then begin seenKeys.Add(merged[i]); merged[n] := merged[i]; Inc(n); end;
              end;
              SetLength(merged, n);
            finally seenKeys.Free; end;
          end;
          outRows := merged;
        end;
      sokExcept:
        begin
          n := 0; SetLength(merged, Length(outRows));
          for i := 0 to High(outRows) do
          begin
            found := False;
            for j := 0 to High(rightRes.Rows) do
              if SameStrArr(outRows[i], rightRes.Rows[j]) then begin found := True; Break; end;
            if not found then begin merged[n] := outRows[i]; Inc(n); end;
          end;
          SetLength(merged, n); outRows := merged;
        end;
      sokIntersect:
        begin
          n := 0; SetLength(merged, Length(outRows));
          for i := 0 to High(outRows) do
          begin
            found := False;
            for j := 0 to High(rightRes.Rows) do
              if SameStrArr(outRows[i], rightRes.Rows[j]) then begin found := True; Break; end;
            if found then begin merged[n] := outRows[i]; Inc(n); end;
          end;
          SetLength(merged, n); outRows := merged;
        end;
    end;
  end;

  Res.Fields := outCols;
  Res.Rows := outRows;
  Res.Affected := Length(outRows);
  Res.Msg := 'OK';
end;

{ ------------------------------------------------------------
  ExecInsert
  ------------------------------------------------------------ }
procedure TVSqlExecutor.ExecInsert(Stmt: TSqlInsertStmt; out Res: TSqlResult);
var
  i, j, rCount: Integer;
  strVals: array of string;
  cnames: array of string;
  subRes: TSqlResult;
  td: TTableDef;
begin
  rCount := 0;
  td := FT.GetTable(Stmt.Table);
  if Length(Stmt.Columns) = 0 then
  begin
    SetLength(cnames, Length(td.Cols));
    for i := 0 to High(td.Cols) do cnames[i] := td.Cols[i].Name;
  end
  else
  begin
    SetLength(cnames, Length(Stmt.Columns));
    for i := 0 to High(Stmt.Columns) do cnames[i] := Stmt.Columns[i];
  end;

  if Stmt.SelectSrc <> nil then
  begin
    ExecSelect(Stmt.SelectSrc, subRes);
    for i := 0 to High(subRes.Rows) do
    begin
      FT.Insert(Stmt.Table, cnames, subRes.Rows[i]);
      Inc(rCount);
    end;
  end
  else if Stmt.ValuesRows <> nil then
  begin
    if (Stmt.ValuesRows.Count > 1) and not FT.Kv.InBatch then
    begin
      FT.Kv.BeginBatch;
      try
        for i := 0 to Stmt.ValuesRows.Count - 1 do
        begin
          if Stmt.ValuesRows[i].Count = 0 then
            FT.Insert(Stmt.Table, [], [])
          else
          begin
            SetLength(strVals, Stmt.ValuesRows[i].Count);
            for j := 0 to Stmt.ValuesRows[i].Count - 1 do
              strVals[j] := EvalExpr(Stmt.ValuesRows[i][j], nil, nil, nil);
            FT.Insert(Stmt.Table, cnames, strVals);
          end;
          Inc(rCount);
        end;
        FT.Kv.CommitBatch;
      except
        FT.AbortBatch;
        raise;
      end;
    end
    else
    begin
      for i := 0 to Stmt.ValuesRows.Count - 1 do
      begin
        if Stmt.ValuesRows[i].Count = 0 then
          FT.Insert(Stmt.Table, [], [])
        else
        begin
          SetLength(strVals, Stmt.ValuesRows[i].Count);
          for j := 0 to Stmt.ValuesRows[i].Count - 1 do
            strVals[j] := EvalExpr(Stmt.ValuesRows[i][j], nil, nil, nil);
          FT.Insert(Stmt.Table, cnames, strVals);
        end;
        Inc(rCount);
      end;
    end;
  end;

  Res.Affected := rCount;
  Res.LastTable := Stmt.Table;
  Res.Msg := 'OK';
end;

{ ------------------------------------------------------------
  ExecUpdate - AST WHERE filtreli, expression-based SET
  ------------------------------------------------------------ }
procedure TVSqlExecutor.ExecUpdate(Stmt: TSqlUpdateStmt; out Res: TSqlResult);
var
  td: TTableDef;
  pks: TStrArray;
  allRows: TStrMatrix;
  colNames: TStrArray;
  colTypes: TByteArray;
  i, j, ci, setIdx, rCount: Integer;
  newVals: TStrArray;
  allColNames: TStrArray;
begin
  td := FT.GetTable(Stmt.Table);
  BuildColInfo(td, colNames, colTypes);
  { Once her zaman FT.ScanRows -> 100.000 satirlik tabloda tek bir
    "UPDATE ... WHERE id = 5" ~1 saniye suruyordu. Simdi once adaylar
    daraltilir (PK nokta / indeks dilimi); bulunamazsa tam tarama. }
  if not NarrowRows(td, Stmt.WhereClause, colNames, colTypes, pks, allRows) then
    FT.ScanRows(Stmt.Table, pks, allRows);

  SetLength(allColNames, Length(td.Cols));
  for i := 0 to High(td.Cols) do allColNames[i] := td.Cols[i].Name;

  rCount := 0;
  if not FT.Kv.InBatch then
  begin
    FT.Kv.BeginBatch;
    try
      for i := 0 to High(allRows) do
      begin
        if not RowMatches(Stmt.WhereClause, allRows[i], colNames, colTypes) then Continue;
        SetLength(newVals, Length(td.Cols));
        for j := 0 to High(td.Cols) do newVals[j] := allRows[i][j];
        for j := 0 to Stmt.Assignments.Count - 1 do
        begin
          ci := -1;
          for setIdx := 0 to High(colNames) do
            if SameText(colNames[setIdx], Stmt.Assignments[j].ColName) then
            begin ci := setIdx; Break; end;
          if ci >= 0 then
            newVals[ci] := EvalExpr(Stmt.Assignments[j].Expr, allRows[i], colNames, colTypes);
        end;
        FT.Delete(Stmt.Table, pks[i]);
        FT.Insert(Stmt.Table, allColNames, newVals);
        Inc(rCount);
      end;
      FT.Kv.CommitBatch;
    except
      FT.AbortBatch;
      raise;
    end;
  end
  else
  begin
    for i := 0 to High(allRows) do
    begin
      if not RowMatches(Stmt.WhereClause, allRows[i], colNames, colTypes) then Continue;
      SetLength(newVals, Length(td.Cols));
      for j := 0 to High(td.Cols) do newVals[j] := allRows[i][j];
      for j := 0 to Stmt.Assignments.Count - 1 do
      begin
        ci := -1;
        for setIdx := 0 to High(colNames) do
          if SameText(colNames[setIdx], Stmt.Assignments[j].ColName) then
          begin ci := setIdx; Break; end;
        if ci >= 0 then
          newVals[ci] := EvalExpr(Stmt.Assignments[j].Expr, allRows[i], colNames, colTypes);
      end;
      FT.Delete(Stmt.Table, pks[i]);
      FT.Insert(Stmt.Table, allColNames, newVals);
      Inc(rCount);
    end;
  end;

  Res.Affected := rCount;
  Res.LastTable := Stmt.Table;
  Res.Msg := 'OK';
end;

{ ------------------------------------------------------------
  ExecDelete - AST WHERE filtreli
  ------------------------------------------------------------ }
procedure TVSqlExecutor.ExecDelete(Stmt: TSqlDeleteStmt; out Res: TSqlResult);
var
  td: TTableDef;
  pks: TStrArray;
  allRows: TStrMatrix;
  colNames: TStrArray;
  colTypes: TByteArray;
  i, rCount: Integer;
  toDelete: TList<string>;
begin
  td := FT.GetTable(Stmt.Table);
  BuildColInfo(td, colNames, colTypes);
  { Once her zaman tam tarama: "DELETE ... WHERE id = 5" 100.000 satirlik
    tabloda ~1 saniye suruyordu. Simdi PK nokta / indeks dilimi denenir. }
  if not NarrowRows(td, Stmt.WhereClause, colNames, colTypes, pks, allRows) then
    FT.ScanRows(Stmt.Table, pks, allRows);

  toDelete := TList<string>.Create;
  try
    for i := 0 to High(allRows) do
      if RowMatches(Stmt.WhereClause, allRows[i], colNames, colTypes) then
        toDelete.Add(pks[i]);
    rCount := toDelete.Count;
    if rCount > 0 then
    begin
      if not FT.Kv.InBatch then
      begin
        FT.Kv.BeginBatch;
        try
          for i := 0 to toDelete.Count - 1 do FT.Delete(Stmt.Table, toDelete[i]);
          FT.Kv.CommitBatch;
        except
          FT.AbortBatch;
          raise;
        end;
      end
      else
        for i := 0 to toDelete.Count - 1 do FT.Delete(Stmt.Table, toDelete[i]);
    end;
  finally
    toDelete.Free;
  end;

  Res.Affected := rCount;
  Res.LastTable := Stmt.Table;
  Res.Msg := 'OK';
end;

function FindColInArr(const Cols: array of TColDef; const ColName: string): Integer;
var i: Integer;
begin
  for i := 0 to High(Cols) do
    if SameText(Cols[i].Name, ColName) then Exit(i);
  Result := -1;
end;

function AndWhereGroups(const A, B: TWhereGroups): TWhereGroups;
var x, y, q, z: Integer;
begin
  if Length(A) = 0 then Exit(B);
  if Length(B) = 0 then Exit(A);
  SetLength(Result, Length(A) * Length(B));
  z := 0;
  for x := 0 to High(A) do
    for y := 0 to High(B) do
    begin
      SetLength(Result[z], Length(A[x]) + Length(B[y]));
      for q := 0 to High(A[x]) do Result[z][q] := A[x][q];
      for q := 0 to High(B[y]) do Result[z][Length(A[x]) + q] := B[y][q];
      Inc(z);
    end;
end;

function OrWhereGroups(const A, B: TWhereGroups): TWhereGroups;
var i, nA, nB: Integer;
begin
  nA := Length(A); nB := Length(B);
  SetLength(Result, nA + nB);
  for i := 0 to nA - 1 do Result[i] := A[i];
  for i := 0 to nB - 1 do Result[nA + i] := B[i];
end;

function ExprToWhereGroups(Expr: TSqlExprNode; const Cols: array of TColDef): TWhereGroups;
var
  bin: TSqlBinaryOpNode;
  colRef: TSqlColumnRefNode;
  lit: TSqlLiteralNode;
  ci: Integer;
  c: TWhereCond;
  colName, valStr, opStr: string;
begin
  SetLength(Result, 0);
  if Expr = nil then Exit;

  if Expr is TSqlBinaryOpNode then
  begin
    bin := TSqlBinaryOpNode(Expr);
    if bin.Op = sboAnd then
      Exit(AndWhereGroups(ExprToWhereGroups(bin.Left, Cols), ExprToWhereGroups(bin.Right, Cols)));
    if bin.Op = sboOr then
      Exit(OrWhereGroups(ExprToWhereGroups(bin.Left, Cols), ExprToWhereGroups(bin.Right, Cols)));

    colName := ''; valStr := ''; opStr := SqlBinaryOpToStr(bin.Op);
    if bin.Left is TSqlColumnRefNode then
    begin
      colName := TSqlColumnRefNode(bin.Left).ColumnName;
      if bin.Right is TSqlLiteralNode then
        valStr := TSqlLiteralNode(bin.Right).AsString
      else if bin.Right is TSqlColumnRefNode then
        valStr := TSqlColumnRefNode(bin.Right).ColumnName;
    end
    else if bin.Right is TSqlColumnRefNode then
    begin
      colName := TSqlColumnRefNode(bin.Right).ColumnName;
      if bin.Left is TSqlLiteralNode then
        valStr := TSqlLiteralNode(bin.Left).AsString;
      if opStr = '<' then opStr := '>'
      else if opStr = '>' then opStr := '<'
      else if opStr = '<=' then opStr := '>='
      else if opStr = '>=' then opStr := '<=';
    end;

    if colName <> '' then
    begin
      ci := FindColInArr(Cols, colName);
      if ci >= 0 then
      begin
        c.Col := ci;
        c.Ctype := Cols[ci].Ctype;
        c.Op := opStr;
        c.Val := valStr;
        SetLength(c.Vals, 0);
        SetLength(Result, 1);
        SetLength(Result[0], 1);
        Result[0][0] := c;
      end;
    end;
  end;
end;

procedure TVSqlExecutor.ExecCreateTable(Stmt: TSqlCreateTableStmt; out Res: TSqlResult);
var i: Integer;
begin
  if Stmt.IfNotExists and FT.TableExists(Stmt.Table) then
  begin Res.Affected := 0; Res.Msg := 'OK'; Exit; end;
  if Stmt.CheckExprs <> nil then
  begin
    for i := 0 to Stmt.CheckExprs.Count - 1 do
      Stmt.Checks := AndWhereGroups(Stmt.Checks, ExprToWhereGroups(Stmt.CheckExprs[i], Stmt.Cols));
  end;
  FT.CreateTable(Stmt.Table, Stmt.Cols, Stmt.PkIndex, Stmt.Checks, Stmt.Fks);
  Res.Affected := 1; Res.LastTable := Stmt.Table; Res.Msg := 'OK';
end;

procedure TVSqlExecutor.ExecDropTable(Stmt: TSqlDropTableStmt; out Res: TSqlResult);
begin
  if Stmt.IfExists and not FT.TableExists(Stmt.Table) then
  begin Res.Affected := 0; Res.Msg := 'OK'; Exit; end;
  FT.DropTable(Stmt.Table);
  Res.Affected := 1; Res.LastTable := Stmt.Table; Res.Msg := 'OK';
end;

procedure TVSqlExecutor.ExecCreateIndex(Stmt: TSqlCreateIndexStmt; out Res: TSqlResult);
begin
  if Length(Stmt.Cols) > 1 then
    FT.CreateIndexCols(Stmt.Table, Stmt.IndexName, Stmt.Cols)
  else
    FT.CreateIndex(Stmt.Table, Stmt.IndexName, Stmt.Col);
  Res.Affected := 1; Res.LastTable := Stmt.Table; Res.Msg := 'OK';
end;

procedure TVSqlExecutor.ExecDropIndex(Stmt: TSqlDropIndexStmt; out Res: TSqlResult);
begin
  FT.DropIndex(Stmt.IndexName);
  Res.Affected := 1; Res.Msg := 'OK';
end;

procedure TVSqlExecutor.ExecAlterTable(Stmt: TSqlAlterTableStmt; out Res: TSqlResult);
begin
  case Stmt.Action of
    ataAddColumn:
      FT.AlterAddColumn(Stmt.Table, Stmt.ColDef, Stmt.PositionCol,
        Stmt.DefaultVal <> '', Stmt.DefaultVal);
    ataDropColumn:
      FT.AlterDropColumn(Stmt.Table, Stmt.ColName);
    ataRenameColumn:
      FT.AlterRenameColumn(Stmt.Table, Stmt.ColName, Stmt.NewName);
    ataAlterColType:
      FT.AlterColumnType(Stmt.Table, Stmt.ColName, Stmt.NewTypeName);
    ataSetDefault:
      FT.AlterSetDefault(Stmt.Table, Stmt.ColName, True, Stmt.DefaultVal);
    ataDropDefault:
      FT.AlterDropDefault(Stmt.Table, Stmt.ColName);
    ataSetNotNull:
      FT.AlterSetNotNull(Stmt.Table, Stmt.ColName, True);
    ataDropNotNull:
      FT.AlterSetNotNull(Stmt.Table, Stmt.ColName, False);
    ataRenameTable:
      FT.AlterRenameTable(Stmt.Table, Stmt.NewName);
  end;
  Res.Affected := 1; Res.LastTable := Stmt.Table; Res.Msg := 'OK';
end;

{ ------------------------------------------------------------
  TX Handler
  ------------------------------------------------------------ }
procedure TVSqlExecutor.ExecTx(Stmt: TSqlTxStmt; out Res: TSqlResult);
begin
  case Stmt.Kind of
    txBegin:    FT.BeginBatch;
    txCommit:   FT.CommitBatch;
    txRollback: FT.AbortBatch;
  end;
  Res.Affected := 0; Res.Msg := 'OK';
end;

{ ------------------------------------------------------------
  Admin Handler
  ------------------------------------------------------------ }
procedure TVSqlExecutor.ExecAdmin(Stmt: TSqlAdminStmt; out Res: TSqlResult);
var
  rep: string;
  vOld, vNew: Int64;
  tbls, tmpi: TStrArray;
  tmprow: TStrMatrix;
  i: Integer;
begin
  case Stmt.Kind of
    admVerify:
      begin
        if FT.Kv.Verify(rep) then
        begin Res.Affected := 1; Res.Msg := 'VERIFY: ' + rep; end
        else
        begin Res.Affected := 0; Res.Msg := 'VERIFY HATASI: ' + rep; end;
      end;
    admVacuum:
      begin
        FT.Kv.Compact(vOld, vNew);
        Res.Affected := 1;
        Res.Msg := Format('VACUUM %d -> %d bayt (%d kazanc)', [vOld, vNew, vOld - vNew]);
      end;
    admReindex:
      begin FT.RebuildIndexes; Res.Affected := 1; Res.Msg := 'OK'; end;
    admShowTables:
      begin
        tbls := FT.TableNames;
        SetLength(Res.Fields, 2);
        Res.Fields[0] := 'table'; Res.Fields[1] := 'rows';
        SetLength(Res.Rows, Length(tbls));
        for i := 0 to High(tbls) do
        begin
          SetLength(Res.Rows[i], 2);
          Res.Rows[i][0] := tbls[i];
          FT.ScanRows(tbls[i], tmpi, tmprow);
          Res.Rows[i][1] := IntToStr(Length(tmprow));
        end;
        Res.Affected := Length(tbls);
        Res.Msg := IntToStr(Length(tbls)) + ' tablo';
      end;
    admBackupDb:
      begin
        FT.Kv.BackupTo(Stmt.BackupPath);
        Res.Affected := 1; Res.Msg := 'OK';
      end;
  else
    Res.Affected := 0; Res.Msg := 'OK';
  end;
end;

{ ------------------------------------------------------------
  JSON Handler
  ------------------------------------------------------------ }
procedure TVSqlExecutor.ExecJson(Stmt: TSqlJsonStmt; out Res: TSqlResult);
begin
  case Stmt.Kind of
    jsoExport:
      begin
        // VDbExportJson: Table='' ise tum veritabani, dolu ise tek tablo
        VDbExportJson(FT, Stmt.FilePath, Stmt.Table);
        Res.Affected := 1; Res.Msg := 'OK';
      end;
    jsoImport:
      begin
        VDbImportJson(FT, Stmt.FilePath);
        Res.Affected := 1; Res.Msg := 'OK';
      end;
  end;
end;


{ ------------------------------------------------------------
  Execute - Ana giris noktasi
  ------------------------------------------------------------ }
function TVSqlExecutor.Execute(Stmt: TSqlStmtNode): TSqlResult;
begin
  Result.Affected := 0;
  Result.Msg := '';
  Result.LastTable := '';
  Result.Stmts := 1;
  SetLength(Result.Fields, 0);
  SetLength(Result.Rows, 0);
  if Stmt = nil then Exit;

  if Stmt is TSqlSelectStmt then ExecSelect(TSqlSelectStmt(Stmt), Result)
  else if Stmt is TSqlInsertStmt then ExecInsert(TSqlInsertStmt(Stmt), Result)
  else if Stmt is TSqlUpdateStmt then ExecUpdate(TSqlUpdateStmt(Stmt), Result)
  else if Stmt is TSqlDeleteStmt then ExecDelete(TSqlDeleteStmt(Stmt), Result)
  else if Stmt is TSqlCreateTableStmt then ExecCreateTable(TSqlCreateTableStmt(Stmt), Result)
  else if Stmt is TSqlAlterTableStmt then ExecAlterTable(TSqlAlterTableStmt(Stmt), Result)
  else if Stmt is TSqlDropTableStmt then ExecDropTable(TSqlDropTableStmt(Stmt), Result)
  else if Stmt is TSqlCreateIndexStmt then ExecCreateIndex(TSqlCreateIndexStmt(Stmt), Result)
  else if Stmt is TSqlDropIndexStmt then ExecDropIndex(TSqlDropIndexStmt(Stmt), Result)
  else if Stmt is TSqlTxStmt then ExecTx(TSqlTxStmt(Stmt), Result)
  else if Stmt is TSqlAdminStmt then ExecAdmin(TSqlAdminStmt(Stmt), Result)
  else if Stmt is TSqlJsonStmt then ExecJson(TSqlJsonStmt(Stmt), Result)
  else raise Exception.Create('Desteklenmeyen AST cumlesi: ' + Stmt.ClassName);
end;

end.
