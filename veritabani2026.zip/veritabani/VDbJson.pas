unit VDbJson;

{ JSON interchange: depolama binary kalir, tasima/incele JSON ile.
  Tum degerler JSON string (veya null) yazilir: sayi duyarligi ve
  locale bagimsizligi icin bilerek boyle (\"24.5\" her makinede ayni okunur).
  Export sirasi kanonik (tablo adi + PK sirali) -> ayni DB hep ayni dosya.
  fpjson yalnizca IMPORT parse icin (FPC RTL, DLL yok).
}

{$mode delphi}

interface

uses
  Classes, SysUtils, VDbCore, VDbTable;

function VDbCtypeName(C: Byte): string;
function VDbCtypeByName(const S: string): Byte;
procedure VDbExportJson(Tb: TVTableDb; const Path, Table: string);
procedure VDbImportJson(Tb: TVTableDb; const Path: string);

implementation

uses
  fpjson, jsonparser, VDbSync;

function VDbCtypeName(C: Byte): string;
begin
  case C of
    VCT_INT: Result := 'INTEGER';
    VCT_FLOAT: Result := 'FLOAT';
    VCT_BOOL: Result := 'BOOLEAN';
    VCT_DATE: Result := 'DATE';
    VCT_DATETIME: Result := 'DATETIME';
    VCT_TIME: Result := 'TIME';
    VCT_BLOB: Result := 'BLOB';
  else
    Result := 'TEXT';
  end;
end;

function VDbCtypeByName(const S: string): Byte;
var
  u: string;
begin
  u := UpperCase(Trim(S));
  if (u = 'INTEGER') or (u = 'INT') then Exit(VCT_INT);
  if (u = 'FLOAT') or (u = 'DOUBLE') or (u = 'REAL') then Exit(VCT_FLOAT);
  if (u = 'BOOLEAN') or (u = 'BOOL') then Exit(VCT_BOOL);
  if u = 'DATE' then Exit(VCT_DATE);
  if (u = 'DATETIME') or (u = 'TIMESTAMP') then Exit(VCT_DATETIME);
  if u = 'TIME' then Exit(VCT_TIME);
  if (u = 'BLOB') or (u = 'BINARY') then Exit(VCT_BLOB);
  Result := VCT_STR;
end;

function JsEsc(const S: RawByteString): RawByteString;
var
  i: Integer;
  c: Byte;
begin
  Result := '"';
  for i := 1 to Length(S) do
  begin
    c := Byte(S[i]);
    case c of
      34: Result := Result + '\"';
      92: Result := Result + '\\';
      8: Result := Result + '\b';
      9: Result := Result + '\t';
      10: Result := Result + '\n';
      12: Result := Result + '\f';
      13: Result := Result + '\r';
    else
      if c < 32 then
        Result := Result + '\u' + IntToHex(c, 4)
      else
        Result := Result + AnsiChar(c);
    end;
  end;
  Result := Result + '"';
end;

procedure SortStr(var A: TStrArray);
  procedure Sort(L, H: Integer);
  var
    i, j: Integer;
    pv, tp: string;
  begin
    i := L; j := H; pv := A[(L + H) div 2];
    repeat
      while CompareStr(A[i], pv) < 0 do Inc(i);
      while CompareStr(A[j], pv) > 0 do Dec(j);
      if i <= j then
      begin tp := A[i]; A[i] := A[j]; A[j] := tp; Inc(i); Dec(j); end;
    until i > j;
    if L < j then Sort(L, j);
    if i < H then Sort(i, H);
  end;
begin
  if Length(A) > 1 then Sort(0, High(A));
end;

procedure WriteRaw(S: TFileStream; const T: RawByteString);
begin
  if Length(T) > 0 then
    S.WriteBuffer(T[1], Length(T));
end;

procedure VDbExportJson(Tb: TVTableDb; const Path, Table: string);
var
  names: TStrArray;
  ti, i, j: Integer;
  td: TTableDef;
  pks: TStrArray;
  rows: TStrMatrix;
  order: array of Integer;
  sw: Integer;
  tmp: TFileStream;
  tmpPath: string;
  first: Boolean;
begin
  if Table = '' then
    names := Tb.TableNames
  else
  begin
    SetLength(names, 1);
    names[0] := VDbNorm(Table);
    Tb.GetTable(names[0]); // yoksa hata
  end;
  SortStr(names);
  tmpPath := Path + '.tmp';
  if FileExists(tmpPath) then DeleteFile(tmpPath);
  tmp := TFileStream.Create(tmpPath, fmCreate);
  try
    WriteRaw(tmp, '{"tables":[');
    first := True;
    for ti := 0 to High(names) do
    begin
      td := Tb.GetTable(names[ti]);
      Tb.ScanRows(td.Name, pks, rows);
      // kanonik satir sirasi: PK string sirasi
      SetLength(order, Length(pks));
      for i := 0 to High(order) do order[i] := i;
      for i := 1 to High(order) do
      begin
        j := i;
        while (j > 0) and (CompareStr(pks[order[j]], pks[order[j - 1]]) < 0) do
        begin
          sw := order[j]; order[j] := order[j - 1]; order[j - 1] := sw;
          Dec(j);
        end;
      end;
      if not first then WriteRaw(tmp, ',');
      first := False;
      WriteRaw(tmp, '{"name":' + JsEsc(UTF8Encode(td.Name)) + ',"cols":[');
      for i := 0 to High(td.Cols) do
      begin
        if i > 0 then WriteRaw(tmp, ',');
        WriteRaw(tmp, '{"name":' + JsEsc(UTF8Encode(td.Cols[i].Name)) +
          ',"type":' + JsEsc(UTF8Encode(VDbCtypeName(td.Cols[i].Ctype))));
        if td.Cols[i].NotNull then WriteRaw(tmp, ',"notnull":true');
        if td.Cols[i].Unique then WriteRaw(tmp, ',"unique":true');
        if td.Cols[i].HasDef then
          WriteRaw(tmp, ',"default":' + JsEsc(UTF8Encode(td.Cols[i].Def)));
        WriteRaw(tmp, '}');
      end;
      WriteRaw(tmp, '],"pk":' + IntToStr(td.PkIndex));
      WriteRaw(tmp, ',"checks":[');
      for i := 0 to High(td.Checks) do
      begin
        if i > 0 then WriteRaw(tmp, ',');
        WriteRaw(tmp, '[');
        for j := 0 to High(td.Checks[i]) do
        begin
          if j > 0 then WriteRaw(tmp, ',');
          WriteRaw(tmp, '{"col":' + IntToStr(td.Checks[i][j].Col) +
            ',"op":' + JsEsc(UTF8Encode(td.Checks[i][j].Op)) +
            ',"val":' + JsEsc(UTF8Encode(td.Checks[i][j].Val)) + '}');
        end;
        WriteRaw(tmp, ']');
      end;
      WriteRaw(tmp, '],"fks":[');
      for i := 0 to High(td.Fks) do
      begin
        if i > 0 then WriteRaw(tmp, ',');
        // ONEDEN/ONUPDATE burada YAZILMIYORDU; import sonrasi tum FK'lar
        // varsayilan RESTRICT olurdu. CASCADE/SETNULL kullanan tablolar
        // export -> import dongusunde sessizce davranis degistiriyordu.
        WriteRaw(tmp, '{"col":' + IntToStr(td.Fks[i].Col) +
          ',"reftable":' + JsEsc(UTF8Encode(td.Fks[i].RefTable)) +
          ',"refcol":' + JsEsc(UTF8Encode(td.Fks[i].RefCol)) +
          ',"ondelete":' + JsEsc(UTF8Encode(td.Fks[i].OnDelete)) +
          ',"onupdate":' + JsEsc(UTF8Encode(td.Fks[i].OnUpdate)) + '}');
      end;
      WriteRaw(tmp, '],"rows":[');
      for i := 0 to High(order) do
      begin
        if i > 0 then WriteRaw(tmp, ',');
        WriteRaw(tmp, '[');
        for j := 0 to High(td.Cols) do
        begin
          if j > 0 then WriteRaw(tmp, ',');
          if rows[order[i]][j] = '' then
            WriteRaw(tmp, 'null')
          else
            WriteRaw(tmp, JsEsc(UTF8Encode(rows[order[i]][j])));
        end;
        WriteRaw(tmp, ']');
      end;
      WriteRaw(tmp, ']}');
    end;
    WriteRaw(tmp, ']}');
    VDbFlushStream(tmp);
  finally
    tmp.Free;
  end;
  if FileExists(Path) then DeleteFile(Path);
  if not RenameFile(tmpPath, Path) then
    raise Exception.Create('JSON yazilamadi: ' + Path);
end;

procedure VDbImportJson(Tb: TVTableDb; const Path: string);
var
  sl: TStringList;
  js: TJSONData;
  root: TJSONObject;
  tbls: TJSONArray;
  ti, i, j: Integer;
  to_: TJSONObject;
  co: TJSONObject;
  cols: TJSONArray;
  rws: TJSONArray;
  row: TJSONArray;
  tname: string;
  cnames: TStrArray;
  cvals: TStrArray;
  cdef: TColArray;
  v: TJSONData;
  sinceCommit: Integer;
  torder: array of Integer;
  tdone: array of Boolean;
  tnames: TStrArray;
  oi: Integer;
  progressed: Boolean;
  pkIdx: Integer;
  chkGroups: TWhereGroups;
  fkArr: array of TFkDef;

  function JStr(d: TJSONData): string;
  var
    raw: AnsiString;
  begin
    // fpjson UTF-8 cozmez, byte'lari genisletir (probe ile dogrulandi).
    // 1) AnsiString atamasi ham UTF-8 byte'lari birebir geri verir.
    // 2) UTF8Decode bunlari gercekten cozer.
    if (d = nil) or (d is TJSONNull) then
      Exit('');
    raw := AnsiString(d.AsString);
    Result := string(UTF8Decode(raw));
  end;

  function JBool(o: TJSONObject; const Key: string): Boolean;
  var
    d: TJSONData;
  begin
    d := o.Find(Key);
    Result := (d <> nil) and not (d is TJSONNull) and
      (SameText(d.AsString, 'true') or (d.AsString = '1'));
  end;

  function DepsReady(Tbls: TJSONArray; Ti: Integer; const Names: TStrArray;
    const Done: array of Boolean; Tb: TVTableDb): Boolean;
  // Ti tablosunun FK hedefleri ya DB'de var ya da dosyada once kuruldu
  var
    o, f, m: Integer;
    to2: TJSONObject;
    fks: TJSONArray;
    rt: string;
  begin
    Result := True;
    to2 := Tbls.Objects[Ti];
    fks := to2.Arrays['fks'];
    if fks = nil then Exit;
    for f := 0 to fks.Count - 1 do
    begin
      rt := VDbNorm(fks.Objects[f].Strings['reftable']);
      if Tb.TableExists(rt) then Continue;
      m := -1;
      for o := 0 to High(Names) do
        if Names[o] = rt then
        begin m := o; Break; end;
      if (m >= 0) and not Done[m] then Exit(False);
    end;
  end;

begin
  sl := TStringList.Create;
  try
    sl.LoadFromFile(Path);
    js := GetJSON(sl.Text);
  finally
    sl.Free;
  end;
  try
    if not (js is TJSONObject) then
      raise Exception.Create('JSON kok obje degil');
    root := TJSONObject(js);
    tbls := root.Arrays['tables'];
    if tbls = nil then
      raise Exception.Create('tables yok');
    // FK bagimlilik sirasi (ebeveyn once)
    SetLength(torder, tbls.Count);
    SetLength(tdone, tbls.Count);
    SetLength(tnames, tbls.Count);
    for ti := 0 to tbls.Count - 1 do
    begin
      torder[ti] := -1;
      tdone[ti] := False;
      tnames[ti] := VDbNorm(TJSONObject(tbls.Objects[ti]).Strings['name']);
    end;
    oi := 0;
    while oi < tbls.Count do
    begin
      progressed := False;
      for ti := 0 to tbls.Count - 1 do
      begin
        if tdone[ti] then Continue;
        if DepsReady(tbls, ti, tnames, tdone, Tb) then
        begin
          torder[oi] := ti;
          Inc(oi);
          tdone[ti] := True;
          progressed := True;
        end;
      end;
      if not progressed then
        raise Exception.Create('dongusel FK bagimliligi');
    end;
    sinceCommit := 0;
    Tb.Kv.BeginBatch;
    try
      for oi := 0 to High(torder) do
      begin
        ti := torder[oi];
        to_ := tbls.Objects[ti];
        tname := VDbNorm(to_.Strings['name']);
        cols := to_.Arrays['cols'];
        rws := to_.Arrays['rows'];
        if (tname = '') or (cols = nil) or (rws = nil) then
          raise Exception.Create('tablo formati bozuk');
        if not Tb.TableExists(tname) then
        begin
          SetLength(cdef, cols.Count);
          for i := 0 to cols.Count - 1 do
          begin
            co := cols.Objects[i];
            cdef[i].Name := VDbNorm(co.Strings['name']);
            cdef[i].Ctype := VDbCtypeByName(co.Strings['type']);
            cdef[i].NotNull := JBool(co, 'notnull');
            cdef[i].Unique := JBool(co, 'unique');
            v := co.Find('default');
            cdef[i].HasDef := (v <> nil) and not (v is TJSONNull);
            if cdef[i].HasDef then
              cdef[i].Def := JStr(v)
            else
              cdef[i].Def := '';
          end;
          pkIdx := to_.Get('pk', 0);
          // checks
          SetLength(chkGroups, 0);
          v := to_.Find('checks');
          if (v <> nil) and (v is TJSONArray) then
            for i := 0 to TJSONArray(v).Count - 1 do
            begin
              row := TJSONArray(v).Arrays[i];
              SetLength(chkGroups, Length(chkGroups) + 1);
              SetLength(chkGroups[High(chkGroups)], row.Count);
              for j := 0 to row.Count - 1 do
              begin
                co := row.Objects[j];
                chkGroups[High(chkGroups)][j].Col := co.Integers['col'];
                chkGroups[High(chkGroups)][j].Op := co.Strings['op'];
                chkGroups[High(chkGroups)][j].Val := JStr(co.Find('val'));
              end;
            end;
          // fks
          SetLength(fkArr, 0);
          v := to_.Find('fks');
          if (v <> nil) and (v is TJSONArray) then
            for i := 0 to TJSONArray(v).Count - 1 do
            begin
              co := TJSONArray(v).Objects[i];
              SetLength(fkArr, Length(fkArr) + 1);
              fkArr[High(fkArr)].Col := co.Integers['col'];
              fkArr[High(fkArr)].RefTable := VDbNorm(co.Strings['reftable']);
              fkArr[High(fkArr)].RefCol := VDbNorm(co.Strings['refcol']);
              // ONDELETE/ONUPDATE aksiyonlari. ESKI JSON dosyalarinda bu
              // alanlar yok -> bos gelir ve CreateTable varsayilani atar.
              fkArr[High(fkArr)].OnDelete :=
                VDbNorm(JStr(co.Find('ondelete')));
              fkArr[High(fkArr)].OnUpdate :=
                VDbNorm(JStr(co.Find('onupdate')));
            end;
          Tb.CreateTable(tname, cdef, pkIdx, chkGroups, fkArr);
        end;
        SetLength(cnames, Length(Tb.GetTable(tname).Cols));
        for i := 0 to High(cnames) do
          cnames[i] := Tb.GetTable(tname).Cols[i].Name;
        for i := 0 to rws.Count - 1 do
        begin
          row := rws.Arrays[i];
          if row.Count <> Length(cnames) then
            raise Exception.CreateFmt('kolon sayisi uymadi (%s satir %d)', [tname, i]);
          SetLength(cvals, Length(cnames));
          for j := 0 to High(cnames) do
          begin
            v := row.Items[j];
            cvals[j] := JStr(v);
          end;
          Tb.Insert(tname, cnames, cvals);
          Inc(sinceCommit);
          if sinceCommit >= 5000 then
          begin
            Tb.CommitBatch;
            Tb.BeginBatch;
            sinceCommit := 0;
          end;
        end;
      end;
      Tb.CommitBatch;
    except
      Tb.AbortBatch;
      raise;
    end;
  finally
    js.Free;
  end;
end;

end.
