unit VDbParser;

{ VDb SQL Ayrıştırıcısı (Parser) — Faz 3 (3.1 - 3.4)
  SQL metnini tarayarak tip-güvenli AST dugumlerine (TSqlStmtNode) donusturur.
  Ozyinelemeli inis (Recursive-Descent) teknigi kullanilir.

  Desteklenen SQL:
    DDL : CREATE TABLE [IF NOT EXISTS], ALTER TABLE, DROP TABLE [IF EXISTS]
          CREATE INDEX, DROP INDEX [IF EXISTS]
          CREATE/DROP/OPEN/CLOSE DATABASE, BACKUP TO, VACUUM, REINDEX, VERIFY
          SHOW/LIST TABLES, LIST DATABASES, EXPORT/IMPORT JSON
    DML : INSERT INTO ... VALUES / SELECT
          UPDATE ... SET ... WHERE
          DELETE FROM ... WHERE
    TX  : BEGIN, COMMIT, ROLLBACK
    SEL : SELECT [DISTINCT] cols FROM tbl [alias]
          [INNER|LEFT JOIN tbl2 alias ON cond]
          [WHERE expr]
          [GROUP BY cols] [HAVING expr]
          [ORDER BY cols [ASC|DESC]]
          [LIMIT n] [OFFSET n]
          UNION [ALL] / EXCEPT / INTERSECT
  
  Cikti: tek bir TSqlStmtNode; cagiran .Free ile temizler.
  Hata durumunda pozisyon bilgili Exception firlatilir.
}

{$mode delphi}

interface

uses
  Classes, SysUtils, Generics.Collections, VDbTable, VDbAst;

type
  TVDbParser = class
  private
    FSql   : string;
    FPos   : Integer;
    FLen   : Integer;
    FParams: TStrArray;
    FParamIdx: Integer;

    { ---- Tokenizer ---- }
    procedure SkipWS;
    function  Peek: Char;
    function  AtEnd: Boolean;
    function  NextToken(out T: string; out IsStringLit: Boolean): Boolean; overload;
    function  NextToken(out T: string): Boolean; overload;
    function  PeekToken: string;
    function  PeekToken2: string;   // ikinci token'a bakar (pos degistirmez)
    procedure Expect(const W: string);
    procedure ExpectToken(out T: string; out IsStringLit: Boolean); overload;
    procedure ExpectToken(out T: string); overload;
    function  TryEat(const W: string): Boolean;
    function  CurPos: string;       // hata mesaji icin "pos=N"

    { ---- Tür / Alan yardımcıları ---- }
    function  ParseTypeName: Byte;   // VCT_* donuyor
    procedure ParseColDef(var C: TColDef; Stmt: TSqlCreateTableStmt = nil);
    function  ReadFkAction: string;

    { ---- İfade Ayrıştırıcı ---- }
    // Operatör öncelik hiyerarşisi (en düşükten en yükseğe):
    //   OR -> AND -> NOT -> karşılaştırma -> ek/çıkar -> çarp/böl -> tekli -> atom
    function ParseExpr: TSqlExprNode;
    function ParseOrExpr: TSqlExprNode;
    function ParseAndExpr: TSqlExprNode;
    function ParseNotExpr: TSqlExprNode;
    function ParseCmpExpr: TSqlExprNode;
    function ParseAddExpr: TSqlExprNode;
    function ParseMulExpr: TSqlExprNode;
    function ParseUnaryExpr: TSqlExprNode;
    function ParsePrimary: TSqlExprNode;
    function ParseInList(Expr: TSqlExprNode; IsNot: Boolean): TSqlInNode;
    function ParseFuncCall(const FuncName: string): TSqlFuncCallNode;

    { ---- SELECT alt-parser ---- }
    procedure ParseSelectColumns(Stmt: TSqlSelectStmt);
    procedure ParseFromClause(Stmt: TSqlSelectStmt);
    procedure ParseJoinClause(Stmt: TSqlSelectStmt);
    procedure ParseGroupBy(Stmt: TSqlSelectStmt);
    procedure ParseOrderBy(Stmt: TSqlSelectStmt);

    { ---- Statement ayrıştırıcıları ---- }
    function ParseSelect: TSqlSelectStmt;
    function ParseInsert: TSqlInsertStmt;
    function ParseUpdate: TSqlUpdateStmt;
    function ParseDelete: TSqlDeleteStmt;
    function ParseCreateTable: TSqlCreateTableStmt;
    function ParseAlterTable: TSqlAlterTableStmt;
    function ParseDropTable: TSqlDropTableStmt;
    function ParseCreateIndex: TSqlCreateIndexStmt;
    function ParseDropIndex: TSqlDropIndexStmt;
    function ParseAdmin(const Kw1, Kw2: string): TSqlAdminStmt;
    function ParseJson(const Kw: string): TSqlJsonStmt;

  public
    { Parse: SQL metnini ayrıştırır, AST dugumu dondurur.
      Params: '?' yer tutucularini sirasıyla dolduran deger listesi. }
    function Parse(const ASql: string;
                   const AParams: array of string): TSqlStmtNode;
  end;

implementation

{ ============================================================
  Küçük yardımcılar
  ============================================================ }

function IsAlpha(C: Char): Boolean; inline;
begin Result := C in ['A'..'Z','a'..'z','_']; end;

function IsAlNum(C: Char): Boolean; inline;
begin Result := C in ['A'..'Z','a'..'z','0'..'9','_']; end;

function IsDigit(C: Char): Boolean; inline;
begin Result := C in ['0'..'9']; end;

{ ============================================================
  TVDbParser — Tokenizer
  ============================================================ }

procedure TVDbParser.SkipWS;
begin
  while FPos <= FLen do
  begin
    case FSql[FPos] of
      ' ', #9, #10, #13: Inc(FPos);
      '-': // -- satir yorumu
        if (FPos < FLen) and (FSql[FPos+1] = '-') then
        begin
          Inc(FPos, 2);
          while (FPos <= FLen) and (FSql[FPos] <> #10) do Inc(FPos);
        end
        else Break;
      '/': // /* ... */ blok yorumu
        if (FPos < FLen) and (FSql[FPos+1] = '*') then
        begin
          Inc(FPos, 2);
          while FPos < FLen do
          begin
            if (FSql[FPos] = '*') and (FSql[FPos+1] = '/') then
            begin Inc(FPos, 2); Break; end;
            Inc(FPos);
          end;
        end
        else Break;
    else
      Break;
    end;
  end;
end;

function TVDbParser.Peek: Char;
begin
  if FPos <= FLen then Result := FSql[FPos] else Result := #0;
end;

function TVDbParser.AtEnd: Boolean;
begin
  SkipWS;
  Result := FPos > FLen;
end;

function TVDbParser.NextToken(out T: string; out IsStringLit: Boolean): Boolean;
var
  Start: Integer;
begin
  SkipWS;
  T := '';
  IsStringLit := False;
  Result := False;
  if FPos > FLen then Exit;

  // Parametreli yer tutucu: ?
  if FSql[FPos] = '?' then
  begin
    Inc(FPos);
    if FParamIdx > High(FParams) then
      raise Exception.Create('parametre eksik: ? sayisi fazla');
    T := FParams[FParamIdx];
    Inc(FParamIdx);
    IsStringLit := True;
    Result := True;
    Exit;
  end;

  // Tekli tırnaklı string
  if FSql[FPos] = '''' then
  begin
    IsStringLit := True;
    Inc(FPos); Start := FPos; T := '';
    while FPos <= FLen do
    begin
      if FSql[FPos] = '''' then
      begin
        if (FPos < FLen) and (FSql[FPos+1] = '''') then
        begin
          T := T + Copy(FSql, Start, FPos - Start) + '''';
          Inc(FPos, 2); Start := FPos; Continue;
        end;
        T := T + Copy(FSql, Start, FPos - Start);
        Inc(FPos); Result := True; Exit;
      end;
      Inc(FPos);
    end;
    raise Exception.Create('Kapanmamis string sabiti');
  end;

  // Çift tırnaklı tanımlayıcı (quoted identifier)
  if FSql[FPos] = '"' then
  begin
    Inc(FPos); Start := FPos; T := '';
    while FPos <= FLen do
    begin
      if FSql[FPos] = '"' then
      begin
        T := T + Copy(FSql, Start, FPos - Start);
        Inc(FPos); Result := True; Exit;
      end;
      Inc(FPos);
    end;
    raise Exception.Create('Kapanmamis tanimla (")');
  end;

  // Backtick tanımlayıcı `col`
  if FSql[FPos] = '`' then
  begin
    Inc(FPos); Start := FPos; T := '';
    while FPos <= FLen do
    begin
      if FSql[FPos] = '`' then
      begin
        T := T + Copy(FSql, Start, FPos - Start);
        Inc(FPos); Result := True; Exit;
      end;
      Inc(FPos);
    end;
    raise Exception.Create('Kapanmamis tanimla (`)');
  end;

  // Sayı: tam veya ondalıklı
  if IsDigit(FSql[FPos]) then
  begin
    Start := FPos;
    while (FPos <= FLen) and IsDigit(FSql[FPos]) do Inc(FPos);
    if (FPos <= FLen) and (FSql[FPos] = '.') and
       (FPos < FLen) and IsDigit(FSql[FPos+1]) then
    begin
      Inc(FPos);
      while (FPos <= FLen) and IsDigit(FSql[FPos]) do Inc(FPos);
    end;
    T := Copy(FSql, Start, FPos - Start);
    Result := True; Exit;
  end;

  // Tanımlayıcı veya anahtar kelime
  if IsAlpha(FSql[FPos]) then
  begin
    Start := FPos;
    while (FPos <= FLen) and IsAlNum(FSql[FPos]) do Inc(FPos);
    T := Copy(FSql, Start, FPos - Start);
    Result := True; Exit;
  end;

  // Operatörler
  case FSql[FPos] of
    '<', '>',  '!':
      begin
        T := FSql[FPos]; Inc(FPos);
        if (FPos <= FLen) and (FSql[FPos] = '=') then begin T := T + '='; Inc(FPos); end
        else if (T = '<') and (FPos <= FLen) and (FSql[FPos] = '>') then begin T := '<>'; Inc(FPos); end;
        Result := True;
      end;
    '|':
      begin
        T := '|'; Inc(FPos);
        if (FPos <= FLen) and (FSql[FPos] = '|') then begin T := '||'; Inc(FPos); end;
        Result := True;
      end;
    '(', ')', ',', '*', '=', '+', '-', '/', '%', '.', ';':
      begin T := FSql[FPos]; Inc(FPos); Result := True; end;
  else
    T := FSql[FPos]; Inc(FPos); Result := True;
  end;
end;

function TVDbParser.NextToken(out T: string): Boolean;
var dummy: Boolean;
begin
  Result := NextToken(T, dummy);
end;

function TVDbParser.PeekToken: string;
var SavePos, SaveIdx: Integer; T: string;
begin
  SavePos := FPos; SaveIdx := FParamIdx;
  if not NextToken(T) then T := '';
  FPos := SavePos; FParamIdx := SaveIdx;
  Result := UpperCase(T);
end;

function TVDbParser.PeekToken2: string;
var SavePos, SaveIdx: Integer; T: string;
begin
  SavePos := FPos; SaveIdx := FParamIdx;
  if not NextToken(T) then begin FPos := SavePos; FParamIdx := SaveIdx; Result := ''; Exit; end;
  if not NextToken(T) then T := '';
  FPos := SavePos; FParamIdx := SaveIdx;
  Result := UpperCase(T);
end;

procedure TVDbParser.Expect(const W: string);
var T: string;
begin
  if not NextToken(T) then
    raise Exception.CreateFmt('"%s" bekleniyor ama dosya sonu (%s)', [W, CurPos]);
  if not SameText(T, W) then
    raise Exception.CreateFmt('"%s" bekleniyor, "%s" bulundu (%s)', [W, T, CurPos]);
end;

procedure TVDbParser.ExpectToken(out T: string; out IsStringLit: Boolean);
begin
  if not NextToken(T, IsStringLit) then
    raise Exception.Create('Beklenmedik dosya sonu ' + CurPos);
end;

procedure TVDbParser.ExpectToken(out T: string);
var dummy: Boolean;
begin
  ExpectToken(T, dummy);
end;

function TVDbParser.TryEat(const W: string): Boolean;
var SavePos, SaveIdx: Integer; T: string;
begin
  SavePos := FPos; SaveIdx := FParamIdx;
  if not NextToken(T) then begin Result := False; Exit; end;
  if SameText(T, W) then
  begin
    Result := True;
  end
  else
  begin
    FPos := SavePos; FParamIdx := SaveIdx;
    Result := False;
  end;
end;

function TVDbParser.CurPos: string;
begin
  Result := 'konum=' + IntToStr(FPos);
end;

{ ============================================================
  Tür / Alan yardımcıları
  ============================================================ }

function TVDbParser.ParseTypeName: Byte;
var T, U: string;
begin
  ExpectToken(T); U := UpperCase(T);
  // Boyutlu tipler: VARCHAR(n), CHAR(n), DECIMAL(p,s) vs. — boyutu yut
  if U = 'VARCHAR'  then begin if TryEat('(') then begin ExpectToken(T); if not TryEat(')') then Expect(')'); end; Exit(VCT_STR); end;
  if U = 'CHAR'     then begin if TryEat('(') then begin ExpectToken(T); if not TryEat(')') then Expect(')'); end; Exit(VCT_STR); end;
  if U = 'TEXT'     then Exit(VCT_STR);
  if U = 'STRING'   then Exit(VCT_STR);
  if (U = 'INT') or (U = 'INTEGER') or (U = 'BIGINT') or (U = 'SMALLINT') or (U = 'TINYINT') then Exit(VCT_INT);
  if U = 'SERIAL'   then Exit(VCT_INT);
  if (U = 'FLOAT') or (U = 'DOUBLE') or (U = 'REAL') or (U = 'DECIMAL') or (U = 'NUMERIC') then
  begin
    if TryEat('(') then begin ExpectToken(T); TryEat(','); if TryEat(',') then ExpectToken(T); Expect(')'); end;
    Exit(VCT_FLOAT);
  end;
  if (U = 'BOOL') or (U = 'BOOLEAN') then Exit(VCT_BOOL);
  if U = 'DATE'     then Exit(VCT_DATE);
  if (U = 'DATETIME') or (U = 'TIMESTAMP') then Exit(VCT_DATETIME);
  if U = 'TIME'     then Exit(VCT_TIME);
  if (U = 'BLOB') or (U = 'BINARY') or (U = 'BYTEA') then Exit(VCT_BLOB);
  raise Exception.CreateFmt('Bilinmeyen kolon tipi: "%s" (%s)', [T, CurPos]);
end;

function TVDbParser.ReadFkAction: string;
var T: string;
begin
  ExpectToken(T); T := UpperCase(T);
  if T = 'RESTRICT'    then Exit(VDB_FK_RESTRICT);
  if T = 'CASCADE'     then Exit(VDB_FK_CASCADE);
  if T = 'SET'         then begin Expect('NULL'); Exit(VDB_FK_SETNULL); end;
  if (T = 'NO') or (T = 'NOTHING') then begin if T = 'NO' then Expect('ACTION'); Exit(VDB_FK_RESTRICT); end;
  if T = 'DEFAULT'     then Exit(VDB_FK_SETDEFAULT);
  raise Exception.CreateFmt('Gecersiz FK aksiyonu: "%s" (%s)', [T, CurPos]);
end;

procedure TVDbParser.ParseColDef(var C: TColDef; Stmt: TSqlCreateTableStmt = nil);
var T, U: string; SavePos, SaveIdx: Integer;
    fk: TFkDef;
begin
  C.Ctype := VCT_STR;
  C.NotNull := False;
  C.HasDef := False;
  C.Def := '';
  C.Unique := False;
  // Tip adını oku
  C.Ctype := ParseTypeName;

  // Nitelikleri tüket (PRIMARY KEY, NOT NULL, DEFAULT, AUTOINCREMENT, UNIQUE, REFERENCES, CHECK)
  while True do
  begin
    SavePos := FPos; SaveIdx := FParamIdx;
    if not NextToken(T) then Break;
    U := UpperCase(T);
    if U = 'PRIMARY' then
    begin
      Expect('KEY'); // ParseCreateTable PkIndex'i ayri yonetiyor
    end
    else if U = 'NOT' then
    begin
      Expect('NULL'); C.NotNull := True;
    end
    else if U = 'NULL' then
    begin
      // NULL explicitly -> nullable
    end
    else if U = 'DEFAULT' then
    begin
      ExpectToken(T);
      C.HasDef := True;
      C.Def := T;
    end
    else if (U = 'AUTOINCREMENT') or (U = 'AUTO_INCREMENT') then
    begin
      // AutoInc: tablo seviyesinde; buradan yonetilmiyor
    end
    else if U = 'UNIQUE' then
    begin
      C.Unique := True;
    end
    else if U = 'REFERENCES' then
    begin
      fk.Col := -1;
      if Stmt <> nil then fk.Col := Length(Stmt.Cols);
      ExpectToken(T); fk.RefTable := VDbNorm(T);
      fk.RefCol := '';
      if PeekToken = '(' then
      begin
        Expect('('); ExpectToken(T); fk.RefCol := VDbNorm(T); Expect(')');
      end;
      fk.OnDelete := VDB_FK_RESTRICT;
      fk.OnUpdate := VDB_FK_RESTRICT;
      while PeekToken = 'ON' do
      begin
        ExpectToken(T); // ON
        ExpectToken(T); // DELETE|UPDATE
        if UpperCase(T) = 'DELETE' then fk.OnDelete := ReadFkAction
        else if UpperCase(T) = 'UPDATE' then fk.OnUpdate := ReadFkAction;
      end;
      if Stmt <> nil then
      begin
        SetLength(Stmt.Fks, Length(Stmt.Fks) + 1);
        Stmt.Fks[High(Stmt.Fks)] := fk;
      end;
    end
    else if (U = 'CHECK') then
    begin
      Expect('(');
      if Stmt <> nil then
        Stmt.CheckExprs.Add(ParseExpr)
      else
        ParseExpr.Free;
      Expect(')');
    end
    else
    begin
      // Tanınmayan token → geri sar, döngüden çık
      FPos := SavePos; FParamIdx := SaveIdx;
      Break;
    end;
  end;
end;

{ ============================================================
  İfade Ayrıştırıcı
  ============================================================ }

function TVDbParser.ParseExpr: TSqlExprNode;
begin
  Result := ParseOrExpr;
end;

function TVDbParser.ParseOrExpr: TSqlExprNode;
var Right: TSqlExprNode; dummy: string;
begin
  Result := ParseAndExpr;
  while PeekToken = 'OR' do
  begin
    NextToken(dummy);
    Right := ParseAndExpr;
    Result := TSqlBinaryOpNode.Create(sboOr, Result, Right);
  end;
end;

function TVDbParser.ParseAndExpr: TSqlExprNode;
var Right: TSqlExprNode; T: string;
begin
  Result := ParseNotExpr;
  while PeekToken = 'AND' do
  begin
    NextToken(T);
    Right := ParseNotExpr;
    Result := TSqlBinaryOpNode.Create(sboAnd, Result, Right);
  end;
end;

function TVDbParser.ParseNotExpr: TSqlExprNode;
var T: string;
begin
  if PeekToken = 'NOT' then
  begin
    NextToken(T);
    Result := TSqlUnaryOpNode.Create(suoNot, ParseCmpExpr);
  end
  else
    Result := ParseCmpExpr;
end;

function TVDbParser.ParseCmpExpr: TSqlExprNode;
var
  T, U: string;
  Op: TSqlBinaryOp;
  Right: TSqlExprNode;
  Low, High: TSqlExprNode;
  IsNot: Boolean;
  SavePos, SaveIdx: Integer;
  likeNode: TSqlExprNode;
begin
  Result := ParseAddExpr;

  while True do
  begin
    SavePos := FPos; SaveIdx := FParamIdx;
    if not NextToken(T) then Break;
    U := UpperCase(T);

    if U = '='  then Op := sboEq
    else if (U = '<>') or (U = '!=') then Op := sboNeq
    else if U = '<'  then Op := sboLt
    else if U = '<=' then Op := sboLte
    else if U = '>'  then Op := sboGt
    else if U = '>=' then Op := sboGte
    else if U = 'LIKE' then Op := sboLike
    else if U = 'IS' then
    begin
      IsNot := TryEat('NOT');
      Expect('NULL');
      if IsNot then
        Result := TSqlUnaryOpNode.Create(suoIsNotNull, Result)
      else
        Result := TSqlUnaryOpNode.Create(suoIsNull, Result);
      Continue;
    end
    else if U = 'NOT' then
    begin
      U := PeekToken;
      if U = 'LIKE' then
      begin
        NextToken(T);
        Right := ParseAddExpr;
        // NOT LIKE = Like + NOT
        likeNode := TSqlBinaryOpNode.Create(sboLike, Result, Right);
        Result := TSqlUnaryOpNode.Create(suoNot, likeNode);
        Continue;
      end
      else if U = 'IN' then
      begin
        NextToken(T);
        Expect('(');
        Result := ParseInList(Result, True);
        Continue;
      end
      else if U = 'BETWEEN' then
      begin
        NextToken(T);
        Low := ParseAddExpr;
        Expect('AND');
        High := ParseAddExpr;
        Result := TSqlBetweenNode.Create(Result, Low, High, True);
        Continue;
      end
      else
      begin
        FPos := SavePos; FParamIdx := SaveIdx;
        Break;
      end;
    end
    else if U = 'IN' then
    begin
      Expect('(');
      Result := ParseInList(Result, False);
      Continue;
    end
    else if U = 'BETWEEN' then
    begin
      Low := ParseAddExpr;
      Expect('AND');
      High := ParseAddExpr;
      Result := TSqlBetweenNode.Create(Result, Low, High, False);
      Continue;
    end
    else
    begin
      FPos := SavePos; FParamIdx := SaveIdx;
      Break;
    end;

    Right := ParseAddExpr;
    Result := TSqlBinaryOpNode.Create(Op, Result, Right);
  end;
end;

function TVDbParser.ParseAddExpr: TSqlExprNode;
var T: string; Op: TSqlBinaryOp; Right: TSqlExprNode;
    SavePos, SaveIdx: Integer;
begin
  Result := ParseMulExpr;
  while True do
  begin
    SavePos := FPos; SaveIdx := FParamIdx;
    if not NextToken(T) then Break;
    if T = '+'  then Op := sboAdd
    else if T = '-' then Op := sboSub
    else if (T = '|') and (PeekToken = '|') then
    begin
      // || string concat -> sboAdd (string kontekstinde)
      NextToken(T);
      Op := sboAdd;
    end
    else begin FPos := SavePos; FParamIdx := SaveIdx; Break; end;
    Right := ParseMulExpr;
    Result := TSqlBinaryOpNode.Create(Op, Result, Right);
  end;
end;

function TVDbParser.ParseMulExpr: TSqlExprNode;
var T: string; Op: TSqlBinaryOp; Right: TSqlExprNode;
    SavePos, SaveIdx: Integer;
begin
  Result := ParseUnaryExpr;
  while True do
  begin
    SavePos := FPos; SaveIdx := FParamIdx;
    if not NextToken(T) then Break;
    if T = '*'  then Op := sboMul
    else if T = '/' then Op := sboDiv
    else if T = '%' then Op := sboMod
    else begin FPos := SavePos; FParamIdx := SaveIdx; Break; end;
    Right := ParseUnaryExpr;
    Result := TSqlBinaryOpNode.Create(Op, Result, Right);
  end;
end;

function TVDbParser.ParseUnaryExpr: TSqlExprNode;
var T: string;
begin
  if PeekToken = '-' then
  begin
    NextToken(T);
    Result := TSqlUnaryOpNode.Create(suoNeg, ParsePrimary);
  end
  else
    Result := ParsePrimary;
end;

function TVDbParser.ParseInList(Expr: TSqlExprNode; IsNot: Boolean): TSqlInNode;
var T: string; Item: TSqlExprNode;
begin
  Result := TSqlInNode.Create(Expr, IsNot);
  if PeekToken = ')' then begin NextToken(T); Exit; end; // bos IN listesi
  while True do
  begin
    Item := ParseExpr;
    Result.List.Add(Item);
    if PeekToken = ')' then begin NextToken(T); Break; end;
    Expect(',');
  end;
end;

function TVDbParser.ParseFuncCall(const FuncName: string): TSqlFuncCallNode;
var T: string; Arg: TSqlExprNode; IsStar, IsDistinct: Boolean;
begin
  IsStar := False; IsDistinct := False; Arg := nil;
  if PeekToken = '*' then
  begin
    NextToken(T); IsStar := True;
  end
  else if PeekToken = 'DISTINCT' then
  begin
    NextToken(T); IsDistinct := True;
    Arg := ParseExpr;
  end
  else if PeekToken <> ')' then
    Arg := ParseExpr;
  Expect(')');
  Result := TSqlFuncCallNode.Create(FuncName, Arg, IsStar, IsDistinct);
end;

function TVDbParser.ParsePrimary: TSqlExprNode;
var T, U, T2, TableQ: string; SavePos, SaveIdx: Integer;
    iv: Int64; fv: Double; IsLit: Boolean;
begin
  SavePos := FPos; SaveIdx := FParamIdx;
  ExpectToken(T, IsLit);
  U := UpperCase(T);

  // String sabiti (tek tırnaklı metin veya ? parametresi)
  if IsLit then
    Exit(TSqlLiteralNode.CreateStr(T));

  // NULL
  if U = 'NULL' then Exit(TSqlLiteralNode.CreateNull);

  // Booelan sabitleri
  if U = 'TRUE'  then Exit(TSqlLiteralNode.CreateBool(True));
  if U = 'FALSE' then Exit(TSqlLiteralNode.CreateBool(False));

  // Sayı sabiti
  if IsDigit(T[1]) then
  begin
    if Pos('.', T) > 0 then
    begin
      if VDbParseFloat(T, fv) then Exit(TSqlLiteralNode.CreateFloat(fv));
    end
    else
    begin
      if VDbParseInt(T, iv) then Exit(TSqlLiteralNode.CreateInt(iv));
    end;
    Exit(TSqlLiteralNode.CreateStr(T)); // fallback
  end;

  // Negatif sayı önüne geldiyse (-1 gibi)
  if T = '-' then
  begin
    ExpectToken(T2);
    if IsDigit(T2[1]) then
    begin
      if Pos('.', T2) > 0 then
      begin
        if VDbParseFloat(T2, fv) then Exit(TSqlLiteralNode.CreateFloat(-fv));
      end
      else if VDbParseInt(T2, iv) then
        Exit(TSqlLiteralNode.CreateInt(-iv));
    end;
    FPos := SavePos; FParamIdx := SaveIdx;
    Exit(ParseUnaryExpr);
  end;

  // String sabiti (tırnaklı — NextToken zaten tırnaksız döndürür)
  // Tırnaklı stringler NextToken tarafından zaten işlenip T'ye atanır;
  // ayrıca burada normal identifier olmayan her şeyi string sayalım:
  // Eğer T tırnak içinden geliyorsa IsAlpha kontrolü fail eder.
  // Ama NextToken '' değilse ve ilk char sayı/alpha değilse string gibi davran.
  if (Length(T) >= 1) and (not IsAlpha(T[1])) and (not IsDigit(T[1]))
     and (T <> '(') and (T <> ')') and (T <> ',') then
  begin
    // Operatör vs. → geri sar
    FPos := SavePos; FParamIdx := SaveIdx;
    raise Exception.CreateFmt('Beklenmedik token: "%s" (%s)', [T, CurPos]);
  end;

  // Fonksiyon çağrısı mı?
  if IsAlpha(T[1]) and (PeekToken = '(') then
  begin
    NextToken(T2); // '('
    Exit(ParseFuncCall(UpperCase(T)));
  end;

  // Kolon referansı: ident veya tablo.kolon
  if IsAlpha(T[1]) then
  begin
    TableQ := '';
    if PeekToken = '.' then
    begin
      NextToken(T2); // '.'
      TableQ := T;
      ExpectToken(T);
    end;
    Exit(TSqlColumnRefNode.Create(T, TableQ));
  end;

  // Alt sorgu veya gruplanmış ifade: (...)
  if T = '(' then
  begin
    Result := ParseExpr;
    Expect(')');
    Exit;
  end;

  // Daha önce NextToken tarafından string olarak okunan değer
  // (Tırnaklı stringler için — ilk karakter IsAlpha değil, sayı değil de string geldi)
  Exit(TSqlLiteralNode.CreateStr(T));
end;

{ ============================================================
  SELECT alt-parser'ları
  ============================================================ }

procedure TVDbParser.ParseSelectColumns(Stmt: TSqlSelectStmt);
var T, U: string; Item: TSelectColumnItem; SavePos, SaveIdx: Integer;
begin
  // SELECT * ?
  if PeekToken = '*' then
  begin
    NextToken(T); Exit; // Columns listesi boş = SELECT *
  end;

  while True do
  begin
    Item.Expr := ParseExpr;
    Item.Alias := '';
    // AS alias
    if PeekToken = 'AS' then
    begin
      NextToken(T); ExpectToken(Item.Alias);
    end
    else
    begin
      // örtük alias: FROM/WHERE/GROUP/ORDER/LIMIT/HAVING/UNION/EXCEPT/INTERSECT/';'/')' değilse
      SavePos := FPos; SaveIdx := FParamIdx;
      if NextToken(T) then
      begin
        U := UpperCase(T);
        if not (U = 'FROM') and not (U = 'WHERE') and not (U = 'GROUP') and
           not (U = 'ORDER') and not (U = 'LIMIT') and not (U = 'HAVING') and
           not (U = 'UNION') and not (U = 'EXCEPT') and not (U = 'INTERSECT') and
           not (U = ',') and not (U = ';') and not (U = ')') then
          Item.Alias := T   // örtük alias
        else
          begin FPos := SavePos; FParamIdx := SaveIdx; end;
      end;
    end;
    Stmt.Columns.Add(Item);

    if PeekToken = ',' then begin NextToken(T); Continue; end;
    Break;
  end;
end;

procedure TVDbParser.ParseFromClause(Stmt: TSqlSelectStmt);
var T, U: string; SavePos, SaveIdx: Integer;
begin
  ExpectToken(T); Stmt.FromTable := VDbNorm(T);
  // Alias kontrolü
  SavePos := FPos; SaveIdx := FParamIdx;
  if NextToken(T) then
  begin
    U := UpperCase(T);
    if (U = 'AS') then ExpectToken(Stmt.FromAlias)
    else if not (U = 'WHERE') and not (U = 'INNER') and not (U = 'LEFT') and
            not (U = 'JOIN')  and not (U = 'GROUP') and not (U = 'ORDER') and
            not (U = 'LIMIT') and not (U = 'HAVING') and not (U = 'UNION') and
            not (U = 'EXCEPT') and not (U = 'INTERSECT') and
            not (U = ';') and not (U = ')') then
      Stmt.FromAlias := T
    else
      begin FPos := SavePos; FParamIdx := SaveIdx; end;
  end;
end;

procedure TVDbParser.ParseJoinClause(Stmt: TSqlSelectStmt);
var T, U: string; SavePos, SaveIdx: Integer;
begin
  Stmt.HasJoin := True;
  Stmt.Join.OnCondition := nil;
  if PeekToken = 'JOIN' then NextToken(T);
  // Tablo adi
  ExpectToken(T); Stmt.Join.Table := VDbNorm(T);
  Stmt.Join.Alias := '';
  // Alias
  if PeekToken = 'AS' then begin NextToken(T); ExpectToken(Stmt.Join.Alias); end
  else
  begin
    SavePos := FPos; SaveIdx := FParamIdx;
    if NextToken(T) then
    begin
      if UpperCase(T) = 'ON' then begin FPos := SavePos; FParamIdx := SaveIdx; end
      else Stmt.Join.Alias := T;
    end;
  end;
  // ON kosulu
  Expect('ON');
  Stmt.Join.OnCondition := ParseExpr;
end;

procedure TVDbParser.ParseGroupBy(Stmt: TSqlSelectStmt);
var T: string;
begin
  // GROUP zaten yutuldu
  Expect('BY');
  while True do
  begin
    ExpectToken(T); Stmt.GroupByCols.Add(VDbNorm(T));
    if PeekToken = ',' then begin NextToken(T); Continue; end;
    Break;
  end;
  // HAVING
  if PeekToken = 'HAVING' then
  begin
    NextToken(T);
    Stmt.HavingClause := ParseExpr;
  end;
end;

procedure TVDbParser.ParseOrderBy(Stmt: TSqlSelectStmt);
var T, U: string; Item: TOrderItem;
begin
  // ORDER zaten yutuldu
  Expect('BY');
  while True do
  begin
    Item.Expr := ParseExpr;
    Item.Desc := False;
    U := PeekToken;
    if U = 'DESC' then begin NextToken(T); Item.Desc := True; end
    else if U = 'ASC' then NextToken(T);
    Stmt.OrderBy.Add(Item);
    if PeekToken = ',' then begin NextToken(T); Continue; end;
    Break;
  end;
end;

{ ============================================================
  SELECT cümlesi
  ============================================================ }

function TVDbParser.ParseSelect: TSqlSelectStmt;
var T, U: string;
    limIv, offIv: Int64;
begin
  Result := TSqlSelectStmt.Create;
  try
    // DISTINCT
    if PeekToken = 'DISTINCT' then begin NextToken(T); Result.IsDistinct := True; end;

    // Kolon listesi
    ParseSelectColumns(Result);

    // FROM
    if PeekToken <> 'FROM' then
    begin
      // FROM'suz SELECT: sabit ifadeler (SELECT 1, 'abc')
      Result.LimitVal := -1; Result.OffsetVal := 0;
      Exit;
    end;
    NextToken(T); // FROM yut

    ParseFromClause(Result);

    // JOIN
    U := PeekToken;
    if U = 'INNER' then begin NextToken(T); Result.Join.JoinType := jtInner; ParseJoinClause(Result); end
    else if U = 'LEFT' then begin NextToken(T); Result.Join.JoinType := jtLeft; ParseJoinClause(Result); end
    else if U = 'JOIN' then begin NextToken(T); Result.HasJoin := True; Result.Join.JoinType := jtInner; ParseJoinClause(Result); end;

    // Birden fazla JOIN kontrolü
    U := PeekToken;
    if (U = 'JOIN') or (U = 'INNER') or (U = 'LEFT') then
      raise Exception.Create('birden fazla JOIN desteklenmiyor (en fazla 2 tablo)');

    // WHERE
    if PeekToken = 'WHERE' then begin NextToken(T); Result.WhereClause := ParseExpr; end;

    // GROUP BY
    if PeekToken = 'GROUP' then begin NextToken(T); ParseGroupBy(Result); end;

    // ORDER BY
    if PeekToken = 'ORDER' then begin NextToken(T); ParseOrderBy(Result); end;

    // LIMIT / OFFSET
    if PeekToken = 'LIMIT' then
    begin
      NextToken(T); ExpectToken(T);
      if VDbParseInt(T, limIv) then Result.LimitVal := limIv else Result.LimitVal := -1;
      if PeekToken = 'OFFSET' then
      begin
        NextToken(T); ExpectToken(T);
        if VDbParseInt(T, limIv) then Result.OffsetVal := limIv else Result.OffsetVal := 0;
      end;
    end;
    if PeekToken = 'OFFSET' then
    begin
      NextToken(T); ExpectToken(T);
      if VDbParseInt(T, offIv) then Result.OffsetVal := offIv;
    end;

    // SET OP: UNION [ALL] / EXCEPT / INTERSECT
    U := PeekToken;
    if (U = 'UNION') or (U = 'EXCEPT') or (U = 'INTERSECT') then
    begin
      NextToken(T);
      if U = 'UNION' then
      begin
        if PeekToken = 'ALL' then begin NextToken(T); Result.SetOp := sokUnionAll; end
        else Result.SetOp := sokUnion;
      end
      else if U = 'EXCEPT' then Result.SetOp := sokExcept
      else Result.SetOp := sokIntersect;

      // Sağ taraf SELECT
      Expect('SELECT');
      Result.RightSelect := ParseSelect;
    end;

  except
    Result.Free;
    raise;
  end;
end;

{ ============================================================
  INSERT
  ============================================================ }

function TVDbParser.ParseInsert: TSqlInsertStmt;
var T: string; i: Integer; Row: TInsertValuesRow; Expr: TSqlExprNode;
begin
  Result := TSqlInsertStmt.Create;
  try
    Expect('INTO');
    ExpectToken(T); Result.Table := VDbNorm(T);

    // Kolon listesi opsiyonel: INSERT INTO t VALUES(...) veya INSERT INTO t () ...
    if PeekToken = '(' then
    begin
      NextToken(T);
      if PeekToken = ')' then
      begin
        NextToken(T); // boş kolon listesi
      end
      else
      begin
        i := 0;
        while True do
        begin
          ExpectToken(T);
          SetLength(Result.Columns, i + 1);
          Result.Columns[i] := VDbNorm(T);
          Inc(i);
          if PeekToken = ')' then begin NextToken(T); Break; end;
          Expect(',');
        end;
      end;
    end;

    // VALUES veya DEFAULT VALUES
    T := UpperCase(PeekToken);
    if T = 'DEFAULT' then
    begin
      while True do
      begin
        NextToken(T);
        Expect('VALUES');
        Row := TList<TSqlExprNode>.Create;
        Result.ValuesRows.Add(Row);
        if PeekToken = ',' then
        begin
          NextToken(T);
          if UpperCase(PeekToken) = 'DEFAULT' then Continue
          else raise Exception.CreateFmt('DEFAULT VALUES bekleniyor, "%s" bulundu (%s)', [PeekToken, CurPos]);
        end;
        Break;
      end;
    end
    else if T = 'VALUES' then
    begin
      NextToken(T);
      // Çoklu satır: VALUES (a,b), (c,d)
      while True do
      begin
        Expect('(');
        Row := TList<TSqlExprNode>.Create;
        if PeekToken = ')' then
        begin
          NextToken(T); // boş VALUES ()
        end
        else
        begin
          while True do
          begin
            Expr := ParseExpr;
            Row.Add(Expr);
            if PeekToken = ')' then begin NextToken(T); Break; end;
            Expect(',');
          end;
        end;
        Result.ValuesRows.Add(Row);
        if PeekToken = ',' then begin NextToken(T); Continue; end;
        Break;
      end;
    end
    else if T = 'SELECT' then
    begin
      NextToken(T);
      Result.SelectSrc := ParseSelect;
    end
    else
      raise Exception.CreateFmt('VALUES veya SELECT bekleniyor, "%s" bulundu (%s)',
        [PeekToken, CurPos]);

  except
    Result.Free;
    raise;
  end;
end;

{ ============================================================
  UPDATE
  ============================================================ }

function TVDbParser.ParseUpdate: TSqlUpdateStmt;
var T: string; Asgn: TUpdateAssignment;
begin
  Result := TSqlUpdateStmt.Create;
  try
    ExpectToken(T); Result.Table := VDbNorm(T);
    Expect('SET');
    while True do
    begin
      ExpectToken(Asgn.ColName); Asgn.ColName := VDbNorm(Asgn.ColName);
      Expect('=');
      Asgn.Expr := ParseExpr;
      Result.Assignments.Add(Asgn);
      if PeekToken = ',' then begin NextToken(T); Continue; end;
      Break;
    end;
    if PeekToken = 'WHERE' then begin NextToken(T); Result.WhereClause := ParseExpr; end;
  except
    Result.Free;
    raise;
  end;
end;

{ ============================================================
  DELETE
  ============================================================ }

function TVDbParser.ParseDelete: TSqlDeleteStmt;
var T: string;
begin
  Result := TSqlDeleteStmt.Create;
  try
    Expect('FROM');
    ExpectToken(T); Result.Table := VDbNorm(T);
    if PeekToken = 'WHERE' then begin NextToken(T); Result.WhereClause := ParseExpr; end;
  except
    Result.Free;
    raise;
  end;
end;

{ ============================================================
  CREATE TABLE
  ============================================================ }

function TVDbParser.ParseCreateTable: TSqlCreateTableStmt;
var T, U: string; C: TColDef; i: Integer;
    Fk: TFkDef; fkColName, fkRef, fkRefCol: string;
    chkText: string; depth: Integer;
    pname: string; k: Integer; isPK: Boolean;
begin
  Result := TSqlCreateTableStmt.Create;
  try
    if PeekToken = 'IF' then
    begin
      NextToken(T); Expect('NOT'); Expect('EXISTS');
      Result.IfNotExists := True;
    end;
    ExpectToken(T); Result.Table := VDbNorm(T);
    Expect('(');
    i := 0;

    while True do
    begin
      // PRIMARY KEY constraint (tablo seviyesi)
      U := PeekToken;
      if U = 'PRIMARY' then
      begin
        NextToken(T); Expect('KEY');
        Expect('(');
        ExpectToken(T); // pk kolon adı
        Result.PkIndex := i - 1; // arama: bir üstte tanımlanan kolon
        // Adı bul
        pname := VDbNorm(T);
        for k := 0 to High(Result.Cols) do
          if SameText(Result.Cols[k].Name, pname) then
          begin Result.PkIndex := k; Break; end;
        Expect(')');
        if PeekToken = ',' then begin NextToken(T); Continue; end;
        if PeekToken = ')' then begin NextToken(T); Break; end;
        Break;
      end;
      if U = 'UNIQUE' then
      begin
        NextToken(T); Expect('('); ExpectToken(T); Expect(')');
        if PeekToken = ',' then begin NextToken(T); Continue; end;
        if PeekToken = ')' then begin NextToken(T); Break; end;
        Break;
      end;
      if U = 'CHECK' then
      begin
        NextToken(T); // CHECK yut
        Expect('(');
        Result.CheckExprs.Add(ParseExpr);
        Expect(')');
        if PeekToken = ',' then begin NextToken(T); Continue; end;
        if PeekToken = ')' then begin NextToken(T); Break; end;
        Break;
      end;
      if U = 'FOREIGN' then
      begin
        NextToken(T); Expect('KEY');
        Expect('('); ExpectToken(fkColName); Expect(')');
        Expect('REFERENCES');
        ExpectToken(fkRef); fkRef := VDbNorm(fkRef);
        fkRefCol := '';
        if PeekToken = '(' then begin NextToken(T); ExpectToken(fkRefCol); Expect(')'); end;
        // TFkDef alanları
        Fk.Col := -1;
        // Col index'i bul
        for k := 0 to High(Result.Cols) do
          if SameText(Result.Cols[k].Name, VDbNorm(fkColName)) then
          begin Fk.Col := k; Break; end;
        fk.RefTable := fkRef;
        fk.RefCol := fkRefCol;
        fk.OnDelete := VDB_FK_RESTRICT;
        fk.OnUpdate := VDB_FK_RESTRICT;
        while PeekToken = 'ON' do
        begin
          NextToken(T); ExpectToken(T); U := UpperCase(T);
          if U = 'DELETE' then fk.OnDelete := ReadFkAction
          else if U = 'UPDATE' then fk.OnUpdate := ReadFkAction;
        end;
        SetLength(Result.Fks, Length(Result.Fks) + 1);
        Result.Fks[High(Result.Fks)] := fk;
        if PeekToken = ',' then begin NextToken(T); Continue; end;
        if PeekToken = ')' then begin NextToken(T); Break; end;
        Break;
      end;

      // Kolon tanımı
      ExpectToken(C.Name); C.Name := VDbNorm(C.Name);
      // PK belirleme: PRIMARY anahtar kelimesi ParseColDef'te tüketilir,
      // ama PkIndex'i burada ayarlamamız gerekiyor.
      isPK := (UpperCase(PeekToken) = 'PRIMARY') or
              (UpperCase(PeekToken2) = 'PRIMARY');
      ParseColDef(C, Result);
      if isPK then Result.PkIndex := i;
      SetLength(Result.Cols, i + 1);
      Result.Cols[i] := C;
      Inc(i);

      if PeekToken = ')' then begin NextToken(T); Break; end;
      if PeekToken = ',' then begin NextToken(T); Continue; end;
      Break;
    end;
    if PeekToken = ')' then NextToken(T);

  except
    Result.Free;
    raise;
  end;
end;

{ ============================================================
  ALTER TABLE
  ============================================================ }

function TVDbParser.ParseAlterTable: TSqlAlterTableStmt;
var T, U: string;
begin
  Result := TSqlAlterTableStmt.Create;
  try
    ExpectToken(T); Result.Table := VDbNorm(T);
    ExpectToken(T); U := UpperCase(T);

    if U = 'ADD' then
    begin
      // ADD [COLUMN] colname type ...
      if PeekToken = 'COLUMN' then NextToken(T);
      ExpectToken(Result.ColDef.Name); Result.ColDef.Name := VDbNorm(Result.ColDef.Name);
      Result.Action := ataAddColumn;
      ParseColDef(Result.ColDef);
      Result.DefaultVal := Result.ColDef.Def;
      // AFTER / FIRST
      if PeekToken = 'AFTER' then begin NextToken(T); ExpectToken(Result.PositionCol); end
      else if PeekToken = 'FIRST' then begin NextToken(T); Result.IsFirst := True; end;
    end
    else if U = 'DROP' then
    begin
      if PeekToken = 'COLUMN' then NextToken(T);
      ExpectToken(Result.ColName);
      Result.ColName := VDbNorm(Result.ColName);
      Result.Action := ataDropColumn;
    end
    else if U = 'RENAME' then
    begin
      U := PeekToken;
      if U = 'TO' then
      begin
        NextToken(T); ExpectToken(Result.NewName);
        Result.Action := ataRenameTable;
      end
      else
      begin
        if U = 'COLUMN' then NextToken(T);
        ExpectToken(Result.ColName); Result.ColName := VDbNorm(Result.ColName);
        Expect('TO'); ExpectToken(Result.NewName);
        Result.Action := ataRenameColumn;
      end;
    end
    else if U = 'MODIFY' then
    begin
      // MODIFY COLUMN col type
      if PeekToken = 'COLUMN' then NextToken(T);
      ExpectToken(Result.ColName); Result.ColName := VDbNorm(Result.ColName);
      ExpectToken(T); Result.NewTypeName := T;
      Result.Action := ataAlterColType;
    end
    else if U = 'ALTER' then
    begin
      // ALTER [COLUMN] col SET DEFAULT x | DROP DEFAULT | SET NOT NULL | DROP NOT NULL
      if PeekToken = 'COLUMN' then NextToken(T);
      ExpectToken(Result.ColName); Result.ColName := VDbNorm(Result.ColName);
      ExpectToken(T); U := UpperCase(T);
      if U = 'SET' then
      begin
        ExpectToken(T); U := UpperCase(T);
        if U = 'DEFAULT' then begin ExpectToken(Result.DefaultVal); Result.Action := ataSetDefault; end
        else if U = 'NOT' then begin Expect('NULL'); Result.Action := ataSetNotNull; end
        else raise Exception.CreateFmt('SET sonrasi DEFAULT veya NOT NULL bekleniyor, "%s" bulundu', [T]);
      end
      else if U = 'DROP' then
      begin
        ExpectToken(T); U := UpperCase(T);
        if U = 'DEFAULT' then Result.Action := ataDropDefault
        else if U = 'NOT' then begin Expect('NULL'); Result.Action := ataDropNotNull; end
        else raise Exception.CreateFmt('DROP sonrasi DEFAULT veya NOT NULL bekleniyor, "%s" bulundu', [T]);
      end
      else if U = 'TYPE' then
      begin
        ExpectToken(Result.NewTypeName); Result.Action := ataAlterColType;
      end
      else raise Exception.CreateFmt('ALTER COLUMN sonrasi bilinmeyen eylem: "%s"', [T]);
    end
    else
      raise Exception.CreateFmt('ALTER TABLE icin bilinmeyen eylem: "%s" (%s)', [T, CurPos]);

  except
    Result.Free;
    raise;
  end;
end;

{ ============================================================
  DROP TABLE
  ============================================================ }

function TVDbParser.ParseDropTable: TSqlDropTableStmt;
var T: string;
begin
  Result := TSqlDropTableStmt.Create;
  try
    if PeekToken = 'IF' then
    begin
      NextToken(T); Expect('EXISTS'); Result.IfExists := True;
    end;
    ExpectToken(T); Result.Table := VDbNorm(T);
  except
    Result.Free; raise;
  end;
end;

{ ============================================================
  CREATE INDEX / DROP INDEX
  ============================================================ }

function TVDbParser.ParseCreateIndex: TSqlCreateIndexStmt;
var T: string;
begin
  Result := TSqlCreateIndexStmt.Create;
  try
    if PeekToken = 'UNIQUE' then NextToken(T); // UNIQUE INDEX
    Expect('INDEX');
    ExpectToken(T); Result.IndexName := VDbNorm(T);
    Expect('ON');
    ExpectToken(T); Result.Table := VDbNorm(T);
    Expect('(');
    // COK KOLONLU: CREATE INDEX ix ON t(a, b, c)
    // (tek kolon = eski davranis)
    while True do
    begin
      ExpectToken(T);
      SetLength(Result.Cols, Length(Result.Cols) + 1);
      Result.Cols[High(Result.Cols)] := VDbNorm(T);
      if PeekToken <> ',' then Break;
      NextToken(T);   // ','
    end;
    Result.Col := Result.Cols[0];
    Expect(')');
  except
    Result.Free; raise;
  end;
end;

function TVDbParser.ParseDropIndex: TSqlDropIndexStmt;
var T: string;
begin
  Result := TSqlDropIndexStmt.Create;
  try
    if PeekToken = 'IF' then begin NextToken(T); Expect('EXISTS'); Result.IfExists := True; end;
    ExpectToken(T); Result.IndexName := VDbNorm(T);
  except
    Result.Free; raise;
  end;
end;

{ ============================================================
  ADMIN cümleleri (CREATE/DROP/OPEN/CLOSE DATABASE, BACKUP, VERIFY,
  VACUUM, REINDEX, SHOW/LIST)
  ============================================================ }

function TVDbParser.ParseAdmin(const Kw1, Kw2: string): TSqlAdminStmt;
var T, U: string; st: TSqlAdminStmt;
begin
  // Kw1 = ilk keyword (CREATE/DROP/OPEN/CLOSE/BACKUP/VERIFY/VACUUM/REINDEX/SHOW/LIST)
  // Kw2 = ikinci keyword (DATABASE, TABLES vs.) — bazı durumlarda boş
  Result := nil;

  if (Kw1 = 'VERIFY') then
    Exit(TSqlAdminStmt.Create(admVerify));

  if (Kw1 = 'VACUUM') then
    Exit(TSqlAdminStmt.Create(admVacuum));

  if (Kw1 = 'REINDEX') then
    Exit(TSqlAdminStmt.Create(admReindex));

  if (Kw1 = 'SHOW') or (Kw1 = 'LIST') then
  begin
    U := PeekToken;
    if U = 'TABLES' then begin NextToken(T); Exit(TSqlAdminStmt.Create(admShowTables)); end;
    if U = 'DATABASES' then begin NextToken(T); Exit(TSqlAdminStmt.Create(admListDbs)); end;
    raise Exception.CreateFmt('"%s" sonrasi TABLES veya DATABASES bekleniyor', [Kw1]);
  end;

  if Kw1 = 'BACKUP' then
  begin
    st := TSqlAdminStmt.Create(admBackupDb);
    Expect('TO'); ExpectToken(T); st.BackupPath := T;
    Exit(st);
  end;

  if Kw1 = 'CREATE' then
  begin
    // Kw2 = DATABASE
    st := TSqlAdminStmt.Create(admCreateDb);
    if PeekToken = 'IF' then begin NextToken(T); Expect('NOT'); Expect('EXISTS'); st.IfNotExists := True; end;
    ExpectToken(T); st.DbName := T;
    Exit(st);
  end;

  if Kw1 = 'DROP' then
  begin
    st := TSqlAdminStmt.Create(admDropDb);
    if PeekToken = 'IF' then begin NextToken(T); Expect('EXISTS'); st.IfExists := True; end;
    ExpectToken(T); st.DbName := T;
    Exit(st);
  end;

  if (Kw1 = 'OPEN') or (Kw1 = 'USE') then
  begin
    if PeekToken = 'DATABASE' then NextToken(T);
    st := TSqlAdminStmt.Create(admOpenDb);
    ExpectToken(T); st.DbName := T;
    Exit(st);
  end;

  if Kw1 = 'CLOSE' then
  begin
    if PeekToken = 'DATABASE' then NextToken(T);
    Exit(TSqlAdminStmt.Create(admCloseDb));
  end;

  raise Exception.CreateFmt('Bilinmeyen admin komutu: "%s %s"', [Kw1, Kw2]);
end;

{ ============================================================
  JSON (EXPORT / IMPORT)
  ============================================================ }

function TVDbParser.ParseJson(const Kw: string): TSqlJsonStmt;
var T: string;
begin
  // Kw = EXPORT veya IMPORT
  if UpperCase(Kw) = 'EXPORT' then
  begin
    Result := TSqlJsonStmt.Create(jsoExport);
    if PeekToken = 'TABLE' then
    begin
      NextToken(T); ExpectToken(T); Result.Table := VDbNorm(T);
    end;
    Expect('JSON');
    if PeekToken = 'TABLE' then
    begin
      NextToken(T); ExpectToken(T); Result.Table := VDbNorm(T);
    end;
    if TryEat('TO') then ;
    ExpectToken(Result.FilePath);
  end
  else // IMPORT
  begin
    Result := TSqlJsonStmt.Create(jsoImport);
    Expect('JSON');
    if TryEat('FROM') then ;
    ExpectToken(Result.FilePath);
  end;
end;

{ ============================================================
  Ana ayrıştırıcı: Parse
  ============================================================ }

function TVDbParser.Parse(const ASql: string;
                           const AParams: array of string): TSqlStmtNode;
var
  T, U, U2: string;
  i: Integer;
  idxStmt: TSqlCreateIndexStmt;
begin
  FSql := ASql;
  FLen := Length(ASql);
  FPos := 1;
  FParamIdx := 0;
  SetLength(FParams, Length(AParams));
  for i := 0 to High(AParams) do FParams[i] := AParams[i];

  if AtEnd then Exit(nil);

  ExpectToken(T); U := UpperCase(T);

  Result := nil;

  // ---- Transaction ----
  if U = 'BEGIN'    then Result := TSqlTxStmt.Create(txBegin)
  else if U = 'COMMIT'   then Result := TSqlTxStmt.Create(txCommit)
  else if U = 'ROLLBACK' then Result := TSqlTxStmt.Create(txRollback)

  // ---- DML ----
  else if U = 'SELECT' then Result := ParseSelect
  else if U = 'INSERT' then Result := ParseInsert
  else if U = 'UPDATE' then Result := ParseUpdate
  else if U = 'DELETE' then Result := ParseDelete

  // ---- DDL ----
  else if U = 'CREATE' then
  begin
    ExpectToken(T); U2 := UpperCase(T);
    if U2 = 'TABLE'    then Result := ParseCreateTable
    else if (U2 = 'INDEX') or (U2 = 'UNIQUE') then
    begin
      if U2 = 'UNIQUE' then begin Expect('INDEX'); end;
      idxStmt := TSqlCreateIndexStmt.Create;
      ExpectToken(T); idxStmt.IndexName := VDbNorm(T);
      Expect('ON');
      ExpectToken(T); idxStmt.Table := VDbNorm(T);
      Expect('(');
      // COK KOLONLU: CREATE INDEX ix ON t(a, b, c)
      while True do
      begin
        ExpectToken(T);
        SetLength(idxStmt.Cols, Length(idxStmt.Cols) + 1);
        idxStmt.Cols[High(idxStmt.Cols)] := VDbNorm(T);
        if PeekToken <> ',' then Break;
        NextToken(T);   // ','
      end;
      idxStmt.Col := idxStmt.Cols[0];
      Expect(')');
      Result := idxStmt;
    end
    else if U2 = 'DATABASE'  then Result := ParseAdmin('CREATE', 'DATABASE')
    else raise Exception.CreateFmt('CREATE sonrasi bilinmeyen: "%s" (%s)', [T, CurPos]);
  end
  else if U = 'DROP' then
  begin
    ExpectToken(T); U2 := UpperCase(T);
    if U2 = 'TABLE'    then Result := ParseDropTable
    else if U2 = 'INDEX'    then Result := ParseDropIndex
    else if U2 = 'DATABASE' then Result := ParseAdmin('DROP', 'DATABASE')
    else raise Exception.CreateFmt('DROP sonrasi bilinmeyen: "%s" (%s)', [T, CurPos]);
  end
  else if U = 'ALTER' then
  begin
    Expect('TABLE'); Result := ParseAlterTable;
  end

  // ---- Admin ----
  else if U = 'VERIFY'  then Result := ParseAdmin('VERIFY', '')
  else if U = 'VACUUM'  then Result := ParseAdmin('VACUUM', '')
  else if U = 'REINDEX' then Result := ParseAdmin('REINDEX', '')
  else if (U = 'SHOW') or (U = 'LIST') then Result := ParseAdmin(U, '')
  else if U = 'BACKUP'  then Result := ParseAdmin('BACKUP', '')
  else if (U = 'OPEN') or (U = 'USE') then Result := ParseAdmin(U, '')
  else if U = 'CLOSE'   then Result := ParseAdmin('CLOSE', '')

  // ---- JSON ----
  else if (U = 'EXPORT') or (U = 'IMPORT') then Result := ParseJson(U)
  else raise Exception.CreateFmt('Bilinmeyen SQL komutu: "%s" (%s)', [T, CurPos]);

  // Artık token kontrolü (sorgu bittiğinde sonda açıklanamayan token kalmamalı)
  if (Result <> nil) and not AtEnd then
  begin
    NextToken(T);
    if (T <> ';') and (T <> '') then
    begin
      Result.Free;
      Result := nil;
      raise Exception.CreateFmt('anlasilamayan ek: %s', [T]);
    end;
  end;
end;

end.
