unit VDbAst;

{ VDb SQL AST (Soyut Sozdizim Agaci) Modeli
  SQL cumleleri ve ifadeleri icin tip-guvenli, agac yapisinda dugum siniflari.
  Her dugum kendi alt agacini Destroy icinde guvenle serbest birakir (RAII). }

{$mode delphi}

interface

uses
  Classes, SysUtils, Generics.Collections, VDbTable, VDbErr;

type
  { Temel AST Dugumu }
  TSqlNode = class
  public
    destructor Destroy; override;
  end;

  { Temel Ifade Dugumu }
  TSqlExprNode = class(TSqlNode)
  end;

  { Sabit Degerler (Literal: Sayi, Metin, Boolean, NULL) }
  TSqlLiteralType = (sltNull, sltInt, sltFloat, sltString, sltBool);

  TSqlLiteralNode = class(TSqlExprNode)
  public
    LitType: TSqlLiteralType;
    IntVal: Int64;
    FloatVal: Double;
    StrVal: string;
    BoolVal: Boolean;
    constructor CreateNull;
    constructor CreateInt(const V: Int64);
    constructor CreateFloat(const V: Double);
    constructor CreateStr(const V: string);
    constructor CreateBool(const V: Boolean);
    function AsString: string;
  end;

  { Kolon Basvurusu (orn. "id" veya "t.ad") }
  TSqlColumnRefNode = class(TSqlExprNode)
  public
    TableQualifier: string;
    ColumnName: string;
    constructor Create(const ACol: string; const ATable: string = '');
    function QualifiedName: string;
  end;

  { Ikili Islemler (+, -, *, /, =, <>, <, <=, >, >=, LIKE, AND, OR) }
  TSqlBinaryOp = (
    sboAdd, sboSub, sboMul, sboDiv, sboMod,
    sboEq, sboNeq, sboLt, sboLte, sboGt, sboGte,
    sboLike, sboAnd, sboOr
  );

  TSqlBinaryOpNode = class(TSqlExprNode)
  public
    Op: TSqlBinaryOp;
    Left: TSqlExprNode;
    Right: TSqlExprNode;
    constructor Create(AOp: TSqlBinaryOp; ALeft, ARight: TSqlExprNode);
    destructor Destroy; override;
  end;

  { Tekli Islemler (NOT, Eksi, IS NULL, IS NOT NULL) }
  TSqlUnaryOp = (suoNot, suoNeg, suoIsNull, suoIsNotNull);

  TSqlUnaryOpNode = class(TSqlExprNode)
  public
    Op: TSqlUnaryOp;
    Operand: TSqlExprNode;
    constructor Create(AOp: TSqlUnaryOp; AOperand: TSqlExprNode);
    destructor Destroy; override;
  end;

  { IN / NOT IN Listesi }
  // Ileri bildirim: cumle dugumleri asagida tanimlidir.
  TSqlSelectStmt = class;
  TSqlInNode = class(TSqlExprNode)
  public
    Expr: TSqlExprNode;
    List: TList<TSqlExprNode>;
    IsNot: Boolean;
    // P5-2: IN (SELECT ...) icin alt sorgu (nil ise duz liste).
    // Doluysa List bos kalir; ic sorgu tek kolon dondurmelidir.
    SubSelect: TSqlSelectStmt;
    constructor Create(AExpr: TSqlExprNode; AIsNot: Boolean = False);
    destructor Destroy; override;
  end;

  { Alt Sorgu (P5-2): skaler deger veya EXISTS denetimi.
    Iliskisiz (uncorrelated) sorgular desteklenir; ic sorgu dis
    tablolara basvuramaz. }
  TSubqueryKind = (sqScalar, sqExists);

  TSqlSubqueryNode = class(TSqlExprNode)
  public
    Select: TSqlSelectStmt;
    Kind: TSubqueryKind;
    IsNot: Boolean;   // NOT EXISTS icin
    constructor CreateScalar(ASelect: TSqlSelectStmt);
    constructor CreateExists(ASelect: TSqlSelectStmt; AIsNot: Boolean = False);
    destructor Destroy; override;
  end;

  { BETWEEN / NOT BETWEEN Araligi }
  TSqlBetweenNode = class(TSqlExprNode)
  public
    Expr: TSqlExprNode;
    LowBound: TSqlExprNode;
    HighBound: TSqlExprNode;
    IsNot: Boolean;
    constructor Create(AExpr, ALow, AHigh: TSqlExprNode; AIsNot: Boolean = False);
    destructor Destroy; override;
  end;
  { Fonksiyon / Toplama Cagirisi (COUNT, SUM, AVG, MIN, MAX) }
  TSqlFuncCallNode = class(TSqlExprNode)
  public
    FuncName: string;     // COUNT, SUM, AVG, MIN, MAX
    Arg: TSqlExprNode;     // nil ise COUNT(*)
    IsStar: Boolean;       // COUNT(*) icin True
    IsDistinct: Boolean;   // COUNT(DISTINCT ...)
    constructor Create(const AFunc: string; AArg: TSqlExprNode; AIsStar: Boolean = False; AIsDistinct: Boolean = False);
    destructor Destroy; override;
  end;

  { CASE Ifadesi (P5-3): aranan (WHEN kosul) ve sade (CASE x WHEN deger)
    bicimler. ELSE yoksa sonuc NULL'dur. }
  TSqlCaseWhen = record
    Cond: TSqlExprNode;    // aranan: boolean kosul; sade: kiyas degeri
    Value: TSqlExprNode;
  end;

  TSqlCaseNode = class(TSqlExprNode)
  public
    Operand: TSqlExprNode; // nil = aranan CASE
    Whens: TList<TSqlCaseWhen>;
    ElseExpr: TSqlExprNode; // nil = ELSE yok
    constructor Create(AOperand: TSqlExprNode);
    destructor Destroy; override;
  end;

  { ---------------- CUMLE DUGUMLERI (STATEMENTS) ---------------- }

  TSqlStmtNode = class(TSqlNode)
  end;

  { SELECT Cikti Kolonu Tanimi }
  TSelectColumnItem = record
    Expr: TSqlExprNode;
    Alias: string;
  end;

  { ORDER BY Elemani }
  TOrderItem = record
    Expr: TSqlExprNode;
    Desc: Boolean;
    Collate: string;  // '' = bayt sirasi; 'TR' = Turk alfabesi
  end;

  { Pencere Fonksiyonu (P5-WIN): ROW_NUMBER/RANK/DENSE_RANK/COUNT/SUM/AVG/
    MIN/MAX/LAG/LEAD ... OVER ([PARTITION BY ...] [ORDER BY ...]).
    Yalniz SELECT listesinde ust-duzey oge olarak kullanilabilir;
    cerceve (ROWS/RANGE) desteklenmez. }
  TSqlWindowNode = class(TSqlExprNode)
  public
    FuncName: string;
    Arg: TSqlExprNode;          // nil: ROW_NUMBER/RANK/DENSE_RANK/COUNT(*)
    IsStar: Boolean;            // COUNT(*) icin
    Offset: Integer;            // LAG/LEAD kaydirma (varsayilan 1)
    Default: TSqlExprNode;      // LAG/LEAD varsayilan deger (nil = NULL)
    Partitions: TList<TSqlExprNode>;
    OrderBys: TList<TOrderItem>;
    constructor Create(const AFunc: string);
    destructor Destroy; override;
  end;

  { JOIN Tanimi }
  TJoinType = (jtInner, jtLeft, jtRight, jtFull);

  TJoinClause = record
    JoinType: TJoinType;
    Table: string;
    Alias: string;
    OnCondition: TSqlExprNode;
  end;

  { Kume Islemleri (UNION, UNION ALL, EXCEPT, INTERSECT) }
  TSetOpKind = (sokNone, sokUnion, sokUnionAll, sokExcept, sokIntersect);

  { WITH-CTE Tanim (P5-CTE): ad + ic sorgu. Kolon alias'lari (x(a,b))
    ve RECURSIVE desteklenmez. }
  TWithQuery = record
    Name: string;
    Select: TSqlSelectStmt;
  end;

  { SELECT Cumlesi }
  TSqlSelectStmt = class(TSqlStmtNode)
  public
    IsDistinct: Boolean;
    Columns: TList<TSelectColumnItem>;
    FromTable: string;
    FromAlias: string;
    HasJoin: Boolean;
    Join: TJoinClause;
    // P5-1: zincir JOIN'ler (3+ tablo). Ilk JOIN Join alaninda,
    // sonrakiler burada (soldan derine left-deep sirada uygulanir).
    MoreJoins: TList<TJoinClause>;
    // P5-CTE: WITH x AS (...), y AS (...) listesi (sira onemli:
    // sonrakiler oncekileri gorebilir). Bos olabilir, nil olmaz.
    WithQueries: TList<TWithQuery>;
    WhereClause: TSqlExprNode;
    GroupByCols: TList<string>;
    HavingClause: TSqlExprNode;
    OrderBy: TList<TOrderItem>;
    LimitVal: Integer;   // sinir yoksa -1
    OffsetVal: Integer;  // yoksa 0
    SetOp: TSetOpKind;
    RightSelect: TSqlSelectStmt;
    constructor Create;
    destructor Destroy; override;
  end;

  { INSERT Cumlesi }
  TInsertValuesRow = TList<TSqlExprNode>;

  TSqlInsertStmt = class(TSqlStmtNode)
  public
    Table: string;
    Columns: TStrArray;
    ValuesRows: TList<TInsertValuesRow>;
    SelectSrc: TSqlSelectStmt;  // INSERT INTO ... SELECT icin
    constructor Create;
    destructor Destroy; override;
  end;

  { UPDATE Cumlesi }
  TUpdateAssignment = record
    ColName: string;
    Expr: TSqlExprNode;
  end;

  TSqlUpdateStmt = class(TSqlStmtNode)
  public
    Table: string;
    Assignments: TList<TUpdateAssignment>;
    WhereClause: TSqlExprNode;
    constructor Create;
    destructor Destroy; override;
  end;

  { DELETE Cumlesi }
  TSqlDeleteStmt = class(TSqlStmtNode)
  public
    Table: string;
    WhereClause: TSqlExprNode;
    constructor Create;
    destructor Destroy; override;
  end;

  { CREATE TABLE Cumlesi }
  TSqlCreateTableStmt = class(TSqlStmtNode)
  public
    Table: string;
    IfNotExists: Boolean;
    Cols: TColArray;
    PkIndex: Integer;
    Checks: TWhereGroups;
    Fks: array of TFkDef;
    CheckExprs: TList<TSqlExprNode>;
    constructor Create;
    destructor Destroy; override;
  end;

  { ALTER TABLE Eylemleri }
  TAlterTableAction = (
    ataAddColumn, ataDropColumn, ataRenameColumn,
    ataAlterColType, ataSetDefault, ataDropDefault,
    ataSetNotNull, ataDropNotNull, ataRenameTable
  );

  TSqlAlterTableStmt = class(TSqlStmtNode)
  public
    Table: string;
    Action: TAlterTableAction;
    ColName: string;
    NewName: string;
    ColDef: TColDef;
    PositionCol: string;  // AFTER col
    IsFirst: Boolean;     // FIRST
    DefaultVal: string;
    NewTypeName: string;
    constructor Create;
  end;

  { DROP TABLE Cumlesi }
  TSqlDropTableStmt = class(TSqlStmtNode)
  public
    Table: string;
    IfExists: Boolean;
    constructor Create;
  end;

  { CREATE INDEX Cumlesi }
  TSqlCreateIndexStmt = class(TSqlStmtNode)
  public
    IndexName: string;
    Table: string;
    Col: string;
    Cols: array of string;   // cok kolonlu indeks (Col = Cols[0], geri uyum)
    constructor Create;
  end;

  { DROP INDEX Cumlesi }
  TSqlDropIndexStmt = class(TSqlStmtNode)
  public
    IndexName: string;
    IfExists: Boolean;
    constructor Create;
  end;

  { Transaction Cumlesi (BEGIN / COMMIT / ROLLBACK) }
  TTxKind = (txBegin, txCommit, txRollback);

  TSqlTxStmt = class(TSqlStmtNode)
  public
    Kind: TTxKind;
    constructor Create(AKind: TTxKind);
  end;

  { Yonetim ve Bakim Cumlesi }
  TAdminKind = (
    admCreateDb, admDropDb, admOpenDb, admCloseDb,
    admBackupDb, admVerify, admVacuum, admReindex,
    admListDbs, admShowTables
  );

  TSqlAdminStmt = class(TSqlStmtNode)
  public
    Kind: TAdminKind;
    DbName: string;
    BackupPath: string;
    IfExists: Boolean;
    IfNotExists: Boolean;
    constructor Create(AKind: TAdminKind);
  end;

  { JSON Export / Import Cumlesi }
  TJsonOpKind = (jsoExport, jsoImport);

  TSqlJsonStmt = class(TSqlStmtNode)
  public
    Kind: TJsonOpKind;
    Table: string;  // bos ise tum veritabani
    FilePath: string;
    constructor Create(AKind: TJsonOpKind);
  end;

  { SQL sorgu sonucu (VDbSql.pas ile paylasilan ortak tip) }
  TSqlResult = record
    Fields: TStrArray;
    Rows: TStrMatrix;
    Affected: Integer;
    Msg: string;
    // Son komutun dokundugu tablo (INSERT/UPDATE/DELETE/DDL).
    LastTable: string;
    // Islenen komut sayisi (betik icin)
    Stmts: Integer;
  end;

function SqlBinaryOpToStr(Op: TSqlBinaryOp): string;
function SqlBinaryOpFromStr(const S: string): TSqlBinaryOp;

implementation

function SqlBinaryOpToStr(Op: TSqlBinaryOp): string;
begin
  case Op of
    sboAdd: Result := '+';
    sboSub: Result := '-';
    sboMul: Result := '*';
    sboDiv: Result := '/';
    sboMod: Result := '%';
    sboEq:  Result := '=';
    sboNeq: Result := '<>';
    sboLt:  Result := '<';
    sboLte: Result := '<=';
    sboGt:  Result := '>';
    sboGte: Result := '>=';
    sboLike: Result := 'LIKE';
    sboAnd: Result := 'AND';
    sboOr:  Result := 'OR';
  else
    Result := '?';
  end;
end;

function SqlBinaryOpFromStr(const S: string): TSqlBinaryOp;
var
  u: string;
begin
  u := UpperCase(Trim(S));
  if u = '+' then Result := sboAdd
  else if u = '-' then Result := sboSub
  else if u = '*' then Result := sboMul
  else if u = '/' then Result := sboDiv
  else if u = '%' then Result := sboMod
  else if u = '=' then Result := sboEq
  else if (u = '<>') or (u = '!=') then Result := sboNeq
  else if u = '<' then Result := sboLt
  else if u = '<=' then Result := sboLte
  else if u = '>' then Result := sboGt
  else if u = '>=' then Result := sboGte
  else if u = 'LIKE' then Result := sboLike
  else if u = 'AND' then Result := sboAnd
  else if u = 'OR' then Result := sboOr
  else raise EVDbException.Create(ecSyntaxError, 'Gecersiz ikili operator: ' + S);
end;

{ TSqlNode }

destructor TSqlNode.Destroy;
begin
  inherited Destroy;
end;

{ TSqlLiteralNode }

constructor TSqlLiteralNode.CreateNull;
begin
  inherited Create;
  LitType := sltNull;
  StrVal := '';
  IntVal := 0;
  FloatVal := 0.0;
  BoolVal := False;
end;

constructor TSqlLiteralNode.CreateInt(const V: Int64);
begin
  inherited Create;
  LitType := sltInt;
  IntVal := V;
  StrVal := IntToStr(V);
  FloatVal := V;
  BoolVal := V <> 0;
end;

constructor TSqlLiteralNode.CreateFloat(const V: Double);
begin
  inherited Create;
  LitType := sltFloat;
  FloatVal := V;
  StrVal := VDbFloatToStr(V);
  IntVal := Trunc(V);
  BoolVal := V <> 0.0;
end;

constructor TSqlLiteralNode.CreateStr(const V: string);
begin
  inherited Create;
  LitType := sltString;
  StrVal := V;
  IntVal := 0;
  FloatVal := 0.0;
  BoolVal := V <> '';
end;

constructor TSqlLiteralNode.CreateBool(const V: Boolean);
begin
  inherited Create;
  LitType := sltBool;
  BoolVal := V;
  if V then StrVal := 'True' else StrVal := 'False';
  IntVal := Ord(V);
  FloatVal := Ord(V);
end;

function TSqlLiteralNode.AsString: string;
begin
  Result := StrVal;
end;

{ TSqlColumnRefNode }

constructor TSqlColumnRefNode.Create(const ACol: string; const ATable: string);
begin
  inherited Create;
  ColumnName := VDbNorm(ACol);
  TableQualifier := VDbNorm(ATable);
end;

function TSqlColumnRefNode.QualifiedName: string;
begin
  if TableQualifier <> '' then
    Result := TableQualifier + '.' + ColumnName
  else
    Result := ColumnName;
end;

{ TSqlBinaryOpNode }

constructor TSqlBinaryOpNode.Create(AOp: TSqlBinaryOp; ALeft, ARight: TSqlExprNode);
begin
  inherited Create;
  Op := AOp;
  Left := ALeft;
  Right := ARight;
end;

destructor TSqlBinaryOpNode.Destroy;
begin
  Left.Free;
  Right.Free;
  inherited Destroy;
end;

{ TSqlUnaryOpNode }

constructor TSqlUnaryOpNode.Create(AOp: TSqlUnaryOp; AOperand: TSqlExprNode);
begin
  inherited Create;
  Op := AOp;
  Operand := AOperand;
end;

destructor TSqlUnaryOpNode.Destroy;
begin
  Operand.Free;
  inherited Destroy;
end;

{ TSqlInNode }

constructor TSqlInNode.Create(AExpr: TSqlExprNode; AIsNot: Boolean);
begin
  inherited Create;
  Expr := AExpr;
  IsNot := AIsNot;
  List := TList<TSqlExprNode>.Create;
  SubSelect := nil;
end;

destructor TSqlInNode.Destroy;
var
  i: Integer;
begin
  Expr.Free;
  if List <> nil then
  begin
    for i := 0 to List.Count - 1 do
      List[i].Free;
    List.Free;
  end;
  SubSelect.Free;
  inherited Destroy;
end;

{ TSqlSubqueryNode }

constructor TSqlSubqueryNode.CreateScalar(ASelect: TSqlSelectStmt);
begin
  inherited Create;
  Select := ASelect;
  Kind := sqScalar;
  IsNot := False;
end;

constructor TSqlSubqueryNode.CreateExists(ASelect: TSqlSelectStmt;
  AIsNot: Boolean);
begin
  inherited Create;
  Select := ASelect;
  Kind := sqExists;
  IsNot := AIsNot;
end;

destructor TSqlSubqueryNode.Destroy;
begin
  Select.Free;
  inherited Destroy;
end;

{ TSqlBetweenNode }

constructor TSqlBetweenNode.Create(AExpr, ALow, AHigh: TSqlExprNode; AIsNot: Boolean);
begin
  inherited Create;
  Expr := AExpr;
  LowBound := ALow;
  HighBound := AHigh;
  IsNot := AIsNot;
end;

destructor TSqlBetweenNode.Destroy;
begin
  Expr.Free;
  LowBound.Free;
  HighBound.Free;
  inherited Destroy;
end;

{ TSqlFuncCallNode }

constructor TSqlFuncCallNode.Create(const AFunc: string; AArg: TSqlExprNode;
  AIsStar: Boolean; AIsDistinct: Boolean);
begin
  inherited Create;
  FuncName := UpperCase(AFunc);
  Arg := AArg;
  IsStar := AIsStar;
  IsDistinct := AIsDistinct;
end;

destructor TSqlFuncCallNode.Destroy;
begin
  Arg.Free;
  inherited Destroy;
end;

{ TSqlWindowNode }

constructor TSqlWindowNode.Create(const AFunc: string);
begin
  inherited Create;
  FuncName := UpperCase(AFunc);
  Arg := nil;
  IsStar := False;
  Offset := 1;
  Default := nil;
  Partitions := TList<TSqlExprNode>.Create;
  OrderBys := TList<TOrderItem>.Create;
end;

destructor TSqlWindowNode.Destroy;
var
  i: Integer;
begin
  Arg.Free;
  Default.Free;
  if Partitions <> nil then
  begin
    for i := 0 to Partitions.Count - 1 do
      Partitions[i].Free;
    Partitions.Free;
  end;
  if OrderBys <> nil then
  begin
    for i := 0 to OrderBys.Count - 1 do
      OrderBys[i].Expr.Free;
    OrderBys.Free;
  end;
  inherited Destroy;
end;

{ TSqlCaseNode }

constructor TSqlCaseNode.Create(AOperand: TSqlExprNode);
begin
  inherited Create;
  Operand := AOperand;
  Whens := TList<TSqlCaseWhen>.Create;
  ElseExpr := nil;
end;

destructor TSqlCaseNode.Destroy;
var
  i: Integer;
begin
  Operand.Free;
  if Whens <> nil then
  begin
    for i := 0 to Whens.Count - 1 do
    begin
      Whens[i].Cond.Free;
      Whens[i].Value.Free;
    end;
    Whens.Free;
  end;
  ElseExpr.Free;
  inherited Destroy;
end;

{ TSqlSelectStmt }

constructor TSqlSelectStmt.Create;
begin
  inherited Create;
  IsDistinct := False;
  Columns := TList<TSelectColumnItem>.Create;
  FromTable := '';
  FromAlias := '';
  HasJoin := False;
  Join.OnCondition := nil;
  MoreJoins := TList<TJoinClause>.Create;
  WithQueries := TList<TWithQuery>.Create;
  WhereClause := nil;
  GroupByCols := TList<string>.Create;
  HavingClause := nil;
  OrderBy := TList<TOrderItem>.Create;
  LimitVal := -1;
  OffsetVal := 0;
  SetOp := sokNone;
  RightSelect := nil;
end;

destructor TSqlSelectStmt.Destroy;
var
  i: Integer;
begin
  if Columns <> nil then
  begin
    for i := 0 to Columns.Count - 1 do
      Columns[i].Expr.Free;
    Columns.Free;
  end;
  if HasJoin then
    Join.OnCondition.Free;
  if MoreJoins <> nil then
  begin
    for i := 0 to MoreJoins.Count - 1 do
      MoreJoins[i].OnCondition.Free;
    MoreJoins.Free;
  end;
  if WithQueries <> nil then
  begin
    for i := 0 to WithQueries.Count - 1 do
      WithQueries[i].Select.Free;
    WithQueries.Free;
  end;
  WhereClause.Free;
  GroupByCols.Free;
  HavingClause.Free;
  if OrderBy <> nil then
  begin
    for i := 0 to OrderBy.Count - 1 do
      OrderBy[i].Expr.Free;
    OrderBy.Free;
  end;
  RightSelect.Free;
  inherited Destroy;
end;

{ TSqlInsertStmt }

constructor TSqlInsertStmt.Create;
begin
  inherited Create;
  Table := '';
  SetLength(Columns, 0);
  ValuesRows := TList<TInsertValuesRow>.Create;
  SelectSrc := nil;
end;

destructor TSqlInsertStmt.Destroy;
var
  i, j: Integer;
begin
  if ValuesRows <> nil then
  begin
    for i := 0 to ValuesRows.Count - 1 do
    begin
      for j := 0 to ValuesRows[i].Count - 1 do
        ValuesRows[i][j].Free;
      ValuesRows[i].Free;
    end;
    ValuesRows.Free;
  end;
  SelectSrc.Free;
  inherited Destroy;
end;

{ TSqlUpdateStmt }

constructor TSqlUpdateStmt.Create;
begin
  inherited Create;
  Table := '';
  Assignments := TList<TUpdateAssignment>.Create;
  WhereClause := nil;
end;

destructor TSqlUpdateStmt.Destroy;
var
  i: Integer;
begin
  if Assignments <> nil then
  begin
    for i := 0 to Assignments.Count - 1 do
      Assignments[i].Expr.Free;
    Assignments.Free;
  end;
  WhereClause.Free;
  inherited Destroy;
end;

{ TSqlDeleteStmt }

constructor TSqlDeleteStmt.Create;
begin
  inherited Create;
  Table := '';
  WhereClause := nil;
end;

destructor TSqlDeleteStmt.Destroy;
begin
  WhereClause.Free;
  inherited Destroy;
end;

{ TSqlCreateTableStmt }

constructor TSqlCreateTableStmt.Create;
begin
  inherited Create;
  Table := '';
  IfNotExists := False;
  SetLength(Cols, 0);
  PkIndex := 0;
  SetLength(Checks, 0);
  SetLength(Fks, 0);
  CheckExprs := TList<TSqlExprNode>.Create;
end;

destructor TSqlCreateTableStmt.Destroy;
var i: Integer;
begin
  if CheckExprs <> nil then
  begin
    for i := 0 to CheckExprs.Count - 1 do CheckExprs[i].Free;
    CheckExprs.Free;
  end;
  inherited Destroy;
end;

{ TSqlAlterTableStmt }

constructor TSqlAlterTableStmt.Create;
begin
  inherited Create;
  Table := '';
  Action := ataAddColumn;
  ColName := '';
  NewName := '';
  PositionCol := '';
  IsFirst := False;
  DefaultVal := '';
  NewTypeName := '';
end;

{ TSqlDropTableStmt }

constructor TSqlDropTableStmt.Create;
begin
  inherited Create;
  Table := '';
  IfExists := False;
end;

{ TSqlCreateIndexStmt }

constructor TSqlCreateIndexStmt.Create;
begin
  inherited Create;
  IndexName := '';
  Table := '';
  Col := '';
end;

{ TSqlDropIndexStmt }

constructor TSqlDropIndexStmt.Create;
begin
  inherited Create;
  IndexName := '';
  IfExists := False;
end;

{ TSqlTxStmt }

constructor TSqlTxStmt.Create(AKind: TTxKind);
begin
  inherited Create;
  Kind := AKind;
end;

{ TSqlAdminStmt }

constructor TSqlAdminStmt.Create(AKind: TAdminKind);
begin
  inherited Create;
  Kind := AKind;
  DbName := '';
  BackupPath := '';
  IfExists := False;
  IfNotExists := False;
end;

{ TSqlJsonStmt }

constructor TSqlJsonStmt.Create(AKind: TJsonOpKind);
begin
  inherited Create;
  Kind := AKind;
  Table := '';
  FilePath := '';
end;

end.
