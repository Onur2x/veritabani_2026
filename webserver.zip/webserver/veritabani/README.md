# VDB Motor v2 — Dokumantasyon

Saf Free Pascal ile yazilmis, harici DLL gerektirmeyen, tek dosyali
(`.odb`) iliskisel veritabani motoru. Ayrinti `SQL.md`'dedir.

## Motor Yapisi

```
SQL metni -> VDbParser -> VDbAst -> VDbExecutor -> VDbTable -> VDbCore -> .odb
```

| Birim | Rol |
|---|---|
| `VDbCore.pas` | Dusuk seviye append-only KV motor + `TCriticalSection` kilit |
| `VDbTable.pas` | Tablo katmani (sema, indeks, `FK`, kisitlar) + tablo kilidi (`Lock/Unlock`) |
| `VDbAst.pas` | Tip-guvenli AST dugum modeli |
| `VDbParser.pas` | Tokenizer + recursive-descent parser |
| `VDbExecutor.pas` | AST yurytucu (filtre, birlestirme, gruplama, siralama) |
| `VDbSql.pas` | Dis cephe (`TVSql.Exec`): betik bolme, otomatik transaction, DB dosya yonetimi |
| `VDbErr.pas` | Hata kodlari (`TVDbErrorCode`) + `EVDbException` |
| `VDbText.pas` | Turkce metin (`TrUpper/Lower`, UTF-8 uzunluk, `COLLATE TR` kiyas) |
| `VDbDataSet.pas` | `TDataSet` baglantisi (`TVDbQuery`) + `VDbDataSetReg.pas` kayit birimi |
| `VDbJson.pas` | JSON disari/iceri (`EXPORT`/`IMPORT JSON`) |
| `VDbWal.pas` | OLU KOD: derlenmiyor, cagrilmiyor (asagidaki dayaniklilik notuna bak) |
| `VDbSync.pas` | `fsync` + dosya kilidi + dizin flush |
| `VDbCrc32.pas` | CRC32 (IEEE 802.3) |
| `VDbTest.pas` | OLU KOD: hicbir proje kullanmiyor |

## Dogru Acilis Sirasi (4 tuzak)

```pascal
Kv := TVDb.Create;
Tb := TVTableDb.Create(Kv);
Sq := TVSql.Create(Tb);
try
  Kv.Open(Dir);    // veri klasoru (veritabani.odb burada aranir/olusturulur)
  Tb.Open(Dir);    // SART: semayi .odb icinden yukler
  ... Sq.Exec(...) ...
finally
  Sq.Free; Tb.Free; Kv.Free;
end;
```

1. `TVDb.Open` diye bir sey YOK. Dogrusu `TVDb.Create` + `Kv.Open(yol)`.
2. `Tb.Open(Dir)` SART. Atlanirsa sema yuklenmez: veri diskte dururken
   her sorgu `tablo yok` diye olur. (`CREATE TABLE` sirasinda fark edilmez,
   sunucu yeniden baslayinca patlar.)
3. `VDbWal.pas` olu kod. `ReplayWAL` stub: `.wal` varsa `False` doner,
   replay yapmaz. `WriteAheadWAL` her cagrida dosyayi bastan aciyordu
   (`fmCreate`); `PutRow` icindeki cagri kaldirildi.
4. `TVDb` + `TVTableDb` + `TVSql` sahipligi uygulamaya aittir (sirasiyla
   `Free` edilir); `Close` cagrisi zorunlu degildir ama `Tb.Close`
   sema sayaclarini kalici yapar.

## SQL Kapsami (ozet, ayrinti `SQL.md`)

`SELECT` (yildiz, alias, `DISTINCT`), `INNER/LEFT/RIGHT/FULL JOIN`
(zincir serbest, soldan derin), `WHERE` (karsilastirma, `LIKE`, `IN`,
`BETWEEN`, `IS NULL`, `AND/OR/NOT`), `GROUP BY` + `HAVING` + aggregate
(`COUNT/SUM/AVG/MIN/MAX`), `ORDER BY` (+ `COLLATE TR`), `LIMIT/OFFSET`,
kume islemleri (`UNION [ALL]/EXCEPT/INTERSECT`), alt sorgular
(`IN (SELECT)`, skaler, `EXISTS` — iliskisiz), `WITH-CTE` (zincir,
`JOIN` ile birlikte), `CASE WHEN` (aranan + sade), pencere fonksiyonlari
(`ROW_NUMBER/RANK/DENSE_RANK/COUNT/SUM/AVG/MIN/MAX/LAG/LEAD OVER`),
`INSERT` (coklu `VALUES`, `INSERT...SELECT`), `UPDATE` (satir-basi
aritmetik), `DELETE`, `DML/DDL transaction` (`BEGIN/COMMIT/ROLLBACK`,
DDL dahil geri alma), `ALTER TABLE`, `CREATE/DROP INDEX`, `VACUUM`,
`REINDEX`, `VERIFY`, `BACKUP`, `SHOW/LIST`, `EXPORT/IMPORT JSON`,
`?` parametre, `UPPER/LOWER/LENGTH` (Turkce duyarli).

Yok (bilerek): iliskili alt sorgu, `WITH RECURSIVE`, pencere cercevesi
(`ROWS/RANGE`), `CROSS` JOIN, `JOIN` + `GROUP BY`, CTE kolon alias'i.

## Hata Kodlari (`VDbErr.pas`)

Tum motor hatalari `EVDbException(ErrorCode)` ile firlar; mesaj metinleri
degismedi. Ornekler: `ecDuplicatePrimaryKey`, `ecUniqueViolation`,
`ecNotNullViolation`, `ecCheckViolation`, `ecForeignKeyViolation`,
`ecTableNotFound`, `ecColumnNotFound`, `ecSyntaxError`, `ecUnsupported`,
`ecDatabaseLocked`, `ecCorrupt`, `ecHashCollision`, `ecJsonError`.
`VDbErrorName(kod)` log/sunucu cevabi icin metin ad dondurur.

## Eszamanlilik

- `TVDb` (cekirdek) ve `TVTableDb` kendi kilitlerini tasir
  (`TCriticalSection`, recursive).
- `TVSql.Exec/ExecAll` cagrinin tamami tablo kilidi altinda calisir:
  ayni motoru paylasan thread'ler siralanir (okuma dahil).
- Dogrudan `TVTableDb` paylasan kod `Lock/Unlock` ile sarmalamalidir.
- Kaba taneli kilit: yazma sirasinda okumalar bekler.

## Baglanti Havuzu (`VDbPool.pas`)

`.odb` dosyasi exclusive kilitlidir: ayni dosyaya ikinci baglanti
acilamaz. Havuz bu yuzden tek motor (`TVDb`/`TVTableDb`) uzerinde `N`
adet `TVSql` ornegi yonetir — paralellik CARPMAZ, kaynak kullanimini
SINIRLAR (asiri yukte kuyruk + zaman asimi). Guvenlik P3 kilitleriyle
saglanir (her ornek bir thread'e aittir).

```pascal
Pool := TVDbPool.Create(TableDb, 8, 5000);  // boyut, zaman asimi (ms)
try
  Sq := Pool.Acquire;
  try
    R := Sq.Exec('SELECT ...', [...]);
  finally
    Pool.Release(Sq);
  end;
  R := Pool.Exec('SELECT ...');  // tek seferlik kisayol
finally
  Pool.Free;
end;
```

- `Acquire` bosta ornek yoksa `TimeoutMs` bekler, sonra `ecPoolTimeout`.
- `Close` yeni `Acquire` isteklerini reddeder (`ecPoolClosed`).
- Havuza ait olmayan ornek `Release` edilirse `ecInvalidArgument`.
- `Free` oncesi baglantilar geri verilmelidir.

## Turkce Destegi (`VDbText.pas`)

- `UPPER/LOWER`: `i->İ`, `I->ı` dogru cevrim (sistem yerel ayarindan bagimsiz).
- `LENGTH`: metinde karakter, `BLOB`'da bayt sayar.
- `ORDER BY x COLLATE TR`: Turk alfabesi sirasi
  (`...c,ç,d...g,ğ,h,ı,i...o,ö,p...s,ş,t...u,ü,v...`); bilinmeyen ad hata
  verir. Indeks sirasi bayt duzeninde oldugu icin `COLLATE TR` indeksi
  kullanmaz (dogru ama yavas yola duser).
- Harf duyarsiz arama deyimi: `WHERE UPPER(ad) = UPPER('cocuk')`.
- `=` karsilastirmasi bayt-ayni kalir (degismedi).

---

## `.odb` Dosya Formati (`v2` — Bozulmadan)

```
[Header: 16 byte]
  Magic (4) = $42444F56 ('VODB' LE)
  Ver   (4) = 2 (VDB_FILE_VER)
  Flags (4) = 0 (varsayilan) | ENCRYPTED(4) | COMPRESSED(8)
  Crc   (4) = Header CRC32
[Kilitler: Append-Only]
  Magic (4) = $56444231
  Crc   (4) = Kayit CRC32
  Seq   (8) = Sira numarasi
  Key   (8) = Anahtar (UInt64)
  ValLen(4) = Veri uzunlugu
  Flags (1) = 0(PUT) | 1(DEL) | 2(BATCHEND)
  Value (ValLen byte)
```

---

## Dayaniklilik (WAL YOK, sunlar var)

`WAL ile sifir veri kaybi` iddiasi GECERSIZDIR (`ReplayWAL` stub,
`VDbWal.pas` olu). Ayrica bu mimaride ayri WAL gereksizdir: `.odb`
dosyasinin kendisi log'dur (append-only + `CRC32` + `BATCHEND` commit
kaydi + acilis recovery'si — Bitcask modeli). Gercek garantiler:

- Kayit basi `CRC32`: bozuk kayit acilista tespit edilir, yirtik kuyruk
  budanir (`Verify` raporlar).
- Batch basi tek `fsync`: `COMMIT` ya hep ya hic yazar (`BATCHEND`
  isareti + recovery geri sarar).
- Commit-flush garantisi (P-DUR): basarili her `Exec` sonrasi kirli
  bayrak (`TVDb.Dirty`) kontrol edilir, yazma olduysa `Flush` cagrilir.
  `SyncWrite=False` olsa bile SQL katmaninda commit dayaniklidir;
  salt-okunur sorgularda syscall yok. Ham API (`TVTableDb` dogrudan)
  ile toplu yukleyenler bitince `Kv.Flush` cagirir.
- `Compact`: olu surumleri temizler (`.bak` birakir).
- JSON `.bak` zincirinden saglamdir; yedek icin `BACKUP`/`EXPORT JSON`
  kullanilir.

---

## `Faz D`: Motor Yenilikleri (`Iskelet`)

| Ozellik | `Flags` / `Durum` | `Acilama` |
|---|---|---|
| `Encryption` | `VDB_FLAG_ENCRYPTED = 4` | `AES` (`Value` sifreli) — `Iskelet` (`True/False`) |
| `Compression` | `VDB_FLAG_COMPRESSED = 8` | `ZLIB` (`Value` sikistirilmis) — `Iskelet` |
| `Streaming` | `StreamCursor(StartKey, PageSize)` | `Pagination` (`O(1)` `Cursor`, `Memory` `OOM` onler) — `Iskelet` |
| `AutoBackup` | `AutoBackup(BackupDir)` | `Timer` tabanli `.bak` (`FPath` `.auto.bak`) — `Iskelet` |
| `Memory-Mapped` | `MMF` (`Windows` `mmap`) | `Zero-Copy` (`Read` `2-5x` hizli) — `Iskelet` |
| `Query Planner` | `VDbSql.pas` (`Plan` `Cost-Based`) | `Index Scan` vs `Table Scan` — `Iskelet` (`VDbAst.pas` bagli) |

---

## `Test`

| Paket | Kapsam | Durum |
|---|---|---|
| `sqltest.lpi` | 52 grup, **569 kontrol** (tipler, kisitlar, `FK`, `JOIN`, kume, `ALTER`, transaction, alt sorgu, `CASE`, `CTE`, pencere, `RIGHT/FULL`, collation, `MIN/MAX` tip kiyasi, `BLOB`, crash kurtarma, legacy gecis, **F1 regresyon** — crash kurtarma kirpmasi, batch atomikligi, `ON DELETE CASCADE` dogru tetikleme, sarkan FK, kalici DDL, set-op kuyrugu, `ORDER BY` tipi, NULL uc-deger, `UPDATE`/`ORDER BY` bilinmeyen kolon, `DELETE DATABASE`, `LIMIT/OFFSET` dogrulama, `SUM` bos kume, parser derinlik, `SplitStatements`) | ✅ **569/569** |
| `vdscheck` (harici) | `TVDbQuery`: gezinti, bookmark, tipler, parametre, duzenleme, hata yollari (53 kontrol) | ✅ 53/53 |
| `vmtcheck` (harici) | 8 thread x 250 eszamanli `INSERT`/`SELECT` | ✅ kayipsiz |
| `vdbgui.lpi` | Basit yonetim GUI'si | ✅ derleniyor + linkleniyor |
| `had.lpi` | Gelismis yonetim arayuzu | ⚠️ derlenmiyor: unit arama yolu (`Can't find unit VDbCore`) — F1 oncesinden gelen ayri konu |
| `mtakipwebsrv.lpi` | Web sunucusu | ⚠️ derlenmiyor: unit arama yolu (`Can't find unit VDbSql`) — ayni ayri konu |

> **F1 (KRITIK) denetim kalemlerinin 23/23'u uygulandi ve her biri mutasyon
> testiyle dogrulandi** (duzeltme geri alininca ilgili test kirmizi oluyor).
> Test sayisi 409 -> 569 yukseldi (+160 assertion). Kanit tablosu:
> `DENETIM_VE_YOL_HARITASI.md` -> *F1 MUTASYON DOGRULAMA*.
> Degisikliklerin tamami `private` oldugu icin public API degismedi.
>
> **Bu turda bulunan, raporda olmayan ek hata:** SQL `UPDATE` satiri
> `Delete`+`Insert` ile yaziyordu; bu yuzden `ON DELETE CASCADE` bir
> UPDATE'in *silme* yarisiyla tetikleniyor ve **ilgisiz kolon**
> guncellenirken cocuk satirlari SILINIYORDU. Satir mantigi
> `TVTableDb.UpdateRowInPlace` ile tek kaynaga baglandi.

## `Derleme` (`Build`)

```
lazbuild sqltest.lpi          # test paketi -> sqltest.exe
lazbuild vdbgui.lpi           # basit yonetim GUI'si
lazbuild vdbcomponents.lpk    # TDataSet paketi (RunTime)
```

`sqltest.lpi` `LazUtils` pakedine baglidir (dosya kilidi `FileUtil`
uzerinden gelir).

---

## `TVDbQuery` — `TDataSet` Baglantisi (`VDbDataSet.pas`)

Standart veri bilesenleri (`TDBGrid`, `TDBEdit`, `TDBNavigator`,
`TDataSource`, FastReport) dogrudan baglanir. Paket:
`vdbcomponents.lpk` (RunTime; palet icin IDE'de `RunAndDesignTime`
secilir, bilesen `VDb` sayfasina gelir).

```pascal
Qry := TVDbQuery.Create(nil);
try
  Qry.SqlEngine := Sq;  // hazir TVSql ornegi (P3 kilidi paylasilir)
  Qry.SQL.Text := 'SELECT id, ad, maas FROM personel ORDER BY id';
  Qry.Open;
  DataSource1.DataSet := Qry;   // DBGrid'e bagla
  Qry.Edit;
  Qry.FieldByName('maas').AsFloat := 9500;
  Qry.Post;                     // UPDATE'ye cevrilir
finally
  Qry.Free;
end;
```

| Ozellik | Davranis |
|---|---|
| `Gezinti` | `First/Next/Prior/Last`, `RecNo/RecordCount`, bookmark |
| `Params` | `SQL`'deki `?` yer tutucularina sirayla karsilik gelir; sayi tutmazsa `ecInvalidArgument` |
| `Tipler` | Tek-tablo/sade sorguda semadan: `ftLargeint/ftFloat/ftBoolean/ftDate/ftTime/ftDateTime`; ifade/`JOIN` kolonlari `ftString` duser |
| `Duzenleme` | Tek tablo + sade kolonlar + ciktida `PK` sarti saglanirsa `Insert/Edit/Post/Delete` calisir (`CanModify=True`); saglanmazsa salt-okunur |
| `INSERT` | Yalniz dokunulan kolonlar yazilir (`DEFAULT` motora kalir); bos `AUTOINC` `PK` atlanir, deger uretilir |
| `PK` | Guncellenemez (`ecUnsupported`); once silip yeniden ekle |
| `NULL` | Motor `''` tasir: bos hucre `IsNull=True` |
| `Hata` | Tumu `EVDbException` + `ErrorCode` (metinler degismedi) |

Kurallar/kisitlar:
- `Open` yalniz satir donduren sonuc kabul eder (`SELECT`/`SHOW`/`LIST`).
  `INSERT` cumlesiyle `Open` denemesi cumleyi CALISTIRIR, sonra
  `ecInvalidArgument` verir (yan etkilidir).
- `Post` sirasinda kisit ihlali (or. `UNIQUE`, `NOT NULL`, `FK`) aynen
  yukari firlar; kayit duzenleme durumunda kalir (`Cancel` ile vazgec).
- `Post-insert` sonrasi imlec yeni satirdadir; `Post-update` konumu korur.
- Thread: ayni `TVSql`/`TVTableDb` paylasilabilir (`Exec` P3 kilidi altindadir).
