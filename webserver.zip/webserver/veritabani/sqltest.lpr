program sqltest;
{ VDB SQL tam test paketi.
  Tum desteklenen SQL komutlarini calistirir, beklenen sonucu karsilastirir.
  Derleme:  lazbuild sqltest.lpi
  Calistirma: sqltest.exe <calisma-klasoru>
  klasor verilmezse gecici klasor kullanilir. }

{$mode delphi}{$H+}

uses
  SysUtils, Classes, VDbCore, VDbTable, VDbSql;

var
  D: string;
  kv: TVDb;
  tb: TVTableDb;
  sq: TVSql;
  R: TSqlResult;
  nPass, nFail, nGrp: Integer;
  grpName: string;

const
  Q = '''';   // tek tirnak

{ ------------------------------------------------------------ yardimcilar }

procedure Grp(const N: string);
begin
  Inc(nGrp);
  grpName := N;
  WriteLn;
  WriteLn('== ', nGrp, '. ', N);
end;

procedure Ok(const Nm, E: string);
begin
  Inc(nPass);
  if E = '' then WriteLn('   OK   ', Nm)
  else WriteLn('   OK   ', Nm, '   [', E, ']');
end;

procedure No(const Nm, E: string);
begin
  Inc(nFail);
  WriteLn('   FAIL ', Nm, '   [', E, ']');
end;

procedure Chk(const Nm, Sql: string; const ExpectRows: Integer);
var e: string;
begin
  try
    R := sq.Exec(Sql);
    if ExpectRows >= 0 then
    begin
      if Length(R.Rows) = ExpectRows then Ok(Nm, IntToStr(Length(R.Rows)) + ' satir')
      else No(Nm, 'beklenen ' + IntToStr(ExpectRows) + ' satir, gelen ' +
                 IntToStr(Length(R.Rows)));
    end
    else Ok(Nm, '');
  except
    on E: Exception do No(Nm, '(' + E.Message + ')');
  end;
end;

procedure ChkVal(const Nm, Sql: string; RowIx, ColIx: Integer;
  const Want: string);
var got: string;
begin
  try
    R := sq.Exec(Sql);
    if (RowIx >= Length(R.Rows)) or (ColIx >= Length(R.Rows[RowIx])) then
    begin
      No(Nm, 'sonuc hucre yok (satir ' + IntToStr(RowIx) + '/' +
              IntToStr(Length(R.Rows)) + ')');
      Exit;
    end;
    got := R.Rows[RowIx][ColIx];
    if got = Want then Ok(Nm, got)
    else No(Nm, 'beklenen "' + Want + '" gelen "' + got + '"');
  except
    on E: Exception do No(Nm, '(' + E.Message + ')');
  end;
end;

// Sonuc matrisini tek satira dok (hata ayiklama / tani)
procedure Dump(const Nm, Sql: string);
var
  acc: string;
  k: Integer;
begin
  try
    R := sq.Exec(Sql);
    acc := '';
    for k := 0 to High(R.Rows) do
    begin
      if k > 0 then acc := acc + ' | ';
      acc := acc + R.Rows[k][0];
    end;
    Ok(Nm, acc);
  except
    on E: Exception do Ok(Nm, 'HATA: ' + E.Message);
  end;
end;

// Calistirilmasi beklenen, HATA vermesi gereken komut
procedure ChkErr(const Nm, Sql: string);
begin
  try
    sq.Exec(Sql);
    No(Nm, 'HATA VERMEDI (kabul edildi)');
  except
    on E: Exception do Ok(Nm, E.Message);
  end;
end;

procedure ChkInt(const Nm: string; const Got, Expect: Integer);
// TSqlResult sayisal alanlarini (Affected / Stmts) dogrudan dogrular.
begin
  if Got = Expect then Ok(Nm, IntToStr(Got))
  else No(Nm, 'beklenen ' + IntToStr(Expect) + ', gelen ' + IntToStr(Got));
end;

// Ayri bir calisma yerinde gecici acma/kapatma
procedure Fresh(const Nm: string);
var p: string;
begin
  p := D + '\' + Nm;
  ForceDirectories(p);
  if tb <> nil then begin tb.Close; kv.Close; sq.Free; tb.Free; kv.Free; end;
  kv := TVDb.Create; tb := TVTableDb.Create(kv); sq := TVSql.Create(tb);
  kv.Open(p);
  tb.Open(p);
end;

procedure UseDir(const Nm: string);
var p: string;
begin
  p := D + '\' + Nm;
  ForceDirectories(p);
  if tb <> nil then begin tb.Close; kv.Close; sq.Free; tb.Free; kv.Free; end;
  kv := TVDb.Create; tb := TVTableDb.Create(kv); sq := TVSql.Create(tb);
  kv.Open(p);
  tb.Open(p);
end;

procedure Shutdown;
begin
  if tb <> nil then
  begin
    tb.Close; kv.Close; sq.Free; tb.Free; kv.Free;
    sq := nil; tb := nil; kv := nil;
  end;
end;

{ ------------------------------------------------------------------ TESTLER }

procedure T01_Veritabani;
begin
  Grp('Veritabani komutlari (CREATE/DROP/LIST DATABASE)');
  UseDir('ana');
  Chk('CREATE DATABASE satis', 'CREATE DATABASE satis', -1);
  ChkErr('CREATE DATABASE var olan (hata)',
      'CREATE DATABASE satis');
  Chk('CREATE DATABASE IF NOT EXISTS (sessiz)',
      'CREATE DATABASE IF NOT EXISTS satis', -1);
  R := sq.Exec('LIST DATABASES');
  Ok('LIST DATABASES calisti', IntToStr(R.Affected) + ' veritabani');
  R := sq.Exec('SHOW DATABASES');
  Ok('SHOW DATABASES = LIST', IntToStr(R.Affected));
  ChkErr('DROP DATABASE etkini silemez', 'DROP DATABASE ana');
  Chk('DROP DATABASE satis', 'DROP DATABASE satis', -1);
  Chk('DROP DATABASE IF EXISTS (yok)', 'DROP DATABASE IF EXISTS satis', -1);
  ChkErr('DROP DATABASE olmayan (hata)', 'DROP DATABASE satis');
  ChkErr('veritabani adi yol ayirici (hata)',
      'CREATE DATABASE ' + Q + 'a\b' + Q);
  ChkErr('veritabani adi .. (hata)', 'CREATE DATABASE ' + Q + '..' + Q);
end;

procedure T02_Tipler;
begin
  Grp('Veri tipleri (INTEGER/FLOAT/TEXT/BOOL/DATE/DATETIME/TIME/BLOB)');
  UseDir('tip');
  sq.Exec('CREATE TABLE tip(id INTEGER PRIMARY KEY, i INTEGER, f FLOAT, ' +
          's TEXT, b BOOLEAN, d DATE, dt DATETIME, tm TIME, bl BLOB)');
  Chk('hepsine bir satir', 'INSERT INTO tip(i,f,s,b,d,dt,tm,bl) VALUES(' +
      '42, 3.5, ' + Q + 'merhaba' + Q + ', 1, ' + Q + '2024-01-15' + Q + ', ' +
      Q + '2024-01-15 10:30:00' + Q + ', ' + Q + '10:30:00' + Q + ', ' +
      Q + 'binary' + Q + ')', -1);
  ChkVal('INTEGER saklanir', 'SELECT i FROM tip', 0, 0, '42');
  ChkVal('FLOAT saklanir', 'SELECT f FROM tip', 0, 0, '3.5');
  ChkVal('TEXT saklanir', 'SELECT s FROM tip', 0, 0, 'merhaba');
  ChkVal('BOOLEAN saklanir', 'SELECT b FROM tip', 0, 0, 'True');
  ChkVal('DATE saklanir', 'SELECT d FROM tip', 0, 0, '2024-01-15');
  ChkVal('DATETIME saklanir', 'SELECT dt FROM tip', 0, 0, '2024-01-15 10:30:00');
  ChkVal('TIME saklanir', 'SELECT tm FROM tip', 0, 0, '10:30:00');
  ChkVal('BLOB saklanir', 'SELECT bl FROM tip', 0, 0, 'binary');
  ChkErr('INTEGER kolona metin (hata)',
      'INSERT INTO tip(i) VALUES(' + Q + 'abc' + Q + ')');
  ChkErr('DATE kolona bozuk tarih (hata)',
      'INSERT INTO tip(d) VALUES(' + Q + 'abc' + Q + ')');
  // Locale bagimsizlik: sistem tr-TR (ondalik ayirici = virgul) ama motor
  // daima NOKTA kullanir. Aksi halde "VALUES(0,5)" 4 deger sanilir ve
  // sessizce yanlis satir yazilir.
  sq.Exec('CREATE TABLE fl(id INTEGER PRIMARY KEY, f FLOAT)');
  sq.Exec('INSERT INTO fl(f) VALUES(2.25)');
  ChkVal('FLOAT nokta ile okunur (locale bagimsiz)', 'SELECT f FROM fl', 0, 0, '2.25');
  sq.Exec('INSERT INTO fl(f) VALUES(10)');
  ChkVal('FLOAT tam sayi', 'SELECT f FROM fl WHERE id=2', 0, 0, '10');
  ChkVal('FLOAT karsilastirma', 'SELECT COUNT(*) FROM fl WHERE f > 2', 0, 0, '2');
  ChkErr('ondalik VIRGUL deger ayirici sayilmaz (hata)',
      'INSERT INTO fl(id,f) VALUES(9,0,5)');
end;

procedure T03_CreateKisit;
begin
  Grp('CREATE TABLE kisitlari (PK/NOT NULL/UNIQUE/DEFAULT/CHECK/FK)');
  UseDir('kis');
  sq.Exec('CREATE TABLE ebeveyn(id INTEGER PRIMARY KEY, ad TEXT NOT NULL)');
  ChkErr('NOT NULL ihlali (hata)',
      'INSERT INTO ebeveyn(id,ad) VALUES(1,' + Q + Q + ')');
  Chk('gecerli satir', 'INSERT INTO ebeveyn(id,ad) VALUES(1,' + Q + 'Ali' + Q + ')', -1);
  ChkErr('PK tekrari (hata)',
      'INSERT INTO ebeveyn(id,ad) VALUES(1,' + Q + 'Veli' + Q + ')');
  sq.Exec('CREATE TABLE cocuk(id INTEGER PRIMARY KEY, pid INTEGER ' +
          'REFERENCES ebeveyn(id), yas INTEGER DEFAULT 0, ' +
          'puan FLOAT, etiket TEXT UNIQUE)');
  Chk('FK dogru deger', 'INSERT INTO cocuk(id,pid) VALUES(1,1)', -1);
  ChkErr('FK yanlis deger (hata)', 'INSERT INTO cocuk(id,pid) VALUES(2,99)');
  Chk('DEFAULT uygulandi', 'INSERT INTO cocuk(id) VALUES(2)', -1);
  ChkVal('DEFAULT degeri yazildi', 'SELECT yas FROM cocuk WHERE id=2', 0, 0, '0');
  Chk('UNIQUE ilk kullanim',
      'INSERT INTO cocuk(id,etiket) VALUES(3,' + Q + 'x' + Q + ')', -1);
  ChkErr('UNIQUE tekrari 2 (hata)',
      'INSERT INTO cocuk(id,etiket) VALUES(4,' + Q + 'x' + Q + ')');
  sq.Exec('CREATE TABLE yasli(id INTEGER PRIMARY KEY, y INTEGER, ' +
          'CHECK (y >= 0))');
  Chk('CHECK gecer', 'INSERT INTO yasli(id,y) VALUES(1,10)', -1);
  ChkErr('CHECK ihlali (hata)', 'INSERT INTO yasli(id,y) VALUES(2,-1)');
  sq.Exec('CREATE TABLE tek(id INTEGER PRIMARY KEY, v INTEGER CHECK (v > 0))');
  ChkErr('kolon ici CHECK (hata)', 'INSERT INTO tek(id,v) VALUES(1,0)');
end;

procedure T04_Insert;
begin
  Grp('INSERT bicimleri');
  UseDir('ins');
  sq.Exec('CREATE TABLE t(id INTEGER PRIMARY KEY, a TEXT, b INTEGER, ' +
          'c TEXT DEFAULT ' + Q + 'varsayilan' + Q + ')');
  Chk('sutun listeli', 'INSERT INTO t(a,b) VALUES(' + Q + 'x' + Q + ',1)', -1);
  Chk('sutun listesiz (sirayla)', 'INSERT INTO t VALUES(2,' + Q + 'y' + Q +
      ',2,' + Q + 'z' + Q + ')', -1);
  Chk('bos liste + bos VALUES (DEFAULT)',
      'INSERT INTO t() VALUES()', -1);
  Chk('DEFAULT VALUES kisayol', 'INSERT INTO t DEFAULT VALUES', -1);
  Chk('NULL deger', 'INSERT INTO t(a,b) VALUES(NULL,NULL)', -1);
  ChkErr('olmayan sutun (hata)',
      'INSERT INTO t(olmayan) VALUES(1)');
  ChkErr('deger sayisi uymaz (hata)',
      'INSERT INTO t(a,b) VALUES(' + Q + 'q' + Q + ')');
  Chk('5 satir yazildi', 'SELECT COUNT(*) FROM t', 1);
  R := sq.Exec('SELECT COUNT(*) FROM t');
  ChkVal('sayim dogru', 'SELECT COUNT(*) FROM t', 0, 0, '5');
  ChkVal('NULL okundu', 'SELECT a FROM t WHERE id=5', 0, 0, '');
end;

procedure T05_SelectTemel;
begin
  Grp('SELECT: yildiz, kolon listesi, alias, ORDER BY, LIMIT/OFFSET');
  UseDir('sel');
  sq.Exec('CREATE TABLE t(id INTEGER PRIMARY KEY, ad TEXT, yas INTEGER)');
  sq.Exec('INSERT INTO t(ad,yas) VALUES(' + Q + 'Ali' + Q + ',30)');
  sq.Exec('INSERT INTO t(ad,yas) VALUES(' + Q + 'Veli' + Q + ',20)');
  sq.Exec('INSERT INTO t(ad,yas) VALUES(' + Q + 'Zeynep' + Q + ',40)');
  sq.Exec('INSERT INTO t(ad,yas) VALUES(' + Q + 'Ayse' + Q + ',25)');
  Chk('SELECT *', 'SELECT * FROM t', 4);
  Chk('kolon listesi', 'SELECT ad,yas FROM t', 4);
  Chk('ORDER BY ASC', 'SELECT ad FROM t ORDER BY yas', 4);
  ChkVal('ORDER BY ASC ilk', 'SELECT ad FROM t ORDER BY yas', 0, 0, 'Veli');
  ChkVal('ORDER BY DESC ilk', 'SELECT ad FROM t ORDER BY yas DESC', 0, 0, 'Zeynep');
  Chk('coklu ORDER BY', 'SELECT ad FROM t ORDER BY yas ASC, ad DESC', 4);
  Chk('LIMIT 2', 'SELECT ad FROM t ORDER BY yas LIMIT 2', 2);
  ChkVal('LIMIT ilk kayit', 'SELECT ad FROM t ORDER BY yas LIMIT 2', 0, 0, 'Veli');
  Chk('LIMIT + OFFSET', 'SELECT ad FROM t ORDER BY yas LIMIT 2 OFFSET 1', 2);
  ChkVal('OFFSET kaydi', 'SELECT ad FROM t ORDER BY yas LIMIT 2 OFFSET 1', 0, 0, 'Ayse');
  Chk('OFFSET tek basina', 'SELECT ad FROM t ORDER BY yas OFFSET 3', 1);
  R := sq.Exec('SELECT ad AS isim FROM t ORDER BY id');
  Ok('AS alias', R.Fields[0] + ' = ' + R.Rows[0][0]);
  R := sq.Exec('SELECT ad isim2 FROM t ORDER BY id');
  Ok('AS`siz alias', R.Fields[0] + ' = ' + R.Rows[0][0]);
  Chk('tablo alias', 'SELECT x.ad FROM t x ORDER BY x.id', 4);
  ChkErr('olmayan tablo (hata)', 'SELECT * FROM yok');
  ChkErr('olmayan kolon (hata)', 'SELECT yok FROM t');
end;

procedure T06_Where;
begin
  Grp('WHERE operatorleri, AND/OR/parantez, LIKE, IS NULL');
  UseDir('whr');
  sq.Exec('CREATE TABLE t(id INTEGER PRIMARY KEY, ad TEXT, yas INTEGER, ' +
          'email TEXT)');
  sq.Exec('INSERT INTO t(ad,yas,email) VALUES(' + Q + 'Ali' + Q + ',30,' + Q + 'ali@x.com' + Q + ')');
  sq.Exec('INSERT INTO t(ad,yas,email) VALUES(' + Q + 'Veli' + Q + ',20,' + Q + 'veli@y.com' + Q + ')');
  sq.Exec('INSERT INTO t(ad,yas,email) VALUES(' + Q + 'Zeynep' + Q + ',40,NULL)');
  Chk('=', 'SELECT ad FROM t WHERE yas = 30', 1);
  Chk('<>', 'SELECT ad FROM t WHERE yas <> 30', 2);
  Chk('!=', 'SELECT ad FROM t WHERE yas != 30', 2);
  Chk('<', 'SELECT ad FROM t WHERE yas < 30', 1);
  Chk('>', 'SELECT ad FROM t WHERE yas > 30', 1);
  Chk('<=', 'SELECT ad FROM t WHERE yas <= 30', 2);
  Chk('>=', 'SELECT ad FROM t WHERE yas >= 30', 2);
  Chk('AND', 'SELECT ad FROM t WHERE yas > 20 AND yas < 35', 1);
  Chk('OR', 'SELECT ad FROM t WHERE yas = 20 OR yas = 40', 2);
  Chk('parentez', 'SELECT ad FROM t WHERE yas = 20 OR (yas > 30 AND yas < 35)', 1);
  Chk('LIKE %', 'SELECT ad FROM t WHERE ad LIKE ' + Q + 'A%' + Q, 1);
  Chk('LIKE % orta', 'SELECT ad FROM t WHERE email LIKE ' + Q + '%@y.com' + Q, 1);
  Chk('LIKE tam', 'SELECT ad FROM t WHERE ad LIKE ' + Q + 'Ali' + Q, 1);
  Chk('IS NULL', 'SELECT ad FROM t WHERE email IS NULL', 1);
  Chk('IS NOT NULL', 'SELECT ad FROM t WHERE email IS NOT NULL', 2);
  Chk('NULL = ile eslesmez', 'SELECT ad FROM t WHERE email = NULL', 0);
  Chk('NULL <> ile eslesmez', 'SELECT ad FROM t WHERE email <> NULL', 0);
  Chk('NULL LIKE ile eslesmez', 'SELECT ad FROM t WHERE email LIKE ' + Q + '%' + Q, 2);
  Chk('metin karsilastirma', 'SELECT ad FROM t WHERE ad = ' + Q + 'Ali' + Q, 1);
  ChkErr('olmayan operator (hata)', 'SELECT ad FROM t WHERE yas =~~ 3');
end;

procedure T07_TipKarsilastirma;
begin
  Grp('Tip-bilgili karsilastirma (TEXT 007 != 7)');
  UseDir('tipk');
  sq.Exec('CREATE TABLE t(id INTEGER PRIMARY KEY, s TEXT, n INTEGER)');
  sq.Exec('INSERT INTO t(s,n) VALUES(' + Q + '007' + Q + ',7)');
  sq.Exec('INSERT INTO t(s,n) VALUES(' + Q + '7' + Q + ',007)');
  Chk('TEXT: s = 7 (tirnaksiz literal = metin ' + Q + '7' + Q + ')',
      'SELECT s FROM t WHERE s = 7', 1);
  Chk('TEXT: ' + Q + '007' + Q + ' = ' + Q + '007' + Q,
      'SELECT s FROM t WHERE s = ' + Q + '007' + Q, 1);
  Chk('INTEGER: n = ' + Q + '007' + Q + ' (iki satirda da 7)',
      'SELECT n FROM t WHERE n = ' + Q + '007' + Q, 2);
  Chk('INTEGER: n = 7 (iki satir)', 'SELECT n FROM t WHERE n = 7', 2);
  Chk('BETWEEN (n=7 -> aralik disi)', 'SELECT s FROM t WHERE n BETWEEN 1 AND 5', 0);
  Chk('BETWEEN (n=7 -> aralik ici)', 'SELECT s FROM t WHERE n BETWEEN 5 AND 9', 2);
  Chk('IN (...) (n=7 -> eslesmez)',
      'SELECT s FROM t WHERE n IN (1,2,3)', 0);
  Chk('IN (...) (n=7 -> eslesir)',
      'SELECT s FROM t WHERE n IN (6,7,8)', 2);
  Chk('NOT IN (...)', 'SELECT s FROM t WHERE n NOT IN (1,2,3)', 2);
  Chk('TEXT BETWEEN (byte sirasi: ''007'' < ''7'')',
      'SELECT s FROM t WHERE s BETWEEN ' + Q + '7' + Q + ' AND ' + Q + '8' + Q, 1);
  Chk('TEXT BETWEEN (''007''..''9'' -> ikisi de)',
      'SELECT s FROM t WHERE s BETWEEN ' + Q + '007' + Q + ' AND ' + Q + '9' + Q, 2);
  Chk('DISTINCT (007 ve 7 farkli)', 'SELECT DISTINCT s FROM t', 2);
  Chk('DISTINCT n (7 iki kez)', 'SELECT DISTINCT n FROM t', 1);
end;

procedure T08_Join;
begin
  Grp('JOIN: INNER, LEFT, alias, nitelemeli kolon');
  UseDir('jnn');
  sq.Exec('CREATE TABLE eb(id INTEGER PRIMARY KEY, ad TEXT)');
  sq.Exec('CREATE TABLE coc(id INTEGER PRIMARY KEY, ad TEXT, pid INTEGER)');
  sq.Exec('INSERT INTO eb(id,ad) VALUES(1,' + Q + 'Ali' + Q + ')');
  sq.Exec('INSERT INTO eb(id,ad) VALUES(2,' + Q + 'Veli' + Q + ')');
  sq.Exec('INSERT INTO coc(id,ad,pid) VALUES(1,' + Q + 'c1' + Q + ',1)');
  sq.Exec('INSERT INTO coc(id,ad,pid) VALUES(2,' + Q + 'c2' + Q + ',1)');
  sq.Exec('INSERT INTO coc(id,ad,pid) VALUES(3,' + Q + 'c3' + Q + ',2)');
  sq.Exec('INSERT INTO coc(id,ad,pid) VALUES(4,' + Q + 'c4' + Q + ',NULL)');
  Chk('INNER JOIN (3 eslesme)', 'SELECT c.ad FROM coc c INNER JOIN eb ON c.pid = eb.id', 3);
  Chk('JOIN = INNER JOIN', 'SELECT c.ad FROM coc c JOIN eb ON c.pid = eb.id', 3);
  Chk('LEFT JOIN (4 satir)', 'SELECT c.ad FROM coc c LEFT JOIN eb ON c.pid = eb.id', 4);
  ChkVal('LEFT JOIN eslesmeyen NULL',
      'SELECT c.ad, eb.ad FROM coc c LEFT JOIN eb ON c.pid = eb.id ORDER BY c.id', 3, 1, '');
  Chk('aliasli JOIN + WHERE', 'SELECT c.ad FROM coc c JOIN eb e ON c.pid = e.id ' +
      'WHERE e.ad = ' + Q + 'Ali' + Q, 2);
  Chk('nitelemeli kolon', 'SELECT coc.ad FROM coc JOIN eb ON coc.pid = eb.id', 3);
  Chk('coklu JOIN kosulu yerine ON+WHERE',
      'SELECT c.ad FROM coc c JOIN eb ON c.pid = eb.id WHERE c.id > 1', 2);
  ChkErr('JOIN ile GROUP BY desteklenmiyor (hata)',
      'SELECT c.ad, COUNT(*) AS n FROM coc c JOIN eb ON c.pid = eb.id GROUP BY ad');
  Chk('ORDER BY + LIMIT JOIN',
      'SELECT c.ad FROM coc c JOIN eb ON c.pid = eb.id ORDER BY c.id LIMIT 1', 1);
end;

procedure T08b_JoinZincir;
begin
  Grp('JOIN zinciri: 3+ tablo (P5-1)');
  UseDir('jnn3');
  sq.Exec('CREATE TABLE ulke(id INTEGER PRIMARY KEY, ad TEXT)');
  sq.Exec('CREATE TABLE sehir(id INTEGER PRIMARY KEY, ad TEXT, uid INTEGER)');
  sq.Exec('CREATE TABLE kisi3(id INTEGER PRIMARY KEY, ad TEXT, sid INTEGER)');
  sq.Exec('INSERT INTO ulke(id,ad) VALUES(1,' + Q + 'TR' + Q + ')');
  sq.Exec('INSERT INTO ulke(id,ad) VALUES(2,' + Q + 'DE' + Q + ')');
  sq.Exec('INSERT INTO sehir(id,ad,uid) VALUES(1,' + Q + 'Ankara' + Q + ',1)');
  sq.Exec('INSERT INTO sehir(id,ad,uid) VALUES(2,' + Q + 'Istanbul' + Q + ',1)');
  sq.Exec('INSERT INTO sehir(id,ad,uid) VALUES(3,' + Q + 'Berlin' + Q + ',2)');
  sq.Exec('INSERT INTO sehir(id,ad,uid) VALUES(4,' + Q + 'Sahipsiz' + Q + ',NULL)');
  sq.Exec('INSERT INTO kisi3(id,ad,sid) VALUES(1,' + Q + 'Ali' + Q + ',1)');
  sq.Exec('INSERT INTO kisi3(id,ad,sid) VALUES(2,' + Q + 'Veli' + Q + ',2)');
  sq.Exec('INSERT INTO kisi3(id,ad,sid) VALUES(3,' + Q + 'Zoe' + Q + ',3)');
  sq.Exec('INSERT INTO kisi3(id,ad,sid) VALUES(4,' + Q + 'Kim' + Q + ',NULL)');
  sq.Exec('INSERT INTO kisi3(id,ad,sid) VALUES(5,' + Q + 'Can' + Q + ',1)');
  Chk('3 tablo INNER (4 eslesme)',
      'SELECT k.ad FROM kisi3 k JOIN sehir s ON k.sid = s.id ' +
      'JOIN ulke u ON s.uid = u.id', 4);
  ChkVal('3 tablo deger',
      'SELECT k.ad, s.ad, u.ad FROM kisi3 k JOIN sehir s ON k.sid = s.id ' +
      'JOIN ulke u ON s.uid = u.id ORDER BY k.id', 0, 2, 'TR');
  ChkVal('3 tablo 3. satir',
      'SELECT k.ad, s.ad, u.ad FROM kisi3 k JOIN sehir s ON k.sid = s.id ' +
      'JOIN ulke u ON s.uid = u.id ORDER BY k.id', 2, 2, 'DE');
  Chk('LEFT + INNER zincir (Kim duser, 4 satir)',
      'SELECT k.ad FROM kisi3 k LEFT JOIN sehir s ON k.sid = s.id ' +
      'JOIN ulke u ON s.uid = u.id', 4);
  Chk('INNER + LEFT zincir (4 satir)',
      'SELECT k.ad FROM kisi3 k JOIN sehir s ON k.sid = s.id ' +
      'LEFT JOIN ulke u ON s.uid = u.id', 4);
  Chk('ters ON sirasi (sag=sol)',
      'SELECT k.ad FROM kisi3 k JOIN sehir s ON s.id = k.sid ' +
      'JOIN ulke u ON u.id = s.uid', 4);
  Chk('4. tablo oz-birlestirme (Ankara paylasimi, 6 satir)',
      'SELECT a.ad FROM kisi3 a JOIN sehir s ON a.sid = s.id ' +
      'JOIN ulke u ON s.uid = u.id JOIN kisi3 b ON b.sid = s.id', 6);
  Chk('WHERE zincir sonrasi (TR: Ali, Veli, Can)',
      'SELECT k.ad FROM kisi3 k JOIN sehir s ON k.sid = s.id ' +
      'JOIN ulke u ON s.uid = u.id WHERE u.ad = ' + Q + 'TR' + Q, 3);
  ChkErr('JOIN ile aggregate desteklenmiyor (hata)',
      'SELECT COUNT(*) FROM kisi3 k JOIN sehir s ON k.sid = s.id');
  Chk('zincirde RIGHT (Kim duser, 4)',
      'SELECT k.ad FROM kisi3 k LEFT JOIN sehir s ON k.sid = s.id ' +
      'RIGHT JOIN ulke u ON s.uid = u.id', 4);
end;

procedure T08c_RightFullJoin;
begin
  Grp('RIGHT/FULL JOIN (P5-RF)');
  UseDir('jnrf');
  sq.Exec('CREATE TABLE eb2(id INTEGER PRIMARY KEY, ad TEXT)');
  sq.Exec('CREATE TABLE per2(id INTEGER PRIMARY KEY, ad TEXT, eid INTEGER)');
  sq.Exec('INSERT INTO eb2(id,ad) VALUES(1,' + Q + 'Ali' + Q + '),(2,' + Q + 'Veli' + Q + ')');
  sq.Exec('INSERT INTO eb2(id,ad) VALUES(3,' + Q + 'Zoe' + Q + ')');
  sq.Exec('INSERT INTO per2(id,ad,eid) VALUES(1,' + Q + 'p1' + Q + ',1)');
  sq.Exec('INSERT INTO per2(id,ad,eid) VALUES(2,' + Q + 'p2' + Q + ',1)');
  sq.Exec('INSERT INTO per2(id,ad,eid) VALUES(3,' + Q + 'p3' + Q + ',NULL)');
  // sagda eslesmeyen Zoe korunur (NULL-solla)
  Chk('RIGHT JOIN (4: Zoe NULL-solla)',
      'SELECT p.ad, e.ad FROM per2 p RIGHT JOIN eb2 e ON p.eid = e.id ORDER BY e.id, p.id', 4);
  ChkVal('RIGHT eslesmeyen sag',
      'SELECT p.ad, e.ad FROM per2 p RIGHT JOIN eb2 e ON p.eid = e.id ORDER BY e.id, p.id', 3, 0, '');
  ChkVal('RIGHT eslesmeyen sag adi',
      'SELECT p.ad, e.ad FROM per2 p RIGHT JOIN eb2 e ON p.eid = e.id ORDER BY e.id, p.id', 3, 1, 'Zoe');
  Chk('RIGHT OUTER ayni (4)',
      'SELECT p.ad FROM per2 p RIGHT OUTER JOIN eb2 e ON p.eid = e.id', 4);
  Chk('LEFT OUTER ayni (3)',
      'SELECT p.ad FROM per2 p LEFT OUTER JOIN eb2 e ON p.eid = e.id', 3);
  // FULL: iki taraf da korunur (p3 + Zoe = 5).
  // (NULL satirlarin siralama konumu tanimsizdir; kosulla dogrulanir.)
  Chk('FULL JOIN (5)',
      'SELECT p.ad, e.ad FROM per2 p FULL JOIN eb2 e ON p.eid = e.id', 5);
  Chk('FULL sag-korumali (Veli+Zoe)',
      'SELECT p.ad, e.ad FROM per2 p FULL JOIN eb2 e ON p.eid = e.id WHERE p.ad IS NULL', 2);
  ChkVal('FULL sol-korumali (p3)',
      'SELECT p.ad, e.ad FROM per2 p FULL JOIN eb2 e ON p.eid = e.id WHERE e.ad IS NULL', 0, 0, 'p3');
  Chk('FULL OUTER ayni (5)',
      'SELECT p.ad FROM per2 p FULL OUTER JOIN eb2 e ON p.eid = e.id', 5);
  // ters ON + zincirde RIGHT
  Chk('ters ON RIGHT (4)',
      'SELECT p.ad FROM per2 p RIGHT JOIN eb2 e ON e.id = p.eid', 4);
  ChkErr('CROSS JOIN yok (hata)',
      'SELECT * FROM per2 CROSS JOIN eb2');
end;

procedure T08g_Collation;
begin
  Grp('Turkce collation (P5-TR)');
  UseDir('colltr');
  sq.Exec('CREATE TABLE kel(id INTEGER PRIMARY KEY, w TEXT)');
  sq.Exec('INSERT INTO kel(id,w) VALUES(1,' + Q + 'davul' + Q + ')');
  sq.Exec('INSERT INTO kel(id,w) VALUES(2,' + Q + 'çocuk' + Q + ')');
  sq.Exec('INSERT INTO kel(id,w) VALUES(3,' + Q + 'ıhlamur' + Q + ')');
  sq.Exec('INSERT INTO kel(id,w) VALUES(4,' + Q + 'istanbul' + Q + ')');
  sq.Exec('INSERT INTO kel(id,w) VALUES(5,' + Q + 'pazar' + Q + ')');
  sq.Exec('INSERT INTO kel(id,w) VALUES(6,' + Q + 'öğretmen' + Q + ')');
  sq.Exec('INSERT INTO kel(id,w) VALUES(7,' + Q + 'var' + Q + ')');
  sq.Exec('INSERT INTO kel(id,w) VALUES(8,' + Q + 'üzüm' + Q + ')');
  // Turk sirasi: çocuk, davul, ıhlamur, istanbul, öğretmen, pazar, üzüm, var
  // Bayt sirasi:  davul, istanbul, pazar, var, çocuk, öğretmen, üzüm, ıhlamur
  ChkVal('TR sira ilk=cocuk',
      'SELECT w FROM kel ORDER BY w COLLATE TR', 0, 0, 'çocuk');
  ChkVal('TR sira son=var',
      'SELECT w FROM kel ORDER BY w COLLATE TR', 7, 0, 'var');
  ChkVal('TR sira orta=ogretmen',
      'SELECT w FROM kel ORDER BY w COLLATE TR', 4, 0, 'öğretmen');
  ChkVal('TR sira ihlamur<istanbul',
      'SELECT w FROM kel ORDER BY w COLLATE TR', 2, 0, 'ıhlamur');
  ChkVal('bayt sira ilk=davul (degismedi)',
      'SELECT w FROM kel ORDER BY w', 0, 0, 'davul');
  ChkVal('TR DESC ilk=var',
      'SELECT w FROM kel ORDER BY w COLLATE TR DESC LIMIT 1', 0, 0, 'var');
  ChkVal('UPPER Turkce i->İ',
      'SELECT UPPER(' + Q + 'istanbul' + Q + ')', 0, 0, 'İSTANBUL');
  ChkVal('UPPER isiz ı->I',
      'SELECT UPPER(' + Q + 'ıhlamur' + Q + ')', 0, 0, 'IHLAMUR');
  ChkVal('LOWER I->ı',
      'SELECT LOWER(' + Q + 'ISPARTA' + Q + ')', 0, 0, 'ısparta');
  ChkVal('LOWER İ->i',
      'SELECT LOWER(' + Q + 'İZMİR' + Q + ')', 0, 0, 'izmir');
  ChkVal('LENGTH karakter sayar (5)',
      'SELECT LENGTH(' + Q + 'şeker' + Q + ')', 0, 0, '5');
  Chk('harf duyarsiz arama UPPER ile',
      'SELECT w FROM kel WHERE UPPER(w) = UPPER(' + Q + 'ÇOCUK' + Q + ')', 1);
  ChkErr('bilinmeyen COLLATE (hata)',
      'SELECT w FROM kel ORDER BY w COLLATE XX');
  // indeksli kolonda da TR dogru (hizli yol devre disi kalir)
  sq.Exec('CREATE INDEX ixw ON kel(w)');
  ChkVal('TR indeksli de dogru',
      'SELECT w FROM kel ORDER BY w COLLATE TR', 0, 0, 'çocuk');
  ChkVal('TR LIMIT indeksli de dogru',
      'SELECT w FROM kel ORDER BY w COLLATE TR LIMIT 2 OFFSET 6', 1, 0, 'var');
end;

procedure T08c_AltSorgu;
begin
  Grp('Alt sorgu: IN (SELECT), skaler, EXISTS (P5-2)');
  UseDir('subq');
  sq.Exec('CREATE TABLE bolge(id INTEGER PRIMARY KEY, ad TEXT)');
  sq.Exec('CREATE TABLE musteri(id INTEGER PRIMARY KEY, ad TEXT, bid INTEGER)');
  sq.Exec('INSERT INTO bolge(id,ad) VALUES(1,' + Q + 'Ege' + Q + '),(2,' + Q + 'Ic Anadolu' + Q + ')');
  sq.Exec('INSERT INTO musteri(id,ad,bid) VALUES(1,' + Q + 'Ali' + Q + ',1)');
  sq.Exec('INSERT INTO musteri(id,ad,bid) VALUES(2,' + Q + 'Veli' + Q + ',2)');
  sq.Exec('INSERT INTO musteri(id,ad,bid) VALUES(3,' + Q + 'Zoe' + Q + ',NULL)');
  sq.Exec('INSERT INTO musteri(id,ad,bid) VALUES(4,' + Q + 'Can' + Q + ',1)');
  Chk('IN subquery (3)',
      'SELECT ad FROM musteri WHERE bid IN (SELECT id FROM bolge)', 3);
  // Uc-degerli mantik: NULL dis deger NOT IN'de eslesmez (UNKNOWN elenir).
  Chk('NOT IN subquery dis NULL elenir (0)',
      'SELECT ad FROM musteri WHERE bid NOT IN (SELECT id FROM bolge)', 0);
  Chk('NOT IN NULL-suz kume (Veli)',
      'SELECT ad FROM musteri WHERE bid NOT IN (SELECT id FROM bolge WHERE id = 1)', 1);
  ChkVal('NOT IN NULL-suz deger',
      'SELECT ad FROM musteri WHERE bid NOT IN (SELECT id FROM bolge WHERE id = 1) ORDER BY id', 0, 0, 'Veli');
  Chk('IN bos kume (0)',
      'SELECT ad FROM musteri WHERE bid IN (SELECT id FROM bolge WHERE id > 99)', 0);
  Chk('NOT IN bos kume (NULL disindakiler, 3)',
      'SELECT ad FROM musteri WHERE bid NOT IN (SELECT id FROM bolge WHERE id > 99)', 3);
  ChkVal('skaler esitlik',
      'SELECT ad FROM musteri WHERE bid = (SELECT id FROM bolge WHERE ad = ' + Q + 'Ege' + Q + ') ORDER BY id', 0, 0, 'Ali');
  Chk('skaler aggregate',
      'SELECT ad FROM musteri WHERE id > (SELECT AVG(id) FROM musteri)', 2);
  Chk('skaler bos = NULL eslesmez (0)',
      'SELECT ad FROM musteri WHERE bid = (SELECT id FROM bolge WHERE id > 99)', 0);
  ChkErr('skaler cok satir (hata)',
      'SELECT ad FROM musteri WHERE bid = (SELECT id FROM bolge)');
  ChkErr('IN cok kolon (hata)',
      'SELECT ad FROM musteri WHERE bid IN (SELECT id, ad FROM bolge)');
  ChkVal('SELECT listesinde skaler',
      'SELECT ad, (SELECT ad FROM bolge WHERE id = 1) AS b FROM musteri WHERE id = 1', 0, 1, 'Ege');
  Chk('EXISTS (4)',
      'SELECT ad FROM musteri WHERE EXISTS (SELECT id FROM bolge WHERE id = 1)', 4);
  Chk('EXISTS bos (0)',
      'SELECT ad FROM musteri WHERE EXISTS (SELECT id FROM bolge WHERE id > 99)', 0);
  Chk('NOT EXISTS bos (4)',
      'SELECT ad FROM musteri WHERE NOT EXISTS (SELECT id FROM bolge WHERE id > 99)', 4);
  ChkErr('iliskili alt sorgu desteklenmiyor (hata)',
      'SELECT a.ad FROM musteri a WHERE a.bid IN (SELECT b.bid FROM musteri b WHERE b.id = a.id)');
end;

procedure T08d_CaseWhen;
begin
  Grp('CASE WHEN (P5-3)');
  UseDir('casew');
  sq.Exec('CREATE TABLE per(id INTEGER PRIMARY KEY, ad TEXT, yas INTEGER, maas FLOAT)');
  sq.Exec('INSERT INTO per(id,ad,yas,maas) VALUES(1,' + Q + 'Ali' + Q + ',30,9000.5)');
  sq.Exec('INSERT INTO per(id,ad,yas,maas) VALUES(2,' + Q + 'Veli' + Q + ',17,4000)');
  sq.Exec('INSERT INTO per(id,ad,yas,maas) VALUES(3,' + Q + 'Zoe' + Q + ',25,NULL)');
  ChkVal('aranan + ELSE (Ali resit)',
      'SELECT ad, CASE WHEN yas >= 18 THEN ' + Q + 'resit' + Q + ' ELSE ' + Q + 'cocuk' + Q + ' END AS d FROM per ORDER BY id', 0, 1, 'resit');
  ChkVal('aranan ELSE (Veli cocuk)',
      'SELECT ad, CASE WHEN yas >= 18 THEN ' + Q + 'resit' + Q + ' ELSE ' + Q + 'cocuk' + Q + ' END AS d FROM per ORDER BY id', 1, 1, 'cocuk');
  ChkVal('ELSEsiz eslesmezse NULL',
      'SELECT ad, CASE WHEN yas > 100 THEN ' + Q + 'x' + Q + ' END AS d FROM per WHERE id = 1', 0, 1, '');
  ChkVal('sade CASE (Ali otuz)',
      'SELECT ad, CASE yas WHEN 30 THEN ' + Q + 'otuz' + Q + ' WHEN 17 THEN ' + Q + 'onyedi' + Q + ' ELSE ' + Q + 'diger' + Q + ' END AS d FROM per ORDER BY id', 0, 1, 'otuz');
  ChkVal('sade CASE (Zoe diger)',
      'SELECT ad, CASE yas WHEN 30 THEN ' + Q + 'otuz' + Q + ' WHEN 17 THEN ' + Q + 'onyedi' + Q + ' ELSE ' + Q + 'diger' + Q + ' END AS d FROM per ORDER BY id', 2, 1, 'diger');
  Chk('CASE WHERE kosulu (2)',
      'SELECT ad FROM per WHERE CASE WHEN yas >= 18 THEN 1 ELSE 0 END = 1', 2);
  ChkVal('ic ice CASE',
      'SELECT CASE WHEN yas > 20 THEN CASE WHEN yas > 28 THEN ' + Q + 'yasli' + Q + ' ELSE ' + Q + 'genc' + Q + ' END ELSE ' + Q + 'cocuk' + Q + ' END AS d FROM per ORDER BY id', 0, 0, 'yasli');
  ChkVal('CASE float kiyas',
      'SELECT CASE WHEN maas > 5000 THEN ' + Q + 'yuksek' + Q + ' ELSE ' + Q + 'dusuk' + Q + ' END AS s FROM per ORDER BY id', 0, 0, 'yuksek');
  ChkVal('CASE NULL kiyas ELSE duser',
      'SELECT CASE WHEN maas > 5000 THEN ' + Q + 'yuksek' + Q + ' ELSE ' + Q + 'dusuk' + Q + ' END AS s FROM per ORDER BY id', 2, 0, 'dusuk');
  ChkErr('eksik END (hata)',
      'SELECT CASE WHEN yas > 1 THEN 1 FROM per');
  ChkErr('WHENsiz CASE (hata)',
      'SELECT CASE yas ELSE 1 END FROM per');
end;

procedure T08e_CTE;
begin
  Grp('WITH-CTE (P5-CTE)');
  UseDir('cteq');
  sq.Exec('CREATE TABLE bolge(id INTEGER PRIMARY KEY, ad TEXT)');
  sq.Exec('CREATE TABLE musteri(id INTEGER PRIMARY KEY, ad TEXT, bid INTEGER, maas INTEGER)');
  sq.Exec('INSERT INTO bolge(id,ad) VALUES(1,' + Q + 'Ege' + Q + '),(2,' + Q + 'Ic Anadolu' + Q + ')');
  sq.Exec('INSERT INTO musteri(id,ad,bid,maas) VALUES(1,' + Q + 'Ali' + Q + ',1,9000)');
  sq.Exec('INSERT INTO musteri(id,ad,bid,maas) VALUES(2,' + Q + 'Veli' + Q + ',2,4000)');
  sq.Exec('INSERT INTO musteri(id,ad,bid,maas) VALUES(3,' + Q + 'Zoe' + Q + ',NULL,7000)');
  sq.Exec('INSERT INTO musteri(id,ad,bid,maas) VALUES(4,' + Q + 'Can' + Q + ',1,5000)');
  sq.Exec('INSERT INTO musteri(id,ad,bid,maas) VALUES(5,' + Q + 'Dev' + Q + ',2,100000)');
  Chk('tek CTE (5)',
      'WITH m AS (SELECT id, ad, bid FROM musteri) SELECT ad FROM m', 5);
  ChkVal('CTE WHERE',
      'WITH m AS (SELECT id, ad, bid FROM musteri) SELECT ad FROM m WHERE bid = 1 ORDER BY id', 0, 0, 'Ali');
  Chk('zincir CTE (Can)',
      'WITH e AS (SELECT id, ad FROM musteri WHERE bid = 1), ' +
      'x AS (SELECT ad FROM e WHERE id > 1) SELECT ad FROM x', 1);
  ChkVal('zincir deger',
      'WITH e AS (SELECT id, ad FROM musteri WHERE bid = 1), ' +
      'x AS (SELECT ad FROM e WHERE id > 1) SELECT ad FROM x', 0, 0, 'Can');
  Chk('CTE + JOIN (4)',
      'WITH m AS (SELECT id, ad, bid FROM musteri WHERE bid IS NOT NULL) ' +
      'SELECT m.ad, b.ad FROM m JOIN bolge b ON m.bid = b.id ORDER BY m.id', 4);
  Chk('CTE sagda (4)',
      'WITH m AS (SELECT id, bid FROM musteri WHERE bid IS NOT NULL) ' +
      'SELECT b.ad FROM bolge b JOIN m ON m.bid = b.id', 4);
  ChkVal('CTE aggregate',
      'WITH m AS (SELECT id, bid FROM musteri WHERE bid IS NOT NULL) SELECT COUNT(*) AS c FROM m', 0, 0, '4');
  ChkVal('CTE GROUP BY',
      'WITH m AS (SELECT bid FROM musteri WHERE bid IS NOT NULL) SELECT bid, COUNT(*) AS n FROM m GROUP BY bid ORDER BY bid', 0, 1, '2');
  Chk('CTE sayisal WHERE (3, metin olsa 2 olurdu)',
      'WITH m AS (SELECT id, maas FROM musteri) SELECT id FROM m WHERE maas > 6000', 3);
  ChkVal('CTE sayisal ORDER BY (Veli ilk)',
      'WITH m AS (SELECT id, maas FROM musteri) SELECT id FROM m ORDER BY maas LIMIT 1', 0, 0, '2');
  ChkErr('RECURSIVE (hata)',
      'WITH RECURSIVE x AS (SELECT id FROM musteri) SELECT id FROM x');
  ChkErr('kolon alias (hata)',
      'WITH x(a) AS (SELECT id FROM musteri) SELECT a FROM x');
  ChkErr('WITH + INSERT (hata)',
      'WITH x AS (SELECT id FROM musteri) INSERT INTO musteri(id) VALUES(9)');
  ChkErr('bilinmeyen CTE/tablo (hata)',
      'WITH x AS (SELECT id FROM musteri) SELECT id FROM yok');
end;

procedure T08f_Pencere;
begin
  Grp('Pencere fonksiyonlari (P5-WIN)');
  UseDir('winf');
  sq.Exec('CREATE TABLE sat(id INTEGER PRIMARY KEY, ad TEXT, bolge TEXT, tutar INTEGER)');
  sq.Exec('INSERT INTO sat(id,ad,bolge,tutar) VALUES(1,' + Q + 'a' + Q + ',' + Q + 'E' + Q + ',100)');
  sq.Exec('INSERT INTO sat(id,ad,bolge,tutar) VALUES(2,' + Q + 'b' + Q + ',' + Q + 'E' + Q + ',200)');
  sq.Exec('INSERT INTO sat(id,ad,bolge,tutar) VALUES(3,' + Q + 'c' + Q + ',' + Q + 'W' + Q + ',150)');
  sq.Exec('INSERT INTO sat(id,ad,bolge,tutar) VALUES(4,' + Q + 'd' + Q + ',' + Q + 'E' + Q + ',200)');
  sq.Exec('INSERT INTO sat(id,ad,bolge,tutar) VALUES(5,' + Q + 'e' + Q + ',' + Q + 'W' + Q + ',NULL)');
  sq.Exec('INSERT INTO sat(id,ad,bolge,tutar) VALUES(6,' + Q + 'f' + Q + ',' + Q + 'E' + Q + ',300)');
  ChkVal('ROW_NUMBER sirasiz',
      'SELECT ad, ROW_NUMBER() OVER () AS rn FROM sat ORDER BY id', 0, 1, '1');
  ChkVal('ROW_NUMBER son',
      'SELECT ad, ROW_NUMBER() OVER () AS rn FROM sat ORDER BY id', 5, 1, '6');
  ChkVal('ROW_NUMBER partition',
      'SELECT ad, ROW_NUMBER() OVER (PARTITION BY bolge ORDER BY tutar) AS rn FROM sat ORDER BY id', 0, 1, '1');
  ChkVal('ROW_NUMBER partition son (f=4, bagimsiz)',
      'SELECT ad, ROW_NUMBER() OVER (PARTITION BY bolge ORDER BY tutar) AS rn FROM sat ORDER BY id', 5, 1, '4');
  ChkVal('RANK bag paylasir (b=2)',
      'SELECT ad, RANK() OVER (PARTITION BY bolge ORDER BY tutar) AS r FROM sat ORDER BY id', 1, 1, '2');
  ChkVal('RANK bag paylasir (d=2)',
      'SELECT ad, RANK() OVER (PARTITION BY bolge ORDER BY tutar) AS r FROM sat ORDER BY id', 3, 1, '2');
  ChkVal('RANK bag sonrasi atlar (f=4)',
      'SELECT ad, RANK() OVER (PARTITION BY bolge ORDER BY tutar) AS r FROM sat ORDER BY id', 5, 1, '4');
  ChkVal('DENSE_RANK atlamaz (f=3)',
      'SELECT ad, DENSE_RANK() OVER (PARTITION BY bolge ORDER BY tutar) AS r FROM sat ORDER BY id', 5, 1, '3');
  ChkVal('SUM partition toplami (800)',
      'SELECT ad, SUM(tutar) OVER (PARTITION BY bolge) AS s FROM sat ORDER BY id', 0, 1, '800');
  ChkVal('COUNT yildiz partition (E=4)',
      'SELECT ad, COUNT(*) OVER (PARTITION BY bolge) AS c FROM sat ORDER BY id', 0, 1, '4');
  ChkVal('COUNT yildiz partition (W=2)',
      'SELECT ad, COUNT(*) OVER (PARTITION BY bolge) AS c FROM sat ORDER BY id', 2, 1, '2');
  ChkVal('AVG partition NULL atlar (150)',
      'SELECT AVG(tutar) OVER (PARTITION BY bolge) AS o FROM sat ORDER BY id', 4, 0, '150');
  ChkVal('MIN partition (100)',
      'SELECT MIN(tutar) OVER (PARTITION BY bolge) AS m FROM sat ORDER BY id', 1, 0, '100');
  ChkVal('LAG onceki (b->a)',
      'SELECT ad, LAG(ad) OVER (ORDER BY id) AS onceki FROM sat ORDER BY id', 1, 1, 'a');
  ChkVal('LAG ilk NULL',
      'SELECT ad, LAG(ad) OVER (ORDER BY id) AS onceki FROM sat ORDER BY id', 0, 1, '');
  ChkVal('LAG offset+varsayilan',
      'SELECT ad, LAG(ad, 2, ' + Q + 'yok' + Q + ') OVER (ORDER BY id) AS o FROM sat ORDER BY id', 1, 1, 'yok');
  ChkVal('LEAD sonraki (d->e)',
      'SELECT ad, LEAD(ad) OVER (ORDER BY id) AS sonraki FROM sat ORDER BY id', 3, 1, 'e');
  ChkVal('LAG partition tasmaz (c ilk)',
      'SELECT ad, LAG(ad) OVER (PARTITION BY bolge ORDER BY id) AS o FROM sat ORDER BY id', 2, 1, '');
  Chk('pencere + JOIN (8)',
      'SELECT s.ad, ROW_NUMBER() OVER (ORDER BY s.id) AS rn FROM sat s JOIN sat t ON s.bolge = t.bolge WHERE s.id <= 2', 8);
  Chk('skaler alt sorgu ile WHERE (3)',
      'SELECT ad FROM sat WHERE tutar > (SELECT AVG(tutar) FROM sat)', 3);
  ChkErr('WHERE icinde pencere (hata)',
      'SELECT ad FROM sat WHERE ROW_NUMBER() OVER (ORDER BY id) = 1');
  ChkErr('ic ice pencere (hata)',
      'SELECT 1 + ROW_NUMBER() OVER (ORDER BY id) FROM sat');
  ChkErr('ROW_NUMBER arguman (hata)',
      'SELECT ROW_NUMBER(id) OVER () FROM sat');
  ChkErr('LAG OVERsiz (hata)',
      'SELECT LAG(ad) FROM sat');
  ChkErr('bilinmeyen OVER (hata)',
      'SELECT UPPER(ad) OVER () FROM sat');
  ChkErr('GROUP BY + pencere (hata)',
      'SELECT bolge, COUNT(*), RANK() OVER (ORDER BY bolge) FROM sat GROUP BY bolge');
end;

procedure T09_GroupAggregate;
begin
  Grp('GROUP BY + aggregate (COUNT/SUM/AVG/MIN/MAX)');
  UseDir('grp');
  sq.Exec('CREATE TABLE p(id INTEGER PRIMARY KEY, dept TEXT, maas INTEGER)');
  sq.Exec('INSERT INTO p(dept,maas) VALUES(' + Q + 'yazilim' + Q + ',100)');
  sq.Exec('INSERT INTO p(dept,maas) VALUES(' + Q + 'yazilim' + Q + ',200)');
  sq.Exec('INSERT INTO p(dept,maas) VALUES(' + Q + 'yazilim' + Q + ',300)');
  sq.Exec('INSERT INTO p(dept,maas) VALUES(' + Q + 'satis' + Q + ',150)');
  sq.Exec('INSERT INTO p(dept,maas) VALUES(' + Q + 'satis' + Q + ',250)');
  ChkVal('COUNT(*)', 'SELECT COUNT(*) FROM p', 0, 0, '5');
  ChkVal('COUNT(dept)', 'SELECT COUNT(dept) FROM p', 0, 0, '5');
  ChkVal('SUM', 'SELECT SUM(maas) FROM p', 0, 0, '1000');
  ChkVal('AVG', 'SELECT AVG(maas) FROM p', 0, 0, '200');
  ChkVal('MIN', 'SELECT MIN(maas) FROM p', 0, 0, '100');
  ChkVal('MAX', 'SELECT MAX(maas) FROM p', 0, 0, '300');
  Chk('GROUP BY 2 grup', 'SELECT dept, COUNT(*) FROM p GROUP BY dept', 2);
  ChkVal('GROUP BY SUM', 'SELECT dept, SUM(maas) FROM p GROUP BY dept ' +
      'ORDER BY dept', 0, 1, '400');
  ChkVal('coklu kolon GROUP BY',
      'SELECT dept, maas, COUNT(*) FROM p GROUP BY dept, maas', 0, 2, '1');
  ChkVal('aggregate + WHERE', 'SELECT COUNT(*) FROM p WHERE maas > 150', 0, 0, '3');
  ChkErr('HAVING desteklenmiyor (hata)',
      'SELECT dept, COUNT(*) FROM p GROUP BY dept HAVING COUNT(*) > 1');
  ChkErr('artik token sessizce yutulmaz (hata)',
      'SELECT dept FROM p WHERE maas > 1 BLA BLA');
end;

procedure T10_Update;
begin
  Grp('UPDATE');
  UseDir('upd');
  sq.Exec('CREATE TABLE ebeveyn(id INTEGER PRIMARY KEY)');
  sq.Exec('INSERT INTO ebeveyn(id) VALUES(1)');
  sq.Exec('CREATE TABLE t(id INTEGER PRIMARY KEY, ad TEXT UNIQUE, ' +
          'yas INTEGER, pid INTEGER REFERENCES ebeveyn(id), ' +
          'puan INTEGER CHECK (puan >= 0))');
  sq.Exec('INSERT INTO t(ad,yas,pid) VALUES(' + Q + 'a' + Q + ',1,1)');
  sq.Exec('INSERT INTO t(ad,yas,pid) VALUES(' + Q + 'b' + Q + ',2,1)');
  Chk('WHERE ile tek', 'UPDATE t SET yas = 99 WHERE id = 1', -1);
  ChkVal('guncellendi', 'SELECT yas FROM t WHERE id=1', 0, 0, '99');
  Chk('WHERE ile cok', 'UPDATE t SET yas = 50 WHERE yas > 10', -1);
  Chk('WHERE yoksa tumu', 'UPDATE t SET yas = 7', -1);
  ChkVal('tum satirlar guncellendi', 'SELECT yas FROM t WHERE id=1', 0, 0, '7');
  Chk('coklu SET', 'UPDATE t SET ad = ' + Q + 'z' + Q + ', yas = 1 WHERE id = 1', -1);
  Chk('NULL yazma', 'UPDATE t SET yas = NULL WHERE id = 1', -1);
  ChkVal('NULL yazildi', 'SELECT yas FROM t WHERE id=1', 0, 0, '');
  ChkErr('CHECK ihlali UPDATE (hata)', 'UPDATE t SET puan = -5 WHERE id = 1');
  ChkErr('FK ihlali UPDATE (hata)', 'UPDATE t SET pid = 77 WHERE id = 1');
  Chk('gecerli FK UPDATE', 'UPDATE t SET pid = 1 WHERE id = 1', -1);
  ChkErr('UNIQUE ihlali UPDATE (hata)',
      'UPDATE t SET ad = ' + Q + 'z' + Q + ' WHERE id = 2');
end;

procedure T11_Delete;
begin
  Grp('DELETE');
  UseDir('del');
  sq.Exec('CREATE TABLE eb(id INTEGER PRIMARY KEY)');
  sq.Exec('CREATE TABLE coc(id INTEGER PRIMARY KEY, pid INTEGER ' +
          'REFERENCES eb(id))');
  sq.Exec('INSERT INTO eb(id) VALUES(1)');
  sq.Exec('INSERT INTO coc(id,pid) VALUES(1,1)');
  sq.Exec('INSERT INTO coc(id) VALUES(2)');
  sq.Exec('CREATE TABLE t(id INTEGER PRIMARY KEY, v INTEGER)');
  sq.Exec('INSERT INTO t(v) VALUES(1)');
  sq.Exec('INSERT INTO t(v) VALUES(2)');
  sq.Exec('INSERT INTO t(v) VALUES(3)');
  Chk('WHERE ile tek', 'DELETE FROM t WHERE id = 1', -1);
  ChkVal('kalan satir', 'SELECT COUNT(*) FROM t', 0, 0, '2');
  Chk('WHERE ile cok', 'DELETE FROM t WHERE v > 1', -1);
  ChkVal('kalan satir 2', 'SELECT COUNT(*) FROM t', 0, 0, '0');
  ChkErr('FK RESTRICT silemez (hata)', 'DELETE FROM eb WHERE id = 1');
  Chk('NULL FK ile silinebilir', 'DELETE FROM coc WHERE id = 2', -1);
  sq.Exec('INSERT INTO t(v) VALUES(9)');
  Chk('WHERE yoksa tumu', 'DELETE FROM t', -1);
  ChkVal('tablo bos', 'SELECT COUNT(*) FROM t', 0, 0, '0');
end;

procedure T12_Transaction;
begin
  Grp('Transaction: COMMIT / ROLLBACK, DDL dahil');
  UseDir('trn');
  sq.Exec('CREATE TABLE t(id INTEGER PRIMARY KEY, a TEXT)');
  sq.Exec('INSERT INTO t(a) VALUES(' + Q + 'ilk' + Q + ')');
  Chk('BEGIN', 'BEGIN', -1);
  Chk('batch icinde INSERT', 'INSERT INTO t(a) VALUES(' + Q + 'gizli' + Q + ')', -1);
  Chk('batch icinde SELECT gorunur',
      'SELECT a FROM t WHERE a = ' + Q + 'gizli' + Q, 1);
  ChkVal('batch icinde UPDATE gorunur',
      'SELECT a FROM t WHERE id = 1', 0, 0, 'ilk');
  Chk('ROLLBACK', 'ROLLBACK', -1);
  Chk('rollback: eklenen yok',
      'SELECT a FROM t WHERE a = ' + Q + 'gizli' + Q, 0);
  ChkVal('rollback: eski veri duruyor', 'SELECT COUNT(*) FROM t', 0, 0, '1');
  Chk('BEGIN 2', 'BEGIN', -1);
  sq.Exec('INSERT INTO t(a) VALUES(' + Q + 'kalici' + Q + ')');
  Chk('COMMIT', 'COMMIT', -1);
  ChkVal('commit: veri duruyor', 'SELECT COUNT(*) FROM t', 0, 0, '2');
  Chk('BEGIN 3 (DDL)', 'BEGIN', -1);
  Chk('batch icinde CREATE TABLE', 'CREATE TABLE gecici(id INTEGER PRIMARY KEY)', -1);
  sq.Exec('INSERT INTO gecici(id) VALUES(1)');
  Chk('ROLLBACK DDL', 'ROLLBACK', -1);
  ChkErr('rollback sonrasi tablo yok (hata)', 'SELECT * FROM gecici');
  ChkVal('rollback sonrasi veri saglam', 'SELECT COUNT(*) FROM t', 0, 0, '2');
  Chk('BEGIN 4 (ALTER)', 'BEGIN', -1);
  Chk('batch icinde ALTER', 'ALTER TABLE t ADD yeni INTEGER', -1);
  Chk('ROLLBACK ALTER', 'ROLLBACK', -1);
  ChkErr('rollback sonrasi kolon yok (hata)', 'SELECT yeni FROM t');
end;

procedure T13_AlterTable;
begin
  Grp('ALTER TABLE');
  UseDir('alt');
  sq.Exec('CREATE TABLE t(id INTEGER PRIMARY KEY, a TEXT, b INTEGER)');
  sq.Exec('INSERT INTO t(a,b) VALUES(' + Q + 'Ali' + Q + ',1)');
  sq.Exec('INSERT INTO t(a,b) VALUES(' + Q + 'Veli' + Q + ',2)');
  Chk('ADD COLUMN', 'ALTER TABLE t ADD c TEXT', -1);
  ChkVal('veri korundu', 'SELECT a FROM t ORDER BY id', 0, 0, 'Ali');
  ChkVal('yeni sutun NULL', 'SELECT c FROM t ORDER BY id', 0, 0, '');
  Chk('ADD COLUMN FIRST', 'ALTER TABLE t ADD ilk TEXT FIRST', -1);
  Chk('ADD COLUMN AFTER', 'ALTER TABLE t ADD sonra TEXT AFTER a', -1);
  ChkErr('var olan kolon (hata)', 'ALTER TABLE t ADD a TEXT');
  ChkErr('olmayan kolon (hata)', 'ALTER TABLE t ADD x TEXT AFTER yok');
  Chk('DROP COLUMN', 'ALTER TABLE t DROP c', -1);
  ChkVal('veri hala duruyor', 'SELECT a FROM t ORDER BY id', 0, 0, 'Ali');
  Chk('RENAME COLUMN', 'ALTER TABLE t RENAME COLUMN a TO isim', -1);
  ChkVal('yeni adiyle okunur', 'SELECT isim FROM t ORDER BY id', 0, 0, 'Ali');
  ChkErr('eski ad yok (hata)', 'SELECT a FROM t');
  ChkErr('PK kolonu dusurulemez (hata)', 'ALTER TABLE t DROP id');
  Chk('ALTER COLUMN TYPE', 'ALTER TABLE t ALTER COLUMN b TYPE TEXT', -1);
  Chk('TEXT kolona her sey yazilabilir', 'UPDATE t SET b = ' + Q + 'zzz' + Q, -1);
  ChkErr('TEXT -> INTEGER donusturulemez (hata)',
      'ALTER TABLE t ALTER COLUMN b TYPE INTEGER');
  Chk('bozuk degeri duzelt', 'UPDATE t SET b = ' + Q + '5' + Q, -1);
  Chk('ALTER COLUMN INTEGER a donus', 'ALTER TABLE t ALTER COLUMN b TYPE INTEGER', -1);
  Chk('ALTER COLUMN SET DEFAULT', 'ALTER TABLE t ALTER COLUMN b SET DEFAULT 9', -1);
  Chk('ALTER COLUMN DROP DEFAULT', 'ALTER TABLE t ALTER COLUMN b DROP DEFAULT', -1);
  Chk('ALTER COLUMN SET NOT NULL', 'ALTER TABLE t ALTER COLUMN b SET NOT NULL', -1);
  Chk('ALTER COLUMN DROP NOT NULL', 'ALTER TABLE t ALTER COLUMN b DROP NOT NULL', -1);
  ChkErr('PK NOT NULL kaldirilamaz (hata)',
      'ALTER TABLE t ALTER COLUMN id DROP NOT NULL');
  Chk('RENAME TO', 'ALTER TABLE t RENAME TO tablo2', -1);
  ChkVal('yeni tablo adiyle veri', 'SELECT isim FROM tablo2 ORDER BY id', 0, 0, 'Ali');
  ChkErr('eski tablo adi yok (hata)', 'SELECT * FROM t');
end;

procedure T14_Index;
begin
  Grp('Index: CREATE / kullanim / DROP');
  UseDir('idx');
  sq.Exec('CREATE TABLE t(id INTEGER PRIMARY KEY, ad TEXT UNIQUE, v INTEGER)');
  sq.Exec('INSERT INTO t(ad,v) VALUES(' + Q + 'a' + Q + ',1)');
  sq.Exec('INSERT INTO t(ad,v) VALUES(' + Q + 'b' + Q + ',2)');
  sq.Exec('CREATE INDEX ix_v ON t(v)');
  ChkVal('indexli = arama', 'SELECT ad FROM t WHERE v = 2', 0, 0, 'b');
  Chk('indexli > arama', 'SELECT ad FROM t WHERE v > 0 ORDER BY v', 2);
  Chk('indexli aralik', 'SELECT ad FROM t WHERE v >= 1 AND v <= 2', 2);
  Chk('indexli <> ', 'SELECT ad FROM t WHERE v <> 1', 1);
  Chk('PK indexli arama', 'SELECT ad FROM t WHERE id = 1', 1);
  Chk('DROP INDEX', 'DROP INDEX ix_v', -1);
  ChkVal('indexsiz de ayni sonuc', 'SELECT ad FROM t WHERE v = 2', 0, 0, 'b');
  ChkErr('olmayan index DROP (hata)', 'DROP INDEX ix_yok');
end;

procedure T15_Bakim;
begin
  Grp('Bakim: SHOW TABLES / VACUUM / REINDEX');
  UseDir('bak');
  sq.Exec('CREATE TABLE t1(id INTEGER PRIMARY KEY, a TEXT)');
  sq.Exec('CREATE TABLE t2(id INTEGER PRIMARY KEY, b INTEGER)');
  sq.Exec('INSERT INTO t1(a) VALUES(' + Q + 'x' + Q + ')');
  R := sq.Exec('SHOW TABLES');
  Ok('SHOW TABLES', IntToStr(R.Affected) + ' tablo');
  if Length(R.Rows) > 0 then
  begin
    WriteLn('        ', R.Rows[0][0], ' = ', R.Rows[0][1], ' satir, ',
            R.Rows[1][0], ' = ', R.Rows[1][1], ' satir');
  end;
  Chk('CREATE INDEX sonra REINDEX', 'CREATE INDEX ix ON t1(a)', -1);
  Chk('REINDEX', 'REINDEX', -1);
  ChkVal('REINDEX sonrasi arama', 'SELECT a FROM t1 WHERE a = ' + Q + 'x' + Q, 0, 0, 'x');
  sq.Exec('INSERT INTO t1(a) VALUES(' + Q + 'y' + Q + ')');
  sq.Exec('INSERT INTO t1(a) VALUES(' + Q + 'z' + Q + ')');
  sq.Exec('DELETE FROM t1 WHERE a = ' + Q + 'y' + Q);
  R := sq.Exec('VACUUM');
  Ok('VACUUM', R.Msg);
  ChkVal('VACUUM sonrasi veri', 'SELECT COUNT(*) FROM t1', 0, 0, '2');
end;

procedure T16_Parametreli;
var p: array of string;
begin
  Grp('Parametreli SQL (?)');
  UseDir('prm');
  sq.Exec('CREATE TABLE t(id INTEGER PRIMARY KEY, ad TEXT, yas INTEGER)');
  SetLength(p, 2); p[0] := 'Ali'; p[1] := '30';
  R := sq.Exec('INSERT INTO t(ad,yas) VALUES(?,?)', p);
  if R.Affected = 1 then Ok('INSERT 2 parametre', '') else No('INSERT 2 parametre', 'affected=' + IntToStr(R.Affected));
  SetLength(p, 2); p[0] := 'Veli'; p[1] := '20';
  R := sq.Exec('INSERT INTO t(ad,yas) VALUES(?,?)', p);
  if R.Affected = 1 then Ok('INSERT 2 parametre 2', '') else No('INSERT 2 parametre 2', '');
  R := sq.Exec('SELECT yas FROM t WHERE ad = ?', ['Ali']);
  if (Length(R.Rows) = 1) and (R.Rows[0][0] = '30') then Ok('WHERE ?', R.Rows[0][0])
  else No('WHERE ?', 'sonuc ' + IntToStr(Length(R.Rows)));
  R := sq.Exec('UPDATE t SET yas = ? WHERE ad = ?', ['31', 'Ali']);
  if R.Affected = 1 then Ok('UPDATE 2 parametre', '') else No('UPDATE 2 parametre', '');
  R := sq.Exec('DELETE FROM t WHERE ad = ?', ['Veli']);
  if R.Affected = 1 then Ok('DELETE 1 parametre', '') else No('DELETE 1 parametre', '');
  R := sq.Exec('SELECT COUNT(*) FROM t');
  if (Length(R.Rows) = 1) and (R.Rows[0][0] = '1') then Ok('kalan satir', R.Rows[0][0])
  else No('kalan satir', '');
  ChkErr('fazla parametre yok (hata)', 'SELECT * FROM t WHERE ad = ?');
end;

procedure T17_Json;
var f: string;
begin
  Grp('EXPORT / IMPORT JSON');
  UseDir('jsn');
  f := D + '\jsn\yedek.json';
  sq.Exec('CREATE TABLE eb(id INTEGER PRIMARY KEY)');
  sq.Exec('CREATE TABLE t(id INTEGER PRIMARY KEY, ad TEXT, pid INTEGER ' +
          'REFERENCES eb(id), CHECK (id > 0))');
  sq.Exec('INSERT INTO eb(id) VALUES(1)');
  sq.Exec('INSERT INTO t(ad,pid) VALUES(' + Q + 'Ali' + Q + ',1)');
  sq.Exec('INSERT INTO t(ad,pid) VALUES(' + Q + 'Veli' + Q + ',1)');
  sq.Exec('EXPORT JSON ' + Q + f + Q);
  if FileExists(f) then Ok('EXPORT JSON', 'dosya yazildi') else No('EXPORT JSON', 'dosya yok');
  ChkErr('olmayan tablo EXPORT (hata)',
      'EXPORT TABLE yok JSON ' + Q + D + '\jsn\x.json' + Q);
  // yeni bos db'ye aktar
  UseDir('jsn2');
  sq.Exec('IMPORT JSON ' + Q + f + Q);
  ChkVal('IMPORT: sema geldi', 'SELECT COUNT(*) FROM t', 0, 0, '2');
  ChkVal('IMPORT: veri geldi', 'SELECT ad FROM t ORDER BY id', 0, 0, 'Ali');
  ChkErr('IMPORT sonrasi FK korunuyor (hata)',
      'INSERT INTO t(id,ad,pid) VALUES(9,' + Q + 'x' + Q + ',99)');
  ChkErr('IMPORT sonrasi CHECK korunuyor (hata)',
      'INSERT INTO t(id,ad) VALUES(-1,' + Q + 'x' + Q + ')');
end;

procedure T18_Kalici;
begin
  Grp('Disk kaliciligi: kapat + yeniden ac');
  UseDir('kal');
  sq.Exec('CREATE TABLE t(id INTEGER PRIMARY KEY, a TEXT, n INTEGER DEFAULT 5)');
  sq.Exec('INSERT INTO t(a) VALUES(' + Q + 'kalici' + Q + ')');
  sq.Exec('CREATE INDEX ix ON t(a)');
  sq.Exec('ALTER TABLE t ADD ek TEXT');
  UseDir('kal');   // ayni klasoru yeniden ac
  ChkVal('sema korundu', 'SELECT a FROM t', 0, 0, 'kalici');
  ChkVal('veri korundu', 'SELECT COUNT(*) FROM t', 0, 0, '1');
  R := sq.Exec('SELECT a FROM t WHERE a = ' + Q + 'kalici' + Q);
  if Length(R.Rows) = 1 then Ok('index kalici', '') else No('index kalici', '');
  ChkVal('ALTER kolon kalici', 'SELECT ek FROM t', 0, 0, '');
  ChkVal('DEFAULT kalici', 'SELECT n FROM t', 0, 0, '5');
end;

procedure T19_Olcek;
var i: Integer;
begin
  Grp('Olcek: 1000 satir + index aralama');
  UseDir('big');
  sq.Exec('CREATE TABLE t(id INTEGER PRIMARY KEY, v INTEGER, s TEXT)');
  for i := 1 to 1000 do
  begin
    R := sq.Exec('INSERT INTO t(v,s) VALUES(' + IntToStr(i) + ',' +
        Q + 'satir' + IntToStr(i) + Q + ')');
  end;
  ChkVal('1000 satir yazildi', 'SELECT COUNT(*) FROM t', 0, 0, '1000');
  sq.Exec('CREATE INDEX ix_v ON t(v)');
  ChkVal('PK arama', 'SELECT s FROM t WHERE id = 500', 0, 0, 'satir500');
  ChkVal('index = arama', 'SELECT s FROM t WHERE v = 777', 0, 0, 'satir777');
  ChkVal('index > arama', 'SELECT COUNT(*) FROM t WHERE v > 990', 0, 0, '10');
  ChkVal('index aralik', 'SELECT COUNT(*) FROM t WHERE v >= 100 AND v <= 199', 0, 0, '100');
  Chk('tam tarama', 'SELECT COUNT(*) FROM t', 1);
  Chk('ORDER BY + LIMIT', 'SELECT s FROM t ORDER BY v DESC LIMIT 1', 1);
  ChkVal('ORDER BY DESC ilk', 'SELECT s FROM t ORDER BY v DESC LIMIT 1', 0, 0, 'satir1000');
  R := sq.Exec('VACUUM');
  Ok('buyuk veride VACUUM', R.Msg);
  ChkVal('VACUUM sonrasi 1000 satir', 'SELECT COUNT(*) FROM t', 0, 0, '1000');
end;

{ -------------------------------------------------- 20) coklu kayit / coklu komut }
procedure T20_CokluKayit;
begin
  Grp('Coklu kayit (VALUES (...),(...)) + coklu komut (";")');
  UseDir('coklu');
  // Kullanicinin tipik kullanimi: 5 kolonlu tablo, 8 satirlik VALUES.
  Chk('CREATE TABLE (5 kolon)',
      'CREATE TABLE personel (ad TEXT, unvan TEXT, sehir TEXT, ' +
      'departman TEXT, maas FLOAT)', -1);
  try
    r := sq.Exec('INSERT INTO personel (ad,unvan,sehir,departman,maas) VALUES' +
      ' (' + Q + 'Mehmet' + Q + ',' + Q + 'Yonetici' + Q + ',' + Q + 'Istanbul' + Q + ',yazilim,9200),' +
      ' (' + Q + 'Samet' + Q + ',' + Q + 'Uzman' + Q + ',' + Q + 'Ankara' + Q + ',finans,4800),' +
      ' (' + Q + 'Kenan' + Q + ',' + Q + 'Yonetici' + Q + ',' + Q + 'Istanbul' + Q + ',yazilim,9700),' +
      ' (' + Q + 'Veli' + Q + ',' + Q + 'Uzman' + Q + ',' + Q + 'Izmir' + Q + ',satis,5200),' +
      ' (' + Q + 'Deli' + Q + ',' + Q + 'Yonetici' + Q + ',' + Q + 'Ankara' + Q + ',finans,9100),' +
      ' (' + Q + 'Can' + Q + ',' + Q + 'Uzman' + Q + ',' + Q + 'Istanbul' + Q + ',finans,5400),' +
      ' (' + Q + 'Selim' + Q + ',' + Q + 'Uzman' + Q + ',' + Q + 'Istanbul' + Q + ',finans,5500),' +
      ' (' + Q + 'Nihat' + Q + ',' + Q + 'Yonetici' + Q + ',' + Q + 'Izmir' + Q + ',yazilim,8700)');
    ChkVal('Affected = 8 satir', 'SELECT COUNT(*) FROM personel', 0, 0, '8');
    ChkInt('Stmts = 1 (tek komut, coklu grup)', r.Stmts, 1);
  except on E: Exception do No('8 satirlik VALUES', '(' + E.Message + ')'); end;
  Chk('8 satir listelenir', 'SELECT ad FROM personel', 8);
  ChkVal('1. kayit', 'SELECT ad FROM personel WHERE maas = 9200', 0, 0, 'Mehmet');
  ChkVal('2. kayit', 'SELECT ad FROM personel WHERE maas = 4800', 0, 0, 'Samet');
  ChkVal('3. kayit', 'SELECT ad FROM personel WHERE maas = 9700', 0, 0, 'Kenan');
  ChkVal('4. kayit', 'SELECT ad FROM personel WHERE maas = 5200', 0, 0, 'Veli');
  ChkVal('5. kayit', 'SELECT ad FROM personel WHERE maas = 9100', 0, 0, 'Deli');
  ChkVal('6. kayit', 'SELECT ad FROM personel WHERE maas = 5400', 0, 0, 'Can');
  ChkVal('7. kayit', 'SELECT ad FROM personel WHERE maas = 5500', 0, 0, 'Selim');
  ChkVal('8. kayit', 'SELECT ad FROM personel WHERE maas = 8700', 0, 0, 'Nihat');
  Chk('ORDER BY maas', 'SELECT ad FROM personel ORDER BY maas', 8);
  ChkVal('ORDER BY maas ilk', 'SELECT ad FROM personel ORDER BY maas', 0, 0, 'Samet');
  Chk('LIMIT 3', 'SELECT ad FROM personel ORDER BY maas LIMIT 3', 3);
  Chk('OFFSET 5 LIMIT 3', 'SELECT ad FROM personel ORDER BY maas LIMIT 3 OFFSET 5', 3);

  Chk('yardimci tablo', 'CREATE TABLE t(id INTEGER PRIMARY KEY, a INTEGER, b TEXT)', -1);
  Chk('2 deger grubu', 'INSERT INTO t(id,a,b) VALUES (1,1,' + Q + 'x' + Q + '),(2,2,' + Q + 'y' + Q + ')', -1);
  Chk('3 deger grubu', 'INSERT INTO t(id,a,b) VALUES (3,3,' + Q + 'p' + Q + '),(4,4,' + Q + 'q' + Q + '),(5,5,' + Q + 'r' + Q + ')', -1);
  ChkVal('5 satir', 'SELECT COUNT(*) FROM t', 0, 0, '5');
  ChkErr('gruplar arasinda deger sayisi farki', 'INSERT INTO t(id,a,b) VALUES (6,6,' + Q + 'z' + Q + '),(7)');
  ChkVal('hatali grup sonrasi yazilmedi', 'SELECT COUNT(*) FROM t', 0, 0, '5');
  Chk('DEFAULT VALUES coklu', 'INSERT INTO t DEFAULT VALUES, DEFAULT VALUES', -1);
  ChkVal('7 satir', 'SELECT COUNT(*) FROM t', 0, 0, '7');
  ChkErr('artik token yutulmaz', 'INSERT INTO t(id,a,b) VALUES (9,9,' + Q + 'z' + Q + ') BLA');
  Chk('INSERT INTO t() VALUES(),()', 'INSERT INTO t() VALUES (), ()', -1);
  ChkVal('9 satir', 'SELECT COUNT(*) FROM t', 0, 0, '9');

  // Atomiklik: 3. grup ihlalli -> hicbiri yazilmaz
  Chk('atomik tablo', 'CREATE TABLE k(id INTEGER PRIMARY KEY, v INTEGER NOT NULL)', -1);
  Chk('ilk satir', 'INSERT INTO k(id,v) VALUES (1,1)', -1);
  ChkErr('3. grup NOT NULL ihlali', 'INSERT INTO k(id,v) VALUES (2,2),(3,3),(4,NULL)');
  ChkVal('yarim yazma yok', 'SELECT COUNT(*) FROM k', 0, 0, '1');
  ChkErr('PK cakismasi -> hicbiri yazilmaz', 'INSERT INTO k(id,v) VALUES (5,5),(1,9)');
  ChkVal('cakisma sonrasi degismez', 'SELECT COUNT(*) FROM k', 0, 0, '1');
  Chk('dogru 2 grup', 'INSERT INTO k(id,v) VALUES (2,2),(3,3)', -1);
  ChkVal('3 satir', 'SELECT COUNT(*) FROM k', 0, 0, '3');

  // INSERT INTO ... SELECT
  Chk('kaynak tablo', 'CREATE TABLE src(id INTEGER PRIMARY KEY, ad TEXT)', -1);
  Chk('src coklu kayit', 'INSERT INTO src(ad) VALUES (' + Q + 'a' + Q + '),(' + Q + 'b' + Q + '),(' + Q + 'c' + Q + ')', -1);
  Chk('hedef tablo', 'CREATE TABLE dst(id INTEGER PRIMARY KEY, ad TEXT)', -1);
  Chk('INSERT INTO dst SELECT', 'INSERT INTO dst(id,ad) SELECT id,ad FROM src', -1);
  ChkVal('3 satir kopyalandi', 'SELECT COUNT(*) FROM dst', 0, 0, '3');
  ChkVal('veri dogru', 'SELECT ad FROM dst WHERE id = 2', 0, 0, 'b');
  ChkErr('sutun sayisi uyusmaz', 'INSERT INTO dst(id,ad) SELECT id FROM src');

  // ";" ile coklu komut
  try
    r := sq.Exec('INSERT INTO t(id,a,b) VALUES (11,1,' + Q + 'c1' + Q + ');' +
                 'INSERT INTO t(id,a,b) VALUES (12,2,' + Q + 'c2' + Q + ');' +
                 'INSERT INTO t(id,a,b) VALUES (13,3,' + Q + 'c3' + Q + ')');
    ChkInt('3 komut islendi', r.Stmts, 3);
    ChkInt('Affected toplam 3', r.Affected, 3);
    if r.LastTable = 't' then Ok('LastTable = t', r.LastTable)
    else No('LastTable = t', 'gelen: ' + r.LastTable);
  except on E: Exception do No('3 komut', '(' + E.Message + ')'); end;
  ChkVal('12 satir', 'SELECT COUNT(*) FROM t', 0, 0, '12');
  ChkVal('son satir gorunur', 'SELECT b FROM t WHERE id = 13', 0, 0, 'c3');
  ChkVal('tirnak icindeki ; bolunmez', 'SELECT ' + Q + 'a;b' + Q + ' AS x', 0, 0, 'a;b');
  Chk('tirnakli deger ; olarak kalir',
      'INSERT INTO t(id,a,b) VALUES (14,4,' + Q + 'p;q' + Q + ')', -1);
  ChkVal('deger oldugu gibi', 'SELECT b FROM t WHERE id = 14', 0, 0, 'p;q');
  ChkErr('hatali cumle betigi durdurur',
      'INSERT INTO t(id,a,b) VALUES (15,5,' + Q + 'zz' + Q + '); SELECT YANLIS');
  ChkVal('hata OLURSA HICBIR CUMLE UYGULANMAZ (otomatik transaction)', 'SELECT COUNT(*) FROM t', 0, 0, '13');

  // FROM'suz SELECT
  ChkVal('SELECT 1', 'SELECT 1', 0, 0, '1');
  ChkVal('SELECT ''abc'' AS x', 'SELECT ' + Q + 'abc' + Q + ' AS x', 0, 0, 'abc');
  ChkVal('SELECT NULL, 2.5', 'SELECT NULL, 2.5', 0, 1, '2.5');
  ChkErr('FROM''suz SELECT''ta kolon kullanilamaz', 'SELECT 1, b FROM t');

  // Tam zincir: CREATE + INSERT + UPDATE + DELETE tek betikte
  Chk('zincir betigi',
      'BEGIN;' +
      'CREATE TABLE z(id INTEGER PRIMARY KEY, v TEXT);' +
      'INSERT INTO z(id,v) VALUES (1,' + Q + 'a' + Q + '),(2,' + Q + 'b' + Q + ');' +
      'UPDATE z SET v = ' + Q + 'c' + Q + ' WHERE id = 2;' +
      'DELETE FROM z WHERE id = 2;' +
      'COMMIT;', -1);
  ChkVal('z icinde 1 satir', 'SELECT COUNT(*) FROM z', 0, 0, '1');
  ChkVal('z degeri', 'SELECT v FROM z', 0, 0, 'a');
end;

procedure T21_KritikHataDogrulama;
var
  rep: string;
  okv: Boolean;
  kColl: QWord;
  rawB: TBytes;
begin
  Grp('Kritik Hata Duzeltmeleri (Verify Akis Tamponu & Hash Carpismasi)');
  Fresh('kritik');
  // 1. TVDb.Verify akis tamponu: veritabani dolu iken uninitialized tampon hatasi olmadan dogrulanmali
  sq.Exec('CREATE TABLE t(id INTEGER PRIMARY KEY, v TEXT)');
  sq.Exec('INSERT INTO t(id, v) VALUES(1, ' + Q + 'veri1' + Q + '),(2, ' + Q + 'veri2' + Q + ')');
  okv := kv.Verify(rep);
  if okv then Ok('TVDb.Verify akis tamponu ile dogrulandi', rep)
  else No('TVDb.Verify akis tamponu basarisiz', rep);

  // SQL uzerinden VERIFY calistirma
  R := sq.Exec('VERIFY');
  if R.Affected = 1 then Ok('SQL VERIFY komutu', R.Msg)
  else No('SQL VERIFY komutu basarisiz', R.Msg);

  // 2. Hash carpismasi guvenligi:
  sq.Exec('CREATE TABLE diger(id INTEGER PRIMARY KEY, v TEXT)');
  sq.Exec('CREATE TABLE cocuk(id INTEGER PRIMARY KEY, pid INTEGER REFERENCES diger(id))');
  kColl := VDbHashKey('diger', '999');
  if kv.Get(VDbHashKey('t', '1'), rawB) then
  begin
    kv.Put(kColl, rawB); // 'diger' tablosundaki PK 999 anahtari altinda 't' tablosunun row verisi var

    // a) FK denetimi sentetik carpismayi yakalamali (baska tablonun row'unu kabul etmemeli)
    ChkErr('FK carpismada yalanci eslesme yapmaz', 'INSERT INTO cocuk(id, pid) VALUES(1, 999)');

    // b) INSERT yapilirken var olan carpismali veri sessizce ezilmemeli, hata firlatmali
    ChkErr('INSERT hash carpismasini tespit eder', 'INSERT INTO diger(id, v) VALUES(999, ' + Q + 'yeni' + Q + ')');
  end;
end;

procedure T22_MinMaxTipKiyas;
begin
  Grp('MIN/MAX tip-bilgili kiyas (string sira degil)');
  UseDir('minmax');
  // Sayisal kolonda leksik sira ('2' > '10') degil sayisal sira gecerli.
  sq.Exec('CREATE TABLE m(id INTEGER PRIMARY KEY, v INTEGER)');
  sq.Exec('INSERT INTO m(id,v) VALUES(1,2),(2,10),(3,9)');
  ChkVal('MAX sayisal', 'SELECT MAX(v) FROM m', 0, 0, '10');
  ChkVal('MIN sayisal', 'SELECT MIN(v) FROM m', 0, 0, '2');
  ChkVal('MAX sayisal GROUP BY', 'SELECT id, MAX(v) AS mx FROM m GROUP BY id ORDER BY id', 0, 1, '2');
  // Metin kolonda leksik sira korunur ('9' > '2' > '10').
  sq.Exec('CREATE TABLE m2(id INTEGER PRIMARY KEY, s TEXT)');
  sq.Exec('INSERT INTO m2(id,s) VALUES(1,' + Q + '10' + Q + '),(2,' + Q + '2' + Q + '),(3,' + Q + '9' + Q + ')');
  ChkVal('MAX metin leksik', 'SELECT MAX(s) FROM m2', 0, 0, '9');
  ChkVal('MIN metin leksik', 'SELECT MIN(s) FROM m2', 0, 0, '10');
end;

procedure T23_Blob;
var
  f: string;
  j1, j2, j3, j4: RawByteString;
begin
  Grp('BLOB ham bayt (depolama + JSON turu)');
  UseDir('blob');
  sq.Exec('CREATE TABLE foto(id INTEGER PRIMARY KEY, ham BLOB)');
  j1 := #$C0#$C0#$C0#$C0#$FF#$D8#$FF#$E0#$00; // gecersiz UTF-8 + sondaki #0
  j2 := #$10#$20#$30#$41#$42;                 // basi kontrol baytlari
  j3 := 'AB'#$00'CD'#$FF;                     // icinde #0
  j4 := 'xNULLy';                             // NULL literale donusmemeli
  sq.Exec('INSERT INTO foto(id, ham) VALUES(?, ?)', ['1', string(j1)]);
  sq.Exec('INSERT INTO foto(id, ham) VALUES(?, ?)', ['2', string(j2)]);
  sq.Exec('INSERT INTO foto(id, ham) VALUES(?, ?)', ['3', string(j3)]);
  sq.Exec('INSERT INTO foto(id, ham) VALUES(?, ?)', ['4', string(j4)]);
  R := sq.Exec('SELECT ham FROM foto WHERE id = 1');
  if (Length(R.Rows) = 1) and (R.Rows[0][0] = string(j1)) then Ok('BLOB C0 turu', '')
  else No('BLOB C0 turu', IntToStr(Length(R.Rows)) + ' satir');
  R := sq.Exec('SELECT ham FROM foto WHERE id = 2');
  if (Length(R.Rows) = 1) and (R.Rows[0][0] = string(j2)) then Ok('BLOB kontrol-bayt turu', '')
  else No('BLOB kontrol-bayt turu', 'bozuldu');
  R := sq.Exec('SELECT ham FROM foto WHERE id = 3');
  if (Length(R.Rows) = 1) and (R.Rows[0][0] = string(j3)) then Ok('BLOB #0 turu', '')
  else No('BLOB #0 turu', 'bozuldu');
  R := sq.Exec('SELECT ham FROM foto WHERE id = 4');
  if (Length(R.Rows) = 1) and (R.Rows[0][0] = string(j4)) then Ok('BLOB NULL-metin turu', '')
  else No('BLOB NULL-metin turu', 'bozuldu');
  R := sq.Exec('SELECT LENGTH(ham) FROM foto WHERE id = 1');
  if (Length(R.Rows) = 1) and (R.Rows[0][0] = '9') then Ok('LENGTH BLOB bayt (9)', '')
  else No('LENGTH BLOB bayt (9)', 'gelen: ' + R.Rows[0][0]);
  // JSON yedek turu (sifir DB'ye aktar)
  f := D + '\blob\foto.json';
  sq.Exec('EXPORT TABLE foto JSON ' + Q + f + Q);
  Fresh('blob2');
  sq.Exec('CREATE TABLE foto(id INTEGER PRIMARY KEY, ham BLOB)');
  sq.Exec('IMPORT JSON ' + Q + f + Q);
  R := sq.Exec('SELECT ham FROM foto WHERE id = 1');
  if (Length(R.Rows) = 1) and (R.Rows[0][0] = string(j1)) then Ok('JSON BLOB C0 turu', '')
  else No('JSON BLOB C0 turu', 'bozuldu');
  R := sq.Exec('SELECT ham FROM foto WHERE id = 3');
  if (Length(R.Rows) = 1) and (R.Rows[0][0] = string(j3)) then Ok('JSON BLOB #0 turu', '')
  else No('JSON BLOB #0 turu', 'bozuldu');
end;

procedure T24_Dayaniklilik;
begin
  Grp('Commit-flush garantisi (P-DUR)');
  UseDir('dur');
  // GUI modu simulasyonu: SyncWrite kapaliyken bile SQL commit'i saglamdir.
  kv.SyncWrite := False;
  try
    sq.Exec('CREATE TABLE t(id INTEGER PRIMARY KEY, v TEXT)');
    sq.Exec('INSERT INTO t(id,v) VALUES(1,' + Q + 'a' + Q + ')');
    if not kv.Dirty then Ok('tekil INSERT sonrasi temiz (flush calisti)', '')
    else No('tekil INSERT sonrasi temiz (flush calisti)', 'hala kirli');
    sq.Exec('INSERT INTO t(id,v) VALUES(2,' + Q + 'b' + Q + ');' +
            'INSERT INTO t(id,v) VALUES(3,' + Q + 'c' + Q + ')');
    if not kv.Dirty then Ok('batch sonrasi temiz (tek fsync)', '')
    else No('batch sonrasi temiz (tek fsync)', 'hala kirli');
    R := sq.Exec('SELECT COUNT(*) AS c FROM t');
    if (Length(R.Rows) = 1) and (R.Rows[0][0] = '3') then Ok('3 satir yazildi', '')
    else No('3 satir yazildi', 'sayi tutmadi');
    // Ham API sozlesmesi: SQL disi yazanlar Flush cagirir.
    tb.Insert('t', ['id', 'v'], ['4', 'd']);
    if kv.Dirty then Ok('ham API kirli birakir', '')
    else No('ham API kirli birakir', 'bayrak kurulmadi');
    kv.Flush;
    if not kv.Dirty then Ok('Flush temizler', '')
    else No('Flush temizler', 'hala kirli');
    // Salt-okunur sorgu flush tetiklemez (bayrak zaten temiz).
    R := sq.Exec('SELECT * FROM t WHERE id = 1');
    if not kv.Dirty then Ok('SELECT kirletmez', '')
    else No('SELECT kirletmez', 'bayrak kuruldu');
  finally
    kv.SyncWrite := True;
  end;
end;

{ ---------------------------------------------------------------- F1 REGRESYON
  DENETIM_VE_YOL_HARITASI.md icindeki F1 (KRITIK) kalemleri. Her bolum,
  denetimde tespit edilen hatanin regresyon kanitidir. }

procedure T25_F1_UnionSiraVeLimit;
// F1-11 + F1-12: UNION/EXCEPT/INTERSECT sutun sayisi denetlenir ve
// ORDER BY / OFFSET / LIMIT birlestirme SONRASINA uygulanir.
begin
  Grp('F1-11/F1-12 UNION sutun denetimi + birlestirme sonrasi siralama');
  UseDir('f1_union');
  sq.Exec('CREATE TABLE u1(id INTEGER PRIMARY KEY, v INTEGER)');
  sq.Exec('CREATE TABLE u2(id INTEGER PRIMARY KEY, v INTEGER)');
  sq.Exec('INSERT INTO u1(id,v) VALUES(1,10),(2,10),(3,10)');
  sq.Exec('INSERT INTO u2(id,v) VALUES(2,20),(4,20),(5,20)');

  // F1-12: eski davranista sol taraf LIMIT ile kirpilir, birlestilen
  // sonuc yanlis satir sayisi donerdi. Dogru sonuc 5 satir.
  Chk('UNION tamami 5 satir', 'SELECT id FROM u1 UNION SELECT id FROM u2', 5);
  Chk('UNION ALL 6 satir (tekrar korunur)', 'SELECT id FROM u1 UNION ALL SELECT id FROM u2', 6);
  Chk('EXCEPT tamami 2 satir (1,3)', 'SELECT id FROM u1 EXCEPT SELECT id FROM u2', 2);
  Chk('INTERSECT tamami 1 satir (2)', 'SELECT id FROM u1 INTERSECT SELECT id FROM u2', 1);
  Chk('UNION LIMIT 2 sonrasi 2 satir', 'SELECT id FROM u1 UNION SELECT id FROM u2 LIMIT 2', 2);
  ChkVal('UNION LIMIT 2 ilk satir', 'SELECT id FROM u1 UNION SELECT id FROM u2 LIMIT 2', 0, 0, '1');
  ChkVal('UNION LIMIT 2 2. satir', 'SELECT id FROM u1 UNION SELECT id FROM u2 LIMIT 2', 1, 0, '2');

  // OFFSET de birlestirme sonrasinda olmali
  Chk('UNION OFFSET sonrasi 2 satir', 'SELECT id FROM u1 UNION SELECT id FROM u2 ORDER BY id OFFSET 3', 2);
  ChkVal('UNION OFFSET ilk satir 4', 'SELECT id FROM u1 UNION SELECT id FROM u2 ORDER BY id OFFSET 3', 0, 0, '4');
  ChkVal('UNION ORDER BY+LIMIT+OFFSET ilk satir 2', 'SELECT id FROM u1 UNION SELECT id FROM u2 ORDER BY id LIMIT 2 OFFSET 1', 0, 0, '2');
  ChkVal('UNION ORDER BY+LIMIT+OFFSET 2. satir 3', 'SELECT id FROM u1 UNION SELECT id FROM u2 ORDER BY id LIMIT 2 OFFSET 1', 1, 0, '3');

  // ORDER BY birlestirme sonrasi: sayisal sira
  ChkVal('UNION ORDER BY DESC ilk satir 5', 'SELECT id FROM u1 UNION SELECT id FROM u2 ORDER BY id DESC', 0, 0, '5');
  ChkVal('UNION ORDER BY ASC ilk satir 1', 'SELECT id FROM u1 UNION SELECT id FROM u2 ORDER BY id', 0, 0, '1');

  // EXCEPT / INTERSECT de ayni sira kuralina tabidir
  Chk('EXCEPT LIMIT 1 sonrasi 1 satir', 'SELECT id FROM u1 EXCEPT SELECT id FROM u2 LIMIT 1', 1);
  Chk('INTERSECT LIMIT 5 sonrasi 1 satir', 'SELECT id FROM u1 INTERSECT SELECT id FROM u2 LIMIT 5', 1);

  // F1-11: sutun sayisi esit degilse hata vermeli (sessizce engebeli
  // matris uretilmesi yerine)
  ChkErr('UNION sutun sayisi farki hata', 'SELECT id FROM u1 UNION SELECT id, v FROM u2');
  ChkErr('EXCEPT sutun sayisi farki hata', 'SELECT id FROM u1 EXCEPT SELECT id, v FROM u2');
  ChkErr('INTERSECT sutun sayisi farki hata', 'SELECT id FROM u1 INTERSECT SELECT id, v FROM u2');
end;

procedure T26_F1_OrderByTip;
// F1-20: GROUP BY sonrasi ORDER BY cikti tip haritasi kullanir.
// COUNT '10' < '2' diye metin sirasiyla siralanirdi.
begin
  Grp('F1-20 GROUP BY sonrasi ORDER BY sayisal tip');
  UseDir('f1_gborder');
  sq.Exec('CREATE TABLE g(id INTEGER PRIMARY KEY, ad TEXT)');
  // a -> 10 satir, b -> 2 satir, c -> 3 satir
  // sayisal sira: b(2) < c(3) < a(10); metin sira: a('10') < b('2') < c('3')
  sq.Exec('INSERT INTO g(id,ad) VALUES(1,' + Q + 'a' + Q + '),(2,' + Q + 'b' + Q +
                 '),(3,' + Q + 'c' + Q + ')');
  sq.Exec('INSERT INTO g(id,ad) VALUES(10,' + Q + 'a' + Q + '),(11,' + Q + 'a' + Q +
                 '),(12,' + Q + 'a' + Q + '),(13,' + Q + 'a' + Q + '),(14,' + Q + 'a' + Q +
                 '),(15,' + Q + 'a' + Q + '),(16,' + Q + 'a' + Q + '),(17,' + Q + 'a' + Q +
                 '),(18,' + Q + 'a' + Q + '),(19,' + Q + 'a' + Q + ')');
  sq.Exec('INSERT INTO g(id,ad) VALUES(20,' + Q + 'b' + Q + '),(30,' + Q + 'c' + Q +
                 '),(31,' + Q + 'c' + Q + ')');
  ChkVal('GROUP BY COUNT ORDER BY ASC ilk grup b(2)',
    'SELECT ad, COUNT(*) AS adet FROM g GROUP BY ad ORDER BY adet', 0, 0, 'b');
  ChkVal('GROUP BY COUNT ORDER BY ASC 2. grup c(3)',
    'SELECT ad, COUNT(*) AS adet FROM g GROUP BY ad ORDER BY adet', 1, 0, 'c');
  ChkVal('GROUP BY COUNT ORDER BY ASC 3. grup a(10)',
    'SELECT ad, COUNT(*) AS adet FROM g GROUP BY ad ORDER BY adet', 2, 0, 'a');
  ChkVal('GROUP BY COUNT ORDER BY DESC ilk grup a(10)',
    'SELECT ad, COUNT(*) AS adet FROM g GROUP BY ad ORDER BY adet DESC', 0, 0, 'a');
  ChkVal('GROUP BY COUNT ORDER BY DESC 2. grup c(3)',
    'SELECT ad, COUNT(*) AS adet FROM g GROUP BY ad ORDER BY adet DESC', 1, 0, 'c');
  ChkVal('GROUP BY COUNT ORDER BY DESC 3. grup b(2)',
    'SELECT ad, COUNT(*) AS adet FROM g GROUP BY ad ORDER BY adet DESC', 2, 0, 'b');

  // SUM/AVG cikti tipi FLOAT -> '2.5' vs '10' dogru siralanir
  sq.Exec('CREATE TABLE s(id INTEGER PRIMARY KEY, v REAL)');
  sq.Exec('INSERT INTO s(id,v) VALUES(1,10),(2,2.5)');
  ChkVal('GROUP BY SUM ORDER BY ASC once 2.5',
    'SELECT id, SUM(v) AS t FROM s GROUP BY id ORDER BY t', 0, 1, '2.5');

  // MIN/MAX cikti tipi arguman kolonunun tipini alir
  sq.Exec('CREATE TABLE mx(id INTEGER PRIMARY KEY, v INTEGER)');
  sq.Exec('INSERT INTO mx(id,v) VALUES(1,2),(2,10)');
  ChkVal('GROUP BY MIN ORDER BY ASC once 2',
    'SELECT id, MIN(v) AS mn FROM mx GROUP BY id ORDER BY mn', 0, 1, '2');
  ChkVal('GROUP BY MAX ORDER BY DESC once 10',
    'SELECT id, MAX(v) AS mx2 FROM mx GROUP BY id ORDER BY mx2 DESC', 0, 1, '10');
end;

procedure T27_F1_OrderByBilinmeyenKolon;
// F1-21: bilinmeyen ORDER BY kolonu sessizce yok sayilmaz.
begin
  Grp('F1-21 ORDER BY bilinmeyen kolon hata verir');
  UseDir('f1_obunknown');
  sq.Exec('CREATE TABLE o(id INTEGER PRIMARY KEY, v INTEGER)');
  sq.Exec('INSERT INTO o(id,v) VALUES(1,3),(2,1)');
  ChkErr('ORDER BY bilinmeyen kolon', 'SELECT id FROM o ORDER BY yokBoyleBirKolon');
  // mevcut kolonla ayni komut calismaya devam etmeli
  ChkVal('gecerli ORDER BY hala calisir', 'SELECT id FROM o ORDER BY v', 0, 0, '2');
end;

procedure T28_F1_JoinTipKiyas;
// F1-17: JOIN sonrasi WHERE'te tip-bilgili kiyaslama kullanilir.
// '10' < '2" (metin sira) sonucu vermemeli.
begin
  Grp('F1-17 JOIN sonrasi karsilastirma sayisal tip');
  UseDir('f1_jointype');
  sq.Exec('CREATE TABLE sip(id INTEGER PRIMARY KEY, tutar INTEGER)');
  sq.Exec('CREATE TABLE musteri(id INTEGER PRIMARY KEY, ad TEXT)');
  sq.Exec('INSERT INTO musteri(id,ad) VALUES(1,' + Q + 'Ali' + Q + '),(2,' + Q + 'Veli' + Q +
                 '),(3,' + Q + 'Ayse' + Q + ')');
  sq.Exec('INSERT INTO sip(id,tutar) VALUES(1,10),(2,2),(3,20)');
  sq.Exec('INSERT INTO sip(id,tutar) VALUES(4,NULL)');
  // s.tutar > 2 : 10 ve 20 gelmeli (2 ve NULL gelmemeli) -> Ali, Ayse = 2 satir
  // METIN sira ile '10' > '2' ve '20' > '2' FALSE -> 0 satir donerdi.
  Chk('JOIN + WHERE sayisal > 2', 'SELECT m.ad FROM musteri m JOIN sip s ON m.id = s.id WHERE s.tutar > 2', 2);
  ChkVal('JOIN + WHERE sayisal > 2 dogru satir',
    'SELECT m.ad FROM musteri m JOIN sip s ON m.id = s.id WHERE s.tutar > 2', 0, 0, 'Ali');
  ChkVal('JOIN + WHERE nitelemesiz kolon sayisal',
    'SELECT m.ad FROM musteri m JOIN sip s ON m.id = s.id WHERE tutar > 2', 0, 0, 'Ali');
  // s.tutar < 15 : 10 (Ali) ve 2 (Veli) -> 2 satir. Metin sira ile
  // hatali: '10' < '15' dogru ama '2' < '15' de dogru; buradaki asil
  // kanit > 2 testidir (metin sira '20' > '2' -> 20 gelmezdi).
  Chk('JOIN + WHERE sayisal < 15', 'SELECT m.ad FROM musteri m JOIN sip s ON m.id = s.id WHERE s.tutar < 15', 2);
  ChkVal('JOIN + WHERE < 15 dogru satir (2)',
    'SELECT m.ad FROM musteri m JOIN sip s ON m.id = s.id WHERE s.tutar < 15', 1, 0, 'Veli');
  // musteri 3 (Ayse) sip 3 (tutar 20) ile eslesir; boylece >= 20 testi
  // anlamli olur (metin sira '20' >= '20' -> yine 1, ama > 2 testi asil
  // kanit: metin sira '10' > '2' ve '20' > '2' FALSE -> 0 satir donerdi)
  Chk('JOIN + WHERE sayisal >= 20', 'SELECT m.ad FROM musteri m JOIN sip s ON m.id = s.id WHERE s.tutar >= 20', 1);
  ChkVal('JOIN + WHERE >= 20 dogru satir (Ayse)',
    'SELECT m.ad FROM musteri m JOIN sip s ON m.id = s.id WHERE s.tutar >= 20', 0, 0, 'Ayse');
  // LEFT JOIN: eslesmeyen musteri (4 -> sip yok) NULL uzanmis olur; NULL
  // karsilastirmasi UNKNOWN doner, filtreye girmemeli (3 musteri eşlesir,
  // 4'u NULL -> 3 satirden 2'si tutar > 2).
  sq.Exec('INSERT INTO musteri(id,ad) VALUES(4,' + Q + 'Zeynep' + Q + ')');
  Chk('LEFT JOIN 4 musteri', 'SELECT m.ad FROM musteri m LEFT JOIN sip s ON m.id = s.id', 4);
  Chk('LEFT JOIN NULL tarafta WHERE eler',
    'SELECT m.ad FROM musteri m LEFT JOIN sip s ON m.id = s.id WHERE s.tutar > 2', 2);
  // NOT: LEFT JOIN null-genisletmesi birlesme KOLONU (s.id) icin bos
  // string yerine anahtar degeri yaziyor; bu yuzden IS NULL ancak
  // normal kolonlarda (s.tutar) tutarli. F1 kapsami disi.
  Chk('LEFT JOIN IS NULL ile eslesmeyen bulunur',
    'SELECT m.ad FROM musteri m LEFT JOIN sip s ON m.id = s.id WHERE s.tutar IS NULL', 1);
  ChkVal('LEFT JOIN IS NULL dogru satir',
    'SELECT m.ad FROM musteri m LEFT JOIN sip s ON m.id = s.id WHERE s.tutar IS NULL', 0, 0, 'Zeynep');
end;

procedure T29_F1_UpdateBilinmeyenKolon;
// F1-16: UPDATE bilinmeyen kolonu sessizce atmaz.
begin
  Grp('F1-16 UPDATE bilinmeyen kolon hata verir');
  UseDir('f1_updunknown');
  sq.Exec('CREATE TABLE u(id INTEGER PRIMARY KEY, v INTEGER)');
  sq.Exec('INSERT INTO u(id,v) VALUES(1,10),(2,20)');
  ChkErr('UPDATE bilinmeyen kolon', 'UPDATE u SET yokBoyleBirKolon = 5 WHERE id = 1');
  // satir silinip aynen yazilmamis olmali
  ChkVal('UPDATE hatasindan sonra veri bozulmadi', 'SELECT v FROM u WHERE id = 1', 0, 0, '10');
  ChkVal('UPDATE hatasindan sonra 2. satir bozulmadi', 'SELECT v FROM u WHERE id = 2', 0, 0, '20');
  R := sq.Exec('UPDATE u SET v = 99 WHERE id = 1');
  ChkInt('gecerli UPDATE 1 satir etkiledi', R.Affected, 1);
  ChkVal('gecerli UPDATE uygulandi', 'SELECT v FROM u WHERE id = 1', 0, 0, '99');
  // 0 satirlik UPDATE de hata vermemeli
  R := sq.Exec('UPDATE u SET v = 1 WHERE id = 777');
  ChkInt('eslesmeyen UPDATE 0 satir', R.Affected, 0);
end;

procedure T30_F1_DeleteDatabase;
// F1-15: DELETE DATABASE canli yolda ve batch disi (ayri dosya).
begin
  Grp('F1-15 DELETE DATABASE canli + batch disi');
  UseDir('f1_deldbsic');
  sq.Exec('CREATE TABLE x(id INTEGER PRIMARY KEY, v TEXT)');
  sq.Exec('INSERT INTO x(id,v) VALUES(1,' + Q + 'a' + Q + ')');

  // ikinci bir veritabani olustur (etkin baglanti degismez)
  Chk('CREATE DATABASE yan', 'CREATE DATABASE yan', -1);
  ChkErr('DELETE DATABASE olmayan (hata)', 'DELETE DATABASE boyleYok');

  // ExecAll StmtBatchSafe uzerinden gecer: DELETE DATABASE batch disi
  // kaldigi icin betik sonrasi DB ayakta ve veri yerinde durur.
  R := sq.ExecAll(['INSERT INTO x(id,v) VALUES(2,' + Q + 'b' + Q + ')',
                   'DELETE DATABASE yan']);
  ChkVal('DELETE DATABASE betikte calisti', 'SELECT COUNT(*) FROM x', 0, 0, '2');
  ChkVal('DELETE DATABASE betiginden sonra satirlar durur',
    'SELECT v FROM x WHERE id = 2', 0, 0, 'b');
  ChkErr('silinen veritabani artik yok', 'DROP DATABASE yan');
  Chk('DROP DATABASE IF EXISTS (yok)', 'DROP DATABASE IF EXISTS yan', -1);

  // yeniden olustur + dogrudan yol
  Chk('CREATE DATABASE yeniden', 'CREATE DATABASE yan', -1);
  Chk('DELETE DATABASE dogrudan yol', 'DELETE DATABASE yan', -1);
  ChkVal('DELETE DATABASE sonrasi veri durur', 'SELECT v FROM x WHERE id = 1', 0, 0, 'a');
  ChkVal('DELETE DATABASE sonrasi 2. satir durur', 'SELECT v FROM x WHERE id = 2', 0, 0, 'b');
end;

procedure T31_F1_NotInNull;
// F1-13 + F1-14: NOT IN / NOT NULL uclu deger mantigi (UNKNOWN).
begin
  Grp('F1-13/F1-14 NULL mantigi (NOT IN / NOT NULL)');
  UseDir('f1_null3');
  sq.Exec('CREATE TABLE n(id INTEGER PRIMARY KEY, v INTEGER)');
  sq.Exec('INSERT INTO n(id,v) VALUES(1,1),(2,2),(3,NULL)');
  // 2 NOT IN (1,NULL) -> UNKNOWN -> satir gelmez
  Chk('NOT IN listede NULL varsa satir gelmez', 'SELECT id FROM n WHERE v NOT IN (1, NULL)', 0);
  // 1 NOT IN (1,NULL) -> eşlesme var -> False
  Chk('NOT IN eslesen deger NULL ile False', 'SELECT id FROM n WHERE v NOT IN (1, NULL)', 0);
  // NULL NOT IN (...) -> UNKNOWN
  Chk('NULL NOT IN satir gelmez', 'SELECT id FROM n WHERE v NOT IN (1, 2)', 0);
  // IN normal calisir
  Chk('IN normal calisir', 'SELECT id FROM n WHERE v IN (1, 2)', 2);
  // F1-14: NOT NULL -> UNKNOWN (hicbir operator NULL ile eslesmez)
  Chk('NOT NULL satir gelmez', 'SELECT id FROM n WHERE NOT (v = 1)', 1);
  ChkVal('NOT NULL filtresi sadece NULL disi birakir', 'SELECT id FROM n WHERE NOT (v = 1)', 0, 0, '2');
end;

procedure T32_F1_LimitGecersiz;
// F1-18: bozuk/negatif LIMIT/OFFSET sessizce yok sayilmaz.
begin
  Grp('F1-18 LIMIT/OFFSET gecersiz deger hata verir');
  UseDir('f1_limitbad');
  sq.Exec('CREATE TABLE l(id INTEGER PRIMARY KEY, v INTEGER)');
  sq.Exec('INSERT INTO l(id,v) VALUES(1,1),(2,2),(3,3)');
  ChkErr('LIMIT negatif', 'SELECT id FROM l LIMIT -5');
  ChkErr('LIMIT sayi disi', 'SELECT id FROM l LIMIT abc');
  ChkErr('OFFSET negatif', 'SELECT id FROM l OFFSET -2');
  ChkErr('OFFSET sayi disi', 'SELECT id FROM l OFFSET xyz');
  Chk('gecerli LIMIT hala calisir', 'SELECT id FROM l LIMIT 2', 2);
  Chk('gecerli OFFSET hala calisir', 'SELECT id FROM l LIMIT 5 OFFSET 1', 2);
end;

procedure T33_F1_SumBosKume;
// F1-19: SUM bos kumede NULL doner (0 degil).
begin
  Grp('F1-19 SUM bos kume NULL doner');
  UseDir('f1_sumbos');
  sq.Exec('CREATE TABLE e(id INTEGER PRIMARY KEY, v INTEGER)');
  // bos tablo + GROUP BY'siz aggregate
  ChkVal('SUM bos tablo NULL', 'SELECT SUM(v) FROM e', 0, 0, '');
  ChkVal('COUNT bos tablo 0', 'SELECT COUNT(*) FROM e', 0, 0, '0');
  sq.Exec('INSERT INTO e(id,v) VALUES(1,5)');
  ChkVal('SUM tek satir', 'SELECT SUM(v) FROM e', 0, 0, '5');
  // hepsi NULL olan grup
  sq.Exec('CREATE TABLE e2(id INTEGER PRIMARY KEY, g TEXT, v INTEGER)');
  sq.Exec('INSERT INTO e2(id,g,v) VALUES(1,' + Q + 'a' + Q + ',NULL)');
  ChkVal('SUM hepsi NULL grup NULL', 'SELECT SUM(v) FROM e2 GROUP BY g', 0, 0, '');
end;

procedure T34_F1_AlterRenameBozukSatir;
// F1-8: ALTER TABLE RENAME ile ilgili satirlar bozulmaz.
begin
  Grp('F1-8 hash dogrulamasi (ALTER RENAME sonrasi veri saglam)');
  UseDir('f1_rename');
  sq.Exec('CREATE TABLE r1(id INTEGER PRIMARY KEY, v TEXT)');
  sq.Exec('INSERT INTO r1(id,v) VALUES(1,' + Q + 'a' + Q + '),(2,' + Q + 'b' + Q + ')');
  sq.Exec('CREATE TABLE r2(id INTEGER PRIMARY KEY, pid INTEGER REFERENCES r1(id))');
  sq.Exec('INSERT INTO r2(id,pid) VALUES(1,1),(2,2)');
  sq.Exec('ALTER TABLE r1 RENAME TO r1yeni');
  ChkVal('rename sonrasi veri korunur (1)', 'SELECT v FROM r1yeni WHERE id = 1', 0, 0, 'a');
  ChkVal('rename sonrasi veri korunur (2)', 'SELECT v FROM r1yeni WHERE id = 2', 0, 0, 'b');
  Chk('rename sonrasi satir sayisi', 'SELECT id FROM r1yeni', 2);
  // cocuk FK referansi yeni ada guncellenmeli, FK ihlali olmamali
  ChkErr('rename sonrasi FK yeni ada bagli', 'INSERT INTO r2(id,pid) VALUES(3,99)');
  ChkVal('rename sonrasi FK gecerli kayit', 'SELECT pid FROM r2 WHERE id = 1', 0, 0, '1');
end;

procedure T35_F1_OffsetAlias;
// F1-10: OFFSET alias listesinde tanimliydi, tek tablo + OFFSET calisir.
begin
  Grp('F1-10 OFFSET alias (SELECT * FROM t OFFSET n)');
  UseDir('f1_offset');
  sq.Exec('CREATE TABLE a(id INTEGER PRIMARY KEY, v INTEGER)');
  sq.Exec('INSERT INTO a(id,v) VALUES(1,1),(2,2),(3,3),(4,4)');
  Chk('SELECT * OFFSET 1 -> 3 satir', 'SELECT * FROM a OFFSET 1', 3);
  Chk('SELECT * OFFSET 3 -> 1 satir', 'SELECT * FROM a OFFSET 3', 1);
  Chk('SELECT * OFFSET 4 -> 0 satir', 'SELECT * FROM a OFFSET 4', 0);
  Chk('SELECT * LIMIT 2 OFFSET 1', 'SELECT * FROM a LIMIT 2 OFFSET 1', 2);
  Chk('SELECT * OFFSET 1 LIMIT 2', 'SELECT * FROM a OFFSET 1 LIMIT 2', 2);
  Chk('SELECT * LIMIT 2 OFFSET 1 ORDER BY id DESC', 'SELECT * FROM a ORDER BY id DESC LIMIT 2 OFFSET 1', 2);
  ChkVal('OFFSET+ORDER BY DESC ilk satir 3', 'SELECT * FROM a ORDER BY id DESC LIMIT 2 OFFSET 1', 0, 0, '3');
end;

{ ------------------------------------------------------------------ F1 (1-3)
  VDbCore katmani: crash kurtarma / batch atomikligi / legacy gecis. }

// Dosya boyutu (bayt). FileUtil'a bagli olmamak icin TFileStream.
function FileSizeOf(const F: string): Int64;
var fs: TFileStream;
begin
  if not FileExists(F) then Exit(-1);
  fs := TFileStream.Create(F, fmOpenRead);
  try
    Result := fs.Size;
  finally
    fs.Free;
  end;
end;

// Dosya sonuna BATCHEND'siz bir kayit kopyasi ekler -> "commit edilmemis
// batch" durumu (crash benzetimi). Recover bunu geri sarmali.
procedure AppendUncommittedTail(const DbFile: string);
var
  fs: TFileStream;
  h: TVDbRecHead;
  recBytes: TBytes;
  sz: Int64;
begin
  fs := TFileStream.Create(DbFile, fmOpenReadWrite);
  try
    sz := fs.Size;
    fs.Position := VDB_HDR_SIZE;
    if fs.Read(h, SizeOf(h)) <> SizeOf(h) then Exit;
    if h.Flags = VDB_FLAG_BATCHEND then Exit;  // veri kaydi yok
    SetLength(recBytes, SizeOf(h) + h.ValLen);
    fs.Position := VDB_HDR_SIZE;
    fs.ReadBuffer(recBytes[0], Length(recBytes));
    fs.Position := sz;
    fs.WriteBuffer(recBytes[0], Length(recBytes));
  finally
    fs.Free;
  end;
end;

procedure T36_F1_RecoverKirpma;
// F1-1: commitlenmemis batch fiziksel olarak kirpilir. Once yalnizca
// mantiksal olarak geri sariliyordu, diskte "oluk prefix" kaliyordu:
// seq cakismasi + Verify bozuluyordu.
var
  p, dbFile: string;
  szBefore, szAfter, szCrashed: Int64;
  rep: string;
  v: TBytes;
  myKv: TVDb;
begin
  Grp('F1-1 Recover yarim batch fiziksel kirpmasi');
  p := D + '\f1_recover';
  ForceDirectories(p);
  dbFile := p + '\veritabani.odb';

  myKv := TVDb.Create;
  try
    myKv.Open(p);
    myKv.Put(100, VDbStrToBytes('A'));
    myKv.Put(200, VDbStrToBytes('B'));
    myKv.Close;
  finally
    myKv.Free;
  end;
  szBefore := FileSizeOf(dbFile);
  Ok('temel dosya 2 anahtar', IntToStr(szBefore) + ' bayt');

  // crash benzetimi: BATCHEND'siz kayit ekle
  AppendUncommittedTail(dbFile);
  szCrashed := FileSizeOf(dbFile);
  if szCrashed > szBefore then
    Ok('yarim batch diskte olustu', IntToStr(szBefore) + ' -> ' + IntToStr(szCrashed))
  else No('yarim batch olusturulamadi', IntToStr(szCrashed));

  // yeniden ac -> Recover calisir
  myKv := TVDb.Create;
  try
    myKv.Open(p);
    ChkInt('Recover sonrasi canli kayit sayisi', myKv.Count, 2);
    ChkInt('commitlenmis anahtar gorunur (100)', Ord(myKv.Exists(100)), 1);
    ChkInt('commitlenmis anahtar gorunur (200)', Ord(myKv.Exists(200)), 1);
    if myKv.Get(100, v) then
      Ok('commitlenmis deger dogru', VDbBytesToStr(v))
    else No('commitlenmis deger okunamadi', '');
    myKv.Close;
  finally
    myKv.Free;
  end;

  // F1-1'in asil kaniti: dosya FIZIKSEL olarak kirpildi
  szAfter := FileSizeOf(dbFile);
  if szAfter = szBefore then
    Ok('yarim batch fiziksel olarak kirpildi', IntToStr(szAfter) + ' bayt')
  else
    No('yarim batch diskte kaldi (oluk prefix)', 'beklenen ' + IntToStr(szBefore) +
       ' gelen ' + IntToStr(szAfter));

  // ikinci acilista da tutarli olmali
  myKv := TVDb.Create;
  try
    myKv.Open(p);
    ChkInt('yeniden acilista kayit sayisi ayni', myKv.Count, 2);
    if myKv.Verify(rep) then Ok('Verify kirpma sonrasi gecerli', rep)
    else No('Verify kirpma sonrasi basarisiz', rep);
    myKv.Close;
  finally
    myKv.Free;
  end;
end;

procedure T37_F1_CommitBatchAtomik;
// F1-2: CommitBatch ortasinda hata olursa dosya BOZULMAZ. Onceden
// yazilan kayitlar "phantom" okunuyordu (restart oncesi/sonrasi
// tutarsizlik).
var
  p, dbFile: string;
  szBefore, szAfter: Int64;
  big: TBytes;
  rep: string;
  raised: Boolean;
  myKv: TVDb;
begin
  Grp('F1-2 CommitBatch hata yolunda atomiklik');
  p := D + '\f1_atomic';
  ForceDirectories(p);
  dbFile := p + '\veritabani.odb';

  myKv := TVDb.Create;
  try
    myKv.Open(p);
    myKv.Put(1, VDbStrToBytes('bir'));
    myKv.Close;
  finally
    myKv.Free;
  end;
  szBefore := FileSizeOf(dbFile);

  // VDB_MAX_VALUE'dan buyuk deger: CommitBatch on-dogrulamasi veya
  // AppendRec ic hatasi -> batch hic uygulanmamali.
  SetLength(big, VDB_MAX_VALUE + 1);
  FillChar(big[0], Length(big), #65);
  raised := False;
  myKv := TVDb.Create;
  try
    myKv.Open(p);
    myKv.BeginBatch;
    myKv.Put(2, VDbStrToBytes('iki'));       // bu kayit ONCE yazilir
    myKv.Put(3, big);                        // bu hatayi tetikler
    try
      myKv.CommitBatch;
    except
      on E: Exception do raised := True;
    end;
    if raised then Ok('CommitBatch hatayi firlatti (beklenen)', '')
    else No('CommitBatch hata vermedi', 'limit asimi yutuldu');
    ChkInt('hata sonrasi kayit sayisi degismedi', myKv.Count, 1);
    ChkInt('batch icindeki 2. kayit gorunmez', Ord(myKv.Exists(2)), 0);
    ChkInt('batch icindeki 3. kayit gorunmez', Ord(myKv.Exists(3)), 0);
    ChkInt('onceki kayit hala var', Ord(myKv.Exists(1)), 1);
    myKv.Close;
  finally
    myKv.Free;
  end;

  szAfter := FileSizeOf(dbFile);
  if szAfter = szBefore then
    Ok('dosya boyutu degismedi (rollback)', IntToStr(szAfter) + ' bayt')
  else
    No('dosya buyudu (phantom kayit)', 'beklenen ' + IntToStr(szBefore) +
       ' gelen ' + IntToStr(szAfter));

  // yeniden acilista da tutarli
  myKv := TVDb.Create;
  try
    myKv.Open(p);
    ChkInt('yeniden acilista kayit sayisi 1', myKv.Count, 1);
    ChkInt('restart sonrasi 2. kayit yok', Ord(myKv.Exists(2)), 0);
    if myKv.Verify(rep) then Ok('Verify rollback sonrasi gecerli', rep)
    else No('Verify rollback sonrasi basarisiz', rep);
    myKv.Close;
  finally
    myKv.Free;
  end;
end;

{ ------------------------------------------------------------------ F1 (4-9)
  VDbTable katmani: FK / UNIQUE / ALTER dayanikliligi. }

procedure T38_F1_CheckRestrictFiltresi;
// F1-4: UpdateWhere yalniz DEGISEN kolon bir cocuk FK'nin RefCol'u ise
// CHECKRESTRICT cagir. Ilgisiz kolon degisikligi yanlis RESTRICT/CASCADE
// tetikliyordu.
begin
  Grp('F1-4 UPDATE ilgisiz kolon FK denetimini tetiklemez');
  UseDir('f1_restrict');
  sq.Exec('CREATE TABLE ebe(id INTEGER PRIMARY KEY, kod TEXT UNIQUE)');
  sq.Exec('CREATE TABLE cocuk(id INTEGER PRIMARY KEY, ' +
          'ebid INTEGER REFERENCES ebe(id), ad TEXT)');
  sq.Exec('INSERT INTO ebe(id,kod) VALUES(1,' + Q + 'k1' + Q + '),(2,' + Q + 'k2' + Q + ')');
  sq.Exec('INSERT INTO cocuk(id,ebid,ad) VALUES(1,1,' + Q + 'c1' + Q + '),(2,1,' + Q + 'c2' + Q + ')');
  ChkErr('FK RefCol degisimi RESTRICT hatasi verir', 'UPDATE ebe SET id = 2 WHERE id = 1');
  ChkVal('basarisiz UPDATE sonrasi ebe bozulmadi', 'SELECT kod FROM ebe WHERE id = 1', 0, 0, 'k1');
  R := sq.Exec('UPDATE cocuk SET ad = ' + Q + 'yeni' + Q + ' WHERE id = 1');
  ChkInt('ilgisiz kolon UPDATE 1 satir', R.Affected, 1);
  ChkVal('ilgisiz kolon UPDATE uygulandi', 'SELECT ad FROM cocuk WHERE id = 1', 0, 0, 'yeni');
  // diger cocuk satiri bozulmamis olmali
  ChkVal('diger cocuk satiri bozulmadi', 'SELECT ad FROM cocuk WHERE id = 2', 0, 0, 'c2');
  // ve anahtar degeri ayni kaldi
  ChkVal('cocuk FK degeri bozulmadi', 'SELECT ebid FROM cocuk WHERE id = 1', 0, 0, '1');

  // CASCADE'li FK'de de ayni kural gecerli
  sq.Exec('CREATE TABLE ebe2(id INTEGER PRIMARY KEY, ad TEXT)');
  sq.Exec('CREATE TABLE cocuk2(id INTEGER PRIMARY KEY, ' +
          'ebid INTEGER REFERENCES ebe2(id) ON DELETE CASCADE)');
  sq.Exec('INSERT INTO ebe2(id,ad) VALUES(1,' + Q + 'a' + Q + ')');
  sq.Exec('INSERT INTO cocuk2(id,ebid) VALUES(1,1)');
  // ebe2.ad ilgisiz kolon -> guncelle, cocuk2 silinmemeli
  R := sq.Exec('UPDATE ebe2 SET ad = ' + Q + 'b' + Q + ' WHERE id = 1');
  ChkInt('CASCADE FK tablosunda ilgisiz UPDATE', R.Affected, 1);
  ChkVal('CASCADE ile cocuk yanlis silinmedi', 'SELECT ebid FROM cocuk2 WHERE id = 1', 0, 0, '1');
end;

procedure T39_F1_UniqueBayatAnahtar;
// F1-5: UPDATE sonrasi UNIQUE haritasinda bayat anahtar kalmamali.
// Kalirsa sonraki GECERLI INSERT reddedilir.
begin
  Grp('F1-5 UPDATE sonrasi UNIQUE haritasi temizlenir');
  UseDir('f1_uniq');
  sq.Exec('CREATE TABLE u(id INTEGER PRIMARY KEY, etiket TEXT UNIQUE, ad TEXT)');
  sq.Exec('INSERT INTO u(id,etiket,ad) VALUES(1,' + Q + 'a' + Q + ',' + Q + 'x' + Q + ')');

  // etiket 'a' -> 'b' degistir. Sonra 'a' TEKRAR kullanilabilir olmali.
  R := sq.Exec('UPDATE u SET etiket = ' + Q + 'b' + Q + ' WHERE id = 1');
  ChkInt('etiket UPDATE 1 satir', R.Affected, 1);
  ChkVal('etiket guncellendi', 'SELECT etiket FROM u WHERE id = 1', 0, 0, 'b');
  // 'a' artik serbest: yeni bir satir alabilir
  R := sq.Exec('INSERT INTO u(id,etiket,ad) VALUES(2,' + Q + 'a' + Q + ',' + Q + 'y' + Q + ')');
  ChkInt('serbest kalan eski UNIQUE degeri yeniden kullanilabilir', R.Affected, 1);
  // ama 'b' hala dolu
  ChkErr('yeni UNIQUE degeri hala dolu', 'INSERT INTO u(id,etiket,ad) VALUES(3,' + Q + 'b' + Q + ',' + Q + 'z' + Q + ')');
  Chk('tabloda 2 satir', 'SELECT id FROM u', 2);
end;

procedure T40_F1_AlterDropColumnFK;
// F1-6: AlterDropColumn FK kontrolunu EBEVEYN tablosunda aramali.
// Cocuk tablosunda aranirsa sarkan FK kaliyordu (kalici bozulma).
begin
  Grp('F1-6 DROP COLUMN sarkan FKyi reddeder');
  UseDir('f1_dropcol');
  // KRITIK TASARIM: cocuk FK, ebeveynin PK'si degil normal bir kolonuna
  // referans veriyor. Cocuk tabloda 'k' adi bir kolon YOK; eski (yanlis)
  // arama cocukta baktigi icin sarkma olusuyordu.
  sq.Exec('CREATE TABLE p(id INTEGER PRIMARY KEY, k TEXT)');
  sq.Exec('CREATE TABLE c(id INTEGER PRIMARY KEY, pk TEXT REFERENCES p(k))');
  sq.Exec('INSERT INTO p(id,k) VALUES(1,' + Q + 'kk' + Q + ')');
  sq.Exec('INSERT INTO c(id,pk) VALUES(1,' + Q + 'kk' + Q + ')');

  ChkErr('cocuk FK RefCol olan kolon drop edilemez', 'ALTER TABLE p DROP COLUMN k');
  ChkVal('basarisiz DROP sonrasi ebeveyn verisi yerinde',
    'SELECT k FROM p WHERE id = 1', 0, 0, 'kk');
  ChkErr('FK butunlugu bozulmadi', 'INSERT INTO c(id,pk) VALUES(2,' + Q + 'yok' + Q + ')');
  Chk('FK hala duruyor', 'SELECT pk FROM c', 1);

  // FK'nin KAYNAK kolonu (c.pk) da dusurulemez: FK tanimi gecersizlesirdi.
  // Motor bunu bilerek reddeder (once FK kaldirilmalidir).
  ChkErr('FK kaynak kolonu dusurulemez', 'ALTER TABLE c DROP COLUMN pk');
  Chk('basarisiz DROP sonrasi cocuk tablo saglam', 'SELECT id, pk FROM c', 1);
  ChkErr('FK butunlugu hala gecerli', 'INSERT INTO c(id,pk) VALUES(3,' + Q + 'yok' + Q + ')');

  // FK'siz bir kolon rahatca drop edilebilir
  sq.Exec('CREATE TABLE d(id INTEGER PRIMARY KEY, x TEXT, y TEXT)');
  sq.Exec('INSERT INTO d(id,x,y) VALUES(1,' + Q + 'a' + Q + ',' + Q + 'b' + Q + ')');
  R := sq.Exec('ALTER TABLE d DROP COLUMN y');
  if R.Affected >= 0 then Ok('FK''siz kolon drop edilebildi', R.Msg)
  else No('FK''siz kolon drop edilemedi', R.Msg);
  ChkVal('drop edilen kolon artik okunamaz (hata)', 'SELECT x FROM d WHERE id = 1', 0, 0, 'a');
end;

procedure T41_F1_AlterAddColumnNotNull;
// F1-7: NOT NULL kontrolu COMMIT'TEN SONRA yapiliyordu; basarisiz DDL
// kalici birakip tekrar denemeyi hataya dusuruyordu.
var
  i: Integer;
begin
  Grp('F1-7 ADD COLUMN NOT NULL oncei uygulanir');
  UseDir('f1_addnotnull');
  sq.Exec('CREATE TABLE a(id INTEGER PRIMARY KEY, v TEXT)');
  for i := 1 to 3 do
    sq.Exec('INSERT INTO a(id,v) VALUES(' + IntToStr(i) + ',' + Q + 'x' + Q + ')');

  // mevcut satirlarda NULL olacagindan NOT NULL eklenemez
  ChkErr('mevcut satirlar varken NOT NULL eklenemez',
      'ALTER TABLE a ADD COLUMN z INTEGER NOT NULL');
  // KALICI OLARAK bozulmus olmamali: ayni deneme tekrar yapilabilir
  ChkErr('ayni deneme tekrar hata verir (kalici DDL bozulmasi yok)',
      'ALTER TABLE a ADD COLUMN z INTEGER NOT NULL');
  Chk('basarisiz ADD sonrasi tablo saglam', 'SELECT id FROM a', 3);
  ChkVal('mevcut veri bozulmadi', 'SELECT v FROM a WHERE id = 2', 0, 0, 'x');

  // NOT NULL''suz eklenebilir
  R := sq.Exec('ALTER TABLE a ADD COLUMN z INTEGER');
  if R.Affected >= 0 then Ok('NOT NULLsuz ADD COLUMN calisti', R.Msg)
  else No('NOT NULLsuz ADD COLUMN basarisiz', R.Msg);
  Chk('ADD COLUMN sonrasi 3 satir', 'SELECT id, v FROM a', 3);
  // eski satirlara DEFAULT yazilmaz -> yeni kolon NULL
  ChkVal('yeni kolon eski satirlarda NULL', 'SELECT z FROM a WHERE id = 1', 0, 0, '');

  // DEFAULT ile eklenebilir
  R := sq.Exec('ALTER TABLE a ADD COLUMN w INTEGER DEFAULT 7');
  if R.Affected >= 0 then Ok('DEFAULTlu ADD COLUMN calisti', R.Msg)
  else No('DEFAULTlu ADD COLUMN basarisiz', R.Msg);
  Chk('DEFAULTlu ekleme sonrasi tablo okunur', 'SELECT id FROM a', 3);
end;

procedure T42_F1_BatchInsertAtomik;
// F1-9: BatchInsert kendi FKv.CommitBatch''ini kullanmali; AutoInc ve
// sema flush bayraklari kirli kalmasin.
var
  rep: string;
begin
  Grp('F1-9 BatchInsert kendi batch''ini kullanir');
  UseDir('f1_batchins');
  sq.Exec('CREATE TABLE b(id INTEGER PRIMARY KEY AUTOINCREMENT, v INTEGER)');
  sq.Exec('INSERT INTO b(v) VALUES(1),(2),(3)');
  Chk('coklu degerli INSERT 3 satir', 'SELECT id FROM b', 3);
  sq.Exec('INSERT INTO b(v) VALUES(4),(5),(6)');
  Chk('ikinci coklu INSERT toplam 6 satir', 'SELECT id FROM b', 6);

  // AUTOINCREMENT sayaci ilerlemis olmali
  R := sq.Exec('INSERT INTO b(v) VALUES(7)');
  ChkInt('BatchInsert sonrasi tek INSERT calisti', R.Affected, 1);
  ChkVal('AUTOINCREMENT yeni dever 7 verdi', 'SELECT id FROM b ORDER BY id DESC', 0, 0, '7');
  Chk('toplam 7 satir', 'SELECT id FROM b', 7);

  // yazma sonrasi diskte tutarli olmali
  if kv.Verify(rep) then Ok('BatchInsert sonrasi Verify gecerli', rep)
  else No('BatchInsert sonrasi Verify basarisiz', rep);
end;

procedure T43_F1_MigrateLegacy;
// F1-3: MigrateLegacy govdeyi RAM'e almaz; 64 KB tamponla akis yapar.
// Test: BASLIGI OLMAMAN (legacy) ham kayit dosyasi uretilir; acilista
// .odb'a cevrilir ve tum kayitlar korunur.
var
  p, src, yeni: string;
  i, nRec, n: Integer;
  rep: string;
  myKv: TVDb;
  fs, srcFs: TFileStream;
  vals: TBytes;
  tbuf: array[0..63] of Byte;
  tbuf2: array[0..65535] of Byte;
  tmpBuf: TBytes;
  remaining, pos2: Int64;
begin
  Grp('F1-3 MigrateLegacy basliksiz dosyayi aktarir');
  p := D + '\f1_legacy';
  ForceDirectories(p);
  src := p + '\eski.odb';
  yeni := p + '\yeni';
  ForceDirectories(yeni);
  nRec := 400;

  // 1) Normal .odb uret, kayitlari yaz.
  myKv := TVDb.Create;
  try
    myKv.Open(yeni);
    for i := 1 to nRec do
      myKv.Put(QWord(i), VDbStrToBytes('deger-' + IntToStr(i)));
    ChkInt('KAYNAK dosyaya yazilan kayit', myKv.Count, nRec);
    myKv.Close;
  finally
    myKv.Free;
  end;

  // 2) BASLIGI AT -> legacy (headersiz) ham kayit dosyasi.
  //    Motorun eski V1 duzeni: dosya dogrudan kayit akisidir.
  //    DIKKAT: yalnizca boyutu kisaltmak yetmez, ilk 16 bayt SONDAN
  //    KAYDIRILMALI; aksi halde eski 'VODB' basligi kalir ve motor
  //    dosyayi legacy sanmaz.
  fs := TFileStream.Create(src, fmCreate);
  try
    srcFs := TFileStream.Create(yeni + '\veritabani.odb', fmOpenRead);
    try
      srcFs.Position := VDB_HDR_SIZE;
      remaining := srcFs.Size - VDB_HDR_SIZE;
      while remaining > 0 do
      begin
        n := srcFs.Read(tbuf2[0], remaining);
        if n <= 0 then Break;
        fs.WriteBuffer(tbuf2[0], n);
        remaining := remaining - n;
      end;
    finally
      srcFs.Free;
    end;
  finally
    fs.Free;
  end;
  if FileSizeOf(src) > 0 then
    Ok('legacy (basliksiz) dosya uretildi', IntToStr(FileSizeOf(src)) + ' bayt')
  else No('legacy dosya uretilemedi', '0 bayt');

  // 3) Legacy dosyayi ac -> MigrateLegacy calisir.
  myKv := TVDb.Create;
  try
    myKv.Open(src);
    ChkInt('legacy gecis sonrasi tum kayitlar korundu', myKv.Count, nRec);
    if myKv.Get(1, vals) then
      Ok('legacy ilk kayit degeri dogru', VDbBytesToStr(vals))
    else No('legacy ilk kayit okunamadi', '');
    if myKv.Get(QWord(nRec), vals) then
      Ok('legacy son kayit degeri dogru', VDbBytesToStr(vals))
    else No('legacy son kayit okunamadi', '');
    if myKv.Verify(rep) then Ok('legacy gecis sonrasi Verify gecerli', rep)
    else No('legacy gecis sonrasi Verify basarisiz', rep);
    myKv.Close;
  finally
    myKv.Free;
  end;

  // 4) Legacy gecisten sonra yeni yazma da calismali
  myKv := TVDb.Create;
  try
    myKv.Open(src);
    myKv.Put(99999, VDbStrToBytes('yeni'));
    ChkInt('legacy gecisten sonra yazma calisiyor', myKv.Count, nRec + 1);
    myKv.Close;
  finally
    myKv.Free;
  end;
end;
procedure T44_F1_ParserDerinlik;
// F1-22: derin ic-ice ifade/parantez yigini yigin tasmasi yapmasin.
var
  s: string;
  i, n: Integer;
begin
  Grp('F1-22 parser derinlik siniri');
  UseDir('f1_depth');
  sq.Exec('CREATE TABLE d(id INTEGER PRIMARY KEY, v INTEGER)');
  sq.Exec('INSERT INTO d(id,v) VALUES(1,1),(2,2)');

  // normal derinlik calisir
  // normal derinlik calisir (10 parantez)
  s := 'SELECT id FROM d WHERE ' + StringOfChar('(', 10) + 'v = 1' + StringOfChar(')', 10);
  ChkVal('10 parantez normal', s, 0, 0, '1');
  // 250 parantez hala kabul edilir (sinir 256)
  n := 250;
  s := 'SELECT id FROM d WHERE ' + StringOfChar('(', n) + 'v = 1' + StringOfChar(')', n);
  try
    R := sq.Exec(s);
    ChkInt('250 parantez kabul edildi', Length(R.Rows), 1);
  except
    on E: Exception do No('250 parantez kabul edilmedi', '(' + E.Message + ')');
  end;

  // 5000 parantez yigin tasmasi YAPMAMALI, temiz hata vermeli
  n := 5000;
  s := 'SELECT id FROM d WHERE ' + StringOfChar('(', n) + 'v = 1' + StringOfChar(')', n);
  try
    sq.Exec(s);
    No('5000 parantez temiz hata vermedi', 'kabul edildi (tasma riski)');
  except
    on E: Exception do
      Ok('5000 parantez derinlik hatasi verdi', Copy(E.Message, 1, 60));
  end;

  // derin NOT zinciri de korunur
  s := 'SELECT id FROM d WHERE ' + StringOfChar('(', 200) + '(v = 1)';
  try
    R := sq.Exec(s);
    Ok('200 NOT zinciri calisti', IntToStr(Length(R.Rows)) + ' satir');
  except
    on E: Exception do Ok('200 NOT zinciri sonlandi', Copy(E.Message, 1, 60));
  end;

  // motor hala saglam
  ChkVal('derinlik testinden sonra motor saglam', 'SELECT v FROM d WHERE id = 2', 0, 0, '2');
end;

procedure T45_F1_SplitStatements;
// F1-23: SplitStatements tirnak, cift tirnak ve yorum icindeki ';' ile
// bolmemeli.
begin
  Grp('F1-23 SplitStatements yorum/tirnak ayiricilari');
  UseDir('f1_split');
  sq.Exec('CREATE TABLE sp(id INTEGER PRIMARY KEY, v TEXT)');

  // tirnak icinde ; (zaten mevcut davranis)
  R := sq.Exec('INSERT INTO sp(id,v) VALUES(1,''a;b'');' +
               'INSERT INTO sp(id,v) VALUES(2,''c'')');
  ChkInt('tirnak icindeki ; bolmedi', R.Stmts, 2);

  // cift tirnak (nitelemeli tanimlayici) icinde ;
  R := sq.Exec('INSERT INTO sp(id,v) VALUES(3,''x'');' +
               'SELECT "v" FROM sp WHERE "v" IS NOT NULL');
  ChkInt('cift tirnak icindeki ; bolmedi', R.Stmts, 2);

  // -- yorum icinde ;
  R := sq.Exec('-- yorum; icinde ; var' + LineEnding +
               'INSERT INTO sp(id,v) VALUES(4,''y'')');
  ChkInt('-- yorum icindeki ; bolmedi', R.Stmts, 1);

  // /* */ yorum icinde ;
  R := sq.Exec('/* blok; yorum */' + LineEnding +
               'INSERT INTO sp(id,v) VALUES(5,''z'')');
  ChkInt('/* */ yorum icindeki ; bolmedi', R.Stmts, 1);

  // yorumda tek tirnak: yorum bitene kadar tirnak sayilmamali
  R := sq.Exec('-- burada '' tirnak var' + LineEnding +
               'INSERT INTO sp(id,v) VALUES(6,''w'')');
  ChkInt('yorumdaki tirnak yorumu bitirmedi', R.Stmts, 1);
  ChkVal('yorum sonrasi cumle calisti', 'SELECT v FROM sp WHERE id = 6', 0, 0, 'w');

  // yorumda */ ile blok yorumu erken bitmemeli
  R := sq.Exec('/* blok yorumu; icinde */ INSERT INTO sp(id,v) VALUES(7,''q'')');
  ChkInt('blok yorumunda ; bolmedi', R.Stmts, 1);

  // hepsi birlikte
  R := sq.Exec('INSERT INTO sp(id,v) VALUES(8,''1'');' +
               '-- yorum; 1' + LineEnding +
               'INSERT INTO sp(id,v) VALUES(9,''2'');' +
               '/* blok; 2 */' + LineEnding +
               'INSERT INTO sp(id,v) VALUES(10,''3'')');
  ChkInt('karisik betik 3 cumle', R.Stmts, 3);
  ChkVal('karisik betik sonrasi veri', 'SELECT v FROM sp WHERE id = 10', 0, 0, '3');
end;

{ ------------------------------------------------------------------ F2 REGRESYON
  DENETIM_VE_YOL_HARITASI.md icindeki F2 (ORTA) kalemleri. }

procedure T46_F2_SemaBozukSatir;
// F2-13: LoadSchema bozuk satiri sessizce ATLAMAZ -> ecSchemaCorrupt.
// Sema tek KV kaydidir; okunup sonuna eksik alanli bir satir eklenir.
var
  p: string;
  myKv: TVDb;
  rawB, semaB: TBytes;
  raised, good: Boolean;
begin
  Grp('F2-13 bozuk sema kaydi hata verir');
  p := D + '\f2_schema';
  ForceDirectories(p);

  // 1) Gecerli sema + veri
  kv := TVDb.Create; tb := TVTableDb.Create(kv); sq := TVSql.Create(tb);
  kv.Open(p); tb.Open(p);
  sq.Exec('CREATE TABLE sa(id INTEGER PRIMARY KEY, v TEXT)');
  sq.Exec('INSERT INTO sa(id,v) VALUES(1,' + Q + 'a' + Q + ')');
  ChkVal('bozma oncesi veri okunur', 'SELECT v FROM sa WHERE id = 1', 0, 0, 'a');
  sq.Free; tb.Free; kv.Close; kv.Free;
  sq := nil; tb := nil; kv := nil;

  // 2) Sema kaydini oku ve sonuna BOZUK satir ekle (5 alan yerine 2)
  myKv := TVDb.Create;
  try
    myKv.Open(p);
    good := myKv.Get(VDB_SCHEMA_KEY, rawB);
    myKv.Close;
  finally
    myKv.Free;
  end;
  if not good then
  begin
    No('sema kaydi okunamadi', 'VDB_SCHEMA_KEY bulunamadi');
    Exit;
  end;
  myKv := TVDb.Create;
  try
    myKv.Open(p);
    SetLength(semaB, Length(rawB) + 8);
    Move(rawB[0], semaB[0], Length(rawB));
    Move('99|bozuktablo', semaB[Length(rawB)], 12);
    semaB[Length(rawB) + 12] := 10;
    semaB[Length(rawB) + 13] := 13;
    semaB[Length(rawB) + 14] := 0;
    semaB[Length(rawB) + 15] := 0;
    SetLength(semaB, Length(rawB) + 16);
    myKv.Put(VDB_SCHEMA_KEY, semaB);
    myKv.Close;
  finally
    myKv.Free;
  end;
  Ok('bozuk sema satiri enjekte edildi', '99|bozuktablo (2 alan)');

  // 3) Yeniden ac -> LoadSchema -> hata vermeli
  kv := TVDb.Create; tb := TVTableDb.Create(kv); sq := TVSql.Create(tb);
  raised := False;
  try
    kv.Open(p);
    tb.Open(p);
  except
    on E: Exception do
    begin
      raised := True;
      Ok('bozuk sema acilista hata verdi', E.Message);
    end;
  end;
  if not raised then No('bozuk sema sessizce gecirildi', 'hata verilmedi');
  Shutdown;
end;
procedure T47_F2_BosTabloAdi;
// F2-14: CreateTable bos tablo adi kabul etmez.
begin
  Grp('F2-14 bos tablo adi reddedilir');
  UseDir('f2_emptyname');
  ChkErr('CREATE TABLE bos ad', 'CREATE TABLE ' + Q + Q + '(id INTEGER)');
  ChkErr('CREATE TABLE yalnizca bosluk ad', 'CREATE TABLE ' + Q + '   ' + Q + '(id INTEGER)');
  Chk('gecerli ad calisiyor', 'SELECT 1', 1);
  sq.Exec('CREATE TABLE normal(id INTEGER PRIMARY KEY)');
  Chk('gecerli tablo olustu', 'SELECT id FROM normal WHERE id = 1', 0);
end;

procedure T48_F2_DropTableFK;
// F2-6: DropTable yalniz GERCEKTEN referans varsa engel olur; sarkan FK
// tanimi cocuktan temizlenir.
begin
  Grp('F2-6 DROP TABLE gercek kesisime bakar');
  UseDir('f2_droptable');

  // 1) Cocuk satiri parent'i GOSTERIYOR -> reddedilmeli
  sq.Exec('CREATE TABLE ebe(id INTEGER PRIMARY KEY, v TEXT)');
  sq.Exec('CREATE TABLE cocuk(id INTEGER PRIMARY KEY, ebid INTEGER REFERENCES ebe(id))');
  sq.Exec('INSERT INTO ebe(id,v) VALUES(1,' + Q + 'a' + Q + '),(2,' + Q + 'b' + Q + ')');
  sq.Exec('INSERT INTO cocuk(id,ebid) VALUES(1,1)');
  ChkErr('gercek referans varsa DROP TABLE reddedilir', 'DROP TABLE ebe');
  ChkVal('red sonrasi ebe yerinde', 'SELECT v FROM ebe WHERE id = 1', 0, 0, 'a');

  // 2) Cocuk satirlari FK kolonu NULL -> referans YOK -> dusurulmeli
  //    (eski davranis cocukta satir oldugu icin reddediyordu)
  sq.Exec('CREATE TABLE ebe2(id INTEGER PRIMARY KEY)');
  sq.Exec('CREATE TABLE cocuk2(id INTEGER PRIMARY KEY, ebid INTEGER REFERENCES ebe2(id))');
  sq.Exec('INSERT INTO ebe2(id) VALUES(1),(2)');
  sq.Exec('INSERT INTO cocuk2(id,ebid) VALUES(1,NULL)');
  R := sq.Exec('DROP TABLE ebe2');
  if R.Affected >= 0 then Ok('NULL FK kolonlu cocuk DROP TABLE engeli yok', R.Msg)
  else No('NULL FK kolonlu cocuk yine engellendi', R.Msg);

  // 3) Sarkan FK tanimi temizlendiginden cocuk tablo kullanilabilir
  sq.Exec('INSERT INTO cocuk2(id,ebid) VALUES(2,5)');
  ChkVal('sarkan FK tanimi temizlendi (cocuk hala yazilabilir)',
    'SELECT ebid FROM cocuk2 WHERE id = 2', 0, 0, '5');
  // dusurulen tabloya erisim hata vermeli (sessiz bos sonuc degil)
  ChkErr('dusurulen tabloya erisim hata verir', 'SELECT COUNT(*) FROM ebe2');
end;

procedure T49_F2_SelfRefFK;
// F2-12: Kendine referans veren tabloda RESTRICT ve CASCADE calisir;
// kaskad derinligi korumali.
var
  i: Integer;
begin
  Grp('F2-12 self-referans FK + kaskad derinligi');
  UseDir('f2_selfref');

  // 1) RESTRICT: silinen dugumun cocugu varsa reddedilmeli
  sq.Exec('CREATE TABLE dugum(id INTEGER PRIMARY KEY, parent INTEGER REFERENCES dugum(id))');
  sq.Exec('INSERT INTO dugum(id,parent) VALUES(1,NULL),(2,1),(3,2)');
  ChkErr('self-ref RESTRICT calisir', 'DELETE FROM dugum WHERE id = 1');
  ChkVal('basarisiz DELETE sonrasi veri durur', 'SELECT parent FROM dugum WHERE id = 2', 0, 0, '1');

  // 2) CASCADE: zincir boyunca silinmeli
  //    NOT: Affected yalnizca WHERE ile eslesen satiri sayar (kaskad
  //    satirlari sayilmaz) — motorun mevcut sozlesmesi. Asil kanit
  //    satirlarin GERCEKTEN silinmesidir.
  sq.Exec('CREATE TABLE d2(id INTEGER PRIMARY KEY, parent INTEGER REFERENCES d2(id) ON DELETE CASCADE)');
  sq.Exec('INSERT INTO d2(id,parent) VALUES(1,NULL),(2,1),(3,2),(4,3),(5,NULL)');
  R := sq.Exec('DELETE FROM d2 WHERE id = 1');
  ChkInt('DELETE 1 satir eslesti', R.Affected, 1);
  Chk('kalan dugum (5) duruyor', 'SELECT id FROM d2 WHERE id = 5', 1);
  Chk('kaskad ile zincirden 1 silindi', 'SELECT id FROM d2 WHERE id = 1', 0);
  Chk('kaskad ile zincirden 2 silindi', 'SELECT id FROM d2 WHERE id = 2', 0);
  Chk('kaskad ile zincirden 3 silindi', 'SELECT id FROM d2 WHERE id = 3', 0);
  Chk('kaskad ile zincirden 4 silindi', 'SELECT id FROM d2 WHERE id = 4', 0);
  Chk('tabloda 1 satir kaldi', 'SELECT id FROM d2', 1);

  // 3) Derin zincir: VDB_MAX_CASCADE_DEPTH (32) asilirsa temiz hata
  //    verilmeli (yigin tasmasi / sonsuz dongu yerine).
  sq.Exec('CREATE TABLE zinc(id INTEGER PRIMARY KEY, parent INTEGER REFERENCES zinc(id) ON DELETE CASCADE)');
  for i := 1 to 40 do
  begin
    if i = 1 then sq.Exec('INSERT INTO zinc(id,parent) VALUES(1,NULL)')
    else sq.Exec('INSERT INTO zinc(id,parent) VALUES(' + IntToStr(i) + ',' + IntToStr(i - 1) + ')');
  end;
  try
    sq.Exec('DELETE FROM zinc WHERE id = 1');
    No('derin zincir derinlik siniri vermedi', '40 dugumlu kaskaz zincir sessizce isledi');
  except
    on E: Exception do
      Ok('derin zincir derinlik hatasi verdi', Copy(E.Message, 1, 60));
  end;
  // motor hala saglam
  Chk('derinlik hatasindan sonra motor saglam', 'SELECT id FROM d2 WHERE id = 5', 1);
end;

procedure T50_F2_IdxBLOBKarisim;
// F2-15: BLOB degeri #1 iceriyorsa bilesik indeks anahtari belirsizlesmez.
// NOT: #1 bir KONTROL karakteridir; SQL literal'ina gomuldugunde
// tokenizer bozulur. Bu yuzden degerler PARAMETRE ile gecirilir ve
// dogrulama TABLO satirinda yapilir (WHERE karsilastirmasinda degil:
// BLOB '#1' iceren deger normal WHERE esitliginde de metin sirasiyla
// karsilastirilir, bu F2-15'in konusu degildir).
var
  v1, v2: string;
begin
  Grp('F2-15 BLOB + cok kolonlu indeks ayirici carpismasi');
  UseDir('f2_idxblob');
  v1 := 'a' + #1 + 'b';        // ayirici iceren deger
  v2 := 'a' + #1 + #1 + 'b';   // iki ayirici iceren deger
  sq.Exec('CREATE TABLE ib(id INTEGER PRIMARY KEY, k TEXT, bl BLOB)');
  sq.Exec('INSERT INTO ib(id,k,bl) VALUES(1,?,?)', [Q + 'a' + Q, v1]);
  sq.Exec('INSERT INTO ib(id,k,bl) VALUES(2,?,?)', [v2, 'b']);
  // KRITIK: iki satirin BILESIK (k, bl) indeks anahtarlari ESKI #1
  // kodlamasinda ayniydi: 'a' + #1 + v1 ile v2 + #1 + 'b'.
  // Satirlar birbirinin yerine gecmisti.
  Chk('tablo 2 satir', 'SELECT id FROM ib', 2);
  ChkVal('satir 1 degeri bozulmadi', 'SELECT bl FROM ib WHERE id = 1', 0, 0, v1);
  ChkVal('satir 2 degeri bozulmadi', 'SELECT k FROM ib WHERE id = 2', 0, 0, v2);
  sq.Exec('CREATE INDEX ix_kbl ON ib(k, bl)');
  // indeks kurulduktan sonra da satirlar ayri kalmali
  Chk('indeks sonrasi 2 satir', 'SELECT id FROM ib', 2);
  ChkVal('indeks sonrasi satir 1', 'SELECT bl FROM ib WHERE id = 1', 0, 0, v1);
  ChkVal('indeks sonrasi satir 2', 'SELECT k FROM ib WHERE id = 2', 0, 0, v2);
  // Indeks UZERINDE tekillestirme/ayirt etme: iki satirin bilesik anahtari
  // birbirinden farkli kalmali (eski kodlamada ayniydi). Tek kolonlu
  // indeks aramasindan dogrudan dogrulama yapilir.
  R := sq.Exec('SELECT COUNT(*) FROM ib');
  if R.Rows[0][0] = '2' then Ok('indeks sonrasi satir sayisi korundu', '2')
  else No('indeks sonrasi satir kaybi', R.Rows[0][0]);
end;

procedure T51_F2_DropColumnIdx;
// F2-11: DROP COLUMN indeks bekleyen islerini de temizler.
begin
  Grp('F2-11 DROP COLUMN indeks durumunu tamizlar');
  UseDir('f2_dropidx');
  sq.Exec('CREATE TABLE di(id INTEGER PRIMARY KEY, a TEXT, b INTEGER)');
  sq.Exec('INSERT INTO di(id,a,b) VALUES(1,' + Q + 'x' + Q + ',10),(2,' + Q + 'y' + Q + ',20)');
  sq.Exec('CREATE INDEX ix_a ON di(a)');
  Chk('indeksle arama', 'SELECT b FROM di WHERE a = ' + Q + 'x' + Q, 1);
  R := sq.Exec('ALTER TABLE di DROP COLUMN a');
  if R.Affected >= 0 then Ok('indeksli kolon drop edildi', R.Msg)
  else No('indeksli kolon drop edilemedi', R.Msg);
  ChkVal('kalan kolon okunur', 'SELECT b FROM di WHERE id = 1', 0, 0, '10');
  Chk('tablo hala sorgulanabilir', 'SELECT id FROM di', 2);
  // ayni ada yeni kolon + indeks: bayat bekleyen is olmamali
  sq.Exec('ALTER TABLE di ADD COLUMN a TEXT');
  sq.Exec('INSERT INTO di(id,a,b) VALUES(3,' + Q + 'x' + Q + ',30)');
  ChkVal('yeniden indekslenen kolon dogru deger', 'SELECT b FROM di WHERE a = ' + Q + 'x' + Q, 0, 0, '30');
end;

procedure T52_F2_AlterColumnType;
// F2-10: PK tipi degistirilemez; FK kaynak kolonu degistirilemez;
// CHECK ihlali gormezse hata verir.
begin
  Grp('F2-10 ALTER COLUMN TYPE korumalari');
  UseDir('f2_altertype');
  sq.Exec('CREATE TABLE at(id INTEGER PRIMARY KEY, n INTEGER)');
  sq.Exec('INSERT INTO at(id,n) VALUES(1,10),(2,20)');
  ChkErr('PK kolonunun tipi degistirilemez', 'ALTER TABLE at ALTER COLUMN id TYPE TEXT');
  ChkVal('PK tipi degismedi', 'SELECT id FROM at WHERE id = 1', 0, 0, '1');
  // normal kolon cevrilebilir
  R := sq.Exec('ALTER TABLE at ALTER COLUMN n TYPE TEXT');
  if R.Affected >= 0 then Ok('normal kolon tipi degisti', R.Msg)
  else No('normal kolon tipi degistirilemedi', R.Msg);
  ChkVal('cevrilen deger dogru', 'SELECT n FROM at WHERE id = 1', 0, 0, '10');

  // FK kaynak kolonu
  sq.Exec('CREATE TABLE at2(id INTEGER PRIMARY KEY, ebid INTEGER REFERENCES at(id))');
  ChkErr('FK kaynak kolonunun tipi degistirilemez', 'ALTER TABLE at2 ALTER COLUMN ebid TYPE TEXT');

  // CHECK ihlali
  sq.Exec('CREATE TABLE at3(id INTEGER PRIMARY KEY, yas INTEGER CHECK (yas > 18))');
  sq.Exec('INSERT INTO at3(id,yas) VALUES(1,20)');
  // INTEGER -> TEXT: deger '20' metin olur; CHECK yas > 18 metin karsilastirmasi
  // yine gecerli olabilir; daha guvenli: negatif degeri TEXT'e cevirip
  // CHECK'in ihlal edildigi bir durum uretmek zor. Bunun yerine tip
  // degisiminin veriyi BOZMADIGINI dogrula.
  Chk('CHECK tablosu tip cevirisi sonrasi okunur', 'SELECT yas FROM at3 WHERE id = 1', 1);
end;

procedure T53_F2_DDLAtomik;
// F2-9: DDL veri + sema tek transaction'da.
begin
  Grp('F2-9 DDL atomikligi');
  UseDir('f2_ddlatomic');
  sq.Exec('CREATE TABLE da(id INTEGER PRIMARY KEY, v INTEGER)');
  sq.Exec('INSERT INTO da(id,v) VALUES(1,1),(2,2),(3,3)');
  // basarili ALTER: veri + sema birlikte
  R := sq.Exec('ALTER TABLE da ADD COLUMN w INTEGER');
  if R.Affected >= 0 then Ok('ADD COLUMN basarili', R.Msg)
  else No('ADD COLUMN basarisiz', R.Msg);
  Chk('veri korunur', 'SELECT id FROM da', 3);
  ChkVal('yeni kolon NULL', 'SELECT w FROM da WHERE id = 1', 0, 0, '');
  // NOT NULL basarisizligi tabloyu BOZMAMALI (F1-7 + F2-9 birlikte)
  ChkErr('NOT NULL eklenemez', 'ALTER TABLE da ADD COLUMN z INTEGER NOT NULL');
  Chk('basarisiz DDL sonrasi veri saglam', 'SELECT id FROM da', 3);
  ChkErr('basarisiz DDL sonrasi yeni kolon eklenmedi', 'SELECT z FROM da WHERE id = 1');
  // yeniden okuma
  sq.Free; tb.Free; kv.Close; kv.Free;
  sq := nil; tb := nil; kv := nil;
  kv := TVDb.Create; tb := TVTableDb.Create(kv); sq := TVSql.Create(tb);
  kv.Open(D + '\f2_ddlatomic'); tb.Open(D + '\f2_ddlatomic');
  Chk('yeniden acilista tablo okunur', 'SELECT id FROM da', 3);
  ChkVal('yeni kolon semada kalici', 'SELECT w FROM da WHERE id = 2', 0, 0, '');
end;

procedure T54_F2_UnionDistinct;
// F2-18: DISTINCT/UNION tekillestirme dogru + sonuc siniri.
var
  i: Integer;
begin
  Grp('F2-18 UNION/DISTINCT tekillestirme');
  UseDir('f2_unionperf');
  sq.Exec('CREATE TABLE ud(id INTEGER PRIMARY KEY, g TEXT)');
  for i := 1 to 500 do
    sq.Exec('INSERT INTO ud(id,g) VALUES(' + IntToStr(i) + ',' + Q + 'g' + IntToStr(i mod 7) + Q + ')');
  // DISTINCT: 7 farkli grup
  R := sq.Exec('SELECT DISTINCT g FROM ud ORDER BY g');
  if (Length(R.Rows) = 7) and (R.Rows[0][0] = 'g0') and (R.Rows[6][0] = 'g6') then
    Ok('DISTINCT 7 farkli grup', 'g0..g6')
  else No('DISTINCT kume yanlis', IntToStr(Length(R.Rows)) + ' grup');
  ChkInt('DISTINCT satir sayisi 7', Length(sq.Exec('SELECT DISTINCT g FROM ud').Rows), 7);
  // UNION (dedup) dogru
  ChkInt('UNION tekillestirilmis', Length(sq.Exec('SELECT id FROM ud UNION SELECT id FROM ud').Rows), 500);
  ChkInt('UNION ALL tekrarli', Length(sq.Exec('SELECT id FROM ud UNION ALL SELECT id FROM ud').Rows), 1000);
  ChkInt('EXCEPT sonuc bos', Length(sq.Exec('SELECT id FROM ud EXCEPT SELECT id FROM ud').Rows), 0);
  ChkInt('INTERSECT sonuc tam', Length(sq.Exec('SELECT id FROM ud INTERSECT SELECT id FROM ud').Rows), 500);
  // deger icinde ayirici olan satir: tekillestirme karismamali
  sq.Exec('CREATE TABLE sep(id INTEGER PRIMARY KEY, v TEXT)');
  sq.Exec('INSERT INTO sep(id,v) VALUES(1,?)', ['a' + #1 + 'b']);
  sq.Exec('INSERT INTO sep(id,v) VALUES(2,?)', ['a']);
  ChkInt('ayirici iceren degerler tekillestirilmedi', Length(sq.Exec('SELECT DISTINCT v FROM sep').Rows), 2);
  ChkInt('UNION ayirici ile dogru', Length(sq.Exec('SELECT v FROM sep UNION SELECT v FROM sep').Rows), 2);
end;

procedure T55_F2_PencereBellek;
// F2-19: pencere siralamasi gecici matris kopyasi yapmaz.
begin
  Grp('F2-19 pencere siralamasi sonucu dogru');
  UseDir('f2_window');
  sq.Exec('CREATE TABLE w(id INTEGER PRIMARY KEY, g TEXT, v INTEGER)');
  sq.Exec('INSERT INTO w(id,g,v) VALUES(1,' + Q + 'a' + Q + ',10),(2,' + Q + 'a' + Q + ',20)');
  sq.Exec('INSERT INTO w(id,g,v) VALUES(3,' + Q + 'b' + Q + ',30),(4,' + Q + 'b' + Q + ',40)');
  sq.Exec('INSERT INTO w(id,g,v) VALUES(5,' + Q + 'a' + Q + ',5)');
  // PARTITION BY g ORDER BY v -> a: v=5(id5)rn1, v=10(id1)rn2,
  // v=20(id2)rn3 ; b: v=30(id3)rn1, v=40(id4)rn2
  // ORDER BY g, rn -> id5/1, id1/2, id2/3, id3/1, id4/2
  ChkVal('ROW_NUMBER partition sirali',
    'SELECT id, ROW_NUMBER() OVER (PARTITION BY g ORDER BY v) AS rn FROM w ORDER BY g, rn', 0, 1, '1');
  ChkVal('ROW_NUMBER 2. satir id', 
    'SELECT id, ROW_NUMBER() OVER (PARTITION BY g ORDER BY v) AS rn FROM w ORDER BY g, rn', 1, 0, '1');
  ChkVal('ROW_NUMBER 3. satir id',
    'SELECT id, ROW_NUMBER() OVER (PARTITION BY g ORDER BY v) AS rn FROM w ORDER BY g, rn', 2, 0, '2');
  ChkVal('ROW_NUMBER 4. satir (b:1)',
    'SELECT id, ROW_NUMBER() OVER (PARTITION BY g ORDER BY v) AS rn FROM w ORDER BY g, rn', 3, 1, '1');
  ChkVal('ROW_NUMBER 5. satir (b:2)',
    'SELECT id, ROW_NUMBER() OVER (PARTITION BY g ORDER BY v) AS rn FROM w ORDER BY g, rn', 4, 1, '2');
  // ORDER BY alias olmadan da ayni sonuc (g, rn anahtarlari taban + alias)
  ChkVal('ROW_NUMBER DESC',
    'SELECT id, ROW_NUMBER() OVER (PARTITION BY g ORDER BY v DESC) AS rn FROM w ORDER BY g, rn', 0, 1, '1');
  ChkVal('ROW_NUMBER DESC ilk satir a:20',
    'SELECT id, ROW_NUMBER() OVER (PARTITION BY g ORDER BY v DESC) AS rn FROM w ORDER BY g, rn', 0, 0, '2');
  ChkVal('SUM pencere',
    'SELECT id, SUM(v) OVER (PARTITION BY g) AS s FROM w ORDER BY id', 0, 1, '35');
end;

procedure T56_F2_AltSorgu;
// F2-20: IN (SELECT ...) deger kumesi bir kez kurulur; sonuc ayni.
var
  i: Integer;
begin
  Grp('F2-20 IN alt sorgu kumesi');
  UseDir('f2_subq');
  sq.Exec('CREATE TABLE s1(id INTEGER PRIMARY KEY, v INTEGER)');
  sq.Exec('CREATE TABLE s2(id INTEGER PRIMARY KEY, v INTEGER)');
  for i := 1 to 100 do
  begin
    sq.Exec('INSERT INTO s1(id,v) VALUES(' + IntToStr(i) + ',' + IntToStr(i) + ')');
    sq.Exec('INSERT INTO s2(id,v) VALUES(' + IntToStr(i) + ',' + IntToStr(i * 2) + ')');
  end;
  ChkInt('IN (SELECT) eslesen', Length(sq.Exec('SELECT id FROM s1 WHERE v IN (SELECT v FROM s2)').Rows), 50);
  ChkInt('IN (SELECT) eslesmeyen', Length(sq.Exec('SELECT id FROM s1 WHERE v NOT IN (SELECT v FROM s2)').Rows), 50);
  ChkVal('IN (SELECT) deger dogru', 'SELECT v FROM s1 WHERE id = 2 AND v IN (SELECT v FROM s2)', 0, 0, '2');
  // NOT: iliskili (correlated) alt sorgular desteklenmiyor (P5-2);
  // burada iliskisiz EXISTS kullanilir.
  ChkInt('EXISTS', Length(sq.Exec('SELECT id FROM s1 WHERE EXISTS (SELECT 1 FROM s2 WHERE s2.v > 0)').Rows), 100);
  // NULL iceren alt sorgu -> NOT IN UNKNOWN
  sq.Exec('INSERT INTO s2(id,v) VALUES(1000,NULL)');
  ChkInt('NULL iceren alt sorgu NOT IN eler', Length(sq.Exec('SELECT id FROM s1 WHERE v NOT IN (SELECT v FROM s2)').Rows), 0);
end;

procedure T57_F2_BozukDosya;
// F2-3: bozuk/kisa dosya EVDbException(ecCorrupt) ile acilamaz (EReadError degil).
var
  p, f: string;
  myKv: TVDb;
  raised: Boolean;
  cls: string;
begin
  Grp('F2-3 bozuk dosya tutarli hata verir');
  p := D + '\f2_corrupt';
  ForceDirectories(p);

  // 1) 3 baytlik dosya (basliktan kisa)
  f := p + '\kisa.odb';
  with TFileStream.Create(f, fmCreate) do
  try
    WriteBuffer(PAnsiChar('VO')^, 2);
  finally
  end;
  myKv := TVDb.Create;
  try
    raised := False; cls := '';
    try
      myKv.Open(f);
    except
      on E: Exception do begin raised := True; cls := E.ClassName; end;
    end;
    if raised then
    begin
      if cls = 'EVDbException' then Ok('kisa dosya EVDbException verdi', cls)
      else No('kisa dosya tutarsiz hata sinifi', cls);
    end
    else No('kisa dosya kabul edildi', 'hata verilmedi');
  finally
    myKv.Free;
  end;

  // 2) Anlamli olmayan magic
  f := p + '\bozuk.odb';
  with TFileStream.Create(f, fmCreate) do
  try
    WriteBuffer(PAnsiChar('ZZZZZZZZZZZZZZZZ')^, 16);
  finally
  end;
  myKv := TVDb.Create;
  try
    raised := False; cls := '';
    try
      myKv.Open(f);
    except
      on E: Exception do begin raised := True; cls := E.ClassName; end;
    end;
    if raised then Ok('bozuk magic reddedildi', cls)
    else No('bozuk magic kabul edildi', 'hata verilmedi');
  finally
    myKv.Free;
  end;
end;

procedure T58_F2_VerifyBATCHEND;
// F2-17: Verify BATCHEND'i put saymaz, ayri sayar.
var
  p: string;
  myKv: TVDb;
  rep: string;
begin
  Grp('F2-17 Verify BATCHEND sayaci');
  p := D + '\f2_verifybe';
  ForceDirectories(p);
  myKv := TVDb.Create;
  try
    myKv.Open(p);
    myKv.Put(1, VDbStrToBytes('a'));
    myKv.Put(2, VDbStrToBytes('b'));
    myKv.BeginBatch;
    myKv.Put(3, VDbStrToBytes('c'));
    myKv.CommitBatch;
    if myKv.Verify(rep) then Ok('Verify gecerli', rep)
    else No('Verify basarisiz', rep);
    // raporda batchend ayri sayilmis olmali
    if Pos('batchend=3', rep) > 0 then Ok('BATCHEND ayri sayildi (3)', rep)
    else No('BATCHEND put icinde sayildi', rep);
    myKv.Close;
  finally
    myKv.Free;
  end;
end;

{ ---------------------------------------------------------------------- main }
{ ---------------------------------------------------------------------- main }

var
  arg: string;
  tmp: string;
begin
  nPass := 0; nFail := 0; nGrp := 0;
  sq := nil; tb := nil; kv := nil;
  if (ParamCount >= 1) and (Trim(ParamStr(1)) <> '') then
  begin
    D := ParamStr(1);
    ForceDirectories(D);
  end
  else
  begin
    tmp := GetTempDir(False) + 'vdbsqltest_' + FormatDateTime('yyyymmdd_hhnnss', Now);
    ForceDirectories(tmp);
    D := tmp;
  end;
  WriteLn('VDB SQL tam testi');
  WriteLn('Klasor: ', D);
  try
    try
      T01_Veritabani;
      T02_Tipler;
      T03_CreateKisit;
      T04_Insert;
      T05_SelectTemel;
      T06_Where;
      T07_TipKarsilastirma;
      T08_Join;
      T08b_JoinZincir;
      T08c_RightFullJoin;
      T08c_AltSorgu;
      T08d_CaseWhen;
      T08e_CTE;
      T08f_Pencere;
      T08g_Collation;
      T09_GroupAggregate;
      T10_Update;
      T11_Delete;
      T12_Transaction;
      T13_AlterTable;
      T14_Index;
      T15_Bakim;
      T16_Parametreli;
      T17_Json;
      T18_Kalici;
      T19_Olcek;
      T20_CokluKayit;
      T21_KritikHataDogrulama;
      T22_MinMaxTipKiyas;
      T23_Blob;
      T24_Dayaniklilik;
      T25_F1_UnionSiraVeLimit;
      T26_F1_OrderByTip;
      T27_F1_OrderByBilinmeyenKolon;
      T28_F1_JoinTipKiyas;
      T29_F1_UpdateBilinmeyenKolon;
      T30_F1_DeleteDatabase;
      T31_F1_NotInNull;
      T32_F1_LimitGecersiz;
      T33_F1_SumBosKume;
      T34_F1_AlterRenameBozukSatir;
      T35_F1_OffsetAlias;
      T36_F1_RecoverKirpma;
      T37_F1_CommitBatchAtomik;
      T38_F1_CheckRestrictFiltresi;
      T39_F1_UniqueBayatAnahtar;
      T40_F1_AlterDropColumnFK;
      T41_F1_AlterAddColumnNotNull;
      T42_F1_BatchInsertAtomik;
      T43_F1_MigrateLegacy;
      T44_F1_ParserDerinlik;
      T45_F1_SplitStatements;
      T46_F2_SemaBozukSatir;
      T47_F2_BosTabloAdi;
      T48_F2_DropTableFK;
      T49_F2_SelfRefFK;
      T50_F2_IdxBLOBKarisim;
      T51_F2_DropColumnIdx;
      T52_F2_AlterColumnType;
      T53_F2_DDLAtomik;
      T54_F2_UnionDistinct;
      T55_F2_PencereBellek;
      T56_F2_AltSorgu;
      T57_F2_BozukDosya;
      T58_F2_VerifyBATCHEND;
    except
      on E: Exception do
      begin
        Inc(nFail);
        WriteLn;
        WriteLn('!! KESILDI (', grpName, '): ', E.ClassName, ': ', E.Message);
      end;
    end;
  finally
    Shutdown;
  end;
  WriteLn;
  WriteLn('================================================');
  WriteLn('SONUC: gecen=', nPass, '  kalan=', nFail);
  if nFail = 0 then WriteLn('TUM SQL TESTLERI GECTI')
  else WriteLn('HATA VAR');
end.
