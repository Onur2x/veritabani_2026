unit VDbSync;

{$mode delphi}

interface

uses
  Classes;

procedure VDbFlushStream(S: TFileStream);
// Dizin girdisini (dosya olusturma/rename/silme) kalici hale getirir.
// F2-1: ONCEDEN hatalar TAMAMEN YUTULUYORDU (Unix'te FpOpen ve
// FpFsync hatalari kontrol edilmiyordu). Artik sonuc dondurur:
//   True  = dizin girdisi kalici (veya Windows: islem gerekmiyor)
//   False = dizin fsync yapilamadi -> rename/silme kalici OLMAYABILIR
// cagiran taraf bunu loglayip karar vermelidir (bkz. VDbCore.ReplaceWith).
function VDbFlushDir(const DirPath: string): Boolean;
// Ayni dosyayi ikinci kez acmayi engeller (cift-yazma bozulmasina karsi).
// Unix'te flock, Windows'ta LockFileEx. Kilit alinamazsa False.
function VDbLockStream(S: TFileStream): Boolean;
procedure VDbUnlockStream(S: TFileStream);

implementation

uses
  SysUtils
  {$IFDEF WINDOWS}, Windows{$ENDIF}
  {$IFDEF UNIX}, BaseUnix{$ENDIF};

procedure VDbFlushStream(S: TFileStream);
begin
  if S = nil then Exit;
  {$IFDEF WINDOWS}
  if not Windows.FlushFileBuffers(S.Handle) then
    RaiseLastOSError;
  {$ELSE}
    {$IFDEF UNIX}
    if FpFsync(S.Handle) <> 0 then
      RaiseLastOSError;
    {$ELSE}
    S.Flush;
    {$ENDIF}
  {$ENDIF}
end;

function VDbFlushDir(const DirPath: string): Boolean;
{$IFDEF UNIX}
var
  fd: cint;
  ok: Boolean;
{$ENDIF}
begin
  // Windows: NTFS gunluk sistemi dosya adi/dizin guncellemelerini atomik
  // yonetir; ayrica bir islem gerekmez.
  Result := True;
  if DirPath = '' then Exit;
  {$IFDEF UNIX}
  fd := FpOpen(PChar(DirPath), O_RDONLY);
  if fd < 0 then
  begin
    // F2-1: once bu durum sessizce yutuluyordu. Dizin acilamiyorsa
    // kalicilik garanti EDILEMEZ; False don.
    Exit(False);
  end;
  ok := False;
  try
    ok := FpFsync(fd) = 0;   // F2-1: FpFsync sonucu kontrol ediliyor
  finally
    FpClose(fd);
  end;
  Result := ok;
  {$ENDIF}
end;

function VDbLockStream(S: TFileStream): Boolean;
{$IFDEF WINDOWS}
var
  ov: TOverlapped;
{$ENDIF}
begin
  Result := False;
  if S = nil then Exit;
  {$IFDEF WINDOWS}
  FillChar(ov, SizeOf(ov), 0);
  Result := Windows.LockFileEx(S.Handle,
    LOCKFILE_EXCLUSIVE_LOCK or LOCKFILE_FAIL_IMMEDIATELY, 0,
    $FFFFFFFF, $FFFFFFFF, @ov);
  {$ELSE}
    {$IFDEF UNIX}
    // LOCK_EX=2, LOCK_NB=4 (POSIX flock)
    Result := FpFlock(S.Handle, 2 or 4) = 0;
    {$ELSE}
    Result := True;
    {$ENDIF}
  {$ENDIF}
end;

procedure VDbUnlockStream(S: TFileStream);
{$IFDEF WINDOWS}
var
  ov: TOverlapped;
{$ENDIF}
begin
  if S = nil then Exit;
  {$IFDEF WINDOWS}
  FillChar(ov, SizeOf(ov), 0);
  Windows.UnlockFileEx(S.Handle, 0, $FFFFFFFF, $FFFFFFFF, @ov);
  {$ELSE}
    {$IFDEF UNIX}
    FpFlock(S.Handle, 8); // LOCK_UN
    {$ENDIF}
  {$ENDIF}
end;

end.
