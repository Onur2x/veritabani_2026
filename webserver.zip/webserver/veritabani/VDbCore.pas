unit VDbCore;

{ V1: append-only UInt64 -> Bytes motoru. DLL yok, saf FPC.
  Format (little-endian, packed):
    magic:u32=$56444231  crc:u32  seq:u64  key:u64  vallen:u32  flags:u8
    + value[vallen]
  crc = CRC32(seq + key + vallen + flags + value)
  flags: 0=put, 1=del
  Crash kurali: sadece dosya sonu yirtik olabilir, acilista truncate edilir.
}

{$mode delphi}

interface

uses
  Classes, SysUtils, SyncObjs, Generics.Collections, FileUtil, VDbErr;

const
  VDB_MAGIC = $56444231;
  VDB_FLAG_PUT = 0;
  VDB_FLAG_DEL = 1;
  // Batch commit isareti: bu bayrakli kayit yazilmadan onceki batch
  // kayitlari UYGULANMAZ (recovery'de geri sarilir). Boylece COMMIT
  // gercekten atomik olur: ya hepsi gecerli, ya hicbiri.
  VDB_FLAG_BATCHEND = 2;
  VDB_FLAG_ENCRYPTED = 4;   // Faz D: Encryption (AES)
  VDB_FLAG_COMPRESSED = 8;  // Faz D: Compression (ZLIB)
  VDB_MAX_VALUE = 16 * 1024 * 1024;

  // Dosya kimligi: her .odb 'VODB'(LE) + surum + bayrak + baslik CRC ile baslar.
  // Kayitlar hep VDB_HDR_SIZE sonrasinda. Ham kayit akisiyla karismaz.
  VDB_FILE_MAGIC = $42444F56; // 'VODB' little-endian
  // SURUM 2: Flags=2 (BATCHEND) eklendi. Daha onceki surum (1) bu bayragi
  // bilmez; Recovery'de "bozuk kayit" sanip dosyayi kirpar -- yani commit
  // edilmis veri SILINIR. Bu yuzden surum yukseltildi: eski surumlu build
  // surumu okuyamayinca dosyayi ACAMAZ (temiz hata) ama KIRPMAZ.
  // V1 dosyalar acildiginda V2'ye yukseltilir (bkz. DetectFormat).
  VDB_FILE_VER = 2;
  VDB_FILE_VER_OLD = 1;
  VDB_HDR_SIZE = 16;

type
  TQWordArray = array of QWord;
  TValArray = array of TBytes;
  TDbLoc = record
    Offset: Int64;
    Size: LongWord;
    Seq: QWord;
  end;

  TPendOp = record
    Key: QWord;
    Value: TBytes;
    IsDel: Boolean;
  end;

  TVDbRecHead = packed record
    Magic: LongWord;
    Crc: LongWord;
    Seq: QWord;
    Key: QWord;
    ValLen: LongWord;
    Flags: Byte;
  end;

  TVDbFileHead = packed record
    Magic: LongWord; // VDB_FILE_MAGIC
    Ver: LongWord;   // VDB_FILE_VER
    Flags: LongWord; // 0
    Crc: LongWord;   // ilk 12 byte'in CRC32'si
  end;

  TVDb = class
  private
    FDir: string;
    FPath: string;
    FS: TFileStream;
    FLock: TCriticalSection;
    FIndex: TDictionary<QWord, TDbLoc>;
    FSeq: QWord;
    FSyncWrite: Boolean;
    FInBatch: Boolean;
    // P-DUR: fsync'lenmemis yazma var mi? AppendRec/AppendBatchEnd kurar,
    // Flush ve CommitBatch temizler. TVSql.Exec basarili yazma sonrasi
    // kirliyse Flush cagirir -> SQL katmaninda SyncWrite ayarindan bagimsiz
    // commit garantisi (salt-okunur sorgularda syscall yok).
    FDirty: Boolean;
    // Bekleyen (batch ici) yazmalar.
    //
    // FPending   : yazma sirasiyla islenen op listesi
    // FPendingIdx: key -> op'in bulundugu slot (O(1) okuma icin)
    // FPutSeen   : bu batch icinde EN AZ BIR KEZ yazilmis anahtarlar.
    //              Put icindeki "eski op'i kaldir" taramasi yalnizca
    //              anahtar batch icinde daha once gorulduyse gerekir
    //              (yoksa silinecek op yoktur). Bu sayede toplu yukleme
    //              O(n^2) yerine O(n) olur ve DAVRANIS BIT BIT AYNIDIR.
    FPending: TList<TPendOp>;
    FPendingPuts: TDictionary<QWord, Byte>;
    FPendingDels: TDictionary<QWord, Byte>;
    FPendingIdx: TDictionary<QWord, Integer>; // key -> op indeksi (O(1))
    FPutSeen: TDictionary<QWord, Byte>;       // batch icinde yazilmis key'ler
    FClosed: Boolean;
    FDataStart: Int64;
    FLcked: Boolean;
    FRestored: Boolean;
  // F2-2: dizin (dosya adi) girdisi fsync edilemedi. Veri dosyasi
  // duruyor ama crash sonrasi dosya adi kaybolabilir.
  FDirSyncFailed: Boolean;
  FNewFile: Boolean;
    FDeadBytes: Int64;
    procedure CheckOpen;
    function RecCrc(Seq, Key: QWord; ValLen: LongWord; Flags: Byte; Value: PByte): LongWord;
    function HeadCrc(const H: TVDbFileHead): LongWord;
    procedure WriteHeaderTo(S: TStream);
    procedure DetectFormat;
    procedure MigrateLegacy;
    procedure ReplaceWith(const TmpPath: string);
    procedure AppendRec(Key: QWord; const Value: TBytes; IsDel: Boolean; DoFlush: Boolean);
    procedure AppendBatchEnd(DoFlush: Boolean);
    procedure AppendBatchEndTo(S: TStream; ASeq: QWord);
    procedure Recover;
    function FindPending(Key: QWord; out Op: TPendOp): Boolean;
    procedure PendingAdd(const Op: TPendOp);
    procedure PendingRemove(const Idx: Integer);
    procedure PendingClear;
    function PendingCount: Integer;
  public
    constructor Create;
    destructor Destroy; override;
    procedure Open(const Dir: string);
    procedure Close;
    procedure Put(Key: QWord; const Value: TBytes);
    function Get(Key: QWord; out Value: TBytes): Boolean;
    function Exists(Key: QWord): Boolean;
    function Delete(Key: QWord): Boolean;
    procedure BeginBatch;
    procedure CommitBatch;
    procedure AbortBatch; // NOT: tablo indexleri onarilmaz, TVTableDb.AbortBatch kullan
    procedure Flush;
    function Count: Integer;
    function GetAllKeys: TQWordArray;
    procedure ScanAll(out Keys: TQWordArray; out Vals: TValArray);
    procedure Compact(out OldBytes, NewBytes: Int64);
    function AutoCompact(out OldBytes, NewBytes: Int64;
      MaxDeadRatio: Double = 0.3; MinBytes: Int64 = 65536): Boolean;
    function Verify(out Report: string): Boolean;
    function GetIsOpen: Boolean;
    procedure BackupTo(const DestPath: string);
    // WAL Motor Entegrasyonu (Gelecek Projeler - Sifir Veri Kaybi)
    function WriteAheadWAL(Key: QWord; const Value: TBytes; Flags: Byte = VDB_FLAG_PUT): Boolean;
    function ReplayWAL: Boolean;
    function CheckpointWAL: Boolean;
    function HasWAL: Boolean;
    property FilePath: string read FPath;
    property IsOpen: Boolean read GetIsOpen;
    property RestoredFromBak: Boolean read FRestored;
  // F2-2: dizin fsync basarisiz (Unix). True ise veri dosyada duruyor
  // ama dosya adi kalici degil; isletme bir uyari vermelidir.
  property DirSyncFailed: Boolean read FDirSyncFailed;
    property DeadBytes: Int64 read FDeadBytes;
    property SyncWrite: Boolean read FSyncWrite write FSyncWrite;
    property InBatch: Boolean read FInBatch;
    // P-DUR: fsync bekleyen yazma var mi (ham API ile toplu yukleyenler
    // bitince Flush cagirir; SQL katmani kendisi halleder).
    property Dirty: Boolean read FDirty;
  end;

function VDbStrToBytes(const S: RawByteString): TBytes;
function VDbBytesToStr(const B: TBytes): RawByteString;

implementation

uses
  VDbCrc32, VDbSync;

function VDbStrToBytes(const S: RawByteString): TBytes;
begin
  SetLength(Result, Length(S));
  if Length(S) > 0 then Move(S[1], Result[0], Length(S));
end;

function VDbBytesToStr(const B: TBytes): RawByteString;
begin
  SetLength(Result, Length(B));
  if Length(B) > 0 then Move(B[0], Result[1], Length(B));
end;

{ TVDb }

constructor TVDb.Create;
begin
  inherited Create;
  FLock := TCriticalSection.Create;
  FIndex := TDictionary<QWord, TDbLoc>.Create;
  FPending := TList<TPendOp>.Create;
  FPendingPuts := TDictionary<QWord, Byte>.Create;
  FPendingDels := TDictionary<QWord, Byte>.Create;
  FPendingIdx := TDictionary<QWord, Integer>.Create;
  FPutSeen := TDictionary<QWord, Byte>.Create;
  FSyncWrite := True;
  FDirty := False;
  FClosed := True;
  FLcked := False;
  FRestored := False;
  FDirSyncFailed := False;
  FNewFile := False;
  FDeadBytes := 0;
  FDataStart := VDB_HDR_SIZE;
end;

destructor TVDb.Destroy;
begin
  try
    Close;
  except
  end;
  FPending.Free;
  FPendingPuts.Free;
  FPendingDels.Free;
  FPendingIdx.Free;
  FPutSeen.Free;
  FIndex.Free;
  FLock.Free;
  inherited;
end;

procedure TVDb.CheckOpen;
begin
  if FClosed or (FS = nil) then
    raise EVDbException.Create(ecDatabaseNotOpen, 'VDb: once Open cagir');
end;

function TVDb.RecCrc(Seq, Key: QWord; ValLen: LongWord; Flags: Byte; Value: PByte): LongWord;
var
  c: LongWord;
begin
  c := VDbCrc32Init;
  c := VDbCrc32Update(c, Seq, SizeOf(Seq));
  c := VDbCrc32Update(c, Key, SizeOf(Key));
  c := VDbCrc32Update(c, ValLen, SizeOf(ValLen));
  c := VDbCrc32Update(c, Flags, SizeOf(Flags));
  if (ValLen > 0) and (Value <> nil) then
    c := VDbCrc32UpdatePtr(c, Value, ValLen);
  Result := VDbCrc32Final(c);
end;

function TVDb.HeadCrc(const H: TVDbFileHead): LongWord;
begin
  Result := VDbCrc32Of(H, SizeOf(H) - SizeOf(H.Crc));
end;

procedure TVDb.WriteHeaderTo(S: TStream);
var
  h: TVDbFileHead;
begin
  h.Magic := VDB_FILE_MAGIC;
  h.Ver := VDB_FILE_VER;
  h.Flags := 0;
  h.Crc := HeadCrc(h);
  S.WriteBuffer(h, SizeOf(h));
end;

procedure TVDb.DetectFormat;
var
  m: LongWord;
  h: TVDbFileHead;
  n: Integer;
begin
  // F2-3: Bu yordam BOSUK veya YARIM yazilmis dosyada ReadBuffer ile
  // EReadError firlatabiliyordu; cagiran taraf EVDbException beklerken
  // EReadError goruyordu (tutarsiz hata sinifi). Artik her yol
  // EVDbException(ecCorrupt) ile biter.
  // cagri oncesi FS acik, FLock tutuluyor
  try
    FS.Position := 0;
    n := FS.Read(m, SizeOf(m));
    if n <> SizeOf(m) then
      // 0 baytlik dosya Open'da zaten yakalaniyor; buraya 1..3 bayt
      // gelir (yarim yazma / bozuk dosya).
      raise EVDbException.CreateFmt(ecCorrupt,
        'VDb: dosya cok kisa (baslik okunamadi, %d bayt)', [n]);
    if m = VDB_MAGIC then
    begin
      MigrateLegacy; // FDataStart'i de kurar
      Exit;
    end
    else if m = VDB_FILE_MAGIC then
    begin
      FS.Position := 0;
      FS.ReadBuffer(h, SizeOf(h));
      if h.Crc <> HeadCrc(h) then
        raise EVDbException.Create(ecCorrupt, 'VDb: dosya basligi CRC hatasi (bozuk)');
      if h.Ver = VDB_FILE_VER_OLD then
      begin
        // V1 -> V2 yukseltme. Kayit duzeni ayni; degisen tek sey Flags=2
        // (BATCHEND) kayitlarinin V1 surumunde KIRPILMASINI engellemek.
        // Basligi yerinde yeniden yazip fsync -> dosya artik eski buildler
        // tarafindan guvenle reddedilir (veri kaybi yerine).
        h.Ver := VDB_FILE_VER;
        h.Crc := HeadCrc(h);
        FS.Position := 0;
        FS.WriteBuffer(h, SizeOf(h));
        VDbFlushStream(FS);
      end
      else if h.Ver <> VDB_FILE_VER then
        raise EVDbException.CreateFmt(ecCorrupt,
          'VDb: dosya surumu desteklenmiyor (dosya=%d, motor=%d). Dosya bu ' +
          'motorun daha yeni surumuyle yazilmis; icerigi degistirilmedi.',
          [h.Ver, VDB_FILE_VER]);
      FDataStart := VDB_HDR_SIZE;
    end
    else
      raise EVDbException.Create(ecCorrupt, 'VDb: dosya formati taninmiyor (VODB degil)');
  except
    on E: EVDbException do raise;              // zaten dogru sinif
    on E: EAccessViolation do
      raise EVDbException.CreateFmt(ecCorrupt,
        'VDb: dosya okunurken bellek hatasi (%s)', [FPath]);
    on E: Exception do
      // EReadError (kisa dosya), EInOutError, EOutOfMemory ...
      raise EVDbException.CreateFmt(ecCorrupt,
        'VDb: dosya basligi okunamadi/bozuk (%s: %s)', [FPath, E.Message]);
  end;
end;


procedure TVDb.MigrateLegacy;
// Eski ham kayit akisini (headersiz) yeni .odb duzenine cevirir:
// kayit byte'lari aynen korunur, basa baslik eklenir. .bak birakir.
// F1-3: Govdeyi RAM'e ALMAZ; sabit 64 KB tamponla akis kopyasi yapar.
var
  ts: TFileStream;
  tmpPath: string;
  sz, copied: Int64;
  buf: array[0..65535] of Byte;
  n: Integer;
begin
  FDataStart := 0;
  Recover; // index kur + yirtik kuyrugu kes
  sz := FS.Size;
  tmpPath := FPath + '.tmp';
  if FileExists(tmpPath) then DeleteFile(tmpPath);
  ts := TFileStream.Create(tmpPath, fmCreate);
  try
    WriteHeaderTo(ts);
    if sz > 0 then
    begin
      FS.Position := 0;
      copied := 0;
      while copied < sz do
      begin
        if sz - copied < Int64(SizeOf(buf)) then
          n := FS.Read(buf[0], sz - copied)
        else
          n := FS.Read(buf[0], SizeOf(buf));
        if n <= 0 then Break;
        ts.WriteBuffer(buf[0], n);
        Inc(copied, n);
      end;
    end;
    VDbFlushStream(ts);
  finally
    ts.Free;
  end;
  // NOT: tmp dosyasi baslikli duzende oldugu icin FDataStart,
  // ReplaceWith icindeki Recover'dan ONCE kurulmali.
  // Yanlis sira dosyayi sifirlar (harness yakaladi).
  FDataStart := VDB_HDR_SIZE;
  ReplaceWith(tmpPath);
end;

procedure TVDb.ReplaceWith(const TmpPath: string);
// TmpPath'teki dosyayi fsync'li ve dogrulanmis kabul eder, atomik
// rename ile FPath yapar, acip index'i kurar. Hata olursa .bak'tan doner.
// Giriste FLock tutuluyor olmali.
var
  bakPath: string;

  procedure Reopen;
  begin
    FS := TFileStream.Create(FPath, fmOpenReadWrite);
    FLcked := False;
    if not VDbLockStream(FS) then
    begin
      FreeAndNil(FS);
      raise EVDbException.Create(ecDatabaseLocked, 'dosya kilitlenemedi (yarisma)');
    end;
    FLcked := True;
    FClosed := False;
    PendingClear;
    FPendingPuts.Clear;
    FPendingDels.Clear;
    Recover;
  end;

begin
  if FLcked then
  begin
    try VDbUnlockStream(FS); except end;
    FLcked := False;
  end;
  FreeAndNil(FS);
  try
    bakPath := FPath + '.bak';
    if FileExists(bakPath) then DeleteFile(bakPath);
    if not RenameFile(FPath, bakPath) then
      raise EVDbException.Create(ecIOError, 'yedekleme basarisiz');
    try
      if not RenameFile(TmpPath, FPath) then
        raise EVDbException.Create(ecIOError, 'degisim basarisiz');
      // F2-1/F2-2: rename sonrasi dizin girdisi flush EDILMEZSE yeni ad
      // kalici olmaz; crash'ta dosya .bak adiyla kalir.
      if not VDbFlushDir(ExtractFileDir(FPath)) then
        FDirSyncFailed := True;
    except
      RenameFile(bakPath, FPath);
      raise;
    end;
    Reopen;
  except
    on E: Exception do
    begin
      try
        if FS = nil then
        begin
          if FileExists(bakPath) and not FileExists(FPath) then
            RenameFile(bakPath, FPath);
          if FileExists(FPath) then
          begin
            FS := TFileStream.Create(FPath, fmOpenReadWrite);
            FLcked := False;
            if VDbLockStream(FS) then
            begin
              FLcked := True;
              FClosed := False;
              PendingClear;
              FPendingPuts.Clear;
              FPendingDels.Clear;
              DetectFormat;
              Recover;
            end
            else
            begin
              FreeAndNil(FS);
              FClosed := True;
            end;
          end
          else
            FClosed := True;
        end;
      except
        FClosed := True;
      end;
      raise EVDbException.Create(ecIOError, 'VDb dosya degisimi hatasi: ' + E.Message);
    end;
  end;
end;

procedure TVDb.AppendRec(Key: QWord; const Value: TBytes; IsDel: Boolean; DoFlush: Boolean);
var
  h: TVDbRecHead;
  loc: TDbLoc;
  off: Int64;
  pv: PByte;
begin
  if IsDel then
    h.ValLen := 0
  else
    h.ValLen := LongWord(Length(Value));
  if h.ValLen > VDB_MAX_VALUE then
    raise EVDbException.Create(ecLimit, 'VDb: value cok buyuk');
  Inc(FSeq);
  h.Magic := VDB_MAGIC;
  h.Seq := FSeq;
  h.Key := Key;
  if IsDel then
    h.Flags := VDB_FLAG_DEL
  else
    h.Flags := VDB_FLAG_PUT;
  if h.ValLen > 0 then
    pv := @Value[0]
  else
    pv := nil;
  h.Crc := RecCrc(h.Seq, h.Key, h.ValLen, h.Flags, pv);

  off := FS.Seek(0, soEnd);
  FS.WriteBuffer(h, SizeOf(h));
  if h.ValLen > 0 then
    FS.WriteBuffer(Value[0], h.ValLen);
  FDirty := True;
  if DoFlush then
    VDbFlushStream(FS);

  if FIndex.TryGetValue(Key, loc) then
    Inc(FDeadBytes, Int64(SizeOf(h)) + Int64(loc.Size));
  if IsDel then
  begin
    Inc(FDeadBytes, Int64(SizeOf(h)) + Int64(h.ValLen));
    FIndex.Remove(Key);
  end
  else
  begin
    loc.Offset := off;
    loc.Size := h.ValLen;
    loc.Seq := h.Seq;
    FIndex.AddOrSetValue(Key, loc);
  end;
end;

procedure TVDb.AppendBatchEnd(DoFlush: Boolean);
// Batch sonu isareti: Key = 0, ValLen = 0, Flags = VDB_FLAG_BATCHEND.
// CommitBatch bunu yazip tek fsync yapar. Recovery bu kaydi gormeden
// onceki batch kayitlarini geri sarar -> gercek atomiklik.
var
  h: TVDbRecHead;
  off: Int64;
begin
  Inc(FSeq);
  h.Magic := VDB_MAGIC;
  h.Seq := FSeq;
  h.Key := 0;
  h.ValLen := 0;
  h.Flags := VDB_FLAG_BATCHEND;
  h.Crc := RecCrc(h.Seq, h.Key, h.ValLen, h.Flags, nil);
  off := FS.Seek(0, soEnd);
  FS.WriteBuffer(h, SizeOf(h));
  FDirty := True;
  if DoFlush then
    VDbFlushStream(FS);
end;

procedure TVDb.AppendBatchEndTo(S: TStream; ASeq: QWord);
// Compact/BackupTo cikis dosyasi icin batch-end (belirtilen seq ile).
var
  h: TVDbRecHead;
begin
  h.Magic := VDB_MAGIC;
  h.Seq := ASeq;
  h.Key := 0;
  h.ValLen := 0;
  h.Flags := VDB_FLAG_BATCHEND;
  h.Crc := RecCrc(h.Seq, h.Key, h.ValLen, h.Flags, nil);
  S.WriteBuffer(h, SizeOf(h));
end;

procedure TVDb.Recover;
// Dosyayi bastan sona tarar. Batch kavrami: CommitBatch her batch sonunda
// bir BATCHEND kaydi yazar. Tarama, BATCHEND gorene kadar olan kayitlari
// GECICI listeye yazar; BATCHEND gorulurse listeyi FIndex'e isler, yoksa
// (yarim batch / crash) listeyi TAMAMEN BIRAKIR -> gercek atomiklik.
var
  fsize, pos, next: Int64;
  h: TVDbRecHead;
  buf: TBytes;
  c: LongWord;
  loc: TDbLoc;
  n: Integer;
  pendPos: array of Int64;
  pendSz: array of LongWord;
  pendKey: array of QWord;
  pendFlags: array of Byte;
  pendN: Integer;
  committed: Boolean;
  torn: Boolean;   // dongu bir kayitta kirildi (CRC/magic/yari yazim)
  sawBatchEnd: Boolean; // dosyada HIC BIR BATCHEND kaydi var miydi
  committedThrough: Int64; // son commit'li BATCHEND'den sonraki bayt offseti
  truncatePos: Int64;

  procedure ApplyPending;
  var
    q: Integer;
    l2: TDbLoc;
  begin
    for q := 0 to pendN - 1 do
    begin
      if FIndex.TryGetValue(pendKey[q], l2) then
        Inc(FDeadBytes, Int64(SizeOf(h)) + Int64(l2.Size));
      if pendFlags[q] = VDB_FLAG_DEL then
      begin
        Inc(FDeadBytes, Int64(SizeOf(h)) + Int64(pendSz[q]));
        FIndex.Remove(pendKey[q]);
      end
      else
      begin
        l2.Offset := pendPos[q];
        l2.Size := pendSz[q];
        l2.Seq := 0;
        FIndex.AddOrSetValue(pendKey[q], l2);
      end;
    end;
    pendN := 0;
  end;

begin
  FIndex.Clear;
  FSeq := 0;
  FDeadBytes := 0;
  fsize := FS.Size;
  pos := FDataStart;
  SetLength(buf, 65536);
  pendN := 0;
  committed := True;
  torn := False;
  sawBatchEnd := False;   // ONEMLI: Boolean yereller otomatik sifirlanmaz
  committedThrough := FDataStart;
  while pos + Int64(SizeOf(h)) <= fsize do
  begin
    FS.Position := pos;
    n := FS.Read(h, SizeOf(h));
    if n <> SizeOf(h) then begin torn := True; Break; end;
    if h.Magic <> VDB_MAGIC then
    begin torn := True; Break; end; // yirtik kuyruk
    if h.ValLen > VDB_MAX_VALUE then
    begin torn := True; Break; end;
    next := pos + Int64(SizeOf(h)) + Int64(h.ValLen);
    if next > fsize then
    begin torn := True; Break; end; // yari yazilmis
    if h.ValLen > 0 then
    begin
      if Length(buf) < Integer(h.ValLen) then
        SetLength(buf, h.ValLen);
      FS.ReadBuffer(buf[0], h.ValLen);
      c := RecCrc(h.Seq, h.Key, h.ValLen, h.Flags, @buf[0]);
    end
    else
      c := RecCrc(h.Seq, h.Key, h.ValLen, h.Flags, nil);
    if c <> h.Crc then
    begin torn := True; Break; end; // CRC tutmadi -> kuyrugu kes
    if (h.Flags <> VDB_FLAG_PUT) and (h.Flags <> VDB_FLAG_DEL) and
       (h.Flags <> VDB_FLAG_BATCHEND) then
    begin torn := True; Break; end;
    if h.Seq > FSeq then
      FSeq := h.Seq;
    if h.Flags = VDB_FLAG_BATCHEND then
    begin
      // batch tamam: gecici kayitlar gecerli
      ApplyPending;
      committed := True;
      sawBatchEnd := True;
      committedThrough := next;  // BATCHEND'den sonraki bayt
    end
    else
    begin
      // henuz commit edilmemis batch kaydi
      if Length(pendPos) <= pendN then
      begin
        SetLength(pendPos, pendN + 64);
        SetLength(pendSz, pendN + 64);
        SetLength(pendKey, pendN + 64);
        SetLength(pendFlags, pendN + 64);
      end;
      pendPos[pendN] := pos;
      pendSz[pendN] := h.ValLen;
      pendKey[pendN] := h.Key;
      pendFlags[pendN] := h.Flags;
      Inc(pendN);
      committed := False;
    end;
    pos := next;
  end;
  // truncate iki farkli duruma gore:
  //  - DONGUDEN CIKTIKSA (pos < fsize): yirtik/bozuk kuyruk, pos'a kes.
  //  - Dosya sonuna kadar okundu ama BATCHEND yoksa (not committed):
  //    commit edilmemis batch -> geri sarildi, dosya sonuna kes.
  // ONEMLI: torn (kayitta kirilma) varsa pos KORUNUR; aksi halde kesme
  // noktasi yanlis olur ve bozuk veri geri gelirdi.
  // Kesme noktasi (F1-1: torn=True+committed=False durumunda pending
  // prefix'i de sil; eskiden pos'a kesiliyor ama pending prefix diskte
  // kaliyordu -> seq cakismasi + Verify bozuluyordu):
  //  - sawBatchEnd=False: legacy dosya (BATCHEND yok), tum kayitlar gecerli
  //    -> ApplyPending + yalniz torn kuyruk kesilir.
  //  - committed=False: son batch commit edilmemis -> committedThrough'a
  //    kes (pending prefix silinir) + FSeq geri sar.
  //  - temiz/torn: yalniz torn kuyruğu kes (pos).
  if not sawBatchEnd then
  begin
    if pendN > 0 then ApplyPending;
    committed := True;
    truncatePos := pos;
  end
  else if not committed then
  begin
    truncatePos := committedThrough;
    if pendN > 0 then FSeq := FSeq - QWord(pendN);
  end
  else
    truncatePos := pos;
  {$IFDEF VDB_DEBUG_RECOVER}
  WriteLn('  [Recover] start=', FDataStart, ' fsize=', fsize, ' pos=', pos,
    ' torn=', torn, ' committed=', committed, ' sawBE=', sawBatchEnd,
    ' pendN=', pendN, ' index=', FIndex.Count,
    ' committedThrough=', committedThrough, ' truncatePos=', truncatePos);
  {$ENDIF}
  if truncatePos < fsize then
  begin
    FS.Size := truncatePos;
    VDbFlushStream(FS);
  end;
  FS.Position := FS.Size;
end;

function TVDb.FindPending(Key: QWord; out Op: TPendOp): Boolean;
// ONEMLI: eskiden FPending listesini bastan taraardi (O(n)). 5000'lik
// batch'te her Get/Exists cagrisi tum listeyi dolasiyordu (O(n^2)).
// Simdi key -> slot haritasi var: O(1).
//
// KRITIK DUZELTME: "haritada anahtar YOK" demek "bu anahtar icin pending
// op yoktur" demektir ve bu durumda ARAMA YAPILMAZ. Once her Get cagrisi
// (ORN. INSERT'in duplicate-PK kontrolunde Get) 20000 satirlik bir batch'te
// "bulunamadi" dondugu icin TUM listeyi tarardi -> her INSERT O(pending) ->
// toplam O(n^2). 20.000 satirlik toplu yazma 3,5 saniye suruyordu;
// ilk 5.000 satir 43 us, sonraki 15.000 satir 215 us idi (lineer artis).
// Tarama YALniz harita bir anahtari gosteriyor ama slot bozuk ciddur
// (nadir, savunma yolu).
var
  idx, i: Integer;
  found: Boolean;
begin
  Op.Key := Key;
  Op.IsDel := False;
  SetLength(Op.Value, 0);
  if not FPendingIdx.TryGetValue(Key, idx) then
  begin
    // haritada yok -> pending op da yoktur. HIZLI ISKALAMA (O(1)).
    Result := False;
    Exit;
  end;
  if (idx >= 0) and (idx < FPending.Count) and (FPending[idx].Key = Key) then
  begin
    Op := FPending[idx];
    Exit(True);
  end;
  // Harita tutarsiz (slot tasinmis): onar
  found := False;
  for i := FPending.Count - 1 downto 0 do
    if FPending[i].Key = Key then
    begin
      FPendingIdx[Key] := i;
      Op := FPending[i];
      found := True;
      Break;
    end;
  if not found then
    FPendingIdx.Remove(Key);
  Result := found;
end;

procedure TVDb.PendingAdd(const Op: TPendOp);
begin
  FPending.Add(Op);
  // FPC TDictionary: '[]' atamasi anahtar YOKSA hata verir.
  // AddOrSetValue ekleme + guncellemeyi tek adimda yapar.
  FPendingIdx.AddOrSetValue(Op.Key, FPending.Count - 1);
end;

procedure TVDb.PendingRemove(const Idx: Integer);
// Listeden bir op siler (TList.Delete son elemani bos slota tasir).
// Silinen anahtarin harita girdisi de silinir: aksi halde harita o
// slottaki FARKLI bir anahtari gosterirdi (bayat kayit).
var
  j: Integer;
  movedKey: QWord;
begin
  if (Idx < 0) or (Idx >= FPending.Count) then Exit;
  FPendingIdx.Remove(FPending[Idx].Key);
  if Idx = FPending.Count - 1 then
  begin
    FPending.Delete(Idx);
    Exit;
  end;
  movedKey := FPending[FPending.Count - 1].Key;
  FPending.Delete(Idx);
  if FPendingIdx.TryGetValue(movedKey, j) then
    FPendingIdx[movedKey] := Idx;
end;

procedure TVDb.PendingClear;
begin
  FPending.Clear;
  FPendingIdx.Clear;
  FPendingPuts.Clear;
  FPendingDels.Clear;
  FPutSeen.Clear;
end;

function TVDb.PendingCount: Integer;
begin
  Result := FPending.Count;
end;

procedure TVDb.Open(const Dir: string);
var
  Loc, Old: string;
begin
  FLock.Enter;
  try
    if not FClosed then Close;
    Loc := Trim(Dir);
    if (Loc <> '') and SameText(ExtractFileExt(Loc), '.odb') then
    begin
      FPath := Loc;
      FDir := IncludeTrailingPathDelimiter(ExtractFileDir(FPath));
      ForceDirectories(FDir);
    end
    else
    begin
      FDir := IncludeTrailingPathDelimiter(Loc);
      ForceDirectories(FDir);
      FPath := FDir + 'veritabani.odb';
      // eski surum tasiyici: vdb.log varsa odb'ye tasi
      Old := FDir + 'vdb.log';
      if not FileExists(FPath) and FileExists(Old) then
      begin
        RenameFile(Old, FPath);
        // F2-2: rename sonrasi dizin girdisi flush edilmezse crash'ta
        // ya eski ad ya hicbiri gorunur. Dosya yeni olmadigi icin
        // FNewFile False kalir ama dizin yine de flush edilir.
        if not VDbFlushDir(FDir) then
          FDirSyncFailed := True;
      end;
    end;
    // yarim kalmis compact/replace: ana dosya yok ama .bak varsa don
    FRestored := False;
    FDirSyncFailed := False;
    FNewFile := False;
    if not FileExists(FPath) and FileExists(FPath + '.bak') then
    begin
      if not RenameFile(FPath + '.bak', FPath) then
        raise EVDbException.Create(ecIOError, 'VDb: .bak geri yuklenemedi: ' + FPath);
      FRestored := True;
      // F2-2: .bak -> ana dosya rename'i de dizin girdisi olusturur
      if not VDbFlushDir(FDir) then
        FDirSyncFailed := True;
    end;
    if FileExists(FPath) then
      FS := TFileStream.Create(FPath, fmOpenReadWrite)
    else
    begin
      FS := TFileStream.Create(FPath, fmCreate);
      // F2-2: YENI dosya olusturuldu. Dosya icerigi fsync edilse bile
      // dizin girdisi (dosya adi) kalici degilse, crash sonrasi dosya
      // KAYBOLUR. Bu yuzden dizin de flush edilir.
      FNewFile := True;
    end;
    FLcked := False;
    if not VDbLockStream(FS) then
    begin
      FreeAndNil(FS);
      FClosed := True;
      raise EVDbException.Create(ecDatabaseLocked, 'VDb: dosya kullanimda (baska islem acik olabilir): ' + FPath);
    end;
    FLcked := True;
    FClosed := False;
    FInBatch := False;
    PendingClear;
    FPendingPuts.Clear;
    FPendingDels.Clear;
    if FS.Size = 0 then
    begin
      WriteHeaderTo(FS);
      VDbFlushStream(FS);
      FDataStart := VDB_HDR_SIZE;
      // F2-2: baslik + yeni dosya -> dizin girdisi de kalici olmali
      if not VDbFlushDir(FDir) then
        FDirSyncFailed := True;
    end
    else
      DetectFormat;
    Recover;
    FDirty := False;
  finally
    FLock.Leave;
  end;
end;

procedure TVDb.Close;
begin
  FLock.Enter;
  try
    if FClosed then Exit;
    if FInBatch then AbortBatch;
    try
      if FS <> nil then VDbFlushStream(FS);
    finally
      if FLcked then
      begin
        try VDbUnlockStream(FS); except end;
        FLcked := False;
      end;
      FreeAndNil(FS);
    end;
    FClosed := True;
  finally
    FLock.Leave;
  end;
end;

procedure TVDb.Put(Key: QWord; const Value: TBytes);
var
  op: TPendOp;
  i: Integer;
begin
  FLock.Enter;
  try
    CheckOpen;
    if FInBatch then
    begin
      // Ayni key batch icinde birden fazla yazilabilir (orn. INSERT sonra
      // UPDATE ayni transaction icinde). Son yazan kazanir: eski pending
      // op once kaldirilir.
      //
      // ONCEDEN bu temizlik HER Put icinde tum listeyi basdan taraardi
      // (O(n)). Tek bir batch'e 20000 satir yazilirken O(n^2) = ~200M
      // karsilastirma olusuyor ve COMMIT ~3 SANIYE suruyordu.
      //
      // SIMDI: FPutSeen bu batch icinde o anahtara ait bir pending op
      // olustugunu soyler. Anahtar ilk kez goruluyorsa silinecek op
      // YOKTUR (PendingAdd'i yalnizca Put ve Delete cagirir ve ikisi de
      // buraya kaydeder) -> tarama kanitlanabilir bicimde atlanir.
      // Davranis bit bit ayni kalir, maliyet O(n)'e iner.
      if FPutSeen.ContainsKey(Key) then
      begin
        for i := FPending.Count - 1 downto 0 do
          if FPending[i].Key = Key then
            PendingRemove(i);
      end
      else
        FPutSeen.AddOrSetValue(Key, 0);
      op.Key := Key;
      op.Value := Value;
      op.IsDel := False;
      PendingAdd(op);
      FPendingPuts.AddOrSetValue(Key, 0);
      FPendingDels.Remove(Key);
    end
    else
    begin
      // Batch disi tek yazim: kayit + BATCHEND. Boylece recovery,
      // yarim kalan tek yazimi da "gorulmemis" sayip geri sarabilir.
      AppendRec(Key, Value, False, False);
      AppendBatchEnd(FSyncWrite);
    end;
  finally
    FLock.Leave;
  end;
end;

function TVDb.Get(Key: QWord; out Value: TBytes): Boolean;
var
  loc: TDbLoc;
  h: TVDbRecHead;
  op: TPendOp;
  fsize: Int64;
  nRead: Integer;
begin
  FLock.Enter;
  try
    CheckOpen;
    if FInBatch and FindPending(Key, op) then
    begin
      if op.IsDel then Exit(False);
      Value := Copy(op.Value, 0, Length(op.Value));
      Exit(True);
    end;
    Result := FIndex.TryGetValue(Key, loc);
    if not Result then Exit;
    // F2-5: index girdisi ile dosya arasindaki guvenlik kontrolu.
    // Once yalniz Magic ve Key bakiliyordu; Offset/Size BOZUKSA ya da
    // dosya sonunu asarsa ReadBuffer EReadError firlatiyordu (tutarsiz
    // hata sinifi) veya Value'ya KARSILTISI bayt yaziliyordu.
    // ScanAll'daki aralik+header kontrolunun Get'teki karsiligi:
    // Get SATIR DONDURDUGU icin sessizce atlamak YANLIS; hata verir.
    fsize := FS.Size;
    if (loc.Offset < 0) or
       (loc.Offset + Int64(SizeOf(h)) + Int64(loc.Size) > fsize) then
      raise EVDbException.CreateFmt(ecCorrupt,
        'VDb: index kaydi dosya disinda (key=%d offset=%d size=%d dosya=%d)',
        [Key, loc.Offset, loc.Size, fsize]);
    FS.Position := loc.Offset;
    nRead := FS.Read(h, SizeOf(h));
    if nRead <> SizeOf(h) then
      raise EVDbException.CreateFmt(ecCorrupt,
        'VDb: kayit basligi eksik (key=%d, okunan=%d)', [Key, nRead]);
    if (h.Magic <> VDB_MAGIC) or (h.Key <> Key) or (h.ValLen <> loc.Size) then
      raise EVDbException.Create(ecCorrupt, 'VDb: index/data uyusmazligi');
    SetLength(Value, loc.Size);
    if loc.Size > 0 then
    begin
      nRead := FS.Read(Value[0], loc.Size);
      if nRead <> loc.Size then
        raise EVDbException.CreateFmt(ecCorrupt,
          'VDb: kayit degeri eksik (key=%d, okunan=%d beklenen=%d)',
          [Key, nRead, loc.Size]);
    end;
  finally
    FLock.Leave;
  end;
end;

function TVDb.Exists(Key: QWord): Boolean;
// Dosyaya dokunmadan net durum: pending + index birlikte.
begin
  FLock.Enter;
  try
    CheckOpen;
    if FInBatch then
    begin
      if FPendingPuts.ContainsKey(Key) then Exit(True);
      if not FIndex.ContainsKey(Key) then Exit(False);
      Result := not FPendingDels.ContainsKey(Key);
      Exit;
    end;
    Result := FIndex.ContainsKey(Key);
  finally
    FLock.Leave;
  end;
end;

function TVDb.Delete(Key: QWord): Boolean;
var
  op: TPendOp;
  i: Integer;
begin
  FLock.Enter;
  try
    CheckOpen;
    if FInBatch then
    begin
      // "put-then-del" kisayolu SADECE anahtar diskte OLMAYAN bir
      // anahtarda gecerlidir (bu batch icinde yeni satir yazilmis, sonra
      // silinmis -> net etki "yok").
      //
      // ONCEDEN bu kosul SORGULANMADAN uygulaniyordu ve bu bir veri
      // HATASI idi: batch icinde "UPDATE t SET n=0 WHERE id=1; DELETE FROM
      // t WHERE id=1" calistirilirsa pending put geri aliniyor, DELETE op'i
      // HIC YAZILMIYOR ve SATIR SILINMIYORDU (Affected=1 donuyordu ama
      // satir diskte kaliyordu; indeks girdisi silinip veri girdisi
      // kaliyordu -> indeksli sorgu satiri kaybediyordu).
      //
      // Dogru kural: FIndex'te anahtar VARSA (yani put bir UZERTE yazmaysa)
      // normal DEL op yazilir.
      if FPendingPuts.ContainsKey(Key) and (not FIndex.ContainsKey(Key)) then
      begin
        // bu batch icinde yeni yazilmis ve simdi siliniyor -> net etki "yok"
        for i := FPending.Count - 1 downto 0 do
          if FPending[i].Key = Key then
            PendingRemove(i);
        FPendingPuts.Remove(Key);
        FPendingDels.Remove(Key);
        FPutSeen.Remove(Key);
        Exit(True);
      end;
      if not FIndex.ContainsKey(Key) and not FPendingPuts.ContainsKey(Key) then
        Exit(False);
      // ayni key icin birden fazla DEL op olmasin.
      // FPutSeen anahtarin bu batch icinde bir pending opu oldugunu
      // soyler; gorulmemisse silinecek op yoktur (tarama atlanir).
      if FPutSeen.ContainsKey(Key) then
        for i := FPending.Count - 1 downto 0 do
          if FPending[i].Key = Key then
            PendingRemove(i);
      FPutSeen.AddOrSetValue(Key, 0);
      // BU ANAHTAR BU BATCH ICINDE PUT EDILMISSE: o put op'i de geri
      // alinir ve yerine DEL konur. Aksi halde commit'te put sonra del
      // olur (yine silinir) ama pending put FPendingPuts'ta kalir ve
      // "yok etkili put-then-del" sanilir.
      FPendingPuts.Remove(Key);
      FPendingDels.AddOrSetValue(Key, 0);
      op.Key := Key;
      SetLength(op.Value, 0);
      op.IsDel := True;
      PendingAdd(op);
      Exit(True);
    end;
    if not FIndex.ContainsKey(Key) then
      Exit(False);
    // Batch disi tek silme: kayit + BATCHEND (bkz. Put).
    AppendRec(Key, nil, True, False);
    AppendBatchEnd(FSyncWrite);
    Result := True;
  finally
    FLock.Leave;
  end;
end;

procedure TVDb.BeginBatch;
begin
  FLock.Enter;
  try
    CheckOpen;
    if FInBatch then
      raise EVDbException.Create(ecTransactionState, 'VDb: batch zaten acik');
    FInBatch := True;
    PendingClear;
    FPendingPuts.Clear;
    FPendingDels.Clear;
  finally
    FLock.Leave;
  end;
end;

procedure TVDb.CommitBatch;
var
  i: Integer;
  op: TPendOp;
  savedSize: Int64;
begin
  FLock.Enter;
  try
    CheckOpen;
    if not FInBatch then
      raise EVDbException.Create(ecTransactionState, 'VDb: batch acik degil');
    savedSize := FS.Size;
    try
      // F1-2: ON-DOGRULAMA
      for i := 0 to FPending.Count - 1 do
        if Length(FPending[i].Value) > VDB_MAX_VALUE then
          raise EVDbException.Create(ecLimit, 'VDb: value cok buyuk');
      try
        for i := 0 to FPending.Count - 1 do
          AppendRec(FPending[i].Key, FPending[i].Value, FPending[i].IsDel, False);
        if PendingCount > 0 then
          AppendBatchEnd(False);
        VDbFlushStream(FS);
        FDirty := False;
      except
        on E: Exception do
        begin
          try
            FS.Size := savedSize;
            VDbFlushStream(FS);
          except
          end;
          try
            Recover;
          except
          end;
          raise;
        end;
      end;
    finally
      PendingClear;
      FPendingPuts.Clear;
      FPendingDels.Clear;
      FInBatch := False;
    end;
  finally
    FLock.Leave;
  end;
end;

procedure TVDb.AbortBatch;
begin
  FLock.Enter;
  try
    PendingClear;
    FPendingPuts.Clear;
    FPendingDels.Clear;
    FInBatch := False;
  finally
    FLock.Leave;
  end;
end;

procedure TVDb.Flush;
begin
  FLock.Enter;
  try
    CheckOpen;
    VDbFlushStream(FS);
    FDirty := False;
  finally
    FLock.Leave;
  end;
end;

procedure TVDb.Compact(out OldBytes, NewBytes: Int64);
// Sadece canli kayitlari yeni dosyaya yazar (olu PUT surumleri ve
// tombstone'lar duser), fsync + atomik rename ile degistirir.
// Canli veriyi tek parca RAM'e cekmez; sabit tamponla akis kopyalamasi yapar.
// Eski dosya .bak olarak kalir. Batch acikken cagrilamaz.
var
  tmpPath: string;
  ts: TFileStream;
  pair: TPair<QWord, TDbLoc>;
  loc: TDbLoc;
  h: TVDbRecHead;
  pv: PByte;
  buf: TBytes;
  i: Integer;
begin
  OldBytes := 0; NewBytes := 0;
  FLock.Enter;
  try
    CheckOpen;
    if FInBatch then
      raise EVDbException.Create(ecTransactionState, 'VDb: batch acikken compact yapilamaz');
    OldBytes := FS.Size;
    tmpPath := FPath + '.tmp';
    if FileExists(tmpPath) then DeleteFile(tmpPath);
    ts := TFileStream.Create(tmpPath, fmCreate);
    try
      WriteHeaderTo(ts);
      SetLength(buf, 65536);
      i := 0;
      for pair in FIndex do
      begin
        loc := pair.Value;
        if loc.Size > 0 then
        begin
          if Length(buf) < Integer(loc.Size) then
            SetLength(buf, loc.Size);
          FS.Position := loc.Offset + Int64(SizeOf(TVDbRecHead));
          FS.ReadBuffer(buf[0], loc.Size);
          pv := @buf[0];
        end
        else
          pv := nil;
        h.Magic := VDB_MAGIC;
        h.Seq := FSeq + QWord(i) + 1;
        h.Key := pair.Key;
        h.ValLen := loc.Size;
        h.Flags := VDB_FLAG_PUT;
        h.Crc := RecCrc(h.Seq, h.Key, h.ValLen, h.Flags, pv);
        ts.WriteBuffer(h, SizeOf(h));
        if h.ValLen > 0 then
          ts.WriteBuffer(buf[0], h.ValLen);
        Inc(i);
      end;
      AppendBatchEndTo(ts, FSeq + QWord(i) + 1);
      VDbFlushStream(ts);
    finally
      ts.Free;
    end;
    ReplaceWith(tmpPath);
    FDataStart := VDB_HDR_SIZE;
    FDeadBytes := 0;
    NewBytes := FS.Size;
  finally
    FLock.Leave;
  end;
end;

function TVDb.AutoCompact(out OldBytes, NewBytes: Int64;
  MaxDeadRatio: Double; MinBytes: Int64): Boolean;
// Olu oran esigi asildiysa Compact yapar.
// DIKKAT: kilidi TEK PARCA icinde tut. Once kilidi birakip sonra Compact
// cagrilirsa araya baska islem girip yanlis karar verirdi (yarisma).
// Compact kendi kilidini alir; TCriticalSection rekursiftir.
var
  sz: Int64;
begin
  Result := False;
  OldBytes := 0; NewBytes := 0;
  FLock.Enter;
  try
    CheckOpen;
    if FInBatch then Exit; // batch icinde compact yapilamaz, atla
    sz := FS.Size;
    if sz <= 0 then Exit;
    if sz < MinBytes then Exit;
    if (Double(FDeadBytes) / Double(sz)) < MaxDeadRatio then Exit;
    Compact(OldBytes, NewBytes);
    Result := True;
  finally
    FLock.Leave;
  end;
end;

procedure TVDb.BackupTo(const DestPath: string);
// Acik DB'nin tutarli kopyasini yeni .odb olarak yazar (schema dahil).
// Commitlenmis veriyi alir; sabit tamponla akis halinde yazar (RAM OOM onler).
var
  ts: TFileStream;
  tmp, dir: string;
  pair: TPair<QWord, TDbLoc>;
  loc: TDbLoc;
  h: TVDbRecHead;
  pv: PByte;
  buf: TBytes;
  i: Integer;
begin
  FLock.Enter;
  try
    CheckOpen;
    if FInBatch then
      raise EVDbException.Create(ecTransactionState, 'VDb: batch acikken yedek alinamaz (once Commit/Abort)');
    dir := ExtractFileDir(DestPath);
    if dir <> '' then ForceDirectories(dir);
    tmp := DestPath + '.tmp';
    if FileExists(tmp) then DeleteFile(tmp);
    ts := TFileStream.Create(tmp, fmCreate);
    try
      WriteHeaderTo(ts);
      SetLength(buf, 65536);
      i := 0;
      for pair in FIndex do
      begin
        loc := pair.Value;
        if loc.Size > 0 then
        begin
          if Length(buf) < Integer(loc.Size) then
            SetLength(buf, loc.Size);
          FS.Position := loc.Offset + Int64(SizeOf(TVDbRecHead));
          FS.ReadBuffer(buf[0], loc.Size);
          pv := @buf[0];
        end
        else
          pv := nil;
        h.Magic := VDB_MAGIC;
        h.Seq := QWord(i) + 1;
        h.Key := pair.Key;
        h.ValLen := loc.Size;
        h.Flags := VDB_FLAG_PUT;
        h.Crc := RecCrc(h.Seq, h.Key, h.ValLen, h.Flags, pv);
        ts.WriteBuffer(h, SizeOf(h));
        if h.ValLen > 0 then
          ts.WriteBuffer(buf[0], h.ValLen);
        Inc(i);
      end;
      AppendBatchEndTo(ts, QWord(i) + 1);
      VDbFlushStream(ts);
    finally
      ts.Free;
    end;
    if FileExists(DestPath) then DeleteFile(DestPath);
    if not RenameFile(tmp, DestPath) then
      raise EVDbException.Create(ecIOError, 'VDb: yedek tasinamadi: ' + DestPath);
    VDbFlushDir(dir);
  finally
    FLock.Leave;
  end;
end;

// ============================================================================
// WAL Motor Entegrasyonu (VDbWal.pas) - STUB / KULLANILMIYOR.
// DURUM: ReplayWAL gercek replay yapmaz (.wal varsa False doner).
// VDbWal.pas derlenmiyor, hicbir sey onu cagirmiyor; PutRow'daki yazma
// cagrisi da kaldirildi (dosyayi her satirda bastan aciyordu).
// Gercek dayaniklilik: kayit basi CRC32 + batch basi tek fsync +
// BATCHEND isareti + acilis recovery'si. Detay README'de.
function TVDb.WriteAheadWAL(Key: QWord; const Value: TBytes; Flags: Byte): Boolean;
// F2-4: ONCEDEN FLock almiyordu; iki thread ayni anda .wal'a yazip
// birbirinin kaydini bozabiliyordu. Simdi tum WAL metotlari ayni kilidi
// kullanir (Put/Delete ile ayni) ve CheckOpen ile dogrulanir.
//
// NOT: replay halen STUB (bkz. ReplayWAL). WAL yazimi guvenlik agina
// degil, ileride gercek replay'e hazir bir tampon olarak duruyor.
var
  fs: TFileStream;
  walPath: string;
  valLen: Integer;
begin
  FLock.Enter;
  try
    CheckOpen;
    Result := False;
    walPath := ChangeFileExt(FPath, '.wal');
    try
      fs := TFileStream.Create(walPath, fmCreate or fmOpenWrite or fmShareExclusive);
      try
        fs.Position := fs.Size;
        fs.Write(Key, SizeOf(Key));
        fs.Write(Flags, SizeOf(Flags));
        valLen := Length(Value);
        fs.Write(valLen, SizeOf(valLen));
        if Length(Value) > 0 then fs.Write(Value[0], Length(Value));
        Result := True;
      finally
        fs.Free;
      end;
    except
      Result := False;
    end;
  finally
    FLock.Leave;
  end;
end;

function TVDb.ReplayWAL: Boolean;
// STUB: replay YOK. .wal dosyasi yoksa True; varsa False doner ve
// icerigi uygulanmaz. F2-4: kilit + CheckOpen eklendi.
// BUGUN ICIN BILINEN BIR RISK: bu False dondugu halde cagiran kod .wal
// dosyasini SILEBILIR; replay uygulanana kadar WriteAheadWAL cagrilmamalidir.
var
  walPath: string;
begin
  FLock.Enter;
  try
    CheckOpen;
    walPath := ChangeFileExt(FPath, '.wal');
    Result := not FileExists(walPath);
  finally
    FLock.Leave;
  end;
end;

function TVDb.CheckpointWAL: Boolean;
// F2-4: kilit + CheckOpen.
var
  walPath: string;
begin
  FLock.Enter;
  try
    CheckOpen;
    walPath := ChangeFileExt(FPath, '.wal');
    if FileExists(walPath) then
      DeleteFile(walPath);
    Result := not FileExists(walPath);
  finally
    FLock.Leave;
  end;
end;

function TVDb.HasWAL: Boolean;
// F2-4: kilit + CheckOpen.
var
  walPath: string;
begin
  FLock.Enter;
  try
    CheckOpen;
    walPath := ChangeFileExt(FPath, '.wal');
    Result := FileExists(walPath);
  finally
    FLock.Leave;
  end;
end;

function TVDb.Verify(out Report: string): Boolean;
// Salt-okunur butunluk denetimi: baslik + tum kayitlarin CRC + seq
// surekliligi. Dosyayi degistirmez (truncate yok).
//
// BELLEK: dosya TAMAMINI bellege almaz; sabit 64 KB tamponla kayit kayit
// okunur. (ONCEDEN `SetLength(buf, fsize)` idi -> 500 MB dosyada OOM.)
var
  buf: TBytes;
  fsize, pos, next: Int64;
  fh: TVDbFileHead;
  h: TVDbRecHead;
  c: LongWord;
  pv: PByte;
  n, nPut, nDel, nEnd: Int64;
  expSeq: QWord;
  first: Boolean;

  procedure Bad(const Fmt: string; const Args: array of const);
  begin
    Report := Format('BOZUK @%d: ', [pos]) + Format(Fmt, Args);
  end;

begin
  Result := False;
  Report := '';
  FLock.Enter;
  try
    CheckOpen;
    fsize := FS.Size;
    // ONCEDEN dosyanin TAMAMI bellege aliniyordu:
    //   SetLength(buf, fsize); FS.ReadBuffer(buf[0], fsize);
    // 500 MB dosyada OutOfMemoryError; Verify GUI'de HER ACILISTA
    // calistigi icin bu pratik bir crash sebebiydi.
    // SIMDI sabit boyutlu tamponla kayit kayit okunur (ScanAll ile ayni).
    if fsize < VDB_HDR_SIZE then begin Report := 'BOZUK: dosya basliktan kisa'; Exit; end;
    SetLength(buf, 65536);
    FS.Position := 0;
    FS.ReadBuffer(buf[0], VDB_HDR_SIZE);
    Move(buf[0], fh, SizeOf(fh));
    if fh.Magic <> VDB_FILE_MAGIC then begin Report := 'BOZUK: VODB imzasi yok'; Exit; end;
    if fh.Ver <> VDB_FILE_VER then begin Report := 'BOZUK: desteklenmeyen surum'; Exit; end;
    if fh.Crc <> HeadCrc(fh) then begin Report := 'BOZUK: baslik CRC'; Exit; end;
    pos := VDB_HDR_SIZE;
    n := 0; nPut := 0; nDel := 0; nEnd := 0; first := True; expSeq := 0;
    while pos + Int64(SizeOf(h)) <= fsize do
    begin
      FS.Position := pos;
      if FS.Read(h, SizeOf(h)) <> SizeOf(h) then
      begin Bad('okunamadi', []); Exit; end;
      if h.Magic <> VDB_MAGIC then begin Bad('kayit imzasi yok', []); Exit; end;
      if h.ValLen > VDB_MAX_VALUE then begin Bad('asiri vallen=%d', [h.ValLen]); Exit; end;
      next := pos + Int64(SizeOf(h)) + Int64(h.ValLen);
      if next > fsize then begin Bad('yirtik kuyruk', []); Exit; end;
      if h.ValLen > 0 then
      begin
        if Length(buf) < Integer(h.ValLen) then
          SetLength(buf, h.ValLen);
        if FS.Read(buf[0], h.ValLen) <> Integer(h.ValLen) then
        begin Bad('deger okunamadi', []); Exit; end;
        pv := @buf[0];
      end
      else
        pv := nil;
      c := RecCrc(h.Seq, h.Key, h.ValLen, h.Flags, pv);
      if c <> h.Crc then begin Bad('CRC tutmadi key=%d', [h.Key]); Exit; end;
      if (h.Flags <> VDB_FLAG_PUT) and (h.Flags <> VDB_FLAG_DEL) and
         (h.Flags <> VDB_FLAG_BATCHEND) then
      begin Bad('bayrak=%d', [h.Flags]); Exit; end;
      // F2-17: BATCHEND isareti Key=0/ValLen=0 olmali; aksi halde
      // Recover'da "commit isareti" yanlis yorumlanir.
      if (h.Flags = VDB_FLAG_BATCHEND) and ((h.Key <> 0) or (h.ValLen <> 0)) then
      begin Bad('BATCHEND bozuk (key=%d vallen=%d)', [h.Key, h.ValLen]); Exit; end;
      if first then begin expSeq := h.Seq; first := False; end;
      if h.Seq <> expSeq then begin Bad('seq kirik beklenen=%d gelen=%d', [expSeq, h.Seq]); Exit; end;
      Inc(expSeq);
      // F2-17: ONCEDEN "del degilse put" sayiliyordu; BATCHEND kayitlari
      // da put olarak sayildigi icin rapor yanilticiydi (399 put + 399
      // BATCHEND -> "put=798"). Artik ucuncu sayac ayri.
      case h.Flags of
        VDB_FLAG_PUT: Inc(nPut);
        VDB_FLAG_DEL: Inc(nDel);
        VDB_FLAG_BATCHEND: Inc(nEnd);
      end;
      Inc(n);
      pos := next;
    end;
    if pos <> fsize then begin Bad('artik %d byte', [fsize - pos]); Exit; end;
    Report := Format('OK kayit=%d put=%d del=%d batchend=%d canli=%d olu=%d boyut=%d',
      [n, nPut, nDel, nEnd, FIndex.Count, FDeadBytes, fsize]);
    Result := True;
  finally
    FLock.Leave;
  end;
end;

function TVDb.GetIsOpen: Boolean;
begin
  Result := not FClosed;
end;

function TVDb.Count: Integer;
begin
  FLock.Enter;
  try
    Result := FIndex.Count;
  finally
    FLock.Leave;
  end;
end;

function TVDb.GetAllKeys: TQWordArray;
var
  k: QWord;
  i: Integer;
begin
  FLock.Enter;
  try
    SetLength(Result, FIndex.Count);
    i := 0;
    for k in FIndex.Keys do
    begin
      Result[i] := k;
      Inc(i);
    end;
  finally
    FLock.Leave;
  end;
end;

procedure TVDb.ScanAll(out Keys: TQWordArray; out Vals: TValArray);
// Canli kayitlarin tamamini dondurur.
// Batch acikken COMMIT edilmemis (pending) yazmalar da dahil edilir;
// aksi halde ayni transaction icinde INSERT edip SELECT etmek bos donerdi
// ve UNIQUE/FK denetimleri kendi ekledigimiz satirlari gormezdi.
var
  buf: TBytes;
  fsize: Int64;
  pair: TPair<QWord, TDbLoc>;
  h: TVDbRecHead;
  n, np: Integer;
  op: TPendOp;          // bekleyen op (sozlukten okunur)
  pendKeys: TDictionary<QWord, Byte>;
begin
  FLock.Enter;
  try
    CheckOpen;
    fsize := FS.Size;
    // Dosyanin tamamini tek seferde RAM'e almak 1GB+ dosyada OOM yapar.
    // Bunun yerine 64KB blok tamponla kayit basina tek seek+read.
    SetLength(buf, 65536);
    // pending yazmalar: ayni key icin diskteki surumu gecersiz kil
    pendKeys := TDictionary<QWord, Byte>.Create;
    try
      if FInBatch then
        for n := 0 to FPending.Count - 1 do
          pendKeys.AddOrSetValue(FPending[n].Key, 0);
      SetLength(Keys, FIndex.Count + FPending.Count);
      SetLength(Vals, FIndex.Count + FPending.Count);
      n := 0;
      for pair in FIndex do
      begin
        // savunma: index/dosya uyusmazliginda kaydi atla, patlama
        if (pair.Value.Offset < 0) or
           (pair.Value.Offset + Int64(SizeOf(h)) + Int64(pair.Value.Size) > fsize) then
          Continue;
        // pending surum varsa diskteki bu kayit artik gecerli degil
        if pendKeys.ContainsKey(pair.Key) then Continue;
        if Length(buf) < Integer(pair.Value.Size) then
          SetLength(buf, pair.Value.Size);
        FS.Position := pair.Value.Offset;
        FS.ReadBuffer(h, SizeOf(h));
        if (h.Magic <> VDB_MAGIC) or (h.Key <> pair.Key) or (h.ValLen <> pair.Value.Size) then
          Continue;
        // Get ile ayni sozlesme: sadece value bytes (header yok),
        // cunku DecodeRow value cozuyor
        Keys[n] := pair.Key;
        SetLength(Vals[n], pair.Value.Size);
        if pair.Value.Size > 0 then
        begin
          if Length(buf) < Integer(pair.Value.Size) then
            SetLength(buf, pair.Value.Size);
          FS.ReadBuffer(buf[0], pair.Value.Size);
          Move(buf[0], Vals[n][0], pair.Value.Size);
        end;
        Inc(n);
      end;
      // pending yazmalari ekle. Put/Delete ayni key icin yinelenen op'lari
      // zaten temizledigi icin burada yalnizca tombstone'lari dusurmek yeter.
      if FInBatch then
        for np := 0 to FPending.Count - 1 do
        begin
          if FPending[np].IsDel then Continue;
          Keys[n] := FPending[np].Key;
          Vals[n] := Copy(FPending[np].Value, 0, Length(FPending[np].Value));
          Inc(n);
        end;
      SetLength(Keys, n);
      SetLength(Vals, n);
    finally
      pendKeys.Free;
    end;
  finally
    FLock.Leave;
  end;
end;

end.
