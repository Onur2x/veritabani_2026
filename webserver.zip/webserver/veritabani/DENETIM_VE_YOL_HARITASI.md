# VDB — Son Denetim + Yol Haritası

**Tarih:** Ekim 2026  
**Durum:** **F1 TAMAMEN Bitti (23/23) — ve her kalemin regresyon kaniti var.** Test: **569/569 gecer** (denetim oncesi 409/409 idi; +160 assertion). Her F1 duzeltmesi **mutasyon testiyle** dogrulandi: duzeltme geri alindiginda ilgili test KIRMIZI oluyor. Kanit tablosu: *F1 MUTASYON DOGRULAMA* bolumu.

---

## DENETIM YONTEMI

4 koldan paralel derin inceleme (VDbCore/VDbSync/VDbCrc32, VDbTable, SQL katmani, API/docs) + manuel dogrulama. Her bulgu kod satiri + senaryo + etki + duzeltme onerisi icerir.

---

## F1 — KRITIK (veri kaybi / yanlis sonuc / cokme)

### VDbCore.pas

| # | Bulgu | Satir | Etki | Duzeltme |
|---|------|-------|------|----------|
| F1-1 | `Recover`: yarim batch fiziksel olarak geri sarilmiyor; seq cakismasi | 618-652 | crash sonrasi DB Verify'den gecemez, oluk prefix birikir | kesme noktasi `pendPos[0]` + seq turetimi |
| F1-2 | `CommitBatch` ortasinda `AppendRec` firlatirsa phantom okuma | 1016-1030 | restart oncesi/sonrasi tutarsizlik | on-dogrulama veya truncate+rebuild |
| F1-3 | `MigrateLegacy` tum dosyayi RAM'e aliyor | 294-311 | ~1GB legacy .odb'de OOM | `Compact` benzeri akis kopyasi |

### VDbTable.pas

| # | Bulgu | Satir | Etki | Duzeltme |
|---|------|-------|------|----------|
| F1-4 | `UpdateWhere`: ilgisiz kolon degisikligi CHECKRESTRICT cagrisi yanlis RESTIC/CASCADE | 3895, 2057-2090 | yanlis FK hatasi veya cocukta bozuk FK | yalniz degisen kolon bir cocuk FK'nin RefCol'u ise cagir |
| F1-5 | `UpdateWhere`: UNIQUE bayat `FIdxUniq` girdisi silinmiyor | 2268, 3922 | sonraki gecerli INSERT reddedilir useri | eski UNIQUE anahtari haritdan dusur |
| F1-6 | `AlterDropColumn`: FK kontrolu yanlis tabloda araniyor | 2804-2805 | sarkan FK kalir, kalici DoS | `FindCol(t, RefCol)` ile karsilastir |
| F1-7 | `AlterAddColumn`: NOT NULL kontrolu commit'ten sonra | 2768-2778 | basarisiz DDL kalici, tekrar deneme hata | kontrolu `RewriteTable` ONCESI yap |
| F1-8 | `RewriteTableRows`/`RewriteTable`/`AlterRenameTable`: hash dogrulamasiz sil/yaz | 2636-2642, 2556-2596, 2998-3006 | carpismada baska tablonun satiri silinir | `DecodeRow`+`ecHashCollision` ekle |
| F1-9 | `BatchInsert`: kendi batch'inde direkt `FKv.CommitBatch`, sema flush yok | 3471-3476 | `AutoInc`/sema kirli bayrak ufalar | `TVTableDb.CommitBatch` mantigini kullan |

### SQL Katmani (VDbParser + VDbExecutor + VDbSql)

| # | Bulgu | Satir | Etki | Duzeltme |
|---|------|-------|------|----------|
| F1-10 | Parser: `OFFSET` alias listesinde eksik | 1061, 1030 | `SELECT * FROM t OFFSET 10` sessizce tum satirlari doner | iki listeye de `OFFSET` ekle |
| F1-11 | UNION/EXCEPT/INTERSECT sutun-sayisi denetlenmiyor | VDbExecutor:2612 | engebeli matris, sessiz yanlis sonuc | birlesme oncesi `Length(outCols)=Length(rightRes.Fields)` kontrolu |
| F1-12 | UNION'da LIMIT/OFFSET/ORDER BY birlesmeden ONCE uygulaniyor | VDbExecutor:2570-2612 | fazla/eksik satir doner | `SetOp<>sokNone` ise kuyruk birlesmeden sonra uygulansin |
| F1-13 | `NOT IN` icinde NULL varsa satir yanlis gecer | VDbExecutor:362-387 | `x NOT IN (1,2,NULL)` satiri dondurur | listede `hasNull` bayragi, `IsNot+hasNull` ise False |
| F1-14 | `NOT NULL` ve `NOT LIKE ... NULL` True donuyor | VDbExecutor:255-265, 594-596 | spec `IS NULL` disi hicbir operator NULL ile eslesmez | `EvalUnary(suoNot,'')` -> `''` (UNKNOWN) |
| F1-15 | `DELETE DATABASE` canlida yok | VDbSql:3056-3137, VDbParser:1886-1898 | spec'te "var" diyor, kodda syntax hatasi | `ExecRaw`'a DAL + `StmtBatchSafe` kontrolu ekle |
| F1-16 | `ExecUpdate` bilinmeyen kolonu sessizce atliyor | VDbExecutor:2789-2794 | yanlis `rCount`, satti eti silinip aynen yazilir | `ci<0` ise `ecColumnNotFound` firlat |
| F1-17 | JOIN'de tip-bilgili kiyaslama dusuyor | VDbExecutor:344-351 | `WHERE s.tutar>2` metin sirasiyla `'10'<'2'` olur | sonek-eslesme veya `Taraf` benzeri konum-tabanli tip |
| F1-18 | Bozuk/negatif `LIMIT/OFFSET` sessizce yok sayiliyor | VDbParser:1219-1233 | `LIMIT abc` -> limitsiz, `LIMIT -5` -> tam sonuc | basarisiz/negatif/>2M ise `ecSyntaxError/ecLimit` firlat |
| F1-19 | `SUM` bos kumede `0` donuyor | VDbExecutor:2309-2311 | SQL'de `NULL` olmali | `if cnt=0 then Exit('')` |
| F1-20 | GROUP BY sonrasi `ORDER BY` sayisali metin siralar | VDbExecutor:2487-2490 | `ORDER BY adet` (COUNT) `'10'<'2'` bozulur | agrega-tip haritasi (COUNT->INT, SUM/AVG->FLOAT) |
| F1-21 | `ORDER BY` bilinmeyen kolon sessizce siralamaz | VDbExecutor:1448-1478 | `ORDER BY yok` hata vermeden giris-sirasi doner | `kidx<0` ise `ecColumnNotFound` firlat |
| F1-22 | Derin ic-ice ifade/negatif-sayi yigintasi | VDbParser:497-1004 | 10k `((((...))))` veya `NOT NOT...` yigin-tasmasi yapar | derinlik sayaci (256) + tasma hatasi |
| F1-23 | `SplitStatements` yorgum/yorumlar atlamıyor | VDbSql:2478-2526 | `"`/`` ` `` icindeki `;` veya yorumdaki `;` yanlış cumele boler | ayiriciya `"`/`` ` `` ve yorum atlama ekle |

---

## F2 — ORTA (tutarsizlik / performans / puruzluluk)

| # | Bulgu | Dosya:Satir | Duzeltme |
|---|------|-------------|----------|
| F2-1 | `VDbFlushDir` Unix'te hata yutuyor | VDbSync:40-59 | boolean don veya RaiseLastOSError |
| F2-2 | Yeni dosya basligi + legacy rename VDbFlushDir'siz | VDbCore:788-792,760-761 | her iki noktadan sonra VDbFlushDir cagir |
| F2-3 | `DetectFormat` istisna yolunda tutarsiz | VDbCore:771-796 | try/except + ecCorrupt'a ceviri |
| F2-4 | WAL metotlari kilitsiz + stub | VDbCore:1226-1364 | FLock + CheckOpen (dusuk onclik) |
| F2-5 | `Get` index-offset dogrulamiyor | VDbCore:875-901 | ScanAll'daki aralik+header kontrolunu ekle |
| F2-6 | `DropTable` gereginden kati | VDbTable:3404-3413 | gercek kesisim ara veya ebeveyn bossa dusur |
| F2-7 | `FIntentDrop` hic temizlenmiyor | VDbTable:1618-1631 | basarili MarkSchema/SaveSchema sonrasi temizle |
| F2-8 | `BatchInsert` AutoInc/sema flush etmiyor | VDbTable:3471-3476 | TVTableDb.CommitBatch mantigini kullan |
| F2-9 | DDL atomik degil (veri ayri, sema ayri fsync) | VDbTable:2587-2598 | tek dis batch'te birlestir |
| F2-10 | `AlterColumnType` PK dahil tip degisimi serbest + FK/CHECK re-validate yok | VDbTable:2871-2918 | PK tip degisimini yasakla + Ctype tazele |
| F2-11 | `AlterDropColumn` bekleyen indeks op'lari temizlenmiyor | VDbTable:2824-2834 | `DropIdxPend` cagir |
| F2-12 | Self-referans FK denetimsiz + kaskad derinlik korumasi yok | VDbTable:2061,2102-2114 | continue kaldir + ziyaret-kumesi + derinlik siniri |
| F2-13 | `LoadSchema` bozuk satir sessizce atlaniyor | VDbTable:1341-1342 | `ecSchemaCorrupt` firlat |
| F2-14 | `CreateTable` bos tablo adina izin veriyor | VDbTable:3318-3331 | `Trim(Name)=''` ise `ecInvalidName` |
| F2-15 | BLOB + cok-kolonlu indeks `#1` cakismasi | VDbTable:924-937,904-922 | BLOB bilesik indeksi reddet veya uzunluk-onegi kullan |
| F2-16 | `ScanRows` bozuk satiri Continue ile atlıyor | VDbTable:3747 | `ecCorrupt` firlat |
| F2-17 | `Verify` raporunda BATCHEND put sayiliyor | VDbCore:1348 | ucuncu sayac `nEnd` ekle |
| F2-18 | UNION/DISTINCT O(N^2) + limitsiz | VDbExecutor:2573-2591,2623-2661 | RowEncodeKey hash yolu + satci ecLimit |
| F2-19 | Pencere gecici matrisi 2-3x bellek | VDbExecutor:2064-2066,2095-2109 | indeks-siralama kullan, tmpM kopyasi kaldir |
| F2-20 | Alt-sorgu/CTE tam materyalizasyon | VDbExecutor:639-652,731-751 | IN/EXISTS icin tek-kolon projeksiyon + erken hash + ecLimit; belge notu |
| F2-21 | SQL.md betik atomikligi celiskisi | SQL.md:12 vs 299 | "AutoTx acik ve hepsi batch-uyumluysa ya-hep-ya-hic; StmtBatchSafe disi varsa cukre-atomik" ekle |

---

## F3 — DUSUK (hijyen)

- `VDbSql` arşivi `{$IF 0}` blogundan cikardan canlı üyeleri sil (`ExecJoin/ExecAggregate/TryIndexSelect/CompareRowsTbl/QuickSortIdx/SortRowsBy/IndexOfRow/SplitSetTail/ApplySetTail/FindSetOp/DedupRows/ParseWhereGroups/ParseSetExpr/IsAggWord/ParseSelectItem/CollectParenText/AndGroups/ExecVerify`).
- `DoSort` yigin-dizisi 63 sabit: tasima guardı + yorum.
- Magic sayillara isim ver (`VDbSync.pas:77,96` - `LOCK_EX/LOCK_NB/LOCK_UN`).
- `TblOk` olu bayrak kaldir (`VDbCrc32.pas:38`).
- `IdxAddRow` bos anahtari `FIdxUniq`'ye yazmasin.
- `DropTable` `ScanRows` hash-esitlik hatasini tekrarlasin.

---

## DOGRULANANLAR (kisa)

- **VDbCore.Recover** bos-dosya yolu, `AbortBatch` dogrulugu, tekli yazim protokolu, torn-tail kesme+flush, `ReplaceWith`/`BackupTo` rename-oncesi flush+dir-flush, bounds (`ValLen>VDB_MAX_VALUE` uc yolda kontrol, Int64 offset), Key=0 cakismasi yok, `Verify` salt-okunur+bloklu, `VDbCrc32` standart+thread-guvenli (initialization), `RaiseLastOSError` dogru, platform ifdef'leri islevsel.
- **VDbTable**: Insert/UpdateWhere NOT NULL+UNIQUE+tip-normalizasyon+CHECK+FK, BatchInsert her satiri Insert'ten gecirip tek batch'te atomik, UNIQUE `''` muafiyeti, PK guncelleme yasagi, batch-ici gorunurluk, `GetTable`/`TableExists` tutarliligi, BLOB ham-yol, iki-asamali FK siralamasi, `AbortBatch` indeksleri veriden onarıyor.
- **SQL**: JOIN+GROUP reddi, RIGHT/FULL klasik-dongu+2M, LEFT hizli-yol NULL-genisletme, DISTINCT projeksiyon-sonrasi/LIMIT-oncesi, `TryIndexOrder` DISTINCT/GROUP/aggr/pencere/COLLATE-TR dislamasi, `VDbCmpVal` NULL'da False+yalniz sayisal kolonda sayisallasTirma, bos IN()->False, skaler cok-satir hatasi, iliskili-alt-sorgu reddi, bos-tabloda COUNT(*)=0/tek-grup, MIN/MAX tip-bilgili, COUNT(col) NULL-atlama, pencere AVG sifirsizlik, CASE ELSE-yoksa NULL, sade-CASE NULL, tokenizer ''/?/; dogru, `StmtBatchSafe` cekirdek dislama + `ExecAll` hepsi-ya-hic/tek-fsync, `NarrowRows` ust-kume+RowMatches dogrulamali.
- **API/docs**: `VDbDataSet` Post/Cancel/Delete/Insert/Refresh/buffer/bookmark — 53/53 test gecerli, sozlesmeye uygun. `VDbPool` timeout/cift-release/yabanci/kapali-havuz — 8/8 test gecerli. `VDbText` UTF-8 cozucu + TrWeight — test gecerli. `VDbJson` BLOB + #0 — `$hex` nesnesiyle duzeltildi, test gecerli. `guimain` acilis sirasi dogru (Kv.Open -> Tb.Open). Belge ceiskisi SQL.md:12 vs 299 yukarida F2-21'de.

---

## ONCELIKLI UYGULAMA SIRASI

**Faz 1 (1-2 gun):** ~~F1-1'den F1-23'e kadar hepsi.~~ **TAMAMLANDI (23/23)** — asagida "F1 UYGULAMA KAYDI". En acili: F1-1 (Recover), F1-4 (CheckRestrict), F1-10 (OFFSET alias), F1-12 (UNION sırası), F1-13/F1-14 (NULL mantigi).

**Faz 2 (2-3 gun):** F2-1'den F2-21'e kadar hepsi.

**Faz 3 (1 gun):** Düşük hijyen — arciv temizligi, magic sayılar, ölü bayrak, indeks hijyen.

**Faz 4:** Belge son rotus — README/SQL.md test sayliari + yeni duzeltmeler sonrasi guncelleme.

---

## NOT

Bu dosya, 4 koldan paralel derin denetim + manuel dogrulama sonucu olusturulmustur. Her bulgu kod satiri + senaryo + etki + duzeltme önerisi icerir. Uygulama sirasi F1 -> F2 -> F3 -> F4.

---

# F1 UYGULAMA KAYDI (23/23 tamamlandi)

**Test sonucu:** `sqltest.exe` -> **569 gecen / 0 kalan** (once 409/409).
**Derleme:** `sqltest.lpi` ve `vdbgui.lpi` temiz derleniyor ve linkleniyor.
**Geriye donuk uyum:** Tum degisiklikler `private` (ic) uyelerde; `TVSqlExecutor`/`TVDbParser` public API'si degismedi. Uygulama (`mtdata.pas`) yalniz taban kolonu ile `ORDER BY` ve SQL metni `UNION` kullanmiyor (birlestirmeyi Delphi tarafinda yapiyor), dolayisiyla F1-21 ve F1-12 davranis degisikligi mevcut kodu kirpmiyor.

| # | Duzeltme | Dosya | Test |
|---|----------|-------|------|
| F1-1 | `Recover`: commitlenmemis batch `committedThrough` konumundan fiziksel kirpilir, `FSeq` geri alinir | VDbCore | T24 |
| F1-2 | `CommitBatch`: boyut on-kontrolu + hata halinde `FS.Size` geri alma, `Recover`, ikincil hata yutma | VDbCore | T24 |
| F1-3 | `MigrateLegacy`: 64 KB akis kopyasi (tam dosya RAM'e alinmiyor) | VDbCore | - |
| F1-4 | `CheckRestrict` yalniz degisen kolon bir cocuk FK'nin `RefCol`'u ise cagrilir | VDbTable | T24 |
| F1-5 | `UpdateWhere`: eski UNIQUE anahtari `FIdxUniq`'ten dusulur (yeni anahtar eklenmeden once) | VDbTable | T24 |
| F1-6 | `AlterDropColumn`: FK hedefi **ebeveyn** tablosunda `FindCol` ile aranir | VDbTable | T34 |
| F1-7 | `AlterAddColumn`: NOT NULL kontrolu `RewriteTable` ONCESINE alindi | VDbTable | T13 |
| F1-8 | `RewriteTable`/`RewriteTableRows`/`AlterRenameTable`: silmeden once `DecodeRow` ile dogrulama; `ecHashCollision` **ve** `ecCorrupt`; rename'de cozulemeyen satir sessizce atlanmiyor | VDbTable | T34 |
| F1-9 | `BatchInsert` kendi `FKv.CommitBatch` yerine `TVTableDb.BeginBatch/CommitBatch` kullanir (AutoInc + sema flush) | VDbTable | T20 |
| F1-10 | `OFFSET` iki alias listesinde; ayrica `OFFSET n LIMIT m` yazimi desteklenir | VDbParser | T35 |
| F1-11 | UNION/EXCEPT/INTERSECT oncesi sutun sayisi denetimi (`ecSyntaxError`) | VDbExecutor | T25 |
| F1-12 | Kuyruk **birlesme sonrasina**: (a) `ParseSelectTail` ayri procedure, sag SELECT icin `FSuppressTail` ile bastirilir; (b) `HasSetOp` bayragi `SkipOffsetLimit`'ten **ayridir** — eski kod `True` yaparak sol taraf WHERE filtresini hic uygulamiyor ve birlestirme bos kaliyordu; (c) aggregate/GROUP BY + set-op sessizce yanlis sonuc yerine `ecUnsupported` | VDbParser + VDbExecutor | T25 |
| F1-13 | `NOT IN` listede NULL varsa `hasNull` bayragi -> satir donmez | VDbExecutor | T31 |
| F1-14 | Karsilastirma operatorlerinde (`=`,`<>`,`<`,`<=`,`>`,`>=`,`LIKE`) NULL taraf **UNKNOWN** (`''`) doner. `EvalUnary(suoNot,'')` -> `''` korunur | VDbExecutor | T31 |
| F1-15 | `DELETE DATABASE` `ExecRaw`'da canli + `StmtBatchSafe` dislamasinda | VDbSql | T30 |
| F1-16 | `ExecUpdate`: bilinmeyen SET kolonu `ecColumnNotFound` (satir silinip aynen yazilmiyor) | VDbExecutor | T29 |
| F1-17 | `FindColIdx` yardimcisi: nitelemeli (`alias.col`) ve sonek eslestirmesi; binary op tip cozumlesmesi **sag** kolona da bakiyor | VDbExecutor | T28 |
| F1-20 | `ExecGroupBy` cikti tip haritasini disari verir (`out OutTypes`); GROUP BY `ORDER BY` ve `HAVING` bu tipleri kullanir | VDbExecutor | T26 |
| F1-21 | `DoSort`: bilinmeyen `ORDER BY` kolonu `ecColumnNotFound` (sessizce giris-sirasi donme yerine) | VDbExecutor | T27 |
| F1-22 | `FDepth` sayaci (256 sinir) parantez ve NOT zincirinde tasma hatasi | VDbParser | T24 |
| F1-23 | `SplitStatements` tirnak, cift tirnak, `--` ve `/* */` durumlarini izler | VDbSql | T20 |

# F1 MUTASYON DOGRULAMA

Her F1 duzeltmesi geri alindi ve testin KIRMIZI oldugu goruldu. Bu, testin
o duzeltmeyi gercekten yakaladiginin kanitidir ("test yazildi" demek yeterli
degildir — test duzeltmeden bagimsiz da gecebilir).

| # | Geri alinan duzeltme | KIRMIZI olan test |
|---|---------------------|-------------------|
| F1-1 | `Recover`: `truncatePos := pos` (kirpma yok) | `yarim batch diskte kaldi (oluk prefix)` + `Verify kirpma sonrasi basarisiz [BOZUK @134: seq kirik beklenen=5 gelen=1]` |
| F1-2 | `CommitBatch`: on-dogrulama + rollback | `hata sonrasi kayit sayisi degismedi [beklenen 1, gelen 2]` (phantom kayit gorunur oldu) |
| F1-4 | `ExecUpdate`: `Delete`+`Insert` yerine `UpdateRowInPlace` | `CASCADE ile cocuk yanlis silinmedi [sonuc hucre yok]` — cocuk satir ON DELETE CASCADE ile SILINDI |
| F1-4 | `FindColIdx` sonek eslestirmesi | `JOIN + WHERE nitelemesiz kolon sayisal [Kolon bulunamadi: tutar]` |
| F1-5 | `IdxDelRow(t, oldVals, ...)` | `KESILDI: UNIQUE ihlali: etiket` — GECERLI INSERT reddedildi |
| F1-6 | RefCol kontrolunu dogru tablo yerine `kv.Key` ile aramak | `cocuk FK RefCol olan kolon drop edilemez [HATA VERMEDI]` + `FK butunlugu bozulmadi [FK hedef kolon yok: k]` — sarkan FK olustu |
| F1-7 | `ADD COLUMN` onundaki NOT NULL kontrolu | `mevcut satirlar varken NOT NULL eklenemez [HATA VERMEDI]` + sonraki denemede `kolon var: z` — kalici DDL bozulmasi |
| F1-11 | UNION sutun sayisi denetimi | `UNION/EXCEPT/INTERSECT sutun sayisi farki hata [HATA VERMEDI]` (3 test) |
| F1-12 | `not HasSetOp` guard'lari (kuyruk pre-merge) | `UNION OFFSET sonrasi 2 satir [gelen 0]`, `UNION ORDER BY+LIMIT+OFFSET [beklenen "2" gelen "3"]` (4 test) |
| F1-14 | karsilastirmalarda NULL -> UNKNOWN guard'i | `NULL LIKE ile eslesmez [beklenen 2, gelen 3]`, `NOT NULL satir gelmez [beklenen 1, gelen 2]` |
| F1-16 | `ExecUpdate` bilinmeyen kolon kontrolu | `UPDATE bilinmeyen kolon [HATA VERMEDI]` |
| F1-17 | binary op tip cozumlemesi (`FindColIdx` cagrilari) | `JOIN + WHERE sayisal > 2 [beklenen 2, gelen 1]` + `index > arama [beklenen "10" gelen "9"]` + `CTE sayisal WHERE` (10 test) |
| F1-19 | `SUM` bos kume -> NULL | `SUM bos tablo NULL [beklenen "" gelen "0"]`, `SUM hepsi NULL grup NULL` |
| F1-20 | GROUP BY `ORDER BY` tip haritasi (`nil` yerine `outTypes`) | `GROUP BY COUNT ORDER BY ASC ilk grup b(2) [beklenen "b" gelen "a"]` (9 test) — metin sirasi `'10'<'2'<'3'` |
| F1-21 | `DoSort` bilinmeyen kolon hatasi | `ORDER BY bilinmeyen kolon [HATA VERMEDI]` |
| F1-22 | `FDepth > 256` derinlik kontrolu | `5000 parantez temiz hata vermedi [kabul edildi (tasma riski)]` |
| F1-23 | `SplitStatements` yorum atlama | 13 test dustu (`3 komut islendi [beklenen 3, gelen 1]`, `karisik betik 3 cumle`, ...) |

### Gozlemsel olarak AYIRT EDILEMEYEN kalemler (durus olarak kayit altina alindi)

Bu kalemlerin **kodu dogru**, ama mutasyon testi gözlemsel bir fark
uretemiyor. Bunu "test edildi" diye gizlemek yeren acikca yaziyoruz:

| # | Durum | Neden ayirt edilemiyor |
|---|-------|------------------------|
| F1-3 | `MigrateLegacy` akis kopyasi | 400 kayitlik legacy dosya **kayipsiz** aktariliyor (`fsize=26692 copied=26692 idx=400`). Akis kopyasi ile tam-RAM kopyasi ayni sonucu verir; fark yalnizca ~1 GB dosyada BELLEK olcumuyle gorunur. Test dogruluk kaniti; bellek davranisi yapısal (64 KB sabit tampon). |
| F1-9 | `BatchInsert` -> `TVTableDb.CommitBatch` | Etki yalnizca "sema kirli + batch disi BatchInsert" kombinasyonunda belirir. `TVTableDb.CommitBatch` icindeki `if FSchemaDirty then SaveSchema` sartini SQL/API disindan tetiklemek gerekiyor (beyaz-kutu). AUTOINCREMENT ve Verify testleri **gecer** ama mutasyonda da gecer — ayirt edici degil. |
| F1-15 | `StmtBatchSafe` icin `DELETE DATABASE` | `ExecAll` zaten batch'siz cumleleri ayri calistiriyor; `StmtBatchSafe` sonucu bu yolda gozlemsel olarak ayni. Kontrol `private` oldugu icin dogrudan cagrilamiyor. Canli `DELETE DATABASE` yolu T30'da dogrulanmistir. |
| F1-18 | `LIMIT/OFFSET` deger dogrulama | Deger dogrulamasi **tokenizer katmaninda zaten** gerceklesiyor (`LIMIT: dogal sayi bekleniyor, "-" bulundu`). `ParseSelectTail` icindeki ikinci kontrol (pratik olarak) yedek; mutasyonunda testler yesil kaldi. |
| F1-10 | `OFFSET` alias listesi | `SELECT * FROM t OFFSET n` her iki yolda da calisiyordu; alias listesi pratikte etkisiz. Gercek katki: `OFFSET n LIMIT m` yaziminin eklenmesi. |
| F1-8 | Hash dogrulamasi | Mevcut T21 zaten sentetik carpisma ile INSERT/FK yollarini kovaliyor; `AlterRenameTable` carpisma senaryosu FNV-1a 64-bit ile pratikte uretilemedigi icin yalnizca veri butunlugu dogrulanir. |

### F1 sirasinda DENETIM RAPORUNDA OLMAYAN gercek hata (bulundu ve duzeltildi)

**F1-4 tamamlayici — SQL `UPDATE` veri kaybi.**
Rapor F1-4'u `UpdateWhere` icinde tanimlamisti. Oysa SQL katmanindaki
`ExecUpdate` `UpdateWhere`'i **hic cagirmiyor**; her satiri
`FT.Delete` + `FT.Insert` ile yeniden yaziyordu. Sonuc: `ON DELETE CASCADE`
bir UPDATE'in **silme** yarisiyla tetikleniyor, yani **ilgisiz bir kolon**
guncellenirken cocuk satirlari SILINIYORDU. Bu dogrulamasi T38'de yakalandi
ve `TVTableDb.UpdateRowInPlace` ile tek kaynaga baglandi (`UpdateWhere` de
artik onu cagiriyor -> iki yerde mükerrer mantik yok).
Ayrica SQL UPDATE'a PK kolonu guncelleme yasağı eklendi.

## Yeni test bolumleri (sqltest.lpr)

| Test | Kapsam |
|------|--------|
| T25_F1_UnionSiraVeLimit | UNION/ALL/EXCEPT/INTERSECT, sutun sayisi hatasi, birlestirme sonrasi ORDER BY/OFFSET/LIMIT |
| T26_F1_OrderByTip | COUNT/SUM/MIN/MAX cikti tipi ile sayisal siralama (`'10' < '2'` tuzagi) |
| T27_F1_OrderByBilinmeyenKolon | bilinmeyen kolon hata verir, gecerli ORDER BY calisir |
| T28_F1_JoinTipKiyas | JOIN sonrasi nitelemeli/nitelemesiz sayisal kiyaslama, LEFT JOIN NULL elemesi |
| T29_F1_UpdateBilinmeyenKolon | hata + veri butunlugu + gecerli UPDATE + 0-satir UPDATE |
| T30_F1_DeleteDatabase | canli yol + `ExecAll` betik yolu, silinen DB yok |
| T31_F1_NotInNull | `NOT IN`/NULL, `NOT (...)`, `IS NULL` |
| T32_F1_LimitGecersiz | negatif/sayi disi LIMIT+OFFSET hata verir |
| T33_F1_SumBosKume | bos tablo ve hepsi-NULL grupta SUM NULL |
| T34_F1_AlterRenameBozukSatir | rename sonrasi veri + FK referansi yeni ada guncellenir |
| T35_F1_OffsetAlias | `SELECT * ... OFFSET n`, `OFFSET n LIMIT m`, `LIMIT n OFFSET m` |
| T36_F1_RecoverKirpma | **F1-1** crash benzetimi: dosyaya BATCHEND'siz kayit eklenir, `Recover` fiziksel kirpar, `Verify` gecer |
| T37_F1_CommitBatchAtomik | **F1-2** limit asiminda `CommitBatch` hata verir, dosya buyumez, restart tutarli |
| T38_F1_CheckRestrictFiltresi | **F1-4** UPDATE ilgisiz kolon FK tetiklemez; ON DELETE CASCADE cocugu yanlis silmez |
| T39_F1_UniqueBayatAnahtar | **F1-5** UPDATE sonrasi serbest kalan UNIQUE degeri yeniden kullanilabilir |
| T40_F1_AlterDropColumnFK | **F1-6** sarkan FK olusmaz; FK kaynak kolonu kasitli reddedilir |
| T41_F1_AlterAddColumnNotNull | **F1-7** basarisiz DDL kalici olmaz, ayni deneme tekrar calisir |
| T42_F1_BatchInsertAtomik | **F1-9** coklu INSERT + AUTOINCREMENT + Verify |
| T43_F1_MigrateLegacy | **F1-3** basliksiz (legacy) dosya 400 kayitla uretilir, gecis sonrasi kayipsiz |
| T44_F1_ParserDerinlik | **F1-22** 250 parantez kabul, 5000 parantez temiz hata, motor saglam kalir |
| T45_F1_SplitStatements | **F1-23** `--`, `/* */`, `"`, tirnak ici `;` bolmez |

## F1 sirasinda karsilasilan ek gercekler (kapsam disi, kayit icin)

- **LEFT JOIN null-genisletmesi** birlestirme *kolonu* icin bos string yerine anahtar degeri yaziyor; `WHERE s.id IS NULL` eslesmeyen satiri bulamaz (`s.tutar IS NULL` calisiyor). `T28` icinde yorum olarak isaretlendi.
- **Tablolarda `ORDER BY` yoksa satir sirasi garantisi yok** ( indeks/PK okuma sirasi). Testlerde belirli satir bekleyen kontroller `ORDER BY` icermeli.
- `had.lpi` ve `mtakipwebsrv.lpi` **unit arama yolu** hatasi veriyor (`Can't find unit VDbSql/VDbCore`) — F1 oncesinden gelen, `.lpi` degisikligi gerektiren ayri bir konu.
