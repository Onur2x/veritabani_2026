program mtakipwebsrv;

{ Makinist Takip Web Server - konsol uygulamasi (LCL yok).
  Her hat kendi veri_*.json dosyasinda (tek yazici: bu server).
  Kullanim:
    mtakipwebsrv [--port=8900] [--data=..\data] [--web=..\web_prototype] [--hat=M8]
  Eski tek-dosya kullanimi da calisir: --data=..\data\veri.json
}

{$mode objfpc}{$H+}

uses
  {$IFDEF UNIX}
  cthreads,
  {$ENDIF}
  Classes, SysUtils, fphttpserver, websrv;

{$IFDEF WINDOWS}
function SetThreadExecutionState(esFlags: DWORD): DWORD; stdcall;
  external 'kernel32.dll' name 'SetThreadExecutionState';
const
  ES_CONTINUOUS = DWORD($80000000);
  ES_SYSTEM_REQUIRED = DWORD($00000001);
{$ENDIF}

var
  Srv: TFPHTTPServer;
  W: TWebSrv;
  Port: Integer;
  DataYol, WebDir, ExeDir, VarsayilanHat, P: string;
  i: Integer;

begin
  { Lazarus/LCL ile ayni davranis: tum string donusumleri UTF-8.
    Yoksa POST ile gelen Turkce her turda bir kat daha kodlanir. }
  SetMultiByteConversionCodePage(CP_UTF8);
  SetMultiByteFileSystemCodePage(CP_UTF8);
  ExeDir := ExtractFilePath(ParamStr(0));
  Port := 8900;
  DataYol := ExpandFileName(ExeDir + '..' + PathDelim + 'data');
  WebDir := ExpandFileName(ExeDir + '..' + PathDelim + 'web_prototype');
  VarsayilanHat := 'M8';
  for i := 1 to ParamCount do
  begin
    P := ParamStr(i);
    if Copy(P, 1, 7) = '--port=' then
      Port := StrToIntDef(Copy(P, 8, 999), Port)
    else if Copy(P, 1, 7) = '--data=' then
      DataYol := ExpandFileName(Copy(P, 8, 999))
    else if Copy(P, 1, 6) = '--web=' then
      WebDir := ExpandFileName(Copy(P, 7, 999))
    else if Copy(P, 1, 6) = '--hat=' then
      VarsayilanHat := UpperCase(Trim(Copy(P, 7, 999)))
    else if (P = '-h') or (P = '--help') then
    begin
      WriteLn('Kullanim: mtakipwebsrv [--port=8900] [--data=...] [--web=...] [--hat=M8]');
      Halt(0);
    end;
  end;

  {$IFDEF WINDOWS}
  { PC uykuya gecmesin (server calistikca): yetki/betik gerekmez }
  SetThreadExecutionState(ES_CONTINUOUS or ES_SYSTEM_REQUIRED);
  {$ENDIF}
  WriteLn('Makinist Takip Web Server');
  WriteLn('  veri : ', DataYol);
  WriteLn('  web  : ', WebDir);
  WriteLn('  hat  : ', VarsayilanHat);
  if not DirectoryExists(WebDir) then
    WriteLn('UYARI: web klasoru yok, sadece API calisir.');

  W := TWebSrv.Olustur(DataYol, WebDir, VarsayilanHat);
  Srv := TFPHTTPServer.Create(nil);
  try
    Srv.Port := Port;
    Srv.Threaded := True;
    Srv.AcceptIdleTimeout := 100;
    Srv.OnRequest := @W.Istek;
    Srv.Active := True;
    WriteLn('Dinleniyor: http://127.0.0.1:', Port, '/  (pano: /pano.html?hat=M8)');
    WriteLn('Durdurmak icin: q + Enter');
    repeat
      try
        ReadLn(P);
      except
        { etkilesimsiz ortam (gorev zamanlayici): stdin EOF verir; olme, bekle }
        P := '';
        Sleep(60000);
      end;
    until LowerCase(Trim(P)) = 'q';
    Srv.Active := False;
  finally
    Srv.Free;
    W.Free;
  end;
end.
