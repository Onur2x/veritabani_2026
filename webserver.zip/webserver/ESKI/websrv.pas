unit websrv;

{ Makinist Takip - Web Server (DB'nin tek sahibi)
  Konsol uygulamasi, LCL BAGIMLILIGI YOK.
  Mevcut masaustu exe'deki (onurvt.pas + onurmakinist.pas) veri ve
  SiralamaYap mantiginin web/JSON karsiligi.

  Endpoint'ler:
    GET  /                    -> /pano.html'e 302
    GET  /pano.html, /veri_37.json, ... (web klasorunden statik)
    GET  /api/durum           -> versiyon, saat, tablo sayilari
    GET  /api/ayarlar         -> AYARLAR objesi
    GET  /api/tablo/ADI       -> tablo JSON array (+eski /tablo/ADI)
    POST /api/tablo/ADI       -> array ile komple degistir + kaydet
    POST /api/yukle-tablo/ADI -> upsert: ID varsa guncelle, yoksa ekle
    POST /api/temizle-tablo/ADI {"TTID":".."} -> tarifeye ait satirlari sil
    GET  /api/resim?sicil=     -> foto indir
    POST /api/resim?sicil=     -> foto yukle (ham jpeg/png govde)
    GET  /api/pano?ttid=&gun=&suan=&yon=&mod=&hat= -> hesaplanmis pano JSON
    POST /komut, /api/komut   -> sirali/numarali/flash/... (AYARLAR yazar)
    POST /dosyaal?adi=        -> eski istemci uyumlulugu (dosyayi data'ya yazar)
    GET  /api/hatlar          -> hat listesi ["M8",...]
    POST /api/hat {"hat":"M5"} -> yeni bos hat dosyasi olustur
    GET  /api/tablolar        -> tablo adlari (arsiv kesfi icin)
  Tum /api/* ve /tablo/*, /komut istekleri ?hat= ile hatta baglanir
  (bos birakilirsa varsayilan hat). Veri dosyalari: veri_{HAT}.json
}

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, fpjson, jsonparser, fphttpserver, httpdefs, DateUtils, base64, sha1;

const
  SRV_VERSIYON = '0001';

type
  { Tek hat deposu: bir JSON dosya + bellek goruntusu }
  THatStore = class
    Hat: string;
    Dosya: string;
    Veri: TJSONObject;
    FileAge: LongInt;
    constructor Olustur(const AHat, ADosya: string);
    destructor Destroy; override;
  end;

  TWebSrv = class
  private
    FHatlar: TStringList; { Name=hat kodu, Object=THatStore }
    FWebDir: string;
    FVarsayilanHat: string;
    FOturumlar: TStringList; { "HAT:token" kayitlari }
    FKilit: TRTLCriticalSection;
    function HatBul(const Hat: string): THatStore;
    procedure Yukle(H: THatStore);
    procedure Kaydet(H: THatStore);
    procedure AnlikGoruntuYaz(H: THatStore);
    procedure GerekirseYenidenYukle(H: THatStore);
    function TabloArr(H: THatStore; const Adi: string): TJSONArray;
    function SonrakiId(H: THatStore; const Adi: string): string;
    function AyarOku(H: THatStore; const Alan: string): string;
    procedure AyarYaz(H: THatStore; const Alan, Deger: string);
    function SureCevir(const S: string): Integer;
    function SureYaz(Sn: Integer): string;
    function TTIdSec(H: THatStore): string;
    function GunKolon: string;
    function PanoHesapla(H: THatStore; const TTId, Gun, SuanStr, Yon, AMod: string): TJSONObject;
    function MimeTip(const FN: string): string;
    procedure StatikSun(const Yol: string; var AResp: TFPHTTPConnectionResponse);
    function KomutIsle(H: THatStore; const Komut: string): string;
    function HatListesiJson: string;
    function TabloAdlariJson(H: THatStore): string;
    function TabloSay(H: THatStore; const Adi: string): Integer;
    function HatSifresi(const Hat: string): string;
    function SifreDosyasiYaz(const Anahtar, Deger: string): Boolean;
    function OturumGecerli(const Hat, Tok: string): Boolean;
    function OturumYonetici(const Tok: string): Boolean;
    function OturumAc(const Hat: string): string;
    procedure OturumKapat(const Tok: string);
    function VeriKlasoru: string;
    function SifreYolu: string;
    function YedekKlasoru: string;
    function GunlukDosya(const Ay: string): string;
    procedure IslemKaydet(const Hat, Yontem, Yol, Oturma, Detay: string; Kod: Integer);
    function GirisSayfasi(const Geri, IlkBaslik, Hat, HatSecenek: string): string;
  public
    constructor Olustur(const DataDir, WebDir, VarsayilanHat: string);
    destructor Destroy; override;
    procedure Istek(Sender: TObject; var ARequest: TFPHTTPConnectionRequest;
      var AResponse: TFPHTTPConnectionResponse);
    property WebKlasor: string read FWebDir;
  end;

function QParam(const Q, Ad: string): string;

implementation

function QParam(const Q, Ad: string): string;
var
  i: Integer;
  k, v: string;
begin
  Result := '';
  if Q = '' then Exit;
  i := 1;
  while i <= Length(Q) do
  begin
    k := ''; v := '';
    while (i <= Length(Q)) and (Q[i] <> '&') and (Q[i] <> '=') do
    begin k := k + Q[i]; Inc(i); end;
    if (i <= Length(Q)) and (Q[i] = '=') then
    begin
      Inc(i);
      while (i <= Length(Q)) and (Q[i] <> '&') do
      begin v := v + Q[i]; Inc(i); end;
    end;
    if AnsiCompareText(k, Ad) = 0 then begin Result := v; Exit; end;
    Inc(i);
  end;
end;

function TemizYol(const U: string): string;
var
  p: Integer;
begin
  Result := U;
  p := Pos('?', Result);
  if p > 0 then Result := Copy(Result, 1, p - 1);
  Result := Trim(Result);
end;

function JAlan(o: TJSONObject; const f: string): string;
var
  d: TJSONData;
begin
  Result := '';
  if o = nil then Exit;
  d := o.Find(f);
  if d <> nil then Result := d.AsString;
end;

{ GRUP1='7;35' veya '1-9' gibi 'a;b' / 'a-b' araliginda mi }
function GermAralik(const Grup: string; Idx: Integer): Boolean;
var
  p, a, b: Integer;
  s: string;
begin
  Result := False;
  s := StringReplace(Grup, '-', ';', [rfReplaceAll]);
  p := Pos(';', s);
  if p = 0 then Exit;
  a := StrToIntDef(Trim(Copy(s, 1, p - 1)), -1);
  b := StrToIntDef(Trim(Copy(s, p + 1, 99)), -1);
  Result := (a >= 0) and (Idx >= a) and (Idx <= b);
end;

{ Mesaj zaman penceresi: BASLAMA/BITIS bossa hep goster; gece devri desteklenir }
function MesajAktif(const R: TJSONObject; Suan: Integer): Boolean;
var
  b1, b2, h, m, s: Integer;
  s1, s2: string;
  function SaatCevir(const V: string): Integer;
  var
    hh, mm, ss: Integer;
  begin
    Result := -1;
    if TryStrToInt(Copy(V, 1, 2), hh) and TryStrToInt(Copy(V, 4, 2), mm) and
      TryStrToInt(Copy(V, 7, 2), ss) then
      Result := hh * 3600 + mm * 60 + ss;
  end;
begin
  Result := True;
  s1 := Trim(JAlan(R, 'BASLAMA'));
  s2 := Trim(JAlan(R, 'BITIS'));
  if (s1 = '') and (s2 = '') then Exit;
  b1 := SaatCevir(s1);
  b2 := SaatCevir(s2);
  if (b1 < 0) and (b2 < 0) then Exit;
  if b1 < 0 then b1 := 0;
  if b2 < 0 then b2 := 86400;
  if b2 <= b1 then
    Result := (Suan >= b1) or (Suan < b2)
  else
    Result := (Suan >= b1) and (Suan < b2);
end;

{ Gorev eslestirme: bastaki F öneki yoksayilir (kadroda F252 = tarifede 252) }
function GorevNorm(const G: string): string;
begin
  Result := Trim(G);
  if (Result <> '') and (UpCase(Result[1]) = 'F') then
    Result := Trim(Copy(Result, 2, 999));
end;

{ 'a;b;c' listesinin idx'inci parcasi (yoksa ilk parca) }
function ParcaAl(const S: string; Idx: Integer): string;
var
  p: TStringList;
begin
  Result := '';
  p := TStringList.Create;
  try
    p.Delimiter := ';';
    p.StrictDelimiter := True;
    p.DelimitedText := S;
    if p.Count = 0 then Exit;
    if (Idx < 0) or (Idx >= p.Count) then
      Result := Trim(p[0])
    else
      Result := Trim(p[Idx]);
  finally
    p.Free;
  end;
end;

{ THatStore }

constructor THatStore.Olustur(const AHat, ADosya: string);
begin
  inherited Create;
  Hat := AHat;
  Dosya := ADosya;
  Veri := nil;
  FileAge := -1;
end;

destructor THatStore.Destroy;
begin
  Veri.Free;
  inherited Destroy;
end;

{ TWebSrv }

constructor TWebSrv.Olustur(const DataDir, WebDir, VarsayilanHat: string);
var
  sr: TSearchRec;
  hat, fp: string;
begin
  inherited Create;
  FWebDir := ExcludeTrailingPathDelimiter(WebDir);
  FVarsayilanHat := UpperCase(Trim(VarsayilanHat));
  if FVarsayilanHat = '' then FVarsayilanHat := 'M8';
  FHatlar := TStringList.Create;
  InitCriticalSection(FKilit);
  if DirectoryExists(DataDir) then
  begin
    // coklu-hat: veri_{HAT}.json dosyalari
    if FindFirst(IncludeTrailingPathDelimiter(DataDir) + 'veri_*.json',
      faAnyFile, sr) = 0 then
    try
      repeat
        fp := IncludeTrailingPathDelimiter(DataDir) + sr.Name;
        hat := UpperCase(Copy(sr.Name, 6, Length(sr.Name) - 10));
        if (hat <> '') and (FHatlar.IndexOf(hat) < 0) then
          FHatlar.AddObject(hat, THatStore.Olustur(hat, fp));
      until FindNext(sr) <> 0;
    finally
      FindClose(sr);
    end;
    // eski tek dosya duzeni: veri.json varsa varsayilan hat olarak al
    fp := IncludeTrailingPathDelimiter(DataDir) + 'veri.json';
    if (FHatlar.Count = 0) and FileExists(fp) then
      FHatlar.AddObject(FVarsayilanHat, THatStore.Olustur(FVarsayilanHat, fp));
  end
  else
  begin
    // tek dosya (eski --data=dizini degil dosya kullanimi)
    FHatlar.AddObject(FVarsayilanHat, THatStore.Olustur(FVarsayilanHat, DataDir));
  end;
  FHatlar.Sorted := True;
  for hat in FHatlar do
    Yukle(HatBul(hat));
  FOturumlar := TStringList.Create;
end;

destructor TWebSrv.Destroy;
var
  i: Integer;
begin
  EnterCriticalSection(FKilit);
  try
    for i := 0 to FHatlar.Count - 1 do
      Kaydet(THatStore(FHatlar.Objects[i]));
  finally
    LeaveCriticalSection(FKilit);
  end;
  for i := 0 to FHatlar.Count - 1 do
    THatStore(FHatlar.Objects[i]).Free;
  FHatlar.Free;
  FOturumlar.Free;
  DoneCriticalSection(FKilit);
  inherited Destroy;
end;

function TWebSrv.HatBul(const Hat: string): THatStore;
var
  h: string;
  i: Integer;
begin
  Result := nil;
  if FHatlar.Count = 0 then Exit;
  h := UpperCase(Trim(Hat));
  if h = '' then h := FVarsayilanHat;
  i := FHatlar.IndexOf(h);
  if i >= 0 then Result := THatStore(FHatlar.Objects[i]);
end;

function TWebSrv.HatListesiJson: string;
var
  i: Integer;
  arr: TJSONArray;
begin
  arr := TJSONArray.Create;
  try
    for i := 0 to FHatlar.Count - 1 do
      arr.Add(FHatlar[i]);
    Result := arr.AsJSON;
  finally
    arr.Free;
  end;
end;

{ Sabit hat sifreleri: data/sifreler.json {"M8":"...","M5":"..."}.
  Dosya yoksa/hat yoksa acik. Kullanicilar panelden degistiremez. }
function TWebSrv.HatSifresi(const Hat: string): string;
var
  fs: TFileStream;
  buf: UTF8String;
  jd: TJSONData;
  d: TJSONData;
  yol: string;
begin
  Result := '';
  if FHatlar.Count = 0 then Exit;
  yol := IncludeTrailingPathDelimiter(ExtractFilePath(
    THatStore(FHatlar.Objects[0]).Dosya)) + 'sifreler.json';
  if not FileExists(yol) then Exit;
  try
    fs := TFileStream.Create(yol, fmOpenRead or fmShareDenyNone);
    try
      SetLength(buf, fs.Size);
      if fs.Size > 0 then fs.ReadBuffer(buf[1], fs.Size);
    finally
      fs.Free;
    end;
    try
      jd := GetJSON(buf);
    except
      jd := nil;
    end;
    if (jd <> nil) and (jd.JSONType = jtObject) then
    begin
      d := TJSONObject(jd).Find(UpperCase(Trim(Hat)));
      if d <> nil then Result := Trim(d.AsString);
    end;
    jd.Free;
  except
    Result := '';
  end;
end;

function TWebSrv.TabloSay(H: THatStore; const Adi: string): Integer;
var
  a: TJSONArray;
begin
  Result := 0;
  a := TabloArr(H, Adi);
  if a <> nil then Result := a.Count;
end;

function TWebSrv.TabloAdlariJson(H: THatStore): string;
var
  i: Integer;
  arr: TJSONArray;
begin
  arr := TJSONArray.Create;
  try
    if (H <> nil) and (H.Veri <> nil) then
      for i := 0 to H.Veri.Count - 1 do
        arr.Add(H.Veri.Names[i]);
    Result := arr.AsJSON;
  finally
    arr.Free;
  end;
end;

{ Hat bazli yonetim girisi. Sifre data/sifreler.json dosyasinda sabittir
  ({"M8":"..."}); kullanicilar panelden degistiremez.
  Kayit "sha1:<hex>" ise salt'li ozet karsilastirilir (dosyadan okunamaz),
  degilse eski duz-metin karsilastirma (gecis uyumlulugu).
  Oturumlar "HAT:token" olarak tutulur. ADMIN sifresiyle giren super
  kullanici "*:token" alir ve tum hatlarda gecerlidir. }
function SifreTutuyor(const Kayitli, Girilen: string): Boolean;
var
  ozet: string;
begin
  Result := False;
  if (Trim(Kayitli) = '') or (Trim(Girilen) = '') then Exit;
  if LowerCase(Copy(Kayitli, 1, 5)) = 'sha1:' then
  begin
    ozet := SHA1Print(SHA1String(UTF8Encode('mtakip-admin:' + UnicodeString(Girilen))));
    Result := LowerCase(ozet) = LowerCase(Trim(Copy(Kayitli, 6, 999)));
  end
  else
    Result := Kayitli = Girilen;
end;
function TWebSrv.OturumGecerli(const Hat, Tok: string): Boolean;
begin
  Result := False;
  if Trim(Tok) = '' then Exit;
  EnterCriticalSection(FKilit);
  try
    Result := (FOturumlar.IndexOf(UpperCase(Trim(Hat)) + ':' + Trim(Tok)) >= 0)
      or (FOturumlar.IndexOf('*:' + Trim(Tok)) >= 0);
  finally
    LeaveCriticalSection(FKilit);
  end;
end;

function TWebSrv.OturumAc(const Hat: string): string;
var
  g: TGUID;
begin
  CreateGUID(g);
  Result := LowerCase(Copy(GUIDToString(g), 2, 36));
  EnterCriticalSection(FKilit);
  try
    if FOturumlar.IndexOf(UpperCase(Trim(Hat)) + ':' + Result) < 0 then
      FOturumlar.Add(UpperCase(Trim(Hat)) + ':' + Result);
  finally
    LeaveCriticalSection(FKilit);
  end;
end;

procedure TWebSrv.OturumKapat(const Tok: string);
var
  i: Integer;
  t: string;
begin
  t := Trim(Tok);
  if t = '' then Exit;
  EnterCriticalSection(FKilit);
  try
    for i := FOturumlar.Count - 1 downto 0 do
      if (Length(FOturumlar[i]) > Length(t)) and
        (Copy(FOturumlar[i], Length(FOturumlar[i]) - Length(t) + 1, Length(t)) = t) and
        (FOturumlar[i][Length(FOturumlar[i]) - Length(t)] = ':') then
        FOturumlar.Delete(i);
  finally
    LeaveCriticalSection(FKilit);
  end;
end;

function TWebSrv.OturumYonetici(const Tok: string): Boolean;
begin
  Result := False;
  if Trim(Tok) = '' then Exit;
  EnterCriticalSection(FKilit);
  try
    Result := FOturumlar.IndexOf('*:' + Trim(Tok)) >= 0;
  finally
    LeaveCriticalSection(FKilit);
  end;
end;

function TWebSrv.VeriKlasoru: string;
begin
  Result := '';
  if FHatlar.Count = 0 then Exit;
  Result := IncludeTrailingPathDelimiter(ExtractFilePath(
    THatStore(FHatlar.Objects[0]).Dosya));
end;

function TWebSrv.SifreYolu: string;
begin
  Result := '';
  if FHatlar.Count = 0 then Exit;
  Result := IncludeTrailingPathDelimiter(ExtractFilePath(
    THatStore(FHatlar.Objects[0]).Dosya)) + 'sifreler.json';
end;

function TWebSrv.YedekKlasoru: string;
begin
  Result := IncludeTrailingPathDelimiter(ExpandFileName(
    ExtractFileDir(ParamStr(0)) + PathDelim + '..' + PathDelim + 'backup'));
  if not DirectoryExists(Result) then
    ForceDirectories(Result);
end;

{ Yedek dosya adi guvenligi: veri_HAT_YYYYMMDD_HHMMSS.json kalibinda mi }
function DosyaAdiGuvenli(const Ad, Hat: string): Boolean;
var
  on, k: string;
  i: Integer;
begin
  Result := False;
  on := 'veri_' + Hat + '_';
  if Copy(Ad, 1, Length(on)) <> on then Exit;
  if (Length(Ad) < Length(on) + 20) or
    (Copy(Ad, Length(Ad) - 4, 5) <> '.json') then Exit;
  k := Copy(Ad, Length(on) + 1, Length(Ad) - Length(on) - 5);
  if Length(k) <> 15 then Exit;
  if k[9] <> '_' then Exit;
  for i := 1 to 15 do
    if i <> 9 then
      if not (k[i] in ['0'..'9']) then Exit;
  Result := True;
end;

{ sifreler.json'a anahtar yazar (ADMIN sha1 ozeti icin) }
function TWebSrv.SifreDosyasiYaz(const Anahtar, Deger: string): Boolean;
var
  fs: TFileStream;
  buf, s: UTF8String;
  root: TJSONData;
  mem: TMemoryStream;
begin
  Result := False;
  if SifreYolu = '' then Exit;
  EnterCriticalSection(FKilit);
  try
    root := nil;
    if FileExists(SifreYolu) then
    try
      fs := TFileStream.Create(SifreYolu, fmOpenRead or fmShareDenyNone);
      try
        SetLength(buf, fs.Size);
        if fs.Size > 0 then fs.ReadBuffer(buf[1], fs.Size);
      finally
        fs.Free;
      end;
      try
        root := GetJSON(buf);
      except
        root := nil;
      end;
      if (root <> nil) and (root.JSONType <> jtObject) then FreeAndNil(root);
    except
      root := nil;
    end;
    if root = nil then root := TJSONObject.Create;
    try
      TJSONObject(root).Strings[UpperCase(Trim(Anahtar))] := Deger;
      s := UTF8String(root.AsJSON);
      mem := TMemoryStream.Create;
      try
        if Length(s) > 0 then mem.WriteBuffer(s[1], Length(s));
        mem.SaveToFile(SifreYolu);
      finally
        mem.Free;
      end;
      Result := True;
    finally
      root.Free;
    end;
  finally
    LeaveCriticalSection(FKilit);
  end;
end;

{ Islem gunlugu dosyasi: aylik (islemgunlugu_YYYY_AA.jsonl). Ay='' ise bu ay. }
function TWebSrv.GunlukDosya(const Ay: string): string;
var
  a: string;
  y, m: Integer;
begin
  Result := '';
  if FHatlar.Count = 0 then Exit;
  a := Trim(Ay);
  y := StrToIntDef(Copy(a, 1, 4), 0);
  m := StrToIntDef(Copy(a, 6, 2), 0);
  if (Length(a) <> 7) or (a[5] <> '-') or (y < 2020) or (y > 2100) or
    (m < 1) or (m > 12) then
    a := FormatDateTime('yyyy-mm', Now);
  Result := VeriKlasoru + 'islemgunlugu_' + Copy(a, 1, 4) + '_' +
    Copy(a, 6, 2) + '.jsonl';
end;

{ Islem gunlugu: yazan istekleri aylik dosyaya ekler (dosya basina 5000 satir).
  Sifre/token ASLA yazilmaz; sadece rol (admin/kullanici/sifre) + islem + sonuc. }
procedure TWebSrv.IslemKaydet(const Hat, Yontem, Yol, Oturma, Detay: string; Kod: Integer);
var
  fyol: string;
  lst: TStringList;
  jo: TJSONObject;
  rol: string;
begin
  if FHatlar.Count = 0 then Exit;
  if OturumYonetici(Oturma) then rol := 'admin'
  else if Trim(Oturma) <> '' then rol := 'kullanici'
  else rol := 'sifre';
  if Kod = 403 then rol := rol + '/red';
  jo := TJSONObject.Create;
  try
    jo.Add('zaman', FormatDateTime('yyyy-mm-dd hh:nn:ss', Now));
    jo.Add('hat', Hat);
    jo.Add('rol', rol);
    jo.Add('islem', Yontem + ' ' + Yol);
    jo.Add('sonuc', Kod);
    jo.Add('detay', Copy(Detay, 1, 120));
    fyol := GunlukDosya('');
    lst := TStringList.Create;
    try
      if FileExists(fyol) then lst.LoadFromFile(fyol);
      lst.Add(jo.AsJSON);
      while lst.Count > 5000 do lst.Delete(0);
      lst.SaveToFile(fyol);
    finally
      lst.Free;
    end;
  finally
    jo.Free;
  end;
end;

function TWebSrv.GirisSayfasi(const Geri, IlkBaslik, Hat, HatSecenek: string): string;
var
  g: string;
  i: Integer;
begin
  g := Trim(Geri);
  if g = '' then g := '/yonetim.html';
  if (g = '') or (g[1] <> '/') then g := '/yonetim.html';
  for i := Length(g) downto 1 do
    if g[i] in ['<', '>', '"'] then Delete(g, i, 1);
  Result :=
    '<!DOCTYPE html><html lang="tr"><head><meta charset="UTF-8">' +
    '<meta name="viewport" content="width=device-width,initial-scale=1">' +
    '<title>Yonetim Girisi</title>' +
    '<style>body{margin:0;background:#0b0b0b;color:#eee;font-family:Tahoma,sans-serif;' +
    'display:flex;align-items:center;justify-content:center;height:100vh}' +
    '.k{width:340px;text-align:center}' +
    'input,select{width:100%;padding:10px;margin:8px 0;background:#222;color:#fff;border:1px solid #444;border-radius:6px}' +
    'button{padding:10px 22px;background:#12351c;color:#fff;border:1px solid #2a5;border-radius:6px;cursor:pointer;margin:4px}' +
    '.h{color:#aa6;font-size:13px;margin-bottom:6px}' +
    '.y{margin-top:18px;border-top:1px solid #333;padding-top:12px}' +
    '.y input{width:60%;display:inline-block;margin-right:6px}</style></head><body>' +
    '<div class="k"><h2>Makinist Takip</h2><div class="h">' + IlkBaslik + '</div>' +
    '<select id="h">' + HatSecenek + '</select>' +
    '<input id="s" type="password" placeholder="sifre" autocomplete="off">' +
    '<br><button id="g">Giris</button><div class="h" id="m"></div>' +
    '<script>function secHat(){return document.getElementById("h").value;}' +
    'function g(){var v=document.getElementById("s").value;' +
    'var H=secHat();' +
    'fetch("api/giris?hat="+encodeURIComponent(H),' +
    '{method:"POST",headers:{"Content-Type":"application/json"},' +
    'body:JSON.stringify({sifre:v})}).then(async r=>{var j=await r.json();' +
    'if(j.oturma){try{sessionStorage.setItem("ys_"+H,v);}catch(e){}' +
    'try{if(j.yonetici){sessionStorage.setItem("yonetici","1");}else{sessionStorage.removeItem("yonetici");}}catch(e){}' +
    'location.href="/yonetim.html?hat="+encodeURIComponent(H)+"&oturma="+j.oturma;}' +
    'else{document.getElementById("m").textContent=j.hata||"hatali";}});}' +
    'document.getElementById("g").onclick=g;' +
    'document.getElementById("s").onkeydown=function(e){if(e.key==="Enter")g();};</script>' +
    '</body></html>';
end;

procedure TWebSrv.Yukle(H: THatStore);
var
  fs: TFileStream;
  buf: UTF8String;
  jd: TJSONData;
begin
  if H = nil then Exit;
  H.Veri := nil;
  if FileExists(H.Dosya) then
  try
    fs := TFileStream.Create(H.Dosya, fmOpenRead or fmShareDenyNone);
    try
      SetLength(buf, fs.Size);
      if fs.Size > 0 then fs.ReadBuffer(buf[1], fs.Size);
    finally
      fs.Free;
    end;
    try
      jd := GetJSON(buf);
    except
      jd := nil;
    end;
    if (jd <> nil) and (jd.JSONType = jtObject) then
      H.Veri := TJSONObject(jd)
    else
      jd.Free;
  except
    H.Veri := nil;
  end;
  if H.Veri = nil then
    H.Veri := TJSONObject.Create;
  if H.Veri.Find('AYARLAR') = nil then
    H.Veri.Add('AYARLAR', TJSONObject.Create);
  if FileExists(H.Dosya) then
    H.FileAge := FileAge(H.Dosya)
  else
    H.FileAge := -1;
end;

{ Disaridan dosya degistiyse bellege al.
  Her istekte bir FileAge kontrolu kadar ucuzdur. }
procedure TWebSrv.GerekirseYenidenYukle(H: THatStore);
var
  age: LongInt;
begin
  if (H = nil) or (H.Dosya = '') then Exit;
  if not FileExists(H.Dosya) then Exit;
  age := FileAge(H.Dosya);
  if age = H.FileAge then Exit;
  EnterCriticalSection(FKilit);
  try
    if FileAge(H.Dosya) = H.FileAge then Exit;
    H.Veri.Free;
    H.Veri := nil;
    Yukle(H);
    WriteLn(FormatDateTime('hh:nn:ss', Now) +
      ' BILGI: veri dosyasi diskten yeniden yuklendi (' + H.Hat + ').');
  finally
    LeaveCriticalSection(FKilit);
  end;
end;

procedure TWebSrv.Kaydet(H: THatStore);
var
  fs: TFileStream;
  buf: UTF8String;
  tmp: string;
begin
  if (H = nil) or (H.Veri = nil) then Exit;
  buf := H.Veri.AsJSON;
  ForceDirectories(ExtractFilePath(H.Dosya));
  tmp := H.Dosya + '.tmp';
  fs := TFileStream.Create(tmp, fmCreate or fmShareDenyNone);
  try
    if Length(buf) > 0 then fs.WriteBuffer(buf[1], Length(buf));
  finally
    fs.Free;
  end;
  if FileExists(H.Dosya) then DeleteFile(H.Dosya + '.bak');
  if FileExists(H.Dosya) then RenameFile(H.Dosya, H.Dosya + '.bak');
  RenameFile(tmp, H.Dosya);
  H.FileAge := FileAge(H.Dosya);
  AnlikGoruntuYaz(H);
end;

{ Cevrimdisi pano yedegi: web klasorune hat snapshot yazar }
procedure TWebSrv.AnlikGoruntuYaz(H: THatStore);
var
  snap: string;
  sfs: TFileStream;
  buf: UTF8String;
begin
  if (H = nil) or (H.Veri = nil) or (FWebDir = '') then Exit;
  try
    snap := IncludeTrailingPathDelimiter(FWebDir) + 'pano-snapshot-' +
      UpperCase(Trim(H.Hat)) + '.json';
    buf := H.Veri.AsJSON;
    sfs := TFileStream.Create(snap, fmCreate or fmShareDenyNone);
    try
      if Length(buf) > 0 then sfs.WriteBuffer(buf[1], Length(buf));
    finally
      sfs.Free;
    end;
  except
    { snapshot yazilamazsa sessiz gec (asil kayit tamam) }
  end;
end;

function TWebSrv.SonrakiId(H: THatStore; const Adi: string): string;
var
  a: TJSONArray;
  i, mx, v: Integer;
  d: TJSONData;
begin
  mx := 0;
  a := TabloArr(H, Adi);
  if a <> nil then
    for i := 0 to a.Count - 1 do
    begin
      d := a.Items[i];
      if (d <> nil) and (d.JSONType = jtObject) then
      begin
        v := StrToIntDef(JAlan(TJSONObject(d), 'ID'), 0);
        if v > mx then mx := v;
      end;
    end;
  Result := IntToStr(mx + 1);
end;

function TWebSrv.TabloArr(H: THatStore; const Adi: string): TJSONArray;
var
  jd: TJSONData;
begin
  Result := nil;
  if H = nil then Exit;
  if H.Veri = nil then Exit;
  jd := H.Veri.Find(UpperCase(Trim(Adi)));
  if (jd <> nil) and (jd.JSONType = jtArray) then
    Result := TJSONArray(jd);
end;

function TWebSrv.AyarOku(H: THatStore; const Alan: string): string;
var
  jd, ay: TJSONData;
begin
  Result := '';
  if H = nil then Exit;
  if H.Veri = nil then Exit;
  ay := H.Veri.Find('AYARLAR');
  if (ay = nil) or (ay.JSONType <> jtObject) then Exit;
  jd := TJSONObject(ay).Find(Alan);
  if jd <> nil then Result := jd.AsString;
end;

procedure TWebSrv.AyarYaz(H: THatStore; const Alan, Deger: string);
var
  ay: TJSONObject;
  jd: TJSONData;
begin
  if H = nil then Exit;
  if H.Veri = nil then Exit;
  ay := TJSONObject(H.Veri.Find('AYARLAR'));
  if ay = nil then Exit;
  jd := ay.Find(Alan);
  if jd = nil then ay.Add(Alan, Deger)
  else jd.AsString := Deger;
end;

function TWebSrv.SureCevir(const S: string): Integer;
var
  p1, p2: Integer;
  h, m, sn: Integer;
  t: string;
begin
  Result := 0;
  t := Trim(S);
  p1 := Pos(':', t);
  if p1 = 0 then Exit;
  p2 := Pos(':', Copy(t, p1 + 1, 99));
  if p2 > 0 then p2 := p1 + p2;
  h := StrToIntDef(Copy(t, 1, p1 - 1), 0);
  if p2 > 0 then
  begin
    m := StrToIntDef(Copy(t, p1 + 1, p2 - p1 - 1), 0);
    sn := StrToIntDef(Copy(t, p2 + 1, 99), 0);
  end
  else
  begin
    m := StrToIntDef(Copy(t, p1 + 1, 99), 0);
    sn := 0;
  end;
  Result := h * 3600 + m * 60 + sn;
end;

function TWebSrv.SureYaz(Sn: Integer): string;
var
  h, m, s: Integer;
begin
  Sn := ((Sn mod 86400) + 86400) mod 86400;
  h := Sn div 3600; m := (Sn mod 3600) div 60; s := Sn mod 60;
  Result := Format('%.2d:%.2d:%.2d', [h, m, s]);
end;

function TWebSrv.TTIdSec(H: THatStore): string;
var
  dow: Integer;
begin
  // Pascal DayOfTheWeek: Pzt=1 ... Paz=7 (onurmakinist.pas:404-422 ile ayni)
  dow := DayOfTheWeek(Now);
  if AyarOku(H, 'TARIFEOROMANUEL') = 'True' then
  begin
    case dow of
      1: Result := AyarOku(H, 'TIMETABLEPZT_ID');
      2: Result := AyarOku(H, 'TIMETABLESAL_ID');
      3: Result := AyarOku(H, 'TIMETABLECAR_ID');
      4: Result := AyarOku(H, 'TIMETABLEPER_ID');
      5: Result := AyarOku(H, 'TIMETABLECUM_ID');
      6: Result := AyarOku(H, 'TIMETABLECMT_ID');
      7: Result := AyarOku(H, 'TIMETABLEPZR_ID');
    else
      Result := AyarOku(H, 'TIMETABLE_ID');
    end;
  end
  else
    Result := AyarOku(H, 'TIMETABLE_ID');
  if Result = '' then Result := '0';
end;

function TWebSrv.GunKolon: string;
begin
  // onurmakinist.pas:559 -> 'G' + ayin gunu
  Result := 'G' + IntToStr(DayOfTheMonth(Now));
end;

function TWebSrv.PanoHesapla(H: THatStore; const TTId, Gun, SuanStr, Yon, AMod: string): TJSONObject;
var
  src, srcC: TJSONArray;
  tt, ttC: array of record
    gorev, saat, run, dizi, hat, cikar, disi, kontrol: string;
  end;
  i, n, k, idx, hangitur, toplamTur: Integer;
  suan, ref, s, sure1, sure2, hw: Integer;
  gk, wtid, wyon, wmod: string;
  mk: array[1..11] of record
    gorev, sicil, adi, run, dizi, hat: string;
    hareket, tur: Integer;
    cikar, disi, kontrol: string;
  end;
  arr, crow: TJSONArray;
  o, r: TJSONObject;
  jd: TJSONData;
  manevStr, hv, dtAd, dtHafta, dtYaz, hgrup, hbas: string;
  aks, ms1, ms2: Integer;
  mno, tmpSicil, tmpAdi, numStr, ilkNo, parca: string;
  aksab: Integer;
  rosArr: array of string;
  mArr, aArr: TJSONArray;
  msgArr, lArr: TJSONArray;
  rr: TJSONObject;
  gi: Integer;
  gunFark, gi2, gidx: Integer;
  sabahMi, aksamMi: Boolean;
  ug, uk: TStringList;

  function KaynakTablo(const Kaynak, Id: string): TJSONArray;
  var
    a: TJSONArray;
    j: Integer;
    rr: TJSONObject;
    jd: TJSONData;
    out_: TJSONArray;
    no: TJSONObject;
    function Alan(x: TJSONObject; f: string): string;
    var d: TJSONData; begin
      Result := '';
      d := x.Find(f);
      if d <> nil then Result := d.AsString;
    end;
  begin
    out_ := TJSONArray.Create;
    a := TabloArr(H, Kaynak);
    if a <> nil then
      for j := 0 to a.Count - 1 do
      begin
        jd := a.Items[j];
        if (jd = nil) or (jd.JSONType <> jtObject) then Continue;
        rr := TJSONObject(jd);
        if (Alan(rr, 'TTID') = Id) and (Alan(rr, 'SILINMIS') = '0') then
        begin
          no := TJSONObject.Create;
          no.Add('gorev', Alan(rr, 'NUMARA'));
          no.Add('saat', Alan(rr, 'SAAT'));
          no.Add('run', Alan(rr, 'RUN'));
          no.Add('dizi', Alan(rr, 'DIZI'));
          no.Add('hat', Alan(rr, 'HATID'));
          no.Add('cikar', Alan(rr, 'ARACCIKAR'));
          no.Add('disi', Alan(rr, 'ARACSDISI'));
          no.Add('kontrol', Alan(rr, 'ARACKONTROL'));
          out_.Add(no);
        end;
      end;
    Result := out_;
  end;

  function AracSaatleri(girisMi, yonBir: Boolean): TStringList;
  var
    a: TJSONArray;
    j: Integer;
    rr: TJSONObject;
  begin
    Result := TStringList.Create;
    a := TabloArr(H, 'ARACGRSLISTESI');
    if a = nil then Exit;
    for j := 0 to a.Count - 1 do
    begin
      if (a.Items[j] = nil) or (a.Items[j].JSONType <> jtObject) then Continue;
      rr := TJSONObject(a.Items[j]);
      if (JAlan(rr, 'TTID') <> wtid) or (JAlan(rr, 'SILINMIS') <> '0') then Continue;
      if ((JAlan(rr, 'GIRISMI') = '1') = girisMi) and
        ((JAlan(rr, 'HANGIYON') = '1') = yonBir) then
        Result.Add(JAlan(rr, 'SAAT'));
    end;
  end;

  function SaatteVar(list: TStringList; hareket: Integer): Boolean;
  var
    j, v: Integer;
  begin
    Result := False;
    for j := 0 to list.Count - 1 do
    begin
      v := SureCevir(list[j]);
      if (v = hareket) or (v + 86400 = hareket) then Exit(True);
    end;
  end;

  function CizelgeBul(const GorevNo: string; out Sicil, Adi: string): Boolean;
  var
    a: TJSONArray;
    j: Integer;
    rr: TJSONObject;
    d: TJSONData;
  begin
    Result := False; Sicil := '0'; Adi := '';
    a := TabloArr(H, 'CIZELGE');
    if a = nil then Exit;
    for j := 0 to a.Count - 1 do
    begin
      d := a.Items[j];
      if (d = nil) or (d.JSONType <> jtObject) then Continue;
      rr := TJSONObject(d);
      if rr.Find('SILINMIS') <> nil then
        if rr.Find('SILINMIS').AsString <> '0' then Continue;
      d := rr.Find(gk);
      if (d <> nil) and (GorevNorm(d.AsString) = GorevNorm(GorevNo)) then
      begin
        if rr.Find('SICIL') <> nil then Sicil := rr.Find('SICIL').AsString;
        if rr.Find('ADI') <> nil then Adi := rr.Find('ADI').AsString;
        Result := True;
        Exit;
      end;
    end;
  end;

begin
  Result := TJSONObject.Create;
  gk := Gun; wtid := TTId; wyon := Yon; wmod := LowerCase(AMod);
  if gk = '' then gk := GunKolon;
  if wtid = '' then wtid := TTIdSec(H);
  if wyon = '' then wyon := AyarOku(H, 'YON');
  if wyon = '' then wyon := '0';
  suan := SureCevir(SuanStr);
  if SuanStr = '' then
    suan := HourOf(Now) * 3600 + MinuteOf(Now) * 60 + SecondOf(Now);
  { mod belirtilmediyse server AYARLAR'i gecerli (admin komutlari aninda yansir) }
  if (wmod = '') or (wmod = 'auto') then
  begin
    if AyarOku(H, 'NUMARALI') = 'True' then wmod := 'numarali' else wmod := 'sirali';
  end
  else if (wmod <> 'sirali') then wmod := 'numarali';

  src := KaynakTablo('TIMETABLE', wtid);
  srcC := KaynakTablo('TIMETABLECEK', wtid);
  try
    if wyon = '0' then
    begin
      // ttableli=TIMETABLE, C=TIMETABLECEK (Pascal ile ayni)
    end;
    // yon=1 ise kaynaklari degistir
    if wyon <> '0' then
    begin
      arr := src; src := srcC; srcC := arr;
    end;
    n := src.Count;
    SetLength(tt, n);
    for i := 0 to n - 1 do
    begin
      r := TJSONObject(src.Items[i]);
      tt[i].gorev := r.Get('gorev', '');
      tt[i].saat := r.Get('saat', '');
      tt[i].run := r.Get('run', '');
      tt[i].dizi := r.Get('dizi', '');
      tt[i].hat := r.Get('hat', '');
      tt[i].cikar := r.Get('cikar', '');
      tt[i].disi := r.Get('disi', '');
      tt[i].kontrol := r.Get('kontrol', '');
    end;
    SetLength(ttC, srcC.Count);
    for i := 0 to srcC.Count - 1 do
    begin
      r := TJSONObject(srcC.Items[i]);
      ttC[i].gorev := r.Get('gorev', '');
      ttC[i].saat := r.Get('saat', '');
      ttC[i].run := r.Get('run', '');
      ttC[i].dizi := r.Get('dizi', '');
      ttC[i].hat := r.Get('hat', '');
      ttC[i].cikar := r.Get('cikar', '');
      ttC[i].disi := r.Get('disi', '');
      ttC[i].kontrol := r.Get('kontrol', '');
    end;
  finally
    src.Free;
    srcC.Free;
  end;

  for k := 1 to 11 do
  begin
    mk[k].gorev := '0'; mk[k].sicil := '0'; mk[k].adi := '';
    mk[k].run := '0'; mk[k].dizi := '4'; mk[k].hat := 'X--X';
    mk[k].hareket := 0; mk[k].tur := 0;
    mk[k].cikar := '0'; mk[k].disi := '0'; mk[k].kontrol := '0';
  end;

  // arac listeleri (satir bayragi yoksa yedek: exe ile ayni saat eslemesi)
  ug := AracSaatleri(True, True);
  uk := AracSaatleri(False, True);
  try

  // Hangitur: suan'a esit/buyuk ilk sefer (gece +86400 toleransi)
  hangitur := 0;
  if suan < 18000 then ref := suan + 86400 else ref := suan;
  for i := 0 to n - 1 do
  begin
    s := SureCevir(tt[i].saat);
    if s < 14400 then s := s + 86400;
    if ref <= s then begin hangitur := i; Break; end;
    if i = n - 1 then hangitur := n - 1;
  end;

  if wmod = 'numarali' then
  begin
    for k := 1 to 11 do
    begin
      idx := hangitur + (k - 1);
      if idx < n then
      begin
        s := SureCevir(tt[idx].saat);
        if s < 14400 then s := s + 86400;
        mk[k].hareket := s;
        mk[k].run := tt[idx].run;
        mk[k].dizi := tt[idx].dizi;
        mk[k].hat := tt[idx].hat;
        mk[k].cikar := tt[idx].cikar;
        mk[k].disi := tt[idx].disi;
        mk[k].kontrol := tt[idx].kontrol;
        if (mk[k].cikar <> '1') and SaatteVar(ug, s) then mk[k].cikar := '1';
        if (mk[k].disi <> '1') and SaatteVar(uk, s) then mk[k].disi := '1';
        if CizelgeBul(tt[idx].gorev, mk[k].sicil, mk[k].adi) then
          mk[k].gorev := tt[idx].gorev
        else
        begin
          mk[k].adi := 'SMAMP BULUNAMADI..';
          mk[k].gorev := '0';
        end;
      end;
    end;
    for k := 1 to 3 do
      for i := hangitur downto 0 do
        if (mk[k].gorev <> '0') and (mk[k].gorev <> '') and (tt[i].gorev = mk[k].gorev) then
          Inc(mk[k].tur);
  end
  else
  begin
    for k := 1 to 11 do
    begin
      idx := hangitur + (k - 1);
      if idx < n then
      begin
        s := SureCevir(tt[idx].saat);
        if s < 14400 then s := s + 86400;
        mk[k].hareket := s;
        mk[k].gorev := tt[idx].gorev;
        mk[k].run := tt[idx].run;
        mk[k].dizi := tt[idx].dizi;
        mk[k].hat := tt[idx].hat;
        mk[k].cikar := tt[idx].cikar;
        mk[k].disi := tt[idx].disi;
        mk[k].kontrol := tt[idx].kontrol;
        if (mk[k].cikar <> '1') and SaatteVar(ug, s) then mk[k].cikar := '1';
        if (mk[k].disi <> '1') and SaatteVar(uk, s) then mk[k].disi := '1';
      end;
    end;
  end
  finally
    ug.Free;
    uk.Free;
  end;

  // headway + trensayisi (Pascal ile ayni formul)
  if hangitur + 1 >= n then
  begin
    hw := 0;
  end
  else
  begin
    if hangitur = 0 then
    begin
      sure1 := SureCevir(tt[hangitur].saat);
      sure2 := SureCevir(tt[hangitur + 1].saat);
    end
    else
    begin
      sure1 := SureCevir(tt[hangitur - 1].saat);
      sure2 := SureCevir(tt[hangitur].saat);
    end;
    if (sure1 > 0) and (sure1 < 14400) then sure1 := sure1 + 86400;
    hw := sure2 - sure1;
    if hw <= 0 then hw := 1;
  end;
  toplamTur := StrToIntDef(AyarOku(H, 'TOPLAMTURSURESI'), 4800);
  if toplamTur <= 0 then toplamTur := 4800;

  { --- sag panel verileri (anasayfa.pas yenidenyaz ile ayni kaynaklar) --- }
  aks := SureCevir(AyarOku(H, 'AKSAMBASLAMASAATI'));
  if (aks > 0) and (suan >= aks) then hv := 'AKŞAM' else hv := 'SABAH';

  dtAd := ''; dtHafta := ''; dtYaz := '';
  aArr := TabloArr(H, 'TTDETAY');
  if aArr <> nil then
    for i := 0 to aArr.Count - 1 do
    begin
      jd := aArr.Items[i];
      if (jd <> nil) and (jd.JSONType = jtObject) and
        (JAlan(TJSONObject(jd), 'ID') = wtid) then
      begin
        dtAd := JAlan(TJSONObject(jd), 'ADI');
        dtHafta := JAlan(TJSONObject(jd), 'HAFTAICISONU');
        dtYaz := JAlan(TJSONObject(jd), 'YAZKIS');
        Break;
      end;
    end;

  manevStr := 'MANEVRACI YOK';
  mArr := TabloArr(H, 'MANEVRA');
  if mArr <> nil then
    for i := 0 to mArr.Count - 1 do
    begin
      jd := mArr.Items[i];
      if (jd = nil) or (jd.JSONType <> jtObject) then Continue;
      rr := TJSONObject(jd);
      if (JAlan(rr, 'TTID') <> wtid) or (JAlan(rr, 'SILINMIS') <> '0') then Continue;
      mno := JAlan(rr, 'GOREVNO');
      ms1 := SureCevir(JAlan(rr, 'BASLANGICSAATI'));
      ms2 := SureCevir(JAlan(rr, 'BITISSAATI'));
      if (ms1 <= suan) and (suan <= ms2) then
        if CizelgeBul(mno, tmpSicil, tmpAdi) and (tmpAdi <> '') then
        begin
          manevStr := Trim(mno + ' ' + UpperCase(tmpAdi));
          Break;
        end;
    end;

  { grup + basmakinist: onurmakinist.pas SiralamaYap ile ayni mantik.
    Kadro = gunun filtreli listesi (dosya sirasi); dilim = haftanin gunune gore;
    secim deterministik (exe'deki rastgele secimin ilk adayi). }
  hgrup := ''; hbas := '';
  SetLength(rosArr, 0);
  aArr := TabloArr(H, 'CIZELGE');
  if aArr <> nil then
    for i := 0 to aArr.Count - 1 do
    begin
      jd := aArr.Items[i];
      if (jd = nil) or (jd.JSONType <> jtObject) then Continue;
      rr := TJSONObject(jd);
      if JAlan(rr, 'SILINMIS') <> '0' then Continue;
      if JAlan(rr, gk) = '' then Continue;
      SetLength(rosArr, Length(rosArr) + 1);
      rosArr[High(rosArr)] := GorevNorm(JAlan(rr, gk));
    end;
  if AyarOku(H, 'TARIFEOROMANUEL') = 'True' then
    aksab := DayOfTheWeek(Now) - 5
  else
  begin
    if dtHafta = 'CUMARTESİ' then aksab := 1
    else if dtHafta = 'PAZAR' then aksab := 2
    else aksab := -1;
  end;
  if hv = 'AKŞAM' then numStr := AyarOku(H, 'AKSAMNUMARALARI')
  else numStr := AyarOku(H, 'SABAHNUMARALARI');
  parca := ParcaAl(numStr, aksab);
  ilkNo := Trim(parca);
  if Pos('-', ilkNo) > 0 then ilkNo := Trim(Copy(ilkNo, 1, Pos('-', ilkNo) - 1));
  { 12 gunluk vardiya dongusu: [4 sabah, 2 izin, 4 aksam, 2 izin].
    Referans: 27.09.2026 = 1. Grup'un aksam 2. gunu (dongu idx 7).
    Gruplar 4'er gun faz farkli. Kadro sirasindan bagimsiz (tarih matematigi). }
  gunFark := Trunc(Now) - Trunc(EncodeDate(2026, 9, 27));
  for gi2 := 1 to 3 do
  begin
    gidx := ((7 + gunFark - (gi2 - 1) * 4) mod 12 + 12) mod 12;
    sabahMi := (gidx >= 0) and (gidx <= 3);
    aksamMi := (gidx >= 6) and (gidx <= 9);
    if ((hv = 'AKŞAM') and aksamMi) or ((hv = 'SABAH') and sabahMi) then
    begin
      hgrup := IntToStr(gi2) + '. GRUP';
      case gi2 of
        1: hbas := AyarOku(H, 'BASMAKINIST1');
        2: hbas := AyarOku(H, 'BASMAKINIST2');
      else hbas := AyarOku(H, 'BASMAKINIST3');
      end;
      Break;
    end;
  end;
  if hgrup = '' then
  begin
    { yedek: eski kadro-sirasi yontemi }
    gi := -1;
    if ilkNo <> '' then
      for i := 0 to High(rosArr) do
        if rosArr[i] = ilkNo then begin gi := i; Break; end;
    if gi >= 0 then
    begin
      if GermAralik(AyarOku(H, 'GRUP1'), gi) then
      begin hgrup := '1. GRUP'; hbas := AyarOku(H, 'BASMAKINIST1'); end
      else if GermAralik(AyarOku(H, 'GRUP2'), gi) then
      begin hgrup := '2. GRUP'; hbas := AyarOku(H, 'BASMAKINIST2'); end
      else if GermAralik(AyarOku(H, 'GRUP3'), gi) then
      begin hgrup := '3. GRUP'; hbas := AyarOku(H, 'BASMAKINIST3'); end;
    end;
  end;

  Result.Add('ttid', wtid);
  Result.Add('gun', gk);
  Result.Add('suan', SureYaz(suan));
  Result.Add('yon', wyon);
  Result.Add('mod', wmod);
  Result.Add('hangitur', hangitur);
  Result.Add('seferSayisi', n);
  Result.Add('sonsefer', (n > 0) and (hangitur >= n - 1));
  if hw = 0 then Result.Add('headway', '00:00:00')
  else Result.Add('headway', SureYaz(hw));
  if hw = 0 then Result.Add('trensayisi', '0')
  else Result.Add('trensayisi', IntToStr(Round(toplamTur / hw)));
  Result.Add('toplamtursuresi', toplamTur);
  Result.Add('seflik', AyarOku(H, 'SEFLIK'));
  Result.Add('manevraci', manevStr);
  Result.Add('hv', hv);
  Result.Add('hgrup', hgrup);
  Result.Add('basmakinist', hbas);
  o := TJSONObject.Create;
  o.Add('adi', dtAd);
  o.Add('hafta', dtHafta);
  o.Add('yazkis', dtYaz);
  Result.Add('ttdetay', o);

  { makinist mesajlari + arac giris/cikis listeleri }
  msgArr := TJSONArray.Create;
  aArr := TabloArr(H, 'MAKINISTEMESAJ');
  if aArr <> nil then
    for i := 0 to aArr.Count - 1 do
    begin
      jd := aArr.Items[i];
      if (jd <> nil) and (jd.JSONType = jtObject) and
        (JAlan(TJSONObject(jd), 'SILINMIS') = '0') and
        MesajAktif(TJSONObject(jd), suan) then
        msgArr.Add(JAlan(TJSONObject(jd), 'MESAJ'));
    end;
  Result.Add('mesajlar', msgArr);

  for gi := 0 to 3 do
  begin
    lArr := TJSONArray.Create;
    aArr := TabloArr(H, 'ARACGRSLISTESI');
    if aArr <> nil then
      for i := 0 to aArr.Count - 1 do
      begin
        jd := aArr.Items[i];
        if (jd = nil) or (jd.JSONType <> jtObject) then Continue;
        rr := TJSONObject(jd);
        if (JAlan(rr, 'TTID') <> wtid) or (JAlan(rr, 'SILINMIS') <> '0') then Continue;
        case gi of
          0: if (JAlan(rr, 'GIRISMI') = '1') and (JAlan(rr, 'HANGIYON') = '1') then
               lArr.Add(JAlan(rr, 'SAAT'));
          1: if (JAlan(rr, 'GIRISMI') <> '1') and (JAlan(rr, 'HANGIYON') = '1') then
               lArr.Add(JAlan(rr, 'SAAT'));
          2: if (JAlan(rr, 'GIRISMI') = '1') and (JAlan(rr, 'HANGIYON') <> '1') then
               lArr.Add(JAlan(rr, 'SAAT'));
          3: if (JAlan(rr, 'GIRISMI') <> '1') and (JAlan(rr, 'HANGIYON') <> '1') then
               lArr.Add(JAlan(rr, 'SAAT'));
        end;
      end;
    case gi of
      0: Result.Add('uskgiris', lArr);
      1: Result.Add('uskcikis', lArr);
      2: Result.Add('cekgiris', lArr);
      3: Result.Add('cekcikis', lArr);
    end;
  end;

  crow := TJSONArray.Create;
  for k := 1 to 11 do
  begin
    if mk[k].hareket = 0 then Continue;
    o := TJSONObject.Create;
    o.Add('no', k);
    o.Add('gorev', mk[k].gorev);
    o.Add('sicil', mk[k].sicil);
    o.Add('adi', mk[k].adi);
    o.Add('run', mk[k].run);
    o.Add('dizi', mk[k].dizi);
    o.Add('hat', mk[k].hat);
    if mk[k].hareket > 86400 then
      o.Add('hareket', SureYaz(mk[k].hareket - 86400))
    else
      o.Add('hareket', SureYaz(mk[k].hareket));
    o.Add('tur', mk[k].tur);
    o.Add('cikar', mk[k].cikar);
    o.Add('disi', mk[k].disi);
    o.Add('kontrol', mk[k].kontrol);
    crow.Add(o);
  end;
  Result.Add('makinist', crow);
end;

function TWebSrv.MimeTip(const FN: string): string;
var
  e: string;
begin
  e := LowerCase(ExtractFileExt(FN));
  if e = '.html' then Result := 'text/html; charset=utf-8'
  else if e = '.json' then Result := 'application/json; charset=utf-8'
  else if e = '.js' then Result := 'application/javascript; charset=utf-8'
  else if e = '.css' then Result := 'text/css; charset=utf-8'
  else if e = '.png' then Result := 'image/png'
  else if e = '.gif' then Result := 'image/gif'
  else if e = '.jpg' then Result := 'image/jpeg'
  else if (e = '.ttf') or (e = '.woff') or (e = '.woff2') then Result := 'font/ttf'
  else Result := 'application/octet-stream';
end;

procedure TWebSrv.StatikSun(const Yol: string; var AResp: TFPHTTPConnectionResponse);
var
  fp: string;
  fs: TFileStream;
begin
  fp := ExpandFileName(IncludeTrailingPathDelimiter(FWebDir) + Yol);
  // path traversal korumasi
  if Pos(ExpandFileName(FWebDir), fp) <> 1 then
  begin
    AResp.Code := 403;
    AResp.Content := 'forbidden';
    Exit;
  end;
  if DirectoryExists(fp) then
    fp := IncludeTrailingPathDelimiter(fp) + 'pano.html';
  if not FileExists(fp) then
  begin
    AResp.Code := 404;
    AResp.Content := 'bulunamadi';
    Exit;
  end;
  AResp.ContentType := MimeTip(fp);
  fs := TFileStream.Create(fp, fmOpenRead or fmShareDenyNone);
  AResp.ContentStream := fs;
  AResp.ContentLength := fs.Size;
  AResp.FreeContentStream := True;
end;

function TWebSrv.KomutIsle(H: THatStore; const Komut: string): string;
var
  k: string;
begin
  Result := '(bilinmeyen komut, islem yok)';
  k := LowerCase(Trim(Komut));
  if k = 'sirali' then
  begin
    AyarYaz(H, 'NUMARALI', 'False');
    Kaydet(H);
    Result := '(numarali -> sirali)';
  end
  else if k = 'numarali' then
  begin
    AyarYaz(H, 'NUMARALI', 'True');
    Kaydet(H);
    Result := '(sirali -> numarali)';
  end
  else if k = 'flash' then
  begin AyarYaz(H, 'FLASHYAPSIN', 'True'); Kaydet(H); Result := '(flash acik)'; end
  else if k = 'flashi' then
  begin AyarYaz(H, 'FLASHYAPSIN', 'False'); Kaydet(H); Result := '(flash kapali)'; end
  else if k = 'kayanyazi' then
  begin AyarYaz(H, 'YAZIKAYSIN', 'True'); Kaydet(H); Result := '(kayan yazi acik)'; end
  else if k = 'kayanyazii' then
  begin AyarYaz(H, 'YAZIKAYSIN', 'False'); Kaydet(H); Result := '(kayan yazi kapali)'; end
  else if k = 'mesaj' then Result := '(mesajlar her yoklamada canli okunuyor)'
  else if (k = 'reset') or (k = 'yenidenyaz') then
    Result := '(pano her yoklamada zaten yeniden hesaplaniyor)'
  else if k = 'vakum' then
  begin Kaydet(H); Result := '(kaydedildi)'; end
  else if k = 'versiyon' then Result := '(server ' + SRV_VERSIYON + ')';
end;

procedure TWebSrv.Istek(Sender: TObject; var ARequest: TFPHTTPConnectionRequest;
  var AResponse: TFPHTTPConnectionResponse);
var
  yol, yol0, q, adi, ttid, gun, suan, yon, amod, sicil, b64, hatQ: string;
  tumu: Boolean;
  ltok, lpw, lokHat: string;
  glst: TStringList;
  gi2, gsay: Integer;
  lay, gfyol: string;
  ydDir, ydAd, ydTam, ydOnceki, ydYeni: string;
  updYol: string;
  ydSr: TSearchRec;
  ydArr: TJSONArray;
  ydObj: TJSONObject;
  yfs, yfo: TFileStream;
  gjo: TJSONObject;
  gja: TJSONArray;
  arr, yeni: TJSONArray;
  jd: TJSONData;
  fd: TJSONData;
  i, ek, gu, k: Integer;
  rid, fnam: string;
  o: TJSONObject;
  opts: string;
  oi: Integer;
  hedef: TJSONObject;
  fs: TFileStream;
  ms: TMemoryStream;
  raw: RawByteString;
  H: THatStore;
  jdG: TJSONData;
  girSifre: string;
  hs: string;
begin
  AResponse.SetCustomHeader('Access-Control-Allow-Origin', '*');
  AResponse.SetCustomHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  AResponse.SetCustomHeader('Access-Control-Allow-Headers', 'Content-Type');
  if CompareText(ARequest.Method, 'OPTIONS') = 0 then
  begin
    AResponse.Code := 204;
    AResponse.Content := '';
    Exit;
  end;
  yol := TemizYol(ARequest.URI);
  q := Trim(ARequest.QueryString);
  if yol = '' then yol := '/';
  yol0 := yol;
  // yonetim giris kapisi: hat bazli, sifreler data/sifreler.json'da sabit
  // alaninda (sabit). Bos ise o hat aciktir; ilk girilen sifre kaydedilir.
  if (yol = '/api/giris') or (yol = '/api/cikis') then
  begin
    if CompareText(ARequest.Method, 'POST') <> 0 then
    begin
      AResponse.Code := 405;
      AResponse.Content := '';
      Exit;
    end;
    try
      jdG := GetJSON(ARequest.Content);
    except
      jdG := nil;
    end;
    if yol = '/api/cikis' then
    begin
      if (jdG <> nil) and (jdG.JSONType = jtObject) then
        OturumKapat(JAlan(TJSONObject(jdG), 'oturma'));
      jdG.Free;
      AResponse.Content := 'OK';
      Exit;
    end;
  end;
  // /api/islemgunlugu?hat=H|TUMU&oturma=&sifre=&n=&ay=YYYY-MM (TUMU sadece yonetici)
  if yol = '/api/islemgunlugu' then
  begin
      tumu := UpperCase(Trim(QParam(q, 'hat'))) = 'TUMU';
      ltok := QParam(q, 'oturma'); lpw := QParam(q, 'sifre');
      gsay := StrToIntDef(QParam(q, 'n'), 300);
      if gsay < 1 then gsay := 1;
      if gsay > 1000 then gsay := 1000;
      lokHat := '';
      if tumu then
      begin
        if not OturumYonetici(ltok) then
        begin
          AResponse.Code := 403;
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := '{"hata":"sadece yonetici"}';
          Exit;
        end;
      end
      else
      begin
        H := HatBul(QParam(q, 'hat'));
        if H = nil then
        begin
          AResponse.Code := 404;
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := '{"hata":"hat yok"}';
          Exit;
        end;
        if not (OturumGecerli(H.Hat, ltok) or
          SifreTutuyor(HatSifresi(H.Hat), lpw) or OturumYonetici(ltok)) then
        begin
          AResponse.Code := 403;
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := '{"hata":"sifre gerekli"}';
          Exit;
        end;
        lokHat := UpperCase(Trim(H.Hat));
      end;
      lay := QParam(q, 'ay');
      gfyol := GunlukDosya(lay);
      gja := TJSONArray.Create;
      try
        if (gfyol <> '') and FileExists(gfyol) then
        begin
          glst := TStringList.Create;
          try
            glst.LoadFromFile(gfyol);
            gi2 := glst.Count - 1;
            while (gi2 >= 0) and (gja.Count < gsay) do
            begin
              try
                gjo := TJSONObject(GetJSON(glst[gi2]));
              except
                gjo := nil;
              end;
              if gjo <> nil then
              begin
                if (lokHat = '') or (UpperCase(JAlan(gjo, 'hat')) = lokHat) then
                  gja.Add(gjo.Clone)
                else
                  gjo.Free;
              end;
              Dec(gi2);
            end;
          finally
            glst.Free;
          end;
        end;
        AResponse.ContentType := 'application/json; charset=utf-8';
        AResponse.Content := gja.AsJSON;
      finally
        gja.Free;
      end;
      Exit;
    end;
  // /api/giris?hat=H
  if yol = '/api/giris' then
  begin
    H := HatBul(QParam(q, 'hat'));
    if H = nil then
    begin
      jdG.Free;
      AResponse.Code := 404;
      AResponse.ContentType := 'application/json; charset=utf-8';
      AResponse.Content := '{"hata":"hat yok","hatlar":' + HatListesiJson + '}';
      Exit;
    end;
    girSifre := '';
    if (jdG <> nil) and (jdG.JSONType = jtObject) then
      girSifre := JAlan(TJSONObject(jdG), 'sifre');
    jdG.Free;
    EnterCriticalSection(FKilit);
    try
      hs := HatSifresi(H.Hat);
      if hs = '' then
      begin
        // bu hatta sifre yok: giris acik, dogrudan oturum
        AResponse.ContentType := 'application/json; charset=utf-8';
        AResponse.Content := '{"oturma":"' + OturumAc(H.Hat) + '","acik":"1"}';
        Exit;
      end;
    finally
      LeaveCriticalSection(FKilit);
    end;
    if SifreTutuyor(HatSifresi('ADMIN'), girSifre) then
    begin
      { super kullanici: tum hatlarda gecerli oturum }
      AResponse.ContentType := 'application/json; charset=utf-8';
      AResponse.Content := '{"oturma":"' + OturumAc('*') + '","yonetici":"1"}';
    end
    else if SifreTutuyor(hs, girSifre) then
    begin
      AResponse.ContentType := 'application/json; charset=utf-8';
      AResponse.Content := '{"oturma":"' + OturumAc(H.Hat) + '"}';
    end
    else
    begin
      WriteLn(FormatDateTime('hh:nn:ss', Now) + ' HATALI YONETIM GIRISI (' + H.Hat + ').');
      AResponse.Code := 403;
      AResponse.ContentType := 'application/json; charset=utf-8';
      AResponse.Content := '{"hata":"sifre yanlis"}';
    end;
    Exit;
  end;
  if yol = '/yonetim.html' then
  begin
    H := HatBul(QParam(q, 'hat'));
    if (H <> nil) and (HatSifresi(H.Hat) <> '') and
      not OturumGecerli(H.Hat, QParam(q, 'oturma')) then
    begin
      opts := '';
      for oi := 0 to FHatlar.Count - 1 do
        if FHatlar[oi] = H.Hat then
          opts := opts + '<option value="' + FHatlar[oi] + '" selected>' +
            FHatlar[oi] + '</option>'
        else
          opts := opts + '<option value="' + FHatlar[oi] + '">' +
            FHatlar[oi] + '</option>';
      AResponse.Code := 401;
      AResponse.ContentType := 'text/html; charset=utf-8';
      AResponse.Content := GirisSayfasi(ARequest.URI,
        'Devam etmek icin hat secip giris yapin.', H.Hat, opts);
      Exit;
    end;
  end;
  // hat cozumu: statik dosya disindaki tum yollar hatta baglanir
  // (/api/hat ve /api/hatlar muaf: henuz var olmayan hat icin de calisir)
  H := nil;
  hatQ := '';
  if (yol <> '/') and (Copy(yol, 1, 4) <> '/bg/') and (Copy(yol, 1, 7) <> '/fonts/') and
    (Copy(yol, 1, 5) <> '/lib/') and (Pos('.', yol) = 0) and
    (yol <> '/api/hat') and (yol <> '/api/hatlar') then
  begin
    hatQ := QParam(q, 'hat');
    H := HatBul(hatQ);
    if H = nil then
    begin
      AResponse.Code := 404;
      AResponse.ContentType := 'application/json; charset=utf-8';
      AResponse.Content := '{"hata":"hat yok:' + hatQ + '","hatlar":' + HatListesiJson + '}';
      Exit;
    end;
    GerekirseYenidenYukle(H);
    // yazma korumasi: hatta sifre varsa POST/PUT/DELETE sifresiz calismaz
    // (sifre data/sifreler.json; yoksa herkes yazabilir)
    if (CompareText(ARequest.Method, 'POST') = 0) or
      (CompareText(ARequest.Method, 'PUT') = 0) or
      (CompareText(ARequest.Method, 'DELETE') = 0) then
    begin
      if (HatSifresi(H.Hat) <> '') and
        not SifreTutuyor(HatSifresi(H.Hat), QParam(q, 'sifre')) and
        not SifreTutuyor(HatSifresi('ADMIN'), QParam(q, 'sifre')) and
        not OturumGecerli(H.Hat, QParam(q, 'oturma')) then
      begin
        WriteLn(FormatDateTime('hh:nn:ss', Now) + ' YETKISIZ YAZMA DENEMESI (' +
          H.Hat + ' ' + yol + ')');
        AResponse.Code := 403;
        AResponse.ContentType := 'application/json; charset=utf-8';
        AResponse.Content := '{"hata":"sifre gerekli"}';
        Exit;
      end;
    end;
  end
  else
  begin
    // hat parametresi yoksa varsayilan hati kullan
    if FHatlar.Count = 0 then
    begin
      AResponse.Code := 500;
      AResponse.Content := 'hat deposu yok';
      Exit;
    end
    else
      H := THatStore(FHatlar.Objects[0]);
    GerekirseYenidenYukle(H);
  end;
  try
    EnterCriticalSection(FKilit);
    try
      if yol = '/' then
      begin
        AResponse.Code := 302;
        AResponse.SetCustomHeader('Location', '/pano.html');
        AResponse.Content := '';
      end
      else if yol = '/api/durum' then
      begin
        o := TJSONObject.Create;
        try
          o.Add('versiyon', 'mtakipwebsrv-' + SRV_VERSIYON);
          o.Add('zaman', FormatDateTime('hh:nn:ss', Now));
          o.Add('tarih', FormatDateTime('dd.mm.yyyy', Now));
          o.Add('seflik', AyarOku(H, 'SEFLIK'));
          o.Add('otomatikTarife', AyarOku(H, 'TARIFEOROMANUEL'));
          o.Add('onerilenTTID', TTIdSec(H));
          o.Add('gunKolon', GunKolon);
          o.Add('hat', H.Hat);
          o.Add('korumali', HatSifresi(H.Hat) <> '');
          jd := GetJSON(HatListesiJson);
          o.Add('hatlar', jd);
          arr := TJSONArray.Create;
          arr.Add(TabloSay(H, 'CIZELGE') > 0);
          o.Add('tablolar', TJSONObject.Create);
          TJSONObject(o.Find('tablolar')).Add('CIZELGE', TabloSay(H, 'CIZELGE'));
          TJSONObject(o.Find('tablolar')).Add('TIMETABLE', TabloSay(H, 'TIMETABLE'));
          TJSONObject(o.Find('tablolar')).Add('TIMETABLECEK', TabloSay(H, 'TIMETABLECEK'));
          TJSONObject(o.Find('tablolar')).Add('TTDETAY', TabloSay(H, 'TTDETAY'));
          arr.Free;
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := o.AsJSON;
        finally
          o.Free;
        end;
      end
      else if yol = '/api/yukle' then
      begin
        // veriaktar vb. dis arac dosya yazdiysa bellege zorla al
        if not FileExists(H.Dosya) then
        begin
          AResponse.Code := 404;
          AResponse.Content := 'veri dosyasi yok';
        end
        else
        begin
          H.Veri.Free;
          H.Veri := nil;
          Yukle(H);
          WriteLn(FormatDateTime('hh:nn:ss', Now) +
            ' BILGI: /api/yukle ile yeniden yuklendi.');
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := '{"sonuc":"OK","cizelge":' +
            IntToStr(TabloSay(H, 'CIZELGE')) + '}';
        end;
      end
      else if yol = '/api/ayarlar' then
      begin
        if CompareText(ARequest.Method, 'POST') = 0 then
        begin
          // ayarlari birlestir + kaydet (pano bir sonraki yoklamada gorur)
          try
            jd := GetJSON(ARequest.Content);
          except
            jd := nil;
          end;
          if (jd <> nil) and (jd.JSONType = jtObject) then
          begin
            o := TJSONObject(H.Veri.Find('AYARLAR'));
            if o = nil then
            begin
              o := TJSONObject.Create;
              H.Veri.Add('AYARLAR', o);
            end;
            for i := 0 to TJSONObject(jd).Count - 1 do
              AyarYaz(H, TJSONObject(jd).Names[i],
                TJSONObject(jd).Items[i].AsString);
            jd.Free;
            Kaydet(H);
            WriteLn(FormatDateTime('hh:nn:ss', Now) + ' AYAR KAYDET');
            AResponse.Content := 'OK(ayarlar kaydedildi)';
          end
          else
          begin
            jd.Free;
            AResponse.Code := 400;
            AResponse.Content := 'obje bekleniyor';
          end;
        end
        else
        begin
          AResponse.ContentType := 'application/json; charset=utf-8';
          jd := H.Veri.Find('AYARLAR');
          if jd <> nil then AResponse.Content := jd.AsJSON
          else AResponse.Content := '{}';
        end;
      end
      else if yol = '/api/hatlar' then
      begin
        AResponse.ContentType := 'application/json; charset=utf-8';
        AResponse.Content := HatListesiJson;
      end
      else if yol = '/api/tablolar' then
      begin
        AResponse.ContentType := 'application/json; charset=utf-8';
        AResponse.Content := TabloAdlariJson(H);
      end
      else if yol = '/api/yedek-indir' then
      begin
        // yedek dosyasi indir (hat sifresi veya admin)
        H := HatBul(QParam(q, 'hat'));
        if H = nil then
        begin
          AResponse.Code := 404;
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := '{"hata":"hat yok"}';
          Exit;
        end;
        if not (OturumGecerli(H.Hat, QParam(q, 'oturma')) or
          SifreTutuyor(HatSifresi(H.Hat), QParam(q, 'sifre')) or
          OturumYonetici(QParam(q, 'oturma'))) then
        begin
          AResponse.Code := 403;
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := '{"hata":"sifre gerekli"}';
          Exit;
        end;
        ydAd := Trim(QParam(q, 'ad'));
        if not DosyaAdiGuvenli(ydAd, UpperCase(Trim(H.Hat))) then
        begin
          AResponse.Code := 400;
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := '{"hata":"yedek adi hatali"}';
          Exit;
        end;
        ydTam := YedekKlasoru + ydAd;
        if not FileExists(ydTam) then
        begin
          AResponse.Code := 404;
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := '{"hata":"yedek bulunamadi"}';
          Exit;
        end;
        AResponse.ContentType := 'application/octet-stream';
        AResponse.SetCustomHeader('Content-Disposition',
          'attachment; filename="' + ydAd + '"');
        yfs := TFileStream.Create(ydTam, fmOpenRead or fmShareDenyNone);
        AResponse.ContentStream := yfs;
        AResponse.ContentLength := yfs.Size;
        AResponse.FreeContentStream := True;
        Exit;
      end
      else if yol = '/api/yedekler' then
      begin
        // yedek listesi: backup/veri_HAT_*.json (hat sifresi veya admin)
        H := HatBul(QParam(q, 'hat'));
        if H = nil then
        begin
          AResponse.Code := 404;
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := '{"hata":"hat yok"}';
          Exit;
        end;
        if not (OturumGecerli(H.Hat, QParam(q, 'oturma')) or
          SifreTutuyor(HatSifresi(H.Hat), QParam(q, 'sifre')) or
          OturumYonetici(QParam(q, 'oturma'))) then
        begin
          AResponse.Code := 403;
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := '{"hata":"sifre gerekli"}';
          Exit;
        end;
        ydArr := TJSONArray.Create;
        try
          ydDir := YedekKlasoru;
          if FindFirst(ydDir + 'veri_' + UpperCase(Trim(H.Hat)) + '_*.json',
            faAnyFile, ydSr) = 0 then
          begin
            repeat
              ydObj := TJSONObject.Create;
              ydObj.Add('ad', ydSr.Name);
              ydObj.Add('boyut', ydSr.Size);
              ydObj.Add('zaman', FormatDateTime('yyyy-mm-dd hh:nn:ss',
                FileDateToDateTime(ydSr.Time)));
              ydArr.Add(ydObj);
            until FindNext(ydSr) <> 0;
            FindClose(ydSr);
          end;
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := ydArr.AsJSON;
        finally
          ydArr.Free;
        end;
        Exit;
      end
      else if yol = '/api/geri-yukle' then
      begin
        // veri dosyasini secili yedekten geri yukler (sadece yonetici).
        // once mevcut durum ayrica yedeklenir (_onceki).
        if (CompareText(ARequest.Method, 'POST') <> 0) or
          not OturumYonetici(QParam(q, 'oturma')) then
        begin
          AResponse.Code := 403;
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := '{"hata":"sadece yonetici"}';
          Exit;
        end;
        try
          jd := GetJSON(ARequest.Content);
        except
          jd := nil;
        end;
        ydAd := '';
        if (jd <> nil) and (jd.JSONType = jtObject) then
          ydAd := Trim(JAlan(TJSONObject(jd), 'yedek'));
        jd.Free;
        H := HatBul(QParam(q, 'hat'));
        if (H = nil) or (ydAd = '') or
          not DosyaAdiGuvenli(ydAd, UpperCase(Trim(H.Hat))) then
        begin
          AResponse.Code := 400;
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := '{"hata":"hat veya yedek adi hatali"}';
          Exit;
        end;
        ydTam := YedekKlasoru + ydAd;
        if not FileExists(ydTam) then
        begin
          AResponse.Code := 404;
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := '{"hata":"yedek bulunamadi"}';
          Exit;
        end;
        try
          ydOnceki := YedekKlasoru + 'veri_' + UpperCase(Trim(H.Hat)) + '_' +
            FormatDateTime('yyyymmdd_hhnnss', Now) + '_onceki.json';
          yfs := TFileStream.Create(H.Dosya, fmOpenRead or fmShareDenyNone);
          try
            yfo := TFileStream.Create(ydOnceki, fmCreate);
            try
              yfo.CopyFrom(yfs, yfs.Size);
            finally
              yfo.Free;
            end;
          finally
            yfs.Free;
          end;
          yfs := TFileStream.Create(ydTam, fmOpenRead or fmShareDenyNone);
          try
            yfo := TFileStream.Create(H.Dosya, fmCreate);
            try
              yfo.CopyFrom(yfs, yfs.Size);
            finally
              yfo.Free;
            end;
          finally
            yfs.Free;
          end;
          H.FileAge := -1;
          GerekirseYenidenYukle(H);
          AnlikGoruntuYaz(H);
          WriteLn(FormatDateTime('hh:nn:ss', Now) + ' GERI YUKLEME (' +
            H.Hat + ' <- ' + ydAd + ')');
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := 'OK(geri yuklendi:' + ydAd + ')';
        except
          on E: Exception do
          begin
            AResponse.Code := 500;
            AResponse.ContentType := 'application/json; charset=utf-8';
            AResponse.Content := 'hata: ' + E.Message;
          end;
        end;
        Exit;
      end
      else if yol = '/api/admin-sifre' then
      begin
        // super kullanici sifresi degistir (sha1 ozet yazilir)
        if (CompareText(ARequest.Method, 'POST') <> 0) or
          not OturumYonetici(QParam(q, 'oturma')) then
        begin
          AResponse.Code := 403;
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := '{"hata":"sadece yonetici"}';
          Exit;
        end;
        try
          jd := GetJSON(ARequest.Content);
        except
          jd := nil;
        end;
        ydYeni := '';
        if (jd <> nil) and (jd.JSONType = jtObject) then
          ydYeni := Trim(JAlan(TJSONObject(jd), 'yeni'));
        jd.Free;
        if Length(ydYeni) < 6 then
        begin
          AResponse.Code := 400;
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := '{"hata":"en az 6 karakter"}';
          Exit;
        end;
        if SifreDosyasiYaz('ADMIN', 'sha1:' + LowerCase(SHA1Print(SHA1String(
          UTF8Encode('mtakip-admin:' + UnicodeString(ydYeni)))))) then
        begin
          WriteLn(FormatDateTime('hh:nn:ss', Now) + ' ADMIN SIFRE DEGISTI.');
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := 'OK(admin sifre guncellendi)';
        end
        else
        begin
          AResponse.Code := 500;
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := '{"hata":"dosya yazilamadi"}';
        end;
        Exit;
      end
      else if yol = '/api/hat-sifre' then
      begin
        // hat sifresi belirle (sha1 ozet yazilir, en az 6 karakter)
        if (CompareText(ARequest.Method, 'POST') <> 0) or
          not OturumYonetici(QParam(q, 'oturma')) then
        begin
          AResponse.Code := 403;
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := '{"hata":"sadece yonetici"}';
          Exit;
        end;
        try
          jd := GetJSON(ARequest.Content);
        except
          jd := nil;
        end;
        ydAd := '';
        ydYeni := '';
        if (jd <> nil) and (jd.JSONType = jtObject) then
        begin
          ydAd := UpperCase(Trim(JAlan(TJSONObject(jd), 'hat')));
          ydYeni := Trim(JAlan(TJSONObject(jd), 'yeni'));
        end;
        jd.Free;
        if HatBul(ydAd) = nil then
        begin
          AResponse.Code := 400;
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := '{"hata":"hat yok"}';
          Exit;
        end;
        if Length(ydYeni) < 6 then
        begin
          AResponse.Code := 400;
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := '{"hata":"en az 6 karakter"}';
          Exit;
        end;
        if SifreDosyasiYaz(ydAd, 'sha1:' + LowerCase(SHA1Print(SHA1String(
          UTF8Encode('mtakip-admin:' + UnicodeString(ydYeni)))))) then
        begin
          WriteLn(FormatDateTime('hh:nn:ss', Now) + ' HAT SIFRE DEGISTI (' +
            ydAd + ').');
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := 'OK(hat sifre guncellendi:' + ydAd + ')';
        end
        else
        begin
          AResponse.Code := 500;
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := '{"hata":"dosya yazilamadi"}';
        end;
        Exit;
      end
      else if yol = '/api/oturumlar' then
      begin
        // aktif oturumlar (sadece yonetici)
        if not OturumYonetici(QParam(q, 'oturma')) then
        begin
          AResponse.Code := 403;
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := '{"hata":"sadece yonetici"}';
          Exit;
        end;
        ydArr := TJSONArray.Create;
        try
          EnterCriticalSection(FKilit);
          try
            for gi2 := 0 to FOturumlar.Count - 1 do
            begin
              ydObj := TJSONObject.Create;
              ydObj.Add('hat', Copy(FOturumlar[gi2], 1,
                Pos(':', FOturumlar[gi2]) - 1));
              ydObj.Add('token', Copy(FOturumlar[gi2],
                Pos(':', FOturumlar[gi2]) + 1, 999));
              ydArr.Add(ydObj);
            end;
          finally
            LeaveCriticalSection(FKilit);
          end;
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := ydArr.AsJSON;
        finally
          ydArr.Free;
        end;
        Exit;
      end
      else if yol = '/api/oturum-kapat' then
      begin
        // oturum dusur (sadece yonetici)
        if (CompareText(ARequest.Method, 'POST') <> 0) or
          not OturumYonetici(QParam(q, 'oturma')) then
        begin
          AResponse.Code := 403;
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := '{"hata":"sadece yonetici"}';
          Exit;
        end;
        try
          jd := GetJSON(ARequest.Content);
        except
          jd := nil;
        end;
        ydAd := '';
        if (jd <> nil) and (jd.JSONType = jtObject) then
          ydAd := Trim(JAlan(TJSONObject(jd), 'token'));
        jd.Free;
        if ydAd = '' then
        begin
          AResponse.Code := 400;
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := '{"hata":"token gerekli"}';
          Exit;
        end;
        OturumKapat(ydAd);
        WriteLn(FormatDateTime('hh:nn:ss', Now) + ' OTURUM KAPATILDI.');
        AResponse.ContentType := 'application/json; charset=utf-8';
        AResponse.Content := 'OK(oturum kapatildi)';
        Exit;
      end
      else if yol = '/api/guncelle-yukle' then
      begin
        // uzaktan guncelleme 1. adim: yeni exe'yi update klasorune al.
        // watchdog/kiosk baslatmadan once yerine koyar (sadece yonetici).
        if (CompareText(ARequest.Method, 'POST') <> 0) or
          not OturumYonetici(QParam(q, 'oturma')) then
        begin
          AResponse.Code := 403;
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := '{"hata":"sadece yonetici"}';
          Exit;
        end;
        raw := RawByteString(ARequest.Content);
        if (Length(raw) < 100000) or (Copy(raw, 1, 2) <> 'MZ') or
          (Length(raw) > 50 * 1024 * 1024) then
        begin
          AResponse.Code := 400;
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := '{"hata":"gecerli exe gerekli (MZ, 100KB-50MB)"}';
          Exit;
        end;
        updYol := IncludeTrailingPathDelimiter(ExtractFileDir(ParamStr(0))) +
          'update' + PathDelim;
        ForceDirectories(updYol);
        fs := TFileStream.Create(updYol + 'mtakipwebsrv.exe', fmCreate);
        try
          fs.WriteBuffer(Pointer(raw)^, Length(raw));
        finally
          fs.Free;
        end;
        WriteLn(FormatDateTime('hh:nn:ss', Now) + ' GUNCELLEME ALINDI (' +
          IntToStr(Length(raw)) + ' byte).');
        AResponse.ContentType := 'application/json; charset=utf-8';
        AResponse.Content := 'OK(guncelleme hazir, yeniden baslatin)';
        Exit;
      end
      else if yol = '/api/yeniden-baslat' then
      begin
        // uzaktan guncelleme 2. adim: server kendini kapatir,
        // watchdog 5 dk icinde (guncellemeyle) baslatir (sadece yonetici).
        if (CompareText(ARequest.Method, 'POST') <> 0) or
          not OturumYonetici(QParam(q, 'oturma')) then
        begin
          AResponse.Code := 403;
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := '{"hata":"sadece yonetici"}';
          Exit;
        end;
        IslemKaydet(hatQ, ARequest.Method, yol0, QParam(q, 'oturma'),
          'yeniden-baslat', 200);
        WriteLn(FormatDateTime('hh:nn:ss', Now) +
          ' YENIDEN BASLATILIYOR (uzaktan komut).');
        Halt(0);
      end
      else if yol = '/api/hat' then
      begin
        // yeni bos hat dosyasi olustur: {"hat":"M5"} (sadece super kullanici)
        if (CompareText(ARequest.Method, 'POST') = 0) and
          not OturumYonetici(QParam(q, 'oturma')) then
        begin
          AResponse.Code := 403;
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := '{"hata":"sadece yonetici yeni hat acabilir"}';
          Exit;
        end;
        if CompareText(ARequest.Method, 'POST') <> 0 then
        begin
          AResponse.Code := 405;
          AResponse.Content := '';
        end
        else
        begin
          try
            jd := GetJSON(ARequest.Content);
          except
            jd := nil;
          end;
          hatQ := '';
          if (jd <> nil) and (jd.JSONType = jtObject) then
            hatQ := UpperCase(Trim(JAlan(TJSONObject(jd), 'hat')));
          jd.Free;
          if (hatQ = '') or (Pos(' ', hatQ) > 0) then
          begin
            AResponse.Code := 400;
            AResponse.Content := 'hat gerekli (orn {"hat":"M5"})';
          end
          else if HatBul(hatQ) <> nil then
          begin
            AResponse.Code := 409;
            AResponse.Content := 'hat zaten var:' + hatQ;
          end
          else
          begin
            if FHatlar.Count = 0 then
            begin
              AResponse.Code := 500;
              AResponse.Content := 'hat deposu yok';
            end
            else
            begin
              H := THatStore(FHatlar.Objects[0]);
              FHatlar.AddObject(hatQ, THatStore.Olustur(hatQ,
                IncludeTrailingPathDelimiter(ExtractFilePath(H.Dosya)) +
                'veri_' + hatQ + '.json'));
              H := THatStore(FHatlar.Objects[FHatlar.IndexOf(hatQ)]);
              Yukle(H);
              Kaydet(H);
              WriteLn(FormatDateTime('hh:nn:ss', Now) + ' YENI HAT: ' + hatQ);
              AResponse.Content := 'OK(hat olustu:' + hatQ + ')';
            end;
          end;
        end;
      end
      else if (Copy(yol, 1, 11) = '/api/tablo/') or (Copy(yol, 1, 7) = '/tablo/') then
      begin
        if Copy(yol, 1, 5) = '/api/' then adi := Copy(yol, 12, 999)
        else adi := Copy(yol, 8, 999);
        adi := UpperCase(Trim(adi));
        if CompareText(ARequest.Method, 'GET') = 0 then
        begin
          arr := TabloArr(H, adi);
          AResponse.ContentType := 'application/json; charset=utf-8';
          if arr <> nil then AResponse.Content := arr.AsJSON
          else begin AResponse.Code := 404; AResponse.Content := '[]'; end;
        end
        else if CompareText(ARequest.Method, 'POST') = 0 then
        begin
          if Trim(ARequest.Content) = '' then
          begin
            arr := TabloArr(H, adi);
            if arr <> nil then arr.Clear;
            Kaydet(H);
            AResponse.Content := 'OK';
          end
          else
          begin
            try
              jd := GetJSON(ARequest.Content);
            except
              jd := nil;
            end;
            if (jd <> nil) and (jd.JSONType = jtArray) then
            begin
              arr := TabloArr(H, adi);
              if arr = nil then
              begin
                arr := TJSONArray.Create;
                H.Veri.Add(adi, arr);
              end;
              yeni := TJSONArray(jd);
              arr.Clear;
              for i := 0 to yeni.Count - 1 do
                arr.Add(yeni.Items[i].Clone);
              yeni.Free;
              Kaydet(H);
              AResponse.Content := 'OK';
            end
            else
            begin
              jd.Free;
              AResponse.Code := 400;
              AResponse.Content := 'array bekleniyor';
            end;
          end;
        end
        else
        begin
          AResponse.Code := 405;
          AResponse.Content := '';
        end;
      end
      else if Copy(yol, 1, 17) = '/api/yukle-tablo/' then
      begin
        // Excel yukleme: ID eslesirse guncelle, yoksa ekle (tablodaki diger satirlar korunur)
        if CompareText(ARequest.Method, 'POST') <> 0 then
        begin
          AResponse.Code := 405;
          AResponse.Content := '';
        end
        else
        begin
          adi := UpperCase(Trim(Copy(yol, 18, 999)));
          try
            jd := GetJSON(ARequest.Content);
          except
            jd := nil;
          end;
          if (jd = nil) or (jd.JSONType <> jtArray) then
          begin
            jd.Free;
            AResponse.Code := 400;
            AResponse.Content := 'array bekleniyor';
          end
          else
          begin
            arr := TabloArr(H, adi);
            if arr = nil then
            begin
              arr := TJSONArray.Create;
              H.Veri.Add(adi, arr);
            end;
            yeni := TJSONArray(jd);
            ek := 0;
            gu := 0;
            for i := 0 to yeni.Count - 1 do
            begin
              if (yeni.Items[i] = nil) or (yeni.Items[i].JSONType <> jtObject) then
                Continue;
              o := TJSONObject(yeni.Items[i]);
              rid := '';
              if o.Find('ID') <> nil then rid := Trim(o.Find('ID').AsString);
              hedef := nil;
              if rid <> '' then
                for k := 0 to arr.Count - 1 do
                  if (arr.Items[k] <> nil) and (arr.Items[k].JSONType = jtObject) and
                    (JAlan(TJSONObject(arr.Items[k]), 'ID') = rid) then
                  begin
                    hedef := TJSONObject(arr.Items[k]);
                    Break;
                  end;
              if hedef = nil then
              begin
                if rid = '' then rid := SonrakiId(H, adi);
                hedef := TJSONObject.Create;
                hedef.Add('ID', rid);
                arr.Add(hedef);
                Inc(ek);
              end
              else
                Inc(gu);
              for k := 0 to o.Count - 1 do
              begin
                fnam := o.Names[k];
                if CompareText(fnam, 'ID') = 0 then Continue;
                fd := hedef.Find(fnam);
                if fd = nil then hedef.Add(fnam, o.Items[k].AsString)
                else fd.AsString := o.Items[k].AsString;
              end;
            end;
            yeni.Free;
            Kaydet(H);
            WriteLn(FormatDateTime('hh:nn:ss', Now) + ' UPSERT ' + adi +
              ': +' + IntToStr(ek) + ' ~' + IntToStr(gu));
            AResponse.ContentType := 'application/json; charset=utf-8';
            AResponse.Content := '{"sonuc":"OK","eklenen":' + IntToStr(ek) +
              ',"guncellenen":' + IntToStr(gu) + '}';
          end;
        end;
      end
      else if Copy(yol, 1, 19) = '/api/temizle-tablo/' then
      begin
        // yeniden-yaz modu: bir tabloda TTID'si eslesen satirlari sil
        if CompareText(ARequest.Method, 'POST') <> 0 then
        begin
          AResponse.Code := 405;
          AResponse.Content := '';
        end
        else
        begin
          adi := UpperCase(Trim(Copy(yol, 20, 999)));
          try
            jd := GetJSON(ARequest.Content);
          except
            jd := nil;
          end;
          ttid := '';
          if (jd <> nil) and (jd.JSONType = jtObject) then
            ttid := JAlan(TJSONObject(jd), 'TTID');
          jd.Free;
          if ttid = '' then
          begin
            AResponse.Code := 400;
            AResponse.Content := 'TTID gerekli';
          end
          else
          begin
            arr := TabloArr(H, adi);
            ek := 0;
            if arr <> nil then
              for i := arr.Count - 1 downto 0 do
              begin
                fd := arr.Items[i];
                if (fd <> nil) and (fd.JSONType = jtObject) and
                  (JAlan(TJSONObject(fd), 'TTID') = ttid) then
                begin
                  arr.Delete(i);
                  Inc(ek);
                end;
              end;
            Kaydet(H);
            WriteLn(FormatDateTime('hh:nn:ss', Now) + ' TEMIZLE ' + adi +
              ' TTID=' + ttid + ': -' + IntToStr(ek));
            AResponse.ContentType := 'application/json; charset=utf-8';
            AResponse.Content := '{"sonuc":"OK","silinen":' + IntToStr(ek) + '}';
          end;
        end;
      end
      else if yol = '/api/pano' then
      begin
        ttid := QParam(q, 'ttid');
        gun := QParam(q, 'gun');
        suan := QParam(q, 'suan');
        yon := QParam(q, 'yon');
        amod := QParam(q, 'mod');
        o := PanoHesapla(H, ttid, gun, suan, yon, amod);
        try
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := o.AsJSON;
        finally
          o.Free;
        end;
      end
      else if (yol = '/komut') or (yol = '/api/komut') then
      begin
        if CompareText(ARequest.Method, 'POST') = 0 then
        begin
          yol := Trim(ARequest.Content);
          adi := KomutIsle(H, yol);
          WriteLn(FormatDateTime('hh:nn:ss', Now) + ' KOMUT: ' + yol + ' ' + adi);
          AResponse.Content := 'OK' + adi;
        end
        else begin AResponse.Code := 405; AResponse.Content := ''; end;
      end
      else if (yol = '/dosyaal') or (yol = '/api/dosyaal') then
      begin
        // eski istemci uyumlulugu: ham govdeyi data klasorune yaz
        adi := QParam(q, 'adi');
        if adi = '' then adi := 'yukleme.bin';
        adi := ExtractFileName(adi);
        raw := RawByteString(ARequest.Content);
        ForceDirectories(ExtractFilePath(H.Dosya));
        fs := TFileStream.Create(ExtractFilePath(H.Dosya) + adi, fmCreate);
        try
          if Length(raw) > 0 then fs.WriteBuffer(Pointer(raw)^, Length(raw));
        finally
          fs.Free;
        end;
        WriteLn(FormatDateTime('hh:nn:ss', Now) + ' DOSYA: ' + adi +
          ' (' + IntToStr(Length(raw)) + ' byte)');
        AResponse.Content := 'OK';
      end
      else if yol = '/api/resim' then
      begin
        if CompareText(ARequest.Method, 'POST') = 0 then
        begin
          // ham jpeg/png govde -> MAKINISTRESIM'e SICILID ile upsert
          sicil := Trim(QParam(q, 'sicil'));
          raw := RawByteString(ARequest.Content);
          if (sicil = '') or (Length(raw) < 100) then
          begin
            AResponse.Code := 400;
            AResponse.Content := 'sicil ve gorsel gerekli';
          end
          else
          begin
            b64 := EncodeStringBase64(raw);
            arr := TabloArr(H, 'MAKINISTRESIM');
            if arr = nil then
            begin
              arr := TJSONArray.Create;
              H.Veri.Add('MAKINISTRESIM', arr);
            end;
            hedef := nil;
            for i := 0 to arr.Count - 1 do
            begin
              jd := arr.Items[i];
              if (jd <> nil) and (jd.JSONType = jtObject) and
                (JAlan(TJSONObject(jd), 'SICILID') = sicil) then
              begin
                hedef := TJSONObject(jd);
                Break;
              end;
            end;
            if hedef = nil then
            begin
              hedef := TJSONObject.Create;
              hedef.Add('ID', SonrakiId(H, 'MAKINISTRESIM'));
              hedef.Add('SICILID', sicil);
              arr.Add(hedef);
            end;
            fd := hedef.Find('RESIM');
            if fd = nil then hedef.Add('RESIM', b64)
            else fd.AsString := b64;
            fd := hedef.Find('SILINMIS');
            if fd = nil then hedef.Add('SILINMIS', '0')
            else fd.AsString := '0';
            Kaydet(H);
            WriteLn(FormatDateTime('hh:nn:ss', Now) + ' FOTO: ' + sicil +
              ' (' + IntToStr(Length(raw)) + ' byte)');
            AResponse.Content := 'OK(foto kaydedildi:' + sicil + ')';
          end;
        end
        else
        begin
        // MAKINISTRESIM.RESIM (base64) -> ham goruntu
        sicil := QParam(q, 'sicil');
        b64 := '';
        arr := TabloArr(H, 'MAKINISTRESIM');
        if arr <> nil then
          for i := 0 to arr.Count - 1 do
          begin
            jd := arr.Items[i];
            if (jd <> nil) and (jd.JSONType = jtObject) then
            begin
              o := TJSONObject(jd);
              if (o.Find('SICILID') <> nil) and (o.Find('SICILID').AsString = sicil) then
              begin
                if o.Find('RESIM') <> nil then b64 := o.Find('RESIM').AsString;
                Break;
              end;
            end;
          end;
        if b64 = '' then
        begin
          AResponse.Code := 404;
          AResponse.Content := 'foto yok';
        end
        else
        begin
          raw := DecodeStringBase64(b64);
          ms := TMemoryStream.Create;
          if Length(raw) > 0 then ms.WriteBuffer(Pointer(raw)^, Length(raw));
          ms.Position := 0;
          if (Length(raw) > 3) and (raw[1] = #$FF) and (raw[2] = #$D8) then
            AResponse.ContentType := 'image/jpeg'
          else if (Length(raw) > 4) and (raw[1] = #$89) and (raw[2] = 'P') then
            AResponse.ContentType := 'image/png'
          else
            AResponse.ContentType := 'application/octet-stream';
          AResponse.ContentStream := ms;
          AResponse.ContentLength := ms.Size;
          AResponse.FreeContentStream := True;
        end;
        end;
      end
      else
        StatikSun(Copy(yol, 2, 9999), AResponse);
      { islem gunlugu: yazan istekler (sifre/token yazilmaz) }
      if (CompareText(ARequest.Method, 'POST') = 0) or
        (CompareText(ARequest.Method, 'PUT') = 0) or
        (CompareText(ARequest.Method, 'DELETE') = 0) then
      begin
        if (yol0 = '/komut') or (yol0 = '/api/komut') then
          IslemKaydet(hatQ, ARequest.Method, yol0, QParam(q, 'oturma'),
            Trim(ARequest.Content), AResponse.Code)
        else if yol0 = '/api/resim' then
          IslemKaydet(hatQ, ARequest.Method, yol0, QParam(q, 'oturma'),
            'sicil=' + QParam(q, 'sicil'), AResponse.Code)
        else
          IslemKaydet(hatQ, ARequest.Method, yol0, QParam(q, 'oturma'),
            'uzunluk=' + IntToStr(Length(ARequest.Content)), AResponse.Code);
      end;
    finally
      LeaveCriticalSection(FKilit);
    end;
  except
    on E: Exception do
    begin
      AResponse.Code := 500;
      AResponse.Content := 'hata: ' + E.Message;
    end;
  end;
end;

end.
