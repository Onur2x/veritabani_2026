﻿unit websrv;

{ Makinist Takip - Web Server (DB'nin tek sahibi)
  Konsol uygulamasi, LCL BAGIMLILIGI YOK.
  Mevcut masaustu exe'deki (onurvt.pas + onurmakinist.pas) veri ve
  SiralamaYap mantiginin web/JSON karsiligi.

  Endpoint'ler:
    GET  /                    -> /pano.html'e 302
    GET  /pano.html, /veri_37.json, ... (web klasorunden statik)
    GET  /api/durum           -> versiyon, saat, tablo sayilari
    GET  /api/ayarlar         -> AYARLAR objesi
    GET  /api/tablo/ADI       -> tablo JSON array (+eski /tablo/ADI)
    POST /api/tablo/ADI       -> array ile komple degistir + kaydet
    POST /api/yukle-tablo/ADI -> upsert: ID varsa guncelle, yoksa ekle
    POST /api/temizle-tablo/ADI {"TTID":".."} -> tarifeye ait satirlari sil
    GET  /api/resim?sicil=     -> foto indir
    POST /api/resim?sicil=     -> foto yukle (ham jpeg/png govde)
    GET  /api/pano?ttid=&gun=&suan=&yon=&mod=&hat= -> hesaplanmis pano JSON
    POST /komut, /api/komut   -> sirali/numarali/flash/... (AYARLAR yazar)
    POST /dosyaal?adi=        -> eski istemci uyumlulugu (dosyayi data'ya yazar)
    GET  /api/hatlar          -> hat listesi ["M8",...]
    POST /api/hat {"hat":"M5"} -> yeni bos hat dosyasi olustur
    GET  /api/tablolar        -> tablo adlari (arsiv kesfi icin)
  Tum /api/* ve /tablo/*, /komut istekleri ?hat= ile hatta baglanir
  (bos birakilirsa varsayilan hat). Veri dosyalari: veri_{HAT}.json
}

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, fpjson, jsonparser, fphttpserver, httpdefs, DateUtils,
  base64, sha1, VDbSql, MtData;

const
  SRV_VERSIYON = '0001';

type
  TDiziler = array of string;

  { TArray<Integer> yerine kullanilir: FPC'de generic dizi tipi derleyici
    bayragina bagli (Generics without specialization) ve bu unit
    {$mode objfpc}; acik tip hem her zaman derlenir hem de intent
    (sayi dizisi) kodda okunur. }
  TIntDizi = array of Integer;

  { Okuma onbellegi. Motor her tablo taramasinda dosyanin tamamini
    okuyup CRC dogruladigi icin (sabit ~33 ms) her istekte sorgu
    yapmak pano acilmasini 600 ms'ye cikarir. Burada tablonun JSON
    metni saklanir; istek gelince yalnizca ayristirilir (~1-2 ms).
    Gecerlilik Vt.Versyon ile izlenir: veri degisince onbellek
    duser. Fotograf (MAKINISTRESIM) onbellege ALINMAZ; BLOB'lar
    birincil anahtarla zaten 0 ms okunuyor. }
  TOnbellek = record
    Surum: QWord;
    Metin: AnsiString;
  end;

  TOnbellekKaydi = class
    Surum: QWord;
    Metin: AnsiString;
  end;

  THatStore = class
    Hat: string;
    constructor Olustur(const AHat: string);
    destructor Destroy; override;
  end;

  TWebSrv = class
  private
    FHatlar: TStringList; { Name=hat kodu, Object=THatStore }
    FWebDir: string;
    FVarsayilanHat: string;
    FOturumlar: TStringList; { "HAT:token" kayitlari }
    FOnbellek: TStringList;   { Name="HAT|TABLO", Object=TOnbellekKaydi }
    FKilit: TRTLCriticalSection;
    function OnbellekGet(const Anahtar: string): string;
    procedure OnbellekKoy(const Anahtar, Metin: string);
    function HatBul(const Hat: string): THatStore;
    { Artik dosya yok; veri her istekte veritabanindan okunur. }
    procedure Yukle(H: THatStore);
    procedure Kaydet(H: THatStore);
    procedure AnlikGoruntuYaz(H: THatStore);
    procedure GerekirseYenidenYukle(H: THatStore);
    function TabloArr(H: THatStore; const Adi: string): TJSONArray;
    { Toplam tur suresini AYAR tablosundan DEGIL, saat tablosundan turetir:
      ayni sefer numarasinin gidis-donus kacisi medyani toplanir
      (gidis medyani + donus medyani). Boylece deger hat ve tabloya gore
      degisir; elle girilmis TOPLAMTURSURESI degerinin hatta gore
      kopyalanmis (M8 icin tutmus, T4'te 2 kat hatali) olmasi sorunu
      olusur. Saat tablosu bos ise kayitli ayara donulur. }
    function TurSuresiTuret(H: THatStore; const Ttid: string): Integer;
    function TabloMetin(H: THatStore; const Adi: string): string;
    { Satirlar bos/gecersizse YAZMA YAPILMAZ ve False doner; cagricilar
      bunu HTTP 400 olarak yansitir. }
    function TabloKaydet(H: THatStore; const Adi: string;
      const Satirlar: TJSONArray): Boolean;
    function AyarJson(H: THatStore): string;
    function AyarJsonSifir(H: THatStore): string;
    function SonrakiId(H: THatStore; const Adi: string): string;
    function AyarOku(H: THatStore; const Alan: string): string;
    procedure AyarYaz(H: THatStore; const Alan, Deger: string);
    function SureCevir(const S: string): Integer;
    function SureYaz(Sn: Integer): string;
    function TTIdSec(H: THatStore): string;
    function GunKolon: string;
    function PanoHesapla(H: THatStore; const TTId, Gun, SuanStr, Yon, AMod: string): TJSONObject;
    function MimeTip(const FN: string): string;
    procedure StatikSun(const Yol: string; var AResp: TFPHTTPConnectionResponse);
    function KomutIsle(H: THatStore; const Komut: string): string;
    function HatListesiJson: string;
    function TabloAdlariJson(H: THatStore): string;
    function TabloSay(H: THatStore; const Adi: string): Integer;
    function HatSifresi(const Hat: string): string;
    function SifreDosyasiYaz(const Anahtar, Deger: string): Boolean;
    function OturumGecerli(const Hat, Tok: string): Boolean;
    function OturumYonetici(const Tok: string): Boolean;
    function OturumAc(const Hat: string): string;
    procedure OturumKapat(const Tok: string);
    function VeriKlasoru: string;
    function SifreYolu: string;
    function YedekKlasoru: string;
    function GunlukDosya(const Ay: string): string;
    procedure IslemKaydet(const Hat, Yontem, Yol, Oturma, Detay: string; Kod: Integer);
    function GirisSayfasi(const Geri, IlkBaslik, Hat, HatSecenek: string): string;
  public
    constructor Olustur(const DataDir, WebDir, VarsayilanHat: string);
    destructor Destroy; override;
    procedure Istek(Sender: TObject; var ARequest: TFPHTTPConnectionRequest;
      var AResponse: TFPHTTPConnectionResponse);
    { Sunucu ici yedek: dosya kilidi acikken disaridan kopyalama yapilamaz,
      bu yuzden motorun kendi tutarli yedeklemesi kullanilir. }
    function YedekAl(const Hedef: string): Boolean;
    function GunlukSatirlari(const Hat, Ay: string; Limit: Integer): TJSONArray;
    function YedekTazeliMi(const Klasor: string; Dakika: Integer): Boolean;
    procedure YedekKirp(const Klasor: string; Tutar: Integer);
    procedure YedekKirpMask(const Klasor: string; Tutar: Integer;
      const Mask: string);
    function GunlukYedekAl(const Klasor: string): Boolean;
    function SaatKlasoru: string;
    function GunKlasoru: string;
    function GeriYuklemeKlasoru: string;
    { Tablo yazma guvenlik anlik goruntusu: satir SAYISI AZALAN her yazmada
      alinir. Kullanici hatirlatmadan veri kaybi yasamaz; hatali bir kayit
      /api/geri-yukle ile bu klasorden geri alinabilir. }
    function YazmaKlasoru: string;
    procedure TabloYazmaGuvenligi(const Hat, Tablo: string; EskiSatir,
      YeniSatir: Integer);
    { Yedek dosya adindan guvenli tam yol cozer. Uc katman var:
        backup\saat\mtakip_YYYYMMDD_HH.odb       saatlik (11 karakter)
        backup\gun\ mtakip_YYYYMMDD.odb           gunluk  (8 karakter)
        backup\yazma\mtakip_YYYYMMDD_HHMMSS.odb  yazma oncesi (15 karakter)
      Damga uzunlugu katmani benzersiz belirledigi icin "tur" parametresi
      gerekmez; yol gezintisi (.., /, \) sizdan gelen metinle kurulamaz. }
    function YedekYolCoz(const Ad: string; out Tam: string): Boolean;
    property WebKlasor: string read FWebDir;
  end;

function QParam(const Q, Ad: string): string;

implementation

type
{ Yedek listesi icin gecici kayit. Siralama JSON nesnesi uretilmeden once
  bu dizi uzerinde yapilir. }
TYedekKaydi = record
  Zaman: TDateTime;
  Boyut: Int64;
  Tur: string;
  Ad: string;
end;

function DosyaIcerik(const Yol: string): string; forward;

function QParam(const Q, Ad: string): string;
var
  i: Integer;
  k, v: string;
begin
  Result := '';
  if Q = '' then Exit;
  i := 1;
  while i <= Length(Q) do
  begin
    k := ''; v := '';
    while (i <= Length(Q)) and (Q[i] <> '&') and (Q[i] <> '=') do
    begin k := k + Q[i]; Inc(i); end;
    if (i <= Length(Q)) and (Q[i] = '=') then
    begin
      Inc(i);
      while (i <= Length(Q)) and (Q[i] <> '&') do
      begin v := v + Q[i]; Inc(i); end;
    end;
    if AnsiCompareText(k, Ad) = 0 then begin Result := v; Exit; end;
    Inc(i);
  end;
end;

function TemizYol(const U: string): string;
var
  p: Integer;
begin
  Result := U;
  p := Pos('?', Result);
  if p > 0 then Result := Copy(Result, 1, p - 1);
  Result := Trim(Result);
end;

function JAlan(o: TJSONObject; const f: string): string;
var
  d: TJSONData;
begin
  Result := '';
  if o = nil then Exit;
  d := o.Find(f);
  if d <> nil then Result := d.AsString;
end;

{ GRUP1='7;35' veya '1-9' gibi 'a;b' / 'a-b' araliginda mi }
function GermAralik(const Grup: string; Idx: Integer): Boolean;
var
  p, a, b: Integer;
  s: string;
begin
  Result := False;
  s := StringReplace(Grup, '-', ';', [rfReplaceAll]);
  p := Pos(';', s);
  if p = 0 then Exit;
  a := StrToIntDef(Trim(Copy(s, 1, p - 1)), -1);
  b := StrToIntDef(Trim(Copy(s, p + 1, 99)), -1);
  Result := (a >= 0) and (Idx >= a) and (Idx <= b);
end;

{ Mesaj zaman penceresi: BASLAMA/BITIS bossa hep goster; gece devri desteklenir }
function MesajAktif(const R: TJSONObject; Suan: Integer): Boolean;
var
  b1, b2, h, m, s: Integer;
  s1, s2: string;
  function SaatCevir(const V: string): Integer;
  var
    hh, mm, ss: Integer;
  begin
    Result := -1;
    if TryStrToInt(Copy(V, 1, 2), hh) and TryStrToInt(Copy(V, 4, 2), mm) and
      TryStrToInt(Copy(V, 7, 2), ss) then
      Result := hh * 3600 + mm * 60 + ss;
  end;
begin
  Result := True;
  s1 := Trim(JAlan(R, 'BASLAMA'));
  s2 := Trim(JAlan(R, 'BITIS'));
  if (s1 = '') and (s2 = '') then Exit;
  b1 := SaatCevir(s1);
  b2 := SaatCevir(s2);
  if (b1 < 0) and (b2 < 0) then Exit;
  if b1 < 0 then b1 := 0;
  if b2 < 0 then b2 := 86400;
  if b2 <= b1 then
    Result := (Suan >= b1) or (Suan < b2)
  else
    Result := (Suan >= b1) and (Suan < b2);
end;

{ Gorev eslestirme: bastaki F Ã¶neki yoksayilir (kadroda F252 = tarifede 252) }
function GorevNorm(const G: string): string;
begin
  Result := Trim(G);
  if (Result <> '') and (UpCase(Result[1]) = 'F') then
    Result := Trim(Copy(Result, 2, 999));
end;

{ 'a;b;c' listesinin idx'inci parcasi (yoksa ilk parca) }
function ParcaAl(const S: string; Idx: Integer): string;
var
  p: TStringList;
begin
  Result := '';
  p := TStringList.Create;
  try
    p.Delimiter := ';';
    p.StrictDelimiter := True;
    p.DelimitedText := S;
    if p.Count = 0 then Exit;
    if (Idx < 0) or (Idx >= p.Count) then
      Result := Trim(p[0])
    else
      Result := Trim(p[Idx]);
  finally
    p.Free;
  end;
end;

{ THatStore }

constructor THatStore.Olustur(const AHat: string);
begin
  inherited Create;
  Hat := AHat;
end;

destructor THatStore.Destroy;
begin
  inherited Destroy;
end;

{ TWebSrv }

constructor TWebSrv.Olustur(const DataDir, WebDir, VarsayilanHat: string);
var
  i: Integer;
  HatlarTum: TStringList;
begin
  inherited Create;
  FWebDir := ExcludeTrailingPathDelimiter(WebDir);
  FVarsayilanHat := UpperCase(Trim(VarsayilanHat));
  if FVarsayilanHat = '' then FVarsayilanHat := 'M8';
  FHatlar := TStringList.Create;
  InitCriticalSection(FKilit);
  { Tek veritabani dosyasi: data\mtakip.odb. Hatlar oradan okunur. }
  Vt := TMtDb.Create(IncludeTrailingPathDelimiter(DataDir) + 'mtakip.odb');
  try
    Vt.Ac;
  except
    on E: Exception do
      WriteLn('HATA: veritabani acilamadi - ', E.Message);
  end;
  HatlarTum := Vt.Hatlar;
  try
    for i := 0 to HatlarTum.Count - 1 do
      FHatlar.AddObject(HatlarTum[i], THatStore.Olustur(HatlarTum[i]));
  finally
    HatlarTum.Free;
  end;
  FHatlar.Sorted := True;
  FOturumlar := TStringList.Create;
  FOnbellek := TStringList.Create;
end;

{ Bir hatin ISLEMGUNLUGU kayitlarini JSON dizisi olarak dondurur.
  Artik aylik .jsonl dosyasi yok; kayitlar {HAT}_ISLEMGUNLUGU tablosunda. }
function TWebSrv.GunlukSatirlari(const Hat, Ay: string; Limit: Integer): TJSONArray;
var
  R: TSqlResult;
  I, K: Integer;
  o: TJSONObject;
  Alan: array[0..7] of string;
begin
  Result := TJSONArray.Create;
  if not HatGecerli(Hat) then Exit;
  try
    { Hat verilmisse motor yalnizca o tabloyu okur; "TUMU" ise butun
      hatlar taranir ve sonuc sunucu tarafinda filtrelenir. }
    R := Vt.GunlukOku(Ay, Limit, Hat);
  except
    on E: Exception do Exit;
  end;
  { Vt.GunlukOku sutunlari: ZAMAN, HAT, KULLANICI, YONTEM, YOL, DETAY,
    SONU, KOD. Hat adi SQL'e degil motor kisiti nedeniyle burada eklenir. }
  if Length(R.Fields) < 8 then Exit;
  Alan[0] := 'zaman';    Alan[1] := 'hat';    Alan[2] := 'rol';
  Alan[3] := 'islem';    Alan[4] := 'yol';    Alan[5] := 'detay';
  Alan[6] := 'sonuc';    Alan[7] := 'kod';
  for I := 0 to High(R.Rows) do
  begin
    { Hat filtresi sunucu tarafinda: bir hat yalnizca kendi gunlugunu gorur. }
    if (Length(R.Rows[I]) > 1) and (R.Rows[I][1] <> Hat) then Continue;
    o := TJSONObject.Create;
    for K := 0 to 7 do
      if Length(R.Rows[I]) > K then
        o.Add(Alan[K], R.Rows[I][K]);
    Result.Add(o);
    if Result.Count >= Limit then Break;
  end;
end;

{ Yedek politikasi (kullanicinin istegi: cok dosya olmasin):
    backup\saat\mtakip_YYYYMMDD_HH.odb  -> son 24 adet (tam 1 gun)
    backup\gun\ mtakip_YYYYMMDD.odb      -> son 14 adet (2 hafta)
  Saatlik katman tek gunu, gunluk katman daha eski hatalari geri
  alabilmek icin tutar. Toplam 38 dosya, iki duz klasorde. }

{ Klasordeki en yeni dosya yasindan kucuk degilse false (yani "yeni
  yedek gerekmiyor"). Saat: dakika cinsinden. }
function TWebSrv.SaatKlasoru: string;
begin
  Result := IncludeTrailingPathDelimiter(YedekKlasoru) + 'saat';
  if not DirectoryExists(Result) then ForceDirectories(Result);
end;

function TWebSrv.GunKlasoru: string;
begin
  Result := IncludeTrailingPathDelimiter(YedekKlasoru) + 'gun';
  if not DirectoryExists(Result) then ForceDirectories(Result);
end;

function TWebSrv.YedekTazeliMi(const Klasor: string; Dakika: Integer): Boolean;
var
  sr: TSearchRec;
  EnYeni: TDateTime;
begin
  Result := True;
  EnYeni := 0;
  if not DirectoryExists(Klasor) then Exit;
  if FindFirst(IncludeTrailingPathDelimiter(Klasor) + 'mtakip_*.odb',
      faAnyFile, sr) = 0 then
  try
    repeat
      if FileDateToDateTime(sr.Time) > EnYeni then
        EnYeni := FileDateToDateTime(sr.Time);
    until FindNext(sr) <> 0;
  finally
    FindClose(sr);
  end;
  if EnYeni > 0 then
    Result := (Now - EnYeni) >= (Dakika / 1440.0);
end;

{ Sirali listeye gore fazlalari siler. }
procedure TWebSrv.YedekKirp(const Klasor: string; Tutar: Integer);
begin
  YedekKirpMask(Klasor, Tutar, 'mtakip_*.odb');
end;

procedure TWebSrv.YedekKirpMask(const Klasor: string; Tutar: Integer;
  const Mask: string);
var
  sr: TSearchRec;
  Adlar: TStringList;
begin
  if Tutar < 1 then Exit;
  Adlar := TStringList.Create;
  try
    if FindFirst(IncludeTrailingPathDelimiter(Klasor) + Mask,
        faAnyFile, sr) = 0 then
    try
      repeat
        { tarih damgasi one gore: en yeni en basta }
        Adlar.Add(FormatDateTime('yyyymmdd_hhnnss', FileDateToDateTime(sr.Time)) +
          '|' + sr.Name);
      until FindNext(sr) <> 0;
    finally
      FindClose(sr);
    end;
    Adlar.Sort;
    while Adlar.Count > Tutar do
    begin
      DeleteFile(IncludeTrailingPathDelimiter(Klasor) +
        Copy(Adlar[0], Length(Adlar[0]) - Length(ExtractFileName(Adlar[0])) + 2,
          MaxInt));
      Adlar.Delete(0);
    end;
  finally
    Adlar.Free;
  end;
end;

{ Gunluk katman: bugun icin henuz yedek yoksa al (yoksa dokunma). }
function TWebSrv.GunlukYedekAl(const Klasor: string): Boolean;
var
  Bugun: string;
begin
  Bugun := IncludeTrailingPathDelimiter(Klasor) + 'mtakip_' +
    FormatDateTime('yyyymmdd', Now) + '.odb';
  if FileExists(Bugun) then Exit(False);
  Result := YedekAl(Bugun);
  if Result then YedekKirp(Klasor, 14);
end;

function TWebSrv.YedekAl(const Hedef: string): Boolean;
begin
  Result := False;
  if not Vt.ACIKMIs then
  begin
    WriteLn('VT: yedek - veritabani kapali');
    Exit;
  end;
  if Hedef = '' then Exit;
  EnterCriticalSection(FKilit);
  try
    try
      WriteLn('VT: yedek hedefi = ', Hedef);
      Vt.YedekAl(Hedef);
      Result := FileExists(Hedef);
      if Result then
        WriteLn(FormatDateTime('dd.mm.yyyy hh:nn:ss', Now) + ' YEDEK ALINDI')
      else
        WriteLn(FormatDateTime('hh:nn:ss', Now) + ' YEDEK ALINAMADI');
    except
      on E: Exception do
        WriteLn('VT: yedek hatasi - ', Copy(E.Message, 1, 120));
    end;
  finally
    LeaveCriticalSection(FKilit);
  end;
  Flush(Output);
end;

destructor TWebSrv.Destroy;
var
  i: Integer;
begin
  EnterCriticalSection(FKilit);
  try
    for i := 0 to FOnbellek.Count - 1 do
      TOnbellekKaydi(FOnbellek.Objects[i]).Free;
    FOnbellek.Free;
    for i := 0 to FHatlar.Count - 1 do
      THatStore(FHatlar.Objects[i]).Free;
    FHatlar.Free;
    FOturumlar.Free;
    Vt.Free;
  finally
    LeaveCriticalSection(FKilit);
  end;
  DoneCriticalSection(FKilit);
  inherited Destroy;
end;

function TWebSrv.HatBul(const Hat: string): THatStore;
var
  h: string;
  i: Integer;
begin
  Result := nil;
  if FHatlar.Count = 0 then Exit;
  h := UpperCase(Trim(Hat));
  if h = '' then h := FVarsayilanHat;
  i := FHatlar.IndexOf(h);
  if i >= 0 then Result := THatStore(FHatlar.Objects[i]);
end;

function TWebSrv.HatListesiJson: string;
var
  i: Integer;
  arr: TJSONArray;
begin
  arr := TJSONArray.Create;
  try
    for i := 0 to FHatlar.Count - 1 do
      arr.Add(FHatlar[i]);
    Result := arr.AsJSON;
  finally
    arr.Free;
  end;
end;

{ Sifreler veritabaninda: VT_SIFRE tablosu.
  ADMIN girisi salted SHA1 ozeti olarak saklanir. }
function TWebSrv.HatSifresi(const Hat: string): string;
begin
  Result := '';
  if not HatGecerli(Hat) then Exit;
  Result := Trim(Vt.SifreOku(UpperCase(Trim(Hat))));
end;

function TWebSrv.TabloSay(H: THatStore; const Adi: string): Integer;
var
  A, Metin: string;
  jd: TJSONData;
  arr: TJSONArray;
begin
  Result := 0;
  if H = nil then Exit;
  A := UpperCase(Trim(Adi));
  { Fotograf tablosu onbellege alinmaz; dogrudan motor sayar. }
  if A = 'MAKINISTRESIM' then
  begin
    Result := Vt.SatirSayisi(H.Hat, A);
    Exit;
  end;
  { Onbellekteki metinden say: COUNT(*) her seferinde tam dosya taramasi
    yapar (13 tablo x ~120 ms = 1.6 sn). }
  Metin := OnbellekGet(H.Hat + '|' + A);
  if Metin <> '' then
  begin
    jd := GetJSON(Metin);
    try
      if jd <> nil then Result := TJSONArray(jd).Count;
    finally
      jd.Free;
    end;
    Exit;
  end;
  arr := TabloArr(H, A);
  if arr <> nil then
  begin
    Result := arr.Count;
    arr.Free;
  end;
end;

function TWebSrv.TabloAdlariJson(H: THatStore): string;
var
  i: Integer;
  arr: TJSONArray;
  l: TStringList;
  Metin: string;
begin
  if H = nil then Exit('[]');
  { SHOW TABLES her tablo icin satir sayisi hesapladigi icin ~1.6 sn
    suruyor; sonuc onbellege alinir. }
  Metin := OnbellekGet(H.Hat + '|@TABLOLAR');
  if Metin <> '' then Exit(Metin);
  arr := TJSONArray.Create;
  l := Vt.HatTabloListesi(H.Hat);
  try
    for i := 0 to l.Count - 1 do
      arr.Add(l[i]);
    Result := arr.AsJSON;
  finally
    l.Free;
    arr.Free;
  end;
  OnbellekKoy(H.Hat + '|@TABLOLAR', Result);
end;

{ Hat bazli yonetim girisi. Sifre data/sifreler.json dosyasinda sabittir
  ({"M8":"..."}); kullanicilar panelden degistiremez.
  Kayit "sha1:<hex>" ise salt'li ozet karsilastirilir (dosyadan okunamaz),
  degilse eski duz-metin karsilastirma (gecis uyumlulugu).
  Oturumlar "HAT:token" olarak tutulur. ADMIN sifresiyle giren super
  kullanici "*:token" alir ve tum hatlarda gecerlidir. }
function SifreTutuyor(const Kayitli, Girilen: string): Boolean;
var
  ozet: string;
begin
  Result := False;
  if (Trim(Kayitli) = '') or (Trim(Girilen) = '') then Exit;
  if LowerCase(Copy(Kayitli, 1, 5)) = 'sha1:' then
  begin
    ozet := SHA1Print(SHA1String(UTF8Encode('mtakip-admin:' + UnicodeString(Girilen))));
    Result := LowerCase(ozet) = LowerCase(Trim(Copy(Kayitli, 6, 999)));
  end
  else
    Result := Kayitli = Girilen;
end;
function TWebSrv.OturumGecerli(const Hat, Tok: string): Boolean;
begin
  Result := False;
  if Trim(Tok) = '' then Exit;
  EnterCriticalSection(FKilit);
  try
    Result := (FOturumlar.IndexOf(UpperCase(Trim(Hat)) + ':' + Trim(Tok)) >= 0)
      or (FOturumlar.IndexOf('*:' + Trim(Tok)) >= 0);
  finally
    LeaveCriticalSection(FKilit);
  end;
end;

function TWebSrv.OturumAc(const Hat: string): string;
var
  g: TGUID;
begin
  CreateGUID(g);
  Result := LowerCase(Copy(GUIDToString(g), 2, 36));
  EnterCriticalSection(FKilit);
  try
    if FOturumlar.IndexOf(UpperCase(Trim(Hat)) + ':' + Result) < 0 then
      FOturumlar.Add(UpperCase(Trim(Hat)) + ':' + Result);
  finally
    LeaveCriticalSection(FKilit);
  end;
end;

procedure TWebSrv.OturumKapat(const Tok: string);
var
  i: Integer;
  t: string;
begin
  t := Trim(Tok);
  if t = '' then Exit;
  EnterCriticalSection(FKilit);
  try
    for i := FOturumlar.Count - 1 downto 0 do
      if (Length(FOturumlar[i]) > Length(t)) and
        (Copy(FOturumlar[i], Length(FOturumlar[i]) - Length(t) + 1, Length(t)) = t) and
        (FOturumlar[i][Length(FOturumlar[i]) - Length(t)] = ':') then
        FOturumlar.Delete(i);
  finally
    LeaveCriticalSection(FKilit);
  end;
end;

function TWebSrv.OturumYonetici(const Tok: string): Boolean;
begin
  Result := False;
  if Trim(Tok) = '' then Exit;
  EnterCriticalSection(FKilit);
  try
    Result := FOturumlar.IndexOf('*:' + Trim(Tok)) >= 0;
  finally
    LeaveCriticalSection(FKilit);
  end;
end;

function TWebSrv.VeriKlasoru: string;
begin
  Result := '';
  if not Vt.ACIKMIs then Exit;
  Result := IncludeTrailingPathDelimiter(Vt.DizinYolu);
end;

function TWebSrv.SifreYolu: string;
begin
  { Artik dosya yok; sifreler VT_SIFRE tablosunda. }
  Result := IncludeTrailingPathDelimiter(Vt.DizinYolu) + 'vt_sifre.odb';
end;

function TWebSrv.YedekKlasoru: string;
begin
  Result := IncludeTrailingPathDelimiter(ExpandFileName(
    ExtractFileDir(ParamStr(0)) + PathDelim + '..' + PathDelim + 'backup'));
  if not DirectoryExists(Result) then
    ForceDirectories(Result);
end;

{ Yedek dosya adi guvenligi: mtakip_YYYYMMDD_HHMMSS.odb kalibinda mi.
  Artik hat basina JSON degil, TEK veritabani dosyasi yedeklenir. }
function TWebSrv.GeriYuklemeKlasoru: string;
begin
  Result := IncludeTrailingPathDelimiter(YedekKlasoru) + 'geri_yukleme';
  if not DirectoryExists(Result) then ForceDirectories(Result);
end;

function TWebSrv.YazmaKlasoru: string;
begin
  Result := IncludeTrailingPathDelimiter(YedekKlasoru) + 'yazma';
  if not DirectoryExists(Result) then ForceDirectories(Result);
end;

{ Satir sayisi azalan tablo yaziminda, yazma ONCESI halin motor yedegi
  alinir. Boylece hatali bir kayit arayuzden geri alinabilir.
  Artan yazimlar (yeni satir ekleme) icin yedek alinmaz: veri kaybi
  olusturmazlar ve her seferinde 7 MB yazmak gereksizdir. }
procedure TWebSrv.TabloYazmaGuvenligi(const Hat, Tablo: string; EskiSatir,
  YeniSatir: Integer);
var
  y: string;
begin
  if YeniSatir >= EskiSatir then Exit;
  y := IncludeTrailingPathDelimiter(YazmaKlasoru) + 'mtakip_' +
    FormatDateTime('yyyymmdd_hhnnss', Now) + '.odb';
  if YedekAl(y) then
  begin
    YedekKirpMask(YazmaKlasoru, 20, 'mtakip_*.odb');
    WriteLn(FormatDateTime('hh:nn:ss', Now) + ' YAZMA GUVENLIGI: ' + Hat + '_' +
      Tablo + ' ' + IntToStr(EskiSatir) + ' -> ' + IntToStr(YeniSatir) +
      ' satir, onceki hal ' + ExtractFileName(y));
  end
  else
    WriteLn(FormatDateTime('hh:nn:ss', Now) + ' YAZMA GUVENLIGI ALINAMADI: ' +
      Hat + '_' + Tablo);
end;

{ Yedek adindan guvenli tam yol. Yalnizca uc bicim kabul edilir:
    yyyymmdd_hh     (11 karakter) -> backup\saat\    saatlik katman
    yyyymmdd        (8  karakter) -> backup\gun\     gunluk katman
    yyyymmdd_hhnnss (15 karakter) -> backup\yazma\   yazma oncesi guvenlik
  Damga uzunlugu katmani benzersiz belirledigi icin ayri "tur" parametresi
  gerekmez. Gelen metinde yol ayiracÄ±, nokta dizisi veya Buyuk/Kucuk harf
  disi karakter olamaz. }
function TWebSrv.YedekYolCoz(const Ad: string; out Tam: string): Boolean;
var
  k: string;
  i, n: Integer;
begin
  Result := False;
  Tam := '';
  if (Length(Ad) < 1) or (Length(Ad) > 40) then Exit;
  if Copy(Ad, 1, 7) <> 'mtakip_' then Exit;
  if Copy(Ad, Length(Ad) - 3, 4) <> '.odb' then Exit;
  k := Copy(Ad, 8, Length(Ad) - 7 - 4);
  n := Length(k);
  if (n <> 8) and (n <> 11) and (n <> 15) then Exit;
  { Tek ayirac 9. pozisyonda: yyyymmdd_hh ve yyyymmdd_hhnnss }
  if (n <> 8) and (k[9] <> '_') then Exit;
  for i := 1 to n do
  begin
    { NOT icin: FPC'de and/or karsilastirmadan daha sik baglandigi icin
      parantez sart. }
    if not (k[i] in ['0'..'9']) then
      if (i <> 9) then Exit;
  end;
  { SaatKlasoru/GunKlasoru/YazmaKlasoru sona ayrac EKLEMEZ. }
  case n of
    8: Tam := IncludeTrailingPathDelimiter(GunKlasoru) + Ad;
    11: Tam := IncludeTrailingPathDelimiter(SaatKlasoru) + Ad;
    else Tam := IncludeTrailingPathDelimiter(YazmaKlasoru) + Ad;
  end;
  Result := True;
end;

procedure DosyaKopyala(const Kaynak, Hedef: string);
var
  fs, yfo: TFileStream;
begin
  fs := TFileStream.Create(Kaynak, fmOpenRead or fmShareDenyNone);
  try
    yfo := TFileStream.Create(Hedef, fmCreate);
    try
      yfo.CopyFrom(fs, fs.Size);
    finally
      yfo.Free;
    end;
  finally
    fs.Free;
  end;
end;

function DosyaIcerik(const Yol: string): string;
var
  fs: TFileStream;
begin
  Result := '';
  if not FileExists(Yol) then Exit;
  fs := TFileStream.Create(Yol, fmOpenRead or fmShareDenyNone);
  try
    SetLength(Result, fs.Size);
    if fs.Size > 0 then fs.ReadBuffer(Result[1], fs.Size);
  finally
    fs.Free;
  end;
end;

{ sifre veritabanina yazar (ADMIN sha1 ozeti icin) }
function TWebSrv.SifreDosyasiYaz(const Anahtar, Deger: string): Boolean;
begin
  Result := False;
  EnterCriticalSection(FKilit);
  try
    try
      Vt.SifreYaz(UpperCase(Trim(Anahtar)), Deger);
      Result := True;
    except
      on E: Exception do
        Result := False;
    end;
  finally
    LeaveCriticalSection(FKilit);
  end;
end;

{ Islem gunlugu dosyasi: aylik (islemgunlugu_YYYY_AA.jsonl). Ay='' ise bu ay. }
function TWebSrv.GunlukDosya(const Ay: string): string;
var
  a: string;
  y, m: Integer;
begin
  Result := '';
  if FHatlar.Count = 0 then Exit;
  a := Trim(Ay);
  y := StrToIntDef(Copy(a, 1, 4), 0);
  m := StrToIntDef(Copy(a, 6, 2), 0);
  if (Length(a) <> 7) or (a[5] <> '-') or (y < 2020) or (y > 2100) or
    (m < 1) or (m > 12) then
    a := FormatDateTime('yyyy-mm', Now);
  Result := VeriKlasoru + 'islemgunlugu_' + Copy(a, 1, 4) + '_' +
    Copy(a, 6, 2) + '.jsonl';
end;

{ Islem gunlugu: {HAT}_ISLEMGUNLUGU tablosuna yazilir.
  Sifre/token ASLA yazilmaz; sadece rol (admin/kullanici/sifre) + islem + sonuc. }
procedure TWebSrv.IslemKaydet(const Hat, Yontem, Yol, Oturma, Detay: string; Kod: Integer);
var
  rol: string;
begin
  if FHatlar.Count = 0 then Exit;
  if not HatGecerli(Hat) then Exit;
  if OturumYonetici(Oturma) then rol := 'admin'
  else if Trim(Oturma) <> '' then rol := 'kullanici'
  else rol := 'sifre';
  if Kod = 403 then rol := rol + '/red';
  Vt.GunlukEkle(Hat, rol, Yontem, Yol, Copy(Detay, 1, 120), Kod);
end;

function TWebSrv.GirisSayfasi(const Geri, IlkBaslik, Hat, HatSecenek: string): string;
var
  g: string;
  i: Integer;
begin
  g := Trim(Geri);
  if g = '' then g := '/yonetim.html';
  if (g = '') or (g[1] <> '/') then g := '/yonetim.html';
  for i := Length(g) downto 1 do
    if g[i] in ['<', '>', '"'] then Delete(g, i, 1);
  Result :=
    '<!DOCTYPE html><html lang="tr"><head><meta charset="UTF-8">' +
    '<meta name="viewport" content="width=device-width,initial-scale=1">' +
    '<title>Yonetim Girisi</title>' +
    '<style>body{margin:0;background:#0b0b0b;color:#eee;font-family:Tahoma,sans-serif;' +
    'display:flex;align-items:center;justify-content:center;height:100vh}' +
    '.k{width:340px;text-align:center}' +
    'input,select{width:100%;padding:10px;margin:8px 0;background:#222;color:#fff;border:1px solid #444;border-radius:6px}' +
    'button{padding:10px 22px;background:#12351c;color:#fff;border:1px solid #2a5;border-radius:6px;cursor:pointer;margin:4px}' +
    '.h{color:#aa6;font-size:13px;margin-bottom:6px}' +
    '.y{margin-top:18px;border-top:1px solid #333;padding-top:12px}' +
    '.y input{width:60%;display:inline-block;margin-right:6px}</style></head><body>' +
    '<div class="k"><h2>Makinist Takip</h2><div class="h">' + IlkBaslik + '</div>' +
    '<select id="h">' + HatSecenek + '</select>' +
    '<input id="s" type="password" placeholder="sifre" autocomplete="off">' +
    '<br><button id="g">Giris</button><div class="h" id="m"></div>' +
    '<script>function secHat(){return document.getElementById("h").value;}' +
    'function g(){var v=document.getElementById("s").value;' +
    'var H=secHat();' +
    'fetch("api/giris?hat="+encodeURIComponent(H),' +
    '{method:"POST",headers:{"Content-Type":"application/json"},' +
    'body:JSON.stringify({sifre:v})}).then(async r=>{var j=await r.json();' +
    'if(j.oturma){try{sessionStorage.setItem("ys_"+H,v);}catch(e){}' +
    'try{if(j.yonetici){sessionStorage.setItem("yonetici","1");}else{sessionStorage.removeItem("yonetici");}}catch(e){}' +
    'location.href="/yonetim.html?hat="+encodeURIComponent(H)+"&oturma="+j.oturma;}' +
    'else{document.getElementById("m").textContent=j.hata||"hatali";}});}' +
    'document.getElementById("g").onclick=g;' +
    'document.getElementById("s").onkeydown=function(e){if(e.key==="Enter")g();};</script>' +
    '</body></html>';
end;

{ Artik dosya yok. Veri tek .odb dosyasinda; her istekte oradan okunur.
  Bu yordam geriye donuk uyumluluk icin birakildi. }
procedure TWebSrv.Yukle(H: THatStore);
begin
end;

procedure TWebSrv.GerekirseYenidenYukle(H: THatStore);
begin
end;

{ Yazma islemleri veritabanina aninda gider (AyarYaz/Ekle/Degistir/Sil).
  Kaydet artik gerekmez; eski cagri noktalariyla uyum icin bos. }
procedure TWebSrv.Kaydet(H: THatStore);
begin
end;

{ Cevrimdisi pano snapshot'i JSON idi; kaldirildi. Veritabani tek
  dosya oldugu icin ayrica kopya gerekmez: dosya ayni yerde durur,
  bozulursa motor .bak/CRC ile kendini onarir. }
procedure TWebSrv.AnlikGoruntuYaz(H: THatStore);
begin
end;

function TWebSrv.SonrakiId(H: THatStore; const Adi: string): string;
begin
  Result := '';
  if H = nil then Exit;
  Result := Vt.SonrakiId(H.Hat, UpperCase(Trim(Adi)));
end;


{ Tabloyu veritabanindan okur ve JSON dizisi olarak dondurur.
  Donen dizi KOPYADIR: cagirani degistirirse TabloKaydet ile yazmalidir.
  Hat izolasyoni MtData icinde zorlanir (fiziksel tablo {HAT}_{Tablo}). }

{ Anahtar kolona gore karsilastirma. Motor tum degerleri metin sakladigi
  icin ORDER BY metin sirasi verir: 1,10,11,...,2. CIZELGE gibi dizi
  sirasina bagli tablolarda bu hatayi yapar; burada sayisal varsa
  sayisal karsilastirilir. }
function AnahtarKarsilastir(const A, B: string): Integer;
var
  IA, IB: Int64;
begin
  if (TryStrToInt64(A, IA)) and (TryStrToInt64(B, IB)) then
  begin
    if IA < IB then Result := -1
    else if IA > IB then Result := 1
    else Result := 0;
    Exit;
  end;
  Result := AnsiCompareText(A, B);
  if Result < 0 then Result := -1
  else if Result > 0 then Result := 1;
end;

function TWebSrv.OnbellekGet(const Anahtar: string): string;
var
  I: Integer;
  K: TOnbellekKaydi;
begin
  Result := '';
  I := FOnbellek.IndexOf(Anahtar);
  if I < 0 then Exit;
  K := TOnbellekKaydi(FOnbellek.Objects[I]);
  if K = nil then Exit;
  if K.Surum <> Vt.Versiyon then
  begin
    { Veri degisti: bu kaydi at. }
    K.Free;
    FOnbellek.Delete(I);
    Exit;
  end;
  Result := K.Metin;
end;

procedure TWebSrv.OnbellekKoy(const Anahtar, Metin: string);
var
  I: Integer;
  K: TOnbellekKaydi;
begin
  if Metin = '' then Exit;
  I := FOnbellek.IndexOf(Anahtar);
  if I >= 0 then
  begin
    TOnbellekKaydi(FOnbellek.Objects[I]).Free;
    FOnbellek.Delete(I);
  end;
  K := TOnbellekKaydi.Create;
  K.Surum := Vt.Versiyon;
  K.Metin := Metin;
  FOnbellek.AddObject(Anahtar, K);
end;

procedure SiralaInt(var A: TIntDizi);
var
  I, J, V: Integer;
begin
  for I := 1 to High(A) do
  begin
    V := A[I];
    J := I - 1;
    while (J >= 0) and (A[J] > V) do
    begin
      A[J + 1] := A[J];
      Dec(J);
    end;
    A[J + 1] := V;
  end;
end;

{ Sirali iki saat listesinden "sonraki sefer" farkini uretir. Sonraki karsilik
  yoksa ilk karsiliga 86400 eklenir (gece yarisi gecisi).
  TStringList'in sozelik siralamasi kullanilmaz ("900" > "1000" der); saatler
  TIntDizi icine alinip SAYISAL siralanir. }
procedure BacaklariHesapla(const G, D: TStringList; var t1, t2: TIntDizi);
var
  K, Q, P, W, Ng, Nd, i: Integer;
  gv, dv: TIntDizi;
begin
  Ng := G.Count;
  Nd := D.Count;
  if (Ng = 0) or (Nd = 0) then Exit;
  SetLength(gv, Ng);
  SetLength(dv, Nd);
  for K := 0 to Ng - 1 do gv[K] := StrToIntDef(G[K], 0);
  for K := 0 to Nd - 1 do dv[K] := StrToIntDef(D[K], 0);
  SiralaInt(gv);
  SiralaInt(dv);
  for K := 0 to Ng - 1 do
  begin
    P := gv[K];
    W := -1;
    for Q := 0 to Nd - 1 do
      if dv[Q] > P then
      begin
        W := dv[Q];
        Break;
      end;
    if W < 0 then W := dv[0] + 86400;
    i := Length(t1);
    SetLength(t1, i + 1);
    t1[i] := W - P;
  end;
  for K := 0 to Nd - 1 do
  begin
    P := dv[K];
    W := -1;
    for Q := 0 to Ng - 1 do
      if gv[Q] > P then
      begin
        W := gv[Q];
        Break;
      end;
    if W < 0 then W := gv[0] + 86400;
    i := Length(t2);
    SetLength(t2, i + 1);
    t2[i] := W - P;
  end;
end;

function Medyan(A: TIntDizi): Integer;
var
  B: TIntDizi;
begin
  Result := 0;
  if Length(A) = 0 then Exit;
  B := Copy(A, 0, Length(A));
  SiralaInt(B);
  Result := B[Length(B) div 2];
end;

{ Toplam tur suresini AYAR tablosundan DEGIL, saat tablosundan turetir:
  ayni sefer icin gidis ve donus kacisi medyani toplanir.

  Neden ayardan okunmuyor: TOPLAMTURSURESI elle girilmis ve hatta gore
  kopyalanmis bir deger. M8 icin 3055 dogru; T4'e ayni deger yazildigi
  halde T4'un gercek turu 7320-8220 sn (2 saat). Elle deger hem hatali
  hem de saat tablosu degisince bayat kaliyor. Tek dogru kaynak saat
  tablosudur; kayitli ayar yalnizca saat tablosu bos hatlarda yedektir.

  MEDYAN (ortalama degil) kullanilir: tek bozuk kayit tum olcegi
  saptirmasin.

  Motor kisitlari: "SELECT kolon, 'sabit' AS alias FROM tablo" kromlaniyor
  (FROM'suz SELECT saniliyor) ve her hatta ayri tablo oldugu icin iki
  tablo zaten ayri okunmali; eslestirme tamamen bellekte yapilir.

  TDictionary kullanilmaz: FPC objfpc modunda generic sinif derlenmiyor
  (bu unit {$mode objfpc}). Anahtar sayisi yuzlerle sinirli oldugu icin
  dogrusal arama yeterli ve daha okunabilir. }
function TWebSrv.TurSuresiTuret(H: THatStore; const Ttid: string): Integer;
var
  gArr, dArr: TJSONArray;
  I, K, Ng, Nd: Integer;
  gK, gV, dK, dV: array of string;
  Anahtarlar: TStringList;
  Lg, Ld: TStringList;
  t1, t2: TIntDizi;
  r: TJSONObject;
  ks: string;
  V: Integer;
begin
  Result := 0;
  if (H = nil) or (Ttid = '') then Exit;

  gArr := TabloArr(H, 'TIMETABLE');
  dArr := TabloArr(H, 'TIMETABLECEK');
  Anahtarlar := TStringList.Create;
  SetLength(t1, 0);
  SetLength(t2, 0);
  try
    Ng := 0;
    Nd := 0;
    SetLength(gK, 0); SetLength(gV, 0);
    SetLength(dK, 0); SetLength(dV, 0);

    if gArr <> nil then
      for I := 0 to gArr.Count - 1 do
      begin
        r := TJSONObject(gArr.Items[I]);
        if r = nil then Continue;
        if (JAlan(r, 'TTID') <> Ttid) or (JAlan(r, 'SILINMIS') <> '0') then Continue;
        V := SureCevir(JAlan(r, 'SAAT'));
        if V < 0 then Continue;
        { Eslestirme anahtari once RUN (gidis ve donus ayni seferi
          paylasir); RUN yoksa gidis numarasi kullanilir. }
        ks := Trim(JAlan(r, 'RUN'));
        if ks <> '' then ks := 'R' + ks else ks := 'G' + Trim(JAlan(r, 'NUMARA'));
        SetLength(gK, Ng + 1); SetLength(gV, Ng + 1);
        gK[Ng] := ks; gV[Ng] := IntToStr(V);
        if Anahtarlar.IndexOf(ks) < 0 then Anahtarlar.Add(ks);
        Inc(Ng);
      end;

    if dArr <> nil then
      for I := 0 to dArr.Count - 1 do
      begin
        r := TJSONObject(dArr.Items[I]);
        if r = nil then Continue;
        if (JAlan(r, 'TTID') <> Ttid) or (JAlan(r, 'SILINMIS') <> '0') then Continue;
        V := SureCevir(JAlan(r, 'SAAT'));
        if V < 0 then Continue;
        ks := Trim(JAlan(r, 'RUN'));
        if ks <> '' then ks := 'R' + ks else ks := 'G' + Trim(JAlan(r, 'NUMARA'));
        SetLength(dK, Nd + 1); SetLength(dV, Nd + 1);
        dK[Nd] := ks; dV[Nd] := IntToStr(V);
        Inc(Nd);
      end;

    if (Ng = 0) or (Nd = 0) then Exit;

    for I := 0 to Anahtarlar.Count - 1 do
    begin
      Lg := TStringList.Create;
      Ld := TStringList.Create;
      try
        Lg.Duplicates := dupAccept;
        Ld.Duplicates := dupAccept;
        for K := 0 to Ng - 1 do
          if gK[K] = Anahtarlar[I] then Lg.Add(gV[K]);
        for K := 0 to Nd - 1 do
          if dK[K] = Anahtarlar[I] then Ld.Add(dV[K]);
        Lg.Sort;
        Ld.Sort;
        if (Lg.Count > 0) and (Ld.Count > 0) then
          BacaklariHesapla(Lg, Ld, t1, t2);
      finally
        Ld.Free;
        Lg.Free;
      end;
    end;

      if (Length(t1) = 0) or (Length(t2) = 0) then Exit;
      Result := Medyan(t1) + Medyan(t2);
      if Result <= 120 then Result := 0;
  finally
    Anahtarlar.Free;
    dArr.Free;
    gArr.Free;
  end;
end;

function TWebSrv.TabloArr(H: THatStore; const Adi: string): TJSONArray;
var
  R: TSqlResult;
  I, J, K, PkIdx, SatirNo: Integer;
  Satir: TJSONObject;
  A, Pk, Metin: string;
  Sirali: array of Integer;
begin
  Result := nil;
  if H = nil then Exit;
  A := UpperCase(Trim(Adi));
  if not TabloGecerli(A) then Exit;
  { Fotograf BLOB'lari onbellege alinmaz (hem yer hem sure). }
  if A <> 'MAKINISTRESIM' then
  begin
    Metin := OnbellekGet(H.Hat + '|' + A);
    if Metin <> '' then
    begin
      try
        Result := TJSONArray(GetJSON(Metin));
      except
        Result := nil;
      end;
      if Result <> nil then Exit;
    end;
  end;
  Result := TJSONArray.Create;
  try
    R := Vt.TumSatirlar(H.Hat, A);
  except
    on E: Exception do Exit;   { tablo yoksa bos dizi }
  end;

  { Satirlari birincil anahtara gore sayisal sirala }
  Pk := Vt.AnahtarAlani(H.Hat, A);
  PkIdx := -1;
  if Pk <> '' then
    for K := 0 to High(R.Fields) do
      if SameText(R.Fields[K], Pk) then
      begin
        PkIdx := K;
        Break;
      end;
  SetLength(Sirali, Length(R.Rows));
  for I := 0 to High(Sirali) do Sirali[I] := I;
  if (PkIdx >= 0) and (Length(R.Rows) > 1) then
    for I := 1 to High(Sirali) do
    begin
      K := Sirali[I];
      J := I - 1;
      while J >= 0 do
      begin
        if AnahtarKarsilastir(R.Rows[Sirali[J]][PkIdx], R.Rows[K][PkIdx]) <= 0 then
          Break;
        Sirali[J + 1] := Sirali[J];
        Dec(J);
      end;
      Sirali[J + 1] := K;
    end;

  for SatirNo := 0 to High(Sirali) do
  begin
    I := Sirali[SatirNo];
    Satir := TJSONObject.Create;
    for K := 0 to High(R.Fields) do
      if Length(R.Rows[I]) > K then
        { Motor alan adlarini kucuk harfle dondurur; arayuz BUYUK HARF
          bekler (SILINMIS, SICIL, G1, TTID ...). }
        Satir.Add(UpperCase(R.Fields[K]), R.Rows[I][K]);
    Result.Add(Satir);
  end;
  if A <> 'MAKINISTRESIM' then
    OnbellekKoy(H.Hat + '|' + A, Result.AsJSON);
end;

{ JSON dizisini veritabanindaki tabloya yazar (tam degistirme).
  Once bosaltir, sonra satirlari toplu ekler; tek islemde olur. }
function TWebSrv.TabloKaydet(H: THatStore; const Adi: string;
  const Satirlar: TJSONArray): Boolean;
var
  A, Sutun, D: string;
  I, K, KB, SutIdx: Integer;
  Satir: TJSONObject;
  Sutunlar, Alanlar, Degerler: TStringList;
  VarMi: Boolean;
begin
  Result := False;
  if H = nil then Exit;
  A := UpperCase(Trim(Adi));
  if not TabloGecerli(A) then Exit;
  if A = 'MAKINISTRESIM' then Exit;  { fotograf BLOB: ozel yol }
  VarMi := Vt.TabloVar(H.Hat, A);
  if not VarMi then
  begin
    { Yeni tablo: JSON'daki kolonlari semaya cevir. }
    if (Satirlar = nil) or (Satirlar.Count = 0) then Exit;
    Sutunlar := TStringList.Create;
    try
      Satir := TJSONObject(Satirlar.Items[0]);
      if (Satir = nil) or (Satir.JSONType <> jtObject) then Exit;
      for K := 0 to Satir.Count - 1 do
        Sutunlar.Add(UpperCase(Satir.Names[K]));
      Alanlar := TStringList.Create;
      try
        if Sutunlar.IndexOf('ID') >= 0 then Alanlar.Add('ID')
        else Alanlar.Add(Sutunlar[0]);
        if not Vt.TabloOlustur(H.Hat, A, Sutunlar, Alanlar) then Exit;
      finally
        Alanlar.Free;
      end;
    finally
      Sutunlar.Free;
    end;
  end;

  Sutunlar := Vt.Sutunlar(H.Hat, A);
  try
    if Sutunlar.Count = 0 then Exit;

    { --- VERI KAYBI KORUMASI -----------------------------------------
      Bosaltmak Once, dogrulamak sonra yapilirsa bos dizi gonderimi tabloyu
      sessizce siler (arayuzdeki basarisiz bir yukleme [] dondurdugunde
      olurdu). Bu yuzden:
        1) Bos veya gecersiz govde hicbir zaman yazma yapmaz.
        2) Satir SAYISI AZALAN yazimlarda onceki halin guvenlik yedegi
           alinir; hatali kayit /api/geri-yukle ile geri alinabilir.
      Tamamen bosaltmak isteyen ayrica bir yol olmali; bu yol bilerek
      kullanilmadigi surece kaza ile mumkun degildir. }
    if (Satirlar = nil) or (Satirlar.Count = 0) then
    begin
      WriteLn(FormatDateTime('hh:nn:ss', Now) +
        ' YAZMA REDDEDILDI (bos govde): ' + H.Hat + '_' + A);
      Exit;
    end;
    for I := 0 to Satirlar.Count - 1 do
      if (Satirlar.Items[I] = nil) or (Satirlar.Items[I].JSONType <> jtObject) then
      begin
        WriteLn(FormatDateTime('hh:nn:ss', Now) +
          ' YAZMA REDDEDILDI (gecersiz satir): ' + H.Hat + '_' + A);
        Exit;
      end;

    TabloYazmaGuvenligi(H.Hat, A, Vt.SatirSayisi(H.Hat, A), Satirlar.Count);

    Vt.Bosalt(H.Hat, A);
    { Her satiri semadaki tum kolonlara gore normalize et. }
    Alanlar := TStringList.Create;
    Degerler := TStringList.Create;
    try
      for I := 0 to Satirlar.Count - 1 do
      begin
        if (Satirlar.Items[I] = nil) or (Satirlar.Items[I].JSONType <> jtObject) then
          Continue;
        Satir := TJSONObject(Satirlar.Items[I]);
        for KB := 0 to Sutunlar.Count - 1 do
        begin
          Sutun := Sutunlar[KB];
          SutIdx := -1;
          for K := 0 to Satir.Count - 1 do
            if SameText(Satir.Names[K], Sutun) then
            begin
              SutIdx := K;
              Break;
            end;
          if SutIdx >= 0 then D := Satir.Items[SutIdx].AsString
          else D := '';
          { RESIM kolonu base64 gelir; ham bayta cevir. }
          if SameText(Sutun, 'RESIM') and (D <> '') then
            D := DecodeStringBase64(D);
          Alanlar.Add(Sutun);
          Degerler.Add(D);
        end;
        if Alanlar.Count > 0 then
          try
            Vt.Ekle(H.Hat, A, Alanlar, Degerler);
          except
            on E: Exception do ;
          end;
        Alanlar.Clear;
        Degerler.Clear;
      end;
    finally
      Alanlar.Free;
      Degerler.Free;
    end;
  finally
    Sutunlar.Free;
  end;
  Result := True;
end;

{ Tablonun JSON metnini dondurur. Onbellekte varsa DOGRUDAN verilir:
  ayristirip yeniden serilestirmeye gerek yok (574 satirlik TIMETABLE
  icin 59 ms -> birkac ms). }
function TWebSrv.TabloMetin(H: THatStore; const Adi: string): string;
var
  A, Metin: string;
  arr: TJSONArray;
begin
  Result := '';
  if H = nil then Exit;
  A := UpperCase(Trim(Adi));
  if not TabloGecerli(A) then Exit;
  if A = 'MAKINISTRESIM' then Exit;   { BLOB: metin olarak dondurulmez }
  Metin := OnbellekGet(H.Hat + '|' + A);
  if Metin <> '' then Exit(Metin);
  arr := TabloArr(H, A);
  if arr = nil then Exit;
  try
    Result := arr.AsJSON;
  finally
    arr.Free;
  end;
end;

function TWebSrv.AyarJson(H: THatStore): string;
var
  Metin: string;
begin
  if H = nil then Exit('{}');
  Metin := OnbellekGet(H.Hat + '|@AYAR');
  if Metin <> '' then Exit(Metin);
  Result := AyarJsonSifir(H);
  OnbellekKoy(H.Hat + '|@AYAR', Result);
end;

function TWebSrv.AyarJsonSifir(H: THatStore): string;
var
  o: TJSONObject;
  Anahtarlar: TStringList;
  i: Integer;
begin
  o := TJSONObject.Create;
  try
    if H <> nil then
    begin
      Anahtarlar := Vt.AyarAnahtarlari(H.Hat);
      try
        for i := 0 to Anahtarlar.Count - 1 do
          o.Add(Anahtarlar[i], Vt.AyarOku(H.Hat, Anahtarlar[i]));
      finally
        Anahtarlar.Free;
      end;
    end;
    Result := o.AsJSON;
  finally
    o.Free;
  end;
end;

function TWebSrv.AyarOku(H: THatStore; const Alan: string): string;
var
  Metin: string;
  jd: TJSONData;
begin
  Result := '';
  if H = nil then Exit;
  Metin := OnbellekGet(H.Hat + '|@AYAR');
  if Metin <> '' then
  begin
    jd := GetJSON(Metin);
    try
      if (jd <> nil) and (jd.JSONType = jtObject) then
        Result := JAlan(TJSONObject(jd), Alan);
    finally
      jd.Free;
    end;
    Exit;
  end;
  Result := AyarJson(H);
  OnbellekKoy(H.Hat + '|@AYAR', Result);
end;

procedure TWebSrv.AyarYaz(H: THatStore; const Alan, Deger: string);
begin
  if H = nil then Exit;
  Vt.AyarYaz(H.Hat, Alan, Deger);
end;

function TWebSrv.SureCevir(const S: string): Integer;
var
  p1, p2: Integer;
  h, m, sn: Integer;
  t: string;
begin
  Result := 0;
  t := Trim(S);
  p1 := Pos(':', t);
  if p1 = 0 then Exit;
  p2 := Pos(':', Copy(t, p1 + 1, 99));
  if p2 > 0 then p2 := p1 + p2;
  h := StrToIntDef(Copy(t, 1, p1 - 1), 0);
  if p2 > 0 then
  begin
    m := StrToIntDef(Copy(t, p1 + 1, p2 - p1 - 1), 0);
    sn := StrToIntDef(Copy(t, p2 + 1, 99), 0);
  end
  else
  begin
    m := StrToIntDef(Copy(t, p1 + 1, 99), 0);
    sn := 0;
  end;
  Result := h * 3600 + m * 60 + sn;
end;

function TWebSrv.SureYaz(Sn: Integer): string;
var
  h, m, s: Integer;
begin
  Sn := ((Sn mod 86400) + 86400) mod 86400;
  h := Sn div 3600; m := (Sn mod 3600) div 60; s := Sn mod 60;
  Result := Format('%.2d:%.2d:%.2d', [h, m, s]);
end;

function TWebSrv.TTIdSec(H: THatStore): string;
var
  dow: Integer;
begin
  // Pascal DayOfTheWeek: Pzt=1 ... Paz=7 (onurmakinist.pas:404-422 ile ayni)
  dow := DayOfTheWeek(Now);
  if AyarOku(H, 'TARIFEOROMANUEL') = 'True' then
  begin
    case dow of
      1: Result := AyarOku(H, 'TIMETABLEPZT_ID');
      2: Result := AyarOku(H, 'TIMETABLESAL_ID');
      3: Result := AyarOku(H, 'TIMETABLECAR_ID');
      4: Result := AyarOku(H, 'TIMETABLEPER_ID');
      5: Result := AyarOku(H, 'TIMETABLECUM_ID');
      6: Result := AyarOku(H, 'TIMETABLECMT_ID');
      7: Result := AyarOku(H, 'TIMETABLEPZR_ID');
    else
      Result := AyarOku(H, 'TIMETABLE_ID');
    end;
  end
  else
    Result := AyarOku(H, 'TIMETABLE_ID');
  if Result = '' then Result := '0';
end;

function TWebSrv.GunKolon: string;
begin
  // onurmakinist.pas:559 -> 'G' + ayin gunu
  Result := 'G' + IntToStr(DayOfTheMonth(Now));
end;

function TWebSrv.PanoHesapla(H: THatStore; const TTId, Gun, SuanStr, Yon, AMod: string): TJSONObject;
var
  src, srcC: TJSONArray;
  tt, ttC: array of record
    gorev, saat, run, dizi, hat, cikar, disi, kontrol: string;
  end;
  i, n, k, idx, hangitur, toplamTur: Integer;
  suan, ref, s, sure1, sure2, hw: Integer;
  gk, wtid, wyon, wmod: string;
  mk: array[1..11] of record
    gorev, sicil, adi, run, dizi, hat: string;
    hareket, tur: Integer;
    cikar, disi, kontrol: string;
  end;
  arr, crow: TJSONArray;
  o, r: TJSONObject;
  jd: TJSONData;
  manevStr, hv, dtAd, dtHafta, dtYaz, hgrup, hbas: string;
  aks, ms1, ms2: Integer;
  mno, tmpSicil, tmpAdi, numStr, ilkNo, parca: string;
  aksab: Integer;
  rosArr: array of string;
  mArr, aArr: TJSONArray;
  msgArr, lArr: TJSONArray;
  rr: TJSONObject;
  gi: Integer;
  gunFark, gi2, gidx: Integer;
  sabahMi, aksamMi: Boolean;
  ug, uk: TStringList;

  function KaynakTablo(const Kaynak, Id: string): TJSONArray;
  var
    a: TJSONArray;
    j: Integer;
    rr: TJSONObject;
    jd: TJSONData;
    out_: TJSONArray;
    no: TJSONObject;
    function Alan(x: TJSONObject; f: string): string;
    var d: TJSONData; begin
      Result := '';
      d := x.Find(f);
      if d <> nil then Result := d.AsString;
    end;
  begin
    out_ := TJSONArray.Create;
    a := TabloArr(H, Kaynak);
    try
      if a <> nil then
        for j := 0 to a.Count - 1 do
        begin
          jd := a.Items[j];
          if (jd = nil) or (jd.JSONType <> jtObject) then Continue;
          rr := TJSONObject(jd);
          if (Alan(rr, 'TTID') = Id) and (Alan(rr, 'SILINMIS') = '0') then
          begin
            no := TJSONObject.Create;
            no.Add('gorev', Alan(rr, 'NUMARA'));
            no.Add('saat', Alan(rr, 'SAAT'));
            no.Add('run', Alan(rr, 'RUN'));
            no.Add('dizi', Alan(rr, 'DIZI'));
            no.Add('hat', Alan(rr, 'HATID'));
            no.Add('cikar', Alan(rr, 'ARACCIKAR'));
            no.Add('disi', Alan(rr, 'ARACSDISI'));
            no.Add('kontrol', Alan(rr, 'ARACKONTROL'));
            out_.Add(no);
          end;
        end;
    finally
      { TIMETABLE ve TIMETABLECEK icin cagrilir; T4'te agac basina ~3.6 MB.
        Birakilirsa her /api/pano isteginde o kadar birikiyordu. }
      a.Free;
    end;
    Result := out_;
  end;

  function AracSaatleri(girisMi, yonBir: Boolean): TStringList;
  var
    a: TJSONArray;
    j: Integer;
    rr: TJSONObject;
  begin
    Result := TStringList.Create;
    a := TabloArr(H, 'ARACGRSLISTESI');
    try
      if a = nil then Exit;
      for j := 0 to a.Count - 1 do
      begin
        if (a.Items[j] = nil) or (a.Items[j].JSONType <> jtObject) then Continue;
        rr := TJSONObject(a.Items[j]);
        if (JAlan(rr, 'TTID') <> wtid) or (JAlan(rr, 'SILINMIS') <> '0') then Continue;
        if ((JAlan(rr, 'GIRISMI') = '1') = girisMi) and
          ((JAlan(rr, 'HANGIYON') = '1') = yonBir) then
          Result.Add(JAlan(rr, 'SAAT'));
      end;
    finally
      a.Free;   { TabloArr yeni agac donduruyor; serbest birakilmazsa
                   her istekte sizar (ARACGRSLISTESI kucuk ama
                   PanoJson icinde 5 agac birden birikiyor) }
    end;
  end;


  function SaatteVar(list: TStringList; hareket: Integer): Boolean;
  var
    j, v: Integer;
  begin
    Result := False;
    for j := 0 to list.Count - 1 do
    begin
      v := SureCevir(list[j]);
      if (v = hareket) or (v + 86400 = hareket) then Exit(True);
    end;
  end;

  function CizelgeBul(const GorevNo: string; out Sicil, Adi: string): Boolean;
  var
    a: TJSONArray;
    j: Integer;
    rr: TJSONObject;
    d: TJSONData;
  begin
    Result := False; Sicil := '0'; Adi := '';
    a := TabloArr(H, 'CIZELGE');
    try
      if a = nil then Exit;
      for j := 0 to a.Count - 1 do
      begin
        d := a.Items[j];
        if (d = nil) or (d.JSONType <> jtObject) then Continue;
        rr := TJSONObject(d);
        if rr.Find('SILINMIS') <> nil then
          if rr.Find('SILINMIS').AsString <> '0' then Continue;
        d := rr.Find(gk);
        if (d <> nil) and (GorevNorm(d.AsString) = GorevNorm(GorevNo)) then
        begin
          if rr.Find('SICIL') <> nil then Sicil := rr.Find('SICIL').AsString;
          if rr.Find('ADI') <> nil then Adi := rr.Find('ADI').AsString;
          Result := True;
          Exit;
        end;
      end;
    finally
      a.Free;   { CIZELGE 36 satir x 31 G sutunu: en buyuk agac.
                   Bu yordam PanoJson icinde manevra satirinda cagriliyor,
                   birakilirsa her istekte onlarca kez sizardi. }
    end;
  end;

begin
  Result := TJSONObject.Create;
  gk := Gun; wtid := TTId; wyon := Yon; wmod := LowerCase(AMod);
  if gk = '' then gk := GunKolon;
  if wtid = '' then wtid := TTIdSec(H);
  if wyon = '' then wyon := AyarOku(H, 'YON');
  if wyon = '' then wyon := '0';
  suan := SureCevir(SuanStr);
  if SuanStr = '' then
    suan := HourOf(Now) * 3600 + MinuteOf(Now) * 60 + SecondOf(Now);
  { mod belirtilmediyse server AYARLAR'i gecerli (admin komutlari aninda yansir) }
  if (wmod = '') or (wmod = 'auto') then
  begin
    if AyarOku(H, 'NUMARALI') = 'True' then wmod := 'numarali' else wmod := 'sirali';
  end
  else if (wmod <> 'sirali') then wmod := 'numarali';

  src := KaynakTablo('TIMETABLE', wtid);
  srcC := KaynakTablo('TIMETABLECEK', wtid);
  try
    if wyon = '0' then
    begin
      // ttableli=TIMETABLE, C=TIMETABLECEK (Pascal ile ayni)
    end;
    // yon=1 ise kaynaklari degistir
    if wyon <> '0' then
    begin
      arr := src; src := srcC; srcC := arr;
    end;
    n := src.Count;
    SetLength(tt, n);
    for i := 0 to n - 1 do
    begin
      r := TJSONObject(src.Items[i]);
      tt[i].gorev := r.Get('gorev', '');
      tt[i].saat := r.Get('saat', '');
      tt[i].run := r.Get('run', '');
      tt[i].dizi := r.Get('dizi', '');
      tt[i].hat := r.Get('hat', '');
      tt[i].cikar := r.Get('cikar', '');
      tt[i].disi := r.Get('disi', '');
      tt[i].kontrol := r.Get('kontrol', '');
    end;
    SetLength(ttC, srcC.Count);
    for i := 0 to srcC.Count - 1 do
    begin
      r := TJSONObject(srcC.Items[i]);
      ttC[i].gorev := r.Get('gorev', '');
      ttC[i].saat := r.Get('saat', '');
      ttC[i].run := r.Get('run', '');
      ttC[i].dizi := r.Get('dizi', '');
      ttC[i].hat := r.Get('hat', '');
      ttC[i].cikar := r.Get('cikar', '');
      ttC[i].disi := r.Get('disi', '');
      ttC[i].kontrol := r.Get('kontrol', '');
    end;
  finally
    src.Free;
    srcC.Free;
  end;

  for k := 1 to 11 do
  begin
    mk[k].gorev := '0'; mk[k].sicil := '0'; mk[k].adi := '';
    mk[k].run := '0'; mk[k].dizi := '4'; mk[k].hat := 'X--X';
    mk[k].hareket := 0; mk[k].tur := 0;
    mk[k].cikar := '0'; mk[k].disi := '0'; mk[k].kontrol := '0';
  end;

  // arac listeleri (satir bayragi yoksa yedek: exe ile ayni saat eslemesi)
  ug := AracSaatleri(True, True);
  uk := AracSaatleri(False, True);
  try

  // Hangitur: suan'a esit/buyuk ilk sefer (gece +86400 toleransi)
  hangitur := 0;
  if suan < 18000 then ref := suan + 86400 else ref := suan;
  for i := 0 to n - 1 do
  begin
    s := SureCevir(tt[i].saat);
    if s < 14400 then s := s + 86400;
    if ref <= s then begin hangitur := i; Break; end;
    if i = n - 1 then hangitur := n - 1;
  end;

  if wmod = 'numarali' then
  begin
    for k := 1 to 11 do
    begin
      idx := hangitur + (k - 1);
      if idx < n then
      begin
        s := SureCevir(tt[idx].saat);
        if s < 14400 then s := s + 86400;
        mk[k].hareket := s;
        mk[k].run := tt[idx].run;
        mk[k].dizi := tt[idx].dizi;
        mk[k].hat := tt[idx].hat;
        mk[k].cikar := tt[idx].cikar;
        mk[k].disi := tt[idx].disi;
        mk[k].kontrol := tt[idx].kontrol;
        if (mk[k].cikar <> '1') and SaatteVar(ug, s) then mk[k].cikar := '1';
        if (mk[k].disi <> '1') and SaatteVar(uk, s) then mk[k].disi := '1';
        if CizelgeBul(tt[idx].gorev, mk[k].sicil, mk[k].adi) then
          mk[k].gorev := tt[idx].gorev
        else
        begin
          mk[k].adi := 'SMAMP BULUNAMADI..';
          mk[k].gorev := '0';
        end;
      end;
    end;
    for k := 1 to 3 do
      for i := hangitur downto 0 do
        if (mk[k].gorev <> '0') and (mk[k].gorev <> '') and (tt[i].gorev = mk[k].gorev) then
          Inc(mk[k].tur);
  end
  else
  begin
    for k := 1 to 11 do
    begin
      idx := hangitur + (k - 1);
      if idx < n then
      begin
        s := SureCevir(tt[idx].saat);
        if s < 14400 then s := s + 86400;
        mk[k].hareket := s;
        mk[k].gorev := tt[idx].gorev;
        mk[k].run := tt[idx].run;
        mk[k].dizi := tt[idx].dizi;
        mk[k].hat := tt[idx].hat;
        mk[k].cikar := tt[idx].cikar;
        mk[k].disi := tt[idx].disi;
        mk[k].kontrol := tt[idx].kontrol;
        if (mk[k].cikar <> '1') and SaatteVar(ug, s) then mk[k].cikar := '1';
        if (mk[k].disi <> '1') and SaatteVar(uk, s) then mk[k].disi := '1';
      end;
    end;
  end
  finally
    ug.Free;
    uk.Free;
  end;

  // headway + trensayisi (Pascal ile ayni formul)
  if hangitur + 1 >= n then
  begin
    hw := 0;
  end
  else
  begin
    if hangitur = 0 then
    begin
      sure1 := SureCevir(tt[hangitur].saat);
      sure2 := SureCevir(tt[hangitur + 1].saat);
    end
    else
    begin
      sure1 := SureCevir(tt[hangitur - 1].saat);
      sure2 := SureCevir(tt[hangitur].saat);
    end;
    if (sure1 > 0) and (sure1 < 14400) then sure1 := sure1 + 86400;
    hw := sure2 - sure1;
    if hw <= 0 then hw := 1;
  end;
  { Toplam tur suresi: ONCE saat tablosundan turetilir. Elle girilmis
    TOPLAMTURSURESI yalnizca saat tablosu bos/yetersiz oldugunda yedektir
    (M4/M5/T1 gibi henuz sefer tanimlanmamis hatlar). }
  toplamTur := TurSuresiTuret(H, wtid);
  if toplamTur <= 0 then
  begin
    toplamTur := StrToIntDef(AyarOku(H, 'TOPLAMTURSURESI'), 0);
    if toplamTur <= 0 then toplamTur := 4800;
  end;

  { --- sag panel verileri (anasayfa.pas yenidenyaz ile ayni kaynaklar) --- }
  aks := SureCevir(AyarOku(H, 'AKSAMBASLAMASAATI'));
  if (aks > 0) and (suan >= aks) then hv := 'AKÅAM' else hv := 'SABAH';

  dtAd := ''; dtHafta := ''; dtYaz := '';
  aArr := TabloArr(H, 'TTDETAY');
  try
    if aArr <> nil then
      for i := 0 to aArr.Count - 1 do
      begin
        jd := aArr.Items[i];
        if (jd <> nil) and (jd.JSONType = jtObject) and
          (JAlan(TJSONObject(jd), 'ID') = wtid) then
        begin
          dtAd := JAlan(TJSONObject(jd), 'ADI');
          dtHafta := JAlan(TJSONObject(jd), 'HAFTAICISONU');
          dtYaz := JAlan(TJSONObject(jd), 'YAZKIS');
          Break;
        end;
      end;
  finally
    aArr.Free;
  end;

  manevStr := 'MANEVRACI YOK';
  mArr := TabloArr(H, 'MANEVRA');
  try
    if mArr <> nil then
      for i := 0 to mArr.Count - 1 do
      begin
        jd := mArr.Items[i];
        if (jd = nil) or (jd.JSONType <> jtObject) then Continue;
        rr := TJSONObject(jd);
        if (JAlan(rr, 'TTID') <> wtid) or (JAlan(rr, 'SILINMIS') <> '0') then Continue;
        mno := JAlan(rr, 'GOREVNO');
        ms1 := SureCevir(JAlan(rr, 'BASLANGICSAATI'));
        ms2 := SureCevir(JAlan(rr, 'BITISSAATI'));
        if (ms1 <= suan) and (suan <= ms2) then
          if CizelgeBul(mno, tmpSicil, tmpAdi) and (tmpAdi <> '') then
          begin
            manevStr := Trim(mno + ' ' + UpperCase(tmpAdi));
            Break;
          end;
      end;
  finally
    mArr.Free;
  end;

  { grup + basmakinist: onurmakinist.pas SiralamaYap ile ayni mantik.
    Kadro = gunun filtreli listesi (dosya sirasi); dilim = haftanin gunune gore;
    secim deterministik (exe'deki rastgele secimin ilk adayi). }
  hgrup := ''; hbas := '';
  SetLength(rosArr, 0);
  aArr := TabloArr(H, 'CIZELGE');
  try
    if aArr <> nil then
      for i := 0 to aArr.Count - 1 do
      begin
        jd := aArr.Items[i];
        if (jd = nil) or (jd.JSONType <> jtObject) then Continue;
        rr := TJSONObject(jd);
        if JAlan(rr, 'SILINMIS') <> '0' then Continue;
        if JAlan(rr, gk) = '' then Continue;
        SetLength(rosArr, Length(rosArr) + 1);
        rosArr[High(rosArr)] := GorevNorm(JAlan(rr, gk));
      end;
  finally
    aArr.Free;
  end;
  if AyarOku(H, 'TARIFEOROMANUEL') = 'True' then
    aksab := DayOfTheWeek(Now) - 5
  else
  begin
    if dtHafta = 'CUMARTESÄ°' then aksab := 1
    else if dtHafta = 'PAZAR' then aksab := 2
    else aksab := -1;
  end;
  if hv = 'AKÅAM' then numStr := AyarOku(H, 'AKSAMNUMARALARI')
  else numStr := AyarOku(H, 'SABAHNUMARALARI');
  parca := ParcaAl(numStr, aksab);
  ilkNo := Trim(parca);
  if Pos('-', ilkNo) > 0 then ilkNo := Trim(Copy(ilkNo, 1, Pos('-', ilkNo) - 1));
  { 12 gunluk vardiya dongusu: [4 sabah, 2 izin, 4 aksam, 2 izin].
    Referans: 27.09.2026 = 1. Grup'un aksam 2. gunu (dongu idx 7).
    Gruplar 4'er gun faz farkli. Kadro sirasindan bagimsiz (tarih matematigi). }
  gunFark := Trunc(Now) - Trunc(EncodeDate(2026, 9, 27));
  for gi2 := 1 to 3 do
  begin
    gidx := ((7 + gunFark - (gi2 - 1) * 4) mod 12 + 12) mod 12;
    sabahMi := (gidx >= 0) and (gidx <= 3);
    aksamMi := (gidx >= 6) and (gidx <= 9);
    if ((hv = 'AKÅAM') and aksamMi) or ((hv = 'SABAH') and sabahMi) then
    begin
      hgrup := IntToStr(gi2) + '. GRUP';
      case gi2 of
        1: hbas := AyarOku(H, 'BASMAKINIST1');
        2: hbas := AyarOku(H, 'BASMAKINIST2');
      else hbas := AyarOku(H, 'BASMAKINIST3');
      end;
      Break;
    end;
  end;
  if hgrup = '' then
  begin
    { yedek: eski kadro-sirasi yontemi }
    gi := -1;
    if ilkNo <> '' then
      for i := 0 to High(rosArr) do
        if rosArr[i] = ilkNo then begin gi := i; Break; end;
    if gi >= 0 then
    begin
      if GermAralik(AyarOku(H, 'GRUP1'), gi) then
      begin hgrup := '1. GRUP'; hbas := AyarOku(H, 'BASMAKINIST1'); end
      else if GermAralik(AyarOku(H, 'GRUP2'), gi) then
      begin hgrup := '2. GRUP'; hbas := AyarOku(H, 'BASMAKINIST2'); end
      else if GermAralik(AyarOku(H, 'GRUP3'), gi) then
      begin hgrup := '3. GRUP'; hbas := AyarOku(H, 'BASMAKINIST3'); end;
    end;
  end;

  Result.Add('ttid', wtid);
  Result.Add('gun', gk);
  Result.Add('suan', SureYaz(suan));
  Result.Add('yon', wyon);
  Result.Add('mod', wmod);
  Result.Add('hangitur', hangitur);
  Result.Add('seferSayisi', n);
  Result.Add('sonsefer', (n > 0) and (hangitur >= n - 1));
  if hw = 0 then Result.Add('headway', '00:00:00')
  else Result.Add('headway', SureYaz(hw));
  if hw = 0 then Result.Add('trensayisi', '0')
  else Result.Add('trensayisi', IntToStr(Round(toplamTur / hw)));
  Result.Add('toplamtursuresi', toplamTur);
  Result.Add('seflik', AyarOku(H, 'SEFLIK'));
  Result.Add('manevraci', manevStr);
  Result.Add('hv', hv);
  Result.Add('hgrup', hgrup);
  Result.Add('basmakinist', hbas);
  o := TJSONObject.Create;
  o.Add('adi', dtAd);
  o.Add('hafta', dtHafta);
  o.Add('yazkis', dtYaz);
  Result.Add('ttdetay', o);

  { makinist mesajlari + arac giris/cikis listeleri }
  msgArr := TJSONArray.Create;
  aArr := TabloArr(H, 'MAKINISTEMESAJ');
  try
    if aArr <> nil then
      for i := 0 to aArr.Count - 1 do
      begin
        jd := aArr.Items[i];
        if (jd <> nil) and (jd.JSONType = jtObject) and
          (JAlan(TJSONObject(jd), 'SILINMIS') = '0') and
          MesajAktif(TJSONObject(jd), suan) then
          msgArr.Add(JAlan(TJSONObject(jd), 'MESAJ'));
      end;
  finally
    aArr.Free;
  end;
  Result.Add('mesajlar', msgArr);

  for gi := 0 to 3 do
  begin
    lArr := TJSONArray.Create;
    aArr := TabloArr(H, 'ARACGRSLISTESI');
    try
      if aArr <> nil then
        for i := 0 to aArr.Count - 1 do
        begin
          jd := aArr.Items[i];
          if (jd = nil) or (jd.JSONType <> jtObject) then Continue;
          rr := TJSONObject(jd);
          if (JAlan(rr, 'TTID') <> wtid) or (JAlan(rr, 'SILINMIS') <> '0') then Continue;
          case gi of
            0: if (JAlan(rr, 'GIRISMI') = '1') and (JAlan(rr, 'HANGIYON') = '1') then
                 lArr.Add(JAlan(rr, 'SAAT'));
            1: if (JAlan(rr, 'GIRISMI') <> '1') and (JAlan(rr, 'HANGIYON') = '1') then
                 lArr.Add(JAlan(rr, 'SAAT'));
            2: if (JAlan(rr, 'GIRISMI') = '1') and (JAlan(rr, 'HANGIYON') <> '1') then
                 lArr.Add(JAlan(rr, 'SAAT'));
            3: if (JAlan(rr, 'GIRISMI') <> '1') and (JAlan(rr, 'HANGIYON') <> '1') then
                 lArr.Add(JAlan(rr, 'SAAT'));
          end;
        end;
    finally
      aArr.Free;   { 4 kez cagriliyor: en sik sizan yer burasiydi }
    end;
    case gi of
      0: Result.Add('uskgiris', lArr);
      1: Result.Add('uskcikis', lArr);
      2: Result.Add('cekgiris', lArr);
      3: Result.Add('cekcikis', lArr);
    end;
  end;

  crow := TJSONArray.Create;
  for k := 1 to 11 do
  begin
    if mk[k].hareket = 0 then Continue;
    o := TJSONObject.Create;
    o.Add('no', k);
    o.Add('gorev', mk[k].gorev);
    o.Add('sicil', mk[k].sicil);
    o.Add('adi', mk[k].adi);
    o.Add('run', mk[k].run);
    o.Add('dizi', mk[k].dizi);
    o.Add('hat', mk[k].hat);
    if mk[k].hareket > 86400 then
      o.Add('hareket', SureYaz(mk[k].hareket - 86400))
    else
      o.Add('hareket', SureYaz(mk[k].hareket));
    o.Add('tur', mk[k].tur);
    o.Add('cikar', mk[k].cikar);
    o.Add('disi', mk[k].disi);
    o.Add('kontrol', mk[k].kontrol);
    crow.Add(o);
  end;
  Result.Add('makinist', crow);
end;

function TWebSrv.MimeTip(const FN: string): string;
var
  e: string;
begin
  e := LowerCase(ExtractFileExt(FN));
  if e = '.html' then Result := 'text/html; charset=utf-8'
  else if e = '.json' then Result := 'application/json; charset=utf-8'
  else if e = '.js' then Result := 'application/javascript; charset=utf-8'
  else if e = '.css' then Result := 'text/css; charset=utf-8'
  else if e = '.png' then Result := 'image/png'
  else if e = '.gif' then Result := 'image/gif'
  else if e = '.jpg' then Result := 'image/jpeg'
  else if (e = '.ttf') or (e = '.woff') or (e = '.woff2') then Result := 'font/ttf'
  else Result := 'application/octet-stream';
end;

procedure TWebSrv.StatikSun(const Yol: string; var AResp: TFPHTTPConnectionResponse);
var
  fp: string;
  fs: TFileStream;
begin
  fp := ExpandFileName(IncludeTrailingPathDelimiter(FWebDir) + Yol);
  // path traversal korumasi
  if Pos(ExpandFileName(FWebDir), fp) <> 1 then
  begin
    AResp.Code := 403;
    AResp.Content := 'forbidden';
    Exit;
  end;
  if DirectoryExists(fp) then
    fp := IncludeTrailingPathDelimiter(fp) + 'pano.html';
  if not FileExists(fp) then
  begin
    AResp.Code := 404;
    AResp.Content := 'bulunamadi';
    Exit;
  end;
  AResp.ContentType := MimeTip(fp);
  fs := TFileStream.Create(fp, fmOpenRead or fmShareDenyNone);
  AResp.ContentStream := fs;
  AResp.ContentLength := fs.Size;
  AResp.FreeContentStream := True;
end;

function TWebSrv.KomutIsle(H: THatStore; const Komut: string): string;
var
  k: string;
begin
  Result := '(bilinmeyen komut, islem yok)';
  k := LowerCase(Trim(Komut));
  if k = 'sirali' then
  begin
    AyarYaz(H, 'NUMARALI', 'False');
    Kaydet(H);
    Result := '(numarali -> sirali)';
  end
  else if k = 'numarali' then
  begin
    AyarYaz(H, 'NUMARALI', 'True');
    Kaydet(H);
    Result := '(sirali -> numarali)';
  end
  else if k = 'flash' then
  begin AyarYaz(H, 'FLASHYAPSIN', 'True'); Kaydet(H); Result := '(flash acik)'; end
  else if k = 'flashi' then
  begin AyarYaz(H, 'FLASHYAPSIN', 'False'); Kaydet(H); Result := '(flash kapali)'; end
  else if k = 'kayanyazi' then
  begin AyarYaz(H, 'YAZIKAYSIN', 'True'); Kaydet(H); Result := '(kayan yazi acik)'; end
  else if k = 'kayanyazii' then
  begin AyarYaz(H, 'YAZIKAYSIN', 'False'); Kaydet(H); Result := '(kayan yazi kapali)'; end
  else if k = 'mesaj' then Result := '(mesajlar her yoklamada canli okunuyor)'
  else if (k = 'reset') or (k = 'yenidenyaz') then
    Result := '(pano her yoklamada zaten yeniden hesaplaniyor)'
  else if k = 'vakum' then
  begin Kaydet(H); Result := '(kaydedildi)'; end
  else if k = 'versiyon' then Result := '(server ' + SRV_VERSIYON + ')';
end;

procedure TWebSrv.Istek(Sender: TObject; var ARequest: TFPHTTPConnectionRequest;
  var AResponse: TFPHTTPConnectionResponse);
var
  yol, yol0, q, adi, ttid, gun, suan, yon, amod, sicil, b64, hatQ: string;
  Metin: string;
  tumu: Boolean;
  ltok, lpw, lokHat: string;
  glst: TStringList;
  gi2, gsay: Integer;
  lay, gfyol: string;
  ydDir, ydAd, ydTam, ydOnceki, ydYeni, ydTur: string;
  ydKayit: array of TYedekKaydi;
  ydTmp: TYedekKaydi;
  ydSira: TJSONArray;
  N, J: Integer;
  updYol: string;
  ydSr: TSearchRec;
  ydArr: TJSONArray;
  ydObj: TJSONObject;
  yfs, yfo: TFileStream;
  gjo: TJSONObject;
  gja: TJSONArray;
  arr, yeni: TJSONArray;
  gl: TJSONArray;
  jd: TJSONData;
  fd: TJSONData;
  i, ek, gu, k: Integer;
  rid, fnam: string;
  o: TJSONObject;
  opts: string;
  oi: Integer;
  hedef: TJSONObject;
  fs: TFileStream;
  ms: TMemoryStream;
  raw: RawByteString;
  H: THatStore;
  jdG: TJSONData;
  girSifre: string;
  hs: string;
begin
  AResponse.SetCustomHeader('Access-Control-Allow-Origin', '*');
  AResponse.SetCustomHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  AResponse.SetCustomHeader('Access-Control-Allow-Headers', 'Content-Type');
  if CompareText(ARequest.Method, 'OPTIONS') = 0 then
  begin
    AResponse.Code := 204;
    AResponse.Content := '';
    Exit;
  end;
  yol := TemizYol(ARequest.URI);
  q := Trim(ARequest.QueryString);
  if yol = '' then yol := '/';
  yol0 := yol;
  // yonetim giris kapisi: hat bazli, sifreler data/sifreler.json'da sabit
  // alaninda (sabit). Bos ise o hat aciktir; ilk girilen sifre kaydedilir.
  if (yol = '/api/giris') or (yol = '/api/cikis') then
  begin
    if CompareText(ARequest.Method, 'POST') <> 0 then
    begin
      AResponse.Code := 405;
      AResponse.Content := '';
      Exit;
    end;
    try
      jdG := GetJSON(ARequest.Content);
    except
      jdG := nil;
    end;
    if yol = '/api/cikis' then
    begin
      if (jdG <> nil) and (jdG.JSONType = jtObject) then
        OturumKapat(JAlan(TJSONObject(jdG), 'oturma'));
      jdG.Free;
      AResponse.Content := 'OK';
      Exit;
    end;
  end;
  // /api/islemgunlugu?hat=H|TUMU&oturma=&sifre=&n=&ay=YYYY-MM (TUMU sadece yonetici)
  if yol = '/api/islemgunlugu' then
  begin
      tumu := UpperCase(Trim(QParam(q, 'hat'))) = 'TUMU';
      ltok := QParam(q, 'oturma'); lpw := QParam(q, 'sifre');
      gsay := StrToIntDef(QParam(q, 'n'), 300);
      if gsay < 1 then gsay := 1;
      if gsay > 1000 then gsay := 1000;
      lokHat := '';
      if tumu then
      begin
        if not OturumYonetici(ltok) then
        begin
          AResponse.Code := 403;
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := '{"hata":"sadece yonetici"}';
          Exit;
        end;
      end
      else
      begin
        H := HatBul(QParam(q, 'hat'));
        if H = nil then
        begin
          AResponse.Code := 404;
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := '{"hata":"hat yok"}';
          Exit;
        end;
        if not (OturumGecerli(H.Hat, ltok) or
          SifreTutuyor(HatSifresi(H.Hat), lpw) or OturumYonetici(ltok)) then
        begin
          AResponse.Code := 403;
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := '{"hata":"sifre gerekli"}';
          Exit;
        end;
        lokHat := UpperCase(Trim(H.Hat));
      end;
      lay := QParam(q, 'ay');
      if Trim(lay) = '' then lay := FormatDateTime('yyyy-mm', Now);
      if (Length(lay) <> 7) or (lay[5] <> '-') then
        lay := FormatDateTime('yyyy-mm', Now);
      { Gunluk artik .jsonl dosyasi degil, {HAT}_ISLEMGUNLUGU tablosu.
        'TUMU' istenirse butun hatlar birlestirilir (sadece yonetici). }
      gja := TJSONArray.Create;
      try
        if lokHat <> '' then
        begin
          gl := GunlukSatirlari(lokHat, lay, gsay);
          try
            for gi2 := 0 to gl.Count - 1 do
              if gja.Count < gsay then
                gja.Add(TJSONObject(gl.Items[gi2]).Clone);
          finally
            gl.Free;
          end;
        end
        else
        begin
          glst := Vt.Hatlar;
          try
            for gi2 := 0 to glst.Count - 1 do
            begin
              gl := GunlukSatirlari(glst[gi2], lay, gsay);
              try
                for k := 0 to gl.Count - 1 do
                  if gja.Count < gsay then
                    gja.Add(TJSONObject(gl.Items[k]).Clone);
              finally
                gl.Free;
              end;
              if gja.Count >= gsay then Break;
            end;
          finally
            glst.Free;
          end;
        end;
        AResponse.ContentType := 'application/json; charset=utf-8';
        AResponse.Content := gja.AsJSON;
      finally
        gja.Free;
      end;
      Exit;
    end;
  // /api/giris?hat=H
  if yol = '/api/giris' then
  begin
    H := HatBul(QParam(q, 'hat'));
    if H = nil then
    begin
      jdG.Free;
      AResponse.Code := 404;
      AResponse.ContentType := 'application/json; charset=utf-8';
      AResponse.Content := '{"hata":"hat yok","hatlar":' + HatListesiJson + '}';
      Exit;
    end;
    girSifre := '';
    if (jdG <> nil) and (jdG.JSONType = jtObject) then
      girSifre := JAlan(TJSONObject(jdG), 'sifre');
    jdG.Free;
    EnterCriticalSection(FKilit);
    try
      hs := HatSifresi(H.Hat);
      if hs = '' then
      begin
        // bu hatta sifre yok: giris acik, dogrudan oturum
        AResponse.ContentType := 'application/json; charset=utf-8';
        AResponse.Content := '{"oturma":"' + OturumAc(H.Hat) + '","acik":"1"}';
        Exit;
      end;
    finally
      LeaveCriticalSection(FKilit);
    end;
    if SifreTutuyor(HatSifresi('ADMIN'), girSifre) then
    begin
      { super kullanici: tum hatlarda gecerli oturum }
      AResponse.ContentType := 'application/json; charset=utf-8';
      AResponse.Content := '{"oturma":"' + OturumAc('*') + '","yonetici":"1"}';
    end
    else if SifreTutuyor(hs, girSifre) then
    begin
      AResponse.ContentType := 'application/json; charset=utf-8';
      AResponse.Content := '{"oturma":"' + OturumAc(H.Hat) + '"}';
    end
    else
    begin
      WriteLn(FormatDateTime('hh:nn:ss', Now) + ' HATALI YONETIM GIRISI (' + H.Hat + ').');
      AResponse.Code := 403;
      AResponse.ContentType := 'application/json; charset=utf-8';
      AResponse.Content := '{"hata":"sifre yanlis"}';
    end;
    Exit;
  end;
  if yol = '/yonetim.html' then
  begin
    H := HatBul(QParam(q, 'hat'));
    if (H <> nil) and (HatSifresi(H.Hat) <> '') and
      not OturumGecerli(H.Hat, QParam(q, 'oturma')) then
    begin
      opts := '';
      for oi := 0 to FHatlar.Count - 1 do
        if FHatlar[oi] = H.Hat then
          opts := opts + '<option value="' + FHatlar[oi] + '" selected>' +
            FHatlar[oi] + '</option>'
        else
          opts := opts + '<option value="' + FHatlar[oi] + '">' +
            FHatlar[oi] + '</option>';
      AResponse.Code := 401;
      AResponse.ContentType := 'text/html; charset=utf-8';
      AResponse.Content := GirisSayfasi(ARequest.URI,
        'Devam etmek icin hat secip giris yapin.', H.Hat, opts);
      Exit;
    end;
  end;
  // hat cozumu: statik dosya disindaki tum yollar hatta baglanir
  // (/api/hat ve /api/hatlar muaf: henuz var olmayan hat icin de calisir)
  H := nil;
  hatQ := '';
  if (yol <> '/') and (Copy(yol, 1, 4) <> '/bg/') and (Copy(yol, 1, 7) <> '/fonts/') and
    (Copy(yol, 1, 5) <> '/lib/') and (Pos('.', yol) = 0) and
    (yol <> '/api/hat') and (yol <> '/api/hatlar') then
  begin
    hatQ := QParam(q, 'hat');
    H := HatBul(hatQ);
    if H = nil then
    begin
      AResponse.Code := 404;
      AResponse.ContentType := 'application/json; charset=utf-8';
      AResponse.Content := '{"hata":"hat yok:' + hatQ + '","hatlar":' + HatListesiJson + '}';
      Exit;
    end;
    GerekirseYenidenYukle(H);
    // yazma korumasi: hatta sifre varsa POST/PUT/DELETE sifresiz calismaz
    // (sifre data/sifreler.json; yoksa herkes yazabilir)
    if (CompareText(ARequest.Method, 'POST') = 0) or
      (CompareText(ARequest.Method, 'PUT') = 0) or
      (CompareText(ARequest.Method, 'DELETE') = 0) then
    begin
      if (HatSifresi(H.Hat) <> '') and
        not SifreTutuyor(HatSifresi(H.Hat), QParam(q, 'sifre')) and
        not SifreTutuyor(HatSifresi('ADMIN'), QParam(q, 'sifre')) and
        not OturumGecerli(H.Hat, QParam(q, 'oturma')) then
      begin
        WriteLn(FormatDateTime('hh:nn:ss', Now) + ' YETKISIZ YAZMA DENEMESI (' +
          H.Hat + ' ' + yol + ')');
        AResponse.Code := 403;
        AResponse.ContentType := 'application/json; charset=utf-8';
        AResponse.Content := '{"hata":"sifre gerekli"}';
        Exit;
      end;
    end;
  end
  else
  begin
    // hat parametresi yoksa varsayilan hati kullan
    if FHatlar.Count = 0 then
    begin
      AResponse.Code := 500;
      AResponse.Content := 'hat deposu yok';
      Exit;
    end
    else
      H := THatStore(FHatlar.Objects[0]);
    GerekirseYenidenYukle(H);
  end;
  try
    EnterCriticalSection(FKilit);
    try
      if yol = '/' then
      begin
        AResponse.Code := 302;
        AResponse.SetCustomHeader('Location', '/pano.html');
        AResponse.Content := '';
      end
      else if yol = '/api/durum' then
      begin
        o := TJSONObject.Create;
        try
          o.Add('versiyon', 'mtakipwebsrv-' + SRV_VERSIYON);
          o.Add('zaman', FormatDateTime('hh:nn:ss', Now));
          o.Add('tarih', FormatDateTime('dd.mm.yyyy', Now));
          o.Add('seflik', AyarOku(H, 'SEFLIK'));
          o.Add('otomatikTarife', AyarOku(H, 'TARIFEOROMANUEL'));
          o.Add('onerilenTTID', TTIdSec(H));
          o.Add('gunKolon', GunKolon);
          o.Add('hat', H.Hat);
          o.Add('korumali', HatSifresi(H.Hat) <> '');
          jd := GetJSON(HatListesiJson);
          o.Add('hatlar', jd);
          arr := TJSONArray.Create;
          arr.Add(TabloSay(H, 'CIZELGE') > 0);
          o.Add('tablolar', TJSONObject.Create);
          TJSONObject(o.Find('tablolar')).Add('CIZELGE', TabloSay(H, 'CIZELGE'));
          TJSONObject(o.Find('tablolar')).Add('TIMETABLE', TabloSay(H, 'TIMETABLE'));
          TJSONObject(o.Find('tablolar')).Add('TIMETABLECEK', TabloSay(H, 'TIMETABLECEK'));
          TJSONObject(o.Find('tablolar')).Add('TTDETAY', TabloSay(H, 'TTDETAY'));
          arr.Free;
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := o.AsJSON;
        finally
          o.Free;
        end;
      end
      else if yol = '/api/yukle' then
      begin
        { Veritabani her istekte canli okundugu icin bellekten yuklemeye
          gerek yok. Butunluk denetimi yapilip cevap verilir. }
        if not Vt.ACIKMIs then
        begin
          AResponse.Code := 404;
          AResponse.Content := 'veritabani kapali';
        end
        else
        begin
          WriteLn(FormatDateTime('hh:nn:ss', Now) + ' BILGI: /api/yukle (veritabani canli).');
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := '{"sonuc":"OK","cizelge":' +
            IntToStr(TabloSay(H, 'CIZELGE')) + '}';
        end;
      end
      else if yol = '/api/ayarlar' then
      begin
        if CompareText(ARequest.Method, 'POST') = 0 then
        begin
          // ayarlari birlestir + kaydet (pano bir sonraki yoklamada gorur)
          try
            jd := GetJSON(ARequest.Content);
          except
            jd := nil;
          end;
          if (jd <> nil) and (jd.JSONType = jtObject) then
          begin
            for i := 0 to TJSONObject(jd).Count - 1 do
              AyarYaz(H, TJSONObject(jd).Names[i],
                TJSONObject(jd).Items[i].AsString);
            jd.Free;
            WriteLn(FormatDateTime('hh:nn:ss', Now) + ' AYAR KAYDET');
            AResponse.Content := 'OK(ayarlar kaydedildi)';
          end
          else
          begin
            jd.Free;
            AResponse.Code := 400;
            AResponse.Content := 'obje bekleniyor';
          end;
        end
        else
        begin
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := AyarJson(H);
        end;
      end
      else if yol = '/api/hatlar' then
      begin
        AResponse.ContentType := 'application/json; charset=utf-8';
        AResponse.Content := HatListesiJson;
      end
      else if yol = '/api/tablolar' then
      begin
        AResponse.ContentType := 'application/json; charset=utf-8';
        AResponse.Content := TabloAdlariJson(H);
      end
      else if (yol = '/api/yedek-al') or (yol = '/api/yedek-al/') then
      begin
        { Anlik yedek: motor dosyayi kilitli tutarken yalnizca sunucunun
          kendisi tutarli kopya alabilir. Sadece yonetici. }
        if not OturumYonetici(QParam(q, 'oturma')) then
        begin
          AResponse.Code := 403;
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := '{"hata":"sadece yonetici"}';
          Exit;
        end;
        ydAd := IncludeTrailingPathDelimiter(SaatKlasoru) + 'mtakip_' +
          FormatDateTime('yyyymmdd_hh', Now) + '.odb';
        if YedekAl(ydAd) then
        begin
          YedekKirp(SaatKlasoru, 24);
          GunlukYedekAl(GunKlasoru);
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := '{"sonuc":"OK","ad":"' + ExtractFileName(ydAd) + '"}';
        end
        else
        begin
          AResponse.Code := 500;
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := '{"hata":"yedek alinamadi"}';
        end;
        Exit;
      end
      else if yol = '/api/yedek-indir' then
      begin
        // yedek dosyasi indir (hat sifresi veya admin)
        H := HatBul(QParam(q, 'hat'));
        if H = nil then
        begin
          AResponse.Code := 404;
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := '{"hata":"hat yok"}';
          Exit;
        end;
        if not (OturumGecerli(H.Hat, QParam(q, 'oturma')) or
          SifreTutuyor(HatSifresi(H.Hat), QParam(q, 'sifre')) or
          OturumYonetici(QParam(q, 'oturma'))) then
        begin
          AResponse.Code := 403;
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := '{"hata":"sifre gerekli"}';
          Exit;
        end;
        ydAd := Trim(QParam(q, 'ad'));
        if not YedekYolCoz(ydAd, ydTam) then
        begin
          AResponse.Code := 400;
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := '{"hata":"yedek adi hatali"}';
          Exit;
        end;
        if not FileExists(ydTam) then
        begin
          AResponse.Code := 404;
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := '{"hata":"yedek bulunamadi"}';
          Exit;
        end;
        AResponse.ContentType := 'application/octet-stream';
        AResponse.SetCustomHeader('Content-Disposition',
          'attachment; filename="' + ydAd + '"');
        yfs := TFileStream.Create(ydTam, fmOpenRead or fmShareDenyNone);
        AResponse.ContentStream := yfs;
        AResponse.ContentLength := yfs.Size;
        AResponse.FreeContentStream := True;
        Exit;
      end
      else if yol = '/api/yedekler' then
      begin
        // yedek listesi: backup/mtakip_*.odb (hat sifresi veya admin)
        H := HatBul(QParam(q, 'hat'));
        if H = nil then
        begin
          AResponse.Code := 404;
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := '{"hata":"hat yok"}';
          Exit;
        end;
        if not (OturumGecerli(H.Hat, QParam(q, 'oturma')) or
          SifreTutuyor(HatSifresi(H.Hat), QParam(q, 'sifre')) or
          OturumYonetici(QParam(q, 'oturma'))) then
        begin
          AResponse.Code := 403;
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := '{"hata":"sifre gerekli"}';
          Exit;
        end;
        ydSira := TJSONArray.Create;
        try
          { Siralama once kayit dizisi uzerinde yapilir; JSON nesneleri en
            sonda uretilir. Ayni TJSONData'yi iki diziye eklemek fpjson'da
            sahiplik zincirini bozup cok serbest birlige yol aciyor. }
          { Uc katman birlikte listelenir: saat (24), gun (14), yazma (20).
            "tur" alani arayuzde hangi klasorden oldugunu gosterir. }
          N := 0;
          for I := 0 to 2 do
          begin
            case I of
              0: begin ydDir := SaatKlasoru;    ydTur := 'saat'; end;
              1: begin ydDir := GunKlasoru;     ydTur := 'gun'; end;
              else begin ydDir := YazmaKlasoru; ydTur := 'yazma'; end;
            end;
            if FindFirst(IncludeTrailingPathDelimiter(ydDir) + 'mtakip_*.odb',
              faAnyFile, ydSr) = 0 then
            begin
              repeat
                SetLength(ydKayit, N + 1);
                ydKayit[N].Zaman := FileDateToDateTime(ydSr.Time);
                ydKayit[N].Boyut := ydSr.Size;
                ydKayit[N].Tur := ydTur;
                ydKayit[N].Ad := ydSr.Name;
                Inc(N);
              until FindNext(ydSr) <> 0;
              FindClose(ydSr);
            end;
          end;

          { kucuk sayida kayit (en fazla 38) icin ekleme siralamasi yeter }
          for I := 1 to High(ydKayit) do
          begin
            ydTmp := ydKayit[I];
            J := I - 1;
            while (J >= 0) and (ydKayit[J].Zaman < ydTmp.Zaman) do
            begin
              ydKayit[J + 1] := ydKayit[J];
              Dec(J);
            end;
            ydKayit[J + 1] := ydTmp;
          end;

          for I := 0 to High(ydKayit) do
          begin
            ydObj := TJSONObject.Create;
            ydObj.Add('ad', ydKayit[I].Ad);
            ydObj.Add('tur', ydKayit[I].Tur);
            ydObj.Add('boyut', ydKayit[I].Boyut);
            ydObj.Add('zaman', FormatDateTime('yyyy-mm-dd hh:nn:ss',
              ydKayit[I].Zaman));
            ydSira.Add(ydObj);
          end;
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := ydSira.AsJSON;
        finally
          ydSira.Free;
        end;
        Exit;
      end
      else if yol = '/api/geri-yukle' then
      begin
        // veri dosyasini secili yedekten geri yukler (sadece yonetici).
        // once mevcut durum ayrica yedeklenir (_onceki).
        if (CompareText(ARequest.Method, 'POST') <> 0) or
          not OturumYonetici(QParam(q, 'oturma')) then
        begin
          AResponse.Code := 403;
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := '{"hata":"sadece yonetici"}';
          Exit;
        end;
        try
          jd := GetJSON(ARequest.Content);
        except
          jd := nil;
        end;
        ydAd := '';
        if (jd <> nil) and (jd.JSONType = jtObject) then
          ydAd := Trim(JAlan(TJSONObject(jd), 'yedek'));
        jd.Free;
        H := HatBul(QParam(q, 'hat'));
        if (H = nil) or not YedekYolCoz(ydAd, ydTam) then
        begin
          AResponse.Code := 400;
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := '{"hata":"hat veya yedek adi hatali"}';
          Exit;
        end;
        if not FileExists(ydTam) then
        begin
          AResponse.Code := 404;
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := '{"hata":"yedek bulunamadi"}';
          Exit;
        end;
        try
          { Geri yukleme: once mevcut durum ayrica bir klasore yedeklenir
            (geri yuklemeden hemen onceki hal, 5 adet tutulur), sonra
            veritabanini kapat, yedek dosyayla degistir, tekrar ac.
            Dosya kilidi acikken yazilamayacagi icin kapama sart. }
          ydOnceki := IncludeTrailingPathDelimiter(GeriYuklemeKlasoru) +
            FormatDateTime('yyyymmdd_hhnnss', Now) + '.odb';
          if not YedekAl(ydOnceki) then
          begin
            AResponse.Code := 500;
            AResponse.ContentType := 'application/json; charset=utf-8';
            AResponse.Content := '{"hata":"geri yukleme oncesi yedek alinamadi, islem durduruldu"}';
            Exit;
          end;
          YedekKirpMask(GeriYuklemeKlasoru, 5, '*.odb');
          Vt.Kapat;
          DosyaKopyala(ydTam, Vt.DosyaYol);
          Vt.Ac;
          WriteLn(FormatDateTime('hh:nn:ss', Now) + ' GERI YUKLEME (' +
            H.Hat + ' <- ' + ydAd + ')');
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := '{"sonuc":"OK","geri":"' + ExtractFileName(ydOnceki) + '"}';
        except
          on E: Exception do
          begin
            AResponse.Code := 500;
            AResponse.ContentType := 'application/json; charset=utf-8';
            AResponse.Content := 'hata: ' + E.Message;
          end;
        end;
        Exit;
      end
      else if yol = '/api/admin-sifre' then
      begin
        // super kullanici sifresi degistir (sha1 ozet yazilir)
        if (CompareText(ARequest.Method, 'POST') <> 0) or
          not OturumYonetici(QParam(q, 'oturma')) then
        begin
          AResponse.Code := 403;
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := '{"hata":"sadece yonetici"}';
          Exit;
        end;
        try
          jd := GetJSON(ARequest.Content);
        except
          jd := nil;
        end;
        ydYeni := '';
        if (jd <> nil) and (jd.JSONType = jtObject) then
          ydYeni := Trim(JAlan(TJSONObject(jd), 'yeni'));
        jd.Free;
        if Length(ydYeni) < 6 then
        begin
          AResponse.Code := 400;
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := '{"hata":"en az 6 karakter"}';
          Exit;
        end;
        if SifreDosyasiYaz('ADMIN', 'sha1:' + LowerCase(SHA1Print(SHA1String(
          UTF8Encode('mtakip-admin:' + UnicodeString(ydYeni)))))) then
        begin
          WriteLn(FormatDateTime('hh:nn:ss', Now) + ' ADMIN SIFRE DEGISTI.');
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := 'OK(admin sifre guncellendi)';
        end
        else
        begin
          AResponse.Code := 500;
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := '{"hata":"dosya yazilamadi"}';
        end;
        Exit;
      end
      else if yol = '/api/hat-sifre' then
      begin
        // hat sifresi belirle (sha1 ozet yazilir, en az 6 karakter)
        if (CompareText(ARequest.Method, 'POST') <> 0) or
          not OturumYonetici(QParam(q, 'oturma')) then
        begin
          AResponse.Code := 403;
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := '{"hata":"sadece yonetici"}';
          Exit;
        end;
        try
          jd := GetJSON(ARequest.Content);
        except
          jd := nil;
        end;
        ydAd := '';
        ydYeni := '';
        if (jd <> nil) and (jd.JSONType = jtObject) then
        begin
          ydAd := UpperCase(Trim(JAlan(TJSONObject(jd), 'hat')));
          ydYeni := Trim(JAlan(TJSONObject(jd), 'yeni'));
        end;
        jd.Free;
        if HatBul(ydAd) = nil then
        begin
          AResponse.Code := 400;
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := '{"hata":"hat yok"}';
          Exit;
        end;
        if Length(ydYeni) < 6 then
        begin
          AResponse.Code := 400;
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := '{"hata":"en az 6 karakter"}';
          Exit;
        end;
        if SifreDosyasiYaz(ydAd, 'sha1:' + LowerCase(SHA1Print(SHA1String(
          UTF8Encode('mtakip-admin:' + UnicodeString(ydYeni)))))) then
        begin
          WriteLn(FormatDateTime('hh:nn:ss', Now) + ' HAT SIFRE DEGISTI (' +
            ydAd + ').');
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := 'OK(hat sifre guncellendi:' + ydAd + ')';
        end
        else
        begin
          AResponse.Code := 500;
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := '{"hata":"dosya yazilamadi"}';
        end;
        Exit;
      end
      else if yol = '/api/oturumlar' then
      begin
        // aktif oturumlar (sadece yonetici)
        if not OturumYonetici(QParam(q, 'oturma')) then
        begin
          AResponse.Code := 403;
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := '{"hata":"sadece yonetici"}';
          Exit;
        end;
        ydArr := TJSONArray.Create;
        try
          EnterCriticalSection(FKilit);
          try
            for gi2 := 0 to FOturumlar.Count - 1 do
            begin
              ydObj := TJSONObject.Create;
              ydObj.Add('hat', Copy(FOturumlar[gi2], 1,
                Pos(':', FOturumlar[gi2]) - 1));
              ydObj.Add('token', Copy(FOturumlar[gi2],
                Pos(':', FOturumlar[gi2]) + 1, 999));
              ydArr.Add(ydObj);
            end;
          finally
            LeaveCriticalSection(FKilit);
          end;
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := ydArr.AsJSON;
        finally
          ydArr.Free;
        end;
        Exit;
      end
      else if yol = '/api/oturum-kapat' then
      begin
        // oturum dusur (sadece yonetici)
        if (CompareText(ARequest.Method, 'POST') <> 0) or
          not OturumYonetici(QParam(q, 'oturma')) then
        begin
          AResponse.Code := 403;
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := '{"hata":"sadece yonetici"}';
          Exit;
        end;
        try
          jd := GetJSON(ARequest.Content);
        except
          jd := nil;
        end;
        ydAd := '';
        if (jd <> nil) and (jd.JSONType = jtObject) then
          ydAd := Trim(JAlan(TJSONObject(jd), 'token'));
        jd.Free;
        if ydAd = '' then
        begin
          AResponse.Code := 400;
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := '{"hata":"token gerekli"}';
          Exit;
        end;
        OturumKapat(ydAd);
        WriteLn(FormatDateTime('hh:nn:ss', Now) + ' OTURUM KAPATILDI.');
        AResponse.ContentType := 'application/json; charset=utf-8';
        AResponse.Content := 'OK(oturum kapatildi)';
        Exit;
      end
      else if yol = '/api/guncelle-yukle' then
      begin
        // uzaktan guncelleme 1. adim: yeni exe'yi update klasorune al.
        // watchdog/kiosk baslatmadan once yerine koyar (sadece yonetici).
        if (CompareText(ARequest.Method, 'POST') <> 0) or
          not OturumYonetici(QParam(q, 'oturma')) then
        begin
          AResponse.Code := 403;
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := '{"hata":"sadece yonetici"}';
          Exit;
        end;
        raw := RawByteString(ARequest.Content);
        if (Length(raw) < 100000) or (Copy(raw, 1, 2) <> 'MZ') or
          (Length(raw) > 50 * 1024 * 1024) then
        begin
          AResponse.Code := 400;
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := '{"hata":"gecerli exe gerekli (MZ, 100KB-50MB)"}';
          Exit;
        end;
        updYol := IncludeTrailingPathDelimiter(ExtractFileDir(ParamStr(0))) +
          'update' + PathDelim;
        ForceDirectories(updYol);
        fs := TFileStream.Create(updYol + 'mtakipwebsrv.exe', fmCreate);
        try
          fs.WriteBuffer(Pointer(raw)^, Length(raw));
        finally
          fs.Free;
        end;
        WriteLn(FormatDateTime('hh:nn:ss', Now) + ' GUNCELLEME ALINDI (' +
          IntToStr(Length(raw)) + ' byte).');
        AResponse.ContentType := 'application/json; charset=utf-8';
        AResponse.Content := 'OK(guncelleme hazir, yeniden baslatin)';
        Exit;
      end
      else if yol = '/api/yeniden-baslat' then
      begin
        // uzaktan guncelleme 2. adim: server kendini kapatir,
        // watchdog 5 dk icinde (guncellemeyle) baslatir (sadece yonetici).
        if (CompareText(ARequest.Method, 'POST') <> 0) or
          not OturumYonetici(QParam(q, 'oturma')) then
        begin
          AResponse.Code := 403;
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := '{"hata":"sadece yonetici"}';
          Exit;
        end;
        IslemKaydet(hatQ, ARequest.Method, yol0, QParam(q, 'oturma'),
          'yeniden-baslat', 200);
        WriteLn(FormatDateTime('hh:nn:ss', Now) +
          ' YENIDEN BASLATILIYOR (uzaktan komut).');
        Halt(0);
      end
      else if yol = '/api/hat' then
      begin
        // yeni bos hat dosyasi olustur: {"hat":"M5"} (sadece super kullanici)
        if (CompareText(ARequest.Method, 'POST') = 0) and
          not OturumYonetici(QParam(q, 'oturma')) then
        begin
          AResponse.Code := 403;
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := '{"hata":"sadece yonetici yeni hat acabilir"}';
          Exit;
        end;
        if CompareText(ARequest.Method, 'POST') <> 0 then
        begin
          AResponse.Code := 405;
          AResponse.Content := '';
        end
        else
        begin
          try
            jd := GetJSON(ARequest.Content);
          except
            jd := nil;
          end;
          hatQ := '';
          if (jd <> nil) and (jd.JSONType = jtObject) then
            hatQ := UpperCase(Trim(JAlan(TJSONObject(jd), 'hat')));
          jd.Free;
          if (hatQ = '') or (Pos(' ', hatQ) > 0) then
          begin
            AResponse.Code := 400;
            AResponse.Content := 'hat gerekli (orn {"hat":"M5"})';
          end
          else if HatBul(hatQ) <> nil then
          begin
            AResponse.Code := 409;
            AResponse.Content := 'hat zaten var:' + hatQ;
          end
          else
          begin
            if FHatlar.Count = 0 then
            begin
              AResponse.Code := 500;
              AResponse.Content := 'hat deposu yok';
            end
            else if not HatGecerli(hatQ) then
            begin
              AResponse.Code := 400;
              AResponse.Content := 'hat adi gecersiz';
            end
            else
            begin
              { Yeni hat: semasi veritabaninda kurulur. }
              Vt.HatEkle(hatQ);
              FHatlar.AddObject(hatQ, THatStore.Olustur(hatQ));
              WriteLn(FormatDateTime('hh:nn:ss', Now) + ' YENI HAT: ' + hatQ);
              AResponse.Content := 'OK(hat olustu:' + hatQ + ')';
            end;
          end;
        end;
      end
      else if (Copy(yol, 1, 11) = '/api/tablo/') or (Copy(yol, 1, 7) = '/tablo/') then
      begin
        if Copy(yol, 1, 5) = '/api/' then adi := Copy(yol, 12, 999)
        else adi := Copy(yol, 8, 999);
        adi := UpperCase(Trim(adi));
        if CompareText(ARequest.Method, 'GET') = 0 then
        begin
          AResponse.ContentType := 'application/json; charset=utf-8';
          if adi = 'MAKINISTRESIM' then
          begin
            arr := TabloArr(H, adi);
            try
              if arr <> nil then AResponse.Content := arr.AsJSON
              else AResponse.Content := '[]';
            finally
              arr.Free;   { pano 2 sn'de bir bu ucu cagirir; birakilirsa
                             TIMETABLE agaci (T4'te 378 KB) her seferinde sizar }
            end;
          end
          else
          begin
            { Onbellekteki metin dogrudan gonderilir: ayristirip yeniden
              serilestirmeye gerek yok. }
            Metin := TabloMetin(H, adi);
            if Metin = '' then AResponse.Code := 404;
            AResponse.Content := Metin;
          end;
        end
        else if CompareText(ARequest.Method, 'POST') = 0 then
        begin
          { BOS GOVDE ASLA YAZMA YAPMAZ. Eski davranis bos dizi uretip
            TabloKaydet'e gonderiyordu; tablo bu yolla sessizce siliniyordu.
            Simdi 400 doner ve mevcut veri olduÄŸu gibi kalir. }
          if Trim(ARequest.Content) = '' then
          begin
            AResponse.Code := 400;
            AResponse.ContentType := 'application/json; charset=utf-8';
            AResponse.Content := '{"hata":"bos govde reddedildi, tabloya dokunulmadi"}';
          end
          else
          begin
            try
              jd := GetJSON(ARequest.Content);
            except
              jd := nil;
            end;
            if (jd <> nil) and (jd.JSONType = jtArray) then
            begin
              try
                if TabloKaydet(H, adi, TJSONArray(jd)) then
                  AResponse.Content := 'OK'
                else
                begin
                  AResponse.Code := 400;
                  AResponse.ContentType := 'application/json; charset=utf-8';
                  AResponse.Content := '{"hata":"yazma reddedildi, tabloya dokunulmadi"}';
                end;
              finally
                jd.Free;   { govde agaci: TabloKaydet sahiplenmez }
              end;
            end
            else
            begin
              jd.Free;
              AResponse.Code := 400;
              AResponse.Content := 'array bekleniyor';
            end;
          end;
        end
        else
        begin
          AResponse.Code := 405;
          AResponse.Content := '';
        end;
      end
      else if Copy(yol, 1, 17) = '/api/yukle-tablo/' then
      begin
        // Excel yukleme: ID eslesirse guncelle, yoksa ekle (tablodaki diger satirlar korunur)
        if CompareText(ARequest.Method, 'POST') <> 0 then
        begin
          AResponse.Code := 405;
          AResponse.Content := '';
        end
        else
        begin
          adi := UpperCase(Trim(Copy(yol, 18, 999)));
          try
            jd := GetJSON(ARequest.Content);
          except
            jd := nil;
          end;
          if (jd = nil) or (jd.JSONType <> jtArray) then
          begin
            jd.Free;
            AResponse.Code := 400;
            AResponse.Content := 'array bekleniyor';
          end
          else
          begin
            arr := TabloArr(H, adi);
            if arr = nil then arr := TJSONArray.Create;
            yeni := TJSONArray(jd);
            ek := 0;
            gu := 0;
            for i := 0 to yeni.Count - 1 do
            begin
              if (yeni.Items[i] = nil) or (yeni.Items[i].JSONType <> jtObject) then
                Continue;
              o := TJSONObject(yeni.Items[i]);
              rid := '';
              if o.Find('ID') <> nil then rid := Trim(o.Find('ID').AsString);
              hedef := nil;
              if rid <> '' then
                for k := 0 to arr.Count - 1 do
                  if (arr.Items[k] <> nil) and (arr.Items[k].JSONType = jtObject) and
                    (JAlan(TJSONObject(arr.Items[k]), 'ID') = rid) then
                  begin
                    hedef := TJSONObject(arr.Items[k]);
                    Break;
                  end;
              if hedef = nil then
              begin
                if rid = '' then rid := SonrakiId(H, adi);
                hedef := TJSONObject.Create;
                hedef.Add('ID', rid);
                arr.Add(hedef);
                Inc(ek);
              end
              else
                Inc(gu);
              for k := 0 to o.Count - 1 do
              begin
                fnam := o.Names[k];
                if CompareText(fnam, 'ID') = 0 then Continue;
                fd := hedef.Find(fnam);
                if fd = nil then hedef.Add(fnam, o.Items[k].AsString)
                else fd.AsString := o.Items[k].AsString;
              end;
            end;
            yeni.Free;
            if not TabloKaydet(H, adi, arr) then
            begin
              arr.Free;
              AResponse.Code := 400;
              AResponse.ContentType := 'application/json; charset=utf-8';
              AResponse.Content := '{"hata":"yazma reddedildi, tabloya dokunulmadi"}';
              Exit;
            end;
            arr.Free;   { TabloKaydet sahiplenmez }
            WriteLn(FormatDateTime('hh:nn:ss', Now) + ' UPSERT ' + adi +
              ': +' + IntToStr(ek) + ' ~' + IntToStr(gu));
            AResponse.ContentType := 'application/json; charset=utf-8';
            AResponse.Content := '{"sonuc":"OK","eklenen":' + IntToStr(ek) +
              ',"guncellenen":' + IntToStr(gu) + '}';
          end;
        end;
      end
      else if Copy(yol, 1, 19) = '/api/temizle-tablo/' then
      begin
        // yeniden-yaz modu: bir tabloda TTID'si eslesen satirlari sil
        if CompareText(ARequest.Method, 'POST') <> 0 then
        begin
          AResponse.Code := 405;
          AResponse.Content := '';
        end
        else
        begin
          adi := UpperCase(Trim(Copy(yol, 20, 999)));
          try
            jd := GetJSON(ARequest.Content);
          except
            jd := nil;
          end;
          ttid := '';
          if (jd <> nil) and (jd.JSONType = jtObject) then
            ttid := JAlan(TJSONObject(jd), 'TTID');
          jd.Free;
          if ttid = '' then
          begin
            AResponse.Code := 400;
            AResponse.Content := 'TTID gerekli';
          end
          else
          begin
            arr := TabloArr(H, adi);
            ek := 0;
            if arr <> nil then
              for i := arr.Count - 1 downto 0 do
              begin
                fd := arr.Items[i];
                if (fd <> nil) and (fd.JSONType = jtObject) and
                  (JAlan(TJSONObject(fd), 'TTID') = ttid) then
                begin
    arr.Delete(i);
    Inc(ek);
    end;
    end;
    if not TabloKaydet(H, adi, arr) then
    begin
      arr.Free;
      AResponse.Code := 400;
      AResponse.ContentType := 'application/json; charset=utf-8';
      AResponse.Content := '{"hata":"yazma reddedildi, tabloya dokunulmadi"}';
      Exit;
    end;
    arr.Free;
    WriteLn(FormatDateTime('hh:nn:ss', Now) + ' TEMIZLE ' + adi +
              ' TTID=' + ttid + ': -' + IntToStr(ek));
            AResponse.ContentType := 'application/json; charset=utf-8';
            AResponse.Content := '{"sonuc":"OK","silinen":' + IntToStr(ek) + '}';
          end;
        end;
      end
      else if yol = '/api/pano' then
      begin
        ttid := QParam(q, 'ttid');
        gun := QParam(q, 'gun');
        suan := QParam(q, 'suan');
        yon := QParam(q, 'yon');
        amod := QParam(q, 'mod');
        o := PanoHesapla(H, ttid, gun, suan, yon, amod);
        try
          AResponse.ContentType := 'application/json; charset=utf-8';
          AResponse.Content := o.AsJSON;
        finally
          o.Free;
        end;
      end
      else if (yol = '/komut') or (yol = '/api/komut') then
      begin
        if CompareText(ARequest.Method, 'POST') = 0 then
        begin
          yol := Trim(ARequest.Content);
          adi := KomutIsle(H, yol);
          WriteLn(FormatDateTime('hh:nn:ss', Now) + ' KOMUT: ' + yol + ' ' + adi);
          AResponse.Content := 'OK' + adi;
        end
        else begin AResponse.Code := 405; AResponse.Content := ''; end;
      end
      else if (yol = '/dosyaal') or (yol = '/api/dosyaal') then
      begin
        // eski istemci uyumlulugu: ham govdeyi veritabani klasorune yaz
        adi := QParam(q, 'adi');
        if adi = '' then adi := 'yukleme.bin';
        adi := ExtractFileName(adi);
        raw := RawByteString(ARequest.Content);
        ForceDirectories(Vt.DizinYolu);
        fs := TFileStream.Create(IncludeTrailingPathDelimiter(Vt.DizinYolu) + adi,
          fmCreate);
        try
          if Length(raw) > 0 then fs.WriteBuffer(Pointer(raw)^, Length(raw));
        finally
          fs.Free;
        end;
        WriteLn(FormatDateTime('hh:nn:ss', Now) + ' DOSYA: ' + adi +
          ' (' + IntToStr(Length(raw)) + ' byte)');
        AResponse.Content := 'OK';
      end
      else if yol = '/api/resim' then
      begin
        if CompareText(ARequest.Method, 'POST') = 0 then
        begin
          // ham jpeg/png govde -> MAKINISTRESIM BLOB kolonuna (SICILID PK)
          sicil := Trim(QParam(q, 'sicil'));
          raw := RawByteString(ARequest.Content);
          if (sicil = '') or (Length(raw) < 100) then
          begin
            AResponse.Code := 400;
            AResponse.Content := 'sicil ve gorsel gerekli';
          end
          else
          begin
            Vt.FotoYaz(H.Hat, sicil, raw);
            WriteLn(FormatDateTime('hh:nn:ss', Now) + ' FOTO: ' + sicil +
              ' (' + IntToStr(Length(raw)) + ' byte)');
            AResponse.Content := 'OK(foto kaydedildi:' + sicil + ')';
          end;
        end
        else
        begin
        // MAKINISTRESIM.RESIM (BLOB) -> ham goruntu (PK ile O(1) okuma)
        sicil := Trim(QParam(q, 'sicil'));
        raw := Vt.FotoOku(H.Hat, sicil);
        if Length(raw) = 0 then
        begin
          AResponse.Code := 404;
          AResponse.Content := 'foto yok';
        end
        else
        begin
          ms := TMemoryStream.Create;
          if Length(raw) > 0 then ms.WriteBuffer(Pointer(raw)^, Length(raw));
          ms.Position := 0;
          if (Length(raw) > 3) and (raw[1] = #$FF) and (raw[2] = #$D8) then
            AResponse.ContentType := 'image/jpeg'
          else if (Length(raw) > 4) and (raw[1] = #$89) and (raw[2] = 'P') then
            AResponse.ContentType := 'image/png'
          else
            AResponse.ContentType := 'application/octet-stream';
          AResponse.ContentStream := ms;
          AResponse.ContentLength := ms.Size;
          AResponse.FreeContentStream := True;
        end;
        end;
      end
      else
        StatikSun(Copy(yol, 2, 9999), AResponse);
      { islem gunlugu: yazan istekler (sifre/token yazilmaz) }
      if (CompareText(ARequest.Method, 'POST') = 0) or
        (CompareText(ARequest.Method, 'PUT') = 0) or
        (CompareText(ARequest.Method, 'DELETE') = 0) then
      begin
        if (yol0 = '/komut') or (yol0 = '/api/komut') then
          IslemKaydet(hatQ, ARequest.Method, yol0, QParam(q, 'oturma'),
            Trim(ARequest.Content), AResponse.Code)
        else if yol0 = '/api/resim' then
          IslemKaydet(hatQ, ARequest.Method, yol0, QParam(q, 'oturma'),
            'sicil=' + QParam(q, 'sicil'), AResponse.Code)
        else
          IslemKaydet(hatQ, ARequest.Method, yol0, QParam(q, 'oturma'),
            'uzunluk=' + IntToStr(Length(ARequest.Content)), AResponse.Code);
      end;
    finally
      LeaveCriticalSection(FKilit);
    end;
  except
    on E: Exception do
    begin
      AResponse.Code := 500;
      AResponse.Content := 'hata: ' + E.Message;
    end;
  end;
end;

end.
